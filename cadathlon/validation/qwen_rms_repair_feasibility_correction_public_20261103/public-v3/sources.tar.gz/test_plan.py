"""Pure public mathematical and level-accounting checks; no model or backend."""
import hashlib,json,math
from decimal import Decimal,localcontext
from fractions import Fraction as F
from pathlib import Path
import pytest
import plan

@pytest.mark.parametrize('x,y',[(F(1,100),F(1,2)),(F(3,4),F(1)),(F(9),F(1,4)),(F(1),F(1))])
def test_tracked_identity_and_ranges(x,y):
    z=y/1024;w=(1-x*y*y)/4
    for _ in range(3):
        assert 0<=w<=F(1,4) and 0<=z<=1
        next_y=y*(3-x*y*y)/2
        next_z=z*(1+2*w);next_w=w*w*(3+4*w)
        assert next_z==next_y/1024 and next_w==(1-x*next_y*next_y)/4
        assert next_w<=w and next_z>=z
        z,w,y=next_z,next_w,next_y

@pytest.mark.parametrize('a,b',[(F(1,10**6),F(1,32)),(F(1,10**6),F(10**6)),(F(1,10**6),F(4*10**13)),(F(1),F(1))])
def test_uniform_directed_certificate(a,b):
    result=plan.certificate(a,b)
    assert result['scaled_inverse_bound_premise']
    with localcontext() as c:
        c.prec=120
        aa=Decimal(a.numerator)/Decimal(a.denominator)
        y=Decimal(2)**(-result['seed_exponent_rule_k'])
        for _ in range(result['iterations']):y=y*(3-aa*y*y)/2
        relative=abs(aa.sqrt()*y-1)
        assert relative<=Decimal(result['final_relative_error_upper'])<=Decimal('1e-6')
    assert result['complete_rms_aligned_depth']==result['tracked_aligned_state_depth']+4

@pytest.mark.parametrize('args',[(0,1),(-1,2),(2,1)])
def test_invalid_certificate_domain(args):
    with pytest.raises(ValueError):plan.certificate(*args)

@pytest.mark.parametrize('capacity',[25,28,29,31])
@pytest.mark.parametrize('iterations',[1,2,8,16,32,64])
def test_every_actual_level_branch(capacity,iterations):
    result=plan.level_schedule(iterations,variance_level=capacity-2,refresh_capacity=capacity,trace=True)
    events={r['before_update']:r for r in result['events']}
    w,z=capacity-3,None;calls=0
    for step in result['updates']:
        if step['update'] in events:
            event=events[step['update']]
            assert event['w_input']==w and event['z_input']==z
            assert w>=2 and (z is None or z>=2)
            calls+=1+(z is not None);w=capacity;z=capacity if z is not None else None
        assert step['w_input']==w and step['z_input']==z
        # Independent operation DAG: each public affine, CT multiply and real
        # unit alignment consumes one level. No metadata reset is inferred.
        w_square=w-1;w_correction=w-1
        new_w=min(w_square,w_correction)-2
        new_z=w-1 if z is None else min(z,w-1)-2
        assert (step['w_output'],step['z_output'])==(new_w,new_z)
        assert new_w>=4 and new_z>=4
        w,z=new_w,new_z
    assert calls==result['state_refresh_calls']
    assert result['final_norm_output_level']==min(capacity,z)-2>=2


def test_frozen_input_bytes():
    for name,digest in plan.INPUT_PINS.items():
        assert hashlib.sha256((plan.HERE/name).read_bytes()).hexdigest()==digest


def test_frozen_exp_and_reciprocal_uniform_premises():
    m=json.loads((plan.HERE/'inputs/candidate2_manifest.json').read_text())
    p=plan.softmax_premises(m)
    assert len(p['reciprocal_checks'])==33 and len(p['mass_checks'])==32
    assert all(r['passes_1e_12'] for r in p['reciprocal_checks'].values())
    assert p['exp_positive_lower']['upper_binary64']>.5 and p['exp_upper']['upper_binary64']<2
    # Independent sampled polynomial checks only supplement the analytic proof.
    coeff=m['exp']['evaluation_coefficients']
    E=p['exp_uniform_abs_error']['upper_binary64']
    for i in range(1001):
        t=-1+2*i/1000
        actual=sum(c*t**n for n,c in enumerate(coeff))
        assert .5<actual<2 and abs(actual-math.exp(t/2))<=E


def test_exact_mass_and_same_square_correlation():
    p=[F(1,10),F(2,10),F(7,10)];r=F(1,10**12)
    d=sum(x*x for x in p);q=[x*x*(1-r)/d for x in p]
    assert all(x>=0 for x in q) and sum(q)==1-r
    # A denominator-only perturbation destroys this identity: no refresh proof
    # may substitute a different denominator and retain exact mass assertions.
    changed=[x*x*(1-r)/(d+F(1,1000)) for x in p]
    assert sum(changed)!=1-r


def test_cancellation_is_a_concrete_obligation():
    r=plan.certificate(F(1,10**6),F(4*10**13))
    assert r['binary64_lower_endpoint_diagnostic']['initial_w_rounded_to_fixed_point']
    assert not r['binary64_lower_endpoint_diagnostic']['passes_1e_6']


def test_w_perturbation_lipschitz():
    # f'(w)=6w+12w² increases over[0,1/4], reaching9/4 exactly.
    assert 6*F(1,4)+12*F(1,4)**2==F(9,4)
    for x in [F(i,400) for i in range(101)]:
        for y in [F(0),F(1,8),F(1,4)]:
            assert abs(x*x*(3+4*x)-y*y*(3+4*y))<=F(9,4)*abs(x-y)


@pytest.mark.parametrize('K',[1,3,5,6,7,10,31,32])
def test_actual_frozen_initial_chain_shared_alpha(K):
    # Execute the actual denominator, affine seed, five Newton updates,
    # per-entry product, and final alpha affine using exact rational arithmetic.
    # No reference mass formula replaces the circuit under test.
    m=json.loads((plan.HERE/'inputs/candidate2_manifest.json').read_text())
    rule=m['initial_reciprocal'];alpha=F(1./K)
    base=[F(1)+F(i,10*K) for i in range(K)]
    denominator=alpha*sum(base)
    inverse=F(rule['rounded_first_weight'])*denominator+F(rule['rounded_first_bias'])
    for _ in range(1,rule['iterations']):
        product=denominator*inverse
        correction=2-product
        inverse=inverse*correction
    probabilities=[alpha*(x*inverse) for x in base]
    mass=sum(probabilities);residual=1-denominator*inverse
    assert mass==1-residual and 1-F(1,10**12)<=mass<=1
    proof=plan.softmax_premises(m)['mass_checks'][str(K)]
    assert F(int(proof['first_mass_lower']['numerator']),int(proof['first_mass_lower']['denominator']))<=mass
    assert mass<=F(int(proof['first_mass_upper']['numerator']),int(proof['first_mass_upper']['denominator']))


def test_preserved_v2_upper_bound_counterexample():
    m=json.loads((plan.HERE/'inputs/candidate2_manifest.json').read_text())
    rule=m['initial_reciprocal'];alpha=F(1./3);base=[F(1)]*3
    denominator=alpha*sum(base)
    inverse=F(rule['rounded_first_weight'])*denominator+F(rule['rounded_first_bias'])
    for _ in range(1,rule['iterations']):inverse=inverse*(2-denominator*inverse)
    actual_mass=sum(alpha*(x*inverse) for x in base)
    assert actual_mass>3*alpha # Old v2 reported this beta as the mass upper.
    assert 1-F(1,10**12)<=actual_mass<=1
