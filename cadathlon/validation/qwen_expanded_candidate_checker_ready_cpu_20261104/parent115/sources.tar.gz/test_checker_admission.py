"""Synthetic public proof structure tests; no actual observer result is read."""
from pathlib import Path
from types import SimpleNamespace
import copy
import io
import json
import tarfile
import pytest
import checker_admission as a

HERE = Path(__file__).parent


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False)+'\n').encode()


def fixture(monkeypatch, initial=None):
    base_raw = (HERE/'public/candidate3_manifest.json').read_bytes()
    base = json.loads(base_raw)
    external=json.loads((HERE/'external_inputs.json').read_bytes())
    binding = initial or SimpleNamespace(parent_report_sha256='1'*64, worker_report_sha256='2'*64,
        root_review_sha256='3'*64, reconstruction_script_sha256='3690b5710a8f019f529062303289d415fad99d85bb579ff426e66ec9633ff2e3', root_outer_sha256='5'*64,
        snapshot_descriptor_bytes=encoded({'sha256':'6'*64}), calibration_sha256=external['calibration']['sha256'],
        model_pins_bytes=(HERE/'public/model_pins.json').read_bytes(), protocol_sha256=a.PROTOCOL,
        baseline_manifest_sha256=a.BASELINE, proof_sha256='8'*64,source_archive_sha256='9'*64)
    monkeypatch.setattr(a, '_initial', lambda blobs, rows: binding)
    blobs = {'public/candidate3_manifest.json':base_raw}
    for name in ('protocol.json','public/protocol.json','external_inputs.json','public/model_pins.json'):
        blobs[name]=(HERE/name).read_bytes()
    def put(name, value, raw=False):
        data = value if raw else encoded(value)
        key = 'candidate_proof/'+name
        blobs[key] = data
        return dict(blob=key, sha256=a.sha(data))
    sources = {f'source{i}.py': b'# synthetic selector\n' for i in range(8)}
    expected = {n:a.sha(b) for n,b in sources.items()}
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode='w:gz') as t:
        for n,b in sources.items():
            info=tarfile.TarInfo(n);info.size=len(b);t.addfile(info,io.BytesIO(b))
    source = put('source_manifest.json', expected)
    archive = put('sources.tar.gz', buf.getvalue(), True)
    evidence={name:dict(path='/synthetic/proof/'+name,sha256=pin,bytes=1) for name,pin in dict(
        parent=binding.parent_report_sha256,worker=binding.worker_report_sha256,source_archive=binding.source_archive_sha256,
        root_review=binding.root_review_sha256,reconstruction_script=binding.reconstruction_script_sha256,
        root_reconstruction_outer_receipt=binding.root_outer_sha256).items()}
    grant = put('grant.json', dict(schema='qwen-expanded-initial-selector-grant-v1',ready=True,
        execute_authorized=True,candidate_ordinal=1,source_manifest_sha256=source['sha256'],
        observer_source_manifest_sha256=a.OBSERVER_MANIFEST,protected_manifest_sha256=a.BASELINE,
        protocol_sha256=a.PROTOCOL,gate_bounds_sha256='761a07e232e0bba981ba014eb6d202cce96a9471616743594fecdc6a57d67840',
        output_directory='/synthetic/selection',model_execution=False,token_or_calibration_body_reads=False,
        validation_body_reads=False,encrypted_execution=False,preflight_report_sha256='a'*64,
        independent_preflight_review_sha256='b'*64,initial_evidence=evidence))
    candidate = copy.deepcopy(base)
    candidate.update(schema='qwen-expanded-initial-selection-v1', candidate_index=1, candidate_ordinal=1,
        synthetic_only=False, actual_coefficient_selection=True, all_norm_sites_supported=True,
        protected_rules_supported=True, all_silu_sites_supported=True, all_centered_softmax_sites_supported=True,
        parent_manifest_sha256=a.BASELINE, protocol_sha256=a.PROTOCOL,
        initial_parent_report_sha256=binding.parent_report_sha256, initial_snapshot_sha256=json.loads(binding.snapshot_descriptor_bytes)['sha256'],
        selection_grant_sha256=grant['sha256'], selector_source_manifest_sha256=source['sha256'])
    candidate_row = put('candidate.json',candidate)
    assessments = put('assessments.json',{name:{'synthetic':True} for name in a.NORMS})
    checks = put('protected_checks.json',{str(i):dict(radius_covered=True, observed_silu_covered=True,
        observed_centered_scores_covered=True) for i in range(28)})
    report = dict(schema='qwen-expanded-initial-selection-report-v1',
        **{k:True for k in a.TERMINAL}, publication_complete=True,actual_coefficient_selection=True,
        candidate_supported=True,all_norm_sites_supported=True,protected_rules_supported=True,
        private_inputs_never_removed=True,model_execution=False,token_or_calibration_body_reads=False,
        validation_body_reads=False,encrypted_execution=False,synthetic_only=False,audit_denials=[],
        candidate_ordinal=1,source_hashes_start=expected,source_hashes_end=expected,
        source_manifest_sha256=source['sha256'],source_archive={'sha256':archive['sha256']},
        grant_sha256=grant['sha256'],initial_parent_report_sha256=binding.parent_report_sha256,
        initial_worker_report_sha256=binding.worker_report_sha256,initial_root_review_sha256=binding.root_review_sha256,
        reconstruction_script_sha256=binding.reconstruction_script_sha256,root_reconstruction_outer_sha256=binding.root_outer_sha256,
        initial_snapshot_sha256=json.loads(binding.snapshot_descriptor_bytes)['sha256'],calibration_sha256=binding.calibration_sha256,
        model_pins_sha256=a.sha(binding.model_pins_bytes),protocol_sha256=a.PROTOCOL,
        outputs={name:dict(sha256=row['sha256'],bytes=len(blobs[row['blob']])) for name,row in (
            ('candidate_manifest.json',candidate_row),('assessments.json',assessments),('protected_checks.json',checks))})
    report_row=put('report.json',report)
    outer=dict(schema='qwen-initial-selection-root-terminal-v1',exit_code=0,reaped=True,process_group_absent=True,
        report_sha256=report_row['sha256'],source_archive_sha256=archive['sha256'],source_manifest_sha256=source['sha256'],
        candidate_manifest_sha256=candidate_row['sha256'],grant_sha256=grant['sha256'])
    outer_row=put('outer.json',outer)
    config=dict(schema='qwen-candidate-checker-binding-v1',ready=True,candidate=candidate_row,initial_proof={},
        selector_proof=dict(report=report_row,archive=archive,source_manifest=source,outer=outer_row,grant=grant,
            assessments=assessments,protected_checks=checks),budget=dict(max_candidates=3,ordinal=1,
            previous_attempts=[],manifest_sha256=candidate_row['sha256']))
    def seal():blobs['candidate_binding.json']=encoded(config)
    seal()
    return blobs,config,candidate,report,outer,put,seal


def test_pending_rejects_before_initial_or_body(monkeypatch):
    monkeypatch.setattr(a,'_initial',lambda *args:pytest.fail('pending initial proof touched'))
    with pytest.raises(PermissionError):
        a.require_candidate({'candidate_binding.json':(HERE/'candidate_binding.json').read_bytes()})


def test_synthetic_public_binding_returns_immutable_bytes(monkeypatch):
    blobs,*rest=fixture(monkeypatch);binding=a.require_candidate(blobs)
    assert binding.ordinal==1 and binding.execution_authorized is False
    assert type(binding.manifest_bytes)is bytes
    with pytest.raises(AttributeError):binding.ordinal=2


@pytest.mark.parametrize('field,value',[(k,False) for k in a.TERMINAL]+[
    ('publication_complete',False),('candidate_supported',False),('audit_denials',['forbidden']),
    ('model_execution',True),('synthetic_only',True),('candidate_ordinal',True),
    ('initial_parent_report_sha256','0'*64),('calibration_sha256','0'*64),('error_type','OSError')])
def test_failed_or_incomplete_selector_rejected(monkeypatch,field,value):
    blobs,config,candidate,report,outer,put,seal=fixture(monkeypatch)
    report[field]=value;row=put('report.json',report);config['selector_proof']['report']=row
    outer['report_sha256']=row['sha256'];config['selector_proof']['outer']=put('outer.json',outer);seal()
    with pytest.raises(ValueError):a.require_candidate(blobs)


@pytest.mark.parametrize('field,value',[('exit_code',False),('reaped',False),('process_group_absent',False),
    ('candidate_manifest_sha256','a'*64),('report_sha256','a'*64)])
def test_selector_outer_terminal_required(monkeypatch,field,value):
    blobs,config,candidate,report,outer,put,seal=fixture(monkeypatch)
    outer[field]=value;config['selector_proof']['outer']=put('outer.json',outer);seal()
    with pytest.raises(ValueError):a.require_candidate(blobs)


@pytest.mark.parametrize('field,value',[('max_candidates',True),('max_candidates',4),('ordinal',2),
    ('previous_attempts',[{}]),('manifest_sha256','b'*64)])
def test_budget_cannot_be_reset_or_revision_inferred(monkeypatch,field,value):
    blobs,config,*remaining=fixture(monkeypatch);config['budget'][field]=value;remaining[-1]()
    with pytest.raises(ValueError):a.require_candidate(blobs)


@pytest.mark.parametrize('mutation',['silu','softmax','missing_norm','bool_ordinal','synthetic'])
def test_candidate_protected_identity_and_inventory(monkeypatch,mutation):
    blobs,config,candidate,report,outer,put,seal=fixture(monkeypatch)
    if mutation=='silu':candidate['nonlinear']['0.silu']['domain']=[-100.,100.]
    if mutation=='softmax':candidate['softmax']['0']['centered_domain']=[-100.,100.]
    if mutation=='missing_norm':del candidate['nonlinear']['final.inverse_sqrt']
    if mutation=='bool_ordinal':candidate['candidate_index']=True
    if mutation=='synthetic':candidate['synthetic_only']=True
    config['candidate']=put('candidate.json',candidate);config['budget']['manifest_sha256']=config['candidate']['sha256'];seal()
    with pytest.raises(ValueError):a.require_candidate(blobs)


def test_body_bytes_not_opened_by_pending_or_public_gate(monkeypatch):
    blobs,*_=fixture(monkeypatch)
    monkeypatch.setattr('builtins.open',lambda *args,**kwargs:pytest.fail('public gate read file'))
    a.require_candidate(blobs)


def test_source_archive_drift_rejected(monkeypatch):
    blobs,config,*rest=fixture(monkeypatch)
    row=config['selector_proof']['archive'];blobs[row['blob']]=b'changed'
    rest[-1]()
    with pytest.raises(ValueError):a.require_candidate(blobs)


@pytest.mark.parametrize('mutation',[None,'native_count','failed_parent','missing_root_reap','source_manifest'])
def test_actual_initial_authenticator_with_synthetic_complete61_proof(monkeypatch,mutation):
    import initial_proof as p
    from test_initial_proof import fixture as initial_fixture, encode
    original=a._initial
    data=initial_fixture()
    if mutation=='native_count':data[1]['native_forward_completed']=3231
    if mutation=='failed_parent':data[0]['passed']=False
    proof,pins,snapshot,outer=encode(data)
    # Bind selector structure to the otherwise-good independent synthetic proof.
    good_proof,good_pins,_,good_outer=encode(initial_fixture())
    initial=p.authenticate_initial(*good_proof,pins=good_pins,root_outer_bytes=good_outer)
    blobs,config,candidate,report,selector_outer,put,seal=fixture(monkeypatch,initial)
    monkeypatch.setattr(a,'_initial',original)
    if mutation=='missing_root_reap':
        row=json.loads(outer);row['reaped']=False;outer=encoded(row)
    manifest=pins.source_manifest_bytes
    if mutation=='source_manifest':manifest+=b' '
    rows={name:put('initial-'+name,raw,True) for name,raw in dict(parent=proof[0],worker=proof[1],
        archive=proof[2],root=proof[3],manifest=manifest,
        script=(HERE/'inputs/reconstruction_script.py.txt').read_bytes(),outer=outer).items()}
    config['initial_proof']=rows;seal()
    if mutation is None:
        result=a.require_candidate(blobs)
        assert result.initial_report_sha256==initial.parent_report_sha256
    else:
        with pytest.raises(ValueError):a.require_candidate(blobs)


@pytest.mark.parametrize('raw',[b'{"n":NaN}',b'{"n":1e999}',b'{"n":Infinity}',b'{"n":1,"n":2}'])
def test_nonfinite_or_duplicate_public_metadata_rejected(raw):
    with pytest.raises(ValueError):a.parse(raw)
