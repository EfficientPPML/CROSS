"""Pure public-proof candidate admission, separate from execution authority.

The pending source contract admits nothing. A reviewed successor must freeze all
public proof bytes and their external pins before any candidate model execution.
No initial ranges, journals, tokens, model files or validation bodies are read.
Only ordinal one is implemented here; revisions require their own reviewed gate.
"""
from dataclasses import dataclass
import hashlib
import io
import json
import math
from pathlib import PurePosixPath
import tarfile

BASELINE = '7f6478a6bc710f3d2a370198e075e6ba8b0e55c144d981bca0eed59eaf176333'
PROTOCOL = 'eea8e4b38b4c2719e63a0aa13028150564901305e9e5f1f9d0f2985c821cb70f'
OBSERVER_MANIFEST = '8131c5ac045f1cf274a493bbc14278e330c0a8e057079edc4f10f9a23dd9bf91'
NORMS = frozenset(f'{i}.{part}.inverse_sqrt' for i in range(28)
                  for part in ('input', 'post', 'q', 'k')) | {'final.inverse_sqrt'}
TERMINAL = ('passed', 'complete', 'cleanup_completed', 'signal_restoration_completed',
            'source_files_unchanged', 'terminal_after_body_cleanup_and_signal_restoration_attempts',
            'acceptance_requires_independent_exit0_reap_and_exact_report_hash')


@dataclass(frozen=True, slots=True)
class CandidateBinding:
    manifest_bytes: bytes
    manifest_sha256: str
    ordinal: int
    initial_report_sha256: str
    calibration_sha256: str
    protocol_sha256: str
    selection_proof_sha256: str
    initial_proof_sha256: str
    binding_sha256: str
    selector_source_manifest_sha256: str
    selector_outer_sha256: str
    execution_authorized: bool = False


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def parse(raw):
    if type(raw) is not bytes:
        raise ValueError('Immutable proof bytes required')
    def pairs(items):
        result = {}
        for name, value in items:
            if name in result:
                raise ValueError('Duplicate proof field')
            result[name] = value
        return result
    def invalid(value):
        raise ValueError('Nonfinite proof number')
    def number(value):
        result = float(value)
        if not math.isfinite(result):
            raise ValueError('Nonfinite proof number')
        return result
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid, parse_float=number)


def digest(value):
    return type(value) is str and len(value) == 64 and all(c in '0123456789abcdef' for c in value)


def same(left, right):
    return canonical(left) == canonical(right)


def require_int(value, expected):
    if type(value) is not int or value != expected:
        raise ValueError('Exact typed proof integer differs')


def fields(value, expected):
    if type(value) is not dict or set(value) != set(expected):
        raise ValueError('Exact proof fields required')


def bound_blob(blobs, row, *, limit=32 << 20):
    fields(row, ('blob', 'sha256'))
    name = row['blob']
    if (type(name) is not str or not name.startswith('candidate_proof/') or
            PurePosixPath(name).as_posix() != name or '..' in PurePosixPath(name).parts or
            not digest(row['sha256'])):
        raise ValueError('Pinned candidate public blob required')
    raw = blobs.get(name)
    if type(raw) is not bytes or not 0 < len(raw) <= limit or sha(raw) != row['sha256']:
        raise ValueError('Candidate public proof bytes differ')
    return raw


def archive(raw, expected):
    if type(expected) is not dict or not 8 <= len(expected) <= 256:
        raise ValueError('Reviewed bounded selector inventory required')
    for name, value in expected.items():
        if (type(name) is not str or PurePosixPath(name).is_absolute() or
                '..' in PurePosixPath(name).parts or PurePosixPath(name).as_posix() != name or
                not digest(value)):
            raise ValueError('Selector source map differs')
    found = {}; total = 0
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as stream:
        for item in stream:
            total += item.size
            if (item.name not in expected or item.name in found or not item.isfile() or
                    not 0 < item.size <= 8 << 20 or total > 32 << 20):
                raise ValueError('Selector archive inventory differs')
            found[item.name] = sha(stream.extractfile(item).read())
    if found != expected:
        raise ValueError('Selector archive bytes differ')


def _initial(blobs, rows):
    # Imported only after the source-bound contract explicitly enables admission.
    # These independently reviewed modules are copied before final preparation.
    from initial_proof import ProofPins, authenticate_initial
    names = ('parent', 'worker', 'archive', 'root', 'manifest', 'script', 'outer')
    fields(rows, names)
    data = {name: bound_blob(blobs, rows[name]) for name in names}
    if sha(data['manifest']) != OBSERVER_MANIFEST:
        raise ValueError('Initial observer must be the reviewed exact61 producer')
    pins = ProofPins(parent_sha256=sha(data['parent']), worker_sha256=sha(data['worker']),
        archive_sha256=sha(data['archive']), root_sha256=sha(data['root']),
        source_manifest_bytes=data['manifest'], reconstruction_script_sha256=sha(data['script']),
        root_outer_sha256=sha(data['outer']))
    return authenticate_initial(data['parent'], data['worker'], data['archive'], data['root'],
                               pins=pins, root_outer_bytes=data['outer'])


def _protected(manifest):
    return dict(nonlinear={k: v for k, v in manifest['nonlinear'].items() if k not in NORMS},
                **{k: manifest[k] for k in ('softmax', 'exp', 'initial_reciprocal', 'reciprocal_by_keys')})


def _selector(blobs, rows, manifest_raw, initial):
    from selection_grant import authenticate_grant
    names = ('report', 'archive', 'source_manifest', 'outer', 'grant', 'assessments', 'protected_checks')
    fields(rows, names)
    data = {name: bound_blob(blobs, rows[name]) for name in names}
    report = parse(data['report']); expected = parse(data['source_manifest'])
    archive(data['archive'], expected)
    grant_value = parse(data['grant'])
    authorization = authenticate_grant(data['grant'], sha(data['grant']),
        source_manifest_sha256=sha(data['source_manifest']), output_directory=grant_value.get('output_directory'))
    grant_evidence = parse(authorization.evidence_bytes)
    expected_evidence = dict(parent=initial.parent_report_sha256, worker=initial.worker_report_sha256,
        source_archive=initial.source_archive_sha256, root_review=initial.root_review_sha256,
        reconstruction_script=initial.reconstruction_script_sha256,
        root_reconstruction_outer_receipt=initial.root_outer_sha256)
    if any(grant_evidence[k]['sha256'] != v for k, v in expected_evidence.items()):
        raise ValueError('Selector grant binds a different initial proof')
    if (report.get('schema') != 'qwen-expanded-initial-selection-report-v1' or
            any(report.get(k) is not True for k in TERMINAL + (
                'publication_complete', 'actual_coefficient_selection', 'candidate_supported',
                'all_norm_sites_supported', 'protected_rules_supported', 'private_inputs_never_removed')) or
            any(report.get(k) is not False for k in ('model_execution', 'token_or_calibration_body_reads',
                'validation_body_reads', 'encrypted_execution', 'synthetic_only')) or
            report.get('audit_denials') != [] or 'error_type' in report):
        raise ValueError('Completed successful pure selector proof required')
    require_int(report.get('candidate_ordinal'), 1)
    if (not same(report.get('source_hashes_start'), expected) or
            not same(report.get('source_hashes_end'), expected) or
            report.get('source_manifest_sha256') != sha(data['source_manifest']) or
            report.get('source_archive', {}).get('sha256') != sha(data['archive']) or
            report.get('grant_sha256') != sha(data['grant'])):
        raise ValueError('Selector source/grant chain differs')
    outer = parse(data['outer'])
    fixed = dict(schema='qwen-initial-selection-root-terminal-v1', exit_code=0, reaped=True,
        process_group_absent=True, report_sha256=sha(data['report']),
        source_archive_sha256=sha(data['archive']), source_manifest_sha256=sha(data['source_manifest']),
        candidate_manifest_sha256=sha(manifest_raw), grant_sha256=sha(data['grant']))
    if not same(outer, fixed):
        raise ValueError('Independent selector exit0/reap receipt required')
    linkage = dict(initial_parent_report_sha256=initial.parent_report_sha256,
        initial_worker_report_sha256=initial.worker_report_sha256,
        initial_root_review_sha256=initial.root_review_sha256,
        reconstruction_script_sha256=initial.reconstruction_script_sha256,
        root_reconstruction_outer_sha256=initial.root_outer_sha256,
        initial_snapshot_sha256=parse(initial.snapshot_descriptor_bytes)['sha256'],
        calibration_sha256=initial.calibration_sha256, model_pins_sha256=sha(initial.model_pins_bytes),
        protocol_sha256=initial.protocol_sha256)
    if any(report.get(k) != v for k, v in linkage.items()):
        raise ValueError('Selector does not consume this complete initial proof')
    outputs = report.get('outputs')
    fields(outputs, ('candidate_manifest.json', 'assessments.json', 'protected_checks.json'))
    for name, raw in (('candidate_manifest.json', manifest_raw),
                      ('assessments.json', data['assessments']), ('protected_checks.json', data['protected_checks'])):
        row = outputs[name]
        if type(row) is not dict or row.get('sha256') != sha(raw):
            raise ValueError('Completed selector publication digest differs')
        require_int(row.get('bytes'), len(raw))
    assessments = parse(data['assessments']); checks = parse(data['protected_checks'])
    if type(assessments) is not dict or set(assessments) != NORMS or set(checks) != set(map(str, range(28))):
        raise ValueError('All113 norm and28 protected assessments required')
    for row in checks.values():
        if any(row.get(k) is not True for k in ('radius_covered', 'observed_silu_covered', 'observed_centered_scores_covered')):
            raise ValueError('Protected SiLU/softmax assessment failed')
    return report, data


def require_candidate(blobs):
    """Return immutable candidate bytes after public-proof authentication only."""
    raw = blobs.get('candidate_binding.json')
    config = parse(raw)
    fields(config, ('schema', 'ready', 'candidate', 'initial_proof', 'selector_proof', 'budget'))
    if config['schema'] != 'qwen-candidate-checker-binding-v1' or config['ready'] is not True:
        raise PermissionError('Candidate publication is pending independent completed initial/selector proof')
    candidate_raw = bound_blob(blobs, config['candidate'], limit=16 << 20)
    candidate = parse(candidate_raw)
    initial = _initial(blobs, config['initial_proof'])
    if initial.protocol_sha256 != PROTOCOL or initial.baseline_manifest_sha256 != BASELINE:
        raise ValueError('Initial protocol/protected baseline differs')
    if (sha(blobs['protocol.json']) != PROTOCOL or sha(blobs['public/protocol.json']) != PROTOCOL or
            not same(parse(initial.model_pins_bytes), parse(blobs['public/model_pins.json'])) or
            parse(blobs['external_inputs.json'])['calibration']['sha256'] != initial.calibration_sha256):
        raise ValueError('Checker model/calibration differs from the completed initial proof')
    budget = config['budget']
    fields(budget, ('max_candidates', 'ordinal', 'previous_attempts', 'manifest_sha256'))
    require_int(budget['max_candidates'], 3); require_int(budget['ordinal'], 1)
    if budget['previous_attempts'] != [] or budget['manifest_sha256'] != sha(candidate_raw):
        raise ValueError('Initial candidate budget or frozen identity differs')
    require_int(candidate.get('candidate_index'), 1); require_int(candidate.get('candidate_ordinal'), 1)
    if (candidate.get('schema') != 'qwen-expanded-initial-selection-v1' or
            candidate.get('synthetic_only') is not False or candidate.get('actual_coefficient_selection') is not True or
            any(candidate.get(k) is not True for k in ('all_norm_sites_supported', 'protected_rules_supported',
                'all_silu_sites_supported', 'all_centered_softmax_sites_supported')) or
            candidate.get('parent_manifest_sha256') != BASELINE or candidate.get('protocol_sha256') != PROTOCOL):
        raise ValueError('Actual frozen supported initial-only candidate required')
    base_raw = blobs['public/candidate3_manifest.json']
    if sha(base_raw) != BASELINE:
        raise ValueError('Protected original candidate3 differs')
    base = parse(base_raw)
    if (set(k for k in candidate['nonlinear'] if k.endswith('.inverse_sqrt')) != NORMS or
            not same(_protected(candidate), _protected(base))):
        raise ValueError('Only the113 normalization rules may change')
    report, data = _selector(blobs, config['selector_proof'], candidate_raw, initial)
    if (candidate.get('initial_parent_report_sha256') != initial.parent_report_sha256 or
            candidate.get('initial_snapshot_sha256') != report['initial_snapshot_sha256'] or
            candidate.get('selection_grant_sha256') != sha(data['grant']) or
            candidate.get('selector_source_manifest_sha256') != sha(data['source_manifest'])):
        raise ValueError('Candidate publication linkage differs')
    return CandidateBinding(candidate_raw, sha(candidate_raw), 1, initial.parent_report_sha256,
        initial.calibration_sha256, PROTOCOL, sha(data['report']), initial.proof_sha256, sha(raw),
        sha(data['source_manifest']), sha(data['outer']))
