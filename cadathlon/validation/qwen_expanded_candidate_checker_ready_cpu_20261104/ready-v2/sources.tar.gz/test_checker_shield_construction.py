"""Construction is part of cleanup setup; all owned resources still retire."""
from contextlib import contextmanager
from pathlib import Path
import pytest
import checker_process as p
from cleanup_origin import cleanup_origin


@pytest.mark.parametrize('construction_type',[MemoryError,KeyboardInterrupt,SystemExit])
@pytest.mark.parametrize('body_type',[None,ValueError,KeyboardInterrupt])
def test_construction_failure_attempts_all_and_preserves_body(monkeypatch,construction_type,body_type):
    events=[];failure=construction_type('synthetic construction failure')
    body=None if body_type is None else body_type('genuine body')
    @contextmanager
    def ordinary(state):
        try:yield
        finally:state['restored']=True
    def signals(state=None,shield=False):
        if shield:raise failure
        return ordinary(state)
    class Output:
        path='/synthetic';owner=(0,1)
        def close(self):events.append('close')
        def json(self,*args):events.append('publish')
        @classmethod
        def reopen(cls,*args):return cls()
    monkeypatch.setattr(p,'signals',signals);monkeypatch.setattr(p,'Output',Output)
    monkeypatch.setattr(p,'source_end',lambda *args:events.append('source')or {})
    def action():
        if body is not None:raise body
    report=dict(passed=True,candidate_validation_admissible=True,failed_attempt_terminal_candidate=True)
    with pytest.raises(BaseException)as caught:
        p.supervise(Output(),report,action,[lambda:events.append('resource')],Path('/synthetic'),{})
    assert caught.value is (failure if body is None else body)
    assert events==['resource','source','close','publish','close']
    assert cleanup_origin(failure)
    assert report['passed'] is report['cleanup_completed'] is False
    assert report['candidate_validation_admissible'] is report['failed_attempt_terminal_candidate'] is False
    assert report['signal_restoration_completed'] is True


@pytest.mark.parametrize('cancel_type',[KeyboardInterrupt,SystemExit])
def test_later_cleanup_cancellation_outranks_construction_only_error(monkeypatch,cancel_type):
    events=[];failure=OSError('construction');cancel=cancel_type('later cleanup')
    @contextmanager
    def ordinary(state):
        try:yield
        finally:state['restored']=True
    def signals(state=None,shield=False):
        if shield:raise failure
        return ordinary(state)
    class Output:
        path='/synthetic';owner=(0,1)
        def close(self):events.append('close')
        def json(self,*args):events.append('publish')
        @classmethod
        def reopen(cls,*args):return cls()
    monkeypatch.setattr(p,'signals',signals);monkeypatch.setattr(p,'Output',Output)
    monkeypatch.setattr(p,'source_end',lambda *args:events.append('source')or {})
    def cleanup():events.append('resource');raise cancel
    report=dict(passed=True)
    with pytest.raises(BaseException)as caught:
        p.supervise(Output(),report,lambda:None,[cleanup],Path('/synthetic'),{})
    assert caught.value is cancel
    assert events==['resource','source','close','publish','close']
    assert cleanup_origin(failure) and cleanup_origin(cancel)
    assert report['passed'] is report['cleanup_completed'] is False
