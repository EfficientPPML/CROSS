"""Completed PUBLIC artifacts only; no descriptor path is followed."""
from pathlib import Path
from types import SimpleNamespace
import json
import pytest
import checker_admission as a
import checker_process as p
import proof_limits

HERE=Path(__file__).parent
CANDIDATE='344954b3873a8847ececba320646f52612ca7277412c7de81a7313894e21799a'


@pytest.fixture(scope='module')
def public_blobs():
    names=('candidate_binding.json','protocol.json','public/protocol.json',
           'public/model_pins.json','public/candidate3_manifest.json','external_inputs.json',
           'execution_authorization.json','checker_runtime_policy.json','checker_protected_paths.json',
           'public/tokenizer_report.json','public/tokenizer_worker_report.json',
           'public/tokenizer_sources.tar.gz','public/tokenizer_root_review.json','public/tokenizer_grant.json')
    result={name:(HERE/name).read_bytes() for name in names}
    result.update({x.relative_to(HERE).as_posix():x.read_bytes() for x in (HERE/'candidate_proof').iterdir()})
    return result


def test_authentic_public_proofs_bind_first_candidate(public_blobs):
    binding=a.require_candidate(public_blobs)
    assert binding.manifest_sha256==CANDIDATE and binding.ordinal==1
    assert binding.execution_authorized is False
    assert len(public_blobs[proof_limits.ASSESSMENT_PATH])==37_283_359
    assert a.parse(binding.manifest_bytes)['parent_manifest_sha256']==a.BASELINE


def test_ready_public_binding_still_requires_external_execution_grant(public_blobs,tmp_path,monkeypatch):
    args=SimpleNamespace(mode='collect-candidate',output=str(tmp_path/'output'),private_output=str(tmp_path/'private'),
                         manifest_sha256='a'*64,grant=None,grant_sha256=None)
    monkeypatch.setattr(p,'read',lambda *args,**kwargs:pytest.fail('unexpected grant or body read'))
    with pytest.raises(PermissionError,match='execution grant'):p.grant_check(args,public_blobs)
    assert not (tmp_path/'output').exists() and not (tmp_path/'private').exists()


@pytest.mark.parametrize('role',['initial','selector'])
def test_real_outer_receipt_requires_exact_success_even_after_local_repin(public_blobs,role):
    blobs=dict(public_blobs);config=a.parse(blobs['candidate_binding.json'])
    row=config[role+'_proof']['outer'];outer=a.parse(blobs[row['blob']]);outer['exit_code']=1
    blobs[row['blob']]=a.canonical(outer);row['sha256']=a.sha(blobs[row['blob']])
    blobs['candidate_binding.json']=a.canonical(config)
    with pytest.raises(ValueError):a.require_candidate(blobs)


def test_full_assessment_bytes_cannot_be_truncated(public_blobs):
    blobs=dict(public_blobs);blobs[proof_limits.ASSESSMENT_PATH]=blobs[proof_limits.ASSESSMENT_PATH][:-1]
    with pytest.raises(ValueError,match='proof bytes differ'):a.require_candidate(blobs)


def test_public_copies_match_exact_origin_inventory():
    origin=json.loads((HERE/'ready_proof_origin.json').read_text())
    rows=origin['public_files']
    assert len(rows)==17
    assert {x.relative_to(HERE).as_posix() for x in (HERE/'candidate_proof').iterdir()}==set(rows)
    for name,row in rows.items():
        raw=(HERE/name).read_bytes()
        assert a.sha(raw)==row['sha256'] and len(raw)==row['bytes']
    assert not any('snapshot' in name or 'ledger' in name for name in rows)


@pytest.mark.parametrize('path',[
    '/tmp/qwen-expanded-prefix-selector-actual-v1-20261104',
    '/tmp/qwen-expanded-prefix-selector-terminal-root-review-20261104',
    '/tmp/qwen-expanded-prefix-selector-terminal-outer-root-20261104',
    '/tmp/qwen-expanded-prefix-selector-root-launch-20261104'])
def test_original_selector_publication_is_protected(public_blobs,path,tmp_path):
    assert path in p.checker_paths(public_blobs)
    args=SimpleNamespace(output=path+'/new',private_output=str(tmp_path/'private'),manifest=None,grant=None)
    with pytest.raises(ValueError):p.validate_paths(args,public_blobs,tmp_path/'source')
