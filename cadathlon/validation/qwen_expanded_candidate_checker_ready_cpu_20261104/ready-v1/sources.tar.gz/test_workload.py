import copy
import json
from pathlib import Path
import pytest
import workload as w


def calibration():
    rows = []
    # Deliberately identical token families: entry denominators must not dedup.
    full = list(range(1000, 1032))
    for p in range(96):
        for length in range(1,33):
            rows.append(dict(prompt_ordinal=p,id=f'prompt{p}',sequence_length=length,
                token_ids=full[:length],original_prefill_member=length in (8,16,32)))
    return dict(prefills=rows,decode_seeds=[dict(seed_ordinal=s,prompt_ordinal=95-s,
        id=f'prompt{95-s}',token_ids=full[:16]) for s in range(16)])


def adapters(events, fail=None):
    def before(name,prefix,entry):
        events.append((name,prefix,entry))
        assert type(prefix) is tuple
        if fail and fail(name,entry): raise w.InvalidObservation('PRIVATE_TOKEN_8675309')
    def native(prefix,entry):
        before('native',prefix,entry);return w.Native(400+(entry.step or 0))
    def exact(prefix,entry,native):
        before('exact',prefix,entry);return w.Exact(native.token,True)
    def baseline(prefix,entry):
        before('baseline',prefix,entry);return w.Baseline(900+(entry.step or 0),True)
    return dict(native=native,exact=exact,baseline=baseline)


def test_full_order_and_distinct_teacher_free_choices():
    data=calibration();before=copy.deepcopy(data);events=[]
    result=w.run_initial(data,**adapters(events));result.require_initial_selection()
    assert data==before
    assert tuple(r.entry for r in result.records)==w.workload()
    assert len(result.records)==3200
    assert sum(r.entry.original416_member for r in result.records)==416
    assert len(events)==3200*2+64
    assert sum(e[0]=='baseline' for e in events)==64
    assert all(e.kind=='free' for name,_,e in events if name=='baseline')
    for seed in range(16):
        for step in range(4):
            teacher=result.records[3072+4*seed+step]
            free=result.records[3136+4*seed+step]
            base=tuple(data['decode_seeds'][seed]['token_ids'])
            assert teacher.prefix==base+tuple(range(400,400+step))
            assert free.prefix==base+tuple(range(900,900+step))
    public=result.public_report()
    assert public['complete'] and public['initial_selection_admissible']
    assert public['new_protocol_candidates_used']==0
    assert public['baseline_ranges_in_initial_selection'] is False
    assert public['prefills_by_length']=={str(i):96 for i in range(1,33)}
    assert public['by_kind']['prefill']['records']==3072


def test_workload_matches_frozen_public_protocol():
    protocol=json.loads((Path(__file__).parent/'public/protocol.json').read_bytes())
    actual=[]
    for e in w.workload():
        row=dict(kind=e.kind,length=e.length,original416_member=e.original416_member)
        if e.kind=='prefill':row['prompt_ordinal']=e.prompt_ordinal
        else:row.update(seed_ordinal=e.seed_ordinal,step=e.step)
        actual.append(row)
    assert actual==protocol['calibration']['workload']
    assert protocol['selection']['maximum_candidates']==3
    assert protocol['old_candidate_manifest_sha256']==w.BASELINE_MANIFEST_SHA256


@pytest.mark.parametrize('kind,stage,seed,step',[
    ('free','baseline',0,0),('free','baseline',7,2),('free','baseline',15,3),
    ('free','exact',8,1),('free','native',3,2),('teacher','native',2,0),
    ('teacher','exact',15,2)])
def test_invalid_decode_keeps_all_slots_and_blocks_selection(kind,stage,seed,step):
    events=[]
    fail=lambda name,e: name==stage and (e.kind,e.seed_ordinal,e.step)==(kind,seed,step)
    result=w.run_initial(calibration(),**adapters(events,fail))
    start=(3072 if kind=='teacher' else 3136)+seed*4
    assert len(result.records)==3200
    assert result.records[start+step].status=='invalid'
    assert result.records[start+step].failed_stage==stage
    assert [r.status for r in result.records[start+step+1:start+4]]==['unmeasured_suffix']*(3-step)
    assert all(r.prefix is None for r in result.records[start+step+1:start+4])
    assert not any(e.kind==kind and e.seed_ordinal==seed and e.step>step for _,_,e in events)
    # Other independent sequences are still attempted, including free after a teacher stop.
    assert sum(r.status=='invalid' for r in result.records)==1
    assert sum(r.status=='unmeasured_suffix' for r in result.records)==3-step
    with pytest.raises(ValueError,match='Complete ordered'):result.require_initial_selection()
    public=json.dumps(result.public_report(),sort_keys=True)
    assert 'PRIVATE_TOKEN_8675309' not in public
    assert 'token_ids' not in public and 'prefix' not in public and 'logits' not in public.replace('contains_tokens_or_logits','')


@pytest.mark.parametrize('stage',['native','exact'])
def test_invalid_prefill_does_not_skip_other_independent_entries(stage):
    events=[]
    fail=lambda name,e:name==stage and e.index==31
    result=w.run_initial(calibration(),**adapters(events,fail))
    assert result.records[31].status=='invalid'
    assert sum(r.status=='complete' for r in result.records)==3199
    assert sum(r.status=='unmeasured_suffix' for r in result.records)==0
    with pytest.raises(ValueError):result.require_initial_selection()


@pytest.mark.parametrize('change',[
    lambda x:x['prefills'].pop(),
    lambda x:x['decode_seeds'].pop(),
    lambda x:x.update(validation_inputs=[]),
    lambda x:x['prefills'][0].update(prompt_ordinal=False),
    lambda x:x['prefills'][0].update(sequence_length=True),
    lambda x:x['prefills'][7].update(original_prefill_member=1),
    lambda x:x['prefills'][0].update(token_ids=[True]),
    lambda x:x['prefills'][0].update(token_ids=[151936]),
    lambda x:x['prefills'][0].update(token_ids=[-1]),
    lambda x:x['prefills'][0].update(token_ids=(1000,)),
    lambda x:x['prefills'][0].update(token_ids=[999]),
    lambda x:x['prefills'][1].update(id='different'),
    lambda x:x['decode_seeds'][0].update(seed_ordinal=False),
    lambda x:x['decode_seeds'][0].update(prompt_ordinal=True),
    lambda x:x['decode_seeds'][0].update(id='different'),
    lambda x:x['decode_seeds'][0].update(token_ids=list(range(16))),
    lambda x:x['decode_seeds'][1].update(prompt_ordinal=95,id='prompt95'),
])
def test_input_rejection_before_any_adapter(change):
    data=calibration();change(data);events=[]
    with pytest.raises(ValueError):w.run_initial(data,**adapters(events))
    assert events==[]


@pytest.mark.parametrize('pin',[None,False,'0'*64])
def test_wrong_generator_pin_before_any_adapter(pin):
    events=[]
    with pytest.raises(ValueError):w.run_initial(calibration(),**adapters(events),baseline_manifest_sha256=pin)
    assert events==[]


@pytest.mark.parametrize('value',[w.Native(True),w.Native(-1),w.Native(151936),w.Exact(1,True),{'token':1}])
def test_bad_native_result_is_programming_failure(value):
    with pytest.raises(ValueError,match='adapter result'):
        w.run_initial(calibration(),native=lambda *args:value,exact=None,baseline=None)


@pytest.mark.parametrize('exact_result',[w.Exact(400,False),w.Exact(401,True)])
def test_semantic_or_argmax_failure_never_generates_free_token(exact_result):
    calls=[];api=adapters(calls)
    real=api['exact']
    api['exact']=lambda p,e,n:exact_result if e.kind=='free' and e.seed_ordinal==0 else real(p,e,n)
    result=w.run_initial(calibration(),**api)
    assert result.records[3136].status=='invalid'
    assert all(r.status=='unmeasured_suffix' for r in result.records[3137:3140])
    assert not any(name=='baseline' and e.seed_ordinal==0 for name,_,e in calls)
    assert not result.public_report()['initial_selection_admissible']
    assert result.public_report()['by_kind']['free']['semantic_failures']==1


def test_false_baseline_domain_does_not_append_returned_token():
    events=[];api=adapters(events)
    api['baseline']=lambda *args:w.Baseline(12345,False)
    result=w.run_initial(calibration(),**api)
    assert result.public_report()['by_kind']['free']['invalid']==16
    assert result.public_report()['by_kind']['free']['unmeasured']==48
    assert all(r.prefix is None for r in result.records if r.status=='unmeasured_suffix')


@pytest.mark.parametrize('error',[KeyboardInterrupt,SystemExit,RuntimeError,MemoryError])
def test_cancellation_or_infrastructure_error_is_not_a_success_ledger(error):
    def native(*args):raise error('synthetic')
    with pytest.raises(error):w.run_initial(calibration(),native=native,exact=None,baseline=None)


@pytest.mark.parametrize('which',['exact','baseline'])
def test_bool_alias_gate_rejected(which):
    events=[];api=adapters(events)
    if which=='exact':api[which]=lambda p,e,n:w.Exact(n.token,1)
    else:api[which]=lambda p,e:w.Baseline(700,1)
    with pytest.raises(ValueError,match='Exact boolean'):w.run_initial(calibration(),**api)
