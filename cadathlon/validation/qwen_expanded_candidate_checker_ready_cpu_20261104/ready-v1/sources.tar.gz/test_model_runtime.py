"""Synthetic numerical and journal contracts; never pretrained bodies/backends."""
import copy
from types import SimpleNamespace
import numpy as np
import pytest
import model_runtime as runtime
import workload


def logits(token=3):
    value = np.zeros((1, runtime.VOCABULARY), dtype=np.float64)
    value[0, token] = 1.
    return value


def test_all_logits_and_exact_top1():
    expected = logits()
    assert runtime.semantic_metric(expected, expected)['passed']
    changed = expected.copy(); changed[0, -1] = .002
    result = runtime.semantic_metric(changed, expected)
    assert result['all_final_logits_checked'] == runtime.VOCABULARY
    assert not result['passed'] and result['max_abs'] == .002
    tied = np.zeros_like(expected)
    changed = tied.copy(); changed[0, -1] = 1e-10
    result = runtime.semantic_metric(changed, tied)
    assert result['nrmse'] < 1e-5 and not result['top1_agreement'] and not result['passed']


@pytest.mark.parametrize('actual', [np.zeros((runtime.VOCABULARY,)),
    np.zeros((1, runtime.VOCABULARY-1)), np.full((1,runtime.VOCABULARY),np.nan),
    np.full((1,runtime.VOCABULARY),np.inf)])
def test_semantic_rejects_incomplete_or_nonfinite(actual):
    assert not runtime.semantic_metric(actual, logits())['passed']


def test_semantic_rms_avoids_square_overflow():
    expected = np.full((1, runtime.VOCABULARY), 1e200)
    result = runtime.semantic_metric(expected, expected)
    assert result['passed'] and result['nrmse'] == 0.


def test_finite_extreme_metric_failure_is_json_safe():
    import json
    expected = np.zeros((1, runtime.VOCABULARY))
    actual = np.full_like(expected, 1e308)
    result = runtime.semantic_metric(actual, expected)
    assert result['passed'] is False and result['finite'] is False
    assert result['nrmse'] is None and result['max_abs']==1e308
    json.dumps(result, allow_nan=False)


def test_merge_ranges_keeps_counts_extremes_and_domain():
    one = {'a':dict(count=2,minimum=2.,maximum=3.,nonfinite=0,nonpositive=0)}
    two = {'a':dict(count=3,minimum=1.,maximum=4.,nonfinite=1,nonpositive=1)}
    old = copy.deepcopy(two)
    runtime.merge_statistics(one,two)
    assert one['a'] == dict(count=5,minimum=1.,maximum=4.,nonfinite=1,nonpositive=1)
    assert two == old
    with pytest.raises(ValueError):
        runtime.merge_statistics(one,{'a':dict(count=1)})
    a={'x':dict(count=1,minimum=1.,maximum=1.,domain=[0.,2.],below=0,above=0,nonfinite=0)}
    b=copy.deepcopy(a);b['x']['domain']=[0.,3.]
    with pytest.raises(ValueError):runtime.merge_statistics(a,b)


def tiny_weights(sequence=3):
    random=np.random.default_rng(731)
    c=dict(num_hidden_layers=28,hidden_size=4,intermediate_size=6,
           num_attention_heads=2,num_key_value_heads=1,head_dim=2,
           rms_norm_eps=1e-6,rope_theta=10000.,vocab_size=8)
    w={'model.embed_tokens.weight':random.normal(0,.01,(8,4)),
       'model.norm.weight':np.ones(4)}
    for i in range(28):
        p=f'model.layers.{i}.';a=p+'self_attn.';m=p+'mlp.'
        for name in ('input_layernorm','post_attention_layernorm'):w[p+name+'.weight']=np.ones(4)
        for name in ('q_norm','k_norm'):w[a+name+'.weight']=np.ones(2)
        for name,shape in [('q_proj',(4,4)),('k_proj',(2,4)),('v_proj',(2,4)),('o_proj',(4,4))]:
            w[a+name+'.weight']=random.normal(0,.01,shape)
        for name,shape in [('gate_proj',(6,4)),('up_proj',(6,4)),('down_proj',(4,6))]:
            w[m+name+'.weight']=random.normal(0,.01,shape)
    return c,w,random.normal(0,.01,(1,sequence,4))


@pytest.mark.parametrize('sequence',[1,2,16,32])
def test_unchanged_exact_arithmetic_and_input_sites(sequence):
    import observed_reference,reference
    from ranges import RangeBook
    c,w,x=tiny_weights(sequence)
    book=RangeBook();book.begin(sequence)
    actual=observed_reference.forward(c,w,x,observe=book.observe)
    expected=reference.forward(c,w,x)
    report=book.end()
    assert np.array_equal(actual,expected)
    assert report['norm_input_sites']==113 and report['silu_gate_sites']==28
    assert report['ranges']['final.inverse_sqrt']['count']==1
    aggregate=runtime.Aggregate();aggregate.add(report);aggregate.add(report)
    combined=aggregate.report()
    assert combined['contexts']==2
    assert combined['ranges']['final.inverse_sqrt']['count']==2
    for rows in combined['score_rows'].values():
        assert set(rows)==set(map(str,range(1,sequence+1)))
        assert rows['1']['k1_bypass'] and rows['1']['reciprocal_observations']==0
        assert rows['1']['contexts']==2 and rows['1']['centered']['maximum']==0.


class Private:
    def __init__(self):self.rows={}
    def json(self,name,value):
        assert name not in self.rows
        self.rows[name]=copy.deepcopy(value)
        return {'sha256':'a'*64,'bytes':1,'identity':[1,1],'mode':'0600'}


class InvalidInput(ValueError):pass


class Capture:
    def __init__(self, report):
        self.report=report;self.active=False
        self.book=SimpleNamespace(snapshot=lambda:dict(complete=False,invalid=True))
    def begin(self,sequence):assert not self.active;self.active=True
    def end(self):self.active=False;return copy.deepcopy(self.report)
    def abort(self):assert self.active;self.active=False;return self.book.snapshot()
    def observe(self,label,array):pass


def report():
    import observed_reference
    from ranges import RangeBook
    c,w,x=tiny_weights(1);book=RangeBook();book.begin(1)
    observed_reference.forward(c,w,x,observe=book.observe)
    return book.end()


def adapters():
    cap=Capture(report());private=Private();same=logits()
    value=runtime.Adapters(native_forward=lambda prefix:same.copy(),capture=cap,
        config={},weights={'model.embed_tokens.weight':np.ones((8,4))},manifest={},
        private=private,progress=lambda row:None,
        exact_module=SimpleNamespace(forward=lambda *a,**kw:same.copy()),
        plain_module=SimpleNamespace(forward=lambda *a,**kw:same.copy()),
        arithmetic_module=None,range_factory=lambda:cap,invalid_range=InvalidInput)
    return value,private,cap


def test_actual_same_prefix_is_required_for_semantic_comparison():
    value,private,cap=adapters();entry=workload.workload()[0]
    native=value.native((1,),entry)
    with pytest.raises(ValueError,match='matching actual native prefix'):
        value.exact((2,),entry,native)
    # No altered-prefix exact result or fallback was journaled.
    assert set(private.rows)=={'0000-started.json','0000-native.json'}


def test_exact_semantics_use_matching_native_and_release_logits():
    value,private,cap=adapters();entry=workload.workload()[0]
    native=value.native((1,),entry)
    exact=value.exact((1,),entry,native)
    assert native.token==exact.token==3 and exact.semantic_pass
    assert value.native_logits is None and value.native_binding is None
    assert value.semantic_passes==1
    assert value.native_ranges.contexts==value.exact_ranges.contexts==1
    metric=private.rows['0000-exact.json']['semantic']
    assert metric['all_final_logits_checked']==runtime.VOCABULARY and metric['passed']
    import hashlib
    from freeze_io import json_bytes
    for name in ('0000-native.json','0000-exact.json'):
        row=private.rows[name]
        assert row['observations']['norm_input_sites']==113
        assert row['ranges_sha256']==hashlib.sha256(json_bytes(row['observations'])).hexdigest()


def test_baseline_chooses_its_own_argmax_without_native_substitution():
    value,private,cap=adapters();entry=workload.workload()[3136]
    engine=SimpleNamespace(domains={},domain_failures=lambda:{})
    class InvalidCircuit(ValueError):pass
    def run(*args,**kwargs):
        return SimpleNamespace(data=logits(7)),engine,[None]*28,dict.fromkeys(range(421))
    value.arithmetic=SimpleNamespace(QwenArithmetic=lambda manifest:engine,
        approximate_forward=run,InvalidCircuit=InvalidCircuit)
    baseline=value.baseline((1,)*16,entry)
    assert baseline.token==7 and baseline.domain_pass and value.baseline_complete==1
    assert private.rows['3136-baseline.json']['token']==7


def test_known_native_invalid_retains_partial_and_deactivates():
    value,private,cap=adapters();entry=workload.workload()[0]
    def forward(prefix):
        if cap.active:raise InvalidInput('nonpositive norm input')
        return logits()
    value.forward=forward
    with pytest.raises(workload.InvalidObservation):value.native((1,),entry)
    assert not cap.active
    invalid=private.rows['0000-native-invalid.json']
    assert invalid['partial_observations']==dict(complete=False,invalid=True)
    cap.begin(1);assert cap.active


def test_no_new_input_range_can_use_baseline_diagnostics():
    value,private,cap=adapters()
    class InvalidCircuit(ValueError):
        def __init__(self):self.label='final.inverse_sqrt';self.record={'above':1}
    engine=SimpleNamespace(domains={'baseline_only':dict(count=1,minimum=9.,maximum=9.,
        below=0,above=1,nonfinite=0,domain=[1.,8.])})
    def run(*args,**kwargs):raise InvalidCircuit()
    value.arithmetic=SimpleNamespace(QwenArithmetic=lambda manifest:engine,
        approximate_forward=run,InvalidCircuit=InvalidCircuit)
    entry=workload.workload()[3136]
    with pytest.raises(workload.InvalidObservation):value.baseline((1,)*16,entry)
    assert 'baseline_only' in value.baseline_ranges
    assert value.native_ranges.ranges=={} and value.exact_ranges.ranges=={}
    assert private.rows['3136-baseline.json']['status']=='invalid'


def test_native_instrumentation_change_is_fatal():
    value,private,cap=adapters()
    value.forward=lambda prefix:logits(4 if cap.active else 3)
    with pytest.raises(ValueError,match='observation changed'):
        value.native((1,),workload.workload()[0])
    assert value.native_ranges.contexts==0


def test_preflight_imports_no_model_backend():
    import sys
    assert not any(n.split('.')[0] in ('torch','transformers','jax','jaxlib') for n in sys.modules)


def test_backend_configuration_rejected_before_any_body_reader(monkeypatch):
    import backend_environment
    for name,value in backend_environment.REQUIRED.items():monkeypatch.setenv(name,value)
    monkeypatch.setenv('USE_TF','1')
    calls=[]
    def forbidden_reader(*args,**kwargs):calls.append('body');raise AssertionError('body read')
    with pytest.raises(ValueError):
        runtime.execute({},forbidden_reader,None,lambda row:calls.append(row))
    assert calls==[]
