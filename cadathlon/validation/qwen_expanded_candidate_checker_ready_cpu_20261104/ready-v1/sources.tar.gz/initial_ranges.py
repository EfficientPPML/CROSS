"""Producer telemetry validation; positive input is distinct from selector floor.

Copied predecessor range/count/per-K validator; only positivity requires lo>0,
not lo>=binary64 epsilon. Selection policy itself remains unchanged.
"""
import math
from admission import exact_int,expected_counts,lengths
from selector import NORMS,canonical

def stat(row,count,positive=False):
    if type(row)is not dict or set(row)!={'count','minimum','maximum','nonfinite','nonpositive'}:raise ValueError('exact range statistic schema required')
    if not exact_int(row['count'],count)or not exact_int(row['nonfinite'],0)or type(row['nonpositive'])is not int or not 0<=row['nonpositive']<=count:raise ValueError('range count/finite coverage differs')
    lo,hi=row['minimum'],row['maximum']
    if any(type(x)is not float or not math.isfinite(x)for x in(lo,hi))or lo>hi:raise ValueError('finite typed range required')
    if positive and(not 0<lo or row['nonpositive']!=0):raise ValueError('positive norm input required')
    return dict(row)

def range_union(ranges):
    if type(ranges)is not dict or set(ranges)!={'native','exact','native_exact_union','baseline_generator_separate_diagnostic','initial_bounds_include_baseline'}:raise ValueError('initial range families differ')
    if ranges['initial_bounds_include_baseline']is not False:raise ValueError('baseline cannot enter initial bounds')
    counts=expected_counts();families=[]
    for kind in('native','exact'):
        family=ranges[kind]
        if type(family)is not dict or not exact_int(family.get('contexts'),3200)or family.get('reciprocal_inputs_observed')is not False:raise ValueError('complete native/exact range family required')
        rows=family['ranges']
        if type(rows)is not dict or set(rows)!=set(counts):raise ValueError('all native/exact nonlinear input labels required')
        cleaned={name:stat(rows[name],count,name in NORMS)for name,count in counts.items()}
        score_rows=family['score_rows']
        if type(score_rows)is not dict or set(score_rows)!=set(map(str,range(28))):raise ValueError('all28 causal score layers required')
        for layer_name,layer in score_rows.items():
            if type(layer)is not dict or set(layer)!=set(map(str,range(1,33))):raise ValueError('every actual causal K required')
            for key,row in layer.items():
                k=int(key);contexts=sum(s>=k for s in lengths())
                if not exact_int(row.get('query'),k-1)or not exact_int(row.get('key_count'),k)or not exact_int(row.get('contexts'),contexts)or row.get('shape')!=[1,16,k]or any(type(x)is not int for x in row['shape']):raise ValueError('per-query/K score coverage differs')
                if row.get('k1_bypass')is not(k==1)or not exact_int(row.get('reciprocal_observations'),0):raise ValueError('K1 bypass/no invented reciprocal required')
                stat(row['raw_valid'],16*k*contexts);centered=stat(row['centered'],16*k*contexts)
                if k==1 and(centered['minimum']!=0. or centered['maximum']!=0.):raise ValueError('K1 centered bypass must be zero')
            for phase in('raw_valid','centered'):
                values=[row[phase]for row in layer.values()]
                aggregate=dict(count=sum(v['count']for v in values),minimum=min(v['minimum']for v in values),maximum=max(v['maximum']for v in values),nonfinite=sum(v['nonfinite']for v in values),nonpositive=sum(v['nonpositive']for v in values))
                if aggregate!=cleaned[f'{layer_name}.softmax.{phase}']:raise ValueError('flat causal range differs from per-K rows')
        families.append(cleaned)
    union={}
    for name in counts:
        a,b=(f[name]for f in families)
        union[name]=dict(count=a['count']+b['count'],minimum=min(a['minimum'],b['minimum']),maximum=max(a['maximum'],b['maximum']),nonfinite=0,nonpositive=a['nonpositive']+b['nonpositive'])
    if canonical(union)!=canonical(ranges['native_exact_union']):raise ValueError('native/exact union differs; baseline must remain excluded')
    return union
