import copy
import numpy as np
import pytest
import arithmetic
from candidate_domains import ObservedArithmetic,plan
from strict_metrics import StructuralFailure,operator_shapes

def manifest():
    norms={f'{i}.{part}.inverse_sqrt':dict(method='newton',domain=[.1,10.],iterations=2,rounded_first_weight=-.01,rounded_first_bias=1.)for i in range(28)for part in('input','post','q','k')}
    norms['final.inverse_sqrt']=copy.deepcopy(norms['0.input.inverse_sqrt'])
    for i in range(28):
        norms[f'{i}.silu']=dict(method='polynomial',domain=[-2.,2.],strategy='power',evaluation_coefficients=[0.,1.],chebyshev_coefficients=[0.,1.])if i<6 else dict(method='rational_tanh',domain=[-2.,2.],doublings=6 if i<27 else 11,base=dict(domain=[-.5,.5]),reciprocal=dict(domain=[1.,2.1],iterations=5))
    return dict(nonlinear=norms,softmax={str(i):dict(centered_domain=[-4.,4.],squarings=5 if i<14 else 6)for i in range(28)},exp=dict(domain=[-.5,.5]),initial_reciprocal=dict(domain=[.5,2.],iterations=6),reciprocal_by_keys={str(k):dict(domain=[.5/k,2.],iterations=8)for k in range(1,33)})

@pytest.mark.parametrize('sequence',range(1,33))
def test_exact_full_domain_labels_and_k1_bypass(sequence):
    rows=plan(manifest(),sequence);names=[r.label for r in rows]
    assert len(rows)==113+28+22+(21*6+11)+(sequence-1)*(14*8+14*9)
    assert len(set(names))==len(rows)and not any('.query0.'in n for n in names)
    assert names[:3]==['0.input.inverse_sqrt','0.q.inverse_sqrt','0.k.inverse_sqrt']and names[-1]=='final.inverse_sqrt'
    assert sum(n.endswith('.inverse_sqrt')for n in names)==113
    if sequence>1:
        row=next(r for r in rows if r.label=='0.attention.query1.initial_inverse');assert row.shape==(1,16,1)
        assert next(r.domain for r in rows if r.label=='0.attention.query1.round0.inverse')==(.25,2.)

def test_original_observe_arithmetic_is_called_and_rejected_before_affine():
    engine=ObservedArithmetic(manifest(),1);calls=[]
    engine.affine=lambda *a,**k:calls.append('affine')
    with pytest.raises(arithmetic.InvalidCircuit):
        engine.inverse_sqrt(arithmetic.Value(np.full((1,1,1),11.)),engine.manifest['nonlinear']['0.input.inverse_sqrt'],'0.input.inverse_sqrt')
    assert calls==[]and engine.domains['0.input.inverse_sqrt']['above']==1 and engine.domains['0.input.inverse_sqrt']['maximum']==11.

@pytest.mark.parametrize('problem',['label','shape','domain','dtype','mutation','duplicate'])
def test_observation_contract_mismatch_is_infrastructure(problem):
    engine=ObservedArithmetic(manifest(),1);row=engine.expected_events[0];label=row.label;shape=row.shape;domain=list(row.domain);data=np.ones(shape)
    if problem=='label':label='wrong'
    if problem=='shape':data=np.ones((1,2,1))
    if problem=='domain':domain=[True,10.]
    if problem=='dtype':data=data.astype(complex)
    if problem=='mutation':engine.manifest['nonlinear'][label]['iterations']=3
    if problem=='duplicate':engine.observe(label,data,domain)
    with pytest.raises(StructuralFailure):engine.observe(label,data,domain)

@pytest.mark.parametrize('sequence',[1,3,32])
def test_all_events_and_outputs_complete_without_aliasing_input_namespaces(sequence):
    engine=ObservedArithmetic(manifest(),sequence)
    for row in engine.expected_events:
        value=sum(row.domain)/2;engine.observe(row.label,np.broadcast_to(np.float64(value),row.shape),list(row.domain))
    for name,shape in operator_shapes(sequence).items():engine.operators[name]=np.broadcast_to(np.float64(100.),shape)
    for _ in range(28):engine.blocks.append(np.broadcast_to(np.float64(100.),(1,sequence,1024)))
    engine.require_complete();r=engine.report();assert len(r['normalization_variance'])==113 and r['normalization_variance']['0.input.inverse_sqrt']['maximum']==5.05
    assert engine.operators['0.input.inverse_sqrt'].max()==100.
    with pytest.raises(StructuralFailure):engine.observe('extra',np.ones((1,1)),[0.,2.])

def test_missing_events_outputs_and_duplicate_operator_rejected():
    engine=ObservedArithmetic(manifest(),1)
    with pytest.raises(StructuralFailure):engine.require_complete()
    engine.operators['0.input.inverse_sqrt']=np.ones((1,1,1024))
    with pytest.raises(StructuralFailure):engine.operators['0.input.inverse_sqrt']=np.ones((1,1,1024))
    with pytest.raises(StructuralFailure):engine.operators['0.k_linear']=np.ones((1,1,1024))
