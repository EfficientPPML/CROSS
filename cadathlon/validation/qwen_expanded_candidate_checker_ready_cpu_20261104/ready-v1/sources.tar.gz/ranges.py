"""Input-range telemetry for one unpadded Qwen28 prefix; no model/data IO.

The unchanged observed_reference.forward callback can be passed observe directly.
Weighted norm outputs are intentionally ignored rather than mislabeled as input
variances. Per-query score rows remain separated by their actual last-axis K.
"""
from copy import deepcopy
import numpy as np

LAYERS = 28
NORM_LABELS = frozenset(
    f"{i}.{part}.inverse_sqrt" for i in range(LAYERS)
    for part in ("input", "post", "q", "k")
) | {"final.inverse_sqrt"}
SILU_LABELS = frozenset(f"{i}.silu" for i in range(LAYERS))
IGNORED_OUTPUT_LABELS = frozenset(x + ".exact_output" for x in NORM_LABELS) | frozenset(
    f"{i}.{part}_rope.exact_output" for i in range(LAYERS) for part in ("q", "k")
)


class ObservationError(ValueError):
    """Structural observation contract failure; terminate collection."""


class InvalidInput(ObservationError):
    """Known nonfinite/nonpositive nonlinear input; dispatcher may mark invalid."""


def statistics(values):
    x = np.asarray(values)
    if x.dtype.kind != "f" or not x.size:
        raise ObservationError("Nonempty real floating observation required")
    with np.errstate(over="ignore", invalid="ignore", under="ignore"):
        x = x.astype(np.float64, copy=False)
    finite = np.isfinite(x)
    valid = x[finite]
    return dict(count=int(x.size), minimum=float(valid.min()) if valid.size else None,
                maximum=float(valid.max()) if valid.size else None,
                nonfinite=int(x.size - valid.size),
                nonpositive=int(np.sum(valid <= 0)))


def merge_statistics(left, right):
    """Merge JSON-safe sufficient statistics without modifying either source."""
    if left is None:
        return dict(right)
    low = [x for x in (left["minimum"], right["minimum"]) if x is not None]
    high = [x for x in (left["maximum"], right["maximum"]) if x is not None]
    return dict(count=left["count"] + right["count"],
                minimum=min(low) if low else None, maximum=max(high) if high else None,
                nonfinite=left["nonfinite"] + right["nonfinite"],
                nonpositive=left["nonpositive"] + right["nonpositive"])


class RangeBook:
    def __init__(self):
        self.active = False
        self.sequence_length = None
        self.ranges = {}
        self.score_rows = {}
        self.ignored_output_callbacks = 0
        self.invalid = False
        self.invalid_input_error = None
        self.complete = False

    def begin(self, sequence_length):
        if self.active:
            raise ObservationError("Observation context already active")
        if type(sequence_length) is not int or not 1 <= sequence_length <= 32:
            raise ObservationError("Exact prefix length1..32 required")
        self.sequence_length = sequence_length
        self.ranges = {}
        self.score_rows = {}
        self.ignored_output_callbacks = 0
        self.invalid = False
        self.invalid_input_error = None
        self.complete = False
        self.active = True
        return self

    def observe(self, label, values):
        if not self.active or type(label) is not str:
            raise ObservationError("Active observation and exact label required")
        try:
            self._observe(label, values)
        except InvalidInput as error:
            self.invalid = True
            if self.invalid_input_error is None:
                self.invalid_input_error = error
            raise
        except BaseException:
            self.invalid = True
            raise

    __call__ = observe

    def _observe(self, label, values):
        if label in IGNORED_OUTPUT_LABELS:
            self.ignored_output_callbacks += 1
            return
        array = np.asarray(values)
        if label in NORM_LABELS or label in SILU_LABELS:
            if label in self.ranges:
                raise ObservationError("Duplicate input site in one prefix")
            if array.ndim < 2 or array.shape[0] != 1:
                raise ObservationError("Single-batch input observation required")
            if label in NORM_LABELS and array.shape[-1] != 1:
                raise ObservationError("Norm input variance requires singleton last axis")
            if label == "final.inverse_sqrt" and array.size != 1:
                raise ObservationError("Final norm observes last token only")
            row = statistics(array)
            self.ranges[label] = row
            if row["nonfinite"] or label in NORM_LABELS and row["nonpositive"]:
                raise InvalidInput("Nonfinite or nonpositive norm input")
            return
        parts = label.split(".")
        if (len(parts) != 3 or parts[1] != "softmax" or parts[2] not in ("raw_valid", "centered")
                or parts[0] not in {str(i) for i in range(LAYERS)}):
            raise ObservationError("Unknown input observation label")
        if array.ndim != 3 or array.shape[0] != 1 or array.shape[1] < 1:
            raise ObservationError("Score row must be batch1 by heads by valid keys")
        key_count = array.shape[-1]
        if not 1 <= key_count <= self.sequence_length:
            raise ObservationError("Valid-key count outside current prefix")
        layer_rows = self.score_rows.setdefault(parts[0], {})
        key = str(key_count)
        phase = parts[2]
        if phase == "raw_valid":
            if key in layer_rows or key_count != len(layer_rows) + 1:
                raise ObservationError("Raw score queries must be unique and ordered")
            layer_rows[key] = dict(query=key_count - 1, key_count=key_count,
                                   shape=list(array.shape), k1_bypass=key_count == 1,
                                   reciprocal_observations=0)
        if key not in layer_rows or phase in layer_rows[key]:
            raise ObservationError("Centered row requires a unique preceding raw row")
        record = layer_rows[key]
        if list(array.shape) != record["shape"]:
            raise ObservationError("Raw/centered score row shapes differ")
        row = statistics(array)
        record[phase] = row
        self.ranges[label] = merge_statistics(self.ranges.get(label), row)
        if row["nonfinite"]:
            raise InvalidInput("Nonfinite valid score row")
        if phase == "centered" and key_count == 1 and np.any(array != 0):
            raise ObservationError("K1 centered score must be zero; no reciprocal is observed")

    def snapshot(self):
        return deepcopy(dict(sequence_length=self.sequence_length, ranges=self.ranges,
                             score_rows=self.score_rows,
                             ignored_exact_output_callbacks=self.ignored_output_callbacks,
                             complete=self.complete,
                             invalid=self.invalid, norm_input_sites=sum(x in self.ranges for x in NORM_LABELS),
                             silu_gate_sites=sum(x in self.ranges for x in SILU_LABELS),
                             scope="Input telemetry only; no inverse/softmax/model evaluation or output-substitution claim."))

    def end(self):
        if not self.active:
            raise ObservationError("No active observation context")
        self.active = False
        if self.invalid_input_error is not None:
            raise self.invalid_input_error
        required = NORM_LABELS | SILU_LABELS | {
            f"{i}.softmax.{phase}" for i in range(LAYERS) for phase in ("raw_valid", "centered")}
        complete = set(self.ranges) == required and set(self.score_rows) == {str(i) for i in range(LAYERS)}
        for rows in self.score_rows.values():
            complete &= set(rows) == {str(k) for k in range(1, self.sequence_length + 1)}
            complete &= all("raw_valid" in row and "centered" in row for row in rows.values())
        if self.invalid or not complete:
            raise ObservationError("Invalid or incomplete113-norm/28-SiLU/per-query score capture")
        self.complete = True
        return self.snapshot()
