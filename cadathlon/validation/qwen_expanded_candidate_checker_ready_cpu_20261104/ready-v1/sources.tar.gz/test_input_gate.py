from pathlib import Path
import copy,hashlib,json,os
import pytest
import input_gate as gate
from freeze_io import json_bytes


def blobs():
    root=Path(__file__).parent
    names=['external_inputs.json','public/protocol.json','public/model_pins.json','public/candidate3_manifest.json',
        'public/tokenizer_report.json','public/tokenizer_worker_report.json','public/tokenizer_root_review.json',
        'public/tokenizer_grant.json','public/tokenizer_sources.tar.gz']
    return {n:(root/n).read_bytes() for n in names}


def test_public_producer_inspection_reads_no_external_body(monkeypatch):
    data=blobs()
    monkeypatch.setattr(gate,'read',lambda *a,**k:pytest.fail('external read during metadata admission'))
    result=gate.inspect(data)
    assert result['calibration']['bytes']==1221283
    assert result['baseline_manifest_sha256']==gate.BASELINE
    assert result['model_assets']==list(gate.ASSETS)


@pytest.mark.parametrize('name',['public/tokenizer_report.json','public/tokenizer_worker_report.json',
    'public/tokenizer_root_review.json','public/tokenizer_grant.json','public/tokenizer_sources.tar.gz',
    'public/protocol.json','public/candidate3_manifest.json'])
def test_producer_digest_failure_before_body(name,monkeypatch):
    data=blobs();data[name]+=b' '
    monkeypatch.setattr(gate,'read',lambda *a,**k:pytest.fail('body before producer admission'))
    with pytest.raises(ValueError):gate.inspect(data)


@pytest.mark.parametrize('field,value',[('bytes',True),('bytes',0),('identity',[True,3379211]),
    ('parent_identity',[66305]),('mode','0644'),('parent_mode','0755'),
    ('path','/tmp/private/validation_inputs.json'),('sha256','bad')])
def test_typed_calibration_descriptor(field,value):
    data=blobs();external=json.loads(data['external_inputs.json']);external['calibration'][field]=value
    data['external_inputs.json']=json_bytes(external)
    with pytest.raises(ValueError):gate.inspect(data)


def private_fixture(tmp_path,monkeypatch):
    root=tmp_path/'private';root.mkdir(mode=0o700);root.chmod(0o700)
    path=root/'calibration_inputs.json';path.write_bytes(b'{"synthetic":true}');path.chmod(0o600)
    stat=path.stat();parent=root.stat();d=dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        bytes=stat.st_size,identity=[stat.st_dev,stat.st_ino],parent_identity=[parent.st_dev,parent.st_ino],mode='0600',parent_mode='0700')
    monkeypatch.setattr(gate,'inspect',lambda b:{'calibration':d})
    return path,d


def test_reader_only_fixed_calibration_and_rechecks(tmp_path,monkeypatch):
    path,d=private_fixture(tmp_path,monkeypatch);reader=gate.Reader({})
    assert reader(path,d['sha256'],limit=d['bytes'])==path.read_bytes();reader.recheck()
    with pytest.raises(PermissionError):reader(path.parent/'validation_inputs.json',d['sha256'])
    with pytest.raises(PermissionError):reader(path,'0'*64)
    path.write_bytes(b'changed');path.chmod(0o600)
    with pytest.raises(ValueError):reader.recheck()


@pytest.mark.parametrize('change',['mode','symlink','parent','file'])
def test_calibration_ownership_change_rejected(tmp_path,monkeypatch,change):
    path,d=private_fixture(tmp_path,monkeypatch);reader=gate.Reader({})
    if change=='mode':path.chmod(0o644)
    elif change=='symlink':
        moved=path.with_name('moved');path.rename(moved);path.symlink_to(moved)
    elif change=='parent':
        moved=path.parent.with_name('moved');path.parent.rename(moved);path.parent.mkdir(mode=0o700);path.write_bytes(b'{}');path.chmod(0o600)
    else:path.unlink();path.write_bytes(b'{}');path.chmod(0o600)
    with pytest.raises(ValueError):reader(path,d['sha256'],limit=d['bytes'])


def model_fixture(tmp_path,monkeypatch):
    # Synthetic bytes use JSON names; the process audit still unconditionally
    # denies safetensors/NumPy bodies during preflight.
    monkeypatch.setattr(gate,'ASSETS',('config.json','generation_config.json','synthetic-weights.json'))
    root=tmp_path/'model';root.mkdir()
    pins={}
    for n in gate.ASSETS:
        (root/n).write_bytes(('synthetic '+n).encode());pins[n]=hashlib.sha256((root/n).read_bytes()).hexdigest()
    monkeypatch.setattr(gate,'inspect',lambda blobs:{'model_root':str(root)})
    return root,{'public/model_pins.json':json_bytes({'asset_sha256':pins})}


def test_model_only_streams_three_fixed_files(tmp_path,monkeypatch):
    root,data=model_fixture(tmp_path,monkeypatch);calls=[];original=gate._stream_hash
    def record(path):calls.append(path.name);return original(path)
    monkeypatch.setattr(gate,'_stream_hash',record)
    with gate.model_assets(data) as value:assert value==root
    assert calls==list(gate.ASSETS)*2
    assert all((root/n).exists() for n in gate.ASSETS)


def test_model_body_change_rejects_postcheck(tmp_path,monkeypatch):
    root,data=model_fixture(tmp_path,monkeypatch)
    with pytest.raises(ValueError):
        with gate.model_assets(data):(root/'config.json').write_bytes(b'changed')


@pytest.mark.parametrize('later',[KeyboardInterrupt,SystemExit])
def test_model_body_identity_survives_sticky_rethrow_and_cleanup_cancel(tmp_path,monkeypatch,later):
    root,data=model_fixture(tmp_path,monkeypatch);original=gate._stream_hash;calls=[]
    primary=ValueError('actual body')
    def hashing(path):
        calls.append(path.name)
        if len(calls)==4:raise primary
        if len(calls)==5:raise later('cleanup')
        return original(path)
    monkeypatch.setattr(gate,'_stream_hash',hashing)
    with pytest.raises(ValueError) as found:
        with gate.model_assets(data):raise primary
    assert found.value is primary and calls==list(gate.ASSETS)*2


@pytest.mark.parametrize('later',[KeyboardInterrupt,SystemExit])
def test_model_cleanup_only_cancellation_precedes_ordinary(tmp_path,monkeypatch,later):
    root,data=model_fixture(tmp_path,monkeypatch);original=gate._stream_hash;calls=[]
    cancellation=later('cleanup')
    def hashing(path):
        calls.append(path.name)
        if len(calls)==4:raise OSError('earlier cleanup')
        if len(calls)==5:raise cancellation
        return original(path)
    monkeypatch.setattr(gate,'_stream_hash',hashing)
    with pytest.raises(later) as found:
        with gate.model_assets(data):pass
    assert found.value is cancellation and calls==list(gate.ASSETS)*2
