"""Synthetic-only input telemetry and lifecycle tests; never imports a model."""
from pathlib import Path
from types import SimpleNamespace
import json
import subprocess
import sys
import numpy as np
import pytest
import native_observer as native
from ranges import RangeBook, ObservationError, InvalidInput, NORM_LABELS, SILU_LABELS, statistics, merge_statistics
from cleanup_origin import cleanup_origin, mark_cleanup


def complete_book(sequence=3):
    book = RangeBook().begin(sequence)
    for label in sorted(NORM_LABELS):
        book.observe(label, np.array([[0.125 if label == "final.inverse_sqrt" else 2.0]]))
        book.observe(label + ".exact_output", np.array([[999.0]]))
    for label in sorted(SILU_LABELS):
        book.observe(label, np.array([[[-2., 3.]]]))
    for layer in range(28):
        for k in range(1, sequence + 1):
            value = np.arange(2 * k, dtype=np.float64).reshape(1, 2, k) / 8
            book.observe(f"{layer}.softmax.raw_valid", value)
            book.observe(f"{layer}.softmax.centered", value - value.mean(-1, keepdims=True))
    return book


@pytest.mark.parametrize("sequence", (1, 2, 3, 16, 32))
def test_exact_callback_schema_all113_inputs_and_per_query_k(sequence):
    result = complete_book(sequence).end()
    assert result["complete"] and result["norm_input_sites"] == 113 and result["silu_gate_sites"] == 28
    assert result["ignored_exact_output_callbacks"] == 113
    assert len(result["ranges"]) == 197
    assert result["ranges"]["0.input.inverse_sqrt"]["maximum"] == 2
    for layer, rows in result["score_rows"].items():
        assert list(rows) == [str(k) for k in range(1, sequence + 1)]
        for k, row in rows.items():
            assert row["query"] == int(k) - 1 and row["key_count"] == int(k)
            assert row["raw_valid"]["count"] == row["centered"]["count"] == 2 * int(k)
            assert row["k1_bypass"] is (int(k) == 1) and row["reciprocal_observations"] == 0
    json.dumps(result, allow_nan=False)


@pytest.mark.parametrize("value", (True, 1.0, 0, 33, None))
def test_prefix_type_and_range(value):
    with pytest.raises(ObservationError):
        RangeBook().begin(value)


@pytest.mark.parametrize("value", (np.nan, np.inf, -np.inf, 0., -1.))
def test_invalid_norm_input_record_is_json_safe_and_fails(value):
    book = RangeBook().begin(1)
    with pytest.raises(ObservationError):
        book.observe("0.input.inverse_sqrt", np.array([[value]]))
    json.dumps(book.snapshot(), allow_nan=False)
    with pytest.raises(ObservationError):
        book.end()


@pytest.mark.parametrize("kind", ("missing", "duplicate", "order", "center_before_raw", "wrong_shape", "k1_nonzero", "reciprocal"))
def test_missing_duplicate_or_invented_rows_rejected(kind):
    book = RangeBook().begin(3)
    with pytest.raises(ObservationError):
        if kind == "missing":
            book.end()
        elif kind == "duplicate":
            book.observe("0.silu", np.ones((1, 2), dtype=float))
            book.observe("0.silu", np.ones((1, 2), dtype=float))
        elif kind == "order":
            book.observe("0.softmax.raw_valid", np.ones((1, 2, 2), dtype=float))
        elif kind == "center_before_raw":
            book.observe("0.softmax.centered", np.zeros((1, 2, 1), dtype=float))
        elif kind == "wrong_shape":
            book.observe("0.softmax.raw_valid", np.ones((1, 2, 1), dtype=float))
            book.observe("0.softmax.centered", np.zeros((1, 3, 1), dtype=float))
        elif kind == "k1_nonzero":
            book.observe("0.softmax.raw_valid", np.ones((1, 2, 1), dtype=float))
            book.observe("0.softmax.centered", np.ones((1, 2, 1), dtype=float))
        else:
            book.observe("0.softmax.reciprocal", np.ones((1, 1), dtype=float))


def test_statistics_merge_and_snapshot_are_independent():
    first = statistics(np.array([1., 2.])); second = statistics(np.array([-1., 4.]))
    merged = merge_statistics(first, second)
    assert merged == dict(count=4, minimum=-1., maximum=4., nonfinite=0, nonpositive=1)
    merged["count"] = 99
    assert first["count"] == second["count"] == 2
    book = complete_book(1); snapshot = book.snapshot()
    snapshot["score_rows"]["0"]["1"]["raw_valid"]["minimum"] = -999
    assert book.end()["score_rows"]["0"]["1"]["raw_valid"]["minimum"] == 0


@pytest.mark.parametrize("label,shape", (("0.input.inverse_sqrt", (1, 1)), ("0.silu", (1, 1, 2)),
                                       ("0.softmax.raw_valid", (1, 2, 1))))
def test_known_invalid_input_identity_and_partial_snapshot(label, shape):
    book = RangeBook().begin(1)
    with pytest.raises(InvalidInput) as first:
        book.observe(label, np.full(shape, np.nan))
    partial = book.snapshot()
    assert partial["complete"] is False and partial["invalid"] is True
    json.dumps(partial, allow_nan=False)
    with pytest.raises(InvalidInput) as second:
        book.end()
    assert second.value is first.value


def test_structural_failure_is_not_dispatcher_invalid_input():
    book = RangeBook().begin(1)
    with pytest.raises(ObservationError) as result:
        book.observe("invented.variance", np.ones((1, 1)))
    assert not isinstance(result.value, InvalidInput)


class Tensor:
    def __init__(self, values, *, dtype=np.float32, device="cpu"):
        self.data = np.array(values, dtype=dtype, copy=True)
        self.dtype = self.data.dtype
        self.device = SimpleNamespace(type=device)
    @property
    def shape(self): return self.data.shape
    @property
    def ndim(self): return self.data.ndim
    def __getitem__(self, key): return Tensor(self.data[key], dtype=self.dtype)
    def detach(self): return self
    def cpu(self): return self
    def numpy(self): return self.data
    def float(self): return Tensor(self.data)
    def pow(self, power): return Tensor(self.data ** power)
    def mean(self, axis, keepdim=False): return Tensor(self.data.mean(axis=axis, keepdims=keepdim))
    def transpose(self, a, b): return Tensor(self.data.swapaxes(a, b))
    def __add__(self, other): return Tensor(self.data + other)
    def __mul__(self, other): return Tensor(self.data * other)


class Handle:
    def __init__(self, target, hook, index, events):
        self.target, self.hook, self.index, self.events = target, hook, index, events
        self.error = None
    def remove(self):
        self.events.append(self.index)
        self.target.hooks.remove(self.hook)
        if self.error is not None:
            raise self.error


class Target:
    def __init__(self, state):
        self.state = state
        self.hooks = []
        self.variance_epsilon = 1e-6
    def register_forward_pre_hook(self, hook):
        self.state.attempts += 1
        if self.state.attempts == self.state.fail_at:
            raise self.state.install_error
        self.hooks.append(hook)
        handle = Handle(self, hook, self.state.attempts, self.state.removed)
        self.state.handles.append(handle)
        return handle
    def emit(self, value):
        for hook in tuple(self.hooks):
            assert hook(self, (value,)) is None
        return value


def synthetic_model():
    state = SimpleNamespace(attempts=0, fail_at=None, install_error=ValueError("synthetic installation"),
                            handles=[], removed=[])
    layers = []
    for i in range(28):
        attention = SimpleNamespace(layer_idx=i, training=False, num_key_value_groups=2,
                                    q_norm=Target(state), k_norm=Target(state))
        layers.append(SimpleNamespace(input_layernorm=Target(state), post_attention_layernorm=Target(state),
                                      self_attn=attention, mlp=SimpleNamespace(act_fn=Target(state))))
    model = SimpleNamespace(training=False, model=SimpleNamespace(layers=layers, norm=Target(state)))
    return model, state


@pytest.fixture
def backend(monkeypatch):
    model, state = synthetic_model()
    calls = []
    sentinel = object()
    def original(*args, **kwargs):
        calls.append((args, kwargs))
        return sentinel
    module = SimpleNamespace(eager_attention_forward=original,
        repeat_kv=lambda key, groups: Tensor(np.repeat(key.data, groups, axis=1)))
    torch = SimpleNamespace(Tensor=Tensor, float32=np.dtype(np.float32),
                            matmul=lambda a, b: Tensor(a.data @ b.data))
    monkeypatch.setattr(native, "_native_dependencies", lambda: (torch, module))
    return model, state, module, original, calls, sentinel


def emit_context(observer, module, model, sequence):
    q = Tensor(np.arange(1, 1 + sequence * 2 * 4).reshape(1, sequence, 2, 4) / 16)
    k = Tensor(np.arange(1, 1 + sequence * 4).reshape(1, sequence, 1, 4) / 8)
    mask = Tensor(np.where(np.tril(np.ones((sequence, sequence), dtype=bool)), 0., -np.inf)[None, None])
    outputs = []
    for i, layer in enumerate(model.model.layers):
        x = Tensor(np.arange(1, 1 + sequence * 4).reshape(1, sequence, 4) / 4 + i / 8)
        layer.input_layernorm.emit(x)
        layer.post_attention_layernorm.emit(x)
        layer.self_attn.q_norm.emit(q)
        layer.self_attn.k_norm.emit(k)
        layer.mlp.act_fn.emit(Tensor(np.array([-2., 0., 3., 4.])[None, None].repeat(sequence, 1)))
        outputs.append(module.eager_attention_forward(layer.self_attn, q.transpose(1, 2), k.transpose(1, 2),
                                                      k.transpose(1, 2), mask, 0.5, 0., supplied="untouched"))
    last = np.ones((1, sequence, 4), dtype=np.float32) * 100
    last[:, -1] = np.array([1., 2., 3., 4.])
    model.model.norm.emit(Tensor(last))
    return outputs, q, k


@pytest.mark.parametrize("sequence", (1, 3, 32))
def test_native_complete_input_formula_lasttoken_and_forward_identity(backend, sequence):
    model, state, module, original, calls, sentinel = backend
    with native.NativeObserver(model) as observer:
        # Installed but inactive: all141 hooks are inert; wrapper still calls original.
        inactive, _, _ = emit_context(observer, module, model, sequence)
        assert all(x is sentinel for x in inactive) and not observer.book.ranges
        observer.begin(sequence)
        outputs, q, k = emit_context(observer, module, model, sequence)
        result = observer.end()
        assert all(x is sentinel for x in outputs)
        assert len(calls) == 56 and all(kwargs == {"supplied": "untouched"} for _, kwargs in calls)
        assert result["norm_input_sites"] == 113 and result["silu_gate_sites"] == 28
        expected_final = np.float32(np.mean(np.array([1, 4, 9, 16], dtype=np.float32)) + np.float32(1e-6))
        assert result["ranges"]["final.inverse_sqrt"]["minimum"] == float(expected_final)
        assert result["ranges"]["final.inverse_sqrt"]["count"] == 1
        assert result["ranges"]["0.silu"]["minimum"] == -2
        # Independent scalar dot products for every valid row; future keys excluded.
        for query in range(sequence):
            values = []
            for head in range(2):
                for key in range(query + 1):
                    values.append(sum(float(q.data[0, query, head, d]) * float(k.data[0, key, 0, d])
                                      for d in range(4)) * 0.5)
            row = result["score_rows"]["0"][str(query + 1)]
            assert row["raw_valid"]["minimum"] == min(values)
            assert row["raw_valid"]["maximum"] == max(values)
        after, _, _ = emit_context(observer, module, model, sequence)
        assert all(x is sentinel for x in after) and observer.book.snapshot()["ranges"] == result["ranges"]
    assert module.eager_attention_forward is original and len(state.removed) == 141
    assert observer.cleanup_completed is True


@pytest.mark.parametrize("failure_index", (1, 2, 27, 141))
def test_partial_hook_install_attempts_every_prior_release(backend, failure_index):
    model, state, module, original, _, _ = backend
    state.fail_at = failure_index
    observer = native.NativeObserver(model)
    with pytest.raises(ValueError) as result:
        observer.__enter__()
    assert result.value is state.install_error
    assert state.removed == list(range(1, failure_index))
    assert module.eager_attention_forward is original and not observer.entered


def test_partial_install_real_body_remains_primary_through_cleanup_cancel(backend):
    model, state, module, original, _, _ = backend
    state.fail_at = 4
    target = model.model.layers[0].input_layernorm
    register = target.register_forward_pre_hook
    def replaced(hook):
        handle = register(hook)
        handle.error = KeyboardInterrupt("cleanup cancellation")
        return handle
    target.register_forward_pre_hook = replaced
    observer = native.NativeObserver(model)
    with pytest.raises(ValueError) as result:
        observer.__enter__()
    assert result.value is state.install_error and state.removed == [1, 2, 3]
    assert module.eager_attention_forward is original and observer.cleanup_completed is False


def test_failed_remove_attribute_lookup_retains_new_handle_and_cleans_earlier(backend):
    model, state, module, original, _, _ = backend
    target = model.model.layers[0].post_attention_layernorm
    register = target.register_forward_pre_hook
    error = ValueError("synthetic remove lookup")
    class BadHandle:
        @property
        def remove(self):
            raise error
    bad = BadHandle()
    def replaced(hook):
        register(hook)
        return bad
    target.register_forward_pre_hook = replaced
    observer = native.NativeObserver(model)
    with pytest.raises(ValueError) as result:
        observer.__enter__()
    assert result.value is error and state.removed == [1]
    assert observer._failed_owners[0][0] is bad and observer.cleanup_completed is False
    assert module.eager_attention_forward is original


def test_global_restore_failure_does_not_skip_handles_or_hide_cancel(backend, monkeypatch):
    model, state, module, original, _, _ = backend
    class BackendModule:
        def __init__(self):
            object.__setattr__(self, "fail_restore", False)
            object.__setattr__(self, "eager_attention_forward", original)
            object.__setattr__(self, "repeat_kv", module.repeat_kv)
        def __setattr__(self, name, value):
            if name == "eager_attention_forward" and value is original and self.fail_restore:
                raise OSError("restore")
            object.__setattr__(self, name, value)
    replacement = BackendModule()
    torch, _ = native._native_dependencies()
    monkeypatch.setattr(native, "_native_dependencies", lambda: (torch, replacement))
    observer = native.NativeObserver(model).__enter__()
    replacement.fail_restore = True
    cancellation = SystemExit("handle cancellation")
    state.handles[0].error = cancellation
    with pytest.raises(SystemExit) as result:
        observer.__exit__(None, None, None)
    assert result.value is cancellation and len(state.removed) == 141
    assert observer.cleanup_completed is False and observer._failed_owners[0][0] is replacement


def test_k1_no_mask_and_original_argument_identity(backend):
    model, _, module, _, calls, sentinel = backend
    with native.NativeObserver(model) as observer:
        observer.begin(1)
        query = Tensor(np.arange(8).reshape(1, 2, 1, 4))
        key = Tensor(np.arange(4).reshape(1, 1, 1, 4))
        value = Tensor(np.ones((1, 1, 1, 4)))
        result = module.eager_attention_forward(model.model.layers[0].self_attn, query, key, value,
                                               None, .5, 0., unchanged="yes")
        assert result is sentinel and calls[0][0][1] is query and calls[0][0][2] is key and calls[0][0][3] is value
        row = observer.book.snapshot()["score_rows"]["0"]["1"]
        assert row["k1_bypass"] and row["centered"]["minimum"] == row["centered"]["maximum"] == 0
        assert row["reciprocal_observations"] == 0


@pytest.mark.parametrize("cancel", (KeyboardInterrupt, SystemExit, GeneratorExit))
def test_cleanup_only_cancellation_wins_and_attempts_all(backend, cancel):
    model, state, module, original, _, _ = backend
    observer = native.NativeObserver(model).__enter__()
    state.handles[0].error = OSError("first cleanup")
    cancellation = cancel("later cleanup")
    state.handles[1].error = cancellation
    with pytest.raises(cancel) as result:
        observer.__exit__(None, None, None)
    assert result.value is cancellation and len(state.removed) == 141
    assert module.eager_attention_forward is original and observer.cleanup_completed is False
    assert len(observer._failed_owners) == 2
    with pytest.raises(ValueError):
        observer.__enter__()


@pytest.mark.parametrize("primary", (ValueError("body"), KeyboardInterrupt("body"), SystemExit("body")))
def test_body_identity_wins_cleanup_and_captured_remove_is_used(backend, primary):
    model, state, module, original, _, _ = backend
    observer = native.NativeObserver(model).__enter__()
    state.handles[0].error = KeyboardInterrupt("remove")
    state.handles[1].remove = lambda: (_ for _ in ()).throw(AssertionError("replacement must not be used"))
    assert observer.__exit__(type(primary), primary, None) is False
    assert len(state.removed) == 141 and primary.__notes__
    assert module.eager_attention_forward is original


@pytest.mark.parametrize("cancel", (KeyboardInterrupt, SystemExit))
def test_external_cleanup_origin_yields_to_later_hook_cancellation(backend, cancel):
    model, state, module, original, _, _ = backend
    observer = native.NativeObserver(model).__enter__()
    incoming = mark_cleanup(OSError("external file close"))
    cancellation = cancel("later hook close")
    state.handles[0].error = incoming
    state.handles[1].error = cancellation
    with pytest.raises(cancel) as result:
        observer.__exit__(type(incoming), incoming, None)
    assert result.value is cancellation and cleanup_origin(cancellation)
    assert len(state.removed) == 141 and module.eager_attention_forward is original


@pytest.mark.parametrize("primary_type", (ValueError, OSError, KeyboardInterrupt, SystemExit))
def test_identical_genuine_body_rethrow_never_becomes_cleanup_origin(backend, primary_type):
    model, state, module, original, _, _ = backend
    observer = native.NativeObserver(model).__enter__()
    incoming = primary_type("genuine body")
    state.handles[0].error = incoming
    state.handles[1].error = KeyboardInterrupt("later cleanup")
    assert observer.__exit__(type(incoming), incoming, None) is False
    assert not cleanup_origin(incoming) and len(state.removed) == 141
    assert module.eager_attention_forward is original


@pytest.mark.parametrize("kind", ("training", "dtype", "cache", "mask", "foreign", "nonfinite", "binding"))
def test_invalid_native_attention_rejects_before_original(backend, kind):
    model, state, module, original, calls, _ = backend
    with native.NativeObserver(model) as observer:
        observer.begin(2)
        attention = model.model.layers[0].self_attn
        q = Tensor(np.ones((1, 2, 2, 4)))
        k = Tensor(np.ones((1, 1, 2, 4)))
        mask = Tensor(np.array([[[[0., -np.inf], [0., 0.]]]]))
        if kind == "training": attention.training = True
        elif kind == "dtype": q = Tensor(q.data, dtype=np.float64)
        elif kind == "cache": k = Tensor(np.ones((1, 1, 1, 4)))
        elif kind == "mask": mask = Tensor(np.zeros((1, 1, 2, 2)))
        elif kind == "foreign": attention = SimpleNamespace(training=False, num_key_value_groups=2)
        elif kind == "nonfinite": q.data[0, 0, 0, 0] = np.nan
        elif kind == "binding": model.model.layers = list(model.model.layers[:-1])
        with pytest.raises(ValueError):
            module.eager_attention_forward(attention, q, k, k, mask, .5)
        assert not calls


def test_nested_capture_and_incomplete_end_fail(backend):
    model, state, module, original, _, _ = backend
    with native.NativeObserver(model) as observer:
        with pytest.raises(ValueError):
            native.NativeObserver(model).__enter__()
        observer.begin(1)
        with pytest.raises(ObservationError):
            observer.end()
    assert module.eager_attention_forward is original


@pytest.mark.parametrize("site", ("norm", "silu", "attention"))
def test_abort_invalid_forward_retains_snapshot_and_allows_next_prefix(backend, site):
    model, state, module, original, _, _ = backend
    with native.NativeObserver(model) as observer:
        observer.begin(1)
        with pytest.raises(InvalidInput):
            if site == "norm":
                model.model.layers[0].input_layernorm.emit(Tensor(np.full((1, 1, 4), np.nan)))
            elif site == "silu":
                model.model.layers[0].mlp.act_fn.emit(Tensor(np.full((1, 1, 4), np.nan)))
            else:
                q = Tensor(np.full((1, 2, 1, 4), np.nan)); k = Tensor(np.ones((1, 1, 1, 4)))
                module.eager_attention_forward(model.model.layers[0].self_attn, q, k, k, None, .5)
        partial = observer.abort()
        assert partial["invalid"] and partial["complete"] is False
        assert not observer.active and not observer.book.active and not state.removed
        # Bare/inactive pass no longer observes or trips the previous invalid book.
        emit_context(observer, module, model, 1)
        observer.begin(1)
        emit_context(observer, module, model, 1)
        assert observer.end()["complete"]
        assert partial["invalid"] and partial["complete"] is False
        with pytest.raises(ValueError):
            observer.abort()
    assert len(state.removed) == 141 and module.eager_attention_forward is original


def test_imports_are_lazy_in_fresh_process():
    root = str(Path(__file__).resolve().parent)
    code = """import sys,importlib.abc
class Block(importlib.abc.MetaPathFinder):
 def find_spec(self,name,path=None,target=None):
  if name.split('.')[0] in ('torch','transformers','jax','jaxlib','jaxite_word'):
   raise AssertionError('model/backend imported during observer module import')
sys.meta_path.insert(0,Block())
sys.path.insert(0,""" + repr(root) + """)
import native_observer,ranges
assert not any(x.split('.')[0] in ('torch','transformers','jax','jaxlib','jaxite_word') for x in sys.modules)
"""
    result = subprocess.run([sys.executable, "-I", "-B", "-c", code], capture_output=True, timeout=60)
    assert result.returncode == 0, result.stderr.decode()
