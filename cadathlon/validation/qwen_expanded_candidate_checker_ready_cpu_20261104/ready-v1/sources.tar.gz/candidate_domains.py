"""Ordered frozen-circuit observations; subclasses do not replace arithmetic."""
from dataclasses import dataclass
import copy,json,math
import numpy as np
import arithmetic
from strict_metrics import StructuralFailure,NonfiniteOutput,array,operator_shapes

@dataclass(frozen=True)
class Event:
    label:str
    domain:tuple
    shape:tuple

def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)
def interval(rule):
    values=rule.get('domain')
    if type(values)is not list or len(values)!=2 or any(type(v)not in(int,float)or not math.isfinite(v)for v in values)or not values[0]<values[1]:
        raise StructuralFailure('Finite declared two-endpoint domain required')
    return tuple(values)
def count(value,label):
    if type(value)is not int or not 1<=value<=64:raise StructuralFailure('Exact bounded circuit count: '+label)
    return value

def plan(manifest,sequence):
    operator_shapes(sequence);S=sequence;rows=[];rules=manifest['nonlinear']
    required={f'{i}.{part}'for i in range(28)for part in('input.inverse_sqrt','post.inverse_sqrt','q.inverse_sqrt','k.inverse_sqrt','silu')}|{'final.inverse_sqrt'}
    if set(rules)!=required:raise StructuralFailure('Exact113 norm and28SiLU rules required')
    def add(label,rule,shape):rows.append(Event(label,interval(rule),shape))
    def norm(label,shape):
        r=rules[label]
        if r['method']not in('newton','polynomial'):raise StructuralFailure('Declared norm method differs')
        if r['method']=='newton':count(r['iterations'],label)
        add(label,r,shape)
    for i in range(28):
        p=str(i);norm(p+'.input.inverse_sqrt',(1,S,1));norm(p+'.q.inverse_sqrt',(1,16,S,1));norm(p+'.k.inverse_sqrt',(1,8,S,1))
        soft=manifest['softmax'][p];rounds=count(soft['squarings'],p+'.softmax')
        for query in range(1,S):
            k=query+1;label=p+'.attention.query'+str(query)
            add(label+'.centered',{'domain':soft['centered_domain']},(1,16,k))
            add(label+'.exp',manifest['exp'],(1,16,k))
            initial=manifest['initial_reciprocal'];count(initial['iterations'],label+'.initial_inverse');add(label+'.initial_inverse',initial,(1,16,1))
            r=manifest['reciprocal_by_keys'][str(k)];count(r['iterations'],label+'.round.inverse')
            for j in range(rounds):add(label+f'.round{j}.inverse',r,(1,16,1))
        norm(p+'.post.inverse_sqrt',(1,S,1));silu=rules[p+'.silu'];add(p+'.silu',silu,(1,S,3072))
        if silu['method']=='rational_tanh':
            add(p+'.silu.tanh_base',silu['base'],(1,S,3072));count(silu['reciprocal']['iterations'],p+'.silu.inverse')
            for j in range(count(silu['doublings'],p+'.silu')):add(p+f'.silu.inverse{j}',silu['reciprocal'],(1,S,3072))
        elif silu['method']!='polynomial':raise StructuralFailure('Declared SiLU method differs')
    norm('final.inverse_sqrt',(1,1))
    if len({r.label for r in rows})!=len(rows):raise StructuralFailure('Duplicate declared domain label')
    return tuple(rows)

class Operators(dict):
    def __init__(self,sequence):super().__init__();self.expected=operator_shapes(sequence)
    def __setitem__(self,label,value):
        labels=tuple(self.expected)
        if len(self)>=len(labels)or label!=labels[len(self)]or label in self:raise StructuralFailure('Missing/duplicate/out-of-order candidate operator')
        array(value,self.expected[label],label=label);super().__setitem__(label,value)

class Blocks(list):
    def __init__(self,sequence):super().__init__();self.sequence=sequence
    def append(self,value):
        if len(self)>=28:raise StructuralFailure('Extra candidate block')
        array(value,(1,self.sequence,1024),label='candidate block');super().append(value)

class ObservedArithmetic(arithmetic.QwenArithmetic):
    def __init__(self,manifest,sequence):
        frozen=copy.deepcopy(manifest);super().__init__(frozen)
        self.manifest_binding=canonical(frozen);self.expected_events=plan(frozen,sequence);self.event_index=0
        self.operators=Operators(sequence);self.blocks=Blocks(sequence)
    def observe(self,label,data,domain):
        if canonical(self.manifest)!=self.manifest_binding:raise StructuralFailure('Frozen candidate mutated')
        if self.event_index>=len(self.expected_events):raise StructuralFailure('Extra domain observation')
        event=self.expected_events[self.event_index];values=np.asarray(data)
        if label!=event.label or canonical(domain)!=canonical(list(event.domain))or values.shape!=event.shape or values.dtype.kind!='f':
            raise StructuralFailure('Missing/duplicate/domain/shape observation mismatch')
        self.event_index+=1
        # Exact inherited observation records rejected finite extrema before it
        # raises; the frozen operator has not evaluated its invalid input yet.
        return super().observe(label,data,domain)
    def require_complete(self):
        if canonical(self.manifest)!=self.manifest_binding or self.event_index!=len(self.expected_events)or len(self.operators)!=421 or len(self.blocks)!=28 or self.domain_failures():
            raise StructuralFailure('Complete candidate domain/operator/block inventory required')
    def report(self):
        return dict(expected_observations=len(self.expected_events),observations=self.event_index,
                    domains=copy.deepcopy(self.domains),normalization_variance={k:copy.deepcopy(v)for k,v in self.domains.items()if k.endswith('.inverse_sqrt')},
                    scope='Candidate propagated inputs only; weighted normalization outputs are separate operator metrics')
