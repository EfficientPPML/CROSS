"""Root-pinned activation contract. A self-asserted JSON file is not authority."""
from dataclasses import dataclass
from initial_proof import (BASELINE_SHA256, GATE_BOUNDS_SHA256, PROTOCOL_SHA256,
    SOURCE_MANIFEST_SHA256, RECONSTRUCTION_SCRIPT_SHA256, absolute_path, bounded, hash_string, parse, canonical, digest)


@dataclass(frozen=True, slots=True)
class Authorization:
    grant_sha256: str
    source_manifest_sha256: str
    output_directory: str
    evidence_bytes: bytes
    preflight_report_sha256: str
    independent_preflight_review_sha256: str


def authenticate_grant(raw, expected_sha256, *, source_manifest_sha256, output_directory):
    bounded(raw, 1 << 20, expected_sha256)
    grant = parse(raw)
    fixed = dict(schema='qwen-expanded-initial-selector-grant-v1', ready=True,
        execute_authorized=True, candidate_ordinal=1, source_manifest_sha256=source_manifest_sha256,
        observer_source_manifest_sha256=SOURCE_MANIFEST_SHA256, protected_manifest_sha256=BASELINE_SHA256,
        protocol_sha256=PROTOCOL_SHA256, gate_bounds_sha256=GATE_BOUNDS_SHA256,
        output_directory=output_directory, model_execution=False, token_or_calibration_body_reads=False,
        validation_body_reads=False, encrypted_execution=False)
    extra = {'preflight_report_sha256', 'independent_preflight_review_sha256', 'initial_evidence'}
    if (type(grant) is not dict or set(grant) != set(fixed) | extra or
            any(canonical(grant[k]) != canonical(v) for k, v in fixed.items())):
        raise ValueError('Exact externally reviewed initial-selection grant required')
    if not hash_string(source_manifest_sha256):
        raise ValueError('Exact selector source manifest digest required')
    absolute_path(output_directory)
    for key in ('preflight_report_sha256', 'independent_preflight_review_sha256'):
        if not hash_string(grant[key]):
            raise ValueError('Reviewed complete preflight hashes required')
    evidence = grant['initial_evidence']
    if type(evidence) is not dict or set(evidence) != {'parent', 'worker', 'source_archive', 'root_review', 'reconstruction_script', 'root_reconstruction_outer_receipt'}:
        raise ValueError('Exact public initial evidence descriptors required')
    for name, row in evidence.items():
        if type(row) is not dict or set(row) != {'path', 'sha256', 'bytes'}:
            raise ValueError('Exact public proof file descriptor required')
        absolute_path(row['path'])
        bound = (2 if name in ('root_review', 'reconstruction_script', 'root_reconstruction_outer_receipt') else 32) << 20
        if not hash_string(row['sha256']) or type(row['bytes']) is not int or not 0 < row['bytes'] <= bound:
            raise ValueError('Bounded public proof file required')
    if len({row['path'] for row in evidence.values()}) != 6:
        raise ValueError('Distinct initial evidence paths required')
    if evidence['reconstruction_script']['sha256'] != RECONSTRUCTION_SCRIPT_SHA256:
        raise ValueError('Independently reviewed reconstruction script required')
    return Authorization(digest(raw), source_manifest_sha256, output_directory, canonical(evidence),
        grant['preflight_report_sha256'], grant['independent_preflight_review_sha256'])
