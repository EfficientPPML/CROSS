from pathlib import Path
from types import SimpleNamespace
import copy,hashlib,json,os
import pytest
import observer_process as p
from test_input_gate import blobs as base_blobs
from freeze_io import json_bytes


def blobs():
    data=base_blobs();data['execution_authorization.json']=b'{"execute":false}'
    return data


def args(tmp_path,mode='collect-observer'):
    return SimpleNamespace(output=str(tmp_path/'evidence'),private_output=str(tmp_path/'private'),
        mode=mode,manifest=str(tmp_path/'sources.json'),manifest_sha256='a'*64,grant=None,grant_sha256=None)


def valid_grant(a,data):
    e=json.loads(data['external_inputs.json'])
    return dict(schema='qwen-expanded-prefix-observer-grant-v2',execute=True,
        scope='initial-native-exact3200-baseline-free64-only',source_manifest_sha256=a.manifest_sha256,
        protocol_sha256=e['producer']['protocol_sha256'],baseline_manifest_sha256=e['baseline_manifest_sha256'],
        producer=e['producer'],calibration=e['calibration'],
        model_pins_sha256=hashlib.sha256(data['public/model_pins.json']).hexdigest(),
        private_output=a.private_output,evidence_output=a.output,
        model_forward=True,tokenizer_execution=False,coefficient_selection=False,validation_read=False,
        cpu_affinity=[112,113,114,115],torch_threads=4,torch_interop_threads=1,
        preflight_report_sha256='b'*64,independent_review_sha256='c'*64,
        backend_environment=dict(p.backend_environment.REQUIRED))


def install_grant(tmp_path,a,value):
    file=tmp_path/'grant.json';file.write_bytes(json_bytes(value));a.grant=str(file)
    a.grant_sha256=hashlib.sha256(file.read_bytes()).hexdigest()


def test_public_grant_exact_binding_only_no_body(tmp_path,monkeypatch):
    data=blobs();a=args(tmp_path);g=valid_grant(a,data);install_grant(tmp_path,a,g)
    monkeypatch.setattr(p.os,'sched_getaffinity',lambda pid:{112,113,114,115})
    assert p.grant_check(a,data)==g
    a.mode='observer-worker';a.output=str(tmp_path/'evidence'/'worker')
    assert p.grant_check(a,data)==g


@pytest.mark.parametrize('field,value',[('execute',1),('scope','selection'),('validation_read',True),
    ('coefficient_selection',True),('model_forward',False),('tokenizer_execution',True),
    ('torch_threads',True),('torch_interop_threads',True),('source_manifest_sha256','d'*64),
    ('baseline_manifest_sha256','e'*64),('model_pins_sha256','f'*64),
    ('private_output','/tmp/different'),('evidence_output','/tmp/different'),
    ('cpu_affinity',[112,113,114,True]),('preflight_report_sha256',None)])
def test_bad_grants_fail_before_output_or_body(tmp_path,monkeypatch,field,value):
    data=blobs();a=args(tmp_path);g=valid_grant(a,data);g[field]=value;install_grant(tmp_path,a,g)
    monkeypatch.setattr(p.os,'sched_getaffinity',lambda pid:{112,113,114,115})
    monkeypatch.setattr(p,'Output',lambda *a:pytest.fail('output before authorization'))
    with pytest.raises(ValueError):p.worker(a,{},data,{},tmp_path/'source')
    assert not Path(a.output).exists() and not Path(a.private_output).exists()


def test_missing_grant_never_creates_output(tmp_path,monkeypatch):
    data=blobs();a=args(tmp_path)
    monkeypatch.setattr(p,'Output',lambda *a:pytest.fail('output without grant'))
    with pytest.raises(PermissionError):p.worker(a,{},data,{},tmp_path/'source')


@pytest.mark.parametrize('which',['calibration','validation','old_outcome','source','model','nested_private'])
def test_protected_output_paths_reject_before_mkdir(tmp_path,which):
    data=blobs();a=args(tmp_path);source=tmp_path/'source';source.mkdir()
    e=json.loads(data['external_inputs.json']);cal=Path(e['calibration']['path'])
    paths={'calibration':cal.parent/'report','validation':cal.parent/'validation_inputs.json',
        'old_outcome':Path(e['protected_paths'][1])/'new-evidence',
        'source':source/'evidence','model':Path(e['model_root'])/'new-evidence',
        'nested_private':Path(a.private_output)/'nested'}
    a.output=str(paths[which])
    with pytest.raises(ValueError):p.validate_paths(a,data,source)


def audit(monkeypatch,allow_inputs):
    hooks=[];monkeypatch.setattr(p.sys,'addaudithook',hooks.append)
    data=blobs();denials=p.install_audit(data,allow_inputs)
    return hooks[0],denials,json.loads(data['external_inputs.json'])


def test_actual_audit_allows_only_calibration_and_three_model_assets(monkeypatch):
    hook,denials,e=audit(monkeypatch,True)
    for file in [e['calibration']['path'],*[e['model_root']+'/'+n for n in e['model_assets']]]:
        hook('open',(file,'rb',os.O_RDONLY))
    assert denials==[]
    for file in [str(Path(e['calibration']['path']).with_name('validation_inputs.json')),
        e['model_root']+'/tokenizer.json',e['protected_paths'][1]+'/old-report.json']:
        with pytest.raises(PermissionError):hook('open',(file,'rb',os.O_RDONLY))
    with pytest.raises(PermissionError):hook('open',(e['calibration']['path'],'wb',os.O_WRONLY|os.O_TRUNC))
    with pytest.raises(PermissionError):hook('socket.connect',('synthetic',))
    assert len(denials)==5


def test_preflight_audit_denies_real_bodies_allows_owned_synthetic(monkeypatch,tmp_path):
    synthetic=tmp_path/'synthetic';synthetic.mkdir()
    hook,denials,e=audit(monkeypatch,False)
    with pytest.raises(PermissionError):hook('open',(e['calibration']['path'],'rb',os.O_RDONLY))
    with pytest.raises(PermissionError):hook('open',(e['model_root']+'/config.json','rb',os.O_RDONLY))
    with pytest.raises(PermissionError):hook('open',(str(synthetic/'model.safetensors'),'wb',os.O_WRONLY|os.O_CREAT))
    hook('open',(str(synthetic/'synthetic-weights.json'),'wb',os.O_WRONLY|os.O_CREAT))
    with pytest.raises(PermissionError):hook('open',(str(tmp_path/'outside.safetensors'),'rb',os.O_RDONLY))
    assert len(denials)==4
