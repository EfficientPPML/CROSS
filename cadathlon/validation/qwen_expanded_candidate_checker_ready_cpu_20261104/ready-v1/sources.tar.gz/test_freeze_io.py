import os
import pytest
import freeze_io as f
from cleanup_origin import protect_body,mark_cleanup,cleanup_origin,choose


def throwing(error):
    def action(*args, **kwargs):raise error
    return action


@pytest.mark.parametrize('body_cls',[ValueError,OSError,KeyboardInterrupt,SystemExit])
@pytest.mark.parametrize('later_cls',[KeyboardInterrupt,SystemExit])
def test_same_body_identity_cannot_be_retagged(body_cls,later_cls):
    primary=body_cls('body')
    f.finish(primary,throwing(primary))
    f.finish(primary,throwing(later_cls('later cleanup')))
    assert cleanup_origin(primary) is False
    assert choose(primary,later_cls('again'),'later',body_primary=primary) is primary


@pytest.mark.parametrize('later_cls',[KeyboardInterrupt,SystemExit])
def test_cleanup_origin_cross_helper_priority(later_cls):
    earlier=mark_cleanup(OSError('first close'));later=later_cls('second close')
    with pytest.raises(later_cls) as found:f.finish(earlier,throwing(later))
    assert found.value is later


def test_read_body_preserved_on_close_failure(tmp_path,monkeypatch):
    path=tmp_path/'data';path.write_bytes(b'synthetic');primary=ValueError('read body');closed=[]
    original=os.close
    monkeypatch.setattr(f.os,'read',throwing(primary))
    def close(fd):closed.append(fd);original(fd);raise KeyboardInterrupt('close')
    monkeypatch.setattr(f.os,'close',close)
    with pytest.raises(ValueError) as found:f.read(path)
    assert found.value is primary and len(closed)==1


def test_owned_directory_replacement_never_publishes(tmp_path):
    path=tmp_path/'owned';out=f.Output(path);moved=tmp_path/'moved';path.rename(moved);path.mkdir(mode=0o700)
    try:
        with pytest.raises(ValueError):out.json('report.json',{'passed':True})
        assert not (path/'report.json').exists() and not (moved/'report.json').exists()
    finally:out.close()


def test_fresh_output_collision_leaves_original_bytes(tmp_path):
    path=tmp_path/'foreign';path.mkdir();file=path/'report.json';file.write_bytes(b'unchanged')
    with pytest.raises(FileExistsError):f.Output(path)
    assert file.read_bytes()==b'unchanged'
