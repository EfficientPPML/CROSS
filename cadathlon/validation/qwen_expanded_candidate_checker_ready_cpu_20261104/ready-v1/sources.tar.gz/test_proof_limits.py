"""Explicit public-assessment limits, with no producer outcome/body access."""
from pathlib import Path
import ast
import hashlib
import os
import pytest
import entry
import checker_admission as admission
import checker_process as process
import proof_limits as limits

HERE=Path(__file__).parent


@pytest.mark.parametrize('name',[limits.ASSESSMENT_PATH,'entry.py','candidate_proof/report.json',
    'candidate_proof/selector-assessments.py','candidate_proof/../selector-assessments.json',
    'candidate_proof//selector-assessments.json','other/selector-assessments.json'])
def test_exact_role_limit_and_bootstrap_agree(name):
    expected=64<<20 if name==limits.ASSESSMENT_PATH else 8<<20
    assert entry.source_limit(name)==limits.source_limit(name)==expected
    assert entry.check_source_sizes({name:expected})==limits.check_source_sizes({name:expected})==expected
    for check in (entry.check_source_sizes,limits.check_source_sizes):
        with pytest.raises(ValueError):check({name:expected+1})


@pytest.mark.parametrize('size',[True,0,-1,1.0,None])
def test_typed_nonempty_source_size_required(size):
    for check in (entry.check_source_sizes,limits.check_source_sizes):
        with pytest.raises(ValueError):check({'entry.py':size})


def test_combined96_limit_stays_bounded():
    sizes={limits.ASSESSMENT_PATH:64<<20,**{f'{n}.py':8<<20 for n in range(4)}}
    for check in (entry.check_source_sizes,limits.check_source_sizes):
        assert check(sizes)==96<<20
        with pytest.raises(ValueError):check(dict(sizes,extra=1))


def test_bootstrap_and_postauth_size_code_are_identical():
    names={'source_limit','check_source_sizes'}
    def body(file):
        return {n.name:ast.dump(n,include_attributes=False)for n in ast.parse((HERE/file).read_text()).body
                if isinstance(n,ast.FunctionDef)and n.name in names}
    assert body('entry.py')==body('proof_limits.py')
    assert entry.MAX_SOURCE==limits.MAX_SOURCE==8<<20
    assert entry.MAX_ASSESSMENT==limits.MAX_ASSESSMENT==64<<20
    assert entry.MAX_SOURCE_TOTAL==limits.MAX_SOURCE_TOTAL==96<<20


@pytest.mark.parametrize('name',['candidate_proof/assessments.json','candidate_proof/report.json',
    'candidate_proof/selector-assessments.py','candidate_proof//selector-assessments.json'])
def test_large_admission_exception_cannot_be_renamed(name):
    data=b'{}';row={'blob':name,'sha256':hashlib.sha256(data).hexdigest()}
    with pytest.raises(ValueError):admission.assessment_blob({name:data},row)


def test_actual_sized_synthetic_public_assessment_roundtrip(tmp_path,monkeypatch):
    # Matches the public selector descriptor size, not its contents. This is a
    # newly owned filler JSON; no actual assessments/outcomes are opened here.
    size=37_283_359;prefix=b'{"synthetic":true,"padding":"';suffix=b'"}'
    raw=prefix+b'x'*(size-len(prefix)-len(suffix))+suffix
    root=tmp_path/'source';path=root/limits.ASSESSMENT_PATH;path.parent.mkdir(parents=True)
    path.write_bytes(raw);pin=hashlib.sha256(raw).hexdigest()
    assert entry.bounded(path,limits.MAX_ASSESSMENT)==raw
    assert admission.assessment_blob({limits.ASSESSMENT_PATH:raw},dict(blob=limits.ASSESSMENT_PATH,sha256=pin)) is raw
    assert process.source_end(root,{limits.ASSESSMENT_PATH:pin})=={limits.ASSESSMENT_PATH:pin}
    with pytest.raises(ValueError):admission.bound_blob({limits.ASSESSMENT_PATH:raw},dict(blob=limits.ASSESSMENT_PATH,sha256=pin))
    # The ordinary/code bound must reject before reading even one body byte.
    with monkeypatch.context() as patch:
        patch.setattr(entry.os,'read',lambda *args:pytest.fail('oversized ordinary source body read'))
        with pytest.raises(ValueError):entry.bounded(path,limits.MAX_SOURCE)


def test_over64_descriptor_rejected_before_body(tmp_path,monkeypatch):
    path=tmp_path/'synthetic.json'
    with path.open('wb')as stream:stream.truncate((64<<20)+1)
    monkeypatch.setattr(entry.os,'read',lambda *args:pytest.fail('oversized assessment body read'))
    with pytest.raises(ValueError):entry.bounded(path,limits.MAX_ASSESSMENT)


def test_source_end_code_limit_not_widened(tmp_path,monkeypatch):
    path=tmp_path/'oversized.py'
    with path.open('wb')as stream:stream.truncate((8<<20)+1)
    monkeypatch.setattr(process,'read',lambda *args,**kwargs:pytest.fail('oversized code read'))
    with pytest.raises(ValueError):process.source_end(tmp_path,{'oversized.py':'0'*64})
