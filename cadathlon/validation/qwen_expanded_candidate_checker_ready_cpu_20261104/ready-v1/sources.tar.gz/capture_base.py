"""Native input observer; lazy imports, unchanged eager forward, no model loader.

Hooks observe INPUT variances and SiLU gate inputs. They never return a tensor.
Final norm observes the last token only. Score telemetry recomputes the native
matmul/scaling expression before calling the original eager function unchanged.
"""
import math
import numpy as np
from ranges import RangeBook, ObservationError
from cleanup_origin import cleanup_origin, protect_body, choose


def _native_dependencies():
    import torch
    from transformers.models.qwen3 import modeling_qwen3
    return torch, modeling_qwen3


class NativeObserver:
    def __init__(self, model):
        self.model = model
        self.layers = tuple(model.model.layers)
        if len(self.layers) != 28:
            raise ValueError("Exactly28 native decoder layers required")
        self.book = RangeBook()
        self.active = False
        self.entered = False
        self.cleanup_completed = None
        self._handles = []
        self._failed_owners = []
        self._module = None
        self._original = None
        self._wrapper = None
        self._torch = None
        self._failed = False
        self._targets = {id(layer.self_attn): i for i, layer in enumerate(self.layers)}
        if len(self._targets) != 28:
            raise ValueError("Distinct native attention owners required")

    def _check_binding(self):
        current = tuple(self.model.model.layers)
        if len(current) != len(self.layers) or any(a is not b for a, b in zip(current, self.layers)):
            raise ValueError("Native decoder layer binding changed")
        if self._module is None or self._module.eager_attention_forward is not self._wrapper:
            raise ValueError("Native eager observer binding changed")

    def _tensor(self, value):
        if (not isinstance(value, self._torch.Tensor) or value.device.type != "cpu"
                or value.dtype != self._torch.float32):
            raise ObservationError("Native observations require CPU float32 tensors")
        return value

    def _array(self, value):
        # A float64 copy is used only for scalar variance/SiLU statistics.
        return self._tensor(value).detach().cpu().numpy().astype(np.float64, copy=True)

    def _norm_hook(self, label, target, last=False):
        def hook(module, args):
            if not self.active:
                return None
            if module is not target or len(args) != 1:
                raise ObservationError("Native norm hook input binding differs")
            self._check_binding()
            value = self._tensor(args[0])
            if value.ndim < 3 or value.shape[0] != 1:
                raise ObservationError("Native norm requires batch1 sequence input")
            if value.shape[1] != self.book.sequence_length:
                raise ObservationError("Native norm sequence differs")
            head_norm = label.split(".")[1:2] in (["q"], ["k"])
            if value.ndim != (4 if head_norm else 3):
                raise ObservationError("Native norm layout differs")
            if last:
                if value.ndim != 3 or value.shape[1] != self.book.sequence_length:
                    raise ObservationError("Final norm sequence differs")
                value = value[:, -1:]
            epsilon = module.variance_epsilon
            if isinstance(epsilon, bool) or not math.isfinite(float(epsilon)) or float(epsilon) <= 0:
                raise ObservationError("Finite positive native norm epsilon required")
            variance = value.float().pow(2).mean(-1, keepdim=True) + epsilon
            self.book.observe(label, self._array(variance))
            return None
        return hook

    def _silu_hook(self, label, target):
        def hook(module, args):
            if not self.active:
                return None
            if module is not target or len(args) != 1:
                raise ObservationError("Native SiLU input binding differs")
            self._check_binding()
            value = self._tensor(args[0])
            if value.ndim != 3 or value.shape[:2] != (1, self.book.sequence_length):
                raise ObservationError("Native SiLU gate layout differs")
            self.book.observe(label, self._array(value))
            return None
        return hook

    def _register(self, module, hook):
        handle = module.register_forward_pre_hook(hook)
        # Store the original removal method so later attribute replacement cannot
        # silently lose retirement ownership.
        self._handles.append((handle, None))
        self._handles[-1] = (handle, handle.remove)

    def _restore(self, primary=None):
        incoming = primary
        body_primary = None if cleanup_origin(primary) else protect_body(primary)
        pending = primary
        self.active = False
        self.book.active = False
        errors = []
        if self._module is not None and self._original is not None:
            try:
                self._module.eager_attention_forward = self._original
            except BaseException as error:
                errors.append(error)
                self._failed_owners.append((self._module, error))
                pending = choose(pending, error, "Native eager restoration", body_primary=body_primary)
        handles, self._handles = self._handles, []
        for owner, remove in handles:
            try:
                if remove is None:
                    owner.remove()
                else:
                    remove()
            except BaseException as error:
                errors.append(error)
                self._failed_owners.append((owner, error))
                pending = choose(pending, error, "Native hook removal", body_primary=body_primary)
        self.entered = False
        self.cleanup_completed = not errors
        if errors:
            self._failed = True
        if pending is not None and pending is not incoming:
            raise pending

    def __enter__(self):
        if self.entered or self._failed:
            raise ValueError("Native observer already entered or cleanup incomplete")
        torch, module = _native_dependencies()
        original = module.eager_attention_forward
        if getattr(original, "_expanded_native_observer", False) or getattr(original, "_strict_native_capture", False):
            raise ValueError("Nested native instrumentation is unsupported")
        self._torch, self._module, self._original = torch, module, original
        self.entered = True
        try:
            for index, layer in enumerate(self.layers):
                if type(layer.self_attn.layer_idx) is not int or layer.self_attn.layer_idx != index:
                    raise ValueError("Native layer indices differ from order")
                for part, norm in (("input", layer.input_layernorm), ("post", layer.post_attention_layernorm),
                                   ("q", layer.self_attn.q_norm), ("k", layer.self_attn.k_norm)):
                    self._register(norm, self._norm_hook(f"{index}.{part}.inverse_sqrt", norm))
                self._register(layer.mlp.act_fn, self._silu_hook(f"{index}.silu", layer.mlp.act_fn))
            norm = self.model.model.norm
            self._register(norm, self._norm_hook("final.inverse_sqrt", norm, last=True))

            def attention(attention_module, query, key, value, attention_mask, scaling, dropout=0., **kwargs):
                if self.active:
                    self._check_binding()
                    if id(attention_module) not in self._targets:
                        raise ObservationError("Native attention belongs to another model")
                    if attention_module.training or dropout != 0:
                        raise ObservationError("Native eager eval attention required")
                    query, key, value = (self._tensor(x) for x in (query, key, value))
                    if any(x.ndim != 4 or x.shape[0] != 1 for x in (query, key, value)):
                        raise ObservationError("Native attention requires batch1 rank4 tensors")
                    sequence = self.book.sequence_length
                    if any(x.shape[-2] != sequence for x in (query, key, value)):
                        raise ObservationError("Full-prefix attention required; no KV cache")
                    if isinstance(scaling, bool) or not math.isfinite(float(scaling)) or float(scaling) <= 0:
                        raise ObservationError("Finite positive native attention scaling required")
                    if sequence > 1 and attention_mask is None:
                        raise ObservationError("Non-singleton context requires causal mask")
                    if attention_mask is not None:
                        mask = self._tensor(attention_mask)[:, :, :, :sequence].detach().cpu().numpy()
                        shape = (1, query.shape[1], sequence, sequence)
                        expanded = np.broadcast_to(mask, shape)
                        allowed = np.broadcast_to(np.tril(np.ones((sequence, sequence), dtype=bool)), shape)
                        if (not np.array_equal(expanded == 0, allowed)
                                or np.any(~allowed & ~((expanded == np.finfo(np.float32).min) | np.isneginf(expanded)))):
                            raise ObservationError("Native mask differs from unpadded causal contract")
                    repeated = module.repeat_kv(key, attention_module.num_key_value_groups)
                    scores = (torch.matmul(query, repeated.transpose(2, 3)) * scaling).detach().cpu().numpy()
                    index = self._targets[id(attention_module)]
                    for query_index in range(sequence):
                        row = scores[..., query_index, :query_index + 1]
                        self.book.observe(f"{index}.softmax.raw_valid", row)
                        # Retain the native float32 NumPy mean/subtract order.
                        self.book.observe(f"{index}.softmax.centered", row - row.mean(axis=-1, keepdims=True))
                return original(attention_module, query, key, value, attention_mask, scaling, dropout, **kwargs)

            attention._expanded_native_observer = True
            self._wrapper = attention
            module.eager_attention_forward = attention
            return self
        except BaseException as error:
            self._restore(error)
            raise

    def begin(self, sequence_length):
        if not self.entered or self.active or self._failed:
            raise ValueError("Installed inactive native observer required")
        self._check_binding()
        if self.model.training:
            raise ValueError("Native model must be in eval mode")
        self.book.begin(sequence_length)
        self.active = True

    def end(self):
        if not self.active:
            raise ValueError("Native observer is not active")
        self.active = False
        self._check_binding()
        return self.book.end()

    def abort(self):
        """Retain a partial invalid context, without removing installed hooks."""
        if not self.active:
            raise ValueError("Only an active native context can be aborted")
        self._check_binding()
        partial = self.book.snapshot()
        partial["complete"] = False
        self.active = False
        self.book.active = False
        return partial

    def __exit__(self, kind, error, traceback):
        self._restore(error)
        return False
