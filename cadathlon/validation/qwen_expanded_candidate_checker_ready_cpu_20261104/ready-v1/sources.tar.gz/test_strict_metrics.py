import json
import numpy as np
import pytest
import strict_metrics as m

@pytest.mark.parametrize('kind,good,bad',[('operator',.04,.06),('block',.04,.06),('logits',.09,.11),('semantic',.9e-5,1.1e-5)])
def test_literal_protocol_limits(kind,good,bad):
    assert m.metric(np.full(13,1+good),np.ones(13),kind)['passed']
    assert not m.metric(np.full(13,1+bad),np.ones(13),kind)['passed']

@pytest.mark.parametrize('actual,expected',[(np.array([np.nan]),np.zeros(1)),(np.array([np.inf]),np.zeros(1)),(np.ones(2),np.ones(1)),(np.array([1j]),np.zeros(1)),(np.array([True]),np.zeros(1)),(np.array([object()]),np.zeros(1)),(np.array([1e308]),np.array([-1e308])),(np.array([1e308]),np.zeros(1)),(np.zeros(0),np.zeros(0))])
def test_bad_and_extreme_metrics_are_strict_json_failures(actual,expected):
    row=m.metric(actual,expected,'operator');assert not row['passed'];json.dumps(row,allow_nan=False)
    if actual.shape==(1,)and actual.dtype.kind=='f'and actual[0]==1e308 and expected[0]==0:
        assert row['max_abs']==1e308 and row['nrmse']is None

def test_scaled_rms_and_floor_are_independent_of_element_count():
    x=np.array([3e200,4e200]);y=np.zeros(2);row=m.metric(x,y,'logits')
    assert row['finite']and np.isclose(row['nrmse'],np.sqrt(12.5)*1e202)
    assert m.metric(np.full(8,.0004),np.zeros(8),'operator')['passed']

def test_full_vocabulary_semantic_absolute_and_top1_gates():
    native=np.zeros((1,151936));native[0,7]=1000.;exact=native.copy()
    assert m.semantic(exact,native)['passed']
    exact[0,0]=.0011;row=m.semantic(exact,native)
    assert row['nrmse']<1e-5 and not row['passed']and row['count']==151936
    native[:]=0.;native[0,7]=1e-8;exact=native.copy();exact[0,8]=2e-8
    assert not m.semantic(exact,native)['passed']

@pytest.mark.parametrize('sequence',[1,8,32])
def test_all421_labels_and_native_layout_shapes(sequence):
    shapes=m.operator_shapes(sequence);assert len(shapes)==421
    assert shapes['0.q.inverse_sqrt']==(1,16,sequence,128)and shapes['0.k.inverse_sqrt']==(1,8,sequence,128)
    assert shapes['27.gated_mlp']==(1,sequence,1024)and shapes['final.inverse_sqrt']==(1,1024)
    capture={'operators':{k:np.broadcast_to(np.float64(1),s)for k,s in shapes.items()},'blocks':[np.broadcast_to(np.float64(1),(1,sequence,1024))for _ in range(28)],'inputs':{}}
    m.capture(capture,sequence)
    capture['operators']['0.q.inverse_sqrt']=np.ones((1,sequence,16,128))
    if sequence!=16:
        with pytest.raises(m.StructuralFailure):m.capture(capture,sequence)

def test_complete_missing_label_is_structural_not_numeric_failure():
    with pytest.raises(m.StructuralFailure):m.capture({'operators':{},'blocks':[],'inputs':{}},1)
    with pytest.raises(m.NonfiniteOutput):m.array(np.array([np.nan]),(1,),label='known')
    with pytest.raises(m.StructuralFailure):m.array(np.array([1j]),(1,),label='dtype')
