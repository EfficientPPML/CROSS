"""One explicit large public proof role; ordinary executable limits stay fixed."""
ASSESSMENT_PATH = 'candidate_proof/selector-assessments.json'
MAX_SOURCE = 8 * 1024 * 1024
MAX_ASSESSMENT = 64 * 1024 * 1024
MAX_SOURCE_TOTAL = 96 * 1024 * 1024


def source_limit(name):
    if type(name) is not str:
        raise ValueError('Exact source member name required')
    return MAX_ASSESSMENT if name == ASSESSMENT_PATH else MAX_SOURCE


def check_source_sizes(sizes):
    if type(sizes) is not dict:
        raise ValueError('Exact source size inventory required')
    total = 0
    for name, size in sizes.items():
        if type(size) is not int or not 0 < size <= source_limit(name):
            raise ValueError('Source member size exceeds its explicit role')
        total += size
        if total > MAX_SOURCE_TOTAL:
            raise ValueError('Combined public source/proof bound exceeded')
    return total
