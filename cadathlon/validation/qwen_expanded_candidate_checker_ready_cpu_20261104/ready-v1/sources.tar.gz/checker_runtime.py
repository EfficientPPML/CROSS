"""Strict candidate context adapter. Actual admission precedes every body read.

ContextAdapters has explicit synthetic seams. execute_candidate supplies only
the frozen production functions; no native intermediate feeds the candidate.
"""
from dataclasses import asdict
import copy,hashlib,json,math
import numpy as np
import arithmetic,reference,observed_reference
import candidate_dispatch as dispatch
from candidate_domains import ObservedArithmetic
from strict_metrics import StructuralFailure,NonfiniteOutput,array,capture,semantic,metric,compare_outputs,operator_shapes
from native_capture import NativeCaptureWithInputs,NativeNonfiniteOutput
from ranges import RangeBook,InvalidInput,NORM_LABELS,SILU_LABELS
from model_runtime import Aggregate,ARCHITECTURE
WORKLOAD=dispatch.workload()

def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def sha(raw):return hashlib.sha256(raw).hexdigest()

def input_inventory(observed,sequence,origin):
    """Count/namespace validation independent of the mutable capture wrappers."""
    if origin not in('native','exact'):raise StructuralFailure('Input origin required')
    if type(observed)is not dict or observed.get('complete')is not True or observed.get('invalid')is not False:
        raise StructuralFailure('Complete valid input observations required')
    for name,wanted in [('sequence_length',sequence),('norm_input_sites',113),('silu_gate_sites',28),('ignored_exact_output_callbacks',0 if origin=='native'else 169)]:
        if type(observed.get(name))is not int or observed[name]!=wanted:raise StructuralFailure('Typed input observation coverage differs')
    counts={name:1 if name=='final.inverse_sqrt'else sequence*(16 if '.q.'in name else 8 if '.k.'in name else 1)for name in NORM_LABELS}
    counts.update({name:sequence*3072 for name in SILU_LABELS})
    counts.update({f'{i}.softmax.{phase}':16*sequence*(sequence+1)//2 for i in range(28)for phase in('raw_valid','centered')})
    rows=observed.get('ranges')
    if type(rows)is not dict or set(rows)!=set(counts):raise StructuralFailure('Exact197 input statistic labels required')
    def stat(row,count,positive=False):
        if type(row)is not dict or set(row)!={'count','minimum','maximum','nonfinite','nonpositive'}:raise StructuralFailure('Exact input statistic schema required')
        if type(row['count'])is not int or row['count']!=count or type(row['nonfinite'])is not int or row['nonfinite']!=0 or type(row['nonpositive'])is not int or not 0<=row['nonpositive']<=count:raise StructuralFailure('Input statistic finite/count mismatch')
        low,high=row['minimum'],row['maximum']
        if any(type(v)is not float or not math.isfinite(v)for v in(low,high))or low>high or positive and(low<=0 or row['nonpositive']):raise StructuralFailure('Finite ordered input statistics required')
    for name,count in counts.items():stat(rows[name],count,name in NORM_LABELS)
    scores=observed.get('score_rows')
    if type(scores)is not dict or set(scores)!={str(i)for i in range(28)}:raise StructuralFailure('Exact28 score-row families required')
    for layer,queries in scores.items():
        if type(queries)is not dict or set(queries)!={str(k)for k in range(1,sequence+1)}:raise StructuralFailure('All causal K rows required')
        for key,row in queries.items():
            k=int(key)
            for name,wanted in [('query',k-1),('key_count',k),('reciprocal_observations',0)]:
                if type(row.get(name))is not int or row[name]!=wanted:raise StructuralFailure('Typed causal-row identity differs')
            if row.get('shape')!=[1,16,k]or any(type(v)is not int for v in row['shape'])or row.get('k1_bypass')is not(k==1):raise StructuralFailure('Causal row shape/bypass differs')
            for phase in('raw_valid','centered'):stat(row[phase],16*k)
            if k==1 and(row['centered']['minimum']!=0. or row['centered']['maximum']!=0.):raise StructuralFailure('K1 centered diagnostic must be zero')
        for phase in('raw_valid','centered'):
            selected=[q[phase]for q in queries.values()]
            derived=dict(count=sum(q['count']for q in selected),minimum=min(q['minimum']for q in selected),maximum=max(q['maximum']for q in selected),nonfinite=0,nonpositive=sum(q['nonpositive']for q in selected))
            if canonical(derived)!=canonical(rows[layer+'.softmax.'+phase]):raise StructuralFailure('Flat score statistics differ from actual K rows')
    return observed

class ContextAdapters:
    def __init__(self,*,native_forward,capture_owner,config,weights,manifest,manifest_sha256,private_output,progress,
                 exact_forward=observed_reference.forward,plain_forward=reference.forward,candidate_forward=arithmetic.approximate_forward):
        if {k:config.get(k)for k in ARCHITECTURE}!=ARCHITECTURE:raise StructuralFailure('Pinned full28 architecture required')
        for k,v in ARCHITECTURE.items():
            if type(config[k])is not type(v):raise StructuralFailure('Exact architecture scalar types required')
        self.forward=native_forward;self.capture=capture_owner;self.config=copy.deepcopy(config);self.weights=weights
        self.manifest=copy.deepcopy(manifest);self.manifest_pin=dispatch.digest(manifest_sha256);self.manifest_binding=canonical(self.manifest)
        self.private=private_output;self.progress=progress;self.exact_forward=exact_forward;self.plain_forward=plain_forward;self.candidate_forward=candidate_forward
        self.native_ranges=Aggregate();self.exact_ranges=Aggregate();self.candidate_ranges={};self.pending=None
        self.native_invariance={};self.exact_invariance={};self.semantic_passes=0;self.candidate_complete=0;self.phase_counts={'native':0,'exact':0,'candidate':0}
    def embeddings(self,prefix):
        # New lookup for each independent path. Never pass a native/reference
        # activation, or the exact branch's mutable embedding array, onward.
        return self.weights['model.embed_tokens.weight'][np.asarray([prefix],dtype=np.int64)].astype(np.float64,copy=True)
    def binding(self,prefix,entry):
        if type(entry)is not dispatch.Entry or type(entry.index)is not int or not 0<=entry.index<len(WORKLOAD):raise StructuralFailure('Exact workload entry required')
        wanted=WORKLOAD[entry.index]
        if any(type(getattr(entry,k))is not type(v)or getattr(entry,k)!=v for k,v in vars(wanted).items()):raise StructuralFailure('Typed workload entry differs')
        if type(prefix)is not tuple or len(prefix)!=entry.length or any(type(t)is not int or not 0<=t<151936 for t in prefix):raise StructuralFailure('Exact actual prefix required')
        return (entry.index,prefix,self.manifest_pin)
    def journal(self,entry,phase,prefix,**record):
        row=dict(entry=asdict(entry),manifest_sha256=self.manifest_pin,token_ids=list(prefix),context_sha256=sha(np.asarray(prefix,dtype='<i8').tobytes()),**record)
        self.private.json(f'{entry.index:04d}-{phase}.json',row)
    def announce(self,entry,phase):
        self.phase_counts[phase]+=1
        self.progress(dict(index=entry.index,kind=entry.kind,sequence_length=entry.length,stage=phase))
    def native(self,prefix,entry):
        self.pending=None;binding=self.binding(prefix,entry);S=len(prefix);self.announce(entry,'native')
        first=S not in self.native_invariance
        if first:self.native_invariance[S]=False
        try:
            bare=array(self.forward(prefix),(1,151936),label='bare native logits').copy()if first else None
            self.capture.begin(S);logits=array(self.forward(prefix),(1,151936),label='native logits').copy();observed=self.capture.end()
            capture(observed,S);input_inventory(observed['inputs'],S,'native')
            if first:
                self.native_invariance[S]=bool(np.array_equal(bare,logits))
                if not self.native_invariance[S]:raise StructuralFailure('Native capture changed actual logits')
        except (InvalidInput,NativeNonfiniteOutput,NonfiniteOutput)as error:
            partial=self.capture.abort()if self.capture.active else None
            self.journal(entry,'native',prefix,status='comparison_invalid',failure_type=type(error).__name__,partial_inputs=partial)
            raise dispatch.InvalidObservation('Known invalid native comparison')from error
        self.native_ranges.add(observed['inputs']);choice=int(logits.argmax())
        self.journal(entry,'native',prefix,status='complete',native_top1=choice,observations=observed['inputs'],observations_sha256=sha(canonical(observed['inputs'])),operator_count=421,block_count=28,all_logits=151936)
        self.pending=dict(binding=binding,phase='native',logits=logits,captured=observed)
        return dispatch.Native(choice)
    def exact(self,prefix,entry,native):
        binding=self.binding(prefix,entry)
        if self.pending is None or self.pending['binding']!=binding or self.pending['phase']!='native':raise StructuralFailure('Exact branch must consume same-prefix native evidence')
        if type(native)is not dispatch.Native or type(native.token)is not int or native.token!=int(self.pending['logits'].argmax()):raise StructuralFailure('Native argmax evidence changed')
        self.announce(entry,'exact');book=RangeBook().begin(len(prefix));first=len(prefix)not in self.exact_invariance
        if first:self.exact_invariance[len(prefix)]=False
        try:
            logits=array(self.exact_forward(self.config,self.weights,self.embeddings(prefix),observe=book.observe),(1,151936),label='exact logits')
            observed=book.end();input_inventory(observed,len(prefix),'exact')
            if first:
                plain=array(self.plain_forward(self.config,self.weights,self.embeddings(prefix)),(1,151936),label='plain exact logits')
                self.exact_invariance[len(prefix)]=bool(np.array_equal(plain,logits))
                if not self.exact_invariance[len(prefix)]:raise StructuralFailure('Exact observation changed reference logits')
            comparison=semantic(logits,self.pending['logits']);choice=int(logits.argmax());self.exact_ranges.add(observed)
            self.journal(entry,'exact',prefix,status='complete'if comparison['passed']else'comparison_invalid',exact_top1=choice,semantic=comparison,observations=observed,observations_sha256=sha(canonical(observed)))
            if comparison['passed']:
                self.semantic_passes+=1;self.pending['phase']='exact'
            else:self.pending=None
            return dispatch.Exact(choice,comparison['passed'])
        except (InvalidInput,NonfiniteOutput)as error:
            self.journal(entry,'exact',prefix,status='comparison_invalid',failure_type=type(error).__name__,partial_inputs=book.snapshot());self.pending=None
            raise dispatch.InvalidObservation('Known invalid exact comparison')from error
    def merge_candidate(self,domains):
        for label,row in domains.items():
            if label not in self.candidate_ranges:self.candidate_ranges[label]=copy.deepcopy(row);continue
            old=self.candidate_ranges[label]
            if canonical(old['domain'])!=canonical(row['domain']):raise StructuralFailure('Candidate declared domain drift')
            for name in('count','below','above','nonfinite'):old[name]+=row[name]
            for name,operation in [('minimum',min),('maximum',max)]:
                values=[v for v in(old[name],row[name])if v is not None];old[name]=operation(values)if values else None
    def candidate(self,prefix,entry):
        binding=self.binding(prefix,entry)
        if self.pending is None or self.pending['binding']!=binding or self.pending['phase']!='exact':raise StructuralFailure('Candidate must start on the same validated prefix')
        if canonical(self.manifest)!=self.manifest_binding:raise StructuralFailure('Frozen manifest changed')
        self.announce(entry,'candidate');engine=ObservedArithmetic(self.manifest,len(prefix));output=None;failure=None
        try:
            try:
                result=self.candidate_forward(self.config,self.weights,self.embeddings(prefix),self.manifest,engine=engine)
                if type(result)is not tuple or len(result)!=4 or result[1]is not engine or result[2]is not engine.blocks or result[3]is not engine.operators:raise StructuralFailure('Returned candidate owners differ')
                output=result[0];array(output.data,(1,151936),label='candidate logits');engine.require_complete()
            except (arithmetic.InvalidCircuit,NonfiniteOutput)as error:
                failure=dict(type=type(error).__name__,label=getattr(error,'label',None),record=getattr(error,'record',None));output=None
            self.merge_candidate(engine.domains)
            op,blocks=compare_outputs(engine.operators,engine.blocks,self.pending['captured'],len(prefix),None if output is None else output.data)
            logits=None if output is None else metric(output.data,self.pending['logits'],'logits')
            numeric=output is not None and all(row['passed']for row in op.values())and all(row['passed']for row in blocks)and logits['passed']
            choice=None if output is None else int(output.data.argmax())
            observed=engine.report()
            self.journal(entry,'candidate',prefix,status='candidate_invalid'if output is None else'complete',candidate_top1=choice,numeric_pass=bool(numeric),domain_pass=output is not None,failure=failure,operator_metrics=op,block_metrics=blocks,full_logit_metric=logits,observations=observed,observations_sha256=sha(canonical(observed)),all_logits=0 if output is None else 151936)
            if output is not None:self.candidate_complete+=1
            return dispatch.Candidate(choice,output is not None,bool(numeric),output is not None,len(op),len(blocks),0 if output is None else 151936)
        finally:self.pending=None
    def run(self,calibration):
        result=dispatch.run_candidate(calibration,manifest_sha256=self.manifest_pin,native=self.native,exact=self.exact,candidate=self.candidate)
        report=result.public_report()
        invariance=set(self.native_invariance)==set(range(1,33))and set(self.exact_invariance)==set(range(1,33))and all(self.native_invariance.values())and all(self.exact_invariance.values())
        report.update(phase_counts=dict(self.phase_counts),semantic_passes=self.semantic_passes,candidate_complete=self.candidate_complete,
            native_invariance_by_length={str(k):v for k,v in self.native_invariance.items()},exact_invariance_by_length={str(k):v for k,v in self.exact_invariance.items()},
            all_length_invariance=invariance,input_ranges=dict(native=self.native_ranges.report(),exact=self.exact_ranges.report(),candidate_propagated=copy.deepcopy(self.candidate_ranges)),
            limits=dict(operator_block_nrmse=.05,full_logit_nrmse=.10,semantic_nrmse=1e-5,semantic_max_abs=.001,nrmse_floor=.01),
            coefficient_selection_performed=False,encrypted_execution=False,validation_inputs_read=False)
        coverage=self.phase_counts==dict(native=3200,exact=3200,candidate=3200)and self.semantic_passes==self.candidate_complete==self.native_ranges.contexts==self.exact_ranges.contexts==3200
        report['complete_measured_context_coverage']=coverage
        report['passed']=report['passed']and invariance and coverage
        measured=sum(row['complete']+row['candidate_invalid']for row in report['by_kind'].values())
        comparisons=self.phase_counts==dict(native=measured,exact=measured,candidate=measured)and self.semantic_passes==self.native_ranges.contexts==self.exact_ranges.contexts==measured
        report['revision_comparison_coverage']=comparisons
        report['revision_eligible_ledger']=report['revision_eligible_ledger']and comparisons and invariance
        report['complete']=report['ledger_complete']
        self.private.json('ledger.json',dict(manifest_sha256=self.manifest_pin,records=[asdict(r)for r in result.records],summary=report))
        return report

def execute_candidate(blobs,reader,private_output,progress):
    # Public admission is always first. Pending candidate metadata must reject
    # before calibration, checkpoint, backend import or constructor access.
    import checker_admission
    binding=checker_admission.require_candidate(blobs)
    import backend_environment
    backend_environment.check()
    from freeze_io import parse,read
    from input_gate import model_assets
    from model_runtime import backend_check
    from candidate_domains import plan
    from cleanup_origin import cleanup_origin,protect_body,choose
    import os,sys,importlib.metadata,gc
    manifest=parse(binding.manifest_bytes)
    if sha(binding.manifest_bytes)!=binding.manifest_sha256:raise StructuralFailure('Admitted manifest bytes differ')
    if type(binding.ordinal)is not int or not 1<=binding.ordinal<=3:raise StructuralFailure('Declared new candidate ordinal required')
    plan(manifest,32) # Complete manifest observation contract before body reads.
    policy=parse(blobs['checker_runtime_policy.json'])
    expected_policy=dict(schema='qwen-expanded-candidate-runtime-policy-v1',cores=[172,173,174,175],torch_threads=4,torch_interop_threads=1,candidate_budget=3,measured_contexts=3200,native_forwards=3232,validation_enabled=False)
    if canonical(policy)!=canonical(expected_policy):
        raise StructuralFailure('Exact preparation runtime policy required')
    if sorted(os.sched_getaffinity(0))!=policy['cores']:raise StructuralFailure('Assigned checker CPU affinity required')
    external=parse(blobs['external_inputs.json']);calibration=external['calibration']
    if binding.calibration_sha256!=calibration['sha256']:raise StructuralFailure('Admitted calibration differs')
    if binding.protocol_sha256!=sha(blobs['protocol.json']):raise StructuralFailure('Admitted expanded protocol differs')
    dependencies=parse(blobs['dependencies.json'])
    installed={name:sys.version if name=='python'else importlib.metadata.version(name)for name in dependencies}
    if installed!=dependencies:raise StructuralFailure('Pinned installed dependencies differ')
    if any(os.environ.get(n)!='1'for n in('HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE','HF_HUB_DISABLE_TELEMETRY'))or any(os.environ.get(n)!='4'for n in('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')):
        raise StructuralFailure('Exact offline four-thread environment required')
    before=backend_check(blobs,read)
    rows=parse(reader(calibration['path'],calibration['sha256'],limit=calibration['bytes']));dispatch.validate_calibration(rows)
    model=weights=adapters=capture_owner=None;primary=None;body=None;report=None
    try:
        with model_assets(blobs)as model_root:
            with backend_environment.import_scope(blobs):
                import torch
                from transformers import Qwen3ForCausalLM
            torch.set_num_threads(4);torch.set_num_interop_threads(1)
            model,loading=Qwen3ForCausalLM.from_pretrained(model_root,local_files_only=True,use_safetensors=True,torch_dtype=torch.float32,attn_implementation='eager',output_loading_info=True)
            if any(loading.get(n)for n in('missing_keys','unexpected_keys','mismatched_keys','error_msgs')):raise StructuralFailure('Exact model loading required')
            model.eval();config=model.config.to_dict()
            if {n:config[n]for n in ARCHITECTURE}!=ARCHITECTURE or model.training or model.config._attn_implementation!='eager':raise StructuralFailure('Pinned eager architecture required')
            if any(p.device.type!='cpu'or p.dtype!=torch.float32 for p in model.parameters()):raise StructuralFailure('CPU float32 native parameters required')
            if model.lm_head.weight.data_ptr()!=model.model.embed_tokens.weight.data_ptr():raise StructuralFailure('Pinned tied vocabulary weight required')
            weights={name:value.detach().numpy().astype(np.float64)for name,value in model.state_dict().items()if name!='lm_head.weight'}
            backend_check(blobs,read,loaded=True);progress(dict(stage='model_loaded',model_loaded=True));calls=dict(started=0,completed=0)
            def native(prefix):
                calls['started']+=1;progress(dict(stage='native_forward_started',native_forward_started=calls['started']))
                with torch.no_grad():
                    result=model(input_ids=torch.tensor([prefix],dtype=torch.long),attention_mask=torch.ones((1,len(prefix)),dtype=torch.long),position_ids=torch.arange(len(prefix))[None,:],use_cache=False).logits[:,-1].detach().numpy().astype(np.float64)
                calls['completed']+=1;progress(dict(stage='native_forward_completed',native_forward_completed=calls['completed']));return result
            with NativeCaptureWithInputs(model)as capture_owner:
                adapters=ContextAdapters(native_forward=native,capture_owner=capture_owner,config=config,weights=weights,manifest=manifest,manifest_sha256=binding.manifest_sha256,private_output=private_output,progress=progress)
                report=adapters.run(rows)
            if capture_owner.cleanup_completed is not True:raise StructuralFailure('Native capture restoration incomplete')
            measured=report['phase_counts']['native']
            expected_calls=measured+len(report['native_invariance_by_length'])
            accounted=(type(measured)is int and calls['started']==calls['completed']==expected_calls
                and 0<=expected_calls<=3232)
            report['native_forward_accounting']=dict(expected=expected_calls,started=calls['started'],completed=calls['completed'],passed=accounted)
            if (report['passed']or report['revision_eligible_ledger'])and not accounted:
                raise StructuralFailure('Native forward accounting differs from complete comparison ledger')
            after=backend_check(blobs,read,loaded=True)
            if after!=before:raise StructuralFailure('Backend source changed during candidate work')
            report.update(model_loaded=True,model_forward=calls['started']>0,native_forward_started=calls['started'],native_forward_completed=calls['completed'],native_capture_cleanup_completed=capture_owner.cleanup_completed,
                backend_sources_before=before,backend_sources_after=after,backend_environment=backend_environment.check(),runtime_policy=policy,installed_dependencies=installed,
                candidate_ordinal=binding.ordinal,initial_report_sha256=binding.initial_report_sha256,selection_proof_sha256=binding.selection_proof_sha256,protocol_sha256=binding.protocol_sha256,calibration_sha256=binding.calibration_sha256,
                native_dtype='float32',exact_candidate_dtype='float64',scope='One frozen candidate on its own fixed3200 calibration workload only; no validation/row0/coefficient selection/HE')
        report['model_asset_postchecks_completed']=True
    except BaseException as error:
        primary=error;body=None if cleanup_origin(error)else protect_body(error);raise
    finally:
        model=weights=adapters=capture_owner=None
        try:gc.collect()
        except BaseException as error:
            selected=choose(primary,error,'candidate model cleanup',body_primary=body)
            if selected is not primary:raise selected
    report['model_cleanup_completed']=True
    return report
