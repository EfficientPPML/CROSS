"""Real successor scopes with fake signals/output; no actual signals or backend."""
from pathlib import Path
import pytest
import checker_process as p
from cleanup_origin import cleanup_origin


@pytest.mark.parametrize('cancel_type',[KeyboardInterrupt,SystemExit])
@pytest.mark.parametrize('body_type',[None,ValueError,OSError,KeyboardInterrupt,SystemExit])
def test_shield_setup_cleanup_origin_and_sticky_genuine_body(monkeypatch,cancel_type,body_type):
    events=[];setup=OSError('synthetic shield setup');cancel=cancel_type('later cleanup')
    body=None if body_type is None else body_type('genuine body')
    class Signal:
        SIG_BLOCK=0;SIG_SETMASK=2;calls=0
        @staticmethod
        def pthread_sigmask(*args):return set()
        @staticmethod
        def getsignal(*args):return None
        @classmethod
        def signal(cls,*args):
            cls.calls+=1
            if cls.calls==4:raise setup
    class Output:
        path='synthetic';owner=(0,1)
        def close(self):events.append('close')
        def json(self,name,report):events.append('publish')
        @classmethod
        def reopen(cls,*args):return cls()
    monkeypatch.setattr(p,'signal',Signal);monkeypatch.setattr(p,'Output',Output)
    monkeypatch.setattr(p,'source_end',lambda *args:events.append('source') or {})
    def action():
        if body is not None:raise body
    def cleanup():events.append('cleanup');raise cancel
    report=dict(passed=True,candidate_validation_admissible=True,failed_attempt_terminal_candidate=True)
    with pytest.raises(BaseException) as found:
        p.supervise(Output(),report,action,[cleanup],Path('/synthetic'),{})
    assert found.value is (body if body is not None else cancel)
    assert cleanup_origin(setup)
    assert all(name in events for name in ('cleanup','source','close','publish'))
    assert report['passed'] is report['cleanup_completed'] is False
    assert report['candidate_validation_admissible'] is report['failed_attempt_terminal_candidate'] is False
