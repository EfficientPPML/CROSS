"""Fixed protocol metrics; pure arrays only, with strict finite JSON results."""
import math
import numpy as np

LIMITS={'operator':.05,'block':.05,'logits':.10,'semantic':1e-5}
FLOOR=.01
VOCABULARY=151936

class StructuralFailure(ValueError):
    """Missing/different capture/schema: infrastructure, never selector evidence."""

class NonfiniteOutput(ValueError):
    """A known invalid numeric output, distinct from structural mismatch."""

def array(value,shape,*,label):
    x=np.asarray(value)
    if x.shape!=tuple(shape)or x.dtype.kind!='f' or not x.size:
        raise StructuralFailure('Real floating exact-shape output required: '+label)
    if not np.isfinite(x).all():raise NonfiniteOutput('Nonfinite output: '+label)
    return x

def metric(actual,expected,kind):
    if kind not in LIMITS:raise ValueError('Fixed protocol metric kind required')
    a,b=np.asarray(actual),np.asarray(expected);shape=a.shape==b.shape
    result=dict(passed=False,finite=False,shape_matches=shape,real_numeric=False,
                count=int(a.size),max_abs=None,nrmse=None,limit=LIMITS[kind],floor=FLOOR)
    if a.dtype.kind not in 'fiu'or b.dtype.kind not in 'fiu':return result
    result['real_numeric']=True
    if not shape or not a.size or not np.isfinite(a).all()or not np.isfinite(b).all():return result
    with np.errstate(all='ignore'):
        a,b=a.astype(np.float64),b.astype(np.float64);d=a-b
        if not np.isfinite(a).all()or not np.isfinite(b).all()or not np.isfinite(d).all():return result
        maximum=float(np.max(abs(d)));scale=float(np.max(abs(b)))
        rms_error=0. if maximum==0. else maximum*float(np.sqrt(np.mean((d/maximum)**2)))
        rms_reference=0. if scale==0. else scale*float(np.sqrt(np.mean((b/scale)**2)))
        normalized=rms_error/max(FLOOR,rms_reference)
    result['max_abs']=maximum
    if not math.isfinite(normalized):return result
    result.update(finite=True,nrmse=normalized,passed=normalized<=LIMITS[kind])
    return result

def semantic(exact,native):
    a=array(exact,(1,VOCABULARY),label='exact logits')
    b=array(native,(1,VOCABULARY),label='native logits')
    result=metric(a,b,'semantic');same=int(a.argmax())==int(b.argmax())
    result.update(top1_match=same,max_abs_limit=.001)
    result['passed']=bool(result['passed']and result['max_abs']<=.001 and same)
    return result

def operator_shapes(sequence):
    if type(sequence)is not int or not 1<=sequence<=32:raise StructuralFailure('Exact sequence1..32 required')
    S=sequence;rows={}
    for layer in range(28):
        p=str(layer)+'.'
        for name,shape in [('input.inverse_sqrt',(1,S,1024)),('q_linear',(1,S,2048)),
                ('k_linear',(1,S,1024)),('v_linear',(1,S,1024)),
                ('q.inverse_sqrt',(1,16,S,128)),('q_rope',(1,16,S,128)),
                ('k.inverse_sqrt',(1,8,S,128)),('k_rope',(1,8,S,128)),
                ('gqa',(1,S,2048)),('output_linear',(1,S,1024)),
                ('post.inverse_sqrt',(1,S,1024)),('gate_linear',(1,S,3072)),
                ('up_linear',(1,S,3072)),('silu',(1,S,3072)),('gated_mlp',(1,S,1024))]:rows[p+name]=shape
    rows['final.inverse_sqrt']=(1,1024)
    return rows

def capture(value,sequence,*,partial=False):
    if type(value)is not dict or set(value)!= {'operators','blocks','inputs'}:
        raise StructuralFailure('Exact capture result schema required')
    operators,blocks=value['operators'],value['blocks'];shapes=operator_shapes(sequence)
    if type(operators)is not dict or type(blocks)is not list or len(blocks)>28:
        raise StructuralFailure('Exact operator/block containers required')
    if (not partial and set(operators)!=set(shapes))or not set(operators)<=set(shapes):
        raise StructuralFailure('Exact421 operator labels required')
    if not partial and len(blocks)!=28:raise StructuralFailure('Exact28 blocks required')
    for label,data in operators.items():array(data,shapes[label],label=label)
    for i,data in enumerate(blocks):array(data,(1,sequence,1024),label='block'+str(i))
    return operators,blocks

def compare_outputs(operators,blocks,native,sequence,logits=None):
    expected_ops,expected_blocks=capture(native,sequence)
    capture(dict(operators=dict(operators),blocks=list(blocks),inputs={}),sequence,partial=logits is None)
    op={label:metric(values,expected_ops[label],'operator')for label,values in operators.items()}
    block=[metric(values,expected_blocks[i],'block')for i,values in enumerate(blocks)]
    return op,block
