"""Public producer admission and calibration-only/model-only borrowed readers.

No model or token body is read at import or by inspect(). Body access is only
through an explicitly invoked Reader/model_assets, after the process grant.
"""
from contextlib import contextmanager
from pathlib import Path
import hashlib
import io
import os
import stat
import tarfile
from freeze_io import read, parse, finish, identity
from cleanup_origin import protect_body, cleanup_origin, choose

ASSETS = ('config.json','generation_config.json','model.safetensors')
BASELINE = '7f6478a6bc710f3d2a370198e075e6ba8b0e55c144d981bca0eed59eaf176333'
PROTOCOL = 'eea8e4b38b4c2719e63a0aa13028150564901305e9e5f1f9d0f2985c821cb70f'
REVISION = 'c1899de289a04d12100db370d81485cdf75e47ca'


def sha(raw): return hashlib.sha256(raw).hexdigest()


def is_digest(value):
    return type(value) is str and len(value)==64 and all(c in '0123456789abcdef' for c in value)


def typed_equal(left,right):
    if type(left) is not type(right):return False
    if type(left) is dict:return set(left)==set(right) and all(typed_equal(left[k],right[k]) for k in left)
    if type(left) is list:return len(left)==len(right) and all(typed_equal(a,b) for a,b in zip(left,right))
    return left==right


def _archive(raw,expected):
    if type(expected) is not dict or len(expected)!=33 or any(not is_digest(h) for h in expected.values()):
        raise ValueError('Exact33 tokenizer source map required')
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as archive:
        rows=archive.getmembers()
        if (len(rows)!=33 or len({r.name for r in rows})!=33 or {r.name for r in rows}!=set(expected) or
            any(not r.isfile() or Path(r.name).is_absolute() or '..' in Path(r.name).parts or
                not 0<=r.size<=8<<20 for r in rows) or sum(r.size for r in rows)>32<<20):
            raise ValueError('Bounded exact producer source archive required')
        if {r.name:sha(archive.extractfile(r).read()) for r in rows}!=expected:
            raise ValueError('Producer source archive bytes differ')


def inspect(blobs):
    """Authenticate only already source-bound PUBLIC blobs; no filesystem IO."""
    external=parse(blobs['external_inputs.json'])
    fields={'schema','calibration','producer','model_root','model_assets','baseline_manifest_sha256','protected_paths'}
    if type(external) is not dict or set(external)!=fields or external['schema']!='qwen-expanded-observer-inputs-v1':
        raise ValueError('Exact observer input contract required')
    cal=external['calibration'];producer=external['producer'];model=parse(blobs['public/model_pins.json'])
    if type(cal) is not dict or set(cal)!={'path','sha256','bytes','identity','parent_identity','mode','parent_mode'}:
        raise ValueError('Exact calibration descriptor required')
    path=Path(cal['path']) if type(cal.get('path')) is str else Path('.')
    if not path.is_absolute() or '..' in path.parts or path.name!='calibration_inputs.json':
        raise ValueError('Fixed calibration-only path required')
    if not is_digest(cal['sha256']) or type(cal['bytes']) is not int or not 0<cal['bytes']<=4<<20:
        raise ValueError('Bounded calibration digest/size required')
    for name in ('identity','parent_identity'):
        if type(cal[name]) is not list or len(cal[name])!=2 or any(type(x) is not int or x<0 for x in cal[name]):
            raise ValueError('Exact calibration ownership identity required')
    if cal['mode']!='0600' or cal['parent_mode']!='0700':raise ValueError('Private calibration permissions required')
    if (type(producer) is not dict or set(producer)!={'protocol_sha256','tokenizer_report_sha256',
        'tokenizer_worker_report_sha256','tokenizer_archive_sha256','tokenizer_source_manifest_sha256',
        'tokenizer_root_review_sha256','tokenizer_grant_sha256'} or any(not is_digest(v) for v in producer.values())):
        raise ValueError('Exact fixed producer pins required')
    mapping={'tokenizer_report_sha256':'tokenizer_report.json','tokenizer_worker_report_sha256':'tokenizer_worker_report.json',
        'tokenizer_archive_sha256':'tokenizer_sources.tar.gz','tokenizer_root_review_sha256':'tokenizer_root_review.json',
        'tokenizer_grant_sha256':'tokenizer_grant.json'}
    for name,file in mapping.items():
        if sha(blobs['public/'+file])!=producer[name]:raise ValueError('Public producer digest differs: '+name)
    if producer['protocol_sha256']!=PROTOCOL or sha(blobs['public/protocol.json'])!=PROTOCOL:
        raise ValueError('Frozen expanded protocol differs')
    if external['baseline_manifest_sha256']!=BASELINE or sha(blobs['public/candidate3_manifest.json'])!=BASELINE:
        raise ValueError('Frozen baseline generator differs')
    parent=parse(blobs['public/tokenizer_report.json']);worker=parse(blobs['public/tokenizer_worker_report.json'])
    review=parse(blobs['public/tokenizer_root_review.json']);grant=parse(blobs['public/tokenizer_grant.json'])
    for record in (parent,worker):
        for flag in ('passed','complete','cleanup_completed','signal_restoration_completed',
            'terminal_after_body_cleanup_and_signal_restoration_attempts',
            'acceptance_requires_independent_exit0_reap_and_exact_report_hash'):
            if record.get(flag) is not True:raise ValueError('Tokenizer terminal flag differs')
        if any(record.get(flag) is not False for flag in ('model_forward','coefficient_selection')) or record.get('audit_denials')!=[]:
            raise ValueError('Tokenizer phase/audit differs')
    if (parent.get('child_reaped') is not True or parent.get('child_group_absent') is not True or
        type(parent.get('child_returncode')) is not int or parent['child_returncode']!=0 or
        not typed_equal(parent.get('worker'),worker) or parent.get('worker_report_sha256')!=producer['tokenizer_worker_report_sha256']):
        raise ValueError('Tokenizer worker/process linkage differs')
    expected=parent.get('source_hashes_start')
    if (parent.get('source_files_unchanged') is not True or expected!=parent.get('source_hashes_end') or
        expected!=worker.get('source_hashes_start') or expected!=worker.get('source_hashes_end') or
        parent.get('source_manifest_sha256')!=producer['tokenizer_source_manifest_sha256'] or
        parent.get('source_archive',{}).get('sha256')!=producer['tokenizer_archive_sha256']):
        raise ValueError('Tokenizer source proof differs')
    _archive(blobs['public/tokenizer_sources.tar.gz'],expected)
    if any(review.get(n) is not True for n in ('passed','source_current_execution_start_end_archive_equal',
        'original288_mapping_and16_seeds_exact','private_directory0700_files0600')):
        raise ValueError('Independent mapping review incomplete')
    outer=review.get('outer',{})
    if (any(outer.get(n) is not True for n in ('outer_completed','collector_absent','child_reaped','child_group_absent')) or
        any(type(outer.get(n)) is not int or outer[n]!=0 for n in ('outer_returncode','child_returncode'))):
        raise ValueError('Independent outer completion missing')
    if (review.get('report_sha256')!=producer['tokenizer_report_sha256'] or outer.get('report_sha256')!=producer['tokenizer_report_sha256'] or
        review.get('source_archive_sha256')!=producer['tokenizer_archive_sha256'] or outer.get('source_archive_sha256')!=producer['tokenizer_archive_sha256'] or
        worker.get('protocol_sha256')!=PROTOCOL or worker.get('grant_sha256')!=producer['tokenizer_grant_sha256'] or
        review.get('grant_sha256')!=producer['tokenizer_grant_sha256']):
        raise ValueError('Independent review links differ')
    description={k:cal[k] for k in ('bytes','identity','mode','sha256')}
    if (not typed_equal(worker.get('private_outputs',{}).get('calibration'),description) or
        not typed_equal(review.get('private_outputs',{}).get('calibration'),description) or
        not typed_equal(review.get('private_root_identity'),cal['parent_identity']) or
        grant.get('private_output')!=str(path.parent)):
        raise ValueError('Calibration producer binding differs')
    if (model.get('revision')!=REVISION or type(external['model_root']) is not str or
        not Path(external['model_root']).is_absolute() or Path(external['model_root']).name!=REVISION or
        external['model_assets']!=list(ASSETS) or any(not is_digest(model['asset_sha256'].get(n)) for n in ASSETS)):
        raise ValueError('Fixed3 model asset contract differs')
    if (type(external['protected_paths']) is not list or not external['protected_paths'] or
        any(type(p) is not str or not Path(p).is_absolute() for p in external['protected_paths']) or
        str(path.parent) not in external['protected_paths']):
        raise ValueError('Protected input trees required')
    return external


def _state(info):return (info.st_dev,info.st_ino,info.st_size,info.st_mtime_ns,info.st_ctime_ns)


def _private_identity(description):
    path=Path(description['path'])
    parent=os.stat(path.parent,follow_symlinks=False);info=os.stat(path,follow_symlinks=False)
    if (not stat.S_ISDIR(parent.st_mode) or not stat.S_ISREG(info.st_mode) or
        identity(parent)!=tuple(description['parent_identity']) or identity(info)!=tuple(description['identity']) or
        stat.S_IMODE(parent.st_mode)!=0o700 or stat.S_IMODE(info.st_mode)!=0o600 or
        parent.st_uid!=os.getuid() or info.st_uid!=os.getuid() or info.st_size!=description['bytes']):
        raise ValueError('Borrowed calibration identity/permissions differ')
    return _state(info)


class Reader:
    def __init__(self,blobs):
        self.description=inspect(blobs)['calibration'];self.loaded=False;self.start=None

    def __call__(self,path,expected,limit=4<<20):
        d=self.description
        if (not isinstance(path,(str,Path)) or os.fspath(path)!=d['path'] or expected!=d['sha256'] or
            type(limit) is not int or not d['bytes']<=limit<=4<<20):
            raise PermissionError('Only authenticated calibration bytes are readable')
        before=_private_identity(d);data=read(d['path'],d['sha256'],limit=limit)
        if _private_identity(d)!=before:raise ValueError('Calibration changed during read')
        if self.start is not None and self.start!=before:raise ValueError('Calibration changed since initial read')
        self.start=before;self.loaded=True
        return data

    def recheck(self):
        if self.loaded:
            d=self.description
            if _private_identity(d)!=self.start:raise ValueError('Calibration changed during observation')
            read(d['path'],d['sha256'],limit=d['bytes'])
            if _private_identity(d)!=self.start:raise ValueError('Calibration changed during final check')


def _stream_hash(path):
    primary=None
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        before=os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or not 0<before.st_size<=8<<30:
            raise ValueError('Bounded regular model asset required')
        hasher=hashlib.sha256();size=0
        while block:=os.read(fd,4<<20):
            size+=len(block)
            if size>before.st_size:raise ValueError('Model asset grew during hashing')
            hasher.update(block)
        after=os.fstat(fd);named=os.stat(path,follow_symlinks=False)
        if (_state(before)!=_state(after) or _state(named)!=_state(before) or
            not stat.S_ISREG(named.st_mode) or size!=before.st_size):
            raise ValueError('Model asset changed during hashing')
        return hasher.hexdigest(),_state(before)
    except BaseException as error:
        primary=protect_body(error);raise
    finally:finish(primary,lambda:os.close(fd))


@contextmanager
def model_assets(blobs):
    contract=inspect(blobs);root=Path(contract['model_root']);pins=parse(blobs['public/model_pins.json'])['asset_sha256']
    before={};primary=None;body=None
    try:
        parent=os.stat(root,follow_symlinks=False)
        if not stat.S_ISDIR(parent.st_mode):raise ValueError('Ordinary fixed model directory required')
        owner=identity(parent)
        for name in ASSETS:
            digest,state=_stream_hash(root/name)
            if digest!=pins[name]:raise ValueError('Model asset digest differs')
            before[name]=state
        yield root
    except BaseException as error:
        primary=error;body=None if cleanup_origin(error) else protect_body(error)
    finally:
        for name,state in before.items():
            try:
                current=os.stat(root,follow_symlinks=False)
                if not stat.S_ISDIR(current.st_mode) or identity(current)!=owner:raise ValueError('Model root replaced')
                digest,after=_stream_hash(root/name)
                if digest!=pins[name] or after!=state:raise ValueError('Model asset changed during observation')
            except BaseException as error:primary=choose(primary,error,'model asset final check',body_primary=body)
        if primary is not None:raise primary
