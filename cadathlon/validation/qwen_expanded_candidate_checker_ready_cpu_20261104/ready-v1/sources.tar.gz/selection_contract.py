"""Grant-capable selection seam; preparation uses synthetic evidence only.

The predecessor mathematical core and its failure histories are unchanged.
Only the separately granted entrypoint may invoke the real publication path.
"""
from admission import InitialAdmission
from initial_proof import InitialSnapshot, authenticate_gate_bounds
from selector import BASELINE_SHA256, canonical, digest, select_synthetic_initial

ACTUAL_COEFFICIENT_SELECTION = False


def prepare_synthetic_selection(base_bytes, snapshot, gate_bounds_bytes):
    if (type(snapshot) is not InitialSnapshot or snapshot.execution_authorized is not False or
            snapshot.binding.execution_authorized is not False):
        raise ValueError('Immutable authenticated snapshot binding required')
    if type(base_bytes) is not bytes or digest(base_bytes) != BASELINE_SHA256:
        raise ValueError('Exact protected candidate3 bytes required')
    gates = authenticate_gate_bounds(gate_bounds_bytes)
    proof = digest(canonical(dict(initial_proof=snapshot.binding.proof_sha256,
        snapshot=snapshot.snapshot_sha256, private_inventory=snapshot.private_inventory_sha256,
        ledger=snapshot.ledger_sha256, gate_bounds=digest(gate_bounds_bytes))))
    admitted = InitialAdmission(snapshot.union_bytes, proof)
    result = select_synthetic_initial(base_bytes, admitted, gates)
    result['input_bindings'] = dict(initial_proof_sha256=snapshot.binding.proof_sha256,
        snapshot_sha256=snapshot.snapshot_sha256, private_inventory_sha256=snapshot.private_inventory_sha256,
        ledger_sha256=snapshot.ledger_sha256, gate_bounds_sha256=digest(gate_bounds_bytes),
        protected_parent_sha256=BASELINE_SHA256)
    result['actual_admission_activated'] = False
    result['actual_coefficient_selection'] = False
    return result


def select_actual(base_bytes, snapshot, gate_bounds_bytes, *, authorization):
    """Entry-owned actual path; callers must separately authenticate root authority."""
    from selection_grant import Authorization
    from initial_proof import parse
    if type(authorization) is not Authorization:
        raise PermissionError('Externally authenticated selection grant required')
    evidence = parse(authorization.evidence_bytes)
    required = {'parent': snapshot.binding.parent_report_sha256,
                'worker': snapshot.binding.worker_report_sha256,
                'source_archive': snapshot.binding.source_archive_sha256,
                'root_review': snapshot.binding.root_review_sha256,
                'reconstruction_script': snapshot.binding.reconstruction_script_sha256,
                'root_reconstruction_outer_receipt': snapshot.binding.root_outer_sha256}
    if any(evidence[name]['sha256'] != pin for name, pin in required.items()):
        raise ValueError('Grant does not bind this admitted initial proof')
    result = prepare_synthetic_selection(base_bytes, snapshot, gate_bounds_bytes)
    candidate = result['candidate']
    candidate.update(schema='qwen-expanded-initial-selection-v1', synthetic_only=False,
        actual_coefficient_selection=True, candidate_ordinal=1, protocol_sha256=snapshot.binding.protocol_sha256,
        initial_parent_report_sha256=snapshot.binding.parent_report_sha256,
        initial_snapshot_sha256=snapshot.snapshot_sha256, selection_grant_sha256=authorization.grant_sha256,
        selector_source_manifest_sha256=authorization.source_manifest_sha256)
    result.update(actual_admission_activated=True, actual_coefficient_selection=True,
        scope='Granted initial-only normalization selection; no candidate model evaluation or HE')
    return result
