from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
import json,os,signal,sys
import pytest
import observer_process as p
import freeze_io
from cleanup_origin import mark_cleanup,cleanup_origin


@contextmanager
def quiet_signals(state=None,shield=False):
    if state is not None:state['restored']=True
    yield


def setup_supervise(tmp_path,monkeypatch):
    monkeypatch.setattr(p,'signals',quiet_signals)
    monkeypatch.setattr(p,'source_end',lambda root,expected:dict(expected))
    output=freeze_io.Output(tmp_path/'out')
    report=dict(passed=True,complete=True,initial_selection_admissible=True)
    return output,report


@pytest.mark.parametrize('body_cls',[ValueError,OSError,KeyboardInterrupt,SystemExit])
@pytest.mark.parametrize('cancel_cls',[KeyboardInterrupt,SystemExit])
def test_supervise_genuine_sticky_body_identity(tmp_path,monkeypatch,body_cls,cancel_cls):
    output,report=setup_supervise(tmp_path,monkeypatch);body=body_cls('genuine');calls=[]
    def action():raise body
    def again():calls.append('same');raise body
    def cancel():calls.append('cancel');raise cancel_cls('later')
    with pytest.raises(body_cls) as found:p.supervise(output,report,action,[again,cancel],tmp_path,{'a':'b'})
    assert found.value is body and calls==['same','cancel']
    assert report['passed'] is False and report['initial_selection_admissible'] is False
    assert report['cleanup_completed'] is False and cleanup_origin(body) is False
    assert json.loads((tmp_path/'out/report.json').read_bytes())['passed'] is False


@pytest.mark.parametrize('cancel_cls',[KeyboardInterrupt,SystemExit])
def test_supervise_cleanup_only_priority(tmp_path,monkeypatch,cancel_cls):
    output,report=setup_supervise(tmp_path,monkeypatch);first=mark_cleanup(OSError('reader close'));later=cancel_cls('outer close')
    def action():raise first
    def cleanup():raise later
    with pytest.raises(cancel_cls) as found:p.supervise(output,report,action,[cleanup],tmp_path,{'a':'b'})
    assert found.value is later and report['initial_selection_admissible'] is False


def test_source_cleanup_failure_blocks_selection(tmp_path,monkeypatch):
    output,report=setup_supervise(tmp_path,monkeypatch)
    monkeypatch.setattr(p,'source_end',lambda *args:(_ for _ in ()).throw(ValueError('drift')))
    with pytest.raises(ValueError):p.supervise(output,report,lambda:None,[],tmp_path,{'a':'b'})
    assert not report['passed'] and report['initial_selection_admissible'] is False


def test_escaped_cleanup_fault_cannot_claim_cleanup_completed(tmp_path,monkeypatch):
    output,report=setup_supervise(tmp_path,monkeypatch)
    failure=mark_cleanup(OSError('inner close failed'))
    def action():raise failure
    with pytest.raises(OSError) as found:p.supervise(output,report,action,[],tmp_path,{'a':'b'})
    assert found.value is failure and report['cleanup_completed'] is False
    assert report['initial_selection_admissible'] is False


def test_cleanup_install_failure_still_attempts_all(tmp_path,monkeypatch):
    output,report=setup_supervise(tmp_path,monkeypatch);calls=[]
    @contextmanager
    def scope(state=None,shield=False):
        if shield:raise OSError('install failed')
        if state is not None:state['restored']=True
        yield
    monkeypatch.setattr(p,'signals',scope)
    with pytest.raises(OSError):p.supervise(output,report,lambda:None,[lambda:calls.append(1),lambda:calls.append(2)],tmp_path,{'a':'b'})
    assert calls==[1,2] and output.fd is None and report['passed'] is False


def test_owned_output_replacement_never_overwrites_foreign(tmp_path,monkeypatch):
    output,report=setup_supervise(tmp_path,monkeypatch);path=Path(output.path);moved=tmp_path/'moved'
    def action():
        path.rename(moved);path.mkdir(mode=0o700);(path/'report.json').write_bytes(b'foreign')
    with pytest.raises(ValueError):p.supervise(output,report,action,[],tmp_path,{'a':'b'})
    assert (path/'report.json').read_bytes()==b'foreign' and not (moved/'report.json').exists()


def test_final_publication_close_error_requires_outer_exit_gate(tmp_path,monkeypatch):
    output,report=setup_supervise(tmp_path,monkeypatch);original=freeze_io.Output.close
    def close(self,primary=None):
        original(self,primary)
        if self is not output:raise OSError('last publication close')
    monkeypatch.setattr(freeze_io.Output,'close',close)
    with pytest.raises(OSError):p.supervise(output,report,lambda:None,[],tmp_path,{'a':'b'})
    # A terminal file cannot certify its own final close. Caller exit0 is mandatory.
    assert json.loads((tmp_path/'out/report.json').read_bytes())['acceptance_requires_independent_exit0_reap_and_exact_report_hash'] is True


def fake_signal(monkeypatch):
    original={n:object() for n in p.SIGNALS};handlers=dict(original);mask=set();calls=[]
    def masking(how,values):
        prior=set(mask);calls.append(('mask',how,tuple(values)))
        if how==signal.SIG_BLOCK:mask.update(values)
        else:mask.clear();mask.update(values)
        return prior
    monkeypatch.setattr(p.signal,'getsignal',lambda n:handlers[n])
    monkeypatch.setattr(p.signal,'signal',lambda n,h:handlers.__setitem__(n,h))
    monkeypatch.setattr(p.signal,'pthread_sigmask',masking)
    return original,handlers,mask,calls


def test_single_fire_termination_restores_all_handlers_masks(monkeypatch):
    old,handlers,mask,calls=fake_signal(monkeypatch);state={}
    with pytest.raises(KeyboardInterrupt):
        with p.signals(state):
            handler=handlers[p.SIGNALS[0]]
            try:handler(p.SIGNALS[0],None)
            except KeyboardInterrupt:
                handler(p.SIGNALS[0],None)
                raise
    assert handlers==old and mask==set() and state['restored'] is True


def test_deferred_cleanup_cancel_restores_then_raises(monkeypatch):
    old,handlers,mask,calls=fake_signal(monkeypatch);state={}
    with pytest.raises(KeyboardInterrupt):
        with p.signals(state,shield=True):
            handlers[p.SIGNALS[0]](p.SIGNALS[0],None)
    assert handlers==old and mask==set() and state['restored'] is False


def test_signal_setter_postmutation_failure_restores_original(monkeypatch):
    old,handlers,mask,calls=fake_signal(monkeypatch);failed=False;state={}
    def setter(n,h):
        nonlocal failed
        handlers[n]=h
        if not failed:failed=True;raise OSError('mutated setter')
    monkeypatch.setattr(p.signal,'signal',setter)
    with pytest.raises(OSError):
        with p.signals(state):pytest.fail('body entered after setup error')
    assert handlers==old and mask==set()


def test_postmutation_mask_failure_restores_queried_mask(monkeypatch):
    old,handlers,mask,calls=fake_signal(monkeypatch);real=p.signal.pthread_sigmask;failed=False
    def block(how,values):
        nonlocal failed
        result=real(how,values)
        if values and how==signal.SIG_BLOCK and not failed:failed=True;raise OSError('mutated mask')
        return result
    monkeypatch.setattr(p.signal,'pthread_sigmask',block)
    with pytest.raises(OSError):
        with p.signals():pytest.fail('body entered')
    assert handlers==old and mask==set()


def test_child_environment_sanitized(monkeypatch):
    for k in ('JAX_PLATFORMS','XLA_FLAGS','TPU_NAME','PYTHONPATH','PYTHONHOME','PYTHONOPTIMIZE'):monkeypatch.setenv(k,'poison')
    result=p.child_environment()
    assert all(k not in result for k in ('JAX_PLATFORMS','XLA_FLAGS','TPU_NAME','PYTHONPATH','PYTHONHOME','PYTHONOPTIMIZE'))
    assert result['HF_HUB_OFFLINE']==result['TRANSFORMERS_OFFLINE']==result['HF_HUB_DISABLE_TELEMETRY']=='1'
    assert result['OMP_NUM_THREADS']==result['OPENBLAS_NUM_THREADS']==result['MKL_NUM_THREADS']=='4'


def test_retire_exited_leader_signals_remaining_group(monkeypatch):
    class Child:
        pid=123;returncode=0
        def poll(self):return 0
        def wait(self,timeout=None):calls.append('wait');return 0
    calls=[];state={'empty':False}
    monkeypatch.setattr(p,'group_absent',lambda pid:state['empty'])
    def kill(pid,sig):calls.append(('signal',sig));state['empty']=True
    monkeypatch.setattr(p.os,'killpg',kill)
    p.retire(Child())
    assert calls==[('signal',signal.SIGTERM),'wait']
