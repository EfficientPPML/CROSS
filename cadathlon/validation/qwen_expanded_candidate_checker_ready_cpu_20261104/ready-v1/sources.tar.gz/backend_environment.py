"""Explicit CPU PyTorch backend selection, checked before backend import."""
import os

REQUIRED = {
    'USE_TF': '0', 'USE_FLAX': '0', 'USE_TORCH': '1',
    'USE_TORCH_XLA': '0', 'FORCE_TF_AVAILABLE': '0',
}

def check():
    actual = {name: os.environ.get(name) for name in REQUIRED}
    if actual != REQUIRED:
        raise ValueError('Explicit PyTorch-only backend environment required')
    return actual


def _sources(blobs):
    import hashlib
    from freeze_io import read, parse
    pins=parse(blobs['import_sources.json'])
    if set(pins)!={'urllib3.util.connection','torch._dynamo.trace_rules','transformers.integrations.flex_attention'}:
        raise ValueError('Exact optional import-probe source required')
    result={}
    for name,pin in pins.items():
        if hashlib.sha256(blobs[pin['snapshot']]).hexdigest()!=pin['sha256']:
            raise ValueError('Import-probe source snapshot differs')
        result[name]=hashlib.sha256(read(pin['path'],pin['sha256'],limit=1<<20)).hexdigest()
    return result


from contextlib import contextmanager
@contextmanager
def import_scope(blobs):
    """Disable only urllib3's optional IPv6 bind probe during offline imports.

    socket operations remain audit-denied. The original stdlib flag is restored
    before any model construction; imported urllib3 keeps HAS_IPV6=False.
    """
    import socket
    import importlib.util
    from cleanup_origin import cleanup_origin, protect_body, choose
    check()
    before=_sources(blobs)
    original=socket.has_ipv6
    original_find_spec=importlib.util.find_spec
    unavailable=frozenset(('jax','jaxlib','jaxite_word','tensorflow','flax','torch_xla'))
    state=dict(source_hashes_before=before,ipv6_probe_disabled=True,restored=False,
        find_spec_restored=False,forbidden_discovery_queries={})
    def discovery(name,package=None):
        if isinstance(name,str) and name.split('.')[0] in unavailable:
            root=name.split('.')[0]
            counts=state['forbidden_discovery_queries'];counts[root]=counts.get(root,0)+1
            return None
        return original_find_spec(name,package)
    primary=body=None
    try:
        socket.has_ipv6=False
        importlib.util.find_spec=discovery
        yield state
    except BaseException as error:
        primary=error
        body=None if cleanup_origin(error) else protect_body(error)
        raise
    finally:
        selected=primary
        try:
            state['source_hashes_after']=_sources(blobs)
            if state['source_hashes_after']!=before:raise ValueError('Import source changed')
        except BaseException as error:selected=choose(selected,error,'import-probe source recheck',body_primary=body)
        try:
            importlib.util.find_spec=original_find_spec
            state['find_spec_restored']=True
        except BaseException as error:selected=choose(selected,error,'restore discovery function',body_primary=body)
        try:
            socket.has_ipv6=original
            state['restored']=True
        except BaseException as error:selected=choose(selected,error,'restore optional IPv6 flag',body_primary=body)
        if selected is not None and selected is not primary:raise selected
