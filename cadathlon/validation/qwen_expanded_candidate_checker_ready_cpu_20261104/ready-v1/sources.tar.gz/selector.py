"""Pure initial-only selector core; no file access or actual-selection entrypoint."""
from decimal import Decimal
from fractions import Fraction as F
import copy, hashlib, json, math
import numpy as np
import certificate, numeric, select_rules, newton_certificate

BASELINE_SHA256='7f6478a6bc710f3d2a370198e075e6ba8b0e55c144d981bca0eed59eaf176333'
LADDER=(16,32,64,128,256,512)
TARGET=1e-6
EPSILON=1e-6
NORMS=tuple(f'{i}.{site}.inverse_sqrt' for i in range(28) for site in ('input','post','q','k'))+('final.inverse_sqrt',)
ACTUAL_COEFFICIENT_SELECTION=False

def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def digest(raw):return hashlib.sha256(raw).hexdigest()
def finite_float(value):return type(value)is float and math.isfinite(value)

def uniform_domain(minimum,maximum,epsilon=EPSILON):
    if any(not finite_float(x)for x in(minimum,maximum,epsilon))or epsilon!=EPSILON or not epsilon<=minimum<=maximum:
        raise ValueError('finite typed initial variance interval and pinned epsilon required')
    base=[max(epsilon,.8*minimum),1.2*maximum]
    expanded=[max(epsilon,base[0]/4),base[1]*4]
    if not all(math.isfinite(x)and x>0 for x in expanded)or expanded[0]>=expanded[1]:
        raise ValueError('unsupported expanded variance interval')
    return dict(base_domain=base,domain=expanded)

def newton_grid(rule):
    a,b=rule['domain'];x=np.unique(np.concatenate((np.linspace(a,b,2049),np.geomspace(a,b,2049))))
    with np.errstate(all='ignore'):
        y=numeric.rsqrt(x,rule);error=y/(1/np.sqrt(x))-1
        finite=bool(np.isfinite(y).all()and np.isfinite(error).all())
        maximum=float(np.max(abs(error)))if finite else None
    return dict(points=len(x),finite=finite,max_relative_error=maximum,passed=finite and maximum<=TARGET)

def newton_fallback(domain):
    if not __debug__:raise RuntimeError('Assertions required by pinned certificate verifier')
    # Recompute the rounded affine and first passing directed certificate count.
    rule=numeric.rsqrt_contract(domain,TARGET)
    if type(rule['iterations'])is not int or not 1<=rule['iterations']<=64:raise ValueError('unsupported Newton count')
    cert=newton_certificate.check_certificate(rule)
    grid=newton_grid(rule)
    if cert['verified']is not True or grid['passed']is not True:raise ValueError('new Newton fallback failed')
    return dict(kind='inverse_sqrt',method='newton',**rule),dict(kind='rounded_first_affine_newton',**cert,
        relative=rule['final_relative_error_bound'],minimal_count_scope='first count satisfying frozen directed residual-bound recurrence'),grid

class SelectionFailure(ValueError):
    def __init__(self,stage,attempts):
        super().__init__("Unsupported selection stage: "+stage)
        self.stage=stage
        self.attempts=tuple(copy.deepcopy(attempts))

def select_interval(domain):
    if type(domain)is not list or len(domain)!=2 or any(not finite_float(x)for x in domain)or not 0<domain[0]<domain[1]:
        raise ValueError('finite typed positive interval required')
    attempts=[]
    for degree in LADDER:
        try:
            candidate=select_rules.rule(domain,degree)
            # A failed/nonfinite generation is unsupported rather than a silent skip.
            if len(candidate['evaluation_coefficients'])!=degree+1 or not all(finite_float(c)for c in candidate['evaluation_coefficients']):
                raise ValueError('unsupported polynomial coefficients')
            cert=certificate.certify(candidate);grid=select_rules.grid_check(candidate)
        except Exception as error:
            attempts.append(dict(degree=degree,selected=False,unsupported=True,error_type=type(error).__name__))
            raise SelectionFailure('polynomial',attempts)from error
        selected=cert['certified']is True and grid['passed']is True
        attempts.append(dict(degree=degree,rule=copy.deepcopy(candidate),certificate=cert,binary64_diagnostic=grid,selected=selected))
        if selected:return dict(rule=candidate,certificate=cert,binary64_diagnostic=grid,attempts=attempts)
    try:chosen,cert,grid=newton_fallback(domain)
    except Exception as error:
        attempts.append(dict(method='newton',selected=False,unsupported=True,error_type=type(error).__name__))
        raise SelectionFailure('newton',attempts)from error
    return dict(rule=chosen,certificate=cert,binary64_diagnostic=grid,attempts=attempts)

def protected(manifest):
    return dict(nonlinear={k:v for k,v in manifest['nonlinear'].items()if k not in NORMS},
        **{k:manifest[k]for k in('softmax','exp','initial_reciprocal','reciprocal_by_keys')})

def relative_bound(row):
    cert=row['certificate']
    return certificate.unpack(cert['relative'])if row['rule']['method']=='polynomial'else F(Decimal(cert['relative']))

def protected_checks(base,union,assessments,gate_bounds):
    if set(gate_bounds)!=set(map(str,range(28))):raise ValueError('all28 public gate bounds required')
    rows={}
    for i in range(28):
        name=str(i);silu=base['nonlinear'][f'{i}.silu']['domain'];center=base['softmax'][name]['centered_domain']
        gate=gate_bounds[name]['native_gate_upper']
        if not finite_float(gate)or gate<=0:raise ValueError('positive exact binary64 public gate bound required')
        bound=F(9,8)*(1+relative_bound(assessments[f'{i}.post.inverse_sqrt']))*F(gate)
        radius=-(-bound.numerator//bound.denominator)
        observed_silu=union[f'{i}.silu'];observed_score=union[f'{i}.softmax.centered']
        rows[name]=dict(required_conditional_radius=radius,unchanged_silu_domain=silu,
            radius_covered=silu[0]<=-radius and radius<=silu[1],
            observed_silu_covered=silu[0]<=observed_silu['minimum']<=observed_silu['maximum']<=silu[1],
            observed_centered_scores_covered=center[0]<=observed_score['minimum']<=observed_score['maximum']<=center[1])
    return rows

def select_synthetic_initial(base_bytes,admitted,gate_bounds):
    """Synthetic preparation seam. No IO; never publishes a usable real candidate."""
    if digest(base_bytes)!=BASELINE_SHA256:raise ValueError('exact candidate3 bytes required')
    from admission import InitialAdmission
    if type(admitted)is not InitialAdmission or admitted.scope!='synthetic_preparation_only':
        raise ValueError('synthetic admitted initial observation required')
    base=json.loads(base_bytes);union=json.loads(admitted.union_bytes)
    if set(k for k in base['nonlinear']if k.endswith('.inverse_sqrt'))!=set(NORMS):raise ValueError('exact113 norm inventory required')
    # Do not inherit old norm hashes, source pins, candidate index or depth metadata.
    candidate={k:copy.deepcopy(base[k])for k in('nonlinear','softmax','exp','initial_reciprocal','reciprocal_by_keys','depth_scope','error_scope')};assessments={}
    # Every site runs the identical policy. No historical norm rule/count lookup.
    for name in NORMS:
        row=union[name]
        try:interval=uniform_domain(row['minimum'],row['maximum'])
        except Exception as cause:
            error=SelectionFailure('domain',[]);error.site=name;error.completed_assessments=copy.deepcopy(assessments)
            raise error from cause
        try:result=select_interval(interval['domain'])
        except SelectionFailure as error:
            error.site=name;error.completed_assessments=copy.deepcopy(assessments)
            raise
        assessments[name]=dict(**interval,**result)
        candidate['nonlinear'][name]=result['rule']
    checks=protected_checks(base,union,assessments,gate_bounds)
    if canonical(protected(candidate))!=canonical(protected(base)):raise ValueError('protected rules changed')
    supported=all(all(row[k]is True for k in('radius_covered','observed_silu_covered','observed_centered_scores_covered'))for row in checks.values())
    candidate.update(schema='qwen-expanded-initial-synthetic-selection-v1',parent_manifest_sha256=BASELINE_SHA256,
        candidate_index=1,synthetic_only=True,actual_coefficient_selection=False,initial_admission_sha256=admitted.proof_sha256,
        selection='Initial native/exact union only; uniform binary64 base expansion then factor4; first certified balanced ladder candidate, otherwise newly certified minimal-count Newton; protected rules unchanged.',
        selection_policy=dict(epsilon=EPSILON,degree_ladder=list(LADDER),uniform_relative_target=TARGET,grid_linear=2049,grid_geometric=2049,max_newton_iterations=64),
        all_norm_sites_supported=True,protected_rules_supported=supported,
        all_silu_sites_supported=all(row['radius_covered']and row['observed_silu_covered']for row in checks.values()),
        all_centered_softmax_sites_supported=all(row['observed_centered_scores_covered']for row in checks.values()),
        depth_by_sequence={str(S):select_rules.depths(candidate,S)for S in range(1,33)})
    return dict(candidate=candidate,assessments=assessments,protected_checks=checks,
        passed=supported,actual_coefficient_selection=False,model_or_HE_executed=False,
        scope='Synthetic core exercise only; no actual selection grant or freeze claim')

def actual_selection(*args,**kwargs):
    raise RuntimeError('Actual coefficient selection is disabled in this preparation')
