"""Freeze and check complete attention-tile ideal assembly without HE."""
from pathlib import Path
import argparse
import hashlib
import io
import json
import os
import subprocess
import sys
import tarfile
import time

HERE = Path(__file__).resolve().parent


def sources():
    paths = sorted(set(HERE.rglob('*.py')) | {HERE/n for n in ('source_origin.json', 'p60_profile_and_refresh.json')})
    return {str(p.relative_to(HERE)): p.read_bytes() for p in paths}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(exist_ok=False)
    started = time.monotonic()
    raw = sources()
    before = {name: sha(data) for name, data in raw.items()}
    with tarfile.open(args.output/'sources.tar.gz', 'w:gz') as archive:
        for name, data in raw.items():
            info = tarfile.TarInfo(name)
            info.size = len(data)
            archive.addfile(info, io.BytesIO(data))
    with (args.output/'tests.log').open('w') as log:
        child = subprocess.run([sys.executable, '-m', 'pytest', '-q', 'test_routing.py', 'test_attention_tile.py'],
            cwd=HERE, env=dict(os.environ, PYTEST_DISABLE_PLUGIN_AUTOLOAD='1'), stdout=log, stderr=subprocess.STDOUT)
    after = {name: sha(data) for name, data in sources().items()}
    with tarfile.open(args.output/'sources.tar.gz') as archive:
        members = archive.getmembers()
        assert len(members) == len({m.name for m in members}) == len(before)
        assert all(m.isfile() for m in members)
        archived = {m.name: sha(archive.extractfile(m).read()) for m in members}
    report = dict(passed=child.returncode == 0 and before == after == archived,
                  scope=__doc__, tests_exit_code=child.returncode, source_hashes_before=before,
                  source_hashes_after=after, source_files_unchanged=before == after,
                  source_archive_verified=before == archived,
                  source_archive_sha256=sha((args.output/'sources.tar.gz').read_bytes()),
                  elapsed_s=time.monotonic()-started,
                  limitations=['Projected synthetic Q/K/V vectors; no pretrained projection or nonlinear softmax.',
                               'Actual binary64 metadata equations with NumPy payload doubles; no CKKS noise or encrypted result.',
                               'The owner has no refresh, file-stage integration, key generation or codecs.'])
    (args.output/'report.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k: v for k, v in report.items() if not isinstance(v, (dict, list))}))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
