"""Public RMS repair feasibility; no replacement candidate or model evaluation."""
from fractions import Fraction as F
from decimal import Decimal,localcontext,ROUND_CEILING
from pathlib import Path
import hashlib,io,json,math,tarfile,time
HERE=Path(__file__).resolve().parent
TARGET=F(1,10**6)
INPUT_PINS={
 'inputs/outer_domains.json':'5fb9e98bd0baaaf9f6591fa8842752c114cc50877f8abc880b69311d141f5fa8',
 'inputs/candidate2_manifest.json':'0af45a8fc6d13b9d429ee1af2311b2cb6ac0aa4cde02eca56478472762482489',
 'inputs/arithmetic.py':'9689b843b4ec2d0a0ef724dbdca7a516e9a4f23da83f83af5571da13380e9a6f',
 'inputs/numeric.py':'5a3a39324133ae52cf4990d9fa48a6e593920e83e6114179b2d9be622bf8b6ce',
 'inputs/learned_normalization_bounds.json':'b4c6ff1b48404dc264fc88b3707b788a456eeda9679f3bc904eefc669ee8f27d',
}


def decimal_upper(x):
    with localcontext() as c:
        c.prec=160;c.rounding=ROUND_CEILING
        return Decimal(x.numerator)/Decimal(x.denominator)



def dyadic(power):return F(1<<power) if power>=0 else F(1,1<<-power)


def upper(x):
    y=float(x)
    return math.nextafter(y,math.inf) if F(y)<x else y


def record(x):return dict(numerator=str(x.numerator),denominator=str(x.denominator),upper_binary64=upper(x))


def certificate(a,b):
    """Symbolic exact-dyadic seed rule only; no candidate coefficient manifest.

    y0=2^-k with4^k>=b, M=1024,z=y/M,w=(1-x*y²)/4.
    Directed recurrence bounds all x in[a,b] under exact-real operations.
    """
    a,b=F(a),F(b)
    if not 0<a<=b:raise ValueError('positive ordered interval required')
    k=0
    while dyadic(2*k)<b:k+=1
    while dyadic(2*(k-1))>=b:k-=1
    seed_square=dyadic(-2*k)
    gap=a*seed_square
    assert 0<gap<=1 and b*seed_square<=1 and a*1024**2>=1
    R0=1-gap
    with localcontext() as c:
        c.prec=160;c.rounding=ROUND_CEILING
        R=Decimal(R0.numerator)/Decimal(R0.denominator);limit=Decimal(TARGET.numerator)/Decimal(TARGET.denominator)
        bounds=[]
        for n in range(1,1000):
            R=R*R*(3+R)/4
            relative=decimal_upper(F(R)/(2-F(R))) # Exact denominator avoids a directed-subtraction ambiguity.
            bounds.append(str(R))
            if relative<=limit:break
        else:raise ValueError('unsupported planning iteration count')
    w0=F(1,4)-gap/4
    # Diagnostic only: it demonstrates why the exact-real proof cannot be
    # silently transferred to even binary64 tracked-state evaluation.
    rounded_w0=.25-float(a)*float(seed_square)/4
    z=float(dyadic(-k))/1024;w=rounded_w0
    for _ in range(n):z,w=z*(1+2*w),w*w*(3+4*w)
    true_z=1/(1024*math.sqrt(float(a)))
    return dict(seed_exponent_rule_k=k,iterations=n,first_residual_gap=record(gap),
                first_scaled_residual_gap=record(gap/4),initial_residual_upper=record(R0),
                exact_real_residual_bounds=bounds,final_relative_error_upper=str(relative),
                static_original_newton_depth=4*n-3,
                tracked_unaligned_symbolic_depth=2*n+1,
                tracked_aligned_state_depth=3*n+1,complete_rms_aligned_depth=3*n+5,
                ciphertext_products_inverse=3*n-1,weighted_operations_inverse=4*n,
                scaled_inverse_upper=1.0,
                scaled_inverse_bound_premise=a*1024**2>=1,
                binary64_lower_endpoint_diagnostic=dict(initial_w_rounded_to_fixed_point=rounded_w0==.25,
                    initial_w=rounded_w0,final_relative_error=abs(z/true_z-1),passes_1e_6=abs(z/true_z-1)<=1e-6),
                coefficient_selection=False,certificate_scope='Exact dyadic public seed rule and exact-real updates only; not floating/CKKS/refresh accuracy.')


def level_schedule(iterations,*,variance_level,refresh_capacity,trace=False):
    """Real three-level aligned macro with explicit two-state refresh events.

    w0 public affine consumes1. Each update computes w² and3+4w in
    parallel, product then real unit alignment:3levels. z*(1+2w) also
    gets a real unit alignment. z1 instead uses its actual public affine.
    Reserve4statelevels so the final feature product/learned affine leave2.
    """
    if type(iterations)is not int or iterations<1 or variance_level<8 or refresh_capacity<7:raise ValueError('positive supported public schedule')
    w=variance_level-1;z=None;events=[];steps=[];feature=variance_level+2
    for i in range(iterations):
        if w<7 or (z is not None and z<7):
            if w<2 or (z is not None and z<2):raise AssertionError('refresh input reserve lost')
            events.append(dict(before_update=i+1,w_input=w,z_input=z,ciphertext_refresh_calls=1+(z is not None)))
            w=refresh_capacity
            if z is not None:z=refresh_capacity
        old_w=w;old_z=z
        w_square=w-1;w_correction=w-1;w_product=min(w_square,w_correction)-1;w=w_product-1
        if z is None:z=old_w-1
        else:z=min(z,old_w-1)-2 # correction affine + CT product + real alignment
        assert min(w,z)>=4
        steps.append(dict(update=i+1,w_input=old_w,z_input=old_z,w_output=w,z_output=z))
    product=min(feature,z)-1;output=product-1
    assert output>=2
    result=dict(variance_level=variance_level,original_feature_level=feature,refresh_capacity=refresh_capacity,
                state_refresh_calls=sum(x['ciphertext_refresh_calls'] for x in events),refresh_boundaries=len(events),
                final_w_level=w,final_z_level=z,final_feature_product_level=product,final_norm_output_level=output,
                final_continuation_reserve=2,events=events,
                assumptions='Each genuine two-input-state refresh returns the declared capacity and preserves required error/correlation; these assumptions are not proved.')
    if trace:result['updates']=steps
    return result


def reciprocal_recheck(rule):
    a,b=map(F,rule['domain']);w=F(rule['rounded_first_weight']);bias=F(rule['rounded_first_bias'])
    points=[a,b];vertex=-bias/(2*w)
    if a<=vertex<=b:points.append(vertex)
    assert min(w*a+bias,w*b+bias)>0
    R=max(abs(1-x*(w*x+bias)) for x in points)
    assert R<1 and rule['iterations']>=2
    with localcontext() as c:
        c.prec=160;c.rounding=ROUND_CEILING;r=Decimal(R.numerator)/Decimal(R.denominator)
        for _ in range(rule['iterations']-1):r=r*r
    return dict(iterations=rule['iterations'],domain=rule['domain'],first_exact_residual_abs=record(R),
                final_residual_upper=str(r),nonnegative_final_residual=True,passes_1e_12=r<=Decimal('1e-12'))


def softmax_premises(manifest):
    coeff=list(map(F,manifest['exp']['evaluation_coefficients']))
    assert manifest['exp']['domain']==[-.5,.5] and manifest['exp']['degree']==8 and manifest['exp']['strategy']=='power'
    # Actual t=2x public affine is exact. Compare the frozen power coefficients
    # with the degree8 Taylor series for exp(t/2); remainder uses exp(.5)<2.
    difference=sum((abs(c-F(1,2**i*math.factorial(i))) for i,c in enumerate(coeff)),F())
    remainder=F(2,2**9*math.factorial(9));E=difference+remainder
    taylor_upper=sum((F(1,2**i*math.factorial(i)) for i in range(9)),F())+remainder
    assert taylor_upper<F(5,3)
    lower=F(3,5)-E;high=F(5,3)+E
    assert F(1,2)<lower<high<2
    checks={'initial':reciprocal_recheck(manifest['initial_reciprocal'])}
    for K in range(1,33):checks[str(K)]=reciprocal_recheck(manifest['reciprocal_by_keys'][str(K)])
    beta={str(K):record(K*F(1./K)) for K in range(1,33)}
    mass_checks={}
    for K in range(1,33):
        factor=K*F(1./K);low=factor*(1-F(1,10**12));high_mass=factor
        squared_lower=low**2/K;squared_upper=high_mass**2
        assert squared_lower>=F(1,2*K) and squared_upper<=2
        assert (1-F(1,10**12))**2/K>=F(1,2*K)
        mass_checks[str(K)]=dict(first_mass_lower=record(low),first_mass_upper=record(high_mass),
            first_squared_denominator_lower=record(squared_lower),first_squared_denominator_upper=record(squared_upper),
            broad_domain_contains_all_first_and_later_squared_denominators=True)
    assert all(x['passes_1e_12'] for x in checks.values())
    return dict(exp_uniform_abs_error=record(E),exp_positive_lower=record(lower),exp_upper=record(high),
                reciprocal_checks=checks,initial_mass_rounding_factor=beta,mass_checks=mass_checks,
                statement='Given current centered score/exp domains and exact-real shared-square denominators, all initial probabilities are positive; broad [.5/K,2] denominators and current rounded-affine certificates imply final row mass in[1-eps,1]. Five or six frozen squarings are at least one, so initial binary64 1/K mass perturbation does not persist.',
                excludes='Later binary64 operations, CKKS/refresh error, centered-score-domain validity, approximate-input variance and norm output obligations.')


def main():
    started=time.monotonic();out=HERE/'public-v1';out.mkdir(exist_ok=False)
    files={str(p.relative_to(HERE)):p for p in HERE.rglob('*') if p.is_file() and p.suffix in ('.py','.json','.md') and out not in p.parents and '.pytest_cache' not in p.parts and '__pycache__' not in p.parts}
    before={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in files.items()}
    with tarfile.open(out/'sources.tar.gz','w:gz') as t:
        for n,p in files.items():b=p.read_bytes();i=tarfile.TarInfo(n);i.size=len(b);t.addfile(i,io.BytesIO(b))
    outer=json.loads((HERE/'inputs/outer_domains.json').read_text());manifest=json.loads((HERE/'inputs/candidate2_manifest.json').read_text());learned=json.loads((HERE/'inputs/learned_normalization_bounds.json').read_text())
    assert all(before.get(name)==digest for name,digest in INPUT_PINS.items())
    assert outer['passed'] and outer['sites_count']==113 and learned['passed']
    rows={}
    for label,site in outer['sites'].items():
        a=F(*map(int,site['lower_fraction']));b=F(*map(int,site['upper_fraction']));row=certificate(a,b)
        row['domain']=dict(lower=record(a),upper=record(b));row['schedules']={}
        for cap in (25,28,29,31):
            for v in (47,cap-2):row['schedules'][f'capacity{cap}_variance{v}']=level_schedule(row['iterations'],variance_level=v,refresh_capacity=cap)
        rows[label]=row
    score=[];delta=F(1,10**6)
    # sqrt128 is enclosed outward by squaring the chosen binary64 endpoint.
    root=math.sqrt(128.)
    while F(root)**2<128:root=math.nextafter(root,math.inf)
    for layer in range(28):
        prefix=f'qwen:model.layers.{layer}.self_attn.'
        q=F(learned['normalizations'][prefix+'q_norm.weight']['gamma_max_abs'])
        k=F(learned['normalizations'][prefix+'k_norm.weight']['gamma_max_abs'])
        dot=F(root)*q*k*(1+delta)**2
        centered=2*dot*F(31,32);m=0
        while dyadic(m)<2*centered:m+=1
        existing=manifest['softmax'][str(layer)]
        score.append(dict(layer=layer,K32_public_centered_abs_upper=record(centered),
                          frozen_centered_domain=existing['centered_domain'],frozen_squarings=existing['squarings'],
                          worst_case_power_of_two_divisions_for_exp_half_interval=m,
                          premise='Exact unitary RoPE, uniform1e-6normrelativeerrors and Cauchy/gamma-max envelopes; no actual floating/CKKS score or changed coefficients.'))
    conditions=softmax_premises(manifest)
    after={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in files.items()};assert before==after
    report=dict(passed=True,scope=__doc__,candidate2_sha256=before['inputs/candidate2_manifest.json'],sites=rows,
                summary=dict(sites=113,minimum_updates=min(r['iterations'] for r in rows.values()),maximum_updates=max(r['iterations'] for r in rows.values()),
                    minimum_aligned_depth=min(r['tracked_aligned_state_depth'] for r in rows.values()),maximum_aligned_depth=max(r['tracked_aligned_state_depth'] for r in rows.values()),
                    binary64_initial_fixed_point_sites=sum(r['binary64_lower_endpoint_diagnostic']['initial_w_rounded_to_fixed_point'] for r in rows.values()),
                    binary64_lower_endpoint_failures=sum(not r['binary64_lower_endpoint_diagnostic']['passes_1e_6'] for r in rows.values()),
                    C25_fresh47_refresh_call_min=min(r['schedules']['capacity25_variance47']['state_refresh_calls'] for r in rows.values()),
                    C25_fresh47_refresh_call_max=max(r['schedules']['capacity25_variance47']['state_refresh_calls'] for r in rows.values()),
                    C25_warm23_refresh_call_min=min(r['schedules']['capacity25_variance23']['state_refresh_calls'] for r in rows.values()),
                    C25_warm23_refresh_call_max=max(r['schedules']['capacity25_variance23']['state_refresh_calls'] for r in rows.values())),
                softmax_premises=conditions,public_score_domain_gap=score,
                source_hashes_before=before,source_hashes_after=after,source_files_unchanged=True,
                source_archive_sha256=hashlib.sha256((out/'sources.tar.gz').read_bytes()).hexdigest(),elapsed_s=time.monotonic()-started,
                model_evaluated=False,coefficient_selection=False,HE_executed=False,
                uniform_exact_real_convergence_certified=True,uniform_floating_or_HE_repair_certified=False,
                limits=['No fresh/held-out inputs or model outputs read. Existing frozen candidate bytes are inputs only.',
                        'A symbolic dyadic seed rule was analyzed; no replacement manifest or executable HE inverse was selected.',
                        'Native outer domains do not automatically cover approximate trajectories.',
                        'Three-level state macros include real scale alignment; omitted-alignment two-level depth is only a prospective lower-cost design requiring metadata proof.',
                        'Refresh counts are exact for the stated public scheduler, not latency estimates or proof that the state error/correlation survives refresh.'])
    with tarfile.open(out/'sources.tar.gz') as t:
        ms=t.getmembers();assert len(ms)==len({m.name for m in ms})==len(before) and all(m.isfile() for m in ms)
        assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in ms}==before
    (out/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps(report['summary'],indent=2))

if __name__=='__main__':main()
