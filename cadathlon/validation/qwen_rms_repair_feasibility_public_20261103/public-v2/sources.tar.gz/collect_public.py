"""Source-bound pure-public checks; does not initialize any numerical backend."""
from pathlib import Path
import hashlib,json,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'source-bound-v2'
OUT.mkdir(exist_ok=False)
def inventory():
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.rglob('*')
        if p.is_file() and p.suffix in ('.py','.json','.md') and not any(part.startswith('public-v') or part.startswith('source-bound-') for part in p.relative_to(ROOT).parts[:-1]) and '.pytest_cache' not in p.parts and '__pycache__' not in p.parts}
started=time.monotonic();before=inventory();reports=[]
for name,cmd in [('tests',[sys.executable,'-m','pytest','-q','test_plan.py']),('plan',[sys.executable,'plan.py'])]:
    with (OUT/(name+'.log')).open('w') as log:
        result=subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=False)
    reports.append(dict(name=name,command=cmd,returncode=result.returncode))
    if result.returncode:break
after=inventory()
result=dict(passed=all(x['returncode']==0 for x in reports) and len(reports)==2 and before==after,
            commands=reports,source_hashes_before=before,source_hashes_after=after,source_files_unchanged=before==after,
            elapsed_s=time.monotonic()-started,scope='Pure public tests and interval/depth planning only; no model, token input, HE, JAX or TPU.')
(OUT/'report.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in result.items() if not k.startswith('source_hashes')},indent=2))
raise SystemExit(0 if result['passed'] else 1)
