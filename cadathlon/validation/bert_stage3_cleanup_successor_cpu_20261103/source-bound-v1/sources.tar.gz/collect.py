"""Source-bound cleanup regression collection; no model/backend imports."""
from pathlib import Path
import hashlib
import io
import json
import os
import subprocess
import sys
import tarfile
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
SOURCES = ('candidate/cleanup.py', 'before/cleanup.py', 'test_cleanup.py',
           'signal_probe.py', 'collect.py')


def hashes():
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in SOURCES}


def verify(path, expected):
    with tarfile.open(path) as tar:
        members = tar.getmembers()
        assert len(members) == len(expected) == len({m.name for m in members})
        assert all(m.isfile() for m in members)
        assert {m.name: hashlib.sha256(tar.extractfile(m).read()).hexdigest()
                for m in members} == expected


def main():
    output = ROOT / sys.argv[1]
    output.mkdir(exist_ok=False)
    start = time.monotonic()
    before = hashes()
    report = dict(passed=False, scope='Isolated cleanup helper; mocked setters and fresh single-thread real-signal subprocesses only. No process-wide signal atomicity or model/HE claim.',
                  source_hashes_before=before, cpu_affinity=sorted(os.sched_getaffinity(0)),
                  python=sys.version, errors=[])
    try:
        with tarfile.open(output / 'sources.tar.gz', 'w:gz') as tar:
            for name in SOURCES:
                raw = (ROOT / name).read_bytes()
                member = tarfile.TarInfo(name);member.size = len(raw)
                tar.addfile(member, io.BytesIO(raw))
        verify(output / 'sources.tar.gz', before)
        with (output / 'tests.log').open('wb') as log:
            result = subprocess.run([sys.executable, '-m', 'pytest', '-q', str(ROOT / 'test_cleanup.py'),
                                     '--tb=short', '--junitxml=' + str(output / 'tests.xml')],
                                    stdout=log, stderr=subprocess.STDOUT,
                                    env={**os.environ, 'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1',
                                         'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1'})
        report['exit_code'] = result.returncode
        tree = ET.parse(output / 'tests.xml').getroot()
        report['tests'] = {key: sum(int(s.attrib.get(key, 0)) for s in tree)
                           for key in ('tests', 'failures', 'errors', 'skipped')}
        report['passed'] = result.returncode == 0 and report['tests'] == dict(tests=30, failures=0, errors=0, skipped=0)
    except BaseException as error:
        report['errors'].append(dict(type=type(error).__name__, message=str(error)))
        raise
    finally:
        report['source_hashes_after'] = hashes()
        report['source_files_unchanged'] = before == report['source_hashes_after']
        verify(output / 'sources.tar.gz', before)
        report['source_archive_verified'] = True
        report['source_archive_sha256'] = hashlib.sha256((output / 'sources.tar.gz').read_bytes()).hexdigest()
        report['elapsed_s'] = time.monotonic() - start
        report['passed'] = report['passed'] and report['source_files_unchanged'] and not report['errors']
        (output / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({k: report[k] for k in ('passed', 'tests', 'elapsed_s', 'source_archive_sha256')}))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
