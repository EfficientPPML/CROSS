"""Single-case actual signal-scope probe; only fabricated engine resources."""
import json,os,signal,sys,threading
from pathlib import Path
from types import SimpleNamespace as NS
HERE=Path(__file__).parent
sys.path[:0]=[str(HERE),str(HERE/'runtime/stage')]
import numpy # Native workers exist before the actual signal scope starts.
from cleanup import termination_signals
import full_model_engine as engine
import engine_prepared_owners as p
from test_engine_prepared import Arithmetic,Rotation,Loader

def run(phase):
    events=[];ctx=NS(secret_key=None,parameters={},_param_cache=NS(secret_key=None,coef_maps={1:object(),64:object()}))
    loader=Loader(ctx,events);handle=NS(ctx=ctx,prepared_arithmetic=loader.create)
    p._types=lambda:(Loader,Arithmetic,Rotation)
    signs=(signal.SIGINT,signal.SIGTERM,signal.SIGHUP);before={s:signal.getsignal(s)for s in signs}
    beforemask=signal.pthread_sigmask(signal.SIG_BLOCK,());real_set=signal.signal;outer={};injected=[]
    class Linear:
        def __init__(self,c,layout,**kw):self.arithmetic=kw.pop('arithmetic_factory')(c,**kw)
    class Refresh:
        def __init__(self,c,**kw):
            self.evaluator=Arithmetic(c,object(),events)
            def clear(**kw):
                events.append('refreshclear')
                if phase=='cleanup'and not injected:
                    injected.append('cleanup');os.kill(os.getpid(),signal.SIGHUP)
            self.compiled_primitives=tuple(NS(clear=clear)for _ in range(5))
    engine._dependencies=lambda:(lambda c:NS(close=lambda:events.append('providerclose')),Arithmetic,Linear,lambda n:n,Refresh,object,lambda *a:None)
    def setter(signum,handler):
        result=real_set(signum,handler)
        if phase in ('restoration','body-and-restoration')and signum==signal.SIGHUP and handler is outer.get(signum)and 'restoration'not in injected:
            injected.append('restoration');os.kill(os.getpid(),signal.SIGHUP)
        return result
    error=None
    try:
        with termination_signals():
            outer.update({s:signal.getsignal(s)for s in signs});signal.signal=setter
            with engine.server_engine(ctx,manifest_bytes=b'fixed',prepared_handle=handle):
                if phase=='body-and-restoration':
                    injected.append('body');os.kill(os.getpid(),signal.SIGTERM)
    except BaseException as caught:error=caught
    finally:signal.signal=real_set
    now=signal.pthread_sigmask(signal.SIG_BLOCK,());restored=all(signal.getsignal(s)is before[s]for s in signs)
    proof=dict(scope='actual single-fire signal scope with preexisting NumPy native threads; mocked engine resources only',
        phase=phase,operation_passed=False,error_type=type(error).__name__ if error else None,
        error_exit_code=error.code if isinstance(error,SystemExit)else(130 if isinstance(error,KeyboardInterrupt)else 1),
        native_thread_count=len(list(Path('/proc/self/task').iterdir())),main_tid=threading.get_native_id(),
        injected=injected,refresh_clear_count=events.count('refreshclear'),provider_closed='providerclose'in events,
        original_prepared_owners_closed=len(loader.created)==2 and all(a.rotation.closed for a in loader.created),
        handler_state_restored=restored,main_mask_restored=now==beforemask,
        loader_lease_still_owned=loader._active,
        limitation='finite samples, no process-wide atomicity claim; actual engine arithmetic/context not run')
    proof['validation_passed']=bool(error is not None and proof['native_thread_count']>1 and proof['provider_closed']and proof['original_prepared_owners_closed']and proof['refresh_clear_count']==5 and restored and now==beforemask)
    # Restore test-process state even if the observed engine restoration failed.
    for s,h in before.items():real_set(s,h)
    signal.pthread_sigmask(signal.SIG_SETMASK,beforemask)
    return proof
if __name__=='__main__':
    report=run(sys.argv[1]);Path(sys.argv[2]).write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    raise SystemExit(report['error_exit_code']or 1)
