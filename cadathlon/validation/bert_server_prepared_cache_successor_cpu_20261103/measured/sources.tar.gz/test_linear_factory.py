"""Execute actual constructors/clear hooks with lightweight public owners."""
import ast
import sys
from pathlib import Path
from types import SimpleNamespace as NS
import pytest
import encrypted_streaming_linear as linear
from encrypted_chained_streaming_linear import ChainedStreamingLinear
HERE=Path(__file__).parent
COMMON=HERE/'joined/checkout/cadathlon/common'

@pytest.fixture
def configured(monkeypatch):
    calls=[]
    class Arithmetic:
        def __init__(self,ctx,**options):self.ctx=ctx;calls.append((self,ctx,options))
    monkeypatch.setitem(sys.modules,'encrypted_packed_qwen',NS(CompiledArithmetic=Arithmetic))
    ctx=NS(num_slots=65536,degree=131072,_param_cache=NS(batch=1))
    return ctx,Arithmetic,calls

@pytest.mark.parametrize('owner',[linear.StreamingLinear,ChainedStreamingLinear])
def test_actual_default_constructor_still_ordinary(configured,owner):
    ctx,A,calls=configured
    result=owner(ctx,linear.RowTileLayout(65536))
    assert type(result.arithmetic)is A and calls==[(result.arithmetic,ctx,dict(low_memory=True,preserve_dispatch_cache=False))]

@pytest.mark.parametrize('owner',[linear.StreamingLinear,ChainedStreamingLinear])
def test_actual_optional_factory_precedes_first_arithmetic(configured,owner):
    ctx,A,calls=configured;seen=[]
    def factory(context,**options):
        assert not calls;seen.append(context);return A(context,**options)
    result=owner(ctx,linear.RowTileLayout(65536),low_memory=True,preserve_dispatch_cache=True,arithmetic_factory=factory)
    assert seen==[ctx] and type(result.arithmetic)is A and len(calls)==1

@pytest.mark.parametrize('bad',['not_callable','foreign_context','wrong_type','bounded'])
def test_factory_contract_rejected(configured,bad):
    ctx,A,calls=configured
    if bad=='not_callable':f=17
    elif bad=='foreign_context':f=lambda *a,**kw:A(object(),**kw)
    elif bad=='wrong_type':f=lambda *a,**kw:object()
    else:
        def f(*a,**kw):
            v=A(ctx,**kw);v.declare_bound=lambda *a:None;return v
    with pytest.raises((ValueError,TypeError)):
        ChainedStreamingLinear(ctx,linear.RowTileLayout(65536),arithmetic_factory=f)


def actual_arithmetic(events):
    # Actual method bodies/zero-argument super semantics, fabricated payloads.
    base_tree=ast.parse((COMMON/'encrypted_polynomial.py').read_text())
    base=next(n for n in base_tree.body if isinstance(n,ast.ClassDef) and n.name=='EncryptedPolynomialEvaluator')
    methods=[n for n in base.body if isinstance(n,ast.FunctionDef) and n.name in ('_prepare','checkpoint')]
    class Base:
        def __init__(self,ctx,**kw):self.ctx=ctx;self.low_memory=kw['low_memory'];self._active_level=None;self.progress=None
        def _clear_working_caches(self):events.append('baseclear')
        def _finish(self,v):events.append('finish');return v
    namespace={};exec(compile(ast.Module(body=methods,type_ignores=[]),'actual-polynomial-methods','exec'),namespace)
    for name in ('_prepare','checkpoint'):setattr(Base,name,namespace[name])
    class Rotation:
        def __init__(self,ctx):self.entries=[];self.fail=None
        def clear(self):
            events.append('rotationclear')
            if self.fail:raise self.fail
            self.entries.clear()
    tree=ast.parse((COMMON/'encrypted_packed_qwen.py').read_text())
    node=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='CompiledArithmetic')
    namespace=dict(EncryptedPolynomialEvaluator=Base,CompiledRotation=Rotation)
    exec(compile(ast.Module(body=[node],type_ignores=[]),'actual-compiled-arithmetic','exec'),namespace)
    return namespace['CompiledArithmetic'](object(),low_memory=True,preserve_dispatch_cache=True)


def test_actual_level_and_checkpoint_clears_remain_in_force():
    events=[];a=actual_arithmetic(events);a.rotation.entries.append(object());a._prepare(49)
    assert events==['rotationclear','baseclear'] and not a.rotation.entries
    events.clear();a.rotation.entries.append(object());a._prepare(49)
    assert not events and a.rotation.entries
    a._prepare(48);assert events==['rotationclear','baseclear'] and not a.rotation.entries
    events.clear();a.rotation.entries.append(object());token=object()
    assert a.checkpoint(token,'phase')is token and a._active_level is None
    assert events==['finish','rotationclear','baseclear'] and not a.rotation.entries


def test_actual_uncertain_barrier_prevents_downstream_cache_clear():
    events=[];a=actual_arithmetic(events);error=OSError('readiness unknown');a.rotation.fail=error
    with pytest.raises(OSError) as caught:a._prepare(49)
    assert caught.value is error and events==['rotationclear'] and a._active_level is None
