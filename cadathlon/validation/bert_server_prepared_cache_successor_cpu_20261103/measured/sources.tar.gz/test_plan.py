import ast,json,hashlib
from pathlib import Path
import pytest
import plan
HERE=Path(__file__).parent

@pytest.mark.parametrize('level,entry',[(49,956825600),(48,940048384),(25,277348352),(24,268959744),(0,17301504)])
def test_public_shape_accounting(level,entry):
    row=plan.entry_bytes(level,degree=131072,q_count=100,p_count=14,dnum=8)
    assert row['one_entry_bytes']==entry
    assert 2*entry<=2<<30


def test_full_profile_caps_and_exclusions():
    p=plan.build()
    assert len(p['logical_bytes_by_level'])==50 and p['all_largest_entries_fit']
    assert p['logical_bytes_by_level'][49]['two_entries_two_owners_bytes']==3827302400
    assert p['logical_bytes_by_level'][25]['two_entries_two_owners_bytes']==1109393408
    assert p['aggregate_logical_byte_cap']==4<<30 and p['refresh_prepared_cache']is False
    assert len(p['exclusions'])==7


def test_only_constructor_changed_in_streamed_linear_math():
    rel='joined/checkout/cadathlon/common/encrypted_streaming_linear.py'
    before=ast.parse((HERE/'baseline/encrypted_streaming_linear.py').read_text())
    after=ast.parse((HERE/rel).read_text())
    for tree in (before,after):
        cls=next(n for n in tree.body if isinstance(n,ast.ClassDef)and n.name=='StreamingLinear')
        cls.body=[n for n in cls.body if not(isinstance(n,ast.FunctionDef)and n.name=='__init__')]
    assert ast.dump(before,include_attributes=False)==ast.dump(after,include_attributes=False)


def test_parity_closure_is_unchanged_except_explicit_two_seams():
    manifest=json.loads((HERE/'prepared_parent_manifest.json').read_bytes())
    changed=[n for n,h in manifest.items()if hashlib.sha256((HERE/n).read_bytes()).hexdigest()!=h]
    assert set(changed)=={'runtime/stage/full_model_engine.py','joined/checkout/cadathlon/common/encrypted_streaming_linear.py'}
    assert len(manifest)==231
