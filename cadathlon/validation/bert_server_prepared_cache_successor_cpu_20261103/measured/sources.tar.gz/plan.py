"""Public logical prepared-key byte accounting; no backend/context imports."""
import hashlib,json,math
from pathlib import Path
HERE=Path(__file__).parent
PROFILE=HERE/'runtime/stage/server_inputs/p60_profile_and_refresh.json'

def entry_bytes(level,*,degree,q_count,p_count,dnum,composite_degree=2):
    if any(type(v)is not int or v<1 for v in (degree,q_count,p_count,dnum,composite_degree)):
        raise ValueError('positive exact public integers required')
    if type(level)is not int or level<0 or composite_degree*(level+1)>q_count:
        raise ValueError('public level outside profile')
    q=composite_degree*(level+1);alpha=math.ceil(q_count/dnum);digits=math.ceil(q/alpha)
    # Two uint32 key operands, one int32 degree-wide coefficient map.
    return dict(level=level,q_count=q,p_count=p_count,active_digits=digits,
        key_pair_bytes=2*digits*degree*(q+p_count)*4,coefficient_map_logical_bytes=degree*4,
        one_entry_bytes=2*digits*degree*(q+p_count)*4+degree*4)

def build():
    raw=PROFILE.read_bytes();p=json.loads(raw)['profile']
    assert (p['degree'],p['depth'],p['dnum'],len(p['q']),len(p['p']))==(131072,49,8,100,14)
    rows=[entry_bytes(i,degree=p['degree'],q_count=len(p['q']),p_count=len(p['p']),dnum=p['dnum'])for i in range(50)]
    for r in rows:r.update(two_entries_one_owner_bytes=2*r['one_entry_bytes'],two_entries_two_owners_bytes=4*r['one_entry_bytes'])
    return dict(scope='Public logical accounting and ownership plan only; no full-engine HE/performance claim',
        profile_sha256=hashlib.sha256(raw).hexdigest(),degree=p['degree'],q_count=len(p['q']),p_count=len(p['p']),dnum=p['dnum'],alpha=13,
        roles=['graph','linear'],max_entries_per_owner=2,max_logical_bytes_per_owner=2<<30,
        aggregate_logical_byte_cap=4<<30,refresh_prepared_cache=False,logical_bytes_by_level=rows,
        raw_public_npy_bytes=125380363136,all_largest_entries_fit=max(r['two_entries_one_owner_bytes']for r in rows)<=2<<30,
        exclusions=['authenticated master key mappings and retained full backing','mmap virtual size, resident pages and page cache','conversion temporaries and in-flight arrays','ciphertexts and retained graph outputs','ordinary refresh key/NTT/compiled controls','JAX executables, compiler workspace and allocator reservation','other nonrotation arithmetic controls'],
        cache_policy='Any requested rotation may occupy the two-entry LRU; keys1/64 are not an exclusive allowlist. Each logical entry charges its map bytes even when physical backing is shared.',
        clear_policy='Existing low-memory level transitions/checkpoints clear each prepared owner. Original retirement methods run before NTT/provider disposal; authenticated loader registration remains outermost.',
        compatible_bsgs='Create prepared arithmetic before child BSGS owners bind helper identities. No postconstruction replacement, no grouped/hoisted rotation, no reordering or rescale movement.',
        remaining='Actual file handler remains ordinary; explicit load_server_prepared plus server_engine(prepared_handle=handle) is the reviewed opt-in seam. No genuine full-engine run yet.')
if __name__=='__main__':print(json.dumps(build(),sort_keys=True,indent=2))
