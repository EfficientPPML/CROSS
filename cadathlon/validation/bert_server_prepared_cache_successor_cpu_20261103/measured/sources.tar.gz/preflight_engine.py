"""Source-bound public/mock engine proof; never opens external key/model stores."""
import argparse,hashlib,json,os,signal,subprocess,sys,tarfile,time
from pathlib import Path
import xml.etree.ElementTree as ET
from cleanup import termination_signals
HERE=Path(__file__).resolve().parent
NEW=('prepared_parent_manifest.json','provenance.json','DESIGN.md','public_plan.json','plan.py','preflight_engine.py','conftest.py',
 'runtime/stage/engine_prepared_owners.py','baseline/full_model_engine.py','baseline/encrypted_streaming_linear.py',
 'test_engine_prepared.py','test_linear_factory.py','test_plan.py','test_full_model_engine.py','test_cleanup_regressions.py','test_mask_capture.py','test_signal_installation.py',
 'native_signal_case.py','test_native_signal_wrapper.py','thread_mask_probe.py')
GROUPS=(('engine',('test_full_model_engine.py','test_cleanup_regressions.py','test_mask_capture.py','test_signal_installation.py'),37),
 ('prepared',('test_engine_prepared.py','test_linear_factory.py','test_plan.py'),49),
 ('native-wrapper',('test_native_signal_wrapper.py',),9))
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def sources():return {n:digest(HERE/n)for n in sorted(set(json.loads((HERE/'prepared_parent_manifest.json').read_bytes()))|set(NEW))}
def write(p,value):p.write_text(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n')
def run(output):
    output=Path(output).resolve();output.mkdir(exist_ok=False);started=time.monotonic()
    report=dict(scope='source-bound mocked full-engine prepared-cache construction/lifecycle, no HE/model/key/payload reads',passed=False,groups=[],started_children=[],pid=os.getpid(),actual_HE=False,source_hashes_before=sources())
    write(output/'report.json',report)
    try:
        with tarfile.open(output/'sources.tar.gz','w:gz')as archive:
            for n in report['source_hashes_before']:archive.add(HERE/n,arcname=n)
        report['source_archive_sha256']=digest(output/'sources.tar.gz')
        with tarfile.open(output/'sources.tar.gz','r:gz')as archive:
            archived={m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest()for m in archive.getmembers()if m.isfile()}
        report['source_archive_verified']=archived==report['source_hashes_before']
        if not report['source_archive_verified']:raise ValueError('source archive differs')
        for name,tests,count in GROUPS:
            env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',JAX_PLATFORMS='cpu',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',SIGNAL_EVIDENCE_DIR=str(output/'signal-cases'))
            with (output/(name+'.log')).open('w')as log:
                process=subprocess.Popen([sys.executable,'-m','pytest','--rootdir='+str(HERE),'--confcutdir='+str(HERE),'-q',*tests,'--junitxml='+str(output/(name+'.xml'))],cwd=HERE,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                child=dict(pid=process.pid,reaped=False,returncode=None);report['started_children'].append(child)
                try:
                    code=process.wait();child.update(reaped=True,returncode=code)
                except BaseException as primary:
                    try:
                        try:os.killpg(process.pid,signal.SIGTERM)
                        except ProcessLookupError:pass
                        try:process.wait(timeout=30)
                        except subprocess.TimeoutExpired:
                            os.killpg(process.pid,signal.SIGKILL);process.wait()
                        child.update(reaped=True,returncode=process.returncode)
                    except BaseException as cleanup:primary.add_note('child cleanup: '+type(cleanup).__name__)
                    raise
            root=ET.parse(output/(name+'.xml')).getroot();cases=list(root.iter('testcase'))
            errors=sum(len(c.findall(t))for c in cases for t in ('failure','error','skipped'))
            item=dict(name=name,pid=process.pid,returncode=code,reaped=True,tests=len(cases),bad=errors,passed=code==0 and len(cases)==count and errors==0)
            report['groups'].append(item);write(output/'report.json',report)
            if not item['passed']:raise ValueError('focused group failed: '+name)
        report['public_plan']=json.loads((HERE/'public_plan.json').read_bytes())
        report['passed']=True
    except BaseException as error:
        report['error']=dict(type=type(error).__name__,message=str(error));raise
    finally:
        active=sys.exception()
        try:
            report['source_hashes_after']=sources();report['source_files_unchanged']=report['source_hashes_before']==report['source_hashes_after']
            report['source_archive_unchanged']=digest(output/'sources.tar.gz')==report.get('source_archive_sha256') if (output/'sources.tar.gz').exists() else False
            report['passed']=report['passed']and report['source_files_unchanged']and report.get('source_archive_verified',False)and report['source_archive_unchanged']
            report['elapsed_seconds']=time.monotonic()-started;report['all_started_children_reaped']=all(g['reaped']for g in report['started_children'])
            write(output/'report.json',report)
        except BaseException as failure:
            if active is not None:active.add_note('final evidence publication failed: '+type(failure).__name__)
            else:raise
    return report
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('output');args=parser.parse_args()
    with termination_signals():
        result=run(args.output)
    print(json.dumps(dict(passed=result['passed'],sources=len(result['source_hashes_before']),groups=result['groups'])))
    raise SystemExit(0 if result['passed']else 1)
