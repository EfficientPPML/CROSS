from pathlib import Path
import sys
HERE=Path(__file__).parent
sys.path[:0]=[str(HERE/'runtime/stage'),str(HERE/'joined/checkout/cadathlon/common')]
