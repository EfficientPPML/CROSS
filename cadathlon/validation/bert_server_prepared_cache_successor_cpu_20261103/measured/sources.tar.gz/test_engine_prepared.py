from pathlib import Path
from types import SimpleNamespace as NS
import sys
import pytest
HERE=Path(__file__).parent
sys.path[:0]=[str(HERE/'runtime/stage')]
import engine_prepared_owners as p,full_model_engine as engine

class Rotation:
    def __init__(self,ctx,lease,events):
        self.ctx=ctx;self._lease=lease;self._max_entries=2;self._max_bytes=2<<30;self.events=events;self._failed=None;self.closed=False
    def clear(self,*,executables=False):
        self.events.append(('clearrotation',id(self),executables))
        if self._failed:raise self._failed
    def close(self):self.clear(executables=True);self.closed=True
class Arithmetic:
    def __init__(self,ctx,lease,events):
        self.ctx=ctx;self.rotation=Rotation(ctx,lease,events);self.events=events;self._plaintext_multiply=self._rescale=self._multiplication_compiler=None
    def _clear_working_caches(self):self.events.append(('cleararith',id(self)));self.rotation.clear()
class Loader:
    def __init__(self,ctx,events):
        self._context=ctx;self._active=True;self._failure=None;self.events=events;self.lease=NS(_check=lambda:events.append('leasecheck'));self.created=[]
    def create(self,**kwargs):
        assert kwargs==dict(max_entries=2,max_bytes=2<<30,low_memory=True,preserve_dispatch_cache=True)
        self.events.append('create');a=Arithmetic(self._context,self.lease,self.events);self.created.append(a);return a
@pytest.fixture
def rig(monkeypatch):
    ctx=NS(secret_key=None,parameters={'secret_key':None},_param_cache=NS(secret_key=None,coef_maps={1:object(),64:object()}));events=[];loader=Loader(ctx,events)
    handle=NS(ctx=ctx,prepared_arithmetic=loader.create)
    monkeypatch.setattr(p,'_types',lambda:(Loader,Arithmetic,Rotation))
    return NS(ctx=ctx,events=events,loader=loader,handle=handle)

def create(rig):return p.PreparedEngineOwners(rig.handle,rig.ctx)

def owners(control,rig):return [control.create(n,rig.ctx,low_memory=True,preserve_dispatch_cache=True) for n in p.ROLES]

def test_exact_two_context_bound_owners(rig):
    control=create(rig);a,b=owners(control,rig)
    assert a is not b and a.rotation is not b.rotation and len(control.owners)==2
    assert control.check() and control.close() and control.close()
    assert a.rotation.closed and b.rotation.closed and rig.loader._active

@pytest.mark.parametrize('role',['linear','other',False])
def test_order_or_role_rejected_before_allocation(rig,role):
    control=create(rig)
    with pytest.raises(ValueError):control.create(role,rig.ctx,low_memory=True,preserve_dispatch_cache=True)
    assert not rig.loader.created

@pytest.mark.parametrize('field',['ctx','factory','lease','map'])
def test_constructor_binding_drift_before_allocation(rig,field):
    control=create(rig)
    if field=='ctx':rig.handle.ctx=object()
    if field=='factory':rig.handle.prepared_arithmetic=lambda **kw:None
    if field=='lease':rig.loader.lease=object()
    if field=='map':rig.ctx._param_cache.coef_maps[1]=object()
    with pytest.raises(ValueError):control.create('graph',rig.ctx,low_memory=True,preserve_dispatch_cache=True)
    assert not rig.loader.created

@pytest.mark.parametrize('field,value',[('_max_entries',True),('_max_entries',3),('_max_bytes',float(2<<30)),('_max_bytes',4<<30)])
def test_typed_fixed_budgets(rig,field,value):
    control=create(rig);a=owners(control,rig)[0];setattr(a.rotation,field,value)
    with pytest.raises(ValueError):control.check()

def test_replacement_cannot_hide_failed_original(rig):
    control=create(rig);a,b=owners(control,rig);old=a.rotation;primary=OSError('uncertain readiness');old._failed=primary;a.rotation=object()
    with pytest.raises(OSError) as seen:control.close()
    assert seen.value is primary and control.failed is primary and len(control.owners)==2 and rig.loader._active
    assert b.rotation.closed and any(e[:2]==('clearrotation',id(old)) for e in rig.events if type(e)is tuple)

def test_cleanup_cancellation_wins_over_ordinary_cleanup(rig):
    control=create(rig);a,b=owners(control,rig);b.rotation._failed=OSError('first');a.rotation._failed=KeyboardInterrupt('later')
    with pytest.raises(KeyboardInterrupt) as seen:control.close()
    assert seen.value is a.rotation._failed and rig.loader._active

def test_constructor_exception_is_sticky(rig,monkeypatch):
    control=create(rig);error=RuntimeError('constructor failure')
    # Original bound factory dispatch enters the fake loader method, whose body
    #now fails without replacing the construction-bound callable identity.
    monkeypatch.setattr(rig.loader,'events',NS(append=lambda *a:(_ for _ in ()).throw(error)))
    with pytest.raises(RuntimeError) as seen:control.create('graph',rig.ctx,low_memory=True,preserve_dispatch_cache=True)
    assert seen.value is error
    with pytest.raises(RuntimeError):control.check()


def test_engine_only_two_primary_caches_refresh_ordinary(rig,monkeypatch):
    class Linear:
        def __init__(self,ctx,layout,**kw):
            self.arithmetic=kw.pop('arithmetic_factory')(ctx,**kw)
    class Refresh:
        def __init__(self,ctx,**kw):
            assert 'arithmetic_factory' not in kw
            self.evaluator=Arithmetic(ctx,object(),rig.events)
            self.compiled_primitives=tuple(NS(clear=lambda **kw:rig.events.append('refreshclear')) for _ in range(5))
    provider=NS(close=lambda:rig.events.append('providerclose'))
    monkeypatch.setattr(engine,'_dependencies',lambda:(lambda ctx:provider,Arithmetic,Linear,lambda slots:slots,Refresh,object,lambda *a:None))
    with engine.server_engine(rig.ctx,manifest_bytes=b'public',prepared_handle=rig.handle) as e:
        assert len(rig.loader.created)==2 and e.prepared_owners.check()
        assert e.refresher.evaluator not in rig.loader.created
    assert rig.events[-1]=='providerclose' and all(a.rotation.closed for a in rig.loader.created)
    assert rig.loader._active # only the outer authenticated loader can retire backing

@pytest.mark.parametrize('action',['clear','pop','replace','reverse'])
def test_inventory_mutation_rejected_and_originals_retired(rig,action):
    control=create(rig);a,b=owners(control,rig)
    if action=='clear':control.owners.clear()
    elif action=='pop':control.owners.pop()
    elif action=='replace':control.owners=list(control.owners)
    else:control.owners.reverse()
    with pytest.raises(ValueError):control.check()
    with pytest.raises(ValueError):control.create('linear',rig.ctx,low_memory=True,preserve_dispatch_cache=True)
    with pytest.raises(ValueError):control.close()
    assert len(rig.loader.created)==2 and a.rotation.closed and b.rotation.closed
    assert len(control._registered)==2 and not control.closed and rig.loader._active

@pytest.mark.parametrize('field',['arithmetic','linear','prepared_owners','refresher','owner_type','secure','manifest_bytes'])
def test_prepared_engine_public_binding_drift_rejects_before_graph(rig,field):
    control=create(rig);a,b=owners(control,rig)
    calls=[];refresh=NS(evaluator=object(),compiled_primitives=(object(),)*5)
    graph=engine.ServerEngine(rig.ctx,a,NS(arithmetic=b),refresh,lambda *a,**k:calls.append('owner'),lambda *a:calls.append('secure'),b'fixed',control)
    setattr(graph,field,None)
    with pytest.raises((ValueError,AttributeError)):graph.evaluate((),{},original_positions=(0,),context_id='x',request_id='y')
    assert not calls

@pytest.mark.parametrize('field',['evaluator','compiled_primitives'])
def test_refresh_helper_swap_rejected_before_graph(rig,field):
    control=create(rig);a,b=owners(control,rig);calls=[]
    refresh=NS(evaluator=object(),compiled_primitives=(object(),)*5)
    graph=engine.ServerEngine(rig.ctx,a,NS(arithmetic=b),refresh,lambda *a,**k:calls.append('owner'),lambda *a:calls.append('secure'),b'fixed',control)
    setattr(refresh,field,object() if field=='evaluator'else (object(),)*5)
    with pytest.raises(ValueError):graph.evaluate((),{},original_positions=(0,),context_id='x',request_id='y')
    assert not calls


def test_real_loader_registered_close_follows_engine_before_lease_retirement(monkeypatch):
    import loader_prepared_rotation as loader_module
    events=[];ctx=NS(_param_cache=NS(coef_maps={1:object()}))
    # Exercise real registration and close methods only; no authenticated key
    # loading, actual arrays, context creation or cryptography in this fixture.
    session=object.__new__(loader_module.PreparedLoaderSession)
    session._context=ctx;session._active=True;session._failure=None;session._registered=[];session.cleanup_completed=False
    session._arrays={};session._maps={};session._states={};session._owner=object()
    session.lease=NS(_check=lambda:None,retire=lambda:events.append('lease-retired'));session._lease_bound=session.lease
    import types
    module=types.ModuleType('prepared_rotation')
    module.create_prepared_arithmetic=lambda context,**kw:Arithmetic(context,kw['source_lease'],events)
    monkeypatch.setitem(sys.modules,'prepared_rotation',module)
    monkeypatch.setattr(p,'_types',lambda:(loader_module.PreparedLoaderSession,Arithmetic,Rotation))
    handle=NS(ctx=ctx,prepared_arithmetic=session.create)
    control=p.PreparedEngineOwners(handle,ctx)
    result=[control.create(role,ctx,low_memory=True,preserve_dispatch_cache=True)for role in p.ROLES]
    assert len(session._registered)==2
    control.close()
    assert all(a.rotation.closed for a in result) and 'lease-retired'not in events
    session.close()
    assert events[-1]=='lease-retired' and session.cleanup_completed and session._context is None


def test_real_loader_quarantines_original_failed_owner_after_engine_replacement(monkeypatch):
    import loader_prepared_rotation as loader_module,types
    events=[];ctx=NS(_param_cache=NS(coef_maps={1:object()}))
    session=object.__new__(loader_module.PreparedLoaderSession)
    session._context=ctx;session._active=True;session._failure=None;session._registered=[];session.cleanup_completed=False
    session._arrays={'retained':object()};session._maps={};session._states={};session._owner=object()
    session.lease=NS(_check=lambda:None,retire=lambda:events.append('lease-retired'));session._lease_bound=session.lease
    module=types.ModuleType('prepared_rotation');module.create_prepared_arithmetic=lambda c,**kw:Arithmetic(c,kw['source_lease'],events)
    monkeypatch.setitem(sys.modules,'prepared_rotation',module)
    monkeypatch.setattr(p,'_types',lambda:(loader_module.PreparedLoaderSession,Arithmetic,Rotation))
    control=p.PreparedEngineOwners(NS(ctx=ctx,prepared_arithmetic=session.create),ctx)
    a=control.create('graph',ctx,low_memory=True,preserve_dispatch_cache=True);b=control.create('linear',ctx,low_memory=True,preserve_dispatch_cache=True)
    original=a.rotation;failure=OSError('uncertain transfer');original._failed=failure;a.rotation=object();control.owners.clear()
    with pytest.raises(OSError) as caught:control.close()
    assert caught.value is failure
    with pytest.raises(OSError) as caught:session.close()
    assert caught.value is failure and session._arrays and not session.cleanup_completed
    assert 'lease-retired'not in events and b.rotation.closed
