"""Public thread-mask observation only; no signal is sent and no HE runs."""
import json,os,signal,threading
from pathlib import Path

def masks():
    result={}
    for p in Path('/proc/self/task').iterdir():
        try:
            lines=p.joinpath('status').read_text().splitlines()
            result[p.name]=next(x.split(':',1)[1].strip() for x in lines if x.startswith('SigBlk:'))
        except FileNotFoundError:pass
    return result

def run():
    before=masks()
    import numpy
    # NumPy/OpenBLAS import creates native workers in this actual environment.
    after=masks();tid=str(threading.get_native_id())
    old=signal.pthread_sigmask(signal.SIG_BLOCK,())
    try:
        signal.pthread_sigmask(signal.SIG_BLOCK,(signal.SIGINT,signal.SIGTERM,signal.SIGHUP))
        blocked=masks()
    finally:signal.pthread_sigmask(signal.SIG_SETMASK,old)
    restored=masks();mask=sum(1<<(int(s)-1)for s in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP))
    return dict(scope='public process thread signal-mask observation; no delivered signal, no HE',
        passed=restored.get(tid)==after.get(tid),main_tid=tid,affinity=sorted(os.sched_getaffinity(0)),
        numpy_version=numpy.__version__,before_import=before,after_import=after,
        main_blocked=blocked,restored=restored,
        native_workers_unblocked=[k for k,v in blocked.items() if k!=tid and int(v,16)&mask!=mask],
        interpretation='pthread_sigmask affects the calling thread; this observation explains a possible race but does not trace the earlier signal delivery')
if __name__=='__main__':
    result=run();print(json.dumps(result,sort_keys=True,indent=2));raise SystemExit(0 if result['passed']else 1)
