from pathlib import Path
import json,os,subprocess,sys
import pytest
HERE=Path(__file__).parent

@pytest.mark.parametrize('phase',['cleanup','restoration','body-and-restoration'])
@pytest.mark.parametrize('sample',range(3))
def test_real_single_fire_scope_with_native_threads(tmp_path,phase,sample):
    destination=tmp_path/'report.json'
    env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='4',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4')
    process=subprocess.Popen([sys.executable,str(HERE/'native_signal_case.py'),phase,str(destination)],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    try:stdout,stderr=process.communicate(timeout=30)
    except BaseException:
        process.kill();process.wait();raise
    result=type('Completed',(),dict(returncode=process.returncode,stderr=stderr))()
    assert destination.exists(),stderr
    report=json.loads(destination.read_bytes())
    if os.environ.get('SIGNAL_EVIDENCE_DIR'):
        evidence=Path(os.environ['SIGNAL_EVIDENCE_DIR']);evidence.mkdir(exist_ok=True)
        record=dict(child_pid=process.pid,returncode=process.returncode,reaped=True,report=report,stdout=stdout,stderr=stderr)
        (evidence/(phase+'-'+str(sample)+'.json')).write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
    assert result.returncode!=0 and result.returncode==report['error_exit_code'],result.stderr
    assert report['operation_passed']is False and report['validation_passed']is True,report
