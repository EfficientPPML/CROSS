from pathlib import Path
from types import SimpleNamespace as NS
import sys
import pytest
HERE=Path(__file__).parent
sys.path[:0]=[str(HERE/'runtime/stage')]
import engine_prepared_owners as p,full_model_engine as engine

class Rotation:
    def __init__(self,ctx,lease,events):
        self.ctx=ctx;self._lease=lease;self._max_entries=2;self._max_bytes=2<<30;self.events=events;self._failed=None;self.closed=False
    def clear(self,*,executables=False):
        self.events.append(('clearrotation',id(self),executables))
        if self._failed:raise self._failed
    def close(self):self.clear(executables=True);self.closed=True
class Arithmetic:
    def __init__(self,ctx,lease,events):
        self.ctx=ctx;self.rotation=Rotation(ctx,lease,events);self.events=events;self._plaintext_multiply=self._rescale=self._multiplication_compiler=None
    def _clear_working_caches(self):self.events.append(('cleararith',id(self)));self.rotation.clear()
class Loader:
    def __init__(self,ctx,events):
        self._context=ctx;self._active=True;self._failure=None;self.events=events;self.lease=NS(_check=lambda:events.append('leasecheck'));self.created=[]
    def create(self,**kwargs):
        assert kwargs==dict(max_entries=2,max_bytes=2<<30,low_memory=True,preserve_dispatch_cache=True)
        self.events.append('create');a=Arithmetic(self._context,self.lease,self.events);self.created.append(a);return a
@pytest.fixture
def rig(monkeypatch):
    ctx=NS(secret_key=None,parameters={'secret_key':None},_param_cache=NS(secret_key=None,coef_maps={1:object(),64:object()}));events=[];loader=Loader(ctx,events)
    handle=NS(ctx=ctx,prepared_arithmetic=loader.create)
    monkeypatch.setattr(p,'_types',lambda:(Loader,Arithmetic,Rotation))
    return NS(ctx=ctx,events=events,loader=loader,handle=handle)

def create(rig):return p.PreparedEngineOwners(rig.handle,rig.ctx)

def owners(control,rig):return [control.create(n,rig.ctx,low_memory=True,preserve_dispatch_cache=True) for n in p.ROLES]

def test_exact_two_context_bound_owners(rig):
    control=create(rig);a,b=owners(control,rig)
    assert a is not b and a.rotation is not b.rotation and len(control.owners)==2
    assert control.check() and control.close() and control.close()
    assert a.rotation.closed and b.rotation.closed and rig.loader._active

@pytest.mark.parametrize('role',['linear','other',False])
def test_order_or_role_rejected_before_allocation(rig,role):
    control=create(rig)
    with pytest.raises(ValueError):control.create(role,rig.ctx,low_memory=True,preserve_dispatch_cache=True)
    assert not rig.loader.created

@pytest.mark.parametrize('field',['ctx','factory','lease','map'])
def test_constructor_binding_drift_before_allocation(rig,field):
    control=create(rig)
    if field=='ctx':rig.handle.ctx=object()
    if field=='factory':rig.handle.prepared_arithmetic=lambda **kw:None
    if field=='lease':rig.loader.lease=object()
    if field=='map':rig.ctx._param_cache.coef_maps[1]=object()
    with pytest.raises(ValueError):control.create('graph',rig.ctx,low_memory=True,preserve_dispatch_cache=True)
    assert not rig.loader.created

@pytest.mark.parametrize('field,value',[('_max_entries',True),('_max_entries',3),('_max_bytes',float(2<<30)),('_max_bytes',4<<30)])
def test_typed_fixed_budgets(rig,field,value):
    control=create(rig);a=owners(control,rig)[0];setattr(a.rotation,field,value)
    with pytest.raises(ValueError):control.check()

def test_replacement_cannot_hide_failed_original(rig):
    control=create(rig);a,b=owners(control,rig);old=a.rotation;primary=OSError('uncertain readiness');old._failed=primary;a.rotation=object()
    with pytest.raises(OSError) as seen:control.close()
    assert seen.value is primary and control.failed is primary and len(control.owners)==2 and rig.loader._active
    assert b.rotation.closed and any(e[:2]==('clearrotation',id(old)) for e in rig.events if type(e)is tuple)

def test_cleanup_cancellation_wins_over_ordinary_cleanup(rig):
    control=create(rig);a,b=owners(control,rig);b.rotation._failed=OSError('first');a.rotation._failed=KeyboardInterrupt('later')
    with pytest.raises(KeyboardInterrupt) as seen:control.close()
    assert seen.value is a.rotation._failed and rig.loader._active

def test_constructor_exception_is_sticky(rig,monkeypatch):
    control=create(rig);error=RuntimeError('constructor failure')
    # Original bound factory dispatch enters the fake loader method, whose body
    #now fails without replacing the construction-bound callable identity.
    monkeypatch.setattr(rig.loader,'events',NS(append=lambda *a:(_ for _ in ()).throw(error)))
    with pytest.raises(RuntimeError) as seen:control.create('graph',rig.ctx,low_memory=True,preserve_dispatch_cache=True)
    assert seen.value is error
    with pytest.raises(RuntimeError):control.check()


def test_engine_only_two_primary_caches_refresh_ordinary(rig,monkeypatch):
    class Linear:
        def __init__(self,ctx,layout,**kw):
            self.arithmetic=kw.pop('arithmetic_factory')(ctx,**kw)
    class Refresh:
        def __init__(self,ctx,**kw):
            assert 'arithmetic_factory' not in kw
            self.evaluator=Arithmetic(ctx,object(),rig.events)
            self.compiled_primitives=tuple(NS(clear=lambda **kw:rig.events.append('refreshclear')) for _ in range(5))
    provider=NS(close=lambda:rig.events.append('providerclose'))
    monkeypatch.setattr(engine,'_dependencies',lambda:(lambda ctx:provider,Arithmetic,Linear,lambda slots:slots,Refresh,object,lambda *a:None))
    with engine.server_engine(rig.ctx,manifest_bytes=b'public',prepared_handle=rig.handle) as e:
        assert len(rig.loader.created)==2 and e.prepared_owners.check()
        assert e.refresher.evaluator not in rig.loader.created
    assert rig.events[-1]=='providerclose' and all(a.rotation.closed for a in rig.loader.created)
    assert rig.loader._active # only the outer authenticated loader can retire backing
