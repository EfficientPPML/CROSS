from pathlib import Path
import json,os,subprocess,sys
import pytest
HERE=Path(__file__).parent

@pytest.mark.parametrize('phase',['cleanup','restoration','body-and-restoration'])
@pytest.mark.parametrize('sample',range(3))
def test_real_single_fire_scope_with_native_threads(tmp_path,phase,sample):
    destination=tmp_path/'report.json'
    env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='4',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4')
    result=subprocess.run([sys.executable,str(HERE/'native_signal_case.py'),phase,str(destination)],env=env,capture_output=True,text=True,timeout=30)
    report=json.loads(destination.read_bytes())
    assert result.returncode!=0 and result.returncode==report['error_exit_code'],result.stderr
    assert report['operation_passed']is False and report['validation_passed']is True,report
