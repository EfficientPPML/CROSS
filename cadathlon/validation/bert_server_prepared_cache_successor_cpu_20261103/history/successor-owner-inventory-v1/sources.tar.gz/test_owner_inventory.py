from test_engine_prepared import rig,create,owners
import pytest

def test_retirement_inventory_cannot_be_cleared(rig):
    control=create(rig);a,b=owners(control,rig);control.owners.clear()
    with pytest.raises(ValueError):control.check()

def test_truncated_inventory_cannot_allocate_third_cache_owner(rig):
    control=create(rig);a,b=owners(control,rig);control.owners.pop()
    with pytest.raises(ValueError):control.create('linear',rig.ctx,low_memory=True,preserve_dispatch_cache=True)
    assert len(rig.loader.created)==2

def test_clear_cannot_silently_skip_original_owners(rig):
    control=create(rig);a,b=owners(control,rig);control.owners.clear()
    with pytest.raises(ValueError):control.close()
    assert not control.closed
