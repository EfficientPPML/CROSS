"""Synthetic integers only; exact old AST plus isolated two-expression candidate."""
import importlib.abc,math,sys,warnings
from fractions import Fraction
from types import SimpleNamespace
import pytest
class NoBackend(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0]in('jax','jaxlib','jaxite_word','torch','tensorflow','transformers','safetensors','tokenizers'):raise ImportError('No backend/model imports in public conversion proof')
sys.meta_path.insert(0,NoBackend())
import diagnose as d

@pytest.mark.parametrize('value',[0,1,-1,2**53+1,-(2**53+1),2**200,2**1023,-2**1023])
def test_legacy_representable_branch_bit_identical(value):
    _,_,scale=d.public_geometry();inv=1.0/scale
    assert d.scaled_coefficient(value,scale,inv).hex()==(float(value)*inv).hex()

@pytest.mark.parametrize('sign',[-1,1])
def test_range_safe_fallback_matches_exact_fraction(sign):
    _,Q,scale=d.public_geometry();value=sign*2**1024
    assert abs(value)<Q//2
    with pytest.raises(OverflowError,match='int too large to convert to float'):float(value)
    actual=d.scaled_coefficient(value,scale,1.0/scale)
    assert math.isfinite(actual)and actual==float(Fraction(value)/Fraction(scale))

@pytest.mark.parametrize('component',['real','imag'])
def test_exact_old_fullslot_decoder_fails_before_guard_or_fft(component):
    q,Q,scale=d.public_geometry();N=131072;values=[0]*N;values[0 if component=='real'else N//2]=2**1024
    env,calls=d.make_decoder(values);ctx=SimpleNamespace(q_towers=q,num_slots=N//2)
    with pytest.raises(OverflowError,match='int too large to convert to float'):env['_fast_decode'](SimpleNamespace(shape=(N,40)),ctx,scale)
    assert calls=={'crt':1,'fft':0}

@pytest.mark.parametrize('component',['real','imag'])
def test_candidate_keeps_original_one_over32_gate_and_rejects_giant_noise(component):
    q,Q,scale=d.public_geometry();N=131072;values=[0]*N;values[0 if component=='real'else N//2]=2**1024
    env,calls=d.make_decoder(values,candidate=True);assert env['_DECODE_STDDEV_LIMIT']==1/32
    with warnings.catch_warnings():
        warnings.simplefilter('ignore',RuntimeWarning)
        with pytest.raises(env['ApproximationErrorTooHigh']):env['_fast_decode'](SimpleNamespace(shape=(N,40)),SimpleNamespace(q_towers=q,num_slots=N//2),scale)
    assert calls=={'crt':1,'fft':0}

@pytest.mark.parametrize('sign',[-1,1])
def test_true_scaled_overflow_remains_failure(sign):
    _,Q,scale=d.public_geometry()
    with pytest.raises(OverflowError,match='unit-scale coefficient is not representable'):d.scaled_coefficient(sign*(Q//2),scale,1.0/scale)

def test_control_zero_fullslot_decode_matches_original():
    q,Q,scale=d.public_geometry();N=131072;values=[0]*N;ctx=SimpleNamespace(q_towers=q,num_slots=N//2);ct=SimpleNamespace(shape=(N,40));outputs=[]
    for candidate in (False,True):
        env,calls=d.make_decoder(values,candidate=candidate);outputs.append(env['_fast_decode'](ct,ctx,scale));assert calls=={'crt':1,'fft':1}
    assert (outputs[0]==outputs[1]).all()and(outputs[0]==0).all()

def test_actual_public_geometry_and_scope():
    q,Q,scale=d.public_geometry();assert len(q)==40 and Q.bit_length()==1096 and scale.hex()=='0x1.ea3b603ea0001p+55'
    assert not any(n in sys.modules for n in ('jax','jaxite_word','torch','transformers','safetensors'))
