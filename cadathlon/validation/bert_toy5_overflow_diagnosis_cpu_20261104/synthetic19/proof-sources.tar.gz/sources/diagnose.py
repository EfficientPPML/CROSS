"""Public synthetic decoder-conversion study; no backend/context/secret loader."""
import ast,copy,math,json
from pathlib import Path
from types import SimpleNamespace
import numpy as np
ROOT=Path(__file__).resolve().parent

def definitions():
    tree=ast.parse((ROOT/'ckks_ctx.py').read_bytes())
    names={'ApproximationErrorTooHigh','_decode_conjugate','_decode_approximation_stddev','_check_decode_stddev','_validate_decode_approximation','_fast_decode'}
    nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))and n.name in names]
    nodes += [n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='_DECODE_STDDEV_LIMIT'for t in n.targets)]
    assert len(nodes)==7
    return nodes

def scaled_coefficient(value,scale,scale_inv):
    """Preserve legacy finite conversion; only rescue pre-scaling int overflow.

    Candidate only. Exact integer division by the binary64 scale avoids first
    converting a huge numerator to binary64. True unit-scale overflow remains
    an OverflowError. No decoder threshold or approximation check is changed.
    """
    try:
        raw=float(value)
    except OverflowError:
        numerator,denominator=float(scale).as_integer_ratio()
        try:return (value*denominator)/numerator
        except OverflowError as error:
            raise OverflowError('CKKS unit-scale coefficient is not representable as binary64')from error
    return raw*scale_inv

class ConversionOnly(ast.NodeTransformer):
    def __init__(self):self.changed=0
    def visit_BinOp(self,node):
        if (isinstance(node.op,ast.Mult)and isinstance(node.left,ast.Call)and isinstance(node.left.func,ast.Name)and node.left.func.id=='float'and len(node.left.args)==1 and isinstance(node.left.args[0],ast.Name)and node.left.args[0].id in('r','im')and isinstance(node.right,ast.Name)and node.right.id=='scale_inv'):
            self.changed+=1
            return ast.copy_location(ast.Call(func=ast.Name(id='_scaled_coefficient',ctx=ast.Load()),args=[node.left.args[0],ast.Name(id='scale',ctx=ast.Load()),node.right],keywords=[]),node)
        return self.generic_visit(node)

def make_decoder(combined,*,candidate=False):
    calls={'crt':0,'fft':0}
    def crt(residues,moduli):calls['crt']+=1;return list(combined)
    def fft(values,degree):calls['fft']+=1
    env=dict(np=np,math=math,_crt_combine_rns=crt,FFTSpecial=fft,_scaled_coefficient=scaled_coefficient)
    nodes=definitions()
    if candidate:
        patch=ConversionOnly();nodes=[patch.visit(copy.deepcopy(n))if isinstance(n,ast.FunctionDef)and n.name=='_fast_decode'else n for n in nodes];assert patch.changed==2
    tree=ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[]));exec(compile(tree,str(ROOT/'ckks_ctx.py'),'exec'),env)
    return env,calls

def public_geometry():
    raw=json.loads((ROOT.parent/'failure-preserved/security_device.json').read_bytes());event=raw['events'][-1];ct=event['ciphertexts'][0]
    q=[int(x)for x in event['actual_rings'][0]['q_towers'][:ct['moduli_count']]]
    return q,math.prod(q),ct['scale']
