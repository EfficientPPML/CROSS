"""Pure byte admission and real fresh-entry rejection before body access."""
import ast
from dataclasses import replace
import json
from pathlib import Path
import sys
from types import SimpleNamespace as NS
import pytest
import model_entry as entry
import model_validation_grant as grant
import model_validation_process as process
from support import RUNTIME,ROOT,canonical,sha,copy_runtime,child

@pytest.mark.parametrize('case',['help','usage','clean-missing-grant','wrong-map','changed-helper','extra-shadow'],
                         ids=['help','usage','clean-missing-grant','wrong-map','changed-helper','extra-shadow'])
def test_real_cli_source_admission_before_helpers_or_output(source,tmp_path,case):
    runtime=copy_runtime(source,tmp_path/'runtime');manifest=tmp_path/'sources.json';manifest.write_bytes(source.raw)
    marker=tmp_path/'helper-executed';output=tmp_path/'output';digest=sha(source.raw)
    if case=='changed-helper':
        (runtime/'model_validation_process.py').write_text('from pathlib import Path\nPath('+repr(str(marker))+').write_text("executed")\n')
    if case=='extra-shadow':
        (runtime/'platform.py').write_text('from pathlib import Path\nPath('+repr(str(marker))+').write_text("executed")\n')
    if case=='wrong-map':digest='0'*64
    argv=[sys.executable,'-I','-B',str(runtime/'model_entry.py')]
    if case=='help':argv+=['--help']
    elif case!='usage':argv+=['--role','validate_existing_model_stores','--manifest',str(manifest),
        '--manifest-sha256',digest,'--grant',str(tmp_path/'missing-grant.json'),'--grant-sha256','a'*64,'--output',str(output)]
    result=child(argv,tmp_path/'child')
    assert result.code==(0 if case=='help'else 2 if case=='usage'else 70)
    assert not marker.exists()and not output.exists()
    if case=='clean-missing-grant':assert b'FileNotFoundError'in result.stderr
    if case in('wrong-map','changed-helper','extra-shadow'):assert b'ValueError'in result.stderr

@pytest.mark.parametrize('case',['clean','main-missing','main-outside','main-spec','entry-missing-spec','entry-alias','unknown-spec'],
                         ids=['clean','main-missing','main-outside','main-spec','entry-missing-spec','entry-alias','unknown-spec'])
def test_exact_main_and_canonical_entry_origins_regression(source,tmp_path,monkeypatch,case):
    root=copy_runtime(source,tmp_path/'runtime');main=NS(__file__=str(root/'model_entry.py'),__spec__=None)
    helper=NS(__file__=str(root/'model_entry.py'),__spec__=NS(origin=str(root/'model_entry.py')))
    modules={'__main__':main,'model_entry':helper}
    if case=='main-missing':del main.__file__
    if case=='main-outside':main.__file__=str(tmp_path/'outside.py')
    if case=='main-spec':main.__spec__=NS(origin=str(tmp_path/'outside.py'))
    if case=='entry-missing-spec':helper.__spec__=None
    if case=='entry-alias':
        alias=tmp_path/'entry-alias.py';alias.symlink_to(root/'model_entry.py');helper.__file__=str(alias)
    if case=='unknown-spec':modules['unknown']=NS(__spec__=NS(origin=str(root/'model_output.py')))
    monkeypatch.setattr(entry,'ROOT',root);monkeypatch.setattr(entry,'sys',NS(modules=modules))
    if case=='clean':entry.origins(source.expected)
    else:
        with pytest.raises(ValueError):entry.origins(source.expected)
    if case in('main-missing','main-outside','main-spec','entry-missing-spec','entry-alias'):
        tree=ast.parse((ROOT/'history/source40-model_entry.py.txt').read_text())
        node=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='origins')
        namespace=dict(entry.__dict__);exec(compile(ast.Module(body=[node],type_ignores=[]),'<exact40-origins>','exec'),namespace)
        namespace['origins'](source.expected)  # Preserved historical gap, no actual helper execution.

def test_pure_external_grant_replays_exact_source_and_store_bytes(grant_bundle):
    admitted=grant_bundle.call();again=admitted.check()
    assert again.grant_bytes==admitted.grant_bytes
    assert admitted.stores.raw==grant_bundle.stores.raw
    assert admitted.stores.execution_authorized is False
    with pytest.raises(ValueError):replace(admitted,grant_sha256='0'*64).check()

@pytest.mark.parametrize('case',['bool-core','model-forward','unknown-field','wrong-source','wrong-policy','failed-review','wrong-stores','wrong-external'],
                         ids=['bool-core','model-forward','unknown-field','wrong-source','wrong-policy','failed-review','wrong-stores','wrong-external'])
def test_repinned_grant_rejects_scope_types_and_external_binding(grant_bundle,case):
    value=json.loads(canonical(grant_bundle.value));kw={}
    if case=='bool-core':value['cores'][0]=True
    elif case=='model-forward':value['model_execution_authorized']=True
    elif case=='unknown-field':value['additional_authority']=True
    elif case=='wrong-source':value['source_manifest_sha256']='f'*64
    elif case=='wrong-policy':value['readonly_policy_sha256']='f'*64
    elif case=='failed-review':
        raw=canonical({'passed':False});value['prelaunch_review']['sha256']=sha(raw);kw['review_override']=raw
    elif case=='wrong-stores':kw['store_override']=b'{}\n'
    else:kw['external']='0'*64
    with pytest.raises((ValueError,TypeError)):grant_bundle.call(value,**kw)

@pytest.mark.parametrize('case',['protected-descendant','protected-ancestor','output-overlap','role-suffix','role-alias'],
                         ids=['protected-descendant','protected-ancestor','output-overlap','role-suffix','role-alias'])
def test_actual_admit_rejects_public_paths_before_first_role_read(source,tmp_path,monkeypatch,case):
    protected=tmp_path/'protected';protected.mkdir();output=tmp_path/'evidence'
    policy,dep=grant.policies(source.blobs);policy=dict(policy,protected_paths=[str(protected)],bootstrap_borrowed_roots=[])
    monkeypatch.setattr(process,'policies',lambda blobs:(policy,dep))
    accesses=[]
    def forbidden(*a,**kw):accesses.append(a);raise AssertionError('public read reached before path rejection')
    monkeypatch.setattr(process,'read',forbidden)
    manifest=tmp_path/'sources.json';grant_path=tmp_path/'grant.json'
    if case=='protected-descendant':grant_path=protected/'grant.json'
    elif case=='protected-ancestor':grant_path=tmp_path
    elif case=='output-overlap':grant_path=output/'grant.json'
    elif case=='role-suffix':grant_path=tmp_path/'grant.npz'
    else:
        target=tmp_path/'real.json';target.write_bytes(b'{}');grant_path.symlink_to(target)
    args=NS(output=str(output),manifest=str(manifest),grant=str(grant_path),grant_sha256='a'*64,manifest_sha256=sha(source.raw))
    with pytest.raises(ValueError):process.admit(args,source.raw,source.expected,source.blobs)
    assert accesses==[]and not output.exists()

def test_actual_admit_public_roles_then_capacity_before_body(source,grant_bundle,tmp_path,monkeypatch):
    # Real byte authenticator; only read() is recorded. No store path is stated/opened.
    manifest=tmp_path/'sources.json';grant_path=tmp_path/'grant.json';value=grant_bundle.value
    docs={str(grant_path):canonical(value),value['expected_stores']['path']:grant_bundle.stores.raw,
          value['prelaunch_review']['path']:grant_bundle.review}
    calls=[]
    def recorded(path,*,limit,expected=None):
        calls.append(str(path));raw=docs[str(path)];assert len(raw)<=limit and sha(raw)==expected;return raw
    monkeypatch.setattr(process,'read',recorded)
    args=NS(output=value['evidence_output'],manifest=str(manifest),grant=str(grant_path),
            grant_sha256=sha(canonical(value)),manifest_sha256=sha(source.raw))
    launch,policy,dep,paths=process.admit(args,source.raw,source.expected,source.blobs)
    assert calls==[str(grant_path),value['expected_stores']['path'],value['prelaunch_review']['path']]
    assert launch.stores.raw==grant_bundle.stores.raw and len(paths)==4
    assert not Path(value['evidence_output']).exists()

@pytest.mark.parametrize('case',['nan','duplicate'],ids=['nan','duplicate'])
def test_closed_json_rejects_nonfinite_and_duplicate_authority(case):
    raw=b'{"execute":NaN}'if case=='nan'else b'{"execute":true,"execute":false}'
    with pytest.raises(ValueError):grant.public_requests(raw)
