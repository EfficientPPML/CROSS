"""Tiny newly owned files; no parameter, private, or historical output access."""
import os
from pathlib import Path
import stat
from types import SimpleNamespace as NS
import pytest
import model_output as output
import model_validation_process as process
from support import canonical,sha

def test_fresh_output_readback_original_reopen_and_protected_sibling(tmp_path,monkeypatch):
    sibling=tmp_path/'borrowed-sibling';sibling.mkdir();(sibling/'marker').write_bytes(b'unchanged')
    calls=[];original_fsync=os.fsync
    monkeypatch.setattr(output.os,'fsync',lambda fd:(calls.append(fd),original_fsync(fd))[1])
    owner=output.Output(tmp_path/'evidence');binding=owner.binding();owner.close()
    reopened=output.Output.reopen(binding)
    try:reopened.write('report.json',b'{"synthetic":true}\n')
    finally:reopened.close()
    result=tmp_path/'evidence'/'report.json'
    assert result.read_bytes()==b'{"synthetic":true}\n'and stat.S_IMODE(result.stat().st_mode)==0o600
    assert stat.S_IMODE(result.parent.stat().st_mode)==0o700 and len(calls)==2
    assert (sibling/'marker').read_bytes()==b'unchanged'
    with pytest.raises(FileExistsError):output.Output(tmp_path/'evidence')

def test_replacement_leaf_is_rejected_and_never_deleted(tmp_path):
    owner=output.Output(tmp_path/'evidence');binding=owner.binding();owner.close()
    original=tmp_path/'original';(tmp_path/'evidence').rename(original)
    replacement=tmp_path/'evidence';replacement.mkdir(mode=0o700);(replacement/'marker').write_bytes(b'replacement')
    with pytest.raises(ValueError):output.Output.reopen(binding)
    assert (replacement/'marker').read_bytes()==b'replacement'and original.is_dir()

@pytest.mark.parametrize('case',['unsafe-parent','changed-parent-mode'],ids=['unsafe-parent','changed-parent-mode'])
def test_output_parent_trust_is_checked_before_and_after_acquisition(tmp_path,case):
    parent=tmp_path/'parent';parent.mkdir(mode=0o700)
    if case=='unsafe-parent':
        parent.chmod(0o777)
        with pytest.raises(ValueError):output.Output(parent/'evidence')
        assert not (parent/'evidence').exists()
    else:
        owner=output.Output(parent/'evidence');parent.chmod(0o755)
        try:
            with pytest.raises(ValueError):owner.check()
        finally:owner.close()

def test_uncertain_file_close_is_not_retried_and_other_original_fds_close(tmp_path,monkeypatch):
    owner=output.Output(tmp_path/'evidence');original_fds=(owner.fd,owner.parent_fd)
    original_close=os.close;calls=[];failure=OSError('synthetic uncertain close')
    def closed(fd):
        calls.append(fd);original_close(fd)
        if fd not in original_fds:raise failure
    with monkeypatch.context()as patch:
        patch.setattr(output.os,'close',closed)
        with pytest.raises(OSError)as caught:owner.write('report.json',b'{}\n')
        assert caught.value is failure
        with pytest.raises(OSError)as caught:owner.close()
        assert caught.value is failure
    assert len(calls)==3 and len(set(calls))==3 and set(original_fds)<=set(calls)
    assert owner.fd is None and owner.parent_fd is None
    assert any(row[0]is owner and row[2]is failure for row in output._QUARANTINE)

@pytest.mark.parametrize('failure',[KeyboardInterrupt,SystemExit],ids=['keyboard','system-exit'])
def test_genuine_read_primary_survives_descriptor_close_cancellation(tmp_path,monkeypatch,failure):
    path=tmp_path/'public.json';path.write_bytes(b'{}\n');body=ValueError('synthetic body');cancel=failure()
    original_close=os.close;calls=[]
    def read(fd,size):raise body
    def close(fd):calls.append(fd);original_close(fd);raise cancel
    with monkeypatch.context()as patch:
        patch.setattr(output.os,'read',read);patch.setattr(output.os,'close',close)
        with pytest.raises(ValueError)as caught:output.read(path,limit=100)
        assert caught.value is body
    assert len(calls)==1

def test_observed_store_records_come_from_live_fds_not_expected_echo(tmp_path):
    """Two tiny file records exercise live-FD reconstruction, not full catalog integrity."""
    fds=[];roots={};calls=[]
    def held(path):
        fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW);fds.append(fd)
        return NS(fd=fd,path=path,check=lambda:calls.append(str(path)))
    try:
        for family in ('qkv','decoder','gamma'):
            path=tmp_path/family;path.mkdir();roots[family]=held(path)
        matrix=tmp_path/'qkv'/'tiny.bin';matrix.write_bytes(b'matrix')
        gamma=tmp_path/'gamma'/'tiny-gamma.bin';gamma.write_bytes(b'gamma')
        mf=held(matrix);mf.expected=sha(b'matrix');gf=held(gamma);gf.expected=sha(b'gamma');gf.name=gamma.name
        raw_sha='a'*64;catalog=NS(matrices=canonical({'logical':{'family':'qkv','descriptor':{'file':matrix.name,'sha256':raw_sha}}}))
        owner=NS(check=lambda:calls.append('owner'),roots=roots,catalog=catalog,
                 matrices={('qkv',matrix.name):NS(file=mf)},gamma_lease=gf)
        expected=dict(roots={family:dict(path=str(row.path),device=os.fstat(row.fd).st_dev,
            inode=os.fstat(row.fd).st_ino,mode=stat.S_IMODE(os.fstat(row.fd).st_mode))for family,row in roots.items()},
            files=sorted([dict(family='qkv',name=matrix.name,state=process._file_state(os.fstat(mf.fd)),file_sha256=mf.expected,raw_sha256=raw_sha),
                dict(family='gamma',name=gamma.name,state=process._file_state(os.fstat(gf.fd)),file_sha256=gf.expected,raw_sha256=None)],key=lambda r:(r['family'],r['name'])))
        stores=NS(check=lambda:expected)
        assert process.observed_stores(owner,stores)==expected and len(calls)==6
        matrix.write_bytes(b'changed extent')
        with pytest.raises(ValueError):process.observed_stores(owner,stores)
    finally:
        for fd in reversed(fds):os.close(fd)

def test_actual_factory_partial_root_acquisition_retires_originals_before_any_body_hash(public,aggregate,tmp_path,monkeypatch):
    """Real selected factory/NumPy import; only empty newly owned roots exist."""
    import qwen_public_parameters as parameters
    from model_admission import ExpectedStoreIdentity
    from support import synthetic_stores
    import json
    value=json.loads(synthetic_stores(aggregate,tmp_path).raw)
    for family in ('qkv','decoder','gamma'):
        path=tmp_path/family;path.mkdir(mode=0o700);s=path.stat()
        value['roots'][family]=dict(path=str(path),device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode))
    value['roots']['decoder']['inode']+=1
    expected=ExpectedStoreIdentity(aggregate,canonical(value));owners=[];body_calls=[]
    original=parameters.HeldDirectory
    def opened(path):owner=original(path);owners.append(owner);return owner
    def forbidden(*args):body_calls.append(args);raise AssertionError('body access preceded expected root check')
    monkeypatch.setattr(parameters,'HeldDirectory',opened)
    monkeypatch.setattr(parameters,'_hash_fd',forbidden)
    monkeypatch.setattr(parameters,'_header',forbidden)
    with pytest.raises(ValueError,match='expected held root'):
        parameters.open_identity_bound_parameters(public,expected)
    assert len(owners)==2 and all(o.fd is None for o in owners)and body_calls==[]
    assert all(not list((tmp_path/f).iterdir())for f in ('qkv','decoder','gamma'))
