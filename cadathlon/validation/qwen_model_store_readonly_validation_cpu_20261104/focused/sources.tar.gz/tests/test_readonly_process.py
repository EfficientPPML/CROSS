"""Actual direct traversal/cleanup with declared reader/admission/resource seams."""
import ast
import json
import os
from pathlib import Path
import sys
from types import SimpleNamespace as NS
import pytest
import model_entry as entry
import model_validation_process as process
from support import ROOT,RecordingRun,canonical,child,sha

def test_direct_traversal_visits_full_catalog_drops_views_and_closes_originals(source,aggregate,tmp_path,monkeypatch):
    run=RecordingRun(monkeypatch,source,aggregate,tmp_path)
    assert run.run()==0
    assert run.matrix_names==sorted(aggregate.catalog['matrices'])and len(run.matrix_names)==198
    assert run.gamma_names==sorted(aggregate.catalog['gammas'])and len(run.gamma_names)==113
    assert len(run.owner.matrices)==197 and all(ref()is None for ref in run.views)
    assert run.observed_calls==1 and run.events.count('owner.close')==1
    assert run.events.index('owner.close')<run.events.index('publication.write')<run.events.index('audit.close')
    report=run.report();assert report['passed']is True and report['counts']['physical_matrices']==197
    assert run.owner.closed and run.audit.closed and run.snapshot_calls==run.origin_calls

@pytest.mark.parametrize('phase',['before-body','open-entered','matrix-entered'],ids=['before-body','open-entered','matrix-entered'])
def test_failure_read_state_is_monotone_and_genuine_primary_is_preserved(source,aggregate,tmp_path,monkeypatch,phase):
    failure=ValueError('synthetic body failure')
    kwargs={'catalog_error':failure}if phase=='before-body'else {'open_error':failure}if phase=='open-entered'else {'matrix_error':failure}
    run=RecordingRun(monkeypatch,source,aggregate,tmp_path,**kwargs)
    with pytest.raises(ValueError)as caught:run.run()
    assert caught.value is failure and run.audit.closed
    if phase=='before-body':
        assert 'reader.open'not in run.events
        report=run.report();assert report['parameter_body_reads_performed']is False
        assert report['body_read_status']=='not_entered'
    else:
        report=run.report();assert report['body_read_status']=='entered_unconfirmed'
        assert report['parameter_body_reads_performed']is None and report['body_integrity_admitted']is False
        assert report['completed_logical_visits']==0
    if phase=='matrix-entered':assert run.close_primary==[failure]

def test_callback_replacement_rejects_then_retires_original_callback_once(source,aggregate,tmp_path,monkeypatch):
    run=RecordingRun(monkeypatch,source,aggregate,tmp_path,swap_callback=True)
    with pytest.raises(ValueError,match='owner callback changed'):run.run()
    assert len(run.matrix_names)==1 and run.events.count('owner.close')==1
    assert 'replacement.close'not in run.events and run.owner.closed and run.audit.closed

@pytest.mark.parametrize('body_kind',['genuine','cleanup-only'],ids=['genuine','cleanup-only'])
def test_sticky_body_identity_and_cleanup_cancellation_across_reader_boundary(source,aggregate,tmp_path,monkeypatch,body_kind):
    from cleanup_origin import mark
    body=ValueError('synthetic body')if body_kind=='genuine'else mark(OSError('earlier cleanup only'))
    cancel=KeyboardInterrupt()
    run=RecordingRun(monkeypatch,source,aggregate,tmp_path,matrix_error=body,close_error=cancel,sticky_body=True)
    with pytest.raises(BaseException)as caught:run.run()
    assert caught.value is (body if body_kind=='genuine'else cancel)
    assert run.events.count('owner.close')==1 and run.audit.closed

@pytest.mark.parametrize('kind',[OSError,KeyboardInterrupt],ids=['ordinary','cancellation'])
def test_shield_construction_failure_still_attempts_original_resources(source,aggregate,tmp_path,monkeypatch,kind):
    body=ValueError('synthetic body');shield=kind('synthetic shield construction')
    run=RecordingRun(monkeypatch,source,aggregate,tmp_path,matrix_error=body,shield_error=shield)
    with pytest.raises(ValueError)as caught:run.run()
    assert caught.value is body
    assert run.events.count('owner.close')==1 and 'output.close'in run.events and run.audit.closed
    assert run.report()['passed']is False

@pytest.mark.parametrize('revision',['held40','held42'],ids=['held40-control-gap','held42-veto'])
def test_postpublication_swallowed_denial_regression_always_restores_audit(source,aggregate,tmp_path,monkeypatch,revision):
    if revision=='held40':
        tree=ast.parse((ROOT/'history/source40-model_validation_process.py.txt').read_text())
        node=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='run')
        namespace=process.__dict__;previous=process.run
        # Exact historical run AST, same explicit recording dependencies as successor.
        exec(compile(ast.Module(body=[node],type_ignores=[]),'<exact40-run>','exec'),namespace)
        old=process.run;namespace['run']=previous;monkeypatch.setattr(process,'run',old)
    run=RecordingRun(monkeypatch,source,aggregate,tmp_path,publish_denial=True)
    if revision=='held40':assert run.run()==0
    else:
        with pytest.raises(PermissionError,match='sticky'):run.run()
    assert run.report()['passed']is True  # Persisted document alone is not terminal authority.
    assert run.audit.closed and run.events[-1]=='audit.close'

@pytest.mark.parametrize('kind',[OSError,SystemExit],ids=['late-oserror','late-system-exit-zero'])
def test_late_publication_close_cannot_turn_persisted_pass_into_normal_success(source,aggregate,tmp_path,monkeypatch,kind):
    failure=kind('synthetic late close')if kind is OSError else SystemExit(0)
    run=RecordingRun(monkeypatch,source,aggregate,tmp_path,publish_error=failure)
    assert entry.terminal_status(run.run)==70
    assert run.report()['passed']is True and run.audit.closed and run.owner.closed

def test_readscope_body_switch_sticky_denial_and_original_open_restoration(source,aggregate,tmp_path,monkeypatch):
    from model_validation_grant import policies
    from support import synthetic_stores,RUNTIME
    stores=synthetic_stores(aggregate,tmp_path/'borrowed');policy,dep=policies(source.blobs)
    launch=NS(stores=stores,source_root=str(RUNTIME),output_path=str(tmp_path/'evidence'),blobs=tuple(source.blobs.items()))
    scope=process.ReadScope(launch,policy,dep,[]);body=next(iter(scope.body));original=os.open;hooks=[]
    monkeypatch.setattr(process.sys,'addaudithook',hooks.append)  # No permanent real audit in shared pytest.
    scope.install()
    try:
        with pytest.raises(PermissionError):scope.access(body,os.O_RDONLY)
        scope.body_enabled=True;scope.access(body,os.O_RDONLY)
        with pytest.raises(PermissionError,match='sticky'):scope.check()
        with pytest.raises(PermissionError):scope.hook('os.fork',())
    finally:scope.close()
    assert os.open is original and scope.closed and len(hooks)==1 and len(scope.denials)==2

@pytest.mark.parametrize('case',['normal-zero','normal-one','bool','subclass','none','late-oserror','late-exit-one','late-exit-zero','diagnostic-failure'],
                         ids=['normal-zero','normal-one','bool','subclass','none','late-oserror','late-exit-one','late-exit-zero','diagnostic-failure'])
def test_exact_terminal_boundary_in_fresh_child_uses_actual_final_entry_guard(tmp_path,case):
    """Exact terminal_status and __main__ AST; synthetic dispatch, not actual model execution."""
    probe=tmp_path/'probe.py'
    code='''import ast,sys
from pathlib import Path
tree=ast.parse(Path(sys.argv[1]).read_text())
names={'terminal_status'}
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in names]
guard=tree.body[-1]
assert isinstance(guard,ast.If)
case=sys.argv[2]
class IntSubclass(int):pass
def dispatch():
 if case=='late-oserror':raise OSError('PRIVATE_MESSAGE_MUST_NOT_APPEAR')
 if case=='late-exit-one':raise SystemExit(1)
 if case=='late-exit-zero':raise SystemExit(0)
 if case=='diagnostic-failure':raise ValueError('PRIVATE_MESSAGE_MUST_NOT_APPEAR')
 return {'normal-zero':0,'normal-one':1,'bool':True,'subclass':IntSubclass(0),'none':None}[case]
namespace={'__name__':'__main__','sys':sys,'INFRASTRUCTURE_EXIT':70}
exec(compile(ast.Module(body=nodes,type_ignores=[]),sys.argv[1],'exec'),namespace)
if case=='diagnostic-failure':
 class BadDiagnostic:
  def write(self,*args):raise SystemExit(1)
  def flush(self):pass
 sys.stderr=BadDiagnostic()
namespace['main']=lambda:namespace['terminal_status'](dispatch)
exec(compile(ast.Module(body=[guard],type_ignores=[]),sys.argv[1],'exec'),namespace)
'''
    probe.write_text(code)
    result=child([sys.executable,'-I','-B',str(probe),str(ROOT/'runtime/model_entry.py'),case],tmp_path/'child')
    assert result.code==({'normal-zero':0,'normal-one':1}.get(case,70))
    assert b'PRIVATE_MESSAGE_MUST_NOT_APPEAR'not in result.stderr
