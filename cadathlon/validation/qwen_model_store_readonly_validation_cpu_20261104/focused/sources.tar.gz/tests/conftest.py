"""Focused new tests only; runtime/ remains the exact independently held42."""
import importlib.abc
import sys
from pathlib import Path
import pytest

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
RUNTIME=ROOT/'runtime'
sys.path.insert(0,str(RUNTIME))
sys.path.insert(0,str(HERE))
FORBIDDEN={'jax','jaxlib','jaxite_word','torch','transformers','tensorflow',
           'flax','torch_xla','safetensors','tokenizers','libtpu'}
class DenyBackend(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0]in FORBIDDEN:
            raise RuntimeError('readonly focused preparation forbids backend import/discovery: '+fullname)
sys.meta_path.insert(0,DenyBackend())
if FORBIDDEN.intersection(sys.modules):raise RuntimeError('preloaded backend in focused preparation')
@pytest.fixture(autouse=True)
def no_backend():
    assert not FORBIDDEN.intersection(sys.modules)
    yield
    assert not FORBIDDEN.intersection(sys.modules)

@pytest.fixture(scope='session')
def source():
    from support import source_bundle
    return source_bundle()
@pytest.fixture(scope='session')
def public(source):
    from qwen_file_contract import PublicContract
    from public_source_pins import PUBLIC_PINS
    return PublicContract.from_blobs({n:source.blobs['public_inputs/'+n]for n in PUBLIC_PINS})
@pytest.fixture(scope='session')
def aggregate(source,public):
    from model_admission import Aggregate
    return Aggregate(public,source.blobs['unadmitted_aggregate_manifest.json'])
@pytest.fixture
def grant_bundle(source,aggregate,tmp_path):
    from support import grant_fixture
    return grant_fixture(source,aggregate,tmp_path)
