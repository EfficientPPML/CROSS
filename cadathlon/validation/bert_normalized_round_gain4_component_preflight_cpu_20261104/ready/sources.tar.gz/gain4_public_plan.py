"""Fixed two-fixture gain4 metadata/IO plan; no backend/key/model execution.

Array helpers return local public fixture/oracle bodies. build_plan emits only
hashes, public metadata and logical counts; it never serializes those bodies.
"""
from pathlib import Path
import hashlib,json,math,sys
import numpy as np
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P/'common'))
from encrypted_bert_normalization_gain4 import gain4_round_plan,DELTA,Q_SHA,P_SHA
from encrypted_bert_normalization_round import NormalizationRoundContract
from encrypted_score_reduction import ScoreReductionLayout
from encrypted_scale_planning import multiply_scale,drop_divisor
import gain4_fixtures as fixtures

SCHEMA='bert-normalized-round-gain4-component-plan-v1'
PINS={
 'gain4_fixtures.py':'d113f252041984ad014d76d3b78b5f6e7c553f632d003e2de5094dc669cacd90',
 'gain4_candidate_manifest.json':'4e2277beea7189aa1d77b168c500c8a175f6c630afa520fcc6b38cb5a179cff9',
 'runtime/stage/server_inputs/p60_profile_and_refresh.json':'fe2408637f9d6de19ac6aef9f6f749aaef9dd56ccbb37b5334293cd223ede035',
 'runtime/stage/server_inputs/twelve_layer_plan.json':'bdc527179b9d1082d3dc0d90f1203523089aa8a24831941ad42a2513d20f7e04',
}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def array_sha(value):
    value=np.asarray(value)
    if value.dtype!=np.dtype('float64') or value.shape!=(65536,) or not np.isfinite(value).all():raise ValueError('finite full-slot float64 fixture required')
    return sha(value.astype('<f8',copy=False).tobytes())
def _inputs():
    bodies={}
    for name,pin in PINS.items():
        raw=(P/name).read_bytes()
        if sha(raw)!=pin:raise ValueError('fixed public source/plan identity differs: '+name)
        bodies[name]=raw
    profile_record=json.loads(bodies['runtime/stage/server_inputs/p60_profile_and_refresh.json']);profile=profile_record['profile']
    keys=json.loads(bodies['runtime/stage/server_inputs/twelve_layer_plan.json'])
    if profile_record['passed']is not True or profile['actual_128_classical_secure']is not True or profile['P_coverage']is not True or keys['passed']is not True:raise ValueError('fixed public profile/security plans must pass')
    for name,want in (('degree',131072),('slots',65536),('depth',49),('scale_bits',60),('dnum',8)):
        if type(profile[name])is not int or profile[name]!=want:raise ValueError('fixed profile dimension differs')
    if type(profile['canonical_scale'])is not float or profile['canonical_scale']!=DELTA:raise ValueError('fixed scale differs')
    for name,count,pin in (('q',100,Q_SHA),('p',14,P_SHA)):
        values=profile[name]
        if type(values)is not list or len(values)!=count or any(type(v)is not int for v in values) or sha(json.dumps(values).encode())!=pin:raise ValueError('fixed ordered Q/P differs')
    union=keys['union_keys']
    if type(union)is not list or len(union)!=130 or any(type(k)is not int for k in union) or len(set(union))!=130:raise ValueError('exact full130 key inventory required')
    refresh=profile_record['refresh_plan']['rotations']
    if type(refresh)is not list or len(refresh)!=106 or len(set(refresh))!=106 or any(type(k)is not int for k in refresh)or not set(refresh)<=set(union):raise ValueError('full store must retain all106 public refresh keys even though this component does not refresh')
    required=tuple(ScoreReductionLayout.rotation_indices())
    if len(required)!=14 or not set(required)<=set(union):raise ValueError('all14 reduction rotations must be supplied')
    return bodies['gain4_candidate_manifest.json'],profile,required,tuple(union)

def fixture_arrays():
    _inputs()
    values=tuple(fixtures.make_probabilities(case) for case in fixtures.definitions())
    if len(values)!=2:raise ValueError('exact two public input fixtures required')
    for value in values:array_sha(value)
    return tuple(value.copy() for value in values)

def oracle_arrays():
    raw,_,_,_=_inputs();result=[]
    for case,value in zip(fixtures.definitions(),fixture_arrays()):
        contract=NormalizationRoundContract(raw,case['key_count']);refs,_=fixtures.client_oracles(value,case,contract)
        result.extend(refs[name].copy() for name in fixtures.checkpoint_names(contract.updates))
    if len(result)!=54:raise ValueError('exact54 original-Newton/residual checkpoints required')
    for value in result:array_sha(value)
    return tuple(result)

def _ct_bytes(level):return 2*131072*(2*(level+1))*4

def build_plan():
    raw,profile,rotations,union=_inputs();q=tuple(profile['q']);cases=[];flat=[]
    for index,(case,value) in enumerate(zip(fixtures.definitions(),fixture_arrays())):
        c=NormalizationRoundContract(raw,case['key_count']);schedule=gain4_round_plan(q[:52],input_level=25,canonical_scale=DELTA,contract=c,input_scale=DELTA)
        refs,details=fixtures.client_oracles(value,case,c);metadata={name:(schedule['levels'][name],schedule['scales'][name]) for name in ('masked_input','squared_numerator','denominator','probabilities')}
        rows=schedule['tracked_inverse_scale_plan']['rows']
        for row in rows:
            n=row['update'];metadata[f'y{n:02}']=(row['level'],row['scale'])
            if n<c.updates:metadata[f'e{n:02}']=(row['residual_level'],row['residual_scale'])
        previous=rows[-2];level=previous['residual_level'];scale=previous['residual_scale']
        metadata[f'e{c.updates:02}']=(level-1,multiply_scale(scale,scale,drop_divisor(q,level)))
        checkpoints=[]
        for label in fixtures.checkpoint_names(c.updates):
            level,scale=metadata[label]
            if type(level)is not int or level<2 or type(scale)is not float or not math.isfinite(scale) or scale<=0:raise ValueError('actual checkpoint metadata invalid')
            row=dict(index=len(flat),case_index=index,case=case['name'],label=label,level=level,scale=scale,nsd=1,
                num_moduli=2*(level+1),payload_shape=[1,2,256,512,2*(level+1)],payload_dtype='uint32',payload_bytes=_ct_bytes(level),expected_array_sha256=array_sha(refs[label]))
            checkpoints.append(row);flat.append(row)
        layout=ScoreReductionLayout(case['key_mask'],valid_rows=case['valid_rows'])
        definition=dict(name=case['name'],key_count=case['key_count'],valid_rows=case['valid_rows'],seed=case['seed'],key_mask=case['key_mask'].astype(int).tolist())
        counts=dict(prefix_level_reductions=1,logical_plaintext_products=3,logical_ciphertext_products=schedule['logical_ciphertext_products']+1,
            final_residual_diagnostic_products=1,actual_composite_rescales=schedule['actual_composite_rescales']+1,rotations=14,reduction_additions=14,
            rounded_first_affines=1,tracked_updates=c.updates,integer_affine_calls=c.updates,refreshes=0)
        cases.append(dict(name=case['name'],index=index,key_count=c.key_count,valid_rows=case['valid_rows'],updates=c.updates,domain=list(c.domain),
            rounded_first_weight=c.first_weight,rounded_first_bias=c.first_bias,definition_sha256=sha(json.dumps(definition,sort_keys=True,separators=(',',':')).encode()),
            fixture_source_sha256=PINS['gain4_fixtures.py'],input_sha256=array_sha(value),input_mask_sha256=array_sha(layout.input_mask),
            key_mask_sha256=sha(case['key_mask'].astype(np.uint8).tobytes()),oracle_sha256={row['label']:row['expected_array_sha256'] for row in checkpoints},
            input_level=49,input_scale=DELTA,prefix_reduced_level=25,prefix_reduced_scale=DELTA,prefix_source_immutability_required=True,prefix_preserves_scale=True,
            input_payload_bytes=_ct_bytes(49),fixed_gate=1e-6,counts=counts,checkpoints=checkpoints,schedule=schedule,public_fixture_diagnostics=details))
    if len(flat)!=54 or tuple(c['name'] for c in cases)!=('K128_rows16','K15_rows9'):raise ValueError('fixed two-case order/count differs')
    total={name:sum(c['counts'][name] for c in cases) for name in cases[0]['counts']}
    return dict(schema=SCHEMA,scope='Public metadata/original fixed fixture hashes only; no backend,keygen,model,HE or accuracy pass.',
        source_sha256=dict(PINS),profile=profile,common_ring=dict(N=131072,slots=65536,composite_degree=2,depth=49,dnum=8,q_count=100,p_count=14,scale=DELTA),
        cases=cases,checkpoints=flat,counts=total,required_rotation_indices=list(rotations),full_rotation_inventory_count=130,rotation_subset_verified=True,
        rotation_inventory_sha256=sha(json.dumps(list(union)).encode()),full_store_refresh_key_count=106,full_store_refresh_keys_preserved=True,inputs=2,outputs=54,
        io=dict(input_payload_bytes=2*_ct_bytes(49),output_payload_bytes=sum(r['payload_bytes'] for r in flat),header_key_plaintext_and_temporary_bytes_excluded=True),
        client_gate=dict(absolute=1e-6,all_physical_slots=65536,unchanged_original_Newton=True,true_inverse_residual_invariant_and_quotient_gates=True),
        ordering='Both fresh encryptedL49 inputs prefix-reduce25; all54 server outputs finalize before client decode. Final e_n is an additional genuine square of e_(n-1).',
        limitations=['Gain4 changes real encoding targets only; no precision improvement is inferred.','Static original domains/coefficients/iteration counts/gates remain unchanged.','Public profile flags are provenance readback, not this module executing qp_is_secure or keygen.','Logical primitive counts exclude key loading, encoding internals and cleanup; IO bytes exclude headers and keys.'])
