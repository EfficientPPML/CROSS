"""Serial arithmetic for the fixed 18-checkpoint BSGS component proof.

The caller owns/authenticates the keyless context, both fresh ciphertexts and
the output files. This helper owns only its ordinary compiled arithmetic and
scoped public NTT provider. It never calls a codec or closes the context.
Synthetic tests replace the dependency seam explicitly; they are not HE.

Any exception must escape the entered server key-loader scope. That loader's
failure quarantine and dedicated-process exit remain required: a failed array
barrier is not evidence that host key mappings can safely be released.
"""
from collections import Counter
import hashlib
from pathlib import Path
import sys

from cleanup import cleanup_signals
from component_contract import OWNER_SHA, numerical_plan

_ACTIVE = False
_QUARANTINE = []
_COUNT_NAMES = {
    'rotations': 'rotations',
    'public_multiplications': 'public_products',
    'ciphertext_additions': 'ciphertext_additions',
    'actual_composite_rescales': 'composite_rescales',
    'public_multiplication_levels': 'critical_public_levels',
}


def _dependencies():
    """Production imports are deferred until the authenticated worker calls us."""
    from encrypted_ntt import enable_scoped_ntt_subsets
    from encrypted_packed_qwen import CompiledArithmetic
    from encrypted_bsgs_score_routing import BSGSScoreRouting, FactoredScoreLayout
    return enable_scoped_ntt_subsets, CompiledArithmetic, BSGSScoreRouting, FactoredScoreLayout


def _counts(values):
    if (any(name not in _COUNT_NAMES for name in values) or
            any(type(value) is not int or value < 0 for value in values.values())):
        raise ValueError('unexpected routing operation counts')
    return {public: values.get(private, 0) for private, public in _COUNT_NAMES.items()}


def _raise_cleanup(primary, errors):
    if primary is not None:
        for label, error in errors:
            if error is not primary:
                primary.add_note(label + ': ' + repr(error))
        return
    if errors:
        selected = next((error for _, error in errors if not isinstance(error, Exception)), errors[0][1])
        for label, error in errors:
            if error is not selected:
                selected.add_note(label + ': ' + repr(error))
        raise selected


def exercise(ctx, x, ones, *, checkpoint):
    """Save 18 synchronized outputs via ``checkpoint(index, value, public_row)``.

    The callback receives exactly case/direction/label/level/scale/counts; counts
    are the per-checkpoint increments in the independently pinned public plan.
    It must save immediately and must not mutate ciphertexts or borrowed state.
    No list of checkpoint ciphertexts is returned or retained across maps.
    """
    global _ACTIVE
    if _ACTIVE or _QUARANTINE:
        raise RuntimeError('serial component is active or cleanup remains quarantined')
    if not callable(checkpoint):
        raise TypeError('checkpoint callback required')
    plan = numerical_plan()
    owner_path = Path(__file__).with_name('encrypted_bsgs_score_routing.py')
    if hashlib.sha256(owner_path.read_bytes()).hexdigest() != OWNER_SHA:
        raise ValueError('exact reviewed BSGS owner required')
    if (ctx.secret_key is not None or ctx._param_cache.secret_key is not None or
            ctx.parameters.get('secret_key') is not None):
        raise ValueError('keyless server context required')

    _ACTIVE = True
    arithmetic = provider = owner = None
    entered = False
    # Each record owns the original array independently of its mutable wrapper.
    held = []
    original_payloads = ()
    next_index = 0
    current_case = current_direction = None
    previous_counts = Counter()
    totals = Counter()
    completed = []
    preparation = dict(level_reduction_calls=0, ciphertext_products=0, composite_rescales=0)

    def retain(value):
        record = (value, value.polynomial, owner._fingerprint(value))
        held.append(record)
        return value

    def check_held():
        owner._guard()
        for value, payload, state in held:
            if value.polynomial is not payload or owner._fingerprint(value) != state:
                raise ValueError('component retained input/result changed')

    def synchronize(payload):
        payload.block_until_ready()

    def note(label, value, cumulative):
        nonlocal next_index, previous_counts
        check_held()
        if next_index >= 18:
            raise ValueError('extra routing checkpoint')
        group_index, within = divmod(next_index, 9)
        group = plan['cases'][group_index]
        expected = group['checkpoints'][within]
        if (current_case != group['name'] or current_direction != expected['direction'] or
                label != expected['label']):
            raise ValueError('routing checkpoint order differs from pinned plan')
        count = Counter(cumulative)
        if any(count[name] < previous_counts[name] for name in previous_counts):
            raise ValueError('routing cumulative counters decreased')
        increments = _counts({name: count[name] - previous_counts[name]
                              for name in count.keys() | previous_counts.keys()})
        if increments != expected['counts']:
            raise ValueError('routing checkpoint counts differ from pinned plan')
        owner._validate(value, level=expected['level'], scale=expected['scale'])
        payload, state = value.polynomial, owner._fingerprint(value)
        # Retain through callback failure and cleanup; normal paths remove the
        # temporary record after checking the actual original array again.
        record = (value, payload, state)
        held.append(record)
        synchronize(payload)
        public_row = dict(case=current_case, direction=current_direction, label=label,
                          level=expected['level'], scale=expected['scale'], counts=dict(increments))
        checkpoint(next_index, value, public_row)
        synchronize(payload)
        check_held()
        owner._validate(value, level=expected['level'], scale=expected['scale'])
        held.pop()
        previous_counts = count
        totals.update(increments)
        next_index += 1

    def reduce(value, level):
        check_held()
        owner._validate(value, level=49, scale=plan['profile']['canonical_scale'])
        result = retain(ctx.he_level_reduce[49, level].level_reduce(value))
        synchronize(result.polynomial)
        check_held()
        owner._validate(result, level=level, scale=value._ckks_scale)
        preparation['level_reduction_calls'] += 1
        return result

    try:
        original_payloads = (x.polynomial, ones.polynomial)
        enable, Arithmetic, Routing, Layout = _dependencies()
        entered = True
        provider = enable(ctx)
        arithmetic = Arithmetic(ctx, low_memory=True, preserve_dispatch_cache=True)
        owner = Routing(arithmetic, Layout(7, 15), progress=note)
        for value in (x, ones):
            owner._validate(value, level=49, scale=plan['profile']['canonical_scale'])
            retain(value)
            synchronize(value.polynomial)
        check_held()
        original_records = tuple(held)

        for case in plan['cases']:
            current_case = case['name']
            if current_case == 'canonical':
                route_input = reduce(x, 5)
            elif current_case == 'noncanonical':
                left, right = reduce(x, 6), reduce(ones, 6)
                check_held()
                route_input = retain(arithmetic.multiply(left, right))
                synchronize(route_input.polynomial)
                check_held()
                preparation['ciphertext_products'] += 1
                preparation['composite_rescales'] += 1
            else:
                raise ValueError('unsupported fixed component case')
            owner._validate(route_input, level=case['input_level'], scale=case['input_scale'])
            current_direction = 'forward'
            forward = retain(owner.forward(route_input, gain=case['gain']))
            synchronize(forward.polynomial)
            check_held()
            current_direction = 'roundtrip_inverse'
            roundtrip = retain(owner.inverse(forward))
            synchronize(roundtrip.polynomial)
            check_held()
            current_direction = 'hostile_inverse'
            independent = retain(owner.inverse(route_input))
            synchronize(independent.polynomial)
            check_held()
            completed.append(dict(case=current_case, input_level=case['input_level'],
                                  input_scale=case['input_scale'], checkpoints=9))
            # Every current array has completed before retirement. Original
            # inputs remain pinned for all cases and final cleanup.
            held[:] = original_records
            route_input = forward = roundtrip = independent = None
            left = right = None
        check_held()
        if (next_index != plan['checkpoint_count'] or dict(totals) != plan['route_totals'] or
                _counts(owner.counts) != plan['route_totals']):
            raise ValueError('complete ordered routing/count gate failed')
        if preparation != {name: plan['input_preparation'][name] for name in preparation}:
            raise ValueError('actual input preparation counts differ')
        return dict(checkpoints_completed=next_index, route_totals=dict(totals),
                    input_preparation=preparation, cases=completed,
                    input_metadata_unchanged=True, synchronous_outputs=True,
                    context_borrowed=True, codecs_called=False)
    finally:
        primary = sys.exception()
        errors = []

        def attempt(label, function):
            try:
                return function()
            except BaseException as error:
                errors.append((label, error))
                return None

        try:
            with cleanup_signals():
                arrays = {id(payload): payload for payload in original_payloads}
                arrays.update((id(payload), payload) for _, payload, _ in held)
                if owner is not None:
                    # The owner preserves failed original-array barriers even
                    #after clearing its ordinary working-retention list.
                    for group in owner._failed_arrays:
                        arrays.update((id(payload), payload) for payload in group)
                    for _, payload, _ in owner._retained:
                        arrays[id(payload)] = payload
                for payload in arrays.values():
                    attempt('component original-array barrier', lambda payload=payload: synchronize(payload))
                if errors or (entered and primary is not None):
                    # A primitive may fail in _finish before returning its new
                    #array to the owner. Successful barriers on reachable inputs
                    #cannot establish that pending result's readiness. Every
                    #entered-body failure therefore retains the compiler and
                    #provider, even when these reachable barriers all succeed.
                    #The outer loader must likewise quarantine its key mappings.
                    _QUARANTINE.append((ctx, arithmetic, provider, owner, tuple(arrays.values())))
                else:
                    if arithmetic is not None:
                        attempt('arithmetic working cleanup', lambda: arithmetic._clear_working_caches())
                        for name in ('rotation', '_plaintext_multiply', '_rescale'):
                            helper = attempt('compiled helper lookup', lambda name=name: getattr(arithmetic, name, None))
                            if helper is not None:
                                attempt('compiled helper cleanup', lambda helper=helper: helper.clear(executables=True))
                        compiler = attempt('multiplication compiler lookup',
                                           lambda: getattr(arithmetic, '_multiplication_compiler', None))
                        if compiler is not None:
                            attempt('multiplication compiler cleanup', lambda: compiler.clear_executables())
                    if provider is not None:
                        attempt('NTT provider cleanup', lambda: provider.close())
                    if errors:
                        _QUARANTINE.append((ctx, arithmetic, provider, owner, tuple(arrays.values())))
                _raise_cleanup(primary, errors)
        finally:
            _ACTIVE = False
