"""Reviewed held-directory identity helpers, copied without model imports."""
import os
import stat
import shutil
from pathlib import Path

def open_owned_directory(path):
    """Pin the just-created directory inode until cleanup completes.

    This detects path replacement and prevents inode reuse. It is not an OS
    sandbox against a same-user child moving other entries into its own tree.
    """
    descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        status = os.fstat(descriptor)
        return descriptor, {'device': status.st_dev, 'inode': status.st_ino}
    except BaseException as error:
        try:
            os.close(descriptor)
        except BaseException as cleanup_error:
            error.add_note(f'Directory handle cleanup also failed: {cleanup_error}')
        raise

def remove_owned_directory(path, descriptor, identity):
    """Remove only the still-identical directory; retain moved/replaced paths.

    The identity check is a concurrency guard, not an atomic defense against
    arbitrary same-user directory manipulation during recursive deletion.
    """
    if descriptor is None or identity is None:
        raise RuntimeError('owned directory identity was not acquired; retained')
    held = os.fstat(descriptor)
    if {'device': held.st_dev, 'inode': held.st_ino} != identity:
        raise RuntimeError('owned directory descriptor identity changed; retained')
    try:
        current = path.lstat()
    except FileNotFoundError:
        if held.st_nlink == 0:
            return True  # The actual original directory was already removed.
        raise RuntimeError('owned directory was moved; original files retained')
    if stat.S_ISLNK(current.st_mode):
        raise RuntimeError('owned directory was replaced by a symlink; retained')
    if (not stat.S_ISDIR(current.st_mode)
            or {'device': current.st_dev, 'inode': current.st_ino} != identity):
        raise RuntimeError('owned directory identity was replaced; retained')
    shutil.rmtree(path)
    return not path.exists() and not path.is_symlink()

def check_owned_directory(path, descriptor, identity):
    held=os.fstat(descriptor);current=path.lstat()
    if (identity!={'device':held.st_dev,'inode':held.st_ino} or not stat.S_ISDIR(current.st_mode)
            or identity!={'device':current.st_dev,'inode':current.st_ino}):
        raise RuntimeError('owned public cache directory moved or replaced')
