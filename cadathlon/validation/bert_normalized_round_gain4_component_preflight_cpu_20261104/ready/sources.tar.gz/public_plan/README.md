This is a public-only plan for the proposed three-process BSGS routing proof.
It loads no key/ciphertext payload, model asset, private fixture or backend.
The four copied inputs are byte-pinned in input_sources.json. In particular,
inputs/fixtures_predecessor.py is unchanged; its generator creates x and the
second public input is all ones. No numerical outcome was used to select them.

`plan.fixture_arrays()` returns immutable float64 x/ones arrays.
`plan.oracle(source, inverse=False, gain=1.)` returns the three independent
coordinate checkpoints. Inverse has no gain and starts with a complete dense
rotation, including hostile padding. `plan.build_plan()` returns the two fixed
pairs (canonical/gain1 and actual-product/gain1/8), all18 checkpoint expectations,
real binary64 metadata, separate route/prestage counts and raw IO arithmetic.

All output checkpoint arrays are recomputable from public x; the report stores
only their hashes, support counts and extrema. The metadata plan retains the
actual float products/divisions in their original order. Tests independently
round exact Fraction operations at every binary64 operation and compare the
reviewed public scale helper. This certifies neither CKKS error nor encoding
precision. Exact integer QP/P-coverage and the36-key subset of the existing130
inventory are checked from the frozen public profile/plan, without key reads.

The expected route totals are72 rotations,168 public products,156 adds and42
composite rescales; the separate noncanonical x*ones prestage has one CT product
and one rescale. Three real level reductions are required. The18 checkpoints
cover1,179,648 physical slots and148MiB raw output payload; two fresh L49 inputs
add200MiB. Atomic write overlap may add a100MiB input or12MiB output temporary,
plus headers and an explicit operational reserve. These are file payload sizes,
not process/device memory estimates or a performance prediction.

All18 server outputs, source identities and successful server retirement must
be authenticated before client validation may open private keys and decode.
The later harness must independently enforce these gates and use the ordinary
authenticated loader. This public plan authorizes no encrypted launch.
