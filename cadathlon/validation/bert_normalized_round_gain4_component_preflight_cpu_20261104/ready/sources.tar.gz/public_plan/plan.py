"""Independent public fixture/coordinate/metadata plan; no HE imports or reads."""
from pathlib import Path
from collections import Counter
import hashlib
import importlib.util
import json
import math
import numpy as np

HERE = Path(__file__).resolve().parent
SLOTS = 65536
DEGREE = 131072
LAYOUT = (256, 512)
TILE = 7
OFFSET = 15
TILE_SHIFT = TILE * 16 * 16
MIB = 1 << 20
SOURCE_NAMES = ('plan.py', 'test_plan.py', 'README.md', 'input_sources.json',
    'inputs/fixtures_predecessor.py', 'inputs/profile.json',
    'inputs/full_key_plan.json', 'inputs/encrypted_scale_planning.py')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def authenticated_inputs():
    origins = json.loads((HERE/'input_sources.json').read_bytes())
    if set(origins) != {'fixtures_predecessor.py', 'profile.json',
                       'full_key_plan.json', 'encrypted_scale_planning.py'}:
        raise ValueError('exact public input inventory required')
    for name, descriptor in origins.items():
        if sha((HERE/'inputs'/name).read_bytes()) != descriptor['sha256']:
            raise ValueError('pinned public input changed: '+name)
    return origins


def fixture_arrays():
    """Execute the unchanged predecessor generator, then own immutable bytes."""
    authenticated_inputs()
    path = HERE/'inputs/fixtures_predecessor.py'
    spec = importlib.util.spec_from_file_location('pinned_predecessor_fixture', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    x = np.asarray(module.values(), dtype='<f8')
    if x.shape != (SLOTS,) or not np.isfinite(x).all():
        raise ValueError('fixed finite full-slot fixture required')
    return tuple(np.frombuffer(v.tobytes(), dtype='<f8') for v in
                 (x, np.ones(SLOTS, dtype='<f8')))


def _source(source):
    a = np.asarray(source)
    if a.shape != (SLOTS,) or a.dtype.kind not in 'fiu' or not np.isfinite(a).all():
        raise ValueError('finite real full-slot source required')
    a = np.asarray(a, dtype=np.float64)
    if not np.isfinite(a).all():
        raise ValueError('finite binary64 source required')
    return a


def oracle(source, *, inverse=False, gain=1.0):
    """Direct coordinates, independent of owner masks/diagonals/BSGS loops."""
    source = _source(source)
    if type(inverse) is not bool or type(gain) is not float or gain not in (1., .125):
        raise ValueError('exact public direction/gain required')
    if inverse and gain != 1.:
        raise ValueError('inverse has no public gain operation')
    if inverse:
        # Rotation exposes the entire hostile source, not a sparse source mask.
        extracted = source[(np.arange(SLOTS) + TILE_SHIFT) % SLOTS].copy()
        compact = np.zeros(SLOTS); expanded = np.zeros(SLOTS)
        for row in range(16):
            key = (row + OFFSET) % 16
            for head in range(12):
                value = source[row*4096 + (TILE*16+key)*16 + head]
                compact[row*4096 + head] = value
                expanded[row*4096 + head*64] = value
        return {'key tile extraction': extracted, 'key extraction': compact,
                'head expansion': expanded}
    compact = np.zeros(SLOTS); local = np.zeros(SLOTS); placed = np.zeros(SLOTS)
    for row in range(16):
        key = (row + OFFSET) % 16
        for head in range(12):
            value = source[row*4096 + head*64] * gain
            compact[row*4096 + head] = value
            local[row*4096 + key*16 + head] = value
            placed[row*4096 + (TILE*16+key)*16 + head] = value
    return {'head compaction': compact, 'local key placement': local,
            'key placement': placed}


def required_keys():
    """Both signs of four babies and each nonzero giant/outer tile shift."""
    head = {63*k for k in (1, 2, 3, 4, 8)}
    key = {16*k for k in (1, 2, 3, 4, 8, 12)}
    outer = {256*k for k in range(1, 8)}
    return tuple(sorted({s % SLOTS for x in head | key | outer for s in (x, -x)}))


def divisor(q, level):
    if type(level) is not int or not 1 <= level < len(q)//2:
        raise ValueError('valid CD2 source level required')
    return q[2*level] * q[2*level+1]


def weighted_scale(source, target, d):
    # Replay actual Python binary64 multiply/divide order, including converting
    # the exact public integer dropped-pair divisor to binary64 at each use.
    before = target * d
    encoding = before / source
    product = source * encoding
    output = product / d
    if not all(math.isfinite(v) and v > 0 for v in (before, encoding, product, output)):
        raise ValueError('unrepresentable metadata plan')
    return dict(divisor=d, target_before_rescale=before, plaintext_scale=encoding,
                product_scale=product, output_scale=output)


def payload_bytes(level):
    if type(level) is not int or not 0 <= level <= 49:
        raise ValueError('valid common-ring level required')
    return 1*2*DEGREE*(2*(level+1))*4


def _stage_cost(terms):
    groups = terms // 4
    return dict(rotations=3+groups-1, public_products=terms,
        ciphertext_additions=3*groups+groups-1,
        composite_rescales=groups, critical_public_levels=1)


def _map_rows(q, delta, level, scale, inverse):
    labels = ('key tile extraction', 'key extraction', 'head expansion') if inverse else (
              'head compaction', 'local key placement', 'key placement')
    terms = (0, 16, 12) if inverse else (12, 16, 0)
    rows = []
    for label, count in zip(labels, terms):
        detail = None
        if count:
            detail = weighted_scale(scale, delta, divisor(q, level))
            level -= 1; scale = detail['output_scale']; cost = _stage_cost(count)
        else:
            cost = dict(rotations=1, public_products=0, ciphertext_additions=0,
                        composite_rescales=0, critical_public_levels=0)
        rows.append(dict(label=label, level=level, scale=scale, scale_hex=scale.hex(),
            noise_scale_degree=1, q_prefix=q[:2*(level+1)],
            payload_shape=[1,2,*LAYOUT,2*(level+1)], payload_dtype='uint32',
            payload_bytes=payload_bytes(level), counts=cost, weighted_metadata=detail))
    return rows


def build_plan():
    origins = authenticated_inputs()
    record = json.loads((HERE/'inputs/profile.json').read_bytes())
    profile = record['profile']; q = profile['q']; p = profile['p']; delta = profile['canonical_scale']
    if (profile['degree'] != DEGREE or len(q) != 100 or len(p) != 14 or
            profile['dnum'] != 8 or any(type(x) is not int or not 1 < x < 2**31 for x in q+p)):
        raise ValueError('exact common Barrett p60 profile required')
    actual_bits = math.prod(q+p).bit_length(); alpha = math.ceil(len(q)/8)
    coverage = all(math.prod(p) >= math.prod(q[i:i+alpha]) for i in range(0,len(q),alpha))
    if actual_bits > 3523 or not coverage:
        raise ValueError('actual QP/security or P-coverage failed')
    keys = required_keys(); full = json.loads((HERE/'inputs/full_key_plan.json').read_bytes())
    supplied = full['union_keys']
    if (full['passed'] is not True or len(supplied) != 130 or len(set(supplied)) != 130 or
            len(keys) != 36 or not set(keys) <= set(supplied)):
        raise ValueError('all36 routing keys must belong to exact public130 inventory')
    x, ones = fixture_arrays(); d = divisor(q,6); product_before = delta*delta
    noncanonical = product_before/d
    cases = []; total = Counter(); output_bytes = 0
    for name,gain,scale in (('canonical',1.,delta),('noncanonical',.125,noncanonical)):
        forward = oracle(x,gain=gain); inverse = oracle(forward['key placement'],inverse=True)
        hostile = oracle(x,inverse=True)
        frows = _map_rows(q,delta,5,scale,False)
        irows = _map_rows(q,delta,3,frows[-1]['scale'],True)
        hrows = _map_rows(q,delta,5,scale,True)
        checkpoints = []
        for direction,rows,expected in (('forward',frows,forward),('roundtrip_inverse',irows,inverse),
                                        ('hostile_inverse',hrows,hostile)):
            for row in rows:
                value = expected[row['label']]
                checkpoints.append(dict(row,direction=direction,
                    expected_array_sha256=sha(value.astype('<f8',copy=False).tobytes()),
                    expected_nonzero_slots=int(np.count_nonzero(value)),
                    expected_min=float(value.min()),expected_max=float(value.max()),strict_absolute_gate=1e-6))
                total.update(row['counts']);output_bytes += row['payload_bytes']
        cases.append(dict(name=name,gain=gain,input_level=5,input_scale=scale,
                          input_scale_hex=scale.hex(),checkpoints=checkpoints))
    return dict(schema='bsgs-routing-public-proof-plan-v1',passed=True,
        scope='Independent public coordinate/metadata/count/storage plan; no key or ciphertext payload/model asset/backend access or HE, no noise or performance claim.',
        source_inputs=origins,profile=dict(degree=DEGREE,q=q,p=p,canonical_scale=delta,
            actual_QP_bit_length=actual_bits,security_ceiling=3523,P_coverage=coverage,alpha=alpha,parts=8),
        required_rotation_indices=list(keys),supplied_public_rotation_count=len(supplied),all_required_keys_supplied=True,
        fixtures=dict(x_sha256=sha(x.tobytes()),ones_sha256=sha(ones.tobytes()),
            x_generator_sha256=origins['fixtures_predecessor.py']['sha256']),
        input_preparation=dict(fresh_input_level=49,canonical_reduce_to=5,product_operand_level=6,
            product_drop_moduli=q[12:14],product_divisor=d,product_before_rescale_scale=product_before,
            noncanonical_output_level=5,noncanonical_output_scale=noncanonical,
            scale_ratio_to_canonical=noncanonical/delta,ciphertext_products=1,composite_rescales=1,
            level_reduction_calls=3,manual_metadata_relabel=False),
        cases=cases,checkpoint_count=18,compared_physical_slots=18*SLOTS,route_totals=dict(total),
        storage=dict(two_fresh_L49_ciphertexts_bytes=2*payload_bytes(49),checkpoint_payload_bytes=output_bytes,
            total_stored_payload_bytes=2*payload_bytes(49)+output_bytes,
            per_input_write_temporary_max_bytes=payload_bytes(49),
            per_checkpoint_write_temporary_max_bytes=max(r['payload_bytes'] for c in cases for r in c['checkpoints']),
            scope='Raw payload arithmetic only; add headers, atomic write overlap and reserve. Excludes external keys, controls, compiler, devices and process memory.'),
        gates=dict(all18_completed_and_authenticated_before_any_decode=True,client_context_retired_before_server=True,
            terminal_success_before_client_private_read=True,original_external_keys_never_removed=True,
            ordered_artifact_roles_required=True,all_slot_absolute_gate=1e-6,no_healthy_deadline=True))


if __name__ == '__main__':
    print(json.dumps(build_plan(),sort_keys=True,indent=2,allow_nan=False))
