"""Public coordinate and independently rounded metadata checks, no backend."""
from fractions import Fraction
import importlib.util
import json
import sys
import numpy as np
import pytest
import plan


@pytest.fixture(scope='module')
def report():
    return plan.build_plan()


def load(name):
    spec=importlib.util.spec_from_file_location('public_'+name,plan.HERE/'inputs'/f'{name}.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def rounded_binary(op,a,b):
    # Round both public operands as Python's float operations do, then compute
    # the exact rational operation and round once to binary64 nearest/even.
    a=Fraction.from_float(float(a));b=Fraction.from_float(float(b))
    return float(a*b if op=='mul' else a/b)


def test_original_fixture_bytes_and_immutable_arrays():
    x,one=plan.fixture_arrays();old=load('fixtures_predecessor')
    np.testing.assert_array_equal(x,old.values());np.testing.assert_array_equal(one,np.ones(plan.SLOTS))
    for a in (x,one):
        assert isinstance(a.base,bytes) and not a.flags.writeable
        with pytest.raises(ValueError):a.flags.writeable=True
    assert np.count_nonzero(x)==plan.SLOTS and np.max(np.abs(x))>39.


@pytest.mark.parametrize('gain',[1.,.125])
def test_forward_and_roundtrip_match_unchanged_predecessor(gain):
    x,_=plan.fixture_arrays();forward=plan.oracle(x,gain=gain)
    inverse=plan.oracle(forward['key placement'],inverse=True)
    expected=load('fixtures_predecessor').oracle(x,gain)
    for label,array in (forward|inverse).items():np.testing.assert_array_equal(array,expected[label])


@pytest.mark.parametrize('gain',[1.,.125])
def test_forward_fullslot_coordinate_oracle_independent_tensor_scatter(gain):
    x=np.arange(plan.SLOTS,dtype=np.float64)+.25
    got=plan.oracle(x,gain=gain)
    source=x.reshape(16,4096)[:,:768:64]*gain
    compact=np.zeros((16,4096));compact[:,:12]=source
    local=np.zeros((16,256,16));placed=np.zeros_like(local)
    rows=np.arange(16);keys=(rows-1)%16
    local[rows,keys,:12]=source;placed[rows,112+keys,:12]=source
    for name,value in [('head compaction',compact),('local key placement',local),('key placement',placed)]:
        np.testing.assert_array_equal(got[name],value.ravel())


def test_hostile_inverse_checks_every_rotated_slot_and_separate_gather():
    x=np.arange(plan.SLOTS,dtype=np.float64)+.25
    got=plan.oracle(x,inverse=True)
    expected_rotation=np.concatenate((x[1792:],x[:1792]))
    np.testing.assert_array_equal(got['key tile extraction'],expected_rotation)
    assert np.count_nonzero(got['key tile extraction'])==65536
    source=x.reshape(16,256,16);rows=np.arange(16);values=source[rows,112+(rows-1)%16,:12]
    compact=np.zeros((16,4096));expanded=np.zeros((16,64,64))
    compact[:,:12]=values;expanded[:,:12,0]=values
    np.testing.assert_array_equal(got['key extraction'],compact.ravel())
    np.testing.assert_array_equal(got['head expansion'],expanded.ravel())
    assert np.count_nonzero(got['key extraction'])==np.count_nonzero(got['head expansion'])==192


def test_dense_inverse_is_not_roundtrip_source_mask():
    x,_=plan.fixture_arrays();raw=plan.oracle(x,inverse=True)
    forward=plan.oracle(x);roundtrip=plan.oracle(forward['key placement'],inverse=True)
    assert all(not np.array_equal(raw[k],roundtrip[k]) for k in raw)


def test_fixed_two_pairs_and_all18_levels(report):
    assert [(c['name'],c['gain']) for c in report['cases']]==[('canonical',1.),('noncanonical',.125)]
    for c in report['cases']:
        assert [x['level'] for x in c['checkpoints']]==[4,3,3,3,2,1,5,4,3]
        assert [x['direction'] for x in c['checkpoints']]==['forward']*3+['roundtrip_inverse']*3+['hostile_inverse']*3
        for row in c['checkpoints']:
            assert row['noise_scale_degree']==1 and row['payload_dtype']=='uint32'
            assert row['payload_shape']==[1,2,256,512,2*(row['level']+1)]
            assert row['q_prefix']==report['profile']['q'][:2*(row['level']+1)]
            assert row['strict_absolute_gate']==1e-6
    assert report['checkpoint_count']==18 and report['compared_physical_slots']==1179648


def test_genuine_product_metadata_before_any_route(report):
    q=report['profile']['q'];delta=report['profile']['canonical_scale'];r=report['input_preparation']
    assert r['product_drop_moduli']==q[12:14] and r['product_divisor']==q[12]*q[13]
    before=rounded_binary('mul',delta,delta);after=rounded_binary('div',before,q[12]*q[13])
    assert r['product_before_rescale_scale']==before and r['noncanonical_output_scale']==after
    assert report['cases'][1]['input_scale']==after and after!=delta
    assert r['noncanonical_output_level']==5 and r['product_operand_level']==6
    assert r['ciphertext_products']==r['composite_rescales']==1 and r['level_reduction_calls']==3
    assert r['manual_metadata_relabel']is False


@pytest.mark.parametrize('case',[0,1])
def test_every_scale_replays_binary64_rounds_and_reviewed_helper(report,case):
    c=report['cases'][case];delta=report['profile']['canonical_scale'];q=report['profile']['q']
    helper=load('encrypted_scale_planning')
    scale=c['input_scale'];level=5
    for i,row in enumerate(c['checkpoints']):
        if i==6:scale=c['input_scale'];level=5
        if row['weighted_metadata'] is not None:
            d=q[2*level]*q[2*level+1]
            before=rounded_binary('mul',delta,d)
            encoding=rounded_binary('div',before,scale)
            product=rounded_binary('mul',scale,encoding)
            result=rounded_binary('div',product,d)
            detail=row['weighted_metadata']
            assert [detail[n] for n in ['target_before_rescale','plaintext_scale','product_scale','output_scale']]==[before,encoding,product,result]
            assert helper.weighted_sum_scale([scale]*4,delta,d)['output_scale']==result
            scale=result;level-=1
        assert row['level']==level and row['scale']==scale and row['scale_hex']==scale.hex()


def test_counts_cover_six_maps_and_product_separately(report):
    assert report['route_totals']==dict(rotations=72,public_products=168,ciphertext_additions=156,composite_rescales=42,critical_public_levels=12)
    for c in report['cases']:
        for start in (0,3,6):
            assert sum(r['counts']['rotations'] for r in c['checkpoints'][start:start+3])==12
    assert sum(r['counts']['composite_rescales'] for c in report['cases'] for r in c['checkpoints'])==42


def test_raw_io_arithmetic_not_peak_memory(report):
    storage=report['storage']
    assert storage['two_fresh_L49_ciphertexts_bytes']==200*plan.MIB
    assert storage['checkpoint_payload_bytes']==148*plan.MIB
    assert storage['total_stored_payload_bytes']==348*plan.MIB
    assert storage['per_checkpoint_write_temporary_max_bytes']==12*plan.MIB
    assert 'Excludes' in storage['scope']


def test_exact_public_ring_and_supplied_key_union(report):
    p=report['profile'];assert p['actual_QP_bit_length']==3403 and p['P_coverage']is True and p['alpha']==13 and p['parts']==8
    assert report['all_required_keys_supplied']is True and report['supplied_public_rotation_count']==130
    keys=report['required_rotation_indices'];assert len(keys)==len(set(keys))==36
    assert set(keys)=={(-k)%65536 for k in keys} and 0 not in keys
    assert {63,126,189,252,504,16,32,48,64,128,192,1792,65536-1792}<=set(keys)


@pytest.mark.parametrize('bad',[np.ones(4),np.ones(65536,dtype=bool),np.ones(65536,dtype=complex),np.full(65536,np.nan),np.full(65536,np.inf)])
def test_invalid_fixture_values_rejected(bad):
    with pytest.raises(ValueError):plan.oracle(bad)


@pytest.mark.parametrize('kwargs',[{'gain':True},{'gain':1},{'gain':.5},{'inverse':1},{'inverse':True,'gain':.125}])
def test_fixed_direction_gain_types(kwargs):
    with pytest.raises(ValueError):plan.oracle(np.zeros(65536),**kwargs)


def test_public_plan_imports_no_backend_or_model(report):
    forbidden=('jax','jaxlib','torch','transformers','jaxite_word')
    assert not any(name==x or name.startswith(x+'.') for name in sys.modules for x in forbidden)
    assert all(report['gates'].values())
    json.dumps(report,allow_nan=False)
