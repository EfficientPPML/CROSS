"""Synthetic primitive/key/field doubles exercising the real frozen BSGS loops.

No backend, key payload, model, private fixture or HE is used. The uint32 RNS
shape is a placeholder; the payload holds independent clear binary64 slots.
"""
from collections import Counter
from pathlib import Path
from types import SimpleNamespace
import importlib.util
import math
import sys

import numpy as np
import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'common'))
import component_arithmetic as component
from component_contract import numerical_plan
from encrypted_bsgs_score_routing import BSGSScoreRouting, required_rotation_indices

PLAN = numerical_plan()
Q, P = tuple(PLAN['profile']['q']), tuple(PLAN['profile']['p'])
DELTA = PLAN['profile']['canonical_scale']


class Barrett:
    computation_format_is_standard = True
    def __init__(self, moduli):
        self.moduli = tuple(moduli)


class Payload:
    dtype = np.dtype('uint32')
    def __init__(self, data, level, events):
        self.data = np.frombuffer(np.asarray(data, dtype='float64').tobytes(), dtype='float64')
        self.shape = (1, 2, 256, 512, 2*(level+1))
        self.events = events
        self.failure = None
    def devices(self):
        return {'synthetic-cpu'}
    def block_until_ready(self):
        self.events.append(('barrier', id(self)))
        if self.failure is not None:
            raise self.failure
        return self


class Value:
    batch, num_elements, degree = 1, 2, 131072
    r, c = 256, 512
    degree_layout, precision, _ckks_nsd = (256, 512), 32, 1
    def __init__(self, data, level, scale, events):
        self.level = level
        self._ckks_scale = scale
        self.moduli = Q[:2*(level+1)]
        self.num_moduli = len(self.moduli)
        self.polynomial = Payload(data, level, events)
        self.ntt_ctx = SimpleNamespace(moduli=self.moduli, ff_ctx=Barrett(self.moduli))


class Helper:
    def __init__(self, ctx, name):
        self.ctx, self.name = ctx, name
    def rotate(self, *args):
        raise AssertionError('synthetic arithmetic supplies the payload')
    multiply = multiply_encoded = rescale = rotate
    def clear(self, *, executables=False):
        self.ctx.events.append(('clear', self.name, executables))
        if self.name in self.ctx.cleanup_failures:
            raise self.ctx.cleanup_failures[self.name]


class Compiler:
    def __init__(self, ctx): self.ctx = ctx
    def clear_executables(self):
        self.ctx.events.append(('clear', 'compiler', True))
        if 'compiler' in self.ctx.cleanup_failures:
            raise self.ctx.cleanup_failures['compiler']


class Arithmetic:
    scale, refresher, progress = DELTA, None, None
    def __init__(self, ctx, *, low_memory=False, preserve_dispatch_cache=False):
        self.ctx, self.low_memory = ctx, low_memory
        ctx.events.append(('arithmetic', low_memory, preserve_dispatch_cache))
        self.rotation = Helper(ctx, 'rotation')
        self._plaintext_multiply = Helper(ctx, 'plaintext')
        self._rescale = Helper(ctx, 'rescale')
        self._multiplication_compiler = Compiler(ctx)
        ctx.arithmetic = self
    def _level(self, value): return value.level
    def _value(self, data, level, scale): return Value(data, level, scale, self.ctx.events)
    def _finish(self, value):
        value.polynomial.block_until_ready()
        return value
    def rotate(self, value, shift):
        self.ctx.events.append(('rotate', shift))
        return self._finish(self._value(np.roll(value.polynomial.data, -shift), value.level, value._ckks_scale))
    def weighted_sum(self, values, weights):
        self.ctx.events.append(('weighted', len(values)))
        level = min(v.level for v in values)
        divisor = math.prod(Q[2*level:2*level+2])
        source = values[0]._ckks_scale
        scale = (source*((DELTA*divisor)/source))/divisor
        data = sum(v.polynomial.data*w for v, w in zip(values, weights))
        return self._finish(self._value(data, level-1, scale))
    def add(self, left, right):
        self.ctx.events.append(('add',))
        return self._finish(self._value(left.polynomial.data+right.polynomial.data,
            min(left.level, right.level), left._ckks_scale))
    def multiply(self, left, right):
        self.ctx.events.append(('multiply', left.level, right.level))
        level = min(left.level, right.level)
        scale = left._ckks_scale*right._ckks_scale/math.prod(Q[2*level:2*level+2])
        result = self._value(left.polynomial.data*right.polynomial.data, level-1, scale)
        if self.ctx.bad_multiply:
            result._ckks_scale = DELTA
        return self._finish(result)
    def _prepare(self, *args): pass
    _lower = _ensure_capacity = _encode_public = _public_slots = _prepare
    def _clear_working_caches(self):
        self.ctx.events.append(('working_cleanup',))
        if 'working' in self.ctx.cleanup_failures:
            raise self.ctx.cleanup_failures['working']


class LevelReduce:
    def __init__(self, ctx): self.ctx = ctx
    def __getitem__(self, levels):
        source, destination = levels
        def lower(value):
            assert source == value.level == 49
            self.ctx.events.append(('level_reduce', source, destination))
            result = Value(value.polynomial.data, destination, value._ckks_scale, self.ctx.events)
            if self.ctx.bad_reduce:
                result._ckks_nsd = True
            return result
        return SimpleNamespace(level_reduce=lower)


def context():
    values = dict(degree=131072, num_slots=65536, composite_degree=2, dnum=8,
                  max_level=49, scaling_factor=DELTA, degree_layout=(256, 512),
                  q_towers=Q, p_towers=P, secret_key=None, batch=1)
    ctx = SimpleNamespace(**values, parameters={}, _param_cache=SimpleNamespace(**values),
        events=[], cleanup_failures={}, bad_reduce=False, bad_multiply=False)
    ctx.he_level_reduce = LevelReduce(ctx)
    k = ctx._param_cache
    k.ff_context_cls, k.per_level_rotation_keys = Barrett, False
    k.raw_rotation_keys = {i: {name: SimpleNamespace(shape=(8,114,131072), dtype=np.dtype('uint32'))
                              for name in ('a', 'b')} for i in required_rotation_indices()}
    k.coef_maps = {i: SimpleNamespace(shape=(131072,), dtype=np.dtype('int32'))
                  for i in required_rotation_indices()}
    return ctx


@pytest.fixture(autouse=True)
def synthetic(monkeypatch):
    assert not component._ACTIVE and not component._QUARANTINE
    def enable(ctx):
        ctx.events.append(('provider',))
        def close():
            ctx.events.append(('provider_close',))
            if 'provider' in ctx.cleanup_failures:
                raise ctx.cleanup_failures['provider']
        return SimpleNamespace(close=close)
    monkeypatch.setitem(sys.modules, 'encrypted_packed_qwen', SimpleNamespace(CompiledArithmetic=Arithmetic))
    monkeypatch.setitem(sys.modules, 'encrypted_ntt', SimpleNamespace(enable_scoped_ntt_subsets=enable))
    monkeypatch.setitem(sys.modules, 'jaxite_word', SimpleNamespace(Polynomial=Value))
    monkeypatch.setitem(sys.modules, 'support', SimpleNamespace(require_secure_execution=lambda *args: None))
    monkeypatch.setitem(sys.modules, 'finite_field', SimpleNamespace(BarrettContext=Barrett))
    monkeypatch.setitem(sys.modules, 'jax', SimpleNamespace(block_until_ready=lambda arrays: [a.block_until_ready() for a in arrays]))
    yield
    component._QUARANTINE.clear()  # Synthetic objects only; production cannot reset quarantine.
    assert not component._ACTIVE


def inputs(ctx):
    # Independent distinct row/head markers with nonzero hostile filler.
    data = np.linspace(-19., 23., 65536)
    return Value(data, 49, DELTA, ctx.events), Value(np.ones(65536), 49, DELTA, ctx.events)


def oracle(source, inverse=False, gain=1.):
    arrays = [np.zeros(65536), np.zeros(65536), np.zeros(65536)]
    if inverse:
        arrays[0] = source[(np.arange(65536)+1792) % 65536].copy()
    for row in range(16):
        key = (row+15) % 16
        for head in range(12):
            a, b, c = row*4096+head*64, row*4096+head, row*4096+key*16+head
            d = c+1792
            if inverse:
                arrays[1][b], arrays[2][a] = source[d], source[d]
            else:
                arrays[0][b] = arrays[1][c] = arrays[2][d] = source[a]*gain
    return arrays


def test_complete_fixed_plan_actual_owner_and_all_physical_slots():
    ctx = context(); x, ones = inputs(ctx)
    expected = []
    for gain in (1., .125):
        forward = oracle(x.polynomial.data, gain=gain)
        expected.extend(forward + oracle(forward[-1], inverse=True) + oracle(x.polynomial.data, inverse=True))
    seen = []
    def checkpoint(index, value, row):
        group, within = divmod(index, 9)
        fixed = PLAN['cases'][group]['checkpoints'][within]
        assert row == {**{name: fixed[name] for name in ('direction','label','level','scale','counts')},
                       'case': PLAN['cases'][group]['name']}
        assert ctx.events[-1] == ('barrier', id(value.polynomial))
        np.testing.assert_array_equal(value.polynomial.data, expected[index])
        seen.append(index)
    result = component.exercise(ctx, x, ones, checkpoint=checkpoint)
    assert seen == list(range(18))
    assert result['route_totals'] == PLAN['route_totals']
    assert result['input_preparation'] == dict(level_reduction_calls=3, ciphertext_products=1, composite_rescales=1)
    assert [e for e in ctx.events if e[0]=='level_reduce'] == [('level_reduce',49,5),('level_reduce',49,6),('level_reduce',49,6)]
    assert [e for e in ctx.events if e[0]=='multiply'] == [('multiply',6,6)]
    assert ('arithmetic',True,True) in ctx.events
    assert ctx.events[-1] == ('provider_close',)
    assert [e for e in ctx.events if e[0]=='clear'] == [('clear', n, True) for n in ('rotation','plaintext','rescale','compiler')]
    assert x.level == ones.level == 49 and x._ckks_scale == ones._ckks_scale == DELTA


@pytest.mark.parametrize('index', [0,8,9,17])
@pytest.mark.parametrize('target', ['x','ones','current'])
@pytest.mark.parametrize('field', ['payload','nsd','scale','moduli'])
def test_callback_mutation_rejects_before_next_checkpoint(index, target, field):
    ctx = context(); x, ones = inputs(ctx); calls=[]; originals=(x.polynomial,ones.polynomial)
    def checkpoint(i, value, row):
        calls.append(i)
        if i == index:
            victim = {'x':x,'ones':ones,'current':value}[target]
            if field == 'payload': victim.polynomial = Payload(np.zeros(65536),victim.level,ctx.events)
            elif field == 'nsd': victim._ckks_nsd = True
            elif field == 'scale': victim._ckks_scale = float(np.nextafter(victim._ckks_scale,np.inf))
            else: victim.num_moduli = 1
    with pytest.raises(ValueError): component.exercise(ctx,x,ones,checkpoint=checkpoint)
    assert calls == list(range(index+1))
    assert all(('barrier',id(p)) in ctx.events for p in originals)
    assert not any(e[0] in ('clear','provider_close','working_cleanup') for e in ctx.events)
    assert component._QUARANTINE


@pytest.mark.parametrize('failure', [RuntimeError('save failed'),KeyboardInterrupt('cancel'),SystemExit(7)])
def test_primary_callback_failure_quarantines_all_owners(failure):
    ctx = context(); x,ones=inputs(ctx)
    ctx.cleanup_failures.update(rotation=ValueError('clear'),rescale=KeyboardInterrupt('later'))
    def checkpoint(*args): raise failure
    with pytest.raises(type(failure)) as caught: component.exercise(ctx,x,ones,checkpoint=checkpoint)
    assert caught.value is failure
    assert not any(e[0] in ('clear','provider_close','working_cleanup') for e in ctx.events)
    assert component._QUARANTINE


def test_cleanup_only_cancellation_precedence_and_provider_last():
    ctx=context();x,ones=inputs(ctx)
    cancellation=KeyboardInterrupt('cleanup cancellation')
    ctx.cleanup_failures.update(working=ValueError('ordinary'),rescale=cancellation)
    with pytest.raises(KeyboardInterrupt) as caught: component.exercise(ctx,x,ones,checkpoint=lambda *args:None)
    assert caught.value is cancellation
    assert ctx.events[-1] == ('provider_close',)


@pytest.mark.parametrize('failure', [RuntimeError('pending result'),KeyboardInterrupt('pending cancel'),SystemExit(7)])
def test_primitive_failure_before_owner_retention_quarantines_helpers(monkeypatch,failure):
    ctx=context();x,ones=inputs(ctx);pending=[]
    def fails_before_return(self, values, weights):
        # Model a result dispatched by a compiled primitive whose _finish
        #raises before the wrapper ever reaches Routing._retain. No readiness
        #failure is injected into the reachable original inputs.
        result=Value(np.zeros(65536),4,DELTA,ctx.events)
        pending.append(result)
        raise failure
    monkeypatch.setattr(Arithmetic,'weighted_sum',fails_before_return)
    with pytest.raises(type(failure)) as caught: component.exercise(ctx,x,ones,checkpoint=lambda *args:None)
    assert caught.value is failure
    assert pending and ('barrier',id(pending[0].polynomial)) not in ctx.events
    assert all(('barrier',id(v.polynomial)) in ctx.events for v in (x,ones))
    assert not any(e[0] in ('clear','provider_close','working_cleanup') for e in ctx.events)
    quarantine=component._QUARANTINE[0]
    assert quarantine[0] is ctx and quarantine[1] is ctx.arithmetic
    assert quarantine[2] is not None and quarantine[3] is not None
    with pytest.raises(RuntimeError,match='quarantined'): component.exercise(ctx,x,ones,checkpoint=lambda *args:None)


def test_failed_original_readiness_quarantines_without_retiring_helpers():
    ctx=context();x,ones=inputs(ctx);original=x.polynomial; primary=RuntimeError('save')
    def checkpoint(*args):
        original.failure=KeyboardInterrupt('barrier')
        x.polynomial=Payload(np.zeros(65536),49,ctx.events)
        raise primary
    with pytest.raises(RuntimeError) as caught: component.exercise(ctx,x,ones,checkpoint=checkpoint)
    assert caught.value is primary
    assert not any(e[0] in ('clear','provider_close','working_cleanup') for e in ctx.events)
    assert any(original is payload for payload in component._QUARANTINE[0][-1])
    with pytest.raises(RuntimeError,match='quarantined'): component.exercise(ctx,x,ones,checkpoint=lambda *args:None)


@pytest.mark.parametrize('field', ['bad_reduce','bad_multiply'])
def test_real_preparation_metadata_is_checked(field):
    ctx=context();x,ones=inputs(ctx);setattr(ctx,field,True);seen=[]
    with pytest.raises(ValueError): component.exercise(ctx,x,ones,checkpoint=lambda i,*args:seen.append(i))
    assert seen == ([] if field=='bad_reduce' else list(range(9)))


@pytest.mark.parametrize('fault', ['order','counts','scale','extra'])
def test_owner_checkpoint_contract_violation_rejected(monkeypatch,fault):
    original=BSGSScoreRouting._note
    def bad(self,label,value):
        if fault=='order': label='wrong'
        elif fault=='counts': self.counts['rotations']+=1
        elif fault=='scale': value._ckks_scale=DELTA*2
        original(self,label,value)
        if fault=='extra': original(self,label,value)
    monkeypatch.setattr(BSGSScoreRouting,'_note',bad)
    ctx=context();x,ones=inputs(ctx)
    with pytest.raises(ValueError): component.exercise(ctx,x,ones,checkpoint=lambda *args:None)


def test_reentry_and_client_context_rejected_before_new_work():
    ctx=context();x,ones=inputs(ctx)
    def checkpoint(*args):
        with pytest.raises(RuntimeError,match='active'): component.exercise(ctx,x,ones,checkpoint=lambda *args:None)
    component.exercise(ctx,x,ones,checkpoint=checkpoint)
    ctx.secret_key=object(); before=list(ctx.events)
    with pytest.raises(ValueError,match='keyless'): component.exercise(ctx,x,ones,checkpoint=lambda *args:None)
    assert ctx.events==before


def test_import_is_backend_free_in_fresh_interpreter():
    import subprocess
    code="import sys; import component_arithmetic; assert not any(n=='jax' or n.startswith(('jax.','jaxlib','torch','transformers','jaxite_word')) for n in sys.modules)"
    subprocess.run([sys.executable,'-c',code],cwd=HERE,check=True,timeout=20)
