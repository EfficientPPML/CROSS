"""Role guards for dedicated BSGS proof processes; these are not a sandbox.

No key generation, native imports, pretrained input, or model loading is allowed.
Only the fixture role may encrypt and only the validate role may decrypt/decode.
The server audits protected client paths, including relative dir-fd opens and
symlink aliases. Already-open descriptors, hard-link aliases, malicious native
code and arbitrary same-user filesystem replacement are outside this guard.
The caller authenticates public keys and owns process isolation/cleanup.
"""
from contextlib import contextmanager
from pathlib import Path
import builtins
import importlib
import importlib.util
import os
import sys
import threading
from cleanup import cleanup_signals

ROLES = ('fixture', 'server', 'validate')
KEY_METHODS = ('gen_pke_pair', 'gen_evaluation_key', 'gen_rotation_key', 'key_switch_gen')
ENCRYPT = ('encrypt', 'encrypt_slots', 'encrypt_slots_batch')
DECRYPT = ('decrypt', 'decrypt_slots', 'decrypt_slots_batch', 'decode')
NATIVE_ROOTS = frozenset(('torch', 'transformers', 'safetensors', 'datasets', 'huggingface_hub', 'tensorflow'))
_ACTIVE = threading.Lock()


def _native(name):
    return isinstance(name, str) and name.split('.', 1)[0] in NATIVE_ROOTS


def _entries(role):
    """Import definitions only, then return the complete fixed denial inventory."""
    from jaxite_word import CKKSContext
    modules = [importlib.import_module(n) for n in ('key_gen', 'jaxite_word.key_gen')]
    if modules[0] is modules[1] or tuple(m.__name__ for m in modules) != ('key_gen', 'jaxite_word.key_gen'):
        raise RuntimeError('both distinct actual keygen aliases required')
    import client_keys, client_inputs, server_public_model, file_stages, full_model_engine, key_contexts
    entries = [(m, name, m.__name__ + '.' + name) for m in modules for name in KEY_METHODS]
    codecs = ENCRYPT + DECRYPT if role == 'server' else DECRYPT if role == 'fixture' else ENCRYPT
    entries += [(CKKSContext, name, 'CKKSContext.' + name) for name in codecs]
    fixed = ((client_keys, 'generate'), (client_inputs, 'ClientEmbeddings'),
             (client_inputs, 'read_preprocessed_jsonl'), (server_public_model, 'preprocess'),
             (server_public_model, 'load'), (file_stages, 'client_key_generation'),
             (file_stages, 'client_encode_encrypt_input'), (file_stages, 'client_decrypt_decode'),
             (file_stages, 'server_preprocess_model'), (file_stages, 'server_encrypted_compute'),
             (file_stages, '_records'), (file_stages, '_snapshot'), (full_model_engine, 'server_engine'))
    entries += [(owner, name, owner.__name__ + '.' + name) for owner, name in fixed]
    loaders = ('load_client', '_read_private') if role == 'server' else ('load_server',)
    entries += [(key_contexts, name, 'key_contexts.' + name) for name in loaders]
    return entries


@contextmanager
def role_scope(role, *, protected_paths=(), calls):
    """Install before context/codec work; restore every mutation on any exit.

    ``calls`` accumulates denied labels. Callers must fail the attempt if this
    list is nonempty, even if a tested/accidental denial was caught by a body.
    No payloads are inspected by entering this scope.
    """
    if type(role) is not str or role not in ROLES or type(calls) is not list:
        raise ValueError('exact fixture/server/validate role and denial list required')
    if any(_native(name) for name in sys.modules):
        raise ValueError('fresh component process must not preload native/model modules')
    protected = tuple(Path(p).absolute().resolve() for p in protected_paths) if role == 'server' else ()
    if not _ACTIVE.acquire(blocking=False):
        raise RuntimeError('component role scopes require a dedicated serial process')
    patches = []; active = [True]; primary = None
    original_import = builtins.__import__; original_module = importlib.import_module; original_open = os.open

    def denied(label):
        calls.append(label)
        raise RuntimeError('forbidden BSGS ' + role + ' action: ' + label)

    def stop(label):
        def forbidden(*args, **kwargs): return denied(label)
        return forbidden

    def patch(owner, name, value):
        original = getattr(owner, name)
        # Record before mutation; a setter can change the value then raise.
        patches.append((owner, name, original))
        setattr(owner, name, value)

    def checked_path(value, directory_fd=None):
        if not isinstance(value, (str, bytes, os.PathLike)): return
        path = Path(os.fsdecode(value))
        if not path.is_absolute() and directory_fd is not None:
            path = Path('/proc/self/fd') / str(directory_fd) / path
        path = path.absolute().resolve()
        if path.suffix == '.safetensors' or path.name == 'client_preprocessed_input':
            denied('pretrained input/model file access')
        if any(path == p or p in path.parents for p in protected):
            denied('private file access')

    def guarded_import(name, *args, **kwargs):
        if _native(name): denied('native model import: ' + name.split('.', 1)[0])
        return original_import(name, *args, **kwargs)

    def guarded_module(name, package=None):
        absolute = importlib.util.resolve_name(name, package) if name.startswith('.') else name
        if _native(absolute): denied('native model import: ' + absolute.split('.', 1)[0])
        return original_module(name, package)

    def guarded_open(path, flags, mode=0o777, *, dir_fd=None):
        checked_path(path, dir_fd)
        return original_open(path, flags, mode, dir_fd=dir_fd)

    def audit(event, args):
        if not active[0]: return
        if event == 'import' and args and _native(args[0]):
            denied('native model import: ' + args[0].split('.', 1)[0])
        if event == 'open' and args: checked_path(args[0])

    try:
        patch(builtins, '__import__', guarded_import)
        patch(importlib, 'import_module', guarded_module)
        patch(os, 'open', guarded_open)
        sys.addaudithook(audit)
        for owner, name, label in _entries(role): patch(owner, name, stop(label))
        yield
    except BaseException as error:
        primary = error
        raise
    finally:
        active[0] = False
        # cleanup_signals always executes its body even on installation failure.
        # It preserves incoming errors and defers repeated INT/TERM/HUP.
        with cleanup_signals():
            failure = None
            try:
                for owner, name, original in reversed(patches):
                    try: setattr(owner, name, original)
                    except BaseException as error:
                        if primary is not None: primary.add_note('role guard restore: ' + repr(error))
                        elif failure is None: failure = error
                        elif not isinstance(error, Exception) and isinstance(failure, Exception):
                            error.add_note('earlier role guard restore: ' + repr(failure)); failure = error
                        else: failure.add_note('additional role guard restore: ' + repr(error))
            finally: _ACTIVE.release()
            if primary is None and failure is not None: raise failure
