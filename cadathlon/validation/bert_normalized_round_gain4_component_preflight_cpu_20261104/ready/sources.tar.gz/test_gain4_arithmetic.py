"""Orchestration/retirement doubles only; the131-source proof owns numerics."""
from types import SimpleNamespace as NS
import pytest
import gain4_arithmetic as a
import gain4_public_plan as p
from encrypted_bert_normalization_round import NormalizationRoundContract
from encrypted_score_reduction import ScoreReductionLayout
from gain4_fixtures import definitions,checkpoint_names

class Array:
    def __init__(self):self.calls=0
    def block_until_ready(self):self.calls+=1;return self
class Value:
    def __init__(self,level,scale):self.level=level;self._ckks_scale=scale;self._ckks_nsd=1;self.polynomial=Array()

@pytest.fixture
def world(monkeypatch):
    plan=p.build_plan();log=[];ctx=NS(secret_key=None,_param_cache=NS(secret_key=None),parameters={})
    class Reduce:
        def level_reduce(self,v):log.append('reduce');return Value(25,v._ckks_scale)
    ctx.he_level_reduce={(49,25):Reduce()}
    class Provider:
        def close(self):log.append('provider.close')
    class Arithmetic:
        def __init__(self,context,**kw):
            self.ctx=context
            def helper(name):return NS(clear=lambda **kw:log.append(name+'.clear'))
            self.rotation=helper('rotation');self._plaintext_multiply=helper('pt');self._rescale=helper('rescale')
            self._multiplication_compiler=NS(clear_executables=lambda:log.append('multiply.clear'))
        def _clear_working_caches(self):log.append('working.clear')
        def multiply(self,x,y):
            log.append('diagnostic.multiply');q=plan['profile']['q'];L=min(x.level,y.level)
            return Value(L-1,x._ckks_scale*y._ckks_scale/(q[2*L]*q[2*L+1]))
    class Owner:
        def __init__(self,ops,layout,contract,progress):self.rule=contract;self.progress=progress
        def _guard(self):pass
        def _fingerprint(self,v):return id(v.polynomial),type(v._ckks_nsd),v._ckks_nsd,v.level,v._ckks_scale
        def _validate(self,v,*,level,scale):
            if v.level!=level or v._ckks_scale!=scale or type(v._ckks_nsd)is not int or v._ckks_nsd!=1:raise ValueError('typed metadata differs')
        def evaluate_tile(self,source,capture_checkpoints):
            log.append('evaluate')
            case=next(c for c in plan['cases']if c['key_count']==self.rule.key_count)
            values={r['label']:Value(r['level'],r['scale'])for r in case['checkpoints']}
            counts=dict(plaintext_products=3,ciphertext_products=2*self.rule.updates,rotations=14,ciphertext_additions=14)
            self.progress('probabilities',values['probabilities'],counts)
            steps=[(i,values[f'y{i:02}'],values[f'e{i:02}']if i<self.rule.updates else None)for i in range(1,self.rule.updates+1)]
            return values['probabilities'],values,steps
    monkeypatch.setattr(a,'_dependencies',lambda:(lambda ctx:Provider(),Arithmetic,Owner,NormalizationRoundContract,ScoreReductionLayout,definitions,checkpoint_names))
    yield NS(ctx=ctx,inputs=tuple(Value(49,plan['profile']['canonical_scale'])for _ in range(2)),log=log,Arithmetic=Arithmetic,plan=plan)
    a._ACTIVE=False;a._QUARANTINE.clear()

def test_both_inputs_reduce_then_all54_ordered_publications(world):
    seen=[];result=a.exercise(world.ctx,*world.inputs,checkpoint=lambda i,v,row:seen.append((i,v.level,v._ckks_scale,row)))
    assert result['checkpoints_completed']==54 and [r[0]for r in seen]==list(range(54))
    assert all((L,s)==(r['level'],r['scale'])for _,L,s,r in seen)
    assert world.log.count('reduce')==2 and world.log.count('diagnostic.multiply')==2 and world.log.count('evaluate')==2
    assert world.log[-6:]==['working.clear','rotation.clear','pt.clear','rescale.clear','multiply.clear','provider.close']
    assert all(v.polynomial.calls>=2 for v in world.inputs)and not a._QUARANTINE

@pytest.mark.parametrize('kind',(RuntimeError,KeyboardInterrupt,SystemExit))
def test_callback_primary_quarantines_all_original_backing(world,kind):
    primary=kind('publication failed')
    def fail(*args):raise primary
    with pytest.raises(kind)as seen:a.exercise(world.ctx,*world.inputs,checkpoint=fail)
    assert seen.value is primary and a._QUARANTINE and not a._ACTIVE
    arrays=a._QUARANTINE[-1][4]
    assert all(any(v.polynomial is x for x in arrays)for v in world.inputs)
    assert not any('.clear'in n or n=='provider.close'for n in world.log)
    with pytest.raises(RuntimeError):a.exercise(world.ctx,*world.inputs,checkpoint=fail)

@pytest.mark.parametrize('which',('original','earlier_output'))
def test_callback_mutation_fails_before_next_publication(world,which):
    captured=[]
    def callback(i,v,row):
        captured.append(v)
        if i==1:
            target=world.inputs[0]if which=='original'else captured[0]
            target.polynomial=Array()
    with pytest.raises(ValueError):a.exercise(world.ctx,*world.inputs,checkpoint=callback)
    assert len(captured)==2 and a._QUARANTINE

def test_reentry_cannot_retire_active_helpers(world):
    def nested(*args):a.exercise(world.ctx,*world.inputs,checkpoint=lambda *args:None)
    with pytest.raises(RuntimeError):a.exercise(world.ctx,*world.inputs,checkpoint=nested)
    assert a._QUARANTINE and not any('.clear'in n for n in world.log)

@pytest.mark.parametrize('kind',(RuntimeError,KeyboardInterrupt,SystemExit))
def test_pre_return_primitive_failure_conservatively_retains_owners(world,monkeypatch,kind):
    primary=kind('pending result')
    def fail(self,*args):pending=Value(7,1.);raise primary
    monkeypatch.setattr(world.Arithmetic,'multiply',fail)
    with pytest.raises(kind)as seen:a.exercise(world.ctx,*world.inputs,checkpoint=lambda *args:None)
    assert seen.value is primary and a._QUARANTINE and not any('.clear'in n for n in world.log)

def test_cleanup_attempts_all_original_accessors(world,monkeypatch):
    primary=OSError('working cache cleanup')
    def fail(self):world.log.append('working.failed');raise primary
    monkeypatch.setattr(world.Arithmetic,'_clear_working_caches',fail)
    with pytest.raises(OSError)as seen:a.exercise(world.ctx,*world.inputs,checkpoint=lambda *args:None)
    assert seen.value is primary and world.log[-1]=='provider.close'and a._QUARANTINE
