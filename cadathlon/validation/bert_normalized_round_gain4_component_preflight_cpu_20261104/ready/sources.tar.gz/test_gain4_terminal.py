"""Outer signal restoration gates both report publication and phase success."""
from contextlib import contextmanager
import json,sys
import pytest
import component_worker as w
import collect_component as c

@pytest.mark.parametrize('module',(w,c))
@pytest.mark.parametrize('kind',(None,RuntimeError,KeyboardInterrupt,SystemExit))
def test_main_publishes_success_only_after_outer_scope_exit(tmp_path,monkeypatch,module,kind):
    report=tmp_path/'worker.json'if module is w else tmp_path/'report.json'
    primary=None if kind is None else kind('outer restoration')
    @contextmanager
    def scope():
        yield
        before=json.loads(report.read_bytes())
        assert before['termination_scope_completed']is False
        if primary is not None:raise primary
    monkeypatch.setattr(module,'termination_signals',scope)
    def body(*args,**kwargs):
        if module is c:kwargs['_publication_owner'].claim(tmp_path)
        module.protocol.write(report,dict(passed=True,terminal_scope_completed=True,termination_scope_completed=False))
        return 0
    if module is w:
        config=tmp_path/'config.json';config.write_text('{}');source=tmp_path/'sources.json';source.write_text('{}')
        monkeypatch.setattr(w.protocol,'require_ready',lambda:None);monkeypatch.setattr(w,'run',body)
        monkeypatch.setattr(sys,'argv',['worker','--config',str(config),'--config-sha256',w.protocol.sha(config.read_bytes()),'--source-manifest',str(source),'--output',str(report),'--execute'])
    else:
        monkeypatch.setattr(c,'collect',body)
        monkeypatch.setattr(sys,'argv',['collector','--output',str(tmp_path),'--key-evidence','/public/evidence','--key-workspace','/public/workspace'])
    if kind is None:
        assert module.main()==0
        result=json.loads(report.read_bytes());assert result['passed']is True and result['termination_scope_completed']is True
    else:
        with pytest.raises(kind)as seen:module.main()
        assert seen.value is primary
        result=json.loads(report.read_bytes());assert result['passed']is False and result['termination_scope_completed']is False and result['terminal_scope_completed']is False

def test_existing_collector_report_remains_untouched(tmp_path,monkeypatch):
    output=tmp_path/'existing';output.mkdir(mode=0o700);report=output/'report.json';original=b'{"passed":true,"foreign":"retained"}';report.write_bytes(original)
    monkeypatch.setattr(sys,'argv',['collector','--output',str(output),'--key-evidence',str(tmp_path/'keys-proof'),'--key-workspace',str(tmp_path/'keys')])
    with pytest.raises(FileExistsError):c.main()
    assert report.read_bytes()==original

def test_replaced_collector_output_is_not_adopted(tmp_path):
    output=tmp_path/'owned';output.mkdir(mode=0o700);owner=c.OwnedOutput();owner.claim(output)
    output.rename(tmp_path/'moved');output.mkdir(mode=0o700);report=output/'report.json';original=b'{"foreign":true}';report.write_bytes(original)
    with pytest.raises(ValueError):owner.write(report,dict(passed=False))
    with pytest.raises(ValueError):owner.read(report)
    assert report.read_bytes()==original

def test_existing_worker_report_remains_untouched(tmp_path,monkeypatch):
    report=tmp_path/'worker.json';original=b'{"passed":true,"foreign":"retained"}';report.write_bytes(original)
    config=tmp_path/'config.json';config.write_text('{}');source=tmp_path/'sources.json';source.write_text('{}')
    monkeypatch.setattr(w.protocol,'require_ready',lambda:None)
    monkeypatch.setattr(sys,'argv',['worker','--config',str(config),'--config-sha256',w.protocol.sha(config.read_bytes()),'--source-manifest',str(source),'--output',str(report),'--execute'])
    with pytest.raises(FileExistsError):w.main()
    assert report.read_bytes()==original
