"""Public metadata tests; never execute a backend, keygen or encryption."""
import hashlib,json,sys
from pathlib import Path
import numpy as np
import pytest
import gain4_public_plan as p
from encrypted_scale_planning import weighted_sum_scale,multiply_scale,drop_divisor

@pytest.fixture(scope='module')
def plan():return p.build_plan()

def test_fixed_inventory_shapes_order_and_scope(plan):
    assert plan['schema']==p.SCHEMA and plan['inputs']==2 and plan['outputs']==54
    assert [(c['name'],c['updates']) for c in plan['cases']]==[('K128_rows16',13),('K15_rows9',10)]
    assert len(plan['required_rotation_indices'])==14 and plan['rotation_subset_verified']is True
    assert plan['full_rotation_inventory_count']==130 and plan['counts']['refreshes']==0
    assert plan['counts']['logical_ciphertext_products']==48 and plan['counts']['actual_composite_rescales']==54
    assert plan['counts']['logical_plaintext_products']==6 and plan['counts']['rotations']==28
    assert plan['io']['input_payload_bytes']==209715200
    assert plan['io']['output_payload_bytes']==sum(r['payload_bytes'] for r in plan['checkpoints'])
    assert [r['index'] for r in plan['checkpoints']]==list(range(54))
    json.dumps(plan,allow_nan=False)

def test_actual_scales_independent_forward_recurrence(plan):
    q=plan['profile']['q'];D=lambda L:q[2*L]*q[2*L+1]
    for case in plan['cases']:
        rows={r['label']:r for r in case['checkpoints']};s=p.DELTA
        mask=s*((4*s*D(25))/s)/D(25);numerator=mask*mask/D(24);den=numerator*((16*s*D(23))/numerator)/D(23)
        assert rows['masked_input']['scale']==mask and rows['squared_numerator']['scale']==numerator and rows['denominator']['scale']==den
        first=case['schedule']['tracked_inverse_scale_plan']['first_output_scale'];encoded=first*D(22)/den
        y=den*encoded/D(22);yl=21;e=den*y/D(21);el=20
        assert rows['y01']['scale']==y and rows['e01']['scale']==e
        for n in range(2,case['updates']+1):
            y=y*e/D(el);yl=el-1;e=e*e/D(el);el-=1
            assert rows[f'y{n:02}']['scale']==y and rows[f'y{n:02}']['level']==yl
            assert rows[f'e{n:02}']['scale']==e and rows[f'e{n:02}']['level']==el
        assert rows['probabilities']['scale']==numerator*y/D(yl)
        assert rows['probabilities']['level']==yl-1

def test_original_arrays_hashes_and_no_aliasing(plan):
    x=p.fixture_arrays();y=p.oracle_arrays()
    assert len(x)==2 and len(y)==54 and all(a.shape==(65536,) and a.dtype==np.float64 and np.isfinite(a).all() for a in (*x,*y))
    assert [p.array_sha(a) for a in x]==[c['input_sha256'] for c in plan['cases']]
    assert [p.array_sha(a) for a in y]==[r['expected_array_sha256'] for r in plan['checkpoints']]
    assert all(not np.shares_memory(a,b) for i,a in enumerate(y) for b in y[i+1:])
    x[0][:]=0.;assert p.array_sha(p.fixture_arrays()[0])==plan['cases'][0]['input_sha256']

@pytest.mark.parametrize('label',['masked_input','squared_numerator','denominator','y01','e01','probabilities'])
def test_all_slot_payload_contract(plan,label):
    for case in plan['cases']:
        r=next(r for r in case['checkpoints'] if r['label']==label)
        assert r['payload_shape']==[1,2,256,512,2*(r['level']+1)]
        assert r['payload_bytes']==np.prod(r['payload_shape'])*4 and r['nsd']==1 and r['payload_dtype']=='uint32'

def test_file_hash_failure_before_fixture_generation(tmp_path,monkeypatch):
    for name in p.PINS:
        dest=tmp_path/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((p.P/name).read_bytes())
    (tmp_path/'gain4_fixtures.py').write_bytes(b'changed')
    monkeypatch.setattr(p,'P',tmp_path)
    monkeypatch.setattr(p.fixtures,'make_probabilities',lambda *args:pytest.fail('must not generate after failed source gate'))
    with pytest.raises(ValueError,match='identity'):p.build_plan()

def test_public_only_imports(plan):
    assert not any(n in sys.modules for n in ('jax','jaxlib','torch','transformers','safetensors'))


def test_returned_pin_metadata_does_not_alias_authority():
    result=p.build_plan();expected=dict(p.PINS);result['source_sha256'].clear()
    assert p.PINS==expected and p.build_plan()['source_sha256']==expected
