"""Synthetic role denial/lifetime tests; no backend/model/key instance exists."""
import builtins
import importlib
import os
from pathlib import Path
import sys
from types import ModuleType
import pytest
import component_boundaries as b

@pytest.fixture
def fake(monkeypatch):
    def original(*args, **kwargs): return 'allowed'
    context = type('Context', (), {name: staticmethod(original) for name in b.ENCRYPT+b.DECRYPT})
    package=ModuleType('jaxite_word');package.CKKSContext=context
    monkeypatch.setitem(sys.modules,'jaxite_word',package)
    definitions={
        'key_gen':b.KEY_METHODS,'jaxite_word.key_gen':b.KEY_METHODS,
        'client_keys':('generate',),'client_inputs':('ClientEmbeddings','read_preprocessed_jsonl'),
        'server_public_model':('preprocess','load'),
        'file_stages':('client_key_generation','client_encode_encrypt_input','client_decrypt_decode',
            'server_preprocess_model','server_encrypted_compute','_records','_snapshot'),
        'full_model_engine':('server_engine',),'key_contexts':('load_client','load_server','_read_private')}
    for name,fields in definitions.items():
        m=ModuleType(name)
        for n in fields:setattr(m,n,original)
        monkeypatch.setitem(sys.modules,name,m)
    return context

@pytest.mark.parametrize('role',b.ROLES)
def test_all_role_entries_denied_and_restored(role,fake):
    entries=b._entries(role);originals=[getattr(o,n) for o,n,_ in entries];calls=[]
    allowed=b.ENCRYPT if role=='fixture' else b.DECRYPT if role=='validate' else ()
    allow=[getattr(fake,n) for n in allowed]
    with b.role_scope(role,calls=calls):
        for o,n,label in entries:
            with pytest.raises(RuntimeError,match='forbidden BSGS'):getattr(o,n)(None)
        assert [getattr(fake,n) for n in allowed]==allow
        assert all(getattr(fake,n)()=='allowed' for n in allowed)
    assert calls==[label for _,_,label in entries]
    assert [getattr(o,n) for o,n,_ in entries]==originals

@pytest.mark.parametrize('role',b.ROLES)
@pytest.mark.parametrize('module',sorted(b.NATIVE_ROOTS))
def test_native_import_denied_without_loading(role,module,fake):
    calls=[]
    with b.role_scope(role,calls=calls):
        for function in (builtins.__import__,importlib.import_module):
            with pytest.raises(RuntimeError,match='native model import'):function(module)
    assert len(calls)==2 and module not in sys.modules

@pytest.mark.parametrize('role',b.ROLES)
def test_pretrained_paths_are_forbidden_for_every_role(role,fake,tmp_path):
    calls=[]
    with b.role_scope(role,calls=calls):
        for name in ('model.safetensors','client_preprocessed_input'):
            with pytest.raises(RuntimeError,match='pretrained'):open(tmp_path/name,'rb')
    assert len(calls)==2

@pytest.mark.parametrize('style',['absolute','relative','symlink','dirfd','dirfd_symlink'])
def test_server_protected_open_aliases(style,fake,tmp_path,monkeypatch):
    private=tmp_path/'private';private.mkdir();secret=private/'secret';secret.write_bytes(b'private synthetic')
    alias=tmp_path/'alias';alias.symlink_to(private,target_is_directory=True)
    directory=os.open(private,os.O_RDONLY|os.O_DIRECTORY);calls=[]
    monkeypatch.chdir(tmp_path)
    try:
        with b.role_scope('server',protected_paths=(private,),calls=calls):
            with pytest.raises(RuntimeError,match='private file access'):
                if style=='absolute':secret.read_bytes()
                elif style=='relative':open('private/secret','rb')
                elif style=='symlink':(alias/'secret').read_bytes()
                elif style=='dirfd':os.open('secret',os.O_RDONLY,dir_fd=directory)
                else:os.open('../alias/secret',os.O_RDONLY,dir_fd=directory)
    finally:os.close(directory)
    assert len(calls)==1
    assert secret.read_bytes()==b'private synthetic' # inactive audit after scope

@pytest.mark.parametrize('role',['fixture','validate'])
def test_client_private_reads_are_not_server_audited(role,fake,tmp_path):
    p=tmp_path/'private';p.write_bytes(b'client synthetic')
    with b.role_scope(role,protected_paths=(p,),calls=[]):assert p.read_bytes()==b'client synthetic'

@pytest.mark.parametrize('bad',[None,1,True,'validator','unknown'])
def test_exact_role_rejected_before_import(bad,monkeypatch):
    monkeypatch.setattr(b,'_entries',lambda *a:pytest.fail('no imports'))
    with pytest.raises(ValueError):
        with b.role_scope(bad,calls=[]):pass

@pytest.mark.parametrize('bad',[None,(),{}])
def test_exact_calls_list_required(bad):
    with pytest.raises(ValueError):
        with b.role_scope('server',calls=bad):pass

@pytest.mark.parametrize('name',['torch','transformers.modeling','safetensors'])
def test_native_preload_rejected(name,monkeypatch):
    monkeypatch.setitem(sys.modules,name,ModuleType(name))
    with pytest.raises(ValueError,match='preload'):
        with b.role_scope('server',calls=[]):pass


def test_reentry_rejected_and_lock_released(fake):
    with b.role_scope('server',calls=[]):
        with pytest.raises(RuntimeError,match='dedicated serial'):
            with b.role_scope('fixture',calls=[]):pass
    with b.role_scope('validate',calls=[]):pass

@pytest.mark.parametrize('error',[ValueError,KeyboardInterrupt,SystemExit])
def test_body_primary_and_all_restorations(fake,error):
    entries=b._entries('server');originals=[getattr(o,n) for o,n,_ in entries]
    original_import=builtins.__import__;original_module=importlib.import_module;original_open=os.open
    primary=error('body')
    with pytest.raises(error) as result:
        with b.role_scope('server',calls=[]):raise primary
    assert result.value is primary
    assert [getattr(o,n) for o,n,_ in entries]==originals
    assert builtins.__import__ is original_import and importlib.import_module is original_module and os.open is original_open
    assert not b._ACTIVE.locked()


def test_partial_mutating_setter_is_restored(monkeypatch):
    original=lambda:None
    class Owner:
        armed=True
        function=staticmethod(original)
        def __setattr__(self,name,value):
            object.__setattr__(self,name,value)
            if name=='function' and self.armed:
                self.armed=False;raise KeyboardInterrupt('partial setter')
    owner=Owner();monkeypatch.setattr(b,'_entries',lambda role:[(owner,'function','owner.function')])
    with pytest.raises(KeyboardInterrupt,match='partial setter'):
        with b.role_scope('server',calls=[]):pytest.fail('body must not enter')
    assert owner.function is original and not b._ACTIVE.locked()

@pytest.mark.parametrize('body_primary',[False,True])
def test_restore_attempt_all_cancellation_priority(monkeypatch,body_primary):
    events=[];primary=ValueError('body primary')
    class Owner:
        def __init__(self,name,error):
            self.name=name;self.error=error;self.original=lambda:None;self.function=self.original;self.armed=False
        def __setattr__(self,name,value):
            object.__setattr__(self,name,value)
            if name=='function' and getattr(self,'armed',False) and value is self.original:
                events.append(self.name);raise self.error
    a=Owner('cancel',KeyboardInterrupt('cleanup cancelled'));z=Owner('ordinary',OSError('cleanup ordinary'))
    monkeypatch.setattr(b,'_entries',lambda role:[(a,'function','a'),(z,'function','z')])
    with pytest.raises(ValueError if body_primary else KeyboardInterrupt) as result:
        with b.role_scope('server',calls=[]):
            a.armed=z.armed=True
            if body_primary:raise primary
    assert events==['ordinary','cancel'] and not b._ACTIVE.locked()
    assert a.function is a.original and z.function is z.original
    if body_primary:assert result.value is primary


def test_failed_entry_inventory_restores_import_open_and_lock(monkeypatch):
    initial=(builtins.__import__,importlib.import_module,os.open)
    def fail(role):raise RuntimeError('entry inventory missing')
    monkeypatch.setattr(b,'_entries',fail)
    with pytest.raises(RuntimeError,match='entry inventory'):
        with b.role_scope('server',calls=[]):pass
    assert initial==(builtins.__import__,importlib.import_module,os.open) and not b._ACTIVE.locked()
