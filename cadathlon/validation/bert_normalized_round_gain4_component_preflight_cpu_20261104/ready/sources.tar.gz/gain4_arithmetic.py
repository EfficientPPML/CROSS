"""Two fixed gain4 rounds inside one borrowed keyless server scope.

No codec, key generation or refresh. Any entered failure retains the complete
arithmetic/provider/context and original array references until process exit;
the exception must escape through the authenticated loader's quarantine.
"""
from pathlib import Path
import hashlib,sys
from cleanup import cleanup_signals
from component_contract import OWNER_SHA,numerical_plan

_ACTIVE=False
_QUARANTINE=[]

def _dependencies():
    from encrypted_ntt import enable_scoped_ntt_subsets
    from encrypted_packed_qwen import CompiledArithmetic
    from encrypted_bert_normalization_gain4 import BertNormalizationRoundGain4
    from encrypted_bert_normalization_round import NormalizationRoundContract
    from encrypted_score_reduction import ScoreReductionLayout
    from gain4_fixtures import definitions,checkpoint_names
    return enable_scoped_ntt_subsets,CompiledArithmetic,BertNormalizationRoundGain4,NormalizationRoundContract,ScoreReductionLayout,definitions,checkpoint_names

def exercise(ctx,*inputs,checkpoint,progress=None):
    global _ACTIVE
    if _ACTIVE or _QUARANTINE:raise RuntimeError('serial component active or quarantined')
    if len(inputs)!=2 or not callable(checkpoint)or progress is not None and not callable(progress):raise ValueError('two fixed inputs and callback required')
    path=Path(__file__).resolve().parent
    if hashlib.sha256((path/'common/encrypted_bert_normalization_gain4.py').read_bytes()).hexdigest()!=OWNER_SHA:raise ValueError('exact frozen gain4 owner required')
    if ctx.secret_key is not None or ctx._param_cache.secret_key is not None or ctx.parameters.get('secret_key')is not None:raise ValueError('keyless context required')
    plan=numerical_plan();raw=(path/'gain4_candidate_manifest.json').read_bytes()
    original_arrays=tuple(v.polynomial for v in inputs)
    provider=arithmetic=owner=None;entered=False;held=[];retire=[];next_index=0;completed=[];owners=[]
    def retain(v):
        row=(v,v.polynomial,owner._fingerprint(v));held.append(row);return v
    def guard():
        owner._guard()
        for v,array,state in held:
            if v.polynomial is not array or owner._fingerprint(v)!=state:raise ValueError('retained round checkpoint/input changed')
    def barrier(v):v.polynomial.block_until_ready()
    try:
        _ACTIVE=True
        enable,Arithmetic,Owner,Contract,Layout,definitions,names=_dependencies()
        entered=True;provider=enable(ctx);arithmetic=Arithmetic(ctx,low_memory=True,preserve_dispatch_cache=True)
        # Capture original retirement accessors immediately. A callback cannot
        # replace a helper and thereby redirect cleanup of the original owner.
        retire.append(('working caches',arithmetic._clear_working_caches))
        for n in ('rotation','_plaintext_multiply','_rescale'):
            helper=getattr(arithmetic,n);method=helper.clear
            retire.append((n,lambda method=method:method(executables=True)))
        retire.append(('multiplication compiler',arithmetic._multiplication_compiler.clear_executables))
        retire.append(('NTT provider',provider.close))
        for case_index,(item,fresh)in enumerate(zip(definitions(),inputs)):
            contract=Contract(raw,item['key_count']);last_counts={}
            def observed(label,value,counts):
                nonlocal last_counts
                guard();last_counts=dict(counts);barrier(value)
                if progress is not None:progress(item['name']+' '+label,value,dict(counts))
                guard()
            owner=Owner(arithmetic,Layout(item['key_mask'],valid_rows=item['valid_rows']),contract,progress=observed);owners.append(owner)
            for value in inputs:
                owner._validate(value,level=49,scale=plan['profile']['canonical_scale'])
                if not any(v is value for v,_,_ in held):retain(value)
                barrier(value)
            guard()
            reduced=retain(ctx.he_level_reduce[49,25].level_reduce(fresh));barrier(reduced);owner._validate(reduced,level=25,scale=fresh._ckks_scale);guard()
            output,stages,steps=owner.evaluate_tile(reduced,capture_checkpoints=True)
            selected={name:stages[name]for name in ('masked_input','squared_numerator','denominator','probabilities')}
            for i,y,e in steps:
                selected[f'y{i:02}']=y
                if e is not None:selected[f'e{i:02}']=e
            # The unused final e square remains a separately counted genuine
            # diagnostic; it is never substituted into the production owner.
            guard();final_e=retain(arithmetic.multiply(steps[-2][2],steps[-2][2]));barrier(final_e);guard()
            selected[f'e{contract.updates:02}']=final_e
            if set(selected)!=set(names(contract.updates)):raise ValueError('full original checkpoint inventory required')
            for name in names(contract.updates):retain(selected[name]);barrier(selected[name])
            guard()
            for name in names(contract.updates):
                expected=plan['checkpoints'][next_index];value=selected[name]
                if expected['case_index']!=case_index or expected['label']!=name:raise ValueError('fixed checkpoint ordering differs')
                owner._validate(value,level=expected['level'],scale=expected['scale'])
                checkpoint(next_index,value,dict(expected));guard();barrier(value);next_index+=1
            if last_counts!=dict(plaintext_products=3,ciphertext_products=2*contract.updates,rotations=14,ciphertext_additions=14):raise ValueError('fixed production primitive counts differ')
            completed.append(dict(name=item['name'],key_count=item['key_count'],updates=contract.updates,production_counts=last_counts,diagnostic_ciphertext_products=1,diagnostic_rescales=1,level_reduction_calls=1))
            output=stages=steps=selected=final_e=reduced=None
        guard()
        if next_index!=54:raise ValueError('all54 checkpoints required')
        return dict(checkpoints_completed=54,cases=completed,input_metadata_unchanged=True,synchronous_outputs=True,context_borrowed=True,codecs_called=False,refreshes=0,keygen=False)
    finally:
        primary=sys.exception();errors=[];cleanup_entered=False
        def attempt(label,fn):
            try:return fn()
            except BaseException as error:errors.append((label,error))
        def cleanup():
            nonlocal cleanup_entered
            cleanup_entered=True
            arrays={id(a):a for a in original_arrays};arrays.update((id(a),a)for _,a,_ in held)
            for a in arrays.values():attempt('original array barrier',a.block_until_ready)
            if errors or entered and primary is not None:
                _QUARANTINE.append((ctx,arithmetic,provider,tuple(owners),tuple(arrays.values()),primary,None if primary is None else primary.__traceback__))
            else:
                for name,fn in retire:attempt(name,fn)
                if errors:_QUARANTINE.append((ctx,arithmetic,provider,tuple(owners),tuple(arrays.values()),tuple(errors)))
        try:
            with cleanup_signals():cleanup()
        except BaseException as error:
            errors.append(('cleanup scope',error))
            if not cleanup_entered:cleanup()
        finally:_ACTIVE=False
        if primary is not None:
            for name,error in errors:
                if error is not primary:primary.add_note(name+': '+repr(error))
        elif errors:
            chosen=next((e for _,e in errors if not isinstance(e,Exception)),errors[0][1])
            for name,error in errors:
                if error is not chosen:chosen.add_note(name+': '+repr(error))
            raise chosen
