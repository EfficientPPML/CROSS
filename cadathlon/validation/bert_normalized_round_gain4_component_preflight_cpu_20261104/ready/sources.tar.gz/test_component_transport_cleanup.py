"""Three synthetic lifecycle negatives of exact reviewed draft; no HE."""
from pathlib import Path
from contextlib import contextmanager
from types import SimpleNamespace
import os
import sys
import numpy as np
import pytest
import component_transport as transport


@pytest.fixture
def tiny(monkeypatch):
    binding=dict(context_id='a'*64,request_id='b'*32,role='request',tile_index=0,
        shape=(1,2,1,2,2),moduli=[17,19],layout=[1,2],scale=10.)
    class Polynomial:
        shape=binding['shape'];degree_layout=(1,2);precision=32;_ckks_nsd=1;_ckks_scale=10.
        def validate(self):pass
        def get_moduli(self):return binding['moduli']
    def writer(ct,directory):
        (directory/'bundle.json').write_bytes(transport._canonical({'shape':{'__ct__':0},'count':1}))
        np.savez(directory/'ct_0.npz',payload=np.ones(binding['shape'],dtype=np.uint32),
            moduli=np.array([17,19],dtype=np.int64),degree_layout=np.array([1,2],dtype=np.int64),
            precision=np.array(32,dtype=np.int64),nsd=np.array(1,dtype=np.int64),scale=np.array(10.,dtype=np.float64))
    monkeypatch.setattr(transport,'ciphertext_contract',lambda *a,**k:dict(binding))
    monkeypatch.setitem(sys.modules,'jaxite_word',SimpleNamespace(Polynomial=Polynomial))
    monkeypatch.setitem(sys.modules,'bundle_io',SimpleNamespace(save_bundle=writer))
    return Polynomial()


@pytest.mark.parametrize('cancel',[KeyboardInterrupt,SystemExit])
@pytest.mark.parametrize('site',['read','write'])
def test_cleanup_only_cancellation_supersedes_prior_close(tmp_path,monkeypatch,tiny,cancel,site):
    target=tmp_path/'tile';real_close=os.close;real_fdopen=os.fdopen;opened_write=[];active=[]
    def fdopen(fd,*a,**kw):
        if a and a[0]=='wb':opened_write.append(fd)
        return real_fdopen(fd,*a,**kw)
    def close(fd):
        real_close(fd)
        if site=='write' and not opened_write:return
        active.append(fd)
        if len(active)==1:raise OSError('first cleanup failure')
        raise cancel('later cleanup cancellation')
    with monkeypatch.context() as m:
        m.setattr(os,'fdopen',fdopen);m.setattr(os,'close',close)
        with pytest.raises(cancel,match='later cleanup'):
            transport.save_ciphertext(tiny,target,contract={},role='request',tile_index=0)
    assert len(active)==2 and target.is_dir()

@pytest.mark.parametrize('kind',[RuntimeError,KeyboardInterrupt,SystemExit])
@pytest.mark.parametrize('mode',['rb','wb'])
def test_real_read_write_body_primary_survives_all_close_errors(tmp_path,monkeypatch,tiny,kind,mode):
    target=tmp_path/'tile';real_close=os.close;real_fdopen=os.fdopen;active=[];started=[]
    primary=kind('body failure')
    class Stream:
        def __init__(self,real):self.real=real
        def read(self,*a):started.append(True);raise primary
        def write(self,*a):started.append(True);raise primary
        def flush(self):return self.real.flush()
        def fileno(self):return self.real.fileno()
        def close(self):self.real.close();raise OSError('stream cleanup failure')
    def opened(fd,*a,**k):
        real=real_fdopen(fd,*a,**k)
        return Stream(real) if a[0]==mode else real
    def close(fd):
        real_close(fd)
        if started:
            active.append(fd)
            raise OSError('descriptor cleanup failure') if len(active)==1 else KeyboardInterrupt('later cleanup cancel')
    with monkeypatch.context() as m:
        m.setattr(os,'fdopen',opened);m.setattr(os,'close',close)
        with pytest.raises(kind) as found:transport.save_ciphertext(tiny,target,contract={},role='request',tile_index=0)
    assert found.value is primary and len(active)==2
    assert len(set(active))==2 and target.is_dir()
    assert len(primary.__notes__)>=3

@pytest.mark.parametrize('cancel',[KeyboardInterrupt,SystemExit])
def test_stream_close_origin_shared_with_descriptor_and_directory(tmp_path,monkeypatch,tiny,cancel):
    real_close=os.close;real_fdopen=os.fdopen;started=[];closes=[]
    class Stream:
        def __init__(self,real):self.real=real
        def read(self,*a):return self.real.read(*a)
        def close(self):self.real.close();started.append(True);raise OSError('stream-only failure')
    def opened(fd,*a,**k):return Stream(real_fdopen(fd,*a,**k))
    cancellation=cancel('descriptor cancellation')
    def close(fd):
        real_close(fd);closes.append(fd)
        if started:raise cancellation if len(closes)==1 else OSError('later directory error')
    with monkeypatch.context() as m:
        m.setattr(os,'fdopen',opened);m.setattr(os,'close',close)
        with pytest.raises(cancel) as found:transport.save_ciphertext(tiny,tmp_path/'tile',contract={},role='request',tile_index=0)
    assert found.value is cancellation and len(closes)==2
    assert any('stream-only' in n for n in cancellation.__notes__)


def test_writer_handoff_failure_closes_once_and_retains(tmp_path,monkeypatch,tiny):
    real_open=os.open;real_close=os.close;real_fdopen=os.fdopen;opened=[];closed=[]
    def opening(path,*a,**k):
        fd=real_open(path,*a,**k)
        if path=='.transport.tmp':opened.append(fd)
        return fd
    def fdopen(fd,*a,**k):
        if a[0]=='wb':raise RuntimeError('handoff failure')
        return real_fdopen(fd,*a,**k)
    def close(fd):
        if opened and fd==opened[0]:closed.append(fd)
        return real_close(fd)
    with monkeypatch.context() as m:
        m.setattr(os,'open',opening);m.setattr(os,'fdopen',fdopen);m.setattr(os,'close',close)
        with pytest.raises(RuntimeError,match='handoff'):transport.save_ciphertext(tiny,tmp_path/'tile',contract={},role='request',tile_index=0)
    assert len(opened)==len(closed)==1
    with pytest.raises(OSError):os.fstat(opened[0])
    assert (tmp_path/'tile').is_dir()


def test_writer_replacement_retains_original_and_foreign(tmp_path,monkeypatch,tiny):
    target=tmp_path/'tile';moved=tmp_path/'original'
    def writer(ct,path):
        (path/'partial').write_bytes(b'partial');path.rename(moved)
        path.mkdir();(path/'foreign').write_bytes(b'foreign')
        raise RuntimeError('writer failure')
    monkeypatch.setitem(sys.modules,'bundle_io',SimpleNamespace(save_bundle=writer))
    with pytest.raises(RuntimeError,match='writer failure'):
        transport.save_ciphertext(tiny,target,contract={},role='request',tile_index=0)
    assert (moved/'partial').read_bytes()==b'partial' and (target/'foreign').read_bytes()==b'foreign'
