"""Three real CKKS processes: pinned full-width QK projections and raw score route."""
from pathlib import Path
import argparse,gc,hashlib,importlib,json,math,os,shutil,sys,time
import numpy as np
if os.environ.get('JAX_PLATFORMS')!='cpu':raise RuntimeError('CPU component requires explicit JAX_PLATFORMS=cpu')
ROOT=Path(os.environ['CROSS_ROOT']).resolve();sys.path[:0]=[str(ROOT),str(ROOT/'cadathlon/common')]
from spec import KINDS,ROTATIONS,INPUT_ROLES,OUTPUT_ROLES,QUERY_TILE,KEY_TILE,OFFSET,PUBLIC_ATTENTION_MASK,parameters
from contracts import check_parameters,digest,write,sha,pack_rows,load_model,store_array,load_public,linear_source_sha256,routing_source_sha256 as score_routing_source_sha256,packing_contract,request_digest
from transport import load_ciphertext,save_ciphertext,manifest_digest,_json,_read_regular


def crypto():
 import jax
 from jaxite_word import CKKSContext,ckks_ctx,key_gen
 jax.config.update('jax_enable_x64',True)
 if {d.platform for d in jax.devices()}!={'cpu'}:raise ValueError('unexpected accelerator')
 return jax,CKKSContext,ckks_ctx,key_gen

def expected_product_scale(parameters, input_level, left_scale, right_scale):
 if type(input_level) is not int or not 1<=input_level<=parameters['max_level']:raise ValueError('invalid product input level')
 moduli=parameters['q_towers'][:parameters['composite_degree']*(input_level+1)]
 return left_scale*right_scale/math.prod(moduli[-parameters['composite_degree']:])

def context_parameters(p):
 return {k:p[k] for k in ('degree','num_slots','q_towers','p_towers','composite_degree','degree_layout','scaling_factor','output_scale','sigma','secret_distribution')}|{'p':56,'CKKS_M_FACTOR':1,'max_bits_in_word':61,'noise_scale_degree':1}

def public_preflight():
 p=parameters();bits=check_parameters(p)
 from encrypted_score_routing import FactoredScoreLayout
 linear=set(range(1,64))|set(range(64,768,64))|set(range(64768,65536,64))
 expected=linear|set(FactoredScoreLayout(KEY_TILE,OFFSET).rotation_indices(include_inverse=False))|{1<<i for i in range(6)}|{OFFSET*4096}
 if sorted(expected)!=ROTATIONS or len(ROTATIONS)!=93:raise ValueError('public operation/key inventory differs')
 pair=2*p['dnum']*(len(p['q_towers'])+len(p['p_towers']))*p['degree']*4
 # Concurrent FFN setup is independently authorized; reserve it before keygen.
 ff_reserve=math.ceil(8.18*1024**3);margin=4*1024**3
 required=94*pair+2*len(p['q_towers'])*p['degree']*4+ff_reserve+margin
 free=shutil.disk_usage('/tmp').free
 if free<required:raise ValueError('insufficient /tmp space including concurrent FFN reserve and4GiB margin')
 return {'stage':'public-preflight','passed':True,'parameters':p,'actual_log2_qp':bits,'rotations':ROTATIONS,'rotation_key_count':93,'rotation_key_raw_bytes':93*pair,'relinearization_raw_bytes':pair,'concurrent_ffn_reserved_bytes':ff_reserve,'additional_margin_bytes':margin,'minimum_free_bytes':required,'current_free_bytes':free,'raw_output_level':7,'masked_output_level':6,'logical_raw_scores':192,'physical_slots':65536,'encryption_executed':False}

def cleanup(jax,ckks,context=None,graph=None,owner=None):
 primary=sys.exception();failures=[]
 callbacks=[]
 if graph is not None:callbacks.append(graph.clear)
 if owner is not None:callbacks.append(owner.close)
 if context is not None:callbacks.append(lambda:ckks.evict_context_caches(context))
 callbacks.extend((jax.clear_caches,gc.collect))
 for callback in callbacks:
  try:callback()
  except BaseException as error:failures.append(error)
 if failures:
  if primary is not None:
   for error in failures:primary.add_note('Cleanup also failed: '+str(error))
  else:raise RuntimeError('Cleanup failed: '+'; '.join(map(str,failures))) from failures[0]

def setup(root,request_id):
 preflight=public_preflight();jax,Context,ckks,kg=crypto();p=parameters()
 private,public,model=root/'client_only',root/'public',root/'model'
 load_model(model)
 from client_contracts import validate_preprocessing
 preprocessing,rows,_,preprocessing_digest=validate_preprocessing(private,model)
 public.mkdir();start=time.perf_counter();client=None
 try:
  pair=kg.gen_pke_pair(p['q_towers'],[],p['degree'],noise_std=p['sigma'])
  ek=kg.gen_evaluation_key(pair['secret_key'],q=p['q_towers'],P=p['p_towers'],dnum=p['dnum'],noise_std=p['sigma'])
  arrays={'public_key.npy':store_array(public,'public_key.npy',pair['public_key'])}
  for part in ('a','b'):arrays[f'relin_{part}.npy']=store_array(public,f'relin_{part}.npy',ek[part])
  for number,index in enumerate(ROTATIONS,1):
   keys=kg.gen_rotation_key(pair['secret_key'],p['q_towers'],p['p_towers'],index,dnum=p['dnum'],noise_std=p['sigma'])[index]
   for part in ('a','b'):
    name=f'rot_{index}_{part}.npy';arrays[name]=store_array(public,name,keys[part])
   if number%10==0:print(f'client generated {number}/{len(ROTATIONS)} rotation keys',file=sys.stderr,flush=True)
  body={'schema':'bert-qk-scores-public-ckks-v1','streaming_linear_source_sha256':linear_source_sha256(),'score_routing_source_sha256':score_routing_source_sha256(),'parameters':p,'rotations':ROTATIONS,'arrays':arrays,'representation':'standard-ntt-residues/digit-modulus-degree','keygen_source_sha256':sha(kg.__file__),'model_manifest_sha256':sha(model/'model_manifest.json'),'packing':packing_contract()}
  manifest=body|{'context_id':digest(body)};write(public/'public_manifest.json',manifest)
  secret=store_array(private,'secret.npy',pair['secret_key']);os.chmod(private/'secret.npy',0o600)
  client=Context(dict(context_parameters(p),**pair));requests={};rings={};(root/'upload').mkdir()
  from support import require_secure_execution
  for i,role in enumerate(INPUT_ROLES):
   encrypted=client.encrypt_slots(pack_rows(rows[i]));assert getattr(encrypted,'_ckks_nsd',1)==1;encrypted._ckks_nsd=1
   rings[role]=require_secure_execution(client,encrypted)
   requests[role]=save_ciphertext(encrypted,root/'upload'/role,public=manifest,request_id=request_id,role=role)
   del encrypted
  pair_digest=request_digest(requests,public=manifest,request_id=request_id)
  write(private/'private_manifest.json',{'schema':'bert-qk-scores-private-v1','context_id':manifest['context_id'],'request_id':request_id,'request_pair_digest':pair_digest,'request_digests':{role:manifest_digest(value) for role,value in requests.items()},'secret':secret,'preprocessing_sha256':preprocessing_digest,'sample_ids':[9017],'query_row_positions':list(range(16)),'key_row_positions':list(range(112,128))})
  return {'stage':'client-encrypt','passed':True,'context_id':manifest['context_id'],'ring':rings,'actual_log2_qp':preflight['actual_log2_qp'],'elapsed_s':time.perf_counter()-start,'public_key_bytes':sum(f.stat().st_size for f in public.iterdir()),'request_count':2,'request_payload_bytes':2*2*38*131072*4,'storage_preflight':preflight}
 finally:cleanup(jax,ckks,client)

def evaluate(root,request_id):
 private=root/'client_only';blocked=[]
 def audit(event,args):
  if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
   path=Path(os.fsdecode(args[0])).resolve()
   if path==private or private in path.parents:blocked.append(str(path));raise PermissionError('server attempted client-only file access')
 sys.addaudithook(audit)
 jax,Context,ckks,kg=crypto();public,arrays,matrices=load_public(root/'public',root/'model');p=public['parameters']
 def forbidden(*args,**kwargs):raise AssertionError('server client-codec or keygen call forbidden')
 for name in ('key_gen','jaxite_word.key_gen'):
  module=importlib.import_module(name)
  for method in ('gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen'):setattr(module,method,forbidden)
 for method in ('encrypt','encrypt_slots','encrypt_slots_batch','decrypt','decrypt_slots','decrypt_slots_batch'):setattr(Context,method,forbidden)
 from encrypted_ntt import enable_scoped_ntt_subsets
 from encrypted_streaming_linear import StreamingLinear,RowTileLayout
 from encrypted_score_routing import FactoredScoreRouting,FactoredScoreLayout
 from encrypted_packed_qwen import MatrixDiagonals
 from support import require_secure_execution,synchronize
 RowTileLayout.pack_client_rows=forbidden;RowTileLayout.unpack_client_rows=forbidden
 globals()['pack_rows']=forbidden
 context=graph=owner=None;started=time.perf_counter();phases=[]
 try:
  context=Context(dict(context_parameters(p),evaluation_key=[jax.numpy.asarray(arrays[f'relin_{part}.npy']).transpose(0,2,1) for part in ('a','b')]))
  rotations={i:{part:arrays[f'rot_{i}_{part}.npy'] for part in ('a','b')} for i in ROTATIONS}
  context.program_initialization(ROTATIONS,dnum=4,r=256,c=512,batch=1,pregenerated_rotation_keys=rotations)
  assert context.secret_key is None and context._param_cache.secret_key is None and context.parameters.get('secret_key') is None and context.public_key is None
  owner=enable_scoped_ntt_subsets(context);graph=StreamingLinear(context,RowTileLayout(65536),low_memory=True,preserve_dispatch_cache=True);ops=graph.arithmetic
  def phase(label,value,counts=None):
   synchronize(value);item={'label':label,'elapsed_s':time.perf_counter()-started,'level':ops._level(value),'scale':value._ckks_scale,'nsd':value._ckks_nsd}
   if counts is not None:item['counts']=counts
   phases.append(item);print(json.dumps(item),file=sys.stderr,flush=True)
  requests={};projected={}
  for kind,role in zip(KINDS,INPUT_ROLES):
   value,requests[role]=load_ciphertext(root/'upload'/role,public=public,request_id=request_id,role=role);require_secure_execution(context,value)
   weight,bias=matrices[kind];diagonals=MatrixDiagonals(weight,65536,4096)
   if len(diagonals.active)!=1535 or diagonals.n1!=64 or not set(diagonals.rotations)<=set(ROTATIONS):raise ValueError('matrix plan differs from key inventory')
   projected[kind]=graph.linear_tile(value,weight,bias,valid_rows=16);phase(kind+' projection',projected[kind]);del value
   if ops._level(projected[kind])!=17 or projected[kind]._ckks_nsd!=1:raise ValueError('unexpected projection metadata')
  input_digest=request_digest(requests,public=public,request_id=request_id)
  aligned=ops.rotate(projected.pop('key'),OFFSET*4096);phase('cyclic key alignment',aligned)
  expected_scale=expected_product_scale(p,ops._level(aligned),projected['query']._ckks_scale,aligned._ckks_scale)
  reduced=ops.multiply(projected.pop('query'),aligned);del aligned;phase('pointwise QK product',reduced)
  if ops._level(reduced)!=16 or reduced._ckks_nsd!=1 or not math.isclose(reduced._ckks_scale,expected_scale,rel_tol=1e-12):raise ValueError('QK product metadata differs')
  for bit in range(6):
   reduced=ops.add(reduced,ops.rotate(reduced,1<<bit));phase('head sum bit '+str(bit),reduced)
  layout=FactoredScoreLayout(KEY_TILE,OFFSET);router=FactoredScoreRouting(ops,layout,progress=phase)
  raw=router.forward(reduced,gain=1/8);del reduced;phase('raw fused score map',raw)
  if ops._level(raw)!=7 or raw._ckks_nsd!=1:raise ValueError('raw score metadata differs')
  download=root/'download';download.mkdir();records={};responses={}
  rings=require_secure_execution(context,raw)
  response=save_ciphertext(raw,download/'raw_scores',public=public,request_id=request_id,role='raw_scores',input_digest=input_digest)
  responses['raw_scores']=manifest_digest(response);records['raw_scores']={'ring':rings,'level':7,'scale':raw._ckks_scale,'nsd':raw._ckks_nsd,'slots':65536}
  key_rows=KEY_TILE*16+(np.arange(16)+OFFSET)%16
  mask=np.zeros(65536);mask[layout.target_indices]=np.repeat(np.asarray(PUBLIC_ATTENTION_MASK)[key_rows],12)
  masked=ops.weighted_sum([raw],[mask]);del raw;phase('separate public attention key mask',masked)
  if ops._level(masked)!=6 or masked._ckks_nsd!=1:raise ValueError('masked score metadata differs')
  response=save_ciphertext(masked,download/'masked_scores',public=public,request_id=request_id,role='masked_scores',input_digest=input_digest)
  responses['masked_scores']=manifest_digest(response);records['masked_scores']={'ring':require_secure_execution(context,masked),'level':6,'scale':masked._ckks_scale,'nsd':masked._ckks_nsd,'slots':65536};del masked
  write(download/'responses.json',{'schema':'bert-qk-scores-responses-v1','context_id':public['context_id'],'request_id':request_id,'input_digest':input_digest,'outputs':responses})
  if dict(router.counts)!=dict(public_multiplications=17,actual_composite_rescales=17,public_multiplication_levels=9,rotations=9,additions=8):raise ValueError('routing operation counts differ')
  return {'stage':'keyless-server','passed':True,'checks':records,'phases':phases,'server_s':time.perf_counter()-started,'server_secret_absent':True,'client_codecs_and_keygen_forbidden':True,'client_file_access_attempts':blocked,'input_count':2,'output_count':2,'logical_raw_scores':192,'routing_counts':dict(router.counts),'total_operation_plan':{'linear_maps':2,'linear_active_diagonals_per_map':1535,'ciphertext_products':1,'rotations':188,'plaintext_multiplications':3088,'actual_composite_rescales':67,'raw_path_levels':11,'masked_path_levels':12},'no_refresh':True,'full_attention_evaluated':False,'full_bert_evaluated':False}
 finally:cleanup(jax,ckks,context,graph,owner)

def finish(root,request_id):
 jax,Context,ckks,kg=crypto();public,arrays,_=load_public(root/'public',root/'model');p=public['parameters'];private=root/'client_only'
 m=_json(_read_regular(private/'private_manifest.json',65536))
 fields={'schema','context_id','request_id','request_pair_digest','request_digests','secret','preprocessing_sha256','sample_ids','query_row_positions','key_row_positions'}
 if set(m)!=fields or m['schema']!='bert-qk-scores-private-v1' or m['context_id']!=public['context_id'] or m['request_id']!=request_id or m['sample_ids']!=[9017] or m['query_row_positions']!=list(range(16)) or m['key_row_positions']!=list(range(112,128)):raise ValueError('private context identity differs')
 from client_contracts import validate_preprocessing
 prep,_,native,preprocessing_digest=validate_preprocessing(private,root/'model')
 if preprocessing_digest!=m['preprocessing_sha256']:raise ValueError('preprocessing identity differs')
 from transport import validate_ciphertext
 requests={}
 if {x.name for x in (root/'upload').iterdir()}!=set(INPUT_ROLES):raise ValueError('input inventory differs')
 for role in INPUT_ROLES:_,_,_,requests[role]=validate_ciphertext(root/'upload'/role,public=public,request_id=request_id,role=role)
 if ({role:manifest_digest(value) for role,value in requests.items()}!=m['request_digests'] or request_digest(requests,public=public,request_id=request_id)!=m['request_pair_digest']):raise ValueError('request pair identity differs')
 desc=m['secret'];path=private/'secret.npy'
 if set(desc)!={'sha256','dtype','shape'} or path.is_symlink() or sha(path)!=desc['sha256'] or desc['dtype']!='uint32' or desc['shape']!=[38,131072]:raise ValueError('private key differs')
 secret=np.load(path,allow_pickle=False)
 if secret.dtype!=np.uint32 or secret.shape!=(38,131072) or np.any(secret>=np.asarray(p['q_towers'],dtype=np.uint32)[:,None]):raise ValueError('private key residues invalid')
 context=None
 try:
  context=Context(dict(context_parameters(p),secret_key=secret,public_key=arrays['public_key.npy']))
  download=root/'download';aggregate=_json(_read_regular(download/'responses.json',65536))
  expected={'schema':'bert-qk-scores-responses-v1','context_id':public['context_id'],'request_id':request_id,'input_digest':m['request_pair_digest']}
  if set(aggregate)!=set(expected)|{'outputs'} or any(aggregate[k]!=v for k,v in expected.items()) or set(aggregate['outputs'])!=set(OUTPUT_ROLES) or {q.name for q in download.iterdir()}!=set(OUTPUT_ROLES)|{'responses.json'}:raise ValueError('response inventory differs')
  checks={}
  if native.shape!=(2,65536) or native.dtype!=np.float64 or not np.isfinite(native).all():raise ValueError('invalid private reference')
  from encrypted_score_routing import FactoredScoreLayout
  target=FactoredScoreLayout(KEY_TILE,OFFSET).target_indices;inactive=np.ones(65536,bool);inactive[target]=False
  if np.count_nonzero(np.abs(native[0,target])>1e-12)!=192:raise ValueError('raw score gate would be vacuous')
  for i,role in enumerate(OUTPUT_ROLES):
   value,response=load_ciphertext(download/role,public=public,request_id=request_id,role=role,input_digest=m['request_pair_digest'])
   if manifest_digest(response)!=aggregate['outputs'][role]:raise ValueError('response digest differs')
   decoded=np.asarray(context.decrypt_slots(value));diff=np.abs(decoded-native[i]);error=float(diff.max())
   checks[role]={'passed':bool(np.isfinite(decoded).all() and error<=1e-6),'max_abs_error':error,'anchor_max_abs_error':float(diff[target].max()),'inactive_max_abs_error':float(diff[inactive].max()),'slots_checked':65536,'gate':1e-6,'native_target_minimum':float(native[i,target].min()),'native_target_maximum':float(native[i,target].max()),'native_target_nonzero_count_above_1e_12':int(np.count_nonzero(np.abs(native[i,target])>1e-12)),'decoded_target_max_abs':float(np.abs(decoded[target]).max()),'reference_all_zero':bool(not np.any(native[i]))}
   del value,decoded
  return {'stage':'client-decrypt','passed':all(x['passed'] for x in checks.values()),'checks':checks,'worst_abs_error':max(x['max_abs_error'] for x in checks.values()),'all_slots_checked':2*65536,'raw_score_gate_nonvacuous':True,'full_attention_evaluated':False,'full_bert_evaluated':False,'mrpc_accuracy_evaluated':False}
 finally:cleanup(jax,ckks,context)

if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('stage',choices=('preflight','setup','server','finish'));parser.add_argument('--root',type=Path);parser.add_argument('--request-id');args=parser.parse_args()
 if args.stage=='preflight':result=public_preflight()
 else:
  if args.root is None or args.request_id is None:parser.error('--root and --request-id required for cryptographic stages')
  result={'setup':setup,'server':evaluate,'finish':finish}[args.stage](args.root.resolve(),args.request_id)
 print(json.dumps(result,allow_nan=False));raise SystemExit(0 if result['passed'] else 1)
