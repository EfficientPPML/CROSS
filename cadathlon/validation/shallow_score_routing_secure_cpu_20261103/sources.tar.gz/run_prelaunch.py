"""Source-bound backend-free route checks; no ciphertext execution."""
from pathlib import Path
import hashlib
import io
import json
import os
import subprocess
import sys
import tarfile
import time

ROOT=Path(__file__).resolve().parent


def sources():
    paths=set(ROOT.glob('*.py')) | set(ROOT.glob('source_origin.json'))
    for rel in ('jaxite_word','cadathlon/common'):
        paths.update((ROOT/'checkout'/rel).glob('*.py'))
    return {str(p.relative_to(ROOT)):p.read_bytes() for p in sorted(paths)}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    output=Path(sys.argv[1]);output.mkdir(parents=True,exist_ok=False)
    raw=sources();before={name:digest(value) for name,value in raw.items()}
    with tarfile.open(output/'sources.tar.gz','w:gz') as archive:
        for name,data in raw.items():
            info=tarfile.TarInfo(name);info.size=len(data);archive.addfile(info,io.BytesIO(data))
    command=[sys.executable,'-m','pytest','-q','-p','no:cacheprovider','test_routing.py',
        '--junitxml='+str(output/'junit.xml')]
    started=time.perf_counter()
    with (output/'pytest.log').open('w') as stream:
        process=subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,check=False)
    after={name:digest(value) for name,value in sources().items()}
    with tarfile.open(output/'sources.tar.gz') as archive:
        members=archive.getmembers()
        actual={member.name:digest(archive.extractfile(member).read()) for member in members}
        assert len(actual)==len(members) and actual==before
    report=dict(passed=process.returncode==0 and before==after,command=command,returncode=process.returncode,
        source_hashes_before=before,source_hashes_after=after,source_files_unchanged=before==after,
        source_archive_members_verified=True,source_archive_sha256=digest((output/'sources.tar.gz').read_bytes()),
        elapsed_s=time.perf_counter()-started,cpu_affinity=sorted(os.sched_getaffinity(0)),
        scope=__doc__)
    (output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({name:report[name] for name in ('passed','returncode','source_files_unchanged','elapsed_s')}))
    return 0 if report['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
