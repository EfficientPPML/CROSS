"""Isolated secure two-level score routing; no attention, refresh or model claim."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import gc
import hashlib
import importlib.metadata
import io
import json
import math
import os
import resource
import shutil
import signal
import sys
import tarfile
import tempfile
import time

if os.environ.get('JAX_PLATFORMS') != 'cpu':
    raise RuntimeError('explicit CPU backend required')
HERE = Path(__file__).resolve().parent
ROOT = HERE/'checkout'
sys.path[:0] = [str(ROOT), str(ROOT/'cadathlon/common')]
import jax
import numpy as np
from jaxite_word import CKKSContext, ckks_ctx, he_params, key_gen, util
from jaxite_word.composite_prime_gen import composite_prime_gen
from encrypted_ntt import enable_scoped_ntt_subsets
from encrypted_packed_qwen import CompiledArithmetic
from encrypted_refresh import ClientRotationKeyStore
from encrypted_shallow_score_routing import ShallowScoreLayout, ShallowScoreRouting, SLOTS
from support import require_secure_execution
from lifecycle import CleanupTracker
jax.config.update('jax_enable_x64', True)


def sources():
    paths = set(HERE.glob('*.py')) | set(HERE.glob('source_origin.json'))
    for folder in ('jaxite_word', 'cadathlon/common'):
        paths.update((ROOT/folder).glob('*.py'))
    return {str(p.relative_to(HERE)): p.read_bytes() for p in sorted(paths)}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')
    temporary.replace(path)


def parameters():
    degree, depth, dnum = 131072, 5, 4
    q = composite_prime_gen(2, 2*(depth+1), 61, 56, 2*degree, 31)
    p = util.generate_p_towers(q, dnum, degree, aux_bits=30)
    if not he_params.qp_is_secure(q, p, degree, he_params.SecurityTarget(128, 'classical')):
        raise ValueError('insecure actual Q/P ring')
    he_params.assert_p_coverage(q, p, dnum)
    alpha = math.ceil(len(q)/dnum)
    parts = math.ceil(len(q)/alpha)
    shape = (parts, len(q)+len(p), degree)
    rotations = ShallowScoreLayout(7,15).rotation_indices()
    pair_bytes = 2*math.prod(shape)*4
    owned = (len(rotations)+1)*pair_bytes + 2*len(q)*degree*4
    return dict(degree=degree, depth=depth, dnum=dnum, q_towers=q, p_towers=p,
        degree_layout=[256,512], slots=SLOTS, actual_log2_qp=sum(map(math.log2,q+p)),
        security_bits=128, scale=float(q[-2])*q[-1], rotation_indices=rotations,
        actual_switch_partitions=parts, key_pair_shape=shape, raw_key_pair_bytes=pair_bytes,
        raw_all_owned_public_key_bytes=owned, key_storage_parent='/tmp',
        current_key_storage_free_bytes=shutil.disk_usage('/tmp').free,
        additional_storage_margin_bytes=4*1024**3, key_tile=7, offset=15,
        independent_slot_input=True, expected_total_rotations=108,
        expected_total_public_multiplications=112, expected_total_rescales=8)


def oracle(values, gain):
    compact = np.zeros(SLOTS)
    forward = np.zeros(SLOTS)
    back = np.zeros(SLOTS)
    for row in range(16):
        key = 112 + (row+15) % 16
        for head in range(12):
            scalar = values[row*4096+head*64]*gain
            compact[row*4096+head] = scalar
            forward[row*4096+key*16+head] = scalar
            back[row*4096+head*64] = scalar
    return {'head compaction':compact, 'key placement':forward,
            'key extraction':compact.copy(), 'head expansion':back}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--preflight', action='store_true')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    raw = sources()
    before = {name:sha(value) for name,value in raw.items()}
    with tarfile.open(args.output/'sources.tar.gz','w:gz') as archive:
        for name,data in raw.items():
            info=tarfile.TarInfo(name); info.size=len(data)
            archive.addfile(info,io.BytesIO(data))
    started = time.monotonic()
    report = dict(scope=__doc__,passed=False,source_hashes_before=before,phases=[],checks={},
        source_archive_sha256=sha((args.output/'sources.tar.gz').read_bytes()),
        started_utc=datetime.now(timezone.utc).isoformat(),fixed_absolute_error_gate=1e-6,
        cpu_affinity=sorted(os.sched_getaffinity(0)),process_pid=os.getpid(),
        versions={name:importlib.metadata.version(name) for name in ('jax','jaxlib','numpy')},
        environment={name:os.environ.get(name) for name in ('JAX_PLATFORMS','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')},
        limitations=['One public tile/offset with two fixed gains; not all maps encrypted.',
            'Client and keyless server are separate objects in one dedicated process, not an OS sandbox.',
            'All codec APIs are blocked during server arithmetic; validation occurs only afterward.',
            'No model input, full attention, refresh, TPU timing or calibrated speed comparison.'])
    client=server=ops=provider=key_store=key_parent=encrypted=router=None
    keys=evaluation=value=None
    retained=[];patched=[];codec_patches=[];old_handlers={}

    def phase(label, value=None, counts=None):
        if value is not None:
            value.polynomial.block_until_ready()
        row=dict(label=label,elapsed_s=time.monotonic()-started,
            peak_host_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        if value is not None:
            row.update(level=ops._level(value),scale=value._ckks_scale,nsd=value._ckks_nsd)
        if counts is not None:
            row['counts']=dict(counts)
        report['phases'].append(row)
        write(args.output/'report.json',report)
        print(json.dumps(row),flush=True)

    def interrupted(signum,frame):
        for number in old_handlers:
            signal.signal(number,signal.SIG_IGN)
        raise KeyboardInterrupt(f'interrupted by signal {signum}')

    def forbidden(*args,**kwargs):
        raise AssertionError('client codec or secret-key generation during server computation')

    try:
        write(args.output/'report.json',report)
        for number in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):
            old_handlers[number]=signal.signal(number,interrupted)
        ring=parameters();report['ring']=ring
        if ring['current_key_storage_free_bytes'] < ring['raw_all_owned_public_key_bytes']+ring['additional_storage_margin_bytes']:
            raise ValueError('insufficient available storage for owned keys plus4GiB margin')
        if jax.default_backend()!='cpu' or any(d.platform!='cpu' for d in jax.devices()):
            raise ValueError('explicit CPU backend not honored')
        phase('actual-ring, P-coverage and resource preflight passed')
        if args.preflight:
            report.update(passed=True,preflight_only=True)
        else:
            q,p,N,dnum=ring['q_towers'],ring['p_towers'],ring['degree'],ring['dnum']
            scale=ring['scale'];rotations=ring['rotation_indices']
            key_parent=tempfile.TemporaryDirectory(prefix='cross-shallow-score-keys-',dir=ring['key_storage_parent'])
            report['owned_public_key_parent']=key_parent.name
            phase('client key generation started')
            keys=key_gen.gen_pke_pair(q,[],N)
            evaluation=key_gen.gen_evaluation_key(keys['secret_key'],q=q,P=p,dnum=dnum)
            key_store=ClientRotationKeyStore.generate(keys['secret_key'],q,p,degree=N,dnum=dnum,
                rotations=rotations,directory=key_parent.name)
            report['public_rotation_key_storage_bytes']=sum(path.stat().st_size for path in Path(key_parent.name).rglob('*.npy'))
            params=dict(degree=N,num_slots=SLOTS,scaling_factor=scale,output_scale=scale,
                q_towers=q,p_towers=p,composite_degree=2,degree_layout=(256,512),p=56,
                CKKS_M_FACTOR=1,max_bits_in_word=61,noise_scale_degree=1)
            client=CKKSContext(dict(params,**keys))
            server=CKKSContext(dict(params,evaluation_key=[jax.numpy.asarray(evaluation[name],dtype='uint32').transpose(0,2,1) for name in ('a','b')]))
            for module in {key_gen,sys.modules.get('key_gen')}-{None}:
                for name in ('gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen'):
                    patched.append((module,name,getattr(module,name)));setattr(module,name,forbidden)
            report['key_generation_guards']=sorted({module.__name__ for module,_,_ in patched})
            if set(report['key_generation_guards'])!={'jaxite_word.key_gen','key_gen'}:
                raise RuntimeError('both key-generation aliases must be guarded')
            server.program_initialization(rotations,dnum=dnum,r=256,c=512,batch=1,pregenerated_rotation_keys=key_store.keys)
            if any(x is not None for x in (server.secret_key,server._param_cache.secret_key,server.parameters.get('secret_key'))):
                raise RuntimeError('server has secret key material')
            report['keyless_server']=True
            client._polynomial_ntt_ctx=server._param_cache.ntt_q_max
            provider=enable_scoped_ntt_subsets(server)
            ops=CompiledArithmetic(server,low_memory=True,preserve_dispatch_cache=True)
            keys=evaluation=None
            rng=np.random.default_rng(2026110317)
            values=rng.uniform(-40.,40.,SLOTS)
            values[ShallowScoreLayout(7,15).source_indices]=np.linspace(-7.,7.,192)
            report['input_contract']=dict(public_seed=2026110317,hostile_nonanchor_padding=True,
                independent_physical_slots=SLOTS,source_anchors=192,
                min_value=float(values.min()),max_value=float(values.max()),
                value_sha256=sha(values.astype('<f8').tobytes()))
            encrypted=client.encrypt_slots(values);encrypted._ckks_nsd=1
            report['input_security']=require_secure_execution(server,encrypted)
            before_payload=sha(np.asarray(encrypted.polynomial).tobytes())
            before_metadata=(encrypted._ckks_scale,encrypted._ckks_nsd,ops._level(encrypted))
            for name in ('encrypt','decrypt','encrypt_slots','decrypt_slots','encrypt_slots_batch','decrypt_slots_batch'):
                codec_patches.append((CKKSContext,name,getattr(CKKSContext,name)))
                setattr(CKKSContext,name,forbidden)
            report['class_codec_guards']=[name for _,name,_ in codec_patches]
            phase('input encrypted at level5; all client codecs guarded',encrypted)
            counts={}
            for gain in (1.,.125):
                def capture(label,value,observed,gain=gain):
                    retained.append((gain,label,value))
                    phase(f'gain{gain} {label}',value,observed)
                router=ShallowScoreRouting(ops,ShallowScoreLayout(7,15),progress=capture)
                output=router.forward(encrypted,gain=gain)
                backward=router.inverse(output)
                for name,count in router.counts.items():
                    counts[name]=counts.get(name,0)+count
            report['counts']=counts
            if (counts['rotations']!=108 or counts['public_multiplications']!=112
                    or counts['actual_composite_rescales']!=8):
                raise RuntimeError('observed operation schedule differs')
            report['server_complete_before_client_validation']=True
            phase('all eight encrypted checkpoints complete; enabling final client validation')
            for module,name,original in codec_patches:
                setattr(module,name,original)
            codec_patches.clear()
            references={gain:oracle(values,gain) for gain in (1.,.125)}
            expected_levels={'head compaction':4,'key placement':3,'key extraction':2,'head expansion':1}
            for gain,label,value in retained:
                expected=references[gain][label]
                decoded=np.asarray(client.decrypt_slots(value))
                error=float(np.max(np.abs(decoded-expected)))
                level=ops._level(value)
                metadata=level==expected_levels[label] and value._ckks_nsd==1 and math.isclose(value._ckks_scale,scale,rel_tol=1e-12)
                report['checks'][f'{gain}:{label}']=dict(passed=bool(error<=1e-6 and metadata),
                    max_abs_error=error,inactive_max_abs=float(np.max(np.abs(decoded[expected==0]))),
                    slots_checked=SLOTS,level=level,scale=value._ckks_scale,nsd=value._ckks_nsd,
                    metadata_ok=metadata,execution_rings=require_secure_execution(server,value))
            report['input_payload_unchanged']=sha(np.asarray(encrypted.polynomial).tobytes())==before_payload
            report['input_metadata_unchanged']=(encrypted._ckks_scale,encrypted._ckks_nsd,ops._level(encrypted))==before_metadata
            report['passed']=bool(len(report['checks'])==8 and all(row['passed'] for row in report['checks'].values())
                and report['input_payload_unchanged'] and report['input_metadata_unchanged'])
            report['provider_stats']=dict(provider.stats)
            phase('final all-slot client validation complete')
    except BaseException as error:
        report.update(passed=False,error=f'{type(error).__name__}: {error}')
        raise
    finally:
        primary=sys.exception();tracker=CleanupTracker(primary)
        cleanup=tracker.errors;attempt=tracker.attempt
        for module,name,original in codec_patches:
            attempt('restore codec guard',lambda:setattr(module,name,original))
        if provider is not None:attempt('provider.close',provider.close)
        if ops is not None:
            attempt('rotation.clear',lambda:ops.rotation.clear(executables=True))
            for helper in (ops._plaintext_multiply,ops._rescale):
                attempt('compiled primitive clear',lambda:helper.clear(executables=True))
            attempt('multiplication compiler clear',ops._multiplication_compiler.clear_executables)
        for context in (server,client):
            if context is not None:attempt('evict context caches',lambda:ckks_ctx.evict_context_caches(context))
        context=keys=evaluation=encrypted=router=ops=server=client=value=output=backward=None
        retained.clear()
        attempt('jax.clear_caches',jax.clear_caches);attempt('gc.collect',gc.collect)
        if key_store is not None:attempt('key_store.close',key_store.close)
        if key_parent is not None:attempt('key_parent.cleanup',key_parent.cleanup)
        for module,name,original in patched:
            attempt('restore key generation guard',lambda:setattr(module,name,original))
        for number,handler in old_handlers.items():
            attempt('restore signal handler',lambda:signal.signal(number,handler))
        data=attempt('source verification',sources)
        after={name:sha(content) for name,content in data.items()} if data is not None else {}
        def verify_source_archive():
            with tarfile.open(args.output/'sources.tar.gz') as archive:
                members=archive.getmembers()
                if len(members)!=len(before) or {m.name for m in members}!=set(before):
                    raise ValueError('source inventory differs')
                for member in members:
                    if not member.isfile() or sha(archive.extractfile(member).read())!=before[member.name]:
                        raise ValueError('source archive bytes differ')
            return True
        verified=attempt('verify source archive',verify_source_archive)
        report.update(source_hashes_after=after,source_files_unchanged=before==after,
            source_archive_members_verified=verified is True,cleanup_errors=cleanup,
            public_key_store_removed=key_parent is None or not Path(key_parent.name).exists(),
            elapsed_s=time.monotonic()-started,peak_host_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            finished_utc=datetime.now(timezone.utc).isoformat())
        report['passed']=bool(report['passed'] and before==after and verified and not cleanup and report['public_key_store_removed'])
        try:write(args.output/'report.json',report)
        except BaseException as publication_error:
            preserved=primary if primary is not None else tracker.cancellation
            if preserved is None:raise
            preserved.add_note(f'Final report publication failed: {publication_error}')
        tracker.finish()
    return 0 if report['passed'] else 1


if __name__=='__main__':
    raise SystemExit(main())
