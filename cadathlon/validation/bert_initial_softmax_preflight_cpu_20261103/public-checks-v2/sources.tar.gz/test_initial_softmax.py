"""Independent full-slot plaintext/level model, not an encrypted numerical proof."""
from pathlib import Path
from types import SimpleNamespace
import sys,copy,json,math,hashlib
import numpy as np
import pytest
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE/'checkout/cadathlon/common')]
import encrypted_bert_initial_softmax as initial
import encrypted_scaled_newton as newton
from encrypted_score_reduction import ScoreReductionLayout,ScoreReduction,SLOTS

PROFILE=json.loads((HERE/'public_profile.json').read_text())
Q=tuple(PROFILE['q']);DELTA=PROFILE['canonical_scale']
CONTRACT=initial.InitialSoftmaxContract.from_manifest_bytes((HERE/'candidate_manifest.json').read_bytes())

class Value:
    batch=1;degree=2*SLOTS;num_elements=2
    def __init__(self,data,level=38,scale=DELTA):
        self.data=np.array(data,dtype=np.float64,copy=True);self.polynomial=self.data
        self.level=level;self._ckks_scale=scale;self._ckks_nsd=1
        self.moduli=Q[:2*(level+1)];self.ntt_ctx=None;self._public_row_l2_bound='stale'

class Arithmetic:
    scale=DELTA;refresher=None
    def __init__(self):
        self.ctx=SimpleNamespace(degree=2*SLOTS,num_slots=SLOTS,composite_degree=2,secret_key=None,parameters={},
            _param_cache=SimpleNamespace(secret_key=None,batch=1,q_towers=list(Q),p_towers=list(PROFILE['p']),q_moduli_at_level=lambda L:Q[:2*(L+1)]))
        self.calls=[]
    def _level(self,value):
        if type(value._ckks_nsd)is not int or value._ckks_nsd!=1:raise ValueError('invalid NSD')
        return value.level
    def rotate(self,value,shift):self.calls.append('rotate');return Value(np.roll(value.data,-shift),value.level,value._ckks_scale)
    def add(self,left,right):self.calls.append('add');return Value(left.data+right.data,min(left.level,right.level),left._ckks_scale)
    def weighted_sum(self,values,weights,*,bias=0.):
        self.calls.append('weighted_sum');return Value(sum(v.data*w for v,w in zip(values,weights))+bias,min(v.level for v in values)-1)
    def multiply(self,left,right):
        self.calls.append('multiply');L=min(left.level,right.level)
        return Value(left.data*right.data,L-1,left._ckks_scale*right._ckks_scale/(Q[2*L]*Q[2*L+1]))

@pytest.fixture(autouse=True)
def ideal_primitives(monkeypatch):
    monkeypatch.setitem(sys.modules,'encrypted_packed_qwen',SimpleNamespace(CompiledArithmetic=Arithmetic))
    monkeypatch.setitem(sys.modules,'jaxite_word',SimpleNamespace(Polynomial=Value))
    monkeypatch.setitem(sys.modules,'support',SimpleNamespace(require_secure_execution=lambda *a:None))
    def affine(arithmetic,value,weight,bias,*,output_scale):
        arithmetic.calls.append('initial_affine');L=value.level;divisor=Q[2*L]*Q[2*L+1]
        encoded=output_scale*divisor/value._ckks_scale
        return Value(value.data*weight+bias,L-1,value._ckks_scale*encoded/divisor)
    def integer(arithmetic,value,multiplier,*,bias=0.):
        arithmetic.calls.append('integer_affine');return Value(value.data*multiplier+bias,value.level,value._ckks_scale)
    monkeypatch.setattr(newton,'affine_at_scale',affine);monkeypatch.setattr(newton,'integer_affine',integer)


def independent(scores,mask,valid):
    output=np.zeros(SLOTS);mean=np.zeros(SLOTS);base=np.zeros(SLOTS);den=np.ones(SLOTS);inverse=np.zeros(SLOTS)
    masks=np.broadcast_to(mask,(16,128));coef=np.array(CONTRACT.exponential_coefficients)
    inv_dummy=1*(-.8*.8)+2*.8
    for _ in range(5):inv_dummy*=2-inv_dummy
    inverse.fill(inv_dummy)
    for row in range(valid):
        keys=np.flatnonzero(masks[row])
        for head in range(12):
            chosen=row*4096+keys*16+head;broadcast=row*4096+np.arange(128)*16+head
            values=scores[chosen];mu=values.mean();centered=values-mu
            assert np.max(np.abs(centered))<=16.
            exponent=np.polynomial.chebyshev.chebval(centered/16,coef)
            denominator=exponent.mean();assert .5<=denominator<=2.
            y=denominator*(-.8*.8)+2*.8
            for _ in range(5):y=y*(2-denominator*y)
            mean[broadcast]=mu;base[chosen]=exponent;den[broadcast]=denominator;inverse[broadcast]=y
            output[chosen]=exponent*y/len(keys)
    return output,mean,base,den,inverse

@pytest.mark.parametrize('valid',(1,7,16))
@pytest.mark.parametrize('pattern',('all','first15','last','boundaries','perrow'))
def test_all_slots_distinct_rows_masks_padding_and_frozen_polynomial(valid,pattern):
    k=np.arange(128);mask={'all':np.ones(128,bool),'first15':k<15,'last':k==127,
        'boundaries':np.isin(k,[0,15,16,63,64,111,112,127]),
        'perrow':np.array([k%(row+2)==row%(row+2) for row in range(16)])}[pattern]
    layout=ScoreReductionLayout(mask,valid_rows=valid);ops=Arithmetic();owner=initial.BertInitialSoftmax(ops,layout,CONTRACT)
    rng=np.random.default_rng(12+valid);scores=rng.uniform(-7,7,SLOTS)
    for row in range(16):scores[row*4096:(row+1)*4096]+=row*4-25
    scores[layout.input_mask==0]=rng.choice([-10000.,10000.],int(np.sum(layout.input_mask==0)))
    original=Value(scores);saved=copy.deepcopy(vars(original));out,stages=owner.evaluate_tile(original,capture_checkpoints=True)
    expected,mean,base,den,inv=independent(scores,mask,valid)
    for key,oracle in [('probabilities',expected),('score_mean',mean),('base_exp',base),('mean_exp',den),('inverse',inv)]:
        np.testing.assert_allclose(stages[key].data,oracle,atol=3e-14,rtol=2e-14)
    assert [stages[k].level for k in ('score_mean','normalized_t','base_exp','mean_exp','inverse','base_times_inverse','probabilities')]==[36,35,31,29,18,17,16]
    assert out._ckks_scale==DELTA and out._ckks_nsd==1
    assert np.all(out.data[layout.input_mask==0]==0)
    assert np.all(stages['normalized_t'].data[layout.input_mask==0]==0)
    assert np.max(np.abs(stages['normalized_t'].data))<=1.
    assert np.all((stages['mean_exp'].data>=.5)&(stages['mean_exp'].data<=2.))
    for value in stages.values():assert not any(k.startswith('_public_') for k in vars(value))
    np.testing.assert_array_equal(original.data,saved['data']);assert original._public_row_l2_bound=='stale'
    assert ops.calls.count('rotate')==28 and ops.calls.count('multiply')==18
    assert owner.last_plan['implemented_squaring_rounds']==0

@pytest.mark.parametrize('mutation',('ctx_secret','cache_secret','parameters_secret','context','cache','scale','layout','layout_payload','q','p','value_scale','value_nsd','value_payload'))
def test_progress_continuation_rejected_before_next_primitive(mutation):
    ops=Arithmetic();layout=ScoreReductionLayout(np.ones(128,bool));calls=[]
    def progress(label,value,counts):
        calls.append(len(ops.calls))
        if mutation=='ctx_secret':ops.ctx.secret_key=object()
        elif mutation=='cache_secret':ops.ctx._param_cache.secret_key=object()
        elif mutation=='parameters_secret':ops.ctx.parameters['secret_key']=object()
        elif mutation=='context':ops.ctx=Arithmetic().ctx
        elif mutation=='cache':ops.ctx._param_cache=Arithmetic().ctx._param_cache
        elif mutation=='scale':ops.scale*=2
        elif mutation=='layout':graph.layout=ScoreReductionLayout(np.ones(128,bool))
        elif mutation=='layout_payload':layout.input_mask.setflags(write=True);layout.input_mask[0]=0
        elif mutation=='q':ops.ctx._param_cache.q_towers.reverse()
        elif mutation=='p':ops.ctx._param_cache.p_towers.reverse()
        elif mutation=='value_scale':value._ckks_scale*=2
        elif mutation=='value_nsd':value._ckks_nsd=True
        else:value.polynomial=value.polynomial.copy()
    graph=ScoreReduction(ops,layout,progress=progress)
    with pytest.raises(ValueError):graph.mean(Value(np.ones(SLOTS)))
    assert calls==[len(ops.calls)] and ops.calls==['weighted_sum']


def test_callback_cancellation_never_continues_or_closes_borrowed_context():
    ops=Arithmetic();ctx=ops.ctx;error=KeyboardInterrupt('stop')
    def progress(*a):raise error
    graph=ScoreReduction(ops,ScoreReductionLayout(np.ones(128,bool)),progress=progress)
    with pytest.raises(KeyboardInterrupt) as caught:graph.mean(Value(np.ones(SLOTS)))
    assert caught.value is error and ops.ctx is ctx and ops.calls==['weighted_sum']


def test_contract_byte_and_static_capacity_rejections_precede_arithmetic():
    raw=(HERE/'candidate_manifest.json').read_bytes()
    with pytest.raises(ValueError):initial.InitialSoftmaxContract.from_manifest_bytes(raw+b' ')
    with pytest.raises(ValueError):initial.InitialSoftmaxContract(tuple([1.]*9))
    ops=Arithmetic();owner=initial.BertInitialSoftmax(ops,ScoreReductionLayout(np.ones(128,bool)),CONTRACT)
    with pytest.raises(ValueError):owner.evaluate_tile(Value(np.zeros(SLOTS),23))
    assert ops.calls==[]
    ops.refresher=object()
    with pytest.raises(ValueError):owner.evaluate_tile(Value(np.zeros(SLOTS)))
    assert ops.calls==[]


def test_actual_public_profile_scale_plan_and_remaining_capacity():
    plan=initial.initial_softmax_plan(Q[:78],input_level=38,canonical_scale=DELTA)
    assert plan['consumed_levels']==22 and plan['levels']['probabilities']==16
    assert len(plan['static_inverse_scale_plan']['rows'])==6
    assert abs(plan['actual_product_scale']/DELTA-1)<1e-11
    for level in (24,38,49):
        p=initial.initial_softmax_plan(Q[:2*(level+1)],input_level=level,canonical_scale=DELTA)
        assert p['levels']['probabilities']==level-22
    assert 'jax' not in sys.modules

@pytest.mark.parametrize('keys',range(1,129))
def test_every_public_key_count_with_distinct_row_masks(keys):
    positions=np.arange(128)
    mask=np.array([((positions+7*row)%128)<keys for row in range(16)])
    layout=ScoreReductionLayout(mask);ops=Arithmetic();graph=initial.BertInitialSoftmax(ops,layout,CONTRACT)
    scores=np.random.default_rng(10000+keys).uniform(-7.,7.,SLOTS)
    for row in range(16):scores[row*4096:(row+1)*4096]+=row*3
    scores[layout.input_mask==0]=9999.
    output=graph.evaluate_tile(Value(scores))
    expected,*_=independent(scores,mask,16)
    np.testing.assert_allclose(output.data,expected,atol=2e-14,rtol=2e-14)
    values=output.data.reshape(16,4096)[:,:2048].reshape(16,128,16)
    np.testing.assert_allclose(values[:,:,:12].sum(axis=1),1.,atol=2e-14,rtol=0)
    assert np.all(output.data[layout.input_mask==0]==0)

@pytest.mark.parametrize('bad_nsd',(True,1.0))
@pytest.mark.parametrize('target',('callback_output','captured_input'))
@pytest.mark.parametrize('phase',('first','final'))
def test_callback_exact_nsd_type_is_guarded_even_when_level_accessor_is_permissive(bad_nsd,target,phase):
    ops=Arithmetic()
    # Core level lookup does not provide the callback's exact-type guarantee.
    # Keep this test independent of the stricter test-double accessor above.
    ops._level=lambda value:value.level
    original=Value(np.zeros(SLOTS));callbacks=[];at_mutation=[]
    def progress(label,value,counts):
        callbacks.append(label)
        if (phase=='first' and len(callbacks)==1) or (phase=='final' and label=='initial softmax probabilities'):
            (original if target=='captured_input' else value)._ckks_nsd=bad_nsd
            at_mutation.append(len(ops.calls))
    graph=initial.BertInitialSoftmax(ops,ScoreReductionLayout(np.ones(128,bool)),CONTRACT,progress=progress)
    with pytest.raises(ValueError):graph.evaluate_tile(original)
    assert len(at_mutation)==1 and at_mutation[0]==len(ops.calls)
    if phase=='first':assert ops.calls==['weighted_sum']
    assert graph.last_plan is None

@pytest.mark.parametrize('owner,name,replacement',[
    ('ctx','degree_layout',(512,256)),('ctx','degree_layout',[256,512]),
    ('cache','degree_layout',(512,256)),('cache','degree_layout',[256,512]),
    ('ctx','dnum',8),('cache','dnum',8),('cache','dnum',4.0),
    ('cache','composite_degree',1),('cache','composite_degree',2.0),
])
def test_callback_changed_primitive_interpretation_is_rejected_before_continuation(owner,name,replacement):
    ops=Arithmetic();ops.ctx.degree_layout=(256,512);ops.ctx.dnum=4
    ops.ctx._param_cache.degree_layout=(256,512);ops.ctx._param_cache.dnum=4
    ops.ctx._param_cache.composite_degree=2
    def progress(*args):
        setattr(ops.ctx if owner=='ctx' else ops.ctx._param_cache,name,replacement)
    graph=initial.BertInitialSoftmax(ops,ScoreReductionLayout(np.ones(128,bool)),CONTRACT,progress=progress)
    with pytest.raises(ValueError):graph.evaluate_tile(Value(np.zeros(SLOTS)))
    assert ops.calls==['weighted_sum']
