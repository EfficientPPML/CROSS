"""Source-bound public-only arithmetic/layout regression and preflight collector."""
from pathlib import Path
import hashlib,io,json,subprocess,sys,tarfile,time
HERE=Path(__file__).resolve().parent

def main():
    output=HERE/'public-checks-v2';output.mkdir(exist_ok=False)
    selected=[*sorted(HERE.glob('*.py')),*sorted(HERE.glob('*.json')),*sorted((HERE/'checkout').rglob('*.py'))]
    selected=[p for p in selected if p.name!='public_plan.json']
    before={str(p.relative_to(HERE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in selected}
    report=dict(passed=False,scope=__doc__,source_hashes_before=before);start=time.monotonic()
    with tarfile.open(output/'sources.tar.gz','w:gz') as archive:
        for p in selected:
            raw=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(HERE)));info.size=len(raw);archive.addfile(info,io.BytesIO(raw))
    try:
        for name,args in [('tests',[sys.executable,'-m','pytest','-q','test_initial_softmax.py','test_reduction.py']),('public_plan',[sys.executable,'plan_public.py'])]:
            with (output/(name+'.log')).open('w') as log:process=subprocess.run(args,cwd=HERE,stdout=log,stderr=subprocess.STDOUT)
            report[name+'_exit_code']=process.returncode
            if process.returncode:raise ValueError(name+' failed')
        report['passed']=True
    except BaseException as error:report.update(error=repr(error));raise
    finally:
        after={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in before}
        with tarfile.open(output/'sources.tar.gz') as archive:
            members=archive.getmembers();verified=len(members)==len(before) and {m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in members}==before
        report.update(source_hashes_after=after,source_files_unchanged=before==after,source_archive_verified=verified,
            source_archive_sha256=hashlib.sha256((output/'sources.tar.gz').read_bytes()).hexdigest(),elapsed_s=time.monotonic()-start)
        report['passed']=bool(report['passed'] and before==after and verified)
        (output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    return 0 if report['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
