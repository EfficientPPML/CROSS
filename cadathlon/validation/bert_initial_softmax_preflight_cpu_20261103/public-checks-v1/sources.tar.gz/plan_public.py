"""Exact frozen initial-softmax public resource/scale plan; no backend import."""
from pathlib import Path
import sys,json,hashlib,math
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'checkout/cadathlon/common'))
from encrypted_bert_initial_softmax import InitialSoftmaxContract,initial_softmax_plan
from encrypted_score_reduction import ScoreReductionLayout

def main():
    contract=InitialSoftmaxContract.from_manifest_bytes((HERE/'candidate_manifest.json').read_bytes())
    profile=json.loads((HERE/'public_profile.json').read_text());q,p=profile['q'],profile['p'];N=profile['degree'];d=profile['dnum']
    alpha=math.ceil(len(q)/d);parts=math.ceil(len(q)/alpha)
    assert N==131072 and math.prod(q+p).bit_length()<=3523
    assert math.prod(p)>=max(math.prod(q[i:i+alpha]) for i in range(0,len(q),alpha))
    rotations=ScoreReductionLayout.rotation_indices();pair=2*parts*(len(q)+len(p))*N*4
    levels={str(L):initial_softmax_plan(q[:2*(L+1)],input_level=L,canonical_scale=profile['canonical_scale']) for L in (24,38,49)}
    report=dict(scope=__doc__,passed=True,manifest_sha256=contract.source_manifest_sha256,
        initialized_context=False,key_generation=False,encrypted_execution=False,logical_layout={'rows':16,'keys':128,'active_heads':12,'padded_heads':16,'row_pitch':4096,'physical_slots':65536},
        all_rows_distinct=True,public_per_row_masks=True,partial_queries=True,critical_path_levels=22,reserved_output_levels=2,
        exponential_degree=8,initial_reciprocal_updates=6,initial_seed=.8,initial_rounded_weight=-.8*.8,initial_rounded_bias=2*.8,
        initial_inverse_domain=[.5,2.],centered_score_domain=[-16.,16.],squaring_rounds_implemented=0,squaring_rounds_still_required=5,
        actual_profile={k:profile[k] for k in ('degree','depth','scale_bits','dnum','Q_count','P_count','log2_QP','canonical_scale','base_Q_over_scale')},
        actual_ordered_q=q,actual_ordered_p=p,recorded_secure_profile=profile['qp_is_secure'],integer_QP_bit_length=math.prod(q+p).bit_length(),P_coverage_rechecked=True,
        rotation_indices=list(rotations),rotation_key_count=len(rotations),raw_rotation_key_bytes=len(rotations)*pair,raw_relinearization_key_bytes=pair,
        raw_ciphertext_bytes_at38=2*78*N*4,logical_operations={'ciphertext_products':18,'plaintext_products':16,'nonzero_rotations':28,'composite_rescales':26},
        plans_by_input_level=levels,no_jax_imported='jax' not in sys.modules,
        limitations=['Public ideal/static planning only; no ciphertext numerical pass or newly generated security profile.',
            'No future normalized-squaring, genuine refresh, attention/V aggregation, block or full-model result.',
            'Bounds are declared input contracts, not ciphertext checks or inferred from the observed fixtures.',
            'Raw key/ciphertext payload excludes tables, compiler, formatted keys, host/device temporary buffers and peak-memory overhead.'])
    assert report['no_jax_imported']
    (HERE/'public_plan.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ('passed','critical_path_levels','rotation_key_count','raw_rotation_key_bytes','logical_operations','no_jax_imported')},indent=2))
if __name__=='__main__':main()
