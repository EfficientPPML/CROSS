from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
import json
import hashlib
import io
import tarfile
import sys
import pytest
import validate_heldout as v


@pytest.mark.parametrize('primary', [ValueError('primary'), KeyboardInterrupt('primary')])
@pytest.mark.parametrize('scope_error', [OSError('scope'), SystemExit('scope')])
def test_scope_failure_preserves_primary_and_publishes_false(tmp_path, monkeypatch, primary, scope_error):
    def fail(*args):
        raise primary
    @contextmanager
    def shield():
        try:
            yield
        finally:
            raise scope_error
    monkeypatch.setattr(v.validation_gate, 'verify', fail)
    monkeypatch.setattr(v, 'cleanup_signals', shield)
    with pytest.raises(type(primary)) as caught:
        v.collect(SimpleNamespace(output=tmp_path/'run', calibration_report=tmp_path/'unused', calibration_source_archive=tmp_path/'unused2'))
    assert caught.value is primary
    assert json.loads((tmp_path/'run/report.json').read_text())['passed'] is False


@pytest.mark.parametrize('restoration', [OSError('restore'), KeyboardInterrupt('restore')])
def test_main_scope_restoration_cannot_leave_success_json(tmp_path, monkeypatch, restoration):
    output = tmp_path / 'run'
    def successful(args):
        args.output.mkdir()
        v.write(args.output/'report.json', dict(passed=True, errors=[]))
        return 0
    @contextmanager
    def scope():
        try:
            yield
        finally:
            raise restoration
    monkeypatch.setattr(v, 'collect', successful)
    monkeypatch.setattr(v, 'termination_signals', scope)
    monkeypatch.setattr(sys, 'argv', ['validate_heldout.py', '--output', str(output), '--calibration-report', 'unused', '--calibration-source-archive', 'unused'])
    with pytest.raises(type(restoration)) as caught:
        v.main()
    assert caught.value is restoration
    result = json.loads((output/'report.json').read_text())
    assert result['passed'] is False and result['errors'][-1]['phase'] == 'termination_scope'


@pytest.mark.parametrize('phase', ['first_open', 'archive_hash', 'token_parse'])
def test_failed_fresh_read_never_claims_known_unread(tmp_path, monkeypatch, phase):
    archive=tmp_path/'synthetic.tar'
    expected={}
    with tarfile.open(archive,'w') as tar:
        for i in range(11):
            name=f'synthetic{i}.py';raw=b'public synthetic source'
            member=tarfile.TarInfo(name);member.size=len(raw);tar.addfile(member,io.BytesIO(raw))
            expected[name]=hashlib.sha256(raw).hexdigest()
    tokens=tmp_path/'synthetic.json';tokens.write_bytes(b'not JSON; synthetic parse failure only')
    token_hash=v.sha(tokens)
    req=dict(validation_input_sha256=token_hash,fresh_freeze=dict(report_sha256='synthetic metadata',
             archive_sha256=v.sha(archive),tokenized_sha256=token_hash))
    if phase=='archive_hash':req['validation_input_sha256']='0'*64
    if phase=='first_open':tokens.unlink()
    monkeypatch.setattr(v.validation_gate,'verify',lambda *a:req)
    monkeypatch.setattr(v.calibration_gate,'verify',lambda *a:dict(verified=True))
    monkeypatch.setattr(v.candidate_gate,'verify',lambda *a:dict(passed=True))
    monkeypatch.setattr(v.published_gate,'verify_metadata',lambda *a:None)
    monkeypatch.setattr(v,'VALIDATION_INPUTS',tokens)
    output=tmp_path/'attempt'
    with pytest.raises((ValueError,OSError)):
        v.collect(SimpleNamespace(output=output,calibration_report=tmp_path/'unused',calibration_source_archive=tmp_path/'unused2'))
    record=json.loads((output/'report.json').read_bytes())
    assert record['validation_input_read_attempted'] is True
    assert record['validation_data_read'] is (None if phase=='first_open' else True)
    assert record['validation_input_read_status']==('attempted' if phase=='first_open' else 'confirmed')
    assert record['passed'] is False
