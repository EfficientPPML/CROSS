from pathlib import Path
import hashlib,json
import pytest
import published_gate

P=Path(__file__).resolve().parent


def test_fixed_metadata_gate_reads_no_real_input():
    req=json.loads((P/'validation_requirement.json').read_bytes())
    published_gate.verify_metadata(P,req)
    assert req['validation_input_sha256']==published_gate.EXPECTED


def test_wrong_input_pin_rejected_before_any_input_open(tmp_path):
    with pytest.raises(ValueError,match='identity'):
        published_gate.verify_inputs(tmp_path,dict(validation_input_sha256='0'*64),tmp_path/'absent')


@pytest.mark.parametrize('changed',[False,True])
def test_synthetic_hash_and_confirmed_read(tmp_path,monkeypatch,changed):
    path=tmp_path/'synthetic.json';path.write_bytes(b'synthetic only')
    expected=hashlib.sha256(path.read_bytes()).hexdigest()
    monkeypatch.setattr(published_gate,'EXPECTED',expected)
    if changed:path.write_bytes(b'changed synthetic only')
    observed=[]
    if changed:
        with pytest.raises(ValueError,match='bytes'):
            published_gate.verify_inputs(tmp_path,dict(validation_input_sha256=expected),path,on_read=lambda:observed.append(True))
    else:
        assert published_gate.verify_inputs(tmp_path,dict(validation_input_sha256=expected),path,on_read=lambda:observed.append(True))['verified']
    assert observed
