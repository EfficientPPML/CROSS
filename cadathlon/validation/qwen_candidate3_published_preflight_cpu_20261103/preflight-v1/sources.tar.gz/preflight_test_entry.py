"""Tiny/precondition tests with fresh inputs and checkpoint assets unreadable."""
from pathlib import Path
import json
import os
import sys

ROOT = Path(__file__).resolve().parent
forbidden = (
    '/tmp/qwen-fresh56-outerdomain-freeze-20261103/',
    '/tmp/qwen-candidate2-fresh-validation-20261103/validation_inputs/',
    '/tmp/qwen-candidate2-fresh-validation-20261103/run-v1/',
    '/tmp/qwen-candidate2-published-validation-20261103/validation_inputs/',
    '/tmp/qwen-candidate2-published-validation-20261103/run-v1/',
    '/home/jianming_gatech/cross_validation_assets/qwen/',
)
blocked = []


def audit(event, args):
    if event != 'open' or not args or not isinstance(args[0], (str, bytes, os.PathLike)):
        return
    name = os.path.abspath(os.fsdecode(args[0]))
    if any(name.startswith(prefix) for prefix in forbidden):
        blocked.append(name)
        raise AssertionError('preflight cannot read fresh/heldout/checkpoint input bodies')


sys.addaudithook(audit)
import pytest

output = Path(sys.argv[1])
code = pytest.main(['-q', '--tb=short', '--junitxml=' + str(output/'tests.xml'),
    'test_prerequisites.py', 'test_collector.py', 'test_arithmetic.py', 'test_native_capture.py',
    'test_validation_gate.py', 'test_published_gate.py', 'test_validation_lifecycle.py'])
(output/'input_read_guard.json').write_text(json.dumps(dict(
    forbidden_reads_blocked=blocked, fresh_input_bodies_read=False, checkpoint_assets_read=False,
    scope='Python open audit in this preflight child; ordinary-process guard, not an OS sandbox.'))+'\n')
raise SystemExit(code)
