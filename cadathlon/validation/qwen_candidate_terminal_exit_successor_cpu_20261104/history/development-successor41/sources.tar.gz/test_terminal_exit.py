"""Actual isolated CLI with authenticated synthetic helpers, never a backend."""
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

import pytest
from test_checker_entry import prepared

HERE = Path(__file__).resolve().parent
MODES = ('candidate-worker', 'collect-candidate')


def functions(path, names):
    parsed = ast.parse(path.read_bytes())
    selected = [node for node in parsed.body if isinstance(node, ast.FunctionDef) and node.name in names]
    assert {node.name for node in selected} == set(names)
    return ast.unparse(ast.Module(body=selected, type_ignores=[]))


def helper(passed, fault):
    # The production worker and collector use this identical terminal helper.
    core = functions(HERE/'checker_process.py', {'supervise', 'accumulate'})
    cleanup = (HERE/'cleanup_origin.py').read_text()
    return '\n'.join((
        'import json, sys, time\nfrom pathlib import Path\nfrom contextlib import contextmanager',
        cleanup, core,
        '''
@contextmanager
def signals(state=None, shield=False):
    yield
    if state is not None:
        state['restored'] = True

def source_end(root, expected):
    return expected

class BrokenDiagnostic:
    def write(self, value):
        raise OSError('synthetic diagnostic failure')
    def flush(self):
        pass

class Output:
    def __init__(self, path, publication=False):
        self.path = path
        self.owner = (0, 1)
        self.publication = publication
    @classmethod
    def reopen(cls, path, owner):
        return cls(path, True)
    def json(self, name, row):
        (Path(self.path)/name).write_text(json.dumps(row, sort_keys=True))
    def close(self):
        if not self.publication:
            return
        if FAULT == 'OSError':
            raise OSError('synthetic late publication close')
        if FAULT == 'SystemExit0':
            raise SystemExit(0)
        if FAULT == 'SystemExit1':
            raise SystemExit(1)
        if FAULT == 'KeyboardInterrupt':
            raise KeyboardInterrupt()
        if FAULT == 'diagnostic_failure':
            sys.stderr = BrokenDiagnostic()
            raise OSError('synthetic late publication close')

def dispatch(args, raw, expected, blobs, origins):
    Path(args.output).mkdir()
    report = dict(passed=PASSED, complete=True,
        candidate_validation_admissible=PASSED,
        failed_attempt_terminal_candidate=not PASSED,
        source_hashes_start=expected, audit_denials=[])
    return supervise(Output(args.output), report, lambda: None, [], Path(args.output), expected)
''',
        'PASSED = '+repr(passed), 'FAULT = '+repr(fault),
    ))


def install(root, manifest, args, body, mode):
    (root/'checker_process.py').write_text(body)
    rows = {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(root.rglob('*')) if path.is_file()}
    manifest.write_text(json.dumps(rows, sort_keys=True))
    args[args.index('--manifest-sha256')+1] = hashlib.sha256(manifest.read_bytes()).hexdigest()
    args[args.index('--mode')+1] = mode


def launch(args, receipt):
    child = subprocess.Popen([sys.executable, '-I', '-B', *args],
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             start_new_session=True)
    stdout, stderr = child.communicate(timeout=20)
    assert child.returncode is not None
    with pytest.raises(ProcessLookupError):
        os.killpg(child.pid, 0)
    receipt.write_text(json.dumps(dict(pid=child.pid, pgid=child.pid,
        returncode=child.returncode, reaped=True, group_absent=True,
        stdout_bytes=len(stdout), stderr_bytes=len(stderr)), sort_keys=True)+'\n')
    return child.returncode, stdout, stderr


@pytest.mark.parametrize('mode', MODES)
@pytest.mark.parametrize('passed', (True, False))
@pytest.mark.parametrize('fault', (None, 'OSError', 'SystemExit0', 'SystemExit1',
                                 'KeyboardInterrupt', 'diagnostic_failure'))
def test_real_entry_and_exact_terminal_helper(tmp_path, mode, passed, fault):
    root, marker, manifest, args = prepared(tmp_path)
    install(root, manifest, args, helper(passed, fault), mode)
    code, stdout, stderr = launch(args, tmp_path/'child_receipt.json')
    row = json.loads((tmp_path/'out/report.json').read_bytes())
    assert row['passed'] is passed
    assert row['cleanup_completed'] is True and row['signal_restoration_completed'] is True
    assert row['failed_attempt_terminal_candidate'] is (not passed)
    assert code == (70 if fault else 0 if passed else 1)
    if fault == 'diagnostic_failure':
        assert stderr == b''
    elif fault:
        assert b'Candidate infrastructure failure: ' in stderr
        assert b'synthetic late publication close' not in stderr


@pytest.mark.parametrize('mode', MODES)
@pytest.mark.parametrize('returned', ('True', 'None', '0.0', '2', '70', "'1'"))
def test_malformed_normal_return_never_scientific(tmp_path, mode, returned):
    root, marker, manifest, args = prepared(tmp_path)
    install(root, manifest, args, 'def dispatch(*args): return '+returned+'\n', mode)
    code, _, stderr = launch(args, tmp_path/'child_receipt.json')
    assert code == 70 and b'ValueError' in stderr


@pytest.mark.parametrize('option, expected', (('--help', 0), ('--unknown', 2)))
def test_help_and_usage_stay_outside_work(tmp_path, option, expected):
    root, marker, manifest, args = prepared(tmp_path)
    code, _, _ = launch([str(root/'entry.py'), option], tmp_path/'child_receipt.json')
    assert code == expected and not marker.exists()


@pytest.mark.parametrize('mode', MODES)
def test_source_failure_is_infrastructure_before_helper(tmp_path, mode):
    root, marker, manifest, args = prepared(tmp_path)
    args[args.index('--mode')+1] = mode
    (root/'input_gate.py').write_text('raise RuntimeError("untrusted")\n')
    code, _, _ = launch(args, tmp_path/'child_receipt.json')
    assert code == 70 and not marker.exists()


def test_both_production_roles_return_unchanged_supervise():
    body = ast.parse((HERE/'checker_process.py').read_bytes()).body
    for role in ('worker', 'collect'):
        function = next(node for node in body if isinstance(node, ast.FunctionDef) and node.name == role)
        final = function.body[-1]
        assert isinstance(final, ast.Return) and isinstance(final.value, ast.Call)
        assert isinstance(final.value.func, ast.Name) and final.value.func.id == 'supervise'
