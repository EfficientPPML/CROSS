"""Isolated secure centered degree8 power experiment; no runtime promotion."""
import os
os.environ['JAX_PLATFORMS']='cpu'
import sys,time,math,json,hashlib
from pathlib import Path
ROOT=Path('/home/jianming_gatech/CROSS')
sys.path[:0]=[str(ROOT),str(ROOT/'cadathlon/common')]
import jax,numpy as np
from jaxite_word import CKKSContext,key_gen,util,he_params
from jaxite_word.composite_prime_gen import composite_prime_gen
from support import load_module
candidate=load_module(Path(__file__).with_name('polynomial_candidate.py'))
jax.config.update('jax_enable_x64',True)
sources=[Path(__file__),Path(__file__).with_name('polynomial_candidate.py'),*sorted((ROOT/'jaxite_word').glob('*.py')),*sorted((ROOT/'cadathlon/common').glob('encrypted_*.py')),ROOT/'cadathlon/common/support.py']
def hashes():return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
report=dict(scope=__doc__,passed=False,source_hashes_start=hashes(),checks={})
start=time.monotonic();N=16384;depth=5;dnum=6
q=composite_prime_gen(2,2*(depth+1),61,56,2*N,31)
p=util.generate_p_towers(q,dnum,N,aux_bits=30)
assert he_params.qp_is_secure(q,p,N,he_params.SecurityTarget(128,'classical'))
he_params.assert_p_coverage(q,p,dnum)
report['ring']=dict(degree=N,depth=depth,dnum=dnum,q_count=len(q),p_count=len(p),actual_log2_qp=sum(map(math.log2,q+p)),security_bits=128)
keys=key_gen.gen_pke_pair(q,[],N)
ek=key_gen.gen_evaluation_key(keys['secret_key'],q=q,P=p,dnum=dnum)
scale=float(q[-2])*q[-1]
params=dict(degree=N,num_slots=N//2,scaling_factor=scale,output_scale=scale,q_towers=q,p_towers=p,composite_degree=2,degree_layout=(128,128),p=56,CKKS_M_FACTOR=1,max_bits_in_word=61,noise_scale_degree=1)
client=CKKSContext(dict(params,**keys))
ctx=CKKSContext(dict(params,evaluation_key=[jax.numpy.asarray(ek[n],dtype='uint32').transpose(0,2,1) for n in ('a','b')]))
ctx.program_initialization([],dnum=dnum,r=128,c=128,batch=1)
client._polynomial_ntt_ctx=ctx._param_cache.ntt_q_max
assert ctx.secret_key is None and ctx._param_cache.secret_key is None and ctx.parameters.get('secret_key') is None
def forbidden(*a,**kw):raise AssertionError('no server encryption/decryption')
ctx.encrypt=ctx.decrypt=ctx.encrypt_slots=ctx.decrypt_slots=forbidden
ops=candidate.EncryptedPolynomialEvaluator(ctx,strategy='power',low_memory=True,compiled_multiply=True,compiled_linear=True)
for name,limit in [('gelu',3.),('tanh',2.)]:
    normal=candidate.nonlinear_approximation(name,(-limit,limit),8)
    direct=candidate.PolynomialApproximation(name,normal.domain,normal.coefficients,input_power_basis=True)
    values=np.resize(np.linspace(-limit,limit,257),N//2)
    encrypted=client.encrypt_slots(values)
    expected=normal.evaluate_public(values)
    results={}
    for label,approximation in [('normalized',normal),('direct',direct)]:
        begin=time.monotonic()
        actual=ops.evaluate(encrypted,approximation)
        actual.polynomial.block_until_ready()
        decoded=client.decrypt_slots(actual)
        error=float(np.max(np.abs(decoded-expected)))
        level=ops._level(actual)
        assert level==depth-ops.polynomial_depth(approximation)
        assert actual._ckks_nsd==1 and math.isclose(actual._ckks_scale,scale,rel_tol=1e-12)
        assert error<1e-6,(name,label,error)
        results[label]=dict(max_abs_error=error,output_level=level,wall_s=time.monotonic()-begin)
        ops.checkpoint(actual,name+label)
        print(name,label,results[label],flush=True)
        del actual,decoded
    assert results['direct']['output_level']==results['normalized']['output_level']+1
    report['checks'][name]=dict(domain=normal.domain,degree=8,maximum_raw_power=limit**8,coefficients=normal.coefficients,results=results)
report.update(source_hashes_end=hashes(),elapsed_s=time.monotonic()-start)
report['source_files_unchanged']=report['source_hashes_start']==report['source_hashes_end']
report['passed']=report['source_files_unchanged'] and len(report['checks'])==2
Path('/tmp/centered_power_probe/report.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS',report['passed'],'elapsed',report['elapsed_s'],flush=True)
assert report['passed']
