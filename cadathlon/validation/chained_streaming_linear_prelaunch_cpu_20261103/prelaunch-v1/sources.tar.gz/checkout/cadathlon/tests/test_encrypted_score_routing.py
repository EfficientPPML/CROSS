"""Independent ideal route and contract checks; no encrypted numerical claim."""
from pathlib import Path
from types import SimpleNamespace
import os
import subprocess
import sys
import numpy as np
import pytest

COMMON = Path(__file__).resolve().parents[1]/'common'
sys.path.insert(0, str(COMMON))
from encrypted_score_routing import FactoredScoreLayout, FactoredScoreRouting, SLOTS


class Value:
    def __init__(self, values, level):
        self.values, self.level = values, level
        self._ckks_scale, self._ckks_nsd = 1., 1


class Arithmetic:
    scale = 1.
    def __init__(self):
        self.ctx = SimpleNamespace(degree=131072, num_slots=SLOTS, secret_key=None,
            parameters={}, _param_cache=SimpleNamespace(secret_key=None, batch=1))
        self.rotations = []
    def _level(self, value):
        return value.level
    def weighted_sum(self, values, weights):
        return Value(sum(v.values*w for v,w in zip(values, weights)), min(v.level for v in values)-1)
    def rotate(self, value, shift):
        self.rotations.append(shift)
        return Value(np.roll(value.values, -shift), value.level)
    def add(self, left, right):
        assert left.level == right.level
        return Value(left.values+right.values, left.level)


class IdealRouting(FactoredScoreRouting):
    def _validate_ciphertext(self, value):
        self._guard_context()
        if value.values.shape != (SLOTS,) or value.level < 9:
            raise ValueError('invalid ideal input')


@pytest.mark.parametrize('tile', range(8))
@pytest.mark.parametrize('offset', range(16))
def test_fullslot_forward_inverse_against_independent_index_oracle(tile, offset):
    value = (np.arange(SLOTS, dtype=float)-32768)/1024
    ops = Arithmetic(); layout = FactoredScoreLayout(tile, offset)
    router = IdealRouting(ops, layout)
    forward = router.forward(Value(value, 18))
    source = np.array([r*4096+h*64 for r in range(16) for h in range(12)])
    target = np.array([r*4096+(tile*16+(r+offset)%16)*16+h for r in range(16) for h in range(12)])
    expected = np.zeros(SLOTS); expected[target] = value[source]
    np.testing.assert_array_equal(forward.values, expected)
    inverse = router.inverse(forward)
    expected = np.zeros(SLOTS); expected[source] = value[source]
    np.testing.assert_array_equal(inverse.values, expected)
    assert (forward.level, inverse.level) == (9, 0)
    assert dict(router.counts) == dict(public_multiplications=34, actual_composite_rescales=34,
        public_multiplication_levels=18, rotations=16+2*bool(tile), additions=16)
    assert set(ops.rotations) == set(layout.rotation_indices())


def test_gain_folds_into_first_mask_and_progress_observes_nine_levels():
    value = (np.arange(SLOTS, dtype=float)-12345)/32
    phases = []; layout = FactoredScoreLayout(7, 15); ops = Arithmetic()
    router = IdealRouting(ops, layout, progress=lambda label, value, counts: phases.append((label, value.level, counts)))
    result = router.forward(Value(value, 16), gain=1/8)
    expected = np.zeros(SLOTS); expected[layout.target_indices] = value[layout.source_indices]/8
    np.testing.assert_array_equal(result.values, expected)
    assert result.level == 7
    assert [p[1] for p in phases] == [15,14,13,12,11,10,9,8,7,7]
    assert router.counts['public_multiplications'] == 17
    assert set(ops.rotations) == set(layout.rotation_indices(include_inverse=False))
    # Callback records are snapshots rather than aliases of the live counter.
    assert phases[0][2]['public_multiplications'] == 1


@pytest.mark.parametrize('tile,offset', [(True,0),(-1,0),(8,0),(0,False),(0,-1),(0,16),(1.,0)])
def test_invalid_public_layout_rejected(tile, offset):
    with pytest.raises(ValueError): FactoredScoreLayout(tile, offset)


@pytest.mark.parametrize('gain', [True, np.bool_(False), float('nan'), float('inf'), 1j, '1'])
def test_invalid_gain_rejected_before_arithmetic(gain):
    ops = Arithmetic(); router = IdealRouting(ops, FactoredScoreLayout(0,0))
    with pytest.raises(ValueError): router.forward(Value(np.ones(SLOTS),9), gain=gain)
    assert not router.counts and not ops.rotations


@pytest.mark.parametrize('location', ['context','cache','parameters'])
def test_constructor_and_later_calls_reject_retained_secret(location):
    ops = Arithmetic(); router = IdealRouting(ops, FactoredScoreLayout(0,0))
    if location == 'context': ops.ctx.secret_key = object()
    elif location == 'cache': ops.ctx._param_cache.secret_key = object()
    else: ops.ctx.parameters['secret_key'] = object()
    with pytest.raises(ValueError, match='keyless'): IdealRouting(ops, FactoredScoreLayout(0,0))
    with pytest.raises(ValueError, match='keyless'): router.forward(Value(np.ones(SLOTS),9))
    assert not router.counts


@pytest.mark.parametrize('attribute,value', [('degree',65536),('num_slots',32768),('batch',2)])
def test_wrong_physical_layout_or_batch_rejected(attribute, value):
    ops = Arithmetic()
    setattr(ops.ctx._param_cache if attribute == 'batch' else ops.ctx, attribute, value)
    with pytest.raises(ValueError): IdealRouting(ops, FactoredScoreLayout(0,0))


def test_source_target_masks_are_read_only_and_input_is_not_modified():
    layout = FactoredScoreLayout(7,15)
    for mask in (layout.mask(), layout.mask(inverse=True)):
        assert not mask.flags.writeable and np.count_nonzero(mask) == 192
        with pytest.raises(ValueError): mask[0] = 0
    value = np.ones(SLOTS); original = value.copy()
    IdealRouting(Arithmetic(), layout).forward(Value(value,9))
    np.testing.assert_array_equal(value, original)


def test_backend_free_module_import():
    env = dict(os.environ, PYTHONPATH=str(COMMON), JAX_PLATFORMS='routing_must_not_initialize_backend')
    result = subprocess.run([sys.executable,'-c',
        "import sys; import encrypted_score_routing; assert 'jax' not in sys.modules; assert 'jaxite_word' not in sys.modules"],
        env=env, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
