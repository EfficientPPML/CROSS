"""Experimental public routing for full-slot row-packed BERT scores.

This component only masks, rotates and adds ciphertexts. It borrows an initialized
arithmetic owner and never encrypts, decrypts, generates keys, refreshes or closes
the context. The fixed layout is 16 query rows at pitch4096, 128 keys and12heads.
"""
from collections import Counter
from dataclasses import dataclass
import math
import numbers
import numpy as np

SLOTS, FEATURES, ROWS, HEADS, HEAD_WIDTH, KEYS, PAD_HEADS = 65536, 4096, 16, 12, 64, 128, 16
_POSITIONS = np.arange(SLOTS)
_ROWS = _POSITIONS // FEATURES
_POSITIONS.setflags(write=False)
_ROWS.setflags(write=False)


@dataclass(frozen=True)
class FactoredScoreLayout:
    key_tile: int
    offset: int

    def __post_init__(self):
        if (type(self.key_tile) is not int or not 0 <= self.key_tile < 8
                or type(self.offset) is not int or not 0 <= self.offset < 16):
            raise ValueError('public tile/offset outside the fixed128-key score layout')

    @property
    def source_indices(self):
        return (np.arange(ROWS)[:, None]*FEATURES + np.arange(HEADS)*HEAD_WIDTH).ravel()

    @property
    def target_indices(self):
        keys = self.key_tile*ROWS + (np.arange(ROWS)+self.offset) % ROWS
        return (np.arange(ROWS)[:, None]*FEATURES + keys[:, None]*PAD_HEADS + np.arange(HEADS)).ravel()

    def mask(self, *, inverse=False):
        result = np.zeros(SLOTS, dtype=np.float64)
        result[self.target_indices if inverse else self.source_indices] = 1.
        result.setflags(write=False)
        return result

    def rotation_indices(self, *, include_inverse=True):
        forward = [63*(1 << bit) for bit in range(4)]
        forward += [-16*(1 << bit) for bit in range(4)]
        forward += [-256*self.key_tile]
        if include_inverse:
            forward += [-value for value in forward]
        return tuple(sorted({value % SLOTS for value in forward if value % SLOTS}))


class FactoredScoreRouting:
    """Nine-level forward or inverse route with explicit public masks.

`forward(..., gain=1/8)` folds a public score scale into its first mask. The
gain-one route preserves the separately validated standalone routing circuit;
the fused gain needs its own encrypted component proof. There is no attention
validity mask here: raw scores for padded keys remain meaningful outputs.
"""
    def __init__(self, arithmetic, layout, *, progress=None):
        if not isinstance(layout, FactoredScoreLayout):
            raise TypeError('expected FactoredScoreLayout')
        if progress is not None and not callable(progress):
            raise TypeError('progress must be callable or None')
        self.arithmetic, self.layout, self.progress = arithmetic, layout, progress
        self.counts = Counter()
        self._guard_context()

    def _guard_context(self):
        context = self.arithmetic.ctx
        if context.degree != 2*SLOTS or context.num_slots != SLOTS:
            raise ValueError('score routing requires the full65536-slot ring')
        cache = context._param_cache
        if (context.secret_key is not None or cache.secret_key is not None
                or context.parameters.get('secret_key') is not None):
            raise ValueError('score routing requires a keyless context')
        if cache.batch != 1:
            raise ValueError('score routing requires batchone')

    def _validate_ciphertext(self, value):
        self._guard_context()
        from jaxite_word import Polynomial
        from support import require_secure_execution
        if not isinstance(value, Polynomial):
            raise TypeError('score routing requires a canonical ciphertext')
        if value.batch != 1 or value.num_elements != 2 or value.degree != 2*SLOTS:
            raise ValueError('score routing requires a full-slot two-component ciphertext')
        require_secure_execution(self.arithmetic.ctx, value)
        if self.arithmetic._level(value) < 9:
            raise ValueError('score routing requires nine remaining levels')

    def _mask(self, value, weight):
        result = self.arithmetic.weighted_sum([value], [weight])
        self.counts['public_multiplications'] += 1
        self.counts['actual_composite_rescales'] += 1
        if self.arithmetic._level(result) != self.arithmetic._level(value)-1:
            raise RuntimeError('routing mask did not consume exactly one level')
        if (result._ckks_nsd != 1 or not math.isclose(result._ckks_scale,
                self.arithmetic.scale, rel_tol=1e-12)):
            raise RuntimeError('routing mask returned noncanonical scale/NSD')
        return result

    def _rotate(self, value, shift):
        shift = int(shift) % SLOTS
        if not shift:
            return value
        result = self.arithmetic.rotate(value, shift)
        self.counts['rotations'] += 1
        return result

    def _note(self, label, value):
        if self.progress is not None:
            self.progress(label, value, dict(self.counts))

    def _route(self, value, selector, shift, label):
        left = self._mask(value, ~selector)
        right = self._rotate(self._mask(value, selector), shift)
        result = self.arithmetic.add(left, right)
        self.counts['additions'] += 1
        self.counts['public_multiplication_levels'] += 1
        self._note(label, result)
        return result

    def forward(self, value, *, gain=1.):
        if (isinstance(gain, (bool, np.bool_)) or not isinstance(gain, numbers.Real)
                or not math.isfinite(float(gain))):
            raise ValueError('routing gain must be a finite public real scalar')
        self._validate_ciphertext(value)
        result = self._mask(value, self.layout.mask()*float(gain))
        self.counts['public_multiplication_levels'] += 1
        self._note('forward source mask', result)
        for bit in range(4):
            result = self._route(result, (_POSITIONS & (1 << (6+bit))) != 0,
                                 63*(1 << bit), f'forward head bit {bit}')
        for bit in range(4):
            result = self._route(result, (((_ROWS+self.layout.offset) % 16) & (1 << bit)) != 0,
                                 -16*(1 << bit), f'forward key bit {bit}')
        result = self._rotate(result, -256*self.layout.key_tile)
        self._note('forward tile shift', result)
        return result

    def inverse(self, value):
        self._validate_ciphertext(value)
        result = self._mask(value, self.layout.mask(inverse=True))
        self.counts['public_multiplication_levels'] += 1
        result = self._rotate(result, 256*self.layout.key_tile)
        self._note('inverse target mask and tile shift', result)
        for bit in reversed(range(4)):
            result = self._route(result, (((_ROWS+self.layout.offset) % 16) & (1 << bit)) != 0,
                                 16*(1 << bit), f'inverse key bit {bit}')
        for bit in reversed(range(4)):
            result = self._route(result, (_POSITIONS & (1 << bit)) != 0,
                                 -63*(1 << bit), f'inverse head bit {bit}')
        return result
