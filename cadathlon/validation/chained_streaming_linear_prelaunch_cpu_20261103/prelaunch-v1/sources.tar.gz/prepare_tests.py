from pathlib import Path
lab=Path(__file__).resolve().parent
original=Path('/tmp/bert-streaming-linear-candidate-20261103/test_streaming_linear_ideal.py').read_text()
s=original.replace('class IdealLinear(StreamingLinear):\n    def __init__(self,layout):\n        self.layout=layout;self.arithmetic=Arithmetic(layout.slots);self.ctx=self.arithmetic.ctx', '''DEFAULT_STRATEGY='direct'

@pytest.fixture(params=['direct','chained'],autouse=True)
def strategy(request,monkeypatch):
    monkeypatch.setattr(sys.modules[__name__],'DEFAULT_STRATEGY',request.param)

class PublicInventory(dict):
    def get(self,key,default=None):return {'a':object(),'b':object()}

class PublicMaps(dict):
    def get(self,key,default=None):return object()

class IdealLinear(StreamingLinear):
    def __init__(self,layout):
        self.rotation_strategy=DEFAULT_STRATEGY
        self.layout=layout;self.arithmetic=Arithmetic(layout.slots);self.ctx=self.arithmetic.ctx
        self.ctx.secret_key=None;self.ctx.parameters={}
        self.ctx._param_cache=SimpleNamespace(secret_key=None,per_level_rotation_keys=False,
            raw_rotation_keys=PublicInventory(),coef_maps=PublicMaps())''')
s=s.replace('worker.required_rotation_indices(weight,layout)', 'worker.required_rotation_indices(weight,layout,rotation_strategy=worker.rotation_strategy)')
(lab/'test_streaming_ideal.py').write_text(s)
