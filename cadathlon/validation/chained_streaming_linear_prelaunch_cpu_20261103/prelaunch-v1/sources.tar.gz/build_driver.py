from pathlib import Path
here=Path(__file__).resolve().parent
s=Path('/tmp/bert-score-reduction-component-20261103/check_component.py').read_text()
s=s.replace('Isolated secure masked row-score reductions; no attention, refresh or model claim.','Isolated secure chained full-width linear components; no full block, refresh or model claim.')
s=s.replace('from encrypted_score_reduction import ScoreReductionLayout, ScoreReduction, validate_public_dummy, SLOTS\nfrom fixtures import public_fixtures, make_client_values, make_client_scores, client_oracles, mean_variation', '''from encrypted_streaming_linear import StreamingLinear,RowTileLayout
from encrypted_packed_qwen import MatrixDiagonals
from encrypted_packed_transformer import linear_rotation_plan
from pinned_assets import load_matrices,make_fixtures
SLOTS=8192''')
s=s.replace("paths = set(HERE.glob('*.py')) | {HERE/'source_origin.json', HERE/'baseline_manifest.json'}", "paths = set(HERE.glob('*.py')) | {HERE/'source_origin.json'}\n    paths.update((HERE/'base').rglob('*.py'))\n    paths.update((ROOT/'cadathlon/tests').glob('*.py'))\n    for problem in ('p2_bert','p4_qwen'):\n        paths.update((ROOT/'cadathlon/agent_pset'/problem/'test').glob('*.in'))\n        paths.update((ROOT/'cadathlon/agent_pset'/problem/'test').glob('*.out'))")
a=s.index('def parameters():');b=s.index('\ndef main():',a)
s=s[:a]+'''def parameters(matrices):
    degree, depth, dnum = 16384, 1, 2
    q=composite_prime_gen(2,2*(depth+1),61,56,2*degree,31)
    p=util.generate_p_towers(q,dnum,degree,aux_bits=30)
    if not he_params.qp_is_secure(q,p,degree,he_params.SecurityTarget(128,'classical')):
        raise ValueError('insecure actual Q/P ring')
    he_params.assert_p_coverage(q,p,dnum)
    alpha=math.ceil(len(q)/dnum);parts=math.ceil(len(q)/alpha)
    shape=(parts,len(q)+len(p),degree)
    plans={}
    for name,(weight,bias) in matrices.items():
        source=MatrixDiagonals(weight,SLOTS,4096)
        direct=linear_rotation_plan(source);chain=linear_rotation_plan(source,strategy='chained')
        plans[name]=dict(weight_shape=list(weight.shape),active_diagonals=len(source.active),
            n1=source.n1,giant_groups=len(chain.giant_indices),required_rotation_indices=chain.required_keys,
            nonzero_rotation_calls=chain.nonzero_rotation_calls,direct_required_rotation_indices=direct.required_keys,
            critical_levels=1,input_level=1,output_level=0)
    rotations=sorted(set().union(*(item['required_rotation_indices'] for item in plans.values())))
    pair_bytes=2*math.prod(shape)*4
    owned=(len(rotations)+1)*pair_bytes+2*len(q)*degree*4
    return dict(degree=degree,depth=depth,dnum=dnum,q_towers=q,p_towers=p,
        degree_layout=[128,128],slots=SLOTS,actual_log2_qp=sum(map(math.log2,q+p)),
        security_bits=128,scale=float(q[-2])*q[-1],rotation_indices=rotations,
        actual_switch_partitions=parts,key_pair_shape=shape,raw_key_pair_bytes=pair_bytes,
        raw_all_owned_public_key_bytes=owned,key_storage_parent='/tmp',
        current_key_storage_free_bytes=shutil.disk_usage('/tmp').free,
        additional_storage_margin_bytes=4*1024**3,matrix_plans=plans,
        static_capacity=True,rotation_strategy='chained',implicit_refresh=False,
        scoped_ntt_subsets=True,preserve_dispatch_cache=True)


def observe_arithmetic(ops,counts):
    # Count only public scheduling events. No activation is inspected here.
    original_rotate,original_weighted,original_add=ops.rotate,ops.weighted_sum,ops.add
    def rotate(value,index):
        if index%SLOTS:counts['rotations']+=1
        return original_rotate(value,index)
    def weighted(values,weights,**kwargs):
        values,weights=tuple(values),tuple(weights)
        counts['weighted_sums']+=1;counts['public_multiplications']+=len(values)
        return original_weighted(values,weights,**kwargs)
    def add(*args,**kwargs):
        counts['ciphertext_additions']+=1
        return original_add(*args,**kwargs)
    ops.rotate,ops.weighted_sum,ops.add=rotate,weighted,add
    return original_rotate,original_weighted,original_add

''' +s[b:]
s=s.replace("parser.add_argument('--preflight', action='store_true')", "parser.add_argument('--preflight', action='store_true')\n    parser.add_argument('--weights',type=Path,default=Path('/tmp/bert-layer0-linear-weights.npz'))\n    parser.add_argument('--checkpoint',type=Path,default=Path('/home/jianming_gatech/cross_validation_assets/bert/f150c1d609d1e50dd5e2e5408661cfac8339277c/model.safetensors'))")
s=s.replace("'Two signed-score/probability fixture pairs only; no composed inverse/softmax or model proof.'", "'Three independent pinned linear maps only; no chained BERT block, GELU, attention or model proof.'")
s=s.replace('encrypted=router=None','encrypted=linear=None')
s=s.replace("ring=parameters();report['ring']=ring", "matrices,assets=load_matrices(args.weights,args.checkpoint);report['public_assets']=assets\n        layout=RowTileLayout(SLOTS)\n        fixtures=make_fixtures(matrices,layout)\n        report['fixture_contracts']={name:item['contract'] for name,item in fixtures.items()}\n        ring=parameters(matrices);report['ring']=ring")
s=s.replace("prefix='cross-score-reduction-keys-'", "prefix='cross-chained-linear-keys-'")
a=s.index("            for item in ring['public_fixtures']:");b=s.index("            phase('client fixture/domain checks passed; key generation starting')",a)
s=s[:a]+'''            for name,item in fixtures.items():
                client_vectors[name]=item['input'];client_references[name]=item['expected']
''' +s[b:]
s=s.replace('degree_layout=(256,512)','degree_layout=(128,128)').replace('dnum=dnum,r=256,c=512','dnum=dnum,r=128,c=128')
s=s.replace('ops=CompiledArithmetic(server,low_memory=True,preserve_dispatch_cache=True)', "linear=StreamingLinear(server,layout,low_memory=True,preserve_dispatch_cache=True,rotation_strategy='chained')\n            ops=linear.arithmetic")
a=s.index("            for item in ring['public_fixtures']:");b=s.index('            encrypted=None;values=None',a)
s=s[:a]+'''            for name,item in fixtures.items():
                values=client_vectors[name]
                report['encryption_started']=True
                encrypted=client.encrypt_slots(values);encrypted._ckks_nsd=1
                require_secure_execution(server,encrypted)
                encrypted_inputs[name]=encrypted
                fingerprints[name]=(sha(np.asarray(encrypted.polynomial).tobytes()),encrypted._ckks_scale,encrypted._ckks_nsd,ops._level(encrypted))
                if ops._level(encrypted)!=1 or not math.isclose(encrypted._ckks_scale,scale,rel_tol=1e-12):
                    raise ValueError('fresh input metadata differs from level1 contract')
                report['input_contracts'].append(dict(name=name,**item['contract']))
''' +s[b:]
a=s.index("            phase('all four inputs encrypted");b=s.index("            report['input_payload_and_metadata_unchanged']=",a)
s=s[:a]+'''            phase('all three distinct-row inputs encrypted at level1; all client codecs guarded')
            report['operation_counts']={}
            for name,(weight,bias) in matrices.items():
                counts=dict(rotations=0,weighted_sums=0,public_multiplications=0,ciphertext_additions=0)
                original=observe_arithmetic(ops,counts)
                try:
                    output=linear.linear_tile(encrypted_inputs[name],weight,bias,
                        valid_rows=fixtures[name]['valid_rows'],input_mask=fixtures[name]['input_mask'])
                finally:
                    ops.rotate,ops.weighted_sum,ops.add=original
                output.polynomial.block_until_ready()
                plan=ring['matrix_plans'][name]
                expected_counts=dict(rotations=plan['nonzero_rotation_calls'],weighted_sums=plan['giant_groups'],
                    public_multiplications=plan['active_diagonals'],ciphertext_additions=plan['giant_groups']-1)
                if counts!=expected_counts:raise RuntimeError('actual encrypted operation schedule differs from public plan')
                report['operation_counts'][name]=counts
                retained.append((name,output));phase(name+' chained output complete',output,counts);output=None
            report['server_complete_before_client_validation']=True
            phase('all three encrypted outputs complete; enabling final client validation')
            for module,name,original in codec_patches:setattr(module,name,original)
            codec_patches.clear()
            for name,value in retained:
                expected=client_references[name]
                decoded=np.asarray(client.decrypt_slots(value))
                finite=decoded.shape==(SLOTS,) and np.isfinite(decoded).all()
                error=float(np.max(np.abs(decoded-expected))) if finite else None
                level=ops._level(value)
                metadata=level==0 and type(value._ckks_nsd)is int and value._ckks_nsd==1 and math.isclose(value._ckks_scale,scale,rel_tol=1e-12)
                report['checks'][name]=dict(passed=bool(finite and error<=1e-6 and metadata),
                    max_abs_error=error,finite_and_shape=bool(finite),slots_checked=SLOTS,level=level,
                    scale=value._ckks_scale,nsd=value._ckks_nsd,metadata_ok=metadata,
                    expected_minimum=float(expected.min()),expected_maximum=float(expected.max()),
                    execution_rings=require_secure_execution(server,value),**fixtures[name]['contract'])
''' +s[b:]
s=s.replace("len(report['checks'])==4", "len(report['checks'])==3")
s=s.replace('encrypted=router=ops=server=client=value=mean=denominator=None', 'encrypted=linear=ops=server=client=value=output=None')
(here/'check_component.py').write_text(s)
