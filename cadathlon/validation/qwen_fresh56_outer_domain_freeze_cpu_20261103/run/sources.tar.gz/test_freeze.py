import copy
import pytest
from author_corpus import records
from freeze import validate_records


def fixture():
    data=records();seq={r['text']:list(range(i*100,i*100+40)) for i,r in enumerate(data)}
    return data,seq


def test_all_fixed_buckets():
    data,seq=fixture();r=validate_records(data,seq.__getitem__,set(),set(),set())
    assert len(r)==56 and len({tuple(x['token_ids']) for x in r})==56
    assert [sum(x['kind']=='prefill' and x['sequence_length']==s for x in r) for s in (8,16,32)]==[16]*3
    assert sum(x['kind']=='decode' for x in r)==8


@pytest.mark.parametrize('bad',['oldtext','oldshort','oldfull','duplicate','short','bool_length','wrong_kind','extra','missing'])
def test_fail_closed(bad):
    data,seq=fixture();texts=set();short=set();full=set()
    if bad=='oldtext':texts.add(data[0]['text'])
    elif bad=='oldshort':short.add(tuple(seq[data[0]['text']][:8]))
    elif bad=='oldfull':full.add(tuple(seq[data[0]['text']]))
    elif bad=='duplicate':seq[data[1]['text']]=seq[data[0]['text']]
    elif bad=='short':seq[data[0]['text']]=list(range(8))
    elif bad=='bool_length':data[0]['sequence_length']=True
    elif bad=='wrong_kind':data[0]['kind']='decode'
    elif bad=='extra':data[0]['output']='must-never-read'
    else:data.pop()
    with pytest.raises(ValueError):validate_records(data,seq.__getitem__,texts,short,full)
