"""Freeze independent public text/token inputs only; never load/evaluate a model."""
from pathlib import Path
import argparse,hashlib,importlib.metadata,io,json,os,sys,tarfile,time
HERE=Path(__file__).resolve().parent
SNAPSHOT=Path('/home/jianming_gatech/cross_validation_assets/qwen/c1899de289a04d12100db370d81485cdf75e47ca')


def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def save(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')


def validate_records(proposed,encode,old_texts,old_sequences,old_full_sequences):
    if type(proposed) is not list or len(proposed)!=56:raise ValueError('fresh56 inventory')
    seen_ids=set();seen_texts=set();seen_sequences=set();seen_full=set();out=[]
    for i,item in enumerate(proposed):
        if type(item) is not dict or set(item)!={'id','kind','sequence_length','text'}:raise ValueError('record schema')
        kind='prefill' if i<48 else 'decode';length=(8,16,32)[i//16] if i<48 else 16
        expected_id=f'R3_S{length}_{i%16:02d}' if i<48 else f'R3_D_{i-48:02d}'
        if type(item['sequence_length']) is not int or item['sequence_length']!=length or item['kind']!=kind or item['id']!=expected_id:raise ValueError('bucket/order')
        text=item['text']
        if type(text) is not str or not text.strip() or text in old_texts or text in seen_texts:raise ValueError('text overlap/empty')
        full=tuple(encode(text));ids=full[:length]
        if any(type(x) is not int or x<0 for x in full) or len(full)<32 or len(ids)!=length:raise ValueError('natural token length/type')
        if ids in old_sequences or ids in seen_sequences or full in old_full_sequences or full in seen_full:raise ValueError('token sequence overlap')
        seen_ids.add(item['id']);seen_texts.add(text);seen_sequences.add(ids);seen_full.add(full)
        out.append(dict(item,raw_token_count=len(full),token_ids=list(ids),full_token_ids_sha256=hashlib.sha256(json.dumps(full,separators=(',',':')).encode()).hexdigest()))
    return out


def run(output):
    output.mkdir(parents=True,exist_ok=False);started=time.monotonic();primary=None;paths={};before={};assets={}
    report=dict(passed=False,complete=False,scope=__doc__,model_forward=False,coefficient_selection=False,errors=[],cpu_affinity=sorted(os.sched_getaffinity(0)))
    try:
        save(output/'report.json',report)
        paths={str(p.relative_to(HERE)):p for p in HERE.iterdir() if p.is_file() and p.suffix in ('.py','.json')}
        paths.update({'inputs/'+p.name:p for p in (HERE/'inputs').glob('*.json')})
        before={n:sha(p) for n,p in paths.items()}
        with tarfile.open(output/'sources.tar.gz','w:gz') as t:
            for n,p in paths.items():b=p.read_bytes();i=tarfile.TarInfo(n);i.size=len(b);t.addfile(i,io.BytesIO(b))
        with tarfile.open(output/'sources.tar.gz') as t:
            ms=t.getmembers()
            if len(ms)!=len(before) or len({m.name for m in ms})!=len(before) or any(not m.isfile() for m in ms):raise ValueError('archive inventory')
            if {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in ms}!=before:raise ValueError('archive bytes')
        report.update(source_hashes_before=before,source_archive_sha256=sha(output/'sources.tar.gz'))
        inputs=json.loads((HERE/'input_pins.json').read_text())
        if any(sha(HERE/name)!=expected for name,expected in inputs.items()):raise ValueError('frozen source input changed')
        pins=json.loads((HERE/'model_pins.json').read_text());assets={n:sha(SNAPSHOT/n) for n in pins['asset_sha256']}
        if assets!=pins['asset_sha256']:raise ValueError('pinned7assets changed')
        report['asset_sha256_before']=assets
        from tokenizers import Tokenizer
        tokenizer=Tokenizer.from_file(str(SNAPSHOT/'tokenizer.json'))
        encode=lambda text:tokenizer.encode(text,add_special_tokens=False).ids
        corpus=json.loads((HERE/'inputs/calibration_corpus.json').read_text())
        by_id={r['id']:r['text'] for r in corpus['calibration_prompts']}
        calibration=json.loads((HERE/'inputs/calibration_tokens.json').read_text())
        published=json.loads((HERE/'inputs/published_tokens.json').read_text())
        prior_fresh=json.loads((HERE/'inputs/candidate2_fresh_tokens.json').read_text())
        if len(calibration)!=288 or len(published)!=56 or len(prior_fresh)!=56:raise ValueError('old inventory')
        old_texts=set(by_id.values())|{r['text'] for r in published+prior_fresh}
        old_sequences=set()
        for records in (calibration,published,prior_fresh):
            for row in records:
                text=by_id[row['id']] if records is calibration else row['text']
                if encode(text)[:row['sequence_length']]!=row['token_ids']:raise ValueError('pinned tokenizer differs from original record')
                old_sequences.add(tuple(row['token_ids']))
        old_full={tuple(encode(text)) for text in old_texts}
        proposed=json.loads((HERE/'proposed_inputs.json').read_text())
        fresh=validate_records(proposed,encode,old_texts,old_sequences,old_full)
        save(output/'tokenized_fresh_inputs.json',fresh)
        report.update(complete=True,records=56,prefills=48,decode_sequences=8,contexts_if_eventually_measured=112,
                      distinct_texts=len({r['text'] for r in fresh}),distinct_token_sequences=len({tuple(r['token_ids']) for r in fresh}),
                      old_records_verified=400,old_unique_texts=len(old_texts),old_unique_sequences=len(old_sequences),
                      exact_text_overlap=0,exact_truncated_sequence_overlap=0,exact_full_sequence_overlap=0,
                      minimum_natural_tokens=min(r['raw_token_count'] for r in fresh),maximum_natural_tokens=max(r['raw_token_count'] for r in fresh),
                      tokenized_sha256=sha(output/'tokenized_fresh_inputs.json'),proposed_sha256=sha(HERE/'proposed_inputs.json'),
                      tokenizers_version=importlib.metadata.version('tokenizers'),no_model_backend_imported=not any(n.split('.')[0] in ('torch','transformers','jax','jaxlib','jaxite_word') for n in sys.modules),
                      limitations=['Equality disjointness does not establish semantic independence or a generalization guarantee.',
                      'Only public texts/token IDs were processed; no model outputs, validation extrema, coefficients or private data were read.',
                      'A future candidate must be independently frozen and approved before any model evaluation; original published regression remains required.'])
        report['passed']=report['no_model_backend_imported']
    except BaseException as exc:
        primary=exc;report['passed']=False;report['errors'].append(dict(type=type(exc).__name__,message=str(exc)))
    finally:
        try:
            after={n:sha(p) for n,p in paths.items()};report.update(source_hashes_after=after,source_files_unchanged=bool(before) and before==after)
            report['asset_sha256_after']={n:sha(SNAPSHOT/n) for n in assets};report['assets_unchanged']=bool(assets) and assets==report['asset_sha256_after']
            report['passed']=report['passed'] and report['source_files_unchanged'] and report['assets_unchanged']
        except BaseException as exc:
            report['passed']=False;report['errors'].append(dict(phase='final_provenance',type=type(exc).__name__,message=str(exc)))
            if primary is None:primary=exc
            else:primary.add_note('Final provenance: '+repr(exc))
        report['elapsed_s']=time.monotonic()-started
        try:save(output/'report.json',report)
        except BaseException as exc:
            if primary is None:raise
            primary.add_note('Final publication: '+repr(exc))
    if primary is not None:raise primary
    return 0 if report['passed'] else 1


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
    raise SystemExit(run(p.parse_args().output))
