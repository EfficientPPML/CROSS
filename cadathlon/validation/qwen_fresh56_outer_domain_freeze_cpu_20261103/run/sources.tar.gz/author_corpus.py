"""Authored independent scenario list; no model calls or previous outputs."""
from pathlib import Path
import json
SCENARIOS = [
'A conservator examines blue ceramic fragments recovered from an abandoned hillside kiln. Some pieces carry matching glaze marks, while others were fired at different temperatures.',
'A railway scheduler compares freight arrivals at a mountain junction after a new passing loop opens. The timetable alone does not reveal which delays originate farther upstream.',
'A botanist maps the opening times of night blooming flowers beside a desert wash. Nearby lamps and a recent warm spell might influence different parts of the observations.',
'A bicycle mechanic investigates a clicking sound that appears only during uphill pedaling. Replacing one worn part changes the sound but does not remove it completely.',
'A town archivist compares three handwritten accounts of a winter river crossing. The writers disagree about the date, the weather, and how many passengers reached the opposite bank.',
'A pastry instructor watches two batches of laminated dough rise at different speeds. Ingredient weights match, but the handling time and kitchen temperature were recorded separately.',
'A satellite technician notices that a ground antenna loses signal near the same azimuth each evening. A newly installed structure and seasonal atmospheric effects are both plausible explanations.',
'A museum educator arranges replicas of ancient measuring tools for a classroom demonstration. Students must decide which quantities each instrument could establish without modern reference standards.',
'A harbor pilot studies tidal records before guiding a vessel through a narrow approach. Soundings from the previous month may not capture a recently shifted sandbank.',
'A community gardener compares compost bins built with different ventilation openings. Moisture readings and the mixture of plant material complicate a simple comparison of decomposition rates.',
'A sound designer records footsteps in a stairwell with several microphone positions. The loudest recording is not necessarily the one that best preserves the direction of movement.',
'A field geologist finds parallel scratches on stones near the edge of a retreating glacier. Their orientation could reflect transport history, local slope, or later disturbance.',
'A volunteer translator reviews two descriptions of a village festival written decades apart. A familiar term appears to refer to different activities in the two accounts.',
'A laboratory technician checks a balance using several small reference masses. The readings drift after a ventilation fan starts, even though the calibration record is current.',
'A theater carpenter designs a folding platform for repeated assembly on uneven floors. The strongest material alone may not produce the most reliable hinge arrangement.',
'A river ecologist surveys insect larvae above and below a restored culvert. Different flow conditions make equal numbers of collected samples difficult to interpret directly.',
'A bookbinder tests several ways to repair a cracked cloth spine without hiding the original title. Each adhesive behaves differently when the repaired cover is opened repeatedly.',
'A school cook estimates how quickly a large pot of soup cools in several storage containers. Container depth and the timing of each measurement both affect the comparison.',
'A weather observer compares hailstones collected from two nearby farms after a brief storm. Collection delays and melting could change the apparent size distribution.',
'A lighting engineer adjusts lamps above a textile exhibition to make subtle colors visible. Brightness, viewing angle, and long term fading create competing requirements.',
'A surveyor rechecks a hillside boundary after finding an old marker buried beside a newer fence. The two objects may have been placed for entirely different purposes.',
'A beekeeper observes that one hive returns with pollen earlier in the morning than its neighbors. Shade patterns and the locations of flowering plants offer several testable explanations.',
'A ceramic artist compares bowls that warped during cooling in different kiln positions. Similar clay recipes do not guarantee the same temperature history or support conditions.',
'A park ranger follows animal tracks across a muddy clearing after overnight rain. Overlapping prints can suggest a sequence of visits without establishing exact arrival times.',
'A piano restorer measures the response of keys before changing the action felt. Small differences in friction can interact with the force applied by each player.',
'A coastal engineer examines photographs of a seawall before and after repairs. Wave direction and tide height must be considered before attributing every visible change to construction.',
'A mathematics tutor asks students to estimate the number of tiles in a patterned courtyard. Different counting strategies can agree on a result while relying on different assumptions.',
'A textile researcher compares repaired seams in two historical coats. Wear patterns may reveal how each garment was used, but later alterations can obscure that evidence.',
'A warehouse planner studies how workers collect orders from shelves of different heights. Travel distance, item weight, and the order in which tasks arrive all influence completion time.',
'A forest technician measures the shade beneath trees along a newly widened trail. Measurements taken at different hours cannot be compared without accounting for the position of the sun.',
'A glassblower inspects bubbles trapped inside several experimental vessels. The appearance of a bubble may depend on both the source material and how the molten glass was handled.',
'A radio hobbyist compares reception from two antennas during a windy afternoon. Moving cables and changing interference can imitate an improvement caused by antenna design.',
'A dance teacher films a turning exercise from two sides of a studio. Camera angle can make the same movement appear balanced in one recording and unstable in another.',
'A fisheries officer compares mesh samples taken from an old net and a new replacement. Stretching, repairs, and the conditions of storage affect what a simple measurement means.',
'A clock repairer examines a mechanism that stops after running normally for several hours. The timing of the failure may narrow the search without identifying a single damaged component.',
'A horticulture student studies leaf spots on plants moved between two greenhouses. Watering practices and the previous location of each plant must remain part of the explanation.',
'A map librarian aligns historical street plans with a modern aerial image. Changes in projection and the rebuilding of landmarks can create apparent discrepancies that are not surveying errors.',
'A rowing coach compares stroke timing from crews practicing on different stretches of water. Current, wind, and the placement of the recording equipment complicate the analysis.',
'A machinist checks the dimensions of a metal ring before and after it cools. Temperature changes can affect both the workpiece and the instrument used to measure it.',
'A wildlife illustrator reconstructs the posture of an animal from incomplete photographs. Several anatomically possible drawings may fit the visible details equally well.',
'A ceramics curator compares inscriptions on storage jars found in separate buildings. Similar marks could indicate ownership, contents, workshop practice, or reuse at a later date.',
'A hydrologist measures water levels in wells after a week of irrigation. Differences in depth and surrounding soil can delay the response to the same rainfall event.',
'A sailing instructor explains why two boats take different routes across a sheltered bay. Wind shifts and the characteristics of each boat may justify more than one reasonable choice.',
'A puppeteer tests new joints for a figure intended to move under stage lights. A smooth movement during rehearsal may change when the material becomes warmer.',
'A landscape historian interprets a row of old trees beside a vanished footpath. Their spacing may preserve an earlier boundary, a planting design, or practical access requirements.',
'A robotics student compares wheel encoders while a small vehicle travels over carpet and tile. Agreement between the sensors does not prove that the vehicle moved the expected distance.',
'A cheesemaker records how curds change during two carefully timed production runs. Small differences in acidity and stirring can matter even when the final temperatures match.',
'A printmaker evaluates impressions from a woodblock before and after cleaning its surface. Changes in ink thickness can resemble changes caused by the condition of the carved lines.',
'A tram driver reports a vibration that occurs near several curves on the route. Maintenance records and observations from other vehicles are needed to distinguish track effects from vehicle effects.',
'A mineral collector compares the streaks produced by two visually similar specimens. Surface weathering can make color less useful than several independent physical observations.',
'A freshwater biologist counts floating seeds caught in traps along a stream. Trap position and the timing of high water can affect which plants appear most common upstream.',
'A furniture maker tests the fit of a drawer in a workshop with changing humidity. A temporary adjustment may solve one symptom while creating a different seasonal problem.',
'A documentary editor compares interviews about the construction of a local bridge. Memories can preserve valuable details even when accounts disagree about the order of events.',
'A cartography student designs symbols for a map showing access to public water fountains. Clear labeling must account for seasonal availability and readers unfamiliar with the neighborhood.',
'A percussion teacher compares drum tones recorded with different mallets in a small room. Reflections from nearby walls can alter the apparent difference between instruments.',
'A soil scientist compares cores taken from opposite sides of a restored wetland. Drainage history and recent vegetation can produce layers that require more than one explanation.',
]
TAIL=' Describe a practical investigation using observations that could be recorded and checked independently. Explain which comparisons would be informative, identify at least one remaining uncertainty, and distinguish a plausible explanation from a conclusion established by the evidence.'

def records():
    if len(SCENARIOS)!=56 or len(set(SCENARIOS))!=56:raise ValueError('authored inventory')
    out=[]
    for i,text in enumerate(SCENARIOS):
        kind='prefill' if i<48 else 'decode';length=(8,16,32)[i//16] if i<48 else 16
        label=f'R3_S{length}_{i%16:02d}' if i<48 else f'R3_D_{i-48:02d}'
        out.append(dict(id=label,kind=kind,sequence_length=length,text=text+TAIL))
    return out

if __name__=='__main__':
    p=Path(__file__).resolve().parent/'proposed_inputs.json'
    if p.exists():raise FileExistsError('never overwrite a frozen proposal')
    p.write_text(json.dumps(records(),indent=2)+'\n')
