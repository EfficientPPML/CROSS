"""Construction/contract bindings on public ideal primitives; no HE claim."""
from pathlib import Path
import numpy as np
import pytest
from test_initial_ideal import Arithmetic,Value,ideal_primitives,ScoreReductionLayout,ScoreReduction,SLOTS,initial
HERE=Path(__file__).resolve().parent

def fresh_contract():return initial.InitialSoftmaxContract.from_manifest_bytes((HERE/'candidate_manifest.json').read_bytes())

@pytest.mark.parametrize('field',('arithmetic','layout','contract','reduction'))
@pytest.mark.parametrize('phase',('before','first','final'))
def test_owner_identity_replacement_rejected_without_next_primitive(field,phase):
    ops=Arithmetic();layout=ScoreReductionLayout(np.ones(128,bool));all_ops=[ops];mutations=[]
    def count():return sum(len(o.calls) for o in all_ops)
    def mutate():
        if field=='arithmetic':replacement=Arithmetic();all_ops.append(replacement)
        elif field=='layout':replacement=ScoreReductionLayout(np.ones(128,bool))
        elif field=='contract':replacement=fresh_contract()
        else:replacement=ScoreReduction(ops,layout,progress=callback)
        setattr(owner,field,replacement);mutations.append(count())
    def callback(label,value,counts):
        if not mutations and ((phase=='first') or (phase=='final' and label=='initial softmax probabilities')):mutate()
    owner=initial.BertInitialSoftmax(ops,layout,fresh_contract(),progress=callback)
    if phase=='before':mutate()
    with pytest.raises(ValueError):owner.evaluate_tile(Value(np.zeros(SLOTS)))
    assert len(mutations)==1 and count()==mutations[0]
    assert owner.last_plan is None
    if phase=='before':assert count()==0
    if phase=='first':assert ops.calls==['weighted_sum']

MUTATIONS=(
    ('source_manifest_sha256','0'*64),
    ('centered_domain',(-16,16)),
    ('exponential_domain',[-.5,.5]),
    ('squarings',5.),
    ('squarings',True),
    ('initial_domain',(.5,2)),
    ('initial_seed',np.float64(.8)),
    ('initial_seed',True),
    ('initial_updates',6.),
    ('initial_updates',True),
    ('exponential_coefficients','list_alias'),
    ('exponential_coefficients','changed_coefficient'),
)

@pytest.mark.parametrize('field,replacement',MUTATIONS,ids=lambda v:str(v))
@pytest.mark.parametrize('method',('dict','object_setattr'))
@pytest.mark.parametrize('phase',('before','first','final'))
def test_frozen_contract_all_fields_and_typed_aliases_revalidated(field,replacement,method,phase):
    ops=Arithmetic();contract=fresh_contract();mutations=[]
    def mutate():
        if replacement=='list_alias' if isinstance(replacement,str) else False:value=list(contract.exponential_coefficients)
        elif replacement=='changed_coefficient' if isinstance(replacement,str) else False:
            value=list(contract.exponential_coefficients);value[0]+=.001;value=tuple(value)
        else:value=replacement
        if method=='dict':contract.__dict__[field]=value
        else:object.__setattr__(contract,field,value)
        mutations.append(len(ops.calls))
    def callback(label,value,counts):
        if not mutations and (phase=='first' or (phase=='final' and label=='initial softmax probabilities')):mutate()
    owner=initial.BertInitialSoftmax(ops,ScoreReductionLayout(np.ones(128,bool)),contract,progress=callback)
    if phase=='before':mutate()
    with pytest.raises(ValueError):owner.evaluate_tile(Value(np.zeros(SLOTS)))
    assert len(mutations)==1 and len(ops.calls)==mutations[0]
    assert owner.last_plan is None
    if phase=='before':assert not ops.calls
    if phase=='first':assert ops.calls==['weighted_sum']


def test_unchanged_complete_contract_allows_final_checkpoint():
    ops=Arithmetic();contract=fresh_contract();events=[]
    owner=initial.BertInitialSoftmax(ops,ScoreReductionLayout(np.ones(128,bool)),contract,
        progress=lambda label,*args:events.append(label))
    output=owner.evaluate_tile(Value(np.zeros(SLOTS)))
    assert events[-1]=='initial softmax probabilities' and owner.last_plan is not None
    assert output.level==16 and output._ckks_scale==owner.last_plan['final_scale']
