"""Fixed public independent full-slot probes and private-client NumPy references."""
from pathlib import Path
import hashlib,json,math
import numpy as np
SLOTS,ROWS,PITCH,KEYS,HEADS=65536,16,4096,128,12
CHECKPOINTS=('score_mean','normalized_t','base_exp','mean_exp','inverse','base_times_inverse','probabilities')

def definitions():
    all_keys=np.ones((ROWS,KEYS),dtype=bool)
    partial=np.zeros((ROWS,KEYS),dtype=bool)
    choices=[(127,),tuple(range(15)),(0,15,16,63,64,111,112,127),tuple(range(1,128)),tuple(range(0,128,2)),tuple(range(113,128)),(0,),tuple(range(128)),(0,127)]
    for row,keys in enumerate(choices):partial[row,list(keys)]=True
    return [dict(name='all128_distinct16',valid_rows=16,key_mask=all_keys,amplitude=14.5,seed=2026110301),
            dict(name='partial9_per_row_edge_keys',valid_rows=9,key_mask=partial,amplitude=7.5,seed=2026110302)]

def make_scores(item):
    values=np.random.default_rng(item['seed']).uniform(-15.5,15.5,SLOTS)
    k=np.arange(KEYS)
    for row in range(item['valid_rows']):
        for head in range(HEADS):
            points=row*PITCH+k*16+head
            values[points]=item['amplitude']*np.cos(2*np.pi*k/KEYS+.173*row+.091*head)+row/64.+head/1024.-.2
    assert values.shape==(SLOTS,) and np.isfinite(values).all() and np.max(np.abs(values))<16
    return values

def client_oracles(scores,item,coefficients):
    """Independent selected-row means, Chebval and original six Newton updates."""
    result={name:np.zeros(SLOTS) for name in CHECKPOINTS}
    result['mean_exp'].fill(1.)
    dummy=1.*(-.8*.8)+2*.8
    for _ in range(5):dummy*=2-dummy
    result['inverse'].fill(dummy)
    selected_means=[];centered_min=math.inf;centered_max=-math.inf
    for row in range(item['valid_rows']):
        keys=np.flatnonzero(item['key_mask'][row]);K=len(keys)
        for head in range(HEADS):
            index=row*PITCH+keys*16+head;broadcast=row*PITCH+np.arange(KEYS)*16+head
            mean=np.mean(scores[index]);centered=scores[index]-mean
            if not (np.isfinite(centered).all() and np.max(np.abs(centered))<=16):raise ValueError('fixed probe centered-domain failure')
            t=centered/16.;exp=np.polynomial.chebyshev.chebval(t,coefficients);denominator=exp.mean()
            if not .5<=denominator<=2:raise ValueError('fixed initial-denominator domain failure')
            inv=denominator*(-.8*.8)+2*.8
            for _ in range(5):inv*=2-denominator*inv
            result['score_mean'][broadcast]=mean;result['normalized_t'][index]=t;result['base_exp'][index]=exp
            result['mean_exp'][broadcast]=denominator;result['inverse'][broadcast]=inv
            result['base_times_inverse'][index]=exp*inv;result['probabilities'][index]=exp*inv/K
            selected_means.append(float(mean));centered_min=min(centered_min,float(centered.min()));centered_max=max(centered_max,float(centered.max()))
    # Distinct query/head means reject periodic-replica or repeated-row fixtures.
    if len(set(selected_means))!=item['valid_rows']*HEADS:raise ValueError('fixed probe means are not distinct')
    return result,dict(centered_minimum=centered_min,centered_maximum=centered_max,
        unique_active_query_head_means=len(set(selected_means)),denominator_minimum=float(result['mean_exp'].min()),
        denominator_maximum=float(result['mean_exp'].max()))

def checkpoint_error(decoded,expected):
    """Fixed all-slot gate whose failure record always contains finite JSON values."""
    values=np.asarray(decoded);reference=np.asarray(expected)
    valid=(values.shape==(SLOTS,) and reference.shape==(SLOTS,) and
        values.dtype.kind in 'fiu' and reference.dtype.kind in 'fiu' and
        np.isfinite(values).all() and np.isfinite(reference).all())
    report=dict(passed=False,shape_and_finite=bool(valid),max_abs_error=None,
        error_arithmetic_finite=False,decoded_minimum=None,decoded_maximum=None)
    if not valid:return report
    with np.errstate(over='ignore',invalid='ignore'):
        values=values.astype(np.float64);reference=reference.astype(np.float64)
    if not (np.isfinite(values).all() and np.isfinite(reference).all()):return report
    with np.errstate(over='ignore',invalid='ignore'):
        error=float(np.max(np.abs(values-reference)))
    if math.isfinite(error):report.update(max_abs_error=error,error_arithmetic_finite=True,passed=error<=1e-6)
    report.update(decoded_minimum=float(values.min()),decoded_maximum=float(values.max()))
    return report


def diagnostics(decoded,item,input_mask):
    """Descriptive mass/padding diagnostics, fail closed if a sum overflows."""
    values=np.asarray(decoded);active=np.asarray(input_mask,dtype=bool)
    valid=(values.shape==(SLOTS,) and values.dtype.kind in 'fiu' and np.isfinite(values).all())
    result=dict(shape_and_finite=bool(valid),reduction_arithmetic_finite=False,
        maximum_active_mass_defect=None,minimum_probability=None,maximum_probability=None,
        maximum_padding_magnitude=None,active_head_mass_shape=[item['valid_rows'],HEADS])
    if not valid:return result
    with np.errstate(over='ignore',invalid='ignore'):values=values.astype(np.float64)
    if not np.isfinite(values).all():return result
    padding=values[~active]
    with np.errstate(over='ignore',invalid='ignore'):
        mass=values.reshape(ROWS,PITCH)[:,:KEYS*16].reshape(ROWS,KEYS,16).sum(axis=1)
        live=mass[:item['valid_rows'],:HEADS]
        defect=float(np.max(np.abs(live-1)))
    if math.isfinite(defect):result.update(maximum_active_mass_defect=defect,reduction_arithmetic_finite=True)
    result.update(minimum_probability=float(values[active].min()),maximum_probability=float(values[active].max()),
        maximum_padding_magnitude=float(np.max(np.abs(padding))) if padding.size else 0.)
    return result
