"""Public fixed-profile/fixture preflight; no CKKS context or key generation."""
from pathlib import Path
import hashlib,json,math,shutil,sys
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=HERE/'checkout'
sys.path[:0]=[str(ROOT),str(ROOT/'cadathlon/common')]
from encrypted_bert_initial_softmax import InitialSoftmaxContract,initial_softmax_plan
from encrypted_score_reduction import ScoreReductionLayout
from fixtures import definitions,make_scores,client_oracles
AUDIT_SHA256='2b2457e50da73b9ccf87984c089afcb99586fde863a48e98b89a1b7ccf872a17'
INPUT_LEVEL=38

def preflight(*,actual_security=True):
    raw=(HERE/'actual_profile_audit.json').read_bytes()
    if hashlib.sha256(raw).hexdigest()!=AUDIT_SHA256:raise ValueError('actual public profile audit differs')
    record=next(x for x in json.loads(raw)['profiles'] if x['name']=='depth49_p60_d8')
    q,p=record['q'],record['p'];degree=record['degree'];dnum=record['dnum'];scale=record['canonical_scale']
    if (degree,record['depth'],record['scale_bits'],dnum,len(q),len(p))!=(131072,49,60,8,100,14):raise ValueError('fixed common-ring profile differs')
    if any(type(x)is not int or x<=1 or x%(2*degree)!=1 for x in q+p) or len(set(q+p))!=114:raise ValueError('invalid actual ordered prime inventory')
    if math.prod(q+p).bit_length()>3523:raise ValueError('actual QP security bound exceeded')
    alpha=math.ceil(len(q)/dnum);partitions=math.ceil(len(q)/alpha)
    if any(math.prod(q[i:i+alpha])>math.prod(p) for i in range(0,len(q),alpha)):raise ValueError('actual P coverage failed')
    if actual_security:
        from jaxite_word import he_params
        if not he_params.qp_is_secure(q,p,degree,he_params.SecurityTarget(128,'classical')):raise ValueError('actual qp_is_secure failed before any keygen')
        he_params.assert_p_coverage(q,p,dnum)
    contract=InitialSoftmaxContract.from_manifest_bytes((HERE/'candidate_manifest.json').read_bytes())
    plan=initial_softmax_plan(q[:2*(INPUT_LEVEL+1)],input_level=INPUT_LEVEL,canonical_scale=scale)
    fixtures=[]
    for item in definitions():
        layout=ScoreReductionLayout(item['key_mask'],valid_rows=item['valid_rows']);values=make_scores(item)
        refs,details=client_oracles(values,item,contract.exponential_coefficients)
        fixtures.append(dict(name=item['name'],valid_rows=item['valid_rows'],valid_key_counts=layout.counts.tolist(),
            key_mask_sha256=hashlib.sha256(item['key_mask'].tobytes()).hexdigest(),input_sha256=hashlib.sha256(values.astype('<f8').tobytes()).hexdigest(),
            max_absolute_input=float(np.max(np.abs(values))),reference_sha256={n:hashlib.sha256(v.astype('<f8').tobytes()).hexdigest() for n,v in refs.items()},**details))
    rotations=ScoreReductionLayout.rotation_indices();pair=2*partitions*(len(q)+len(p))*degree*4
    required=(len(rotations)+1)*pair+2*len(q)*degree*4
    return dict(degree=degree,slots=65536,depth=49,scale_bits=60,dnum=dnum,q_towers=q,p_towers=p,
        scale=scale,input_level=INPUT_LEVEL,base_Q_pair_over_canonical_scale=(q[0]*q[1])/scale,actual_log2_QP=sum(map(math.log2,q+p)),actual_QP_bit_length=math.prod(q+p).bit_length(),
        actual_qp_is_secure_checked=actual_security,P_coverage_passed=True,degree_layout=[256,512],
        actual_switch_partitions=partitions,raw_key_pair_bytes=pair,rotation_indices=list(rotations),
        raw_all_owned_public_key_bytes=required,key_storage_parent='/dev/shm',current_key_storage_free_bytes=shutil.disk_usage('/dev/shm').free,
        additional_storage_margin_bytes=4*1024**3,plan=plan,fixtures=fixtures,
        fixed_checkpoint_absolute_gate=1e-6,expected_checkpoint_count=14,
        limitations=['Raw key payload excludes tables, compiled controls, ciphertext checkpoints and host/device temporary buffers; not a peak-memory claim.',
                    'Two synthetic independent full-slot fixtures only; no native model inputs or five later square rounds.',
                    'No refresh is performed. P60 base-Q/canonical-scale ratio is about1.6113; p56 bound16 refresh range/accuracy does not transfer.'])
