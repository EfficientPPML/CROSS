"""Fake-crypto lifecycle/ordering test, distinct from real numerical evidence."""
from types import ModuleType,SimpleNamespace
from pathlib import Path
import sys
import numpy as np
import pytest
import component,public_contract
from fixtures import definitions,client_oracles,CHECKPOINTS
from encrypted_bert_initial_softmax import InitialSoftmaxContract

@pytest.fixture
def fake_crypto(monkeypatch):
    monkeypatch.setenv('JAX_PLATFORMS','cpu')
    ring=public_contract.preflight(actual_security=False);events=[];completed=[];cleanup_error=[None]
    real_contract=InitialSoftmaxContract
    def preflight(**kwargs):events.append('actual security before keygen');return ring
    monkeypatch.setattr(component,'preflight',preflight)
    class Payload:
        def __init__(self,array):self.array=np.asarray(array)
        def __array__(self,dtype=None,copy=None):return np.asarray(self.array,dtype=dtype)
        def block_until_ready(self):events.append('synchronize')
    class CT:
        batch=1;num_elements=2;degree=131072;degree_layout=(256,512)
        def __init__(self,data,level=49,scale=None):
            self.polynomial=Payload(data);self.level=level;self._ckks_scale=ring['scale'] if scale is None else scale
            self._ckks_nsd=1;self.moduli=tuple(ring['q_towers'][:2*(level+1)])
    class Lower:
        def __getitem__(self,pair):return SimpleNamespace(level_reduce=lambda value:CT(np.asarray(value.polynomial),pair[1],value._ckks_scale))
    class Context:
        def __init__(self,params):
            self.parameters=params;self.secret_key=params.get('secret_key');self._param_cache=None;self.he_level_reduce=Lower()
        def program_initialization(self,*args,**kwargs):
            events.append('server initialization')
            for module in (packaged,flat):
                for name in ('gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen'):
                    with pytest.raises(AssertionError):getattr(module,name)()
            self._param_cache=SimpleNamespace(secret_key=None,ntt_q_max=object())
        def encrypt_slots(self,values):events.append('encrypt');return CT(values)
        def decrypt_slots(self,value):
            assert len(completed)==2 and events.count('synchronize')>=14
            events.append('decode');return np.asarray(value.polynomial)
        def encrypt(self,*a):raise AssertionError('unexpected raw encrypt')
        def decrypt(self,*a):raise AssertionError('unexpected raw decrypt')
        def encrypt_slots_batch(self,*a):raise AssertionError('unexpected batch encrypt')
        def decrypt_slots_batch(self,*a):raise AssertionError('unexpected batch decrypt')
        def decode(self,*a):raise AssertionError('unexpected raw decode')
    originals={n:getattr(Context,n) for n in ('encrypt','decrypt','encrypt_slots','decrypt_slots','encrypt_slots_batch','decrypt_slots_batch','decode')}
    def generated(*args,**kwargs):events.append('client keygen');return {'secret_key':object(),'public_key':object()}
    def evaluation(*args,**kwargs):events.append('evaluation keygen');return {'a':np.zeros((1,1,1),np.uint32),'b':np.zeros((1,1,1),np.uint32)}
    packaged=ModuleType('jaxite_word.key_gen');flat=ModuleType('key_gen')
    for module in (packaged,flat):
        module.gen_pke_pair=generated;module.gen_evaluation_key=evaluation;module.gen_rotation_key=generated;module.key_switch_gen=generated
    key_originals={m:{n:getattr(m,n) for n in ('gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen')} for m in (packaged,flat)}
    package=ModuleType('jaxite_word');package.CKKSContext=Context;package.key_gen=packaged
    package.ckks_ctx=SimpleNamespace(evict_context_caches=lambda c:events.append('evict'))
    monkeypatch.setitem(sys.modules,'jaxite_word',package);monkeypatch.setitem(sys.modules,'jaxite_word.key_gen',packaged);monkeypatch.setitem(sys.modules,'key_gen',flat)
    monkeypatch.setitem(sys.modules,'jax',SimpleNamespace(config=SimpleNamespace(update=lambda *a:None),numpy=np,default_backend=lambda:'cpu',devices=lambda:[SimpleNamespace(platform='cpu')],clear_caches=lambda:events.append('jax clear')))
    class Store:
        keys={}
        @classmethod
        def generate(cls,*args,**kwargs):events.append('rotation keygen');return cls()
        def close(self):
            events.append('store close')
            if cleanup_error[0]:raise cleanup_error[0]
    monkeypatch.setitem(sys.modules,'encrypted_refresh',SimpleNamespace(ClientRotationKeyStore=Store))
    provider=SimpleNamespace(stats={},close=lambda:events.append('provider close'))
    monkeypatch.setitem(sys.modules,'encrypted_ntt',SimpleNamespace(enable_scoped_ntt_subsets=lambda c:provider))
    class Ops:
        def __init__(self,ctx,**kwargs):
            self.ctx=ctx;self.rotation=SimpleNamespace(clear=lambda **k:None)
            self._plaintext_multiply=self._rescale=SimpleNamespace(clear=lambda **k:None)
            self._multiplication_compiler=SimpleNamespace(clear_executables=lambda:None)
        def _level(self,value):return value.level
        def _clear_working_caches(self):events.append('phase cache clear')
    monkeypatch.setitem(sys.modules,'encrypted_packed_qwen',SimpleNamespace(CompiledArithmetic=Ops))
    class Graph:
        def __init__(self,ops,layout,contract,progress):self.layout=layout;self.contract=contract;self.progress=progress
        def evaluate_tile(self,value,**kwargs):
            # Confirm every client codec is blocked before simulating computation.
            for name in originals:
                with pytest.raises(AssertionError,match='client codec/runtime key generation'):getattr(Context,name)(None,None)
            item=definitions()[len(completed)];refs,_=client_oracles(np.asarray(value.polynomial),item,self.contract.exponential_coefficients)
            scales=ring['plan']['scales']
            outputs={name:CT(refs[name],ring['plan']['levels'][name],scales[name]) for name in CHECKPOINTS}
            for name,output in outputs.items():self.progress(name,output,{})
            completed.append(item['name']);return outputs['probabilities'],outputs
    monkeypatch.setitem(sys.modules,'encrypted_bert_initial_softmax',SimpleNamespace(BertInitialSoftmax=Graph,InitialSoftmaxContract=real_contract))
    monkeypatch.setitem(sys.modules,'support',SimpleNamespace(require_secure_execution=lambda *a:{'test_double_only':True}))
    def assert_restored():
        for name,original in originals.items():assert getattr(Context,name)is original
        for module,entries in key_originals.items():
            for name,original in entries.items():assert getattr(module,name)is original
    return ring,events,completed,cleanup_error,assert_restored

def test_all_outputs_precede_any_decode_and_keyless_initialization_guards(fake_crypto):
    ring,events,completed,_,restored=fake_crypto;report={'passed':False}
    component.run(report,lambda *a:None)
    assert report['passed'] and len(report['checks'])==14 and report['server_complete_before_any_decode']
    assert report['input_payload_and_metadata_unchanged'] and report['cleanup_completed'] and report['owned_key_directory_removed']
    assert events.index('actual security before keygen')<events.index('client keygen')<events.index('server initialization')<events.index('encrypt')<events.index('decode')
    assert len(completed)==2 and events.count('decode')==14;restored()

@pytest.mark.parametrize('primary_present',(False,True))
def test_cleanup_cancellation_attempts_every_release_and_preserves_primary(fake_crypto,primary_present):
    _,events,_,cleanup_error,restored=fake_crypto;primary=ValueError('computation primary');cleanup=KeyboardInterrupt('cleanup interruption');cleanup_error[0]=cleanup
    report={'passed':False}
    def phase(label,*args):
        if primary_present and label.endswith('score_mean'):raise primary
    with pytest.raises(ValueError if primary_present else KeyboardInterrupt) as caught:component.run(report,phase)
    assert caught.value is (primary if primary_present else cleanup)
    assert report['cleanup_completed'] is False and report['cleanup_errors'] and report['owned_key_directory_removed'] and not report['passed']
    assert 'provider close' in events and 'jax clear' in events and 'store close' in events
    restored()

def test_collector_rejects_forced_canonical_checkpoint_metadata(fake_crypto,monkeypatch):
    ring,_,_,_,restored=fake_crypto
    graph=sys.modules['encrypted_bert_initial_softmax'].BertInitialSoftmax;original=graph.evaluate_tile
    def incorrect_metadata(self,*args,**kwargs):
        output,checkpoints=original(self,*args,**kwargs)
        assert checkpoints['normalized_t']._ckks_scale!=ring['scale']
        checkpoints['normalized_t']._ckks_scale=ring['scale']
        return output,checkpoints
    monkeypatch.setattr(graph,'evaluate_tile',incorrect_metadata)
    report={'passed':False};component.run(report,lambda *args:None)
    assert not report['passed'] and report['cleanup_completed']
    for item in definitions():
        check=report['checks'][item['name']+':normalized_t']
        assert check['max_abs_error']<1e-6 and not check['metadata_ok'] and not check['passed']
    restored()
