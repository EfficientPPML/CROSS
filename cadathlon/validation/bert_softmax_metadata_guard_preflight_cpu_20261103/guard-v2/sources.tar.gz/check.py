"""Freeze and verify the complete copied metadata-correction source closure."""
from pathlib import Path
import sys,json,tarfile,hashlib,subprocess,time,io
HERE=Path(__file__).resolve().parent

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def inventory():
    paths=list((HERE/'checkout').rglob('*.py'))+list(HERE.glob('*.py'))
    paths += [HERE/'candidate_manifest.json',HERE/'actual_profile_audit.json',HERE/'origin.json']
    paths += list((HERE/'before').glob('*.py'))+list((HERE/'binding-before').glob('*.py'))+[HERE/'scale_v1_prerequisite.json']
    return {str(p.relative_to(HERE)):sha(p) for p in sorted(paths)}
def main():
    out=HERE/'source-bound-v2';out.mkdir(exist_ok=False);start=time.monotonic();before=inventory()
    report=dict(passed=False,scope='Source-bound public metadata correction; no HE launch.',source_hashes_before=before)
    with tarfile.open(out/'sources.tar.gz','w:gz') as archive:
        for name in before:
            data=(HERE/name).read_bytes();member=tarfile.TarInfo(name);member.size=len(data);archive.addfile(member,io.BytesIO(data))
    with tarfile.open(out/'sources.tar.gz','r:gz') as archive:
        members=archive.getmembers()
        if len(members)!=len(before) or {m.name for m in members}!=set(before) or any(not m.isfile() for m in members):raise ValueError('source archive membership mismatch')
        restored={m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in members}
    if restored!=before:raise ValueError('archive byte mismatch')
    report['source_archive_sha256']=sha(out/'sources.tar.gz')
    with (out/'tests.log').open('w') as log:
        run=subprocess.run([sys.executable,'-m','pytest','-q','test_initial_ideal.py','test_round_ideal.py','test_scale_schedules.py','test_scale_primitives.py','test_initial_bindings.py'],cwd=HERE,stdout=log,stderr=subprocess.STDOUT)
    with (out/'public.log').open('w') as log:
        public=subprocess.run([sys.executable,'reproduce.py'],cwd=HERE,stdout=log,stderr=subprocess.STDOUT)
    after=inventory();report.update(source_hashes_after=after,source_files_unchanged=before==after,
        tests_exit_code=run.returncode,public_exit_code=public.returncode,elapsed_s=time.monotonic()-start)
    report['passed']=before==after and run.returncode==public.returncode==0
    (out/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:report[k] for k in ('passed','tests_exit_code','public_exit_code','source_files_unchanged','elapsed_s','source_archive_sha256')},indent=2))
    return 0 if report['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
