"""Public binary64 metadata report. No context, key generation, HE or backend."""
from pathlib import Path
import sys,json,math,hashlib
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'checkout/cadathlon/common'))
from encrypted_bert_initial_softmax import initial_softmax_plan
from encrypted_bert_normalization_round import normalization_round_plan,NormalizationRoundContract
from encrypted_scale_planning import weighted_sum_scale,drop_divisor

def report():
    profile=next(x for x in json.loads((HERE/'actual_profile_audit.json').read_text())['profiles'] if x['name']=='depth49_p60_d8')
    q=profile['q'];delta=profile['canonical_scale'];raw=(HERE/'candidate_manifest.json').read_bytes()
    initial=initial_softmax_plan(q[:78],input_level=38,canonical_scale=delta,input_scale=delta)
    rounds=[normalization_round_plan(q[:2*(level+1)],input_level=level,canonical_scale=delta,input_scale=delta,
        contract=NormalizationRoundContract(raw,K)) for level in (25,38,49) for K in range(1,129)]
    return dict(scope='Public scale bookkeeping only. No encoded operations, coefficients, numerical gates or nominal first-affine targets changed. No encrypted numerical claim.',
        canonical_scale=delta,profile_sha256=hashlib.sha256((HERE/'actual_profile_audit.json').read_bytes()).hexdigest(),
        old_failures=dict(initial_final_scale=initial['final_scale'],old_expected_scale=delta,
            round_denominator_scale=rounds[127]['scales']['denominator']),
        actual_profile=profile,initial_plan=initial,all_K_round_plans=rounds,
        round_schedules=len(rounds),max_round_output_relative_scale_error=max(abs(x['output_relative_scale_error']) for x in rounds),
        no_backend_import=not any(n.split('.')[0] in ('jax','jaxlib','jaxite_word') for n in sys.modules),
        limitation='The ideal data calculations and binary64 metadata replay do not measure plaintext encoding, rescale or CKKS noise. Existing live initial-softmax run and old preflight sources stay unchanged.')
if __name__=='__main__':
    result=report();(HERE/'public_scale_report.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:result[k] for k in ('scope','round_schedules','max_round_output_relative_scale_error','old_failures','no_backend_import')},indent=2))
