from pathlib import Path
p=Path(__file__).resolve().parent/'checkout/cadathlon/common/encrypted_bert_initial_softmax.py'
s=p.read_text();point=s.index('\ndef initial_softmax_plan(')
s=s[:point]+'''
CONTRACT_FIELDS=('exponential_coefficients','source_manifest_sha256','centered_domain',
    'exponential_domain','squarings','initial_domain','initial_seed','initial_updates')

def _contract_state(contract):
    return tuple(ScoreReduction._typed(getattr(contract,name,None)) for name in CONTRACT_FIELDS)

def _verified_contract_state(contract):
    """Validate every field and its type against the canonical frozen defaults."""
    if not isinstance(contract,InitialSoftmaxContract):raise TypeError('expected frozen initial-softmax contract')
    expected=InitialSoftmaxContract(contract.exponential_coefficients)
    state=_contract_state(contract)
    if state!=_contract_state(expected):
        raise ValueError('initial-softmax contract fields differ from the exact frozen defaults')
    return state

''' +s[point:]
s=s.replace("        if not isinstance(contract,InitialSoftmaxContract):raise TypeError('expected frozen initial-softmax contract')\n        if not isinstance(layout", "        contract_state=_verified_contract_state(contract)\n        if not isinstance(layout")
s=s.replace("        self.reduction=ScoreReduction(arithmetic,layout,progress=progress)\n        self.last_plan=None", "        self.reduction=ScoreReduction(arithmetic,layout,progress=progress)\n        self._bound_arithmetic=arithmetic;self._bound_layout=layout;self._bound_contract=contract\n        self._bound_reduction=self.reduction;self._bound_contract_state=contract_state\n        self.last_plan=None\n        self._guard_bindings()")
point=s.index('    def evaluate_tile(')
s=s[:point]+'''    def _guard_bindings(self):
        if (self.arithmetic is not self._bound_arithmetic or self.layout is not self._bound_layout
                or self.contract is not self._bound_contract or self.reduction is not self._bound_reduction):
            raise ValueError('construction-bound initial-softmax owner was replaced')
        if _contract_state(self.contract)!=self._bound_contract_state:
            raise ValueError('construction-bound initial-softmax contract changed')
        self.reduction._guard_context()

''' +s[point:]
s=s.replace("    def evaluate_tile(self,value,*,capture_checkpoints=False):\n        if type", "    def evaluate_tile(self,value,*,capture_checkpoints=False):\n        self._guard_bindings()\n        if type")
s=s.replace("        def guard():\n            self.reduction._guard_context()", "        def guard():\n            self._guard_bindings()")
p.write_text(s)
