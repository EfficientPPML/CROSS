"""Independent metadata replay and preservation of original encoded targets."""
from pathlib import Path
import importlib.util,sys,json,math
import numpy as np
import pytest
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE/'checkout/cadathlon/common')]
import encrypted_bert_initial_softmax as initial
import encrypted_bert_normalization_round as normal
from encrypted_scale_planning import positive_scale,weighted_sum_scale
P=next(x for x in json.loads((HERE/'actual_profile_audit.json').read_text())['profiles'] if x['name']=='depth49_p60_d8')
Q=P['q'];DELTA=P['canonical_scale'];RAW=(HERE/'candidate_manifest.json').read_bytes()

def old_module(name):
    spec=importlib.util.spec_from_file_location('old_'+name,HERE/'before'/('encrypted_bert_'+name+'.py'))
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    return module
OLD_INITIAL=old_module('initial_softmax');OLD_NORMAL=old_module('normalization_round')

def independent_weighted(s,level):
    divisor=math.prod(Q[2*level:2*level+2])
    return float(s)*float((DELTA*divisor)/s)/divisor

def independent_static(den,level,target,count):
    d=Q[2*level]*Q[2*level+1];y=den*(target*d/den)/d;level-=1
    values=[(level,y)]
    for _ in range(1,count):
        prod=den*y/(Q[2*level]*Q[2*level+1]);level-=1
        y=y*prod/(Q[2*level]*Q[2*level+1]);level-=1;values.append((level,y))
    return values

def independent_tracked(den,level,target,count):
    d=Q[2*level]*Q[2*level+1];y=den*(target*d/den)/d;level-=1
    e=den*y/(Q[2*level]*Q[2*level+1]);level-=1
    rows=[(level+1,y,level,e)]
    for i in range(2,count+1):
        d=Q[2*level]*Q[2*level+1]
        y=y*e/d
        e=e*e/d if i<count else None
        rows.append((level-1,y,level-1 if e is not None else None,e));level-=1
    return rows

SCALES=(DELTA,math.nextafter(DELTA,0),math.nextafter(DELTA,math.inf),DELTA*(1+2e-13))

@pytest.mark.parametrize('level',(24,25,38,49))
@pytest.mark.parametrize('source',SCALES)
def test_initial_plan_replays_each_weighted_power_and_original_inverse_target(level,source):
    plan=initial.initial_softmax_plan(Q[:2*(level+1)],input_level=level,canonical_scale=DELTA,input_scale=source)
    old=OLD_INITIAL.initial_softmax_plan(Q[:2*(level+1)],input_level=level,canonical_scale=DELTA)
    assert plan['nominal_inverse_target_plan']==old['static_inverse_scale_plan']
    assert plan['static_inverse_scale_plan']['initial_target_scale']==old['static_inverse_scale_plan']['initial_target_scale']
    masked=independent_weighted(source,level);mean=independent_weighted(masked,level-1)
    t=independent_weighted(source,level-2);powers={1:(level-3,t)}
    def power(n):
        if n not in powers:
            ll,ls=power(n//2);rl,rs=power((n+1)//2);L=min(ll,rl)
            powers[n]=(L-1,ls*rs/(Q[2*L]*Q[2*L+1]))
        return powers[n]
    ordered=[power(i) for i in range(1,9)]
    base=independent_weighted(ordered[0][1],min(x[0] for x in ordered))
    den=independent_weighted(independent_weighted(base,level-7),level-8)
    inv=independent_static(den,level-9,old['static_inverse_scale_plan']['initial_target_scale'],6)
    for row,(L,s) in zip(plan['static_inverse_scale_plan']['rows'],inv):assert row['level']==L and row['scale']==s
    L,s=inv[-1];product=base*s/(Q[2*L]*Q[2*L+1]);final=independent_weighted(product,L-1)
    assert plan['scales']==dict(score_mean=mean,normalized_t=t,base_exp=base,mean_exp=den,inverse=s,base_times_inverse=product,probabilities=final)
    assert len(plan['weighted_sum_scale_stages'])==7

@pytest.mark.parametrize('level',(25,38,49))
@pytest.mark.parametrize('source',SCALES)
@pytest.mark.parametrize('K',range(1,129))
def test_all_K_round_actual_metadata_preserves_original_encoding(level,source,K):
    contract=normal.NormalizationRoundContract(RAW,K)
    plan=normal.normalization_round_plan(Q[:2*(level+1)],input_level=level,canonical_scale=DELTA,contract=contract,input_scale=source)
    oldcontract=OLD_NORMAL.NormalizationRoundContract(RAW,K)
    old=OLD_NORMAL.normalization_round_plan(Q[:2*(level+1)],input_level=level,canonical_scale=DELTA,contract=oldcontract)
    assert plan['nominal_inverse_target_plan']==old['tracked_inverse_scale_plan']
    target=old['tracked_inverse_scale_plan']['first_output_scale']
    assert plan['tracked_inverse_scale_plan']['first_output_scale']==target
    masked=independent_weighted(source,level)
    square=masked*masked/(Q[2*(level-1)]*Q[2*(level-1)+1])
    den=independent_weighted(square,level-2)
    expected=independent_tracked(den,level-3,target,contract.updates)
    for row,(L,s,eL,eS) in zip(plan['tracked_inverse_scale_plan']['rows'],expected):
        assert row['level']==L and row['scale']==s
        if eS is not None:assert row['residual_level']==eL and row['residual_scale']==eS
    L,s,_,_=expected[-1];output=square*s/(Q[2*L]*Q[2*L+1])
    assert plan['scales']==dict(masked_input=masked,squared_numerator=square,denominator=den,inverse=s,probabilities=output)

@pytest.mark.parametrize('bad',(True,False,0.,-1.,float('nan'),float('inf'),1j,'1'))
def test_bad_input_scales_rejected_by_both_plans(bad):
    with pytest.raises(ValueError):initial.initial_softmax_plan(Q[:78],input_level=38,canonical_scale=DELTA,input_scale=bad)
    with pytest.raises(ValueError):normal.normalization_round_plan(Q[:52],input_level=25,canonical_scale=DELTA,input_scale=bad,contract=normal.NormalizationRoundContract(RAW,128))
