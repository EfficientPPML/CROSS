"""Construction/contract bindings on public ideal primitives; no HE claim."""
from pathlib import Path
import numpy as np
import pytest
from test_initial_ideal import Arithmetic,Value,ideal_primitives,ScoreReductionLayout,ScoreReduction,SLOTS,initial
HERE=Path(__file__).resolve().parent

def fresh_contract():return initial.InitialSoftmaxContract.from_manifest_bytes((HERE/'candidate_manifest.json').read_bytes())

@pytest.mark.parametrize('field',('arithmetic','contract'))
def test_before_entry_replacement_rejected_before_any_work(field):
    ops=Arithmetic();owner=initial.BertInitialSoftmax(ops,ScoreReductionLayout(np.ones(128,bool)),fresh_contract())
    replacement=Arithmetic() if field=='arithmetic' else fresh_contract()
    setattr(owner,field,replacement)
    with pytest.raises(ValueError):owner.evaluate_tile(Value(np.zeros(SLOTS)))
    assert not ops.calls
    if field=='arithmetic':assert not replacement.calls
