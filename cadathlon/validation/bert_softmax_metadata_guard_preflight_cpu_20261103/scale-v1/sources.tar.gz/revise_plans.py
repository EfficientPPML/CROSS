from pathlib import Path
HERE=Path(__file__).resolve().parent
common=HERE/'checkout/cadathlon/common'
p=common/'encrypted_bert_initial_softmax.py';s=p.read_text()
s=s.replace('from encrypted_integer_affine import backward_scale_plan','from encrypted_integer_affine import backward_scale_plan\nfrom encrypted_scale_planning import positive_scale,drop_divisor,weighted_sum_scale,multiply_scale,static_newton_forward')
a=s.index('def initial_softmax_plan(');b=s.index('\n\nclass BertInitialSoftmax:',a)
s=s[:a]+'''def initial_softmax_plan(q_moduli,*,input_level,canonical_scale,input_scale=None):
    q=tuple(q_moduli)
    if (type(input_level)is not int or input_level<24 or len(q)!=2*(input_level+1)
            or len(set(q))!=len(q) or any(type(x)is not int or x<=1 for x in q)):
        raise ValueError('static full-slot CD2 plan needs22 levels plus two continuation levels')
    canonical_scale=positive_scale(canonical_scale)
    source=canonical_scale if input_scale is None else positive_scale(input_scale)
    weighted=[]
    def ws(name,scales,level):
        row=weighted_sum_scale(scales,canonical_scale,drop_divisor(q,level))
        row.update(name=name,input_level=level,output_level=level-1);weighted.append(row)
        return row['output_scale']
    mean_mask=ws('score_mean_mask',[source],input_level)
    mean=ws('score_mean_anchor',[mean_mask],input_level-1)
    t=ws('normalized_t',[source,mean],input_level-2)
    terms={1:dict(power=1,level=input_level-3,scale=t)}
    def power(n):
        if n not in terms:
            left=power(n//2);right=power((n+1)//2);level=min(left['level'],right['level'])
            terms[n]=dict(power=n,level=level-1,
                scale=multiply_scale(left['scale'],right['scale'],drop_divisor(q,level)))
        return terms[n]
    ordered=[power(i) for i in range(1,9)]
    base=ws('base_exp',[x['scale'] for x in ordered],min(x['level'] for x in ordered))
    exp_mask=ws('mean_exp_mask',[base],input_level-7)
    den_scale=ws('mean_exp_anchor',[exp_mask],input_level-8)
    denominator=input_level-9;inverse=denominator-11
    divisor=drop_divisor(q,inverse)
    # Preserve the historical REAL first-affine encoding target. Correct only
    # its predicted metadata, replayed using the actual denominator scale.
    nominal=backward_scale_plan(q[:2*(denominator+1)],input_scale=canonical_scale,
        first_output_level=denominator-1,updates=6,final_scale=float(divisor))
    scale=static_newton_forward(q,input_scale=den_scale,first_output_level=denominator-1,
        updates=6,first_target_scale=nominal['initial_target_scale'])
    product_scale=multiply_scale(base,scale['rows'][-1]['scale'],divisor)
    final=ws('probabilities',[product_scale],input_level-21)
    scales=dict(score_mean=mean,normalized_t=t,base_exp=base,mean_exp=den_scale,
                inverse=scale['rows'][-1]['scale'],base_times_inverse=product_scale,probabilities=final)
    return dict(input_level=input_level,input_scale=source,canonical_scale=canonical_scale,
        consumed_levels=22,reserved_output_levels=2,
        levels={'score_mean':input_level-2,'normalized_t':input_level-3,'base_exp':input_level-7,
                'mean_exp':denominator,'inverse':inverse,'base_times_inverse':input_level-21,'probabilities':input_level-22},
        scales=scales,weighted_sum_scale_stages=weighted,power_scale_stages=ordered,
        nominal_inverse_target_plan=nominal,static_inverse_scale_plan=scale,actual_product_scale=product_scale,
        final_scale=final,initial_updates=6,first_weight=-.8*.8,first_bias=2*.8,
        encoding_target_policy='Preserve original nominal target; replay actual binary64 metadata without relabeling.',
        future_normalized_squarings=5,implemented_squaring_rounds=0)
''' +s[b:]
s=s.replace('plan=initial_softmax_plan(q,input_level=input_level,canonical_scale=arithmetic.scale)','plan=initial_softmax_plan(q,input_level=input_level,canonical_scale=arithmetic.scale,input_scale=input_scale)')
s=s.replace("if arithmetic._level(result)!=plan['levels'][name] or type(result._ckks_nsd)is not int or result._ckks_nsd!=1:","if (arithmetic._level(result)!=plan['levels'][name] or result._ckks_scale!=plan['scales'][name]\n                    or type(result._ckks_nsd)is not int or result._ckks_nsd!=1):")
s=s.replace("if output._ckks_scale!=arithmetic.scale:raise RuntimeError('initial-softmax output scale differs')","if output._ckks_scale!=plan['final_scale']:raise RuntimeError('initial-softmax output scale differs')")
p.write_text(s)
p=common/'encrypted_bert_normalization_round.py';s=p.read_text()
s=s.replace('from tracked_reciprocal import tracked_scale_plan,tracked_reciprocal_updates','from tracked_reciprocal import tracked_scale_plan,tracked_reciprocal_updates,_forward as tracked_scale_forward\nfrom encrypted_scale_planning import positive_scale,drop_divisor,weighted_sum_scale,multiply_scale')
s=s.replace('def normalization_round_plan(q_moduli,*,input_level,canonical_scale,contract):','def normalization_round_plan(q_moduli,*,input_level,canonical_scale,contract,input_scale=None):')
a=s.index('    masked=input_level-1;');b=s.index("    if not math.isfinite(output_scale)",a)
s=s[:a]+'''    canonical_scale=positive_scale(canonical_scale)
    source=canonical_scale if input_scale is None else positive_scale(input_scale)
    masked=input_level-1;square=input_level-2;denominator=input_level-3
    mask_plan=weighted_sum_scale([source],canonical_scale,drop_divisor(q,input_level))
    mask_plan.update(name='masked_input',input_level=input_level,output_level=masked)
    numerator_scale=multiply_scale(mask_plan['output_scale'],mask_plan['output_scale'],drop_divisor(q,masked))
    denominator_plan=weighted_sum_scale([numerator_scale],canonical_scale,drop_divisor(q,square))
    denominator_plan.update(name='denominator',input_level=square,output_level=denominator)
    inverse=denominator-contract.updates-1
    final_divisor=drop_divisor(q,inverse)
    # Keep the original encoding target selection, including its binary64
    # operation order. The actual replay below changes no encoded operation.
    nominal_numerator=canonical_scale*canonical_scale/drop_divisor(q,masked)
    nominal_target=canonical_scale*final_divisor/nominal_numerator
    nominal=tracked_scale_plan(q[:2*(denominator+1)],input_scale=canonical_scale,
        input_level=denominator,updates=contract.updates,final_scale=nominal_target)
    inverse_plan=tracked_scale_forward(q[:2*(denominator+1)],input_scale=denominator_plan['output_scale'],
        input_level=denominator,updates=contract.updates,first_output_scale=nominal['first_output_scale'])
    output_scale=multiply_scale(numerator_scale,inverse_plan['rows'][-1]['scale'],final_divisor)
''' +s[b:]
s=s.replace('input_level=input_level,consumed_levels=used,reserved_output_levels=2,','input_level=input_level,input_scale=source,canonical_scale=canonical_scale,consumed_levels=used,reserved_output_levels=2,')
s=s.replace('scales=dict(masked_input=canonical_scale,squared_numerator=numerator_scale,denominator=canonical_scale,',"scales=dict(masked_input=mask_plan['output_scale'],squared_numerator=numerator_scale,denominator=denominator_plan['output_scale'],")
s=s.replace('tracked_inverse_scale_plan=inverse_plan,output_relative_scale_error=',"weighted_sum_scale_stages=[mask_plan,denominator_plan],nominal_inverse_target_plan=nominal,\n        encoding_target_policy='Preserve original nominal target; replay actual binary64 metadata without relabeling.',\n        tracked_inverse_scale_plan=inverse_plan,output_relative_scale_error=")
s=s.replace('input_level=arithmetic._level(value),canonical_scale=arithmetic.scale,contract=contract)','input_level=arithmetic._level(value),canonical_scale=arithmetic.scale,contract=contract,input_scale=value._ckks_scale)')
p.write_text(s)
p=HERE/'test_initial_ideal.py';s=p.read_text().replace("assert out._ckks_scale==DELTA and out._ckks_nsd==1","assert out._ckks_scale==owner.last_plan['final_scale'] and out._ckks_nsd==1")
p.write_text(s)
