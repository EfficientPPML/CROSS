"""Freeze complete masked softmax assembly and run ideal arithmetic checks."""
from pathlib import Path
import argparse
import hashlib
import io
import json
import os
import subprocess
import sys
import tarfile
import time

HERE = Path(__file__).resolve().parent


def sha(raw): return hashlib.sha256(raw).hexdigest()


def sources():
    files = set(HERE.glob('*.py')) | set((HERE/'checkout').rglob('*.py'))
    files |= {HERE/name for name in ('candidate_manifest.json', 'actual_profile_audit.json',
                                     'p60_profile_and_refresh.json', 'source_origin.json')}
    return {str(p.relative_to(HERE)): p.read_bytes() for p in sorted(files)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(exist_ok=False)
    start = time.monotonic()
    raw = sources()
    before = {name: sha(data) for name, data in raw.items()}
    with tarfile.open(args.output/'sources.tar.gz', 'w:gz') as archive:
        for name, data in raw.items():
            member = tarfile.TarInfo(name)
            member.size = len(data)
            archive.addfile(member, io.BytesIO(data))
    with (args.output/'tests.log').open('w') as log:
        result = subprocess.run([sys.executable, '-m', 'pytest', '-q',
                                 'test_initial_ideal.py', 'test_softmax_tile.py'],
                                cwd=HERE, env=dict(os.environ, PYTEST_DISABLE_PLUGIN_AUTOLOAD='1'),
                                stdout=log, stderr=subprocess.STDOUT)
    after = {name: sha(data) for name, data in sources().items()}
    with tarfile.open(args.output/'sources.tar.gz') as archive:
        members = archive.getmembers()
        assert len(members) == len({m.name for m in members}) == len(before)
        assert all(m.isfile() for m in members)
        archived = {m.name: sha(archive.extractfile(m).read()) for m in members}
    report = dict(passed=result.returncode == 0 and before == after == archived,
                  scope=__doc__, tests_exit_code=result.returncode,
                  source_hashes_before=before, source_hashes_after=after,
                  source_files_unchanged=before == after, source_archive_verified=before == archived,
                  source_archive_sha256=sha((args.output/'sources.tar.gz').read_bytes()),
                  elapsed_s=time.monotonic()-start, encrypted_execution=False,
                  limitations=['Identity-refresh payload double only; no CKKS error, native model or encrypted refresh proof.',
                               'Fixed layer0 and uniform public valid-key count, with only explicit valid query rows.',
                               'B2 is an engineering margin; no domain/noise certificate is inferred.',
                               'Actual copied initial child has a new callback guard; live initial proofs remain unchanged.'])
    (args.output/'report.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if not isinstance(v,(dict,list))}), flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__': raise SystemExit(main())
