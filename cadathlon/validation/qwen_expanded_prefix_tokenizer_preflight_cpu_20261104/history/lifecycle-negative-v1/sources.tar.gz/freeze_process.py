"""Owned process collection and public preflight for the separate input freeze."""
import hashlib
import importlib
import importlib.metadata
import io
import os
from pathlib import Path
import signal
import subprocess
import sys
import tarfile
import time
import xml.etree.ElementTree as ET
from contextlib import contextmanager
from freeze_io import Output, finish, json_bytes, parse, read
import freeze_logic


def source_end(root, expected):
    names = set()
    for path in root.rglob('*'):
        if path.is_symlink():
            raise ValueError('terminal source symlink')
        if path.is_file():
            names.add(path.relative_to(root).as_posix())
        elif not path.is_dir():
            raise ValueError('terminal nonregular source')
    if names != set(expected):
        raise ValueError('terminal source inventory differs')
    after = {name: hashlib.sha256(read(root/name, limit=4*1024*1024)).hexdigest() for name in expected}
    if after != expected:
        raise ValueError('terminal source hashes differ')
    return after


@contextmanager
def signals():
    old = {}
    def cancelled(number, frame):
        raise KeyboardInterrupt('termination signal')
    primary = None
    try:
        for number in (signal.SIGTERM, signal.SIGINT):
            old[number] = signal.getsignal(number)
            signal.signal(number, cancelled)
        yield
    except BaseException as error:
        primary = error
        raise
    finally:
        pending = primary
        for number, handler in old.items():
            try:
                signal.signal(number, handler)
            except BaseException as error:
                if pending is None:
                    pending = error
                else:
                    pending.add_note('signal restoration failure: '+type(error).__name__)
                    if not isinstance(error, Exception) and isinstance(pending, Exception):
                        pending = error
        if pending is not None and pending is not primary:
            raise pending


def install_audit(blobs, allow_inputs):
    external = parse(blobs['external_inputs.json'])
    input_paths = {os.path.abspath(x['path']) for x in external.values()}
    allowed = input_paths | {freeze_logic.ASSET_ROOT+'/'+name for name in freeze_logic.ASSETS}
    denials = []
    def audit(event, args):
        reason = None
        if event == 'open' and args and isinstance(args[0], (str, bytes, os.PathLike)):
            path = os.path.abspath(os.fsdecode(args[0]))
            if (path in input_paths or path.startswith('/home/jianming_gatech/cross_validation_assets/')
                    or path.endswith(('.safetensors', '.parquet'))):
                if not allow_inputs or path not in allowed:
                    reason = 'external input/model body'
        elif event in ('socket.connect', 'socket.bind'):
            reason = 'network'
        if reason:
            denials.append(reason)
            raise PermissionError('input-freeze audit denied '+reason)
    sys.addaudithook(audit)
    return denials


def grant_check(args, blobs):
    authorization = parse(blobs['execution_authorization.json'])
    if authorization != {'execute': False}:
        raise ValueError('preparation source must remain disabled')
    if not args.grant or not args.grant_sha256:
        raise PermissionError('separate reviewed tokenizer-only launch grant required')
    grant = parse(read(args.grant, args.grant_sha256, limit=1024*1024))
    expected = dict(schema='qwen-expanded-prefix-tokenizer-grant-v1', execute=True,
                    scope='tokenizer-only', source_manifest_sha256=args.manifest_sha256,
                    protocol_sha256=hashlib.sha256(blobs['public/protocol.json']).hexdigest(),
                    private_output=os.path.abspath(args.private_output or ''),
                    model_forward=False, coefficient_selection=False)
    required = set(expected) | {'preflight_report_sha256', 'independent_review_sha256'}
    if type(grant) is not dict or set(grant) != required or any(type(grant[k]) is not type(v) or grant[k] != v for k,v in expected.items()):
        raise ValueError('exact tokenizer-only grant binding differs')
    for name in ('preflight_report_sha256', 'independent_review_sha256'):
        value = grant[name]
        if type(value) is not str or len(value) != 64 or any(x not in '0123456789abcdef' for x in value):
            raise ValueError('review/preflight digest required')
    if not args.private_output or not os.path.isabs(args.private_output):
        raise ValueError('fresh absolute private output required')
    return grant


def worker(args, expected, blobs, origins, root):
    grant = grant_check(args, blobs)  # Before output creation and every external body read.
    denials = install_audit(blobs, True)
    report = dict(passed=False, complete=False, pid=os.getpid(), source_hashes_start=expected,
                  source_manifest_sha256=args.manifest_sha256, bootstrap_origins=origins,
                  private_outputs_retained=True, external_inputs_never_removed=True,
                  model_forward=False, coefficient_selection=False)
    output = Output(args.output)
    private = None
    primary = None
    start = time.monotonic()
    try:
        with signals():
            private = Output(args.private_output)
            from tokenizers import Tokenizer
            report['tokenizers_version'] = importlib.metadata.version('tokenizers')
            report.update(freeze_logic.execute(blobs, read, Tokenizer.from_str, private))
    except BaseException as error:
        primary = error
        report.update(passed=False, error_type=type(error).__name__)
    finally:
        if private is not None:
            try:
                private.close(primary)
            except BaseException as error:
                if primary is not None:
                    error.add_note('earlier worker error: '+type(primary).__name__)
                primary = error
                report.update(passed=False, error_type=type(error).__name__)
        try:
            report['source_hashes_end'] = source_end(root, expected)
            report['source_files_unchanged'] = True
        except BaseException as error:
            report.update(passed=False, source_files_unchanged=False)
            if primary is None:
                primary = error
            else:
                primary.add_note('terminal source verification failure: '+type(error).__name__)
        report.update(elapsed_s=time.monotonic()-start, audit_denials=denials,
                      terminal_after_private_close_and_signal_restoration=True,
                      grant_sha256=args.grant_sha256)
        if denials:
            report['passed'] = False
        try:
            output.json('report.json', report)
        except BaseException as error:
            if primary is None:
                primary = error
            else:
                primary.add_note('final worker publication failure: '+type(error).__name__)
        output.close(primary)
    if primary is not None:
        raise primary
    return 0 if report['passed'] else 1


def test_worker(args, expected, blobs, origins, root):
    denials = install_audit(blobs, False)
    output = Output(args.output)
    primary = None
    report = dict(passed=False, complete=False, pid=os.getpid(), source_hashes_start=expected,
                  source_manifest_sha256=args.manifest_sha256, bootstrap_origins=origins,
                  scope='Source-bound synthetic preflight only; no actual token input or tokenizer access.')
    start = time.monotonic()
    try:
        with signals():
            import pytest
            result = pytest.main(['-q', '-p', 'no:cacheprovider', '--import-mode=importlib',
                                  '--junitxml='+str(Path(args.output)/'tests.xml')]
                                 + [str(root/name) for name in expected if name.startswith('test_') and name.endswith('.py')])
            tree = ET.parse(Path(args.output)/'tests.xml')
            cases = tree.findall('.//testcase')
            report.update(tests=len(cases), failures=len(tree.findall('.//failure')),
                          errors=len(tree.findall('.//error')), skipped=len(tree.findall('.//skipped')),
                          pytest_returncode=int(result))
            installed = []
            for name in ('torch','transformers','jax','jaxlib','jaxite_word','tensorflow'):
                try:
                    importlib.import_module(name)
                except ImportError:
                    installed.append(name)
                else:
                    raise AssertionError('forbidden backend imported')
            report['installed_import_denials'] = installed
            report.update(complete=True, passed=result==0 and len(cases)>0 and not report['skipped'])
    except BaseException as error:
        primary = error
        report.update(passed=False, error_type=type(error).__name__)
    finally:
        try:
            report.update(source_hashes_end=source_end(root, expected), source_files_unchanged=True)
        except BaseException as error:
            report.update(passed=False, source_files_unchanged=False)
            if primary is None:
                primary = error
            else:
                primary.add_note('test terminal source verification failure: '+type(error).__name__)
        report.update(elapsed_s=time.monotonic()-start, audit_denials=denials,
                      terminal_after_signal_restoration=True)
        try:
            output.json('report.json', report)
        except BaseException as error:
            if primary is None:
                primary = error
            else:
                primary.add_note('test terminal publication failure: '+type(error).__name__)
        output.close(primary)
    if primary is not None:
        raise primary
    return 0 if report['passed'] else 1


def group_absent(pid):
    try:
        os.killpg(pid, 0)
    except ProcessLookupError:
        return True
    return False


def retire(child, primary):
    if child is None:
        return
    # Healthy waits have no timeout. Only an exceptional owner exit requests shutdown.
    if child.poll() is None:
        try:
            os.killpg(child.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            child.wait(timeout=30)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            child.wait()
    else:
        child.wait()
    if not group_absent(child.pid):
        raise RuntimeError('owned child group remains')


def collect(args, raw, expected, blobs, origins, root):
    actual = args.mode == 'collect-freeze'
    if actual:
        grant_check(args, blobs)
    output = Output(args.output)
    report = dict(passed=False, complete=False, scope='Tokenizer-only input freeze' if actual else 'Public synthetic input-freeze preflight',
                  source_hashes_start=expected, source_manifest_sha256=args.manifest_sha256,
                  bootstrap_origins=origins, pid=os.getpid(), actual_tokenizer_stage=actual,
                  model_forward=False, coefficient_selection=False)
    child = None
    stdout = stderr = None
    primary = None
    start = time.monotonic()
    try:
        with signals():
            output.write('source_manifest.json', raw)
            buffer = io.BytesIO()
            with tarfile.open(fileobj=buffer, mode='w:gz') as archive:
                for name, data in sorted(blobs.items()):
                    item = tarfile.TarInfo(name)
                    item.size = len(data)
                    item.mode = 0o600
                    archive.addfile(item, io.BytesIO(data))
            report['source_archive'] = output.write('sources.tar.gz', buffer.getvalue())
            execution = Path(args.output)/'execution_source'
            execution.mkdir(mode=0o700)
            directories = {'': None}
            for name, data in sorted(blobs.items()):
                path = execution/name
                if path.parent != execution:
                    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                fd = os.open(path, os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC, 0o600)
                error = None
                try:
                    view = memoryview(data)
                    while view:
                        count = os.write(fd, view)
                        if count <= 0:
                            raise OSError('source copy made no progress')
                        view = view[count:]
                except BaseException as exc:
                    error = exc
                    raise
                finally:
                    finish(error, lambda: os.close(fd))
            source_end(execution, expected)
            command = [sys.executable, '-I', '-B', str(execution/'entry.py'),
                       '--manifest', str(Path(args.output)/'source_manifest.json'),
                       '--manifest-sha256', args.manifest_sha256,
                       '--mode', 'freeze-worker' if actual else 'test-worker',
                       '--output', str(Path(args.output)/'worker')]
            if actual:
                command += ['--private-output', args.private_output, '--grant', args.grant,
                            '--grant-sha256', args.grant_sha256]
            stdout = open(Path(args.output)/'stdout.log', 'xb', buffering=0)
            stderr = open(Path(args.output)/'stderr.log', 'xb', buffering=0)
            child = subprocess.Popen(command, stdout=stdout, stderr=stderr, start_new_session=True,
                                     env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1', TOKENIZERS_PARALLELISM='false'))
            report.update(child_pid=child.pid, child_pgid=child.pid)
            code = child.wait()
            report.update(child_returncode=code, child_reaped=True, child_group_absent=group_absent(child.pid))
            worker_data = read(Path(args.output)/'worker/report.json')
            observed = parse(worker_data)
            report['worker_report_sha256'] = hashlib.sha256(worker_data).hexdigest()
            report['worker'] = observed
            report.update(complete=True, passed=code==0 and observed.get('passed') is True and report['child_group_absent'])
    except BaseException as error:
        primary = error
        report.update(passed=False, error_type=type(error).__name__)
    finally:
        for operation in (lambda: retire(child, primary),
                          lambda: stdout.close() if stdout is not None else None,
                          lambda: stderr.close() if stderr is not None else None):
            try:
                operation()
            except BaseException as error:
                report['passed'] = False
                if primary is None or (not isinstance(error, Exception) and isinstance(primary, Exception)):
                    primary = error
                else:
                    primary.add_note('collector cleanup failure: '+type(error).__name__)
        if child is not None:
            report.update(child_returncode=child.returncode, child_reaped=child.returncode is not None,
                          child_group_absent=group_absent(child.pid))
        try:
            report.update(source_hashes_end=source_end(root, expected), source_files_unchanged=True)
        except BaseException as error:
            report.update(passed=False, source_files_unchanged=False)
            if primary is None:
                primary = error
            else:
                primary.add_note('collector source verification failure: '+type(error).__name__)
        report.update(elapsed_s=time.monotonic()-start, outer_after_cleanup_and_signal_restoration=True)
        try:
            output.json('report.json', report)
        except BaseException as error:
            if primary is None:
                primary = error
            else:
                primary.add_note('collector final publication failure: '+type(error).__name__)
        output.close(primary)
    if primary is not None:
        raise primary
    return 0 if report['passed'] else 1


def dispatch(args, raw, expected, blobs, origins):
    root = Path(__file__).parent
    if args.mode.startswith('collect-'):
        return collect(args, raw, expected, blobs, origins, root)
    if args.mode == 'test-worker':
        return test_worker(args, expected, blobs, origins, root)
    return worker(args, expected, blobs, origins, root)
