"""Actual ownership regressions use only synthetic files and child controls."""
import hashlib
import json
from pathlib import Path
import signal
from types import SimpleNamespace
import pytest
import freeze_process as p
from freeze_io import Output,json_bytes
from test_freeze_logic import workflow


def source(tmp_path):
    root=tmp_path/'source';root.mkdir();(root/'a').write_bytes(b'a')
    return root,{'a':hashlib.sha256(b'a').hexdigest()}


def test_cleanup_hup_int_term_shield_and_outer_restoration(tmp_path):
    root,expected=source(tmp_path);output=Output(tmp_path/'output');report={'passed':True}
    before={n:signal.getsignal(n)for n in p.SIGNALS}
    def cleanup():assert all(signal.getsignal(n)==signal.SIG_IGN for n in p.SIGNALS)
    assert p.supervise(output,report,lambda:None,[cleanup],root,expected)==0
    assert {n:signal.getsignal(n)for n in p.SIGNALS}==before
    saved=json.loads((tmp_path/'output/report.json').read_bytes())
    assert saved['passed']and saved['cleanup_completed']and saved['signal_restoration_completed']
    assert saved['source_hashes_end']==expected and output.fd is None


def test_genuine_body_primary_preserved_through_cleanup_cancel(tmp_path):
    root,expected=source(tmp_path);output=Output(tmp_path/'output');primary=ValueError('body')
    def action():raise primary
    def cleanup():raise KeyboardInterrupt('close')
    with pytest.raises(ValueError)as result:p.supervise(output,{'passed':False},action,[cleanup],root,expected)
    assert result.value is primary and not json.loads((tmp_path/'output/report.json').read_bytes())['passed']


def test_later_cancellation_wins_over_cleanup_only_error(tmp_path):
    root,expected=source(tmp_path);output=Output(tmp_path/'output')
    def cleanup1():raise OSError('close1')
    def cleanup2():raise KeyboardInterrupt('close2')
    with pytest.raises(KeyboardInterrupt):p.supervise(output,{'passed':True},lambda:None,[cleanup1,cleanup2],root,expected)
    assert output.fd is None and not json.loads((tmp_path/'output/report.json').read_bytes())['passed']


def test_directory_body_close_failure_is_published_false(tmp_path,monkeypatch):
    root,expected=source(tmp_path);output=Output(tmp_path/'output');close=output.close
    def failure():close();raise OSError('body directory close')
    monkeypatch.setattr(output,'close',failure)
    with pytest.raises(OSError,match='body directory close'):p.supervise(output,{'passed':True},lambda:None,[],root,expected)
    saved=json.loads((tmp_path/'output/report.json').read_bytes())
    assert saved['passed']is False and saved['cleanup_completed']is False
    assert saved['source_files_unchanged']is True


def test_replaced_report_directory_is_never_written(tmp_path):
    root,expected=source(tmp_path);path=tmp_path/'output';output=Output(path)
    def action():path.rename(tmp_path/'retained');path.mkdir(mode=0o700)
    with pytest.raises(ValueError,match='identity'):p.supervise(output,{'passed':True},action,[],root,expected)
    assert not (path/'report.json').exists() and not (tmp_path/'retained/report.json').exists()


def test_signal_setup_failure_still_closes_owned_resources(tmp_path,monkeypatch):
    root,expected=source(tmp_path);output=Output(tmp_path/'output');original=signal.signal;calls=[];cleaned=[]
    def failing(number,handler):
        calls.append(number)
        if len(calls)==1:raise OSError('install')
        return original(number,handler)
    with monkeypatch.context()as patch:
        patch.setattr(p.signal,'signal',failing)
        with pytest.raises(OSError,match='install'):
            p.supervise(output,{'passed':False},lambda:None,[lambda:cleaned.append(True)],root,expected)
    assert cleaned==[True]and output.fd is None


def test_cleanup_shield_setup_failure_still_closes_resources(tmp_path,monkeypatch):
    root,expected=source(tmp_path);output=Output(tmp_path/'output');original=signal.signal;calls=[];cleaned=[]
    def failing(number,handler):
        calls.append(number)
        if len(calls)==4:raise OSError('shield')
        return original(number,handler)
    with monkeypatch.context()as patch:
        patch.setattr(p.signal,'signal',failing)
        with pytest.raises(OSError,match='shield'):
            p.supervise(output,{'passed':True},lambda:None,[lambda:cleaned.append(True)],root,expected)
    assert cleaned==[True]and output.fd is None


def test_retire_signals_owned_group_after_direct_leader_exits(monkeypatch):
    events=[];alive=[True]
    child=SimpleNamespace(pid=999999,returncode=0,poll=lambda:0,wait=lambda:events.append('wait'))
    def kill(pid,number):
        events.append((pid,number));alive[0]=False
    monkeypatch.setattr(p,'group_absent',lambda pid:not alive[0]);monkeypatch.setattr(p.os,'killpg',kill)
    p.retire(child)
    assert events==[(999999,signal.SIGTERM),'wait']


@pytest.mark.parametrize('location',['source','old_parent','assets','nested_private','private_parent','same','relative'])
def test_output_path_rejection_happens_before_mkdir(tmp_path,location):
    blobs,*_=workflow();root=tmp_path/'source';root.mkdir()
    output=tmp_path/'public';private=tmp_path/'private'
    if location=='source':output=root/'evidence'
    elif location=='old_parent':output=Path('/synthetic/evidence')
    elif location=='assets':output=Path(p.freeze_logic.ASSET_ROOT)/'evidence'
    elif location=='nested_private':private=output/'private'
    elif location=='private_parent':output=private/'public'
    elif location=='same':private=output
    elif location=='relative':output=Path('relative')
    args=SimpleNamespace(output=str(output),private_output=str(private))
    with pytest.raises(ValueError):p.validate_paths(args,blobs,root)
    assert not output.exists()


def test_disjoint_output_paths_allowed_without_accessing_input_bodies(tmp_path):
    blobs,*_=workflow();root=tmp_path/'source';root.mkdir()
    args=SimpleNamespace(output=str(tmp_path/'public'),private_output=str(tmp_path/'private'))
    p.validate_paths(args,blobs,root)
    assert not Path(args.output).exists()and not Path(args.private_output).exists()


def test_grant_required_before_output_or_input_access(tmp_path):
    blobs,*_=workflow();blobs['execution_authorization.json']=b'{"execute":false}'
    args=SimpleNamespace(grant=None,grant_sha256=None)
    with pytest.raises(PermissionError):p.grant_check(args,blobs)
