"""Owned process collection and public preflight for the separate input freeze."""
import hashlib
import importlib
import importlib.metadata
import io
import os
from pathlib import Path
import signal
import subprocess
import sys
import tarfile
import time
import xml.etree.ElementTree as ET
from contextlib import contextmanager
from freeze_io import Output, finish, parse, read
import freeze_logic

SIGNALS = (signal.SIGTERM, signal.SIGINT, signal.SIGHUP)


def accumulate(primary, error, phase, body_primary=None):
    if primary is None:
        return error
    primary.add_note(phase+': '+type(error).__name__)
    if body_primary is None and isinstance(primary, Exception) and not isinstance(error, Exception):
        return error
    return primary


@contextmanager
def signals(state=None, shield=False):
    state = {} if state is None else state
    state['restored'] = False
    old = {}
    primary = None
    def cancelled(number, frame):
        raise KeyboardInterrupt('termination signal')
    try:
        for number in SIGNALS:
            old[number] = signal.getsignal(number)
            signal.signal(number, signal.SIG_IGN if shield else cancelled)
        yield
    except BaseException as error:
        primary = error
        raise
    finally:
        pending = primary
        restored = True
        for number, handler in old.items():
            try:
                signal.signal(number, handler)
            except BaseException as error:
                restored = False
                pending = accumulate(pending, error, 'signal restoration failure', primary)
        state['restored'] = restored
        if pending is not None and pending is not primary:
            raise pending


def source_end(root, expected):
    names = set()
    for path in root.rglob('*'):
        if path.is_symlink():
            raise ValueError('terminal source symlink')
        if path.is_file():
            names.add(path.relative_to(root).as_posix())
        elif not path.is_dir():
            raise ValueError('terminal nonregular source')
    if names != set(expected):
        raise ValueError('terminal source inventory differs')
    after = {name: hashlib.sha256(read(root/name, limit=4*1024*1024)).hexdigest() for name in expected}
    if after != expected:
        raise ValueError('terminal source hashes differ')
    return after


def validate_paths(args, blobs, root):
    external = parse(blobs['external_inputs.json'])
    protected = [root.resolve(), Path(freeze_logic.ASSET_ROOT)]
    protected += [Path(row['path']).parent for row in external.values()]
    values = []
    for name in ('output', 'private_output'):
        value = getattr(args, name, None)
        if value is None:
            continue
        path = Path(value)
        if not path.is_absolute() or path != path.resolve() or '..' in path.parts:
            raise ValueError('canonical absolute output path required')
        if any(path == p or p in path.parents or path in p.parents for p in protected):
            raise ValueError('output overlaps a protected input or source tree')
        values.append(path)
    if len(values) == 2 and (values[0] == values[1] or values[0] in values[1].parents or values[1] in values[0].parents):
        raise ValueError('public and private outputs must be disjoint')


def dependencies(blobs):
    expected = parse(blobs['dependencies.json'])
    actual = dict(python=sys.version, tokenizers=importlib.metadata.version('tokenizers'),
                  pytest=importlib.metadata.version('pytest'))
    if actual != expected:
        raise ValueError('installed dependency versions differ from preparation')
    return actual


def install_audit(blobs, allow_inputs):
    external = parse(blobs['external_inputs.json'])
    input_paths = {os.path.abspath(x['path']) for x in external.values()}
    allowed = input_paths | {freeze_logic.ASSET_ROOT+'/'+name for name in freeze_logic.ASSETS}
    denials = []
    def audit(event, args):
        reason = None
        if event == 'open' and args and isinstance(args[0], (str, bytes, os.PathLike)):
            path = os.path.abspath(os.fsdecode(args[0]))
            if (path in input_paths or path.startswith('/home/jianming_gatech/cross_validation_assets/')
                    or path.endswith(('.safetensors', '.parquet'))):
                flags = args[2] if len(args)>2 and type(args[2])is int else 0
                writing = bool(flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
                if not allow_inputs or path not in allowed or writing:
                    reason = 'external input/model body'
        elif event in ('socket.connect', 'socket.bind'):
            reason = 'network'
        if reason:
            denials.append(reason)
            raise PermissionError('input-freeze audit denied '+reason)
    sys.addaudithook(audit)
    return denials


def grant_check(args, blobs):
    if parse(blobs['execution_authorization.json']) != {'execute': False}:
        raise ValueError('preparation source must remain disabled')
    if not args.grant or not args.grant_sha256:
        raise PermissionError('separate reviewed tokenizer-only launch grant required')
    grant = parse(read(args.grant, args.grant_sha256, limit=1024*1024))
    evidence = os.path.abspath(args.output)
    if args.mode == 'freeze-worker':
        if Path(evidence).name != 'worker':
            raise ValueError('owned collector worker output required')
        evidence = str(Path(evidence).parent)
    expected = dict(schema='qwen-expanded-prefix-tokenizer-grant-v1', execute=True,
                    scope='tokenizer-only', source_manifest_sha256=args.manifest_sha256,
                    protocol_sha256=hashlib.sha256(blobs['public/protocol.json']).hexdigest(),
                    private_output=os.path.abspath(args.private_output or ''), evidence_output=evidence,
                    model_forward=False, coefficient_selection=False)
    required = set(expected) | {'preflight_report_sha256', 'independent_review_sha256'}
    if type(grant) is not dict or set(grant) != required or any(type(grant[k]) is not type(v) or grant[k] != v for k,v in expected.items()):
        raise ValueError('exact tokenizer-only grant binding differs')
    for name in ('preflight_report_sha256', 'independent_review_sha256'):
        value = grant[name]
        if type(value) is not str or len(value) != 64 or any(x not in '0123456789abcdef' for x in value):
            raise ValueError('review/preflight digest required')
    if not args.private_output:
        raise ValueError('fresh absolute private output required')
    return grant


def supervise(output, report, action, cleanup, root, expected):
    """Close body resources and restore signals before final inode-bound publication."""
    start = time.monotonic()
    primary = body_primary = None
    state = {}
    cleanup_complete = True
    cleanup_ran = False
    report['source_files_unchanged'] = False
    def verify_source():
        report['source_hashes_end'] = source_end(root, expected)
        report['source_files_unchanged'] = True
    def cleanup_all():
        nonlocal primary, cleanup_complete, cleanup_ran
        cleanup_ran = True
        shield = signals(shield=True)
        entered = False
        try:
            shield.__enter__()
            entered = True
        except BaseException as error:
            cleanup_complete = False
            primary = accumulate(primary, error, 'cleanup shielding setup failure', body_primary)
        for operation in (*cleanup, verify_source, lambda: output.close()):
            try:
                operation()
            except BaseException as error:
                cleanup_complete = False
                primary = accumulate(primary, error, 'body cleanup failure', body_primary)
        if entered:
            try:
                shield.__exit__(None,None,None)
            except BaseException as error:
                cleanup_complete = False
                primary = accumulate(primary, error, 'cleanup shielding restoration failure', body_primary)
    try:
        with signals(state):
            try:
                action()
            except BaseException as error:
                primary = body_primary = error
                report.update(passed=False, error_type=type(error).__name__)
            finally:
                cleanup_all()
    except BaseException as error:
        report['passed'] = False
        primary = accumulate(primary, error, 'outer signal scope failure', body_primary)
    if not cleanup_ran:
        cleanup_all()
    report.update(elapsed_s=time.monotonic()-start, cleanup_completed=cleanup_complete,
                  signal_restoration_completed=state.get('restored',False),
                  terminal_after_body_cleanup_and_signal_restoration_attempts=True,
                  acceptance_requires_independent_exit0_reap_and_exact_report_hash=True)
    if not cleanup_complete or not state.get('restored',False) or primary is not None:
        report['passed'] = False
    publication = None
    try:
        publication = Output.reopen(output.path, output.owner)
        publication.json('report.json', report)
    except BaseException as error:
        primary = accumulate(primary, error, 'final publication failure', body_primary)
    finally:
        if publication is not None:
            try:
                publication.close()
            except BaseException as error:
                primary = accumulate(primary, error, 'final publication close failure', body_primary)
    if primary is not None:
        raise primary
    return 0 if report['passed'] else 1


def worker(args, expected, blobs, origins, root):
    validate_paths(args, blobs, root)
    grant_check(args, blobs)
    denials = install_audit(blobs, True)
    output = Output(args.output)
    private = [None]
    report = dict(passed=False, complete=False, pid=os.getpid(), source_hashes_start=expected,
                  source_manifest_sha256=args.manifest_sha256, bootstrap_origins=origins,
                  private_outputs_retained=True, external_inputs_never_removed=True,
                  model_forward=False, coefficient_selection=False, grant_sha256=args.grant_sha256,
                  audit_denials=denials)
    def action():
        report['dependencies'] = dependencies(blobs)
        private[0] = Output(args.private_output)
        from tokenizers import Tokenizer
        report.update(freeze_logic.execute(blobs, read, Tokenizer.from_str, private[0]))
        if denials:
            raise ValueError('forbidden input access attempted')
    return supervise(output, report, action, [lambda: private[0].close() if private[0] else None], root, expected)


def test_worker(args, expected, blobs, origins, root):
    validate_paths(args, blobs, root)
    denials = install_audit(blobs, False)
    output = Output(args.output)
    report = dict(passed=False, complete=False, pid=os.getpid(), source_hashes_start=expected,
                  source_manifest_sha256=args.manifest_sha256, bootstrap_origins=origins,
                  scope='Source-bound synthetic preflight only; no actual token input or tokenizer access.',
                  audit_denials=denials)
    def action():
        report['dependencies'] = dependencies(blobs)
        import pytest
        result = pytest.main(['-q', '-p', 'no:cacheprovider', '--import-mode=importlib',
                              '--junitxml='+str(Path(args.output)/'tests.xml')]
                             + [str(root/name) for name in expected if name.startswith('test_') and name.endswith('.py')])
        tree = ET.parse(Path(args.output)/'tests.xml')
        cases = tree.findall('.//testcase')
        report.update(tests=len(cases), failures=len(tree.findall('.//failure')),
                      errors=len(tree.findall('.//error')), skipped=len(tree.findall('.//skipped')),
                      pytest_returncode=int(result))
        installed = []
        for name in ('torch','transformers','jax','jaxlib','jaxite_word','tensorflow'):
            try:
                importlib.import_module(name)
            except ImportError:
                installed.append(name)
            else:
                raise AssertionError('forbidden backend imported')
        report['installed_import_denials'] = installed
        expectations = parse(blobs['preflight_expectations.json'])
        report.update(complete=True, passed=result==0 and len(cases)==expectations['synthetic_tests']
                      and len(installed)==expectations['installed_import_denials'] and not report['skipped'] and not denials)
    return supervise(output, report, action, [], root, expected)


def group_absent(pid):
    try:
        os.killpg(pid, 0)
    except ProcessLookupError:
        return True
    return False


def retire(child, primary=None):
    if child is None:
        return
    # Healthy waits have no timeout. Cleanup begins only after body completion/error.
    child.poll()
    if not group_absent(child.pid):
        try:
            os.killpg(child.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        deadline = time.monotonic()+30
        while not group_absent(child.pid) and time.monotonic()<deadline:
            child.poll()
            time.sleep(.02)
        if not group_absent(child.pid):
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
    child.wait()
    if not group_absent(child.pid):
        raise RuntimeError('owned child group remains')


def collect(args, raw, expected, blobs, origins, root):
    validate_paths(args, blobs, root)
    actual = args.mode == 'collect-freeze'
    if actual:
        grant_check(args, blobs)
    denials = install_audit(blobs, False)
    output = Output(args.output)
    report = dict(passed=False, complete=False, audit_denials=denials, scope='Tokenizer-only input freeze' if actual else 'Public synthetic input-freeze preflight',
                  source_hashes_start=expected, source_manifest_sha256=args.manifest_sha256,
                  bootstrap_origins=origins, pid=os.getpid(), actual_tokenizer_stage=actual,
                  model_forward=False, coefficient_selection=False)
    child = [None]
    logs = []
    def action():
        report['dependencies'] = dependencies(blobs)
        output.write('source_manifest.json', raw)
        buffer = io.BytesIO()
        with tarfile.open(fileobj=buffer, mode='w:gz') as archive:
            for name, data in sorted(blobs.items()):
                item = tarfile.TarInfo(name)
                item.size = len(data)
                item.mode = 0o600
                archive.addfile(item, io.BytesIO(data))
        report['source_archive'] = output.write('sources.tar.gz', buffer.getvalue())
        execution = Path(args.output)/'execution_source'
        execution.mkdir(mode=0o700)
        for name, data in sorted(blobs.items()):
            path = execution/name
            if path.parent != execution:
                path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            fd = os.open(path, os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC, 0o600)
            error = None
            try:
                view = memoryview(data)
                while view:
                    count = os.write(fd, view)
                    if count <= 0:
                        raise OSError('source copy made no progress')
                    view = view[count:]
            except BaseException as exc:
                error = exc
                raise
            finally:
                finish(error, lambda: os.close(fd))
        source_end(execution, expected)
        command = [sys.executable, '-I', '-B', str(execution/'entry.py'),
                   '--manifest', str(Path(args.output)/'source_manifest.json'),
                   '--manifest-sha256', args.manifest_sha256,
                   '--mode', 'freeze-worker' if actual else 'test-worker',
                   '--output', str(Path(args.output)/'worker')]
        if actual:
            command += ['--private-output', args.private_output, '--grant', args.grant,
                        '--grant-sha256', args.grant_sha256]
        for name in ('stdout.log','stderr.log'):
            fd = os.open(Path(args.output)/name, os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
            primary = None
            try:
                logs.append(os.fdopen(fd,'wb',buffering=0))
            except BaseException as error:
                primary = error
                finish(primary, lambda:os.close(fd))
                raise
        child[0] = subprocess.Popen(command, stdout=logs[0], stderr=logs[1], start_new_session=True,
                                    env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1', TOKENIZERS_PARALLELISM='false',
                                             PYTEST_DISABLE_PLUGIN_AUTOLOAD='1'))
        report.update(child_pid=child[0].pid, child_pgid=child[0].pid)
        code = child[0].wait()
        report.update(child_returncode=code, child_reaped=True, child_group_absent=group_absent(child[0].pid))
        worker_data = read(Path(args.output)/'worker/report.json')
        observed = parse(worker_data)
        report['worker_report_sha256'] = hashlib.sha256(worker_data).hexdigest()
        report['worker'] = observed
        report.update(complete=True, passed=code==0 and observed.get('passed') is True
                      and observed.get('cleanup_completed')is True and observed.get('signal_restoration_completed')is True
                      and observed.get('source_hashes_start')==expected and observed.get('source_hashes_end')==expected
                      and report['child_group_absent'] and not denials)
    def child_cleanup():
        retire(child[0])
        if child[0] is not None:
            report.update(child_returncode=child[0].returncode, child_reaped=child[0].returncode is not None,
                          child_group_absent=group_absent(child[0].pid))
    def log_cleanup():
        primary = None
        for stream in logs:
            try:
                stream.close()
            except BaseException as error:
                primary = accumulate(primary,error,'log close failure')
        if primary is not None:
            raise primary
    return supervise(output, report, action, [child_cleanup,log_cleanup], root, expected)


def dispatch(args, raw, expected, blobs, origins):
    root = Path(__file__).parent
    if args.mode.startswith('collect-'):
        return collect(args, raw, expected, blobs, origins, root)
    if args.mode == 'test-worker':
        return test_worker(args, expected, blobs, origins, root)
    return worker(args, expected, blobs, origins, root)
