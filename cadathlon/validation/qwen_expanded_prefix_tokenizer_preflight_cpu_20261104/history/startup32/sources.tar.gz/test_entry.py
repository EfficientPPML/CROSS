"""Actual isolated CLI negatives must reject before any modified helper executes."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import pytest
import entry


def snapshot(tmp_path):
    source=Path(__file__).parent
    root=tmp_path/'source';root.mkdir()
    expected={}
    for path in source.rglob('*'):
        if path.is_file():
            name=path.relative_to(source).as_posix();out=root/name;out.parent.mkdir(parents=True,exist_ok=True)
            data=path.read_bytes();out.write_bytes(data);expected[name]=hashlib.sha256(data).hexdigest()
    manifest=tmp_path/'manifest.json';manifest.write_text(json.dumps(expected,sort_keys=True)+'\n')
    digest=hashlib.sha256(manifest.read_bytes()).hexdigest()
    args=['--manifest',str(manifest),'--manifest-sha256',digest,'--mode','freeze-worker',
          '--output',str(tmp_path/'output'),'--private-output',str(tmp_path/'private')]
    return root,manifest,args


def launch(root,args,script=None):
    command=[sys.executable,'-I','-B']
    command += [str(root/'entry.py')]+args if script is None else ['-c',script,str(root/'entry.py')]+args
    return subprocess.run(command,capture_output=True,text=True,check=False)


def test_clean_cli_rejects_missing_grant_before_outputs(tmp_path):
    root,manifest,args=snapshot(tmp_path)
    result=launch(root,args)
    assert result.returncode==1 and 'separate reviewed tokenizer-only launch grant required'in result.stderr
    assert not (tmp_path/'output').exists() and not (tmp_path/'private').exists()


@pytest.mark.parametrize('changed',['freeze_io.py','freeze_process.py','freeze_logic.py','input_plan.py'])
def test_modified_helper_never_executes(tmp_path,changed):
    root,manifest,args=snapshot(tmp_path);marker=tmp_path/'marker'
    path=root/changed;path.write_text('from pathlib import Path\nPath('+repr(str(marker))+').write_text("executed")\n'+path.read_text())
    result=launch(root,args)
    assert result.returncode==1 and 'source closure SHA256 differs'in result.stderr
    assert not marker.exists() and not (tmp_path/'output').exists()


@pytest.mark.parametrize('kind',['extra_python','extra_cache','symlink','fifo','missing','wrong_digest'])
def test_source_inventory_negatives(tmp_path,kind):
    root,manifest,args=snapshot(tmp_path);marker=tmp_path/'marker'
    if kind=='extra_python':(root/'platform.py').write_text('from pathlib import Path\nPath('+repr(str(marker))+').touch()\n')
    elif kind=='extra_cache':(root/'__pycache__').mkdir()
    elif kind=='symlink':(root/'platform.py').symlink_to(root/'input_plan.py')
    elif kind=='fifo':os.mkfifo(root/'unexpected')
    elif kind=='missing':(root/'input_plan.py').unlink()
    elif kind=='wrong_digest':args[3]='0'*64
    result=launch(root,args)
    assert result.returncode==1 and 'launch grant required'not in result.stderr
    assert not marker.exists() and not (tmp_path/'output').exists()


@pytest.mark.parametrize('kind',['file_alias','spec_alias','foreign_helper'])
def test_preloaded_helper_or_unknown_local_alias_rejected(tmp_path,kind):
    root,manifest,args=snapshot(tmp_path)
    origin=str(root/'input_plan.py')
    variable='alias'if kind!='foreign_helper'else'input_plan'
    attribute="m.__file__="+repr(origin)if kind=='file_alias'else"m.__spec__=types.SimpleNamespace(origin="+repr(origin if kind=='spec_alias'else'/outside/input_plan.py')+")"
    script="import runpy,sys,types; m=types.ModuleType("+repr(variable)+"); "+attribute+"; sys.modules["+repr(variable)+"]=m; sys.argv=sys.argv[1:]; runpy.run_path(sys.argv[0],run_name='__main__')"
    result=launch(root,args,script)
    assert result.returncode==1 and 'preloaded local helper or unknown local alias'in result.stderr
    assert not (tmp_path/'output').exists()


def test_verified_bytes_loader_ignores_later_path_change(tmp_path,monkeypatch):
    path=tmp_path/'frozen.py';path.write_text('raise AssertionError("unverified path read")')
    with monkeypatch.context()as patch:
        patch.setattr(entry,'ROOT',tmp_path)
        loader=entry.FrozenLoader('frozen',b'value=17\n')
        import types
        module=types.ModuleType('frozen');loader.exec_module(module)
    assert module.value==17
