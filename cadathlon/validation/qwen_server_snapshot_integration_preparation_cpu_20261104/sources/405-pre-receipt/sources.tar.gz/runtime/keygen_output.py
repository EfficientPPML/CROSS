"""Bounded public reads and fresh held-parent evidence publication.

Adapted from readonly42 Output with REQUIRED external parent binding; shared4543. No
borrowed-store write, buffered stream, replacement, deletion, or close retry.
"""
import hashlib
import os
import stat
from pathlib import Path
from cleanup_origin import protect_body, select
from qwen_finalizer import Finalizer
from qwen_file_contract import canonical
from qwen_public_parse import parse

_QUARANTINE=[]


def identity(info): return (info.st_dev,info.st_ino)
def state(info): return (info.st_dev,info.st_ino,info.st_size,info.st_mtime_ns,info.st_ctime_ns,stat.S_IMODE(info.st_mode))


def canonical_path(value):
    if type(value)is not str or not 1<len(value)<=4096 or value.startswith('//') or '\\'in value or '\x00'in value:
        raise ValueError('canonical absolute path required')
    path=Path(value)
    if not path.is_absolute() or str(path)!=value or '..'in path.parts or path==path.parent or path.resolve()!=path:
        raise ValueError('resolved canonical non-root path required')
    return path


def overlap(a,b): return a==b or a in b.parents or b in a.parents


def finish(primary,operation,label):
    protect_body(primary)
    try: operation()
    except BaseException as error:
        chosen=select(primary,[(label,error)])
        if chosen is not primary: raise chosen


def read(path,*,limit,expected=None):
    path=canonical_path(str(path))
    if type(limit)is not int or limit<=0: raise ValueError('exact positive read bound required')
    primary=None
    fd=os.open(path,os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        before=os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or not 0<before.st_size<=limit:
            raise ValueError('bounded ordinary public input required')
        blocks=[];size=0
        while size<=limit:
            block=os.read(fd,min(1<<16,limit+1-size))
            if not block: break
            blocks.append(block);size+=len(block)
        raw=b''.join(blocks);after=os.fstat(fd);named=path.lstat()
        if state(before)!=state(after) or state(before)!=state(named) or not stat.S_ISREG(named.st_mode) or len(raw)!=before.st_size or size>limit:
            raise ValueError('public input identity/extent changed')
        if expected is not None and hashlib.sha256(raw).hexdigest()!=expected:
            raise ValueError('public input digest differs')
        return raw
    except BaseException as error:
        primary=protect_body(error);raise
    finally:
        original_fd=fd;fd=None
        def close():
            try: os.close(original_fd)
            except BaseException as error:
                _QUARANTINE.append((path,original_fd,error));raise
        finish(primary,close,'public read descriptor close')


def expected_parent(raw,parent):
    if type(raw)is not bytes or not 0<len(raw)<=8192: raise ValueError('bounded immutable external parent bytes required')
    value=parse(raw)
    if type(value)is not dict or set(value)!={'path','device','inode','mode'} or canonical(value)!=raw:
        raise ValueError('exact canonical external parent fields required')
    if canonical_path(value['path'])!=parent: raise ValueError('external parent path differs')
    for name,minimum,maximum in (('device',0,None),('inode',1,None),('mode',0,4095)):
        x=value[name]
        if type(x)is not int or x<minimum or (maximum is not None and x>maximum): raise ValueError('exact external parent integer required')
    return (value['path'],value['device'],value['inode'],value['mode'])


class Output:
    """Fresh evidence leaf under the independently granted original parent."""
    def _prepare(self,path,parent_bytes):
        self.path=canonical_path(path);self.parent=self.path.parent
        self.expected_parent=parent_bytes;self.parent_expectation=expected_parent(parent_bytes,self.parent)
        self.effective_uid=os.geteuid();self.parent_uid=None
        self.parent_fd=None;self.fd=None;self.failure=None;self.owner=None
        self.parent_identity=self.parent_expectation[1:3]
        self._fixed=(self.path,self.parent,self.expected_parent,self.parent_expectation,self.effective_uid)
        self._owned_fds=[]

    def __init__(self,path,*,expected_parent):
        self._prepare(path,expected_parent)
        try:
            self.parent_fd=os.open(self.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
            self._owned_fds.append(self.parent_fd)
            self.parent_uid=self._parent_check()
            self._parent_uid_fixed=self.parent_uid
            os.mkdir(self.path.name,0o700,dir_fd=self.parent_fd)
            self.fd=os.open(self.path.name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=self.parent_fd)
            self._owned_fds.append(self.fd)
            self.owner=identity(os.fstat(self.fd));self.check()
        except BaseException as error:
            primary=protect_body(error);self.close(primary=primary);raise

    def _parent_check(self):
        current=(self.path,self.parent,self.expected_parent,self.parent_expectation,self.effective_uid)
        if any(a is not b for a,b in zip(current,self._fixed)) or os.geteuid()!=self.effective_uid:
            raise ValueError('original external output parent binding changed')
        if self.parent_uid is not None and self.parent_uid!=self._parent_uid_fixed:
            raise ValueError('captured output parent UID changed')
        if not self._owned_fds or self.parent_fd!=self._owned_fds[0]: raise ValueError('original output parent descriptor changed')
        if self.parent.resolve()!=self.parent: raise ValueError('output parent alias differs')
        held=os.fstat(self.parent_fd);visible=self.parent.lstat()
        for info in (held,visible):
            mode=stat.S_IMODE(info.st_mode)
            if not stat.S_ISDIR(info.st_mode) or (str(self.parent),info.st_dev,info.st_ino,mode)!=self.parent_expectation:
                raise ValueError('granted original output parent identity differs')
            if info.st_uid not in (0,self.effective_uid) or (mode&0o022 and not mode&stat.S_ISVTX):
                raise ValueError('output parent is not trusted owned or sticky storage')
            if self.parent_uid is not None and info.st_uid!=self.parent_uid: raise ValueError('original output parent UID differs')
        if held.st_uid!=visible.st_uid: raise ValueError('held/named output parent UID differs')
        return held.st_uid

    def check(self):
        if self.failure is not None: raise self.failure
        if self.fd is None or self.parent_fd is None or len(self._owned_fds)!=2 or self.fd!=self._owned_fds[1]:
            raise ValueError('output is closed or descriptor changed')
        self._parent_check()
        if self.path.resolve()!=self.path: raise ValueError('output leaf alias differs')
        held=os.fstat(self.fd);visible=os.stat(self.path.name,dir_fd=self.parent_fd,follow_symlinks=False)
        for info in (held,visible):
            if not stat.S_ISDIR(info.st_mode) or identity(info)!=self.owner or info.st_uid!=self.effective_uid or stat.S_IMODE(info.st_mode)!=0o700:
                raise ValueError('original fresh output identity differs')

    def binding(self):
        self.check()
        return (str(self.path),self.expected_parent,self.effective_uid,self.parent_uid,self.owner)

    @classmethod
    def reopen(cls,binding):
        if type(binding)is not tuple or len(binding)!=5: raise ValueError('exact immutable output binding required')
        path,parent_bytes,uid,parent_uid,owner=binding
        if type(uid)is not int or uid<0 or type(parent_uid)is not int or parent_uid<0:
            raise ValueError('exact captured output UID required')
        if type(owner)is not tuple or len(owner)!=2 or any(type(x)is not int or x<0 for x in owner) or owner[1]<=0:
            raise ValueError('exact captured output inode required')
        value=cls.__new__(cls);value._prepare(path,parent_bytes)
        if value.effective_uid!=uid: raise ValueError('original effective UID differs on reopen')
        value.parent_uid=parent_uid;value._parent_uid_fixed=parent_uid;value.owner=owner
        try:
            value.parent_fd=os.open(value.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
            value._owned_fds.append(value.parent_fd);value._parent_check()
            value.fd=os.open(value.path.name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=value.parent_fd)
            value._owned_fds.append(value.fd);value.check();return value
        except BaseException as error:
            primary=protect_body(error);value.close(primary=primary);raise

    def write(self,name,raw):
        if type(name)is not str or name not in ('report.json','failure.json') or type(raw)is not bytes or not 0<len(raw)<=2<<20:
            raise ValueError('one bounded fresh evidence document required')
        self.check();primary=None
        fd=os.open(name,os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=self.fd)
        try:
            before=os.fstat(fd)
            if not stat.S_ISREG(before.st_mode) or stat.S_IMODE(before.st_mode)!=0o600 or before.st_uid!=self.effective_uid or before.st_size!=0:
                raise ValueError('fresh owned evidence file required')
            position=0
            while position<len(raw):
                count=os.write(fd,raw[position:position+(1<<16)])
                if type(count)is not int or not 0<count<=min(1<<16,len(raw)-position):
                    raise OSError('evidence write made invalid progress')
                position+=count
            os.fsync(fd)
            out=hashlib.sha256();position=0
            while position<len(raw):
                block=os.pread(fd,min(1<<16,len(raw)-position),position)
                if not block: raise ValueError('truncated evidence readback')
                out.update(block);position+=len(block)
            final=os.fstat(fd);named=os.stat(name,dir_fd=self.fd,follow_symlinks=False)
            if (identity(final)!=identity(before) or state(final)!=state(named)
                    or not stat.S_ISREG(named.st_mode) or final.st_size!=len(raw)
                    or out.hexdigest()!=hashlib.sha256(raw).hexdigest()):
                raise ValueError('original evidence file/hash differs')
            self.check();os.fsync(self.fd);self.check()
        except BaseException as error:
            primary=protect_body(error);raise
        finally:
            original_fd=fd;fd=None
            def close():
                try: os.close(original_fd)
                except BaseException as error:
                    self.failure=error;_QUARANTINE.append((self,original_fd,error));raise
            finish(primary,close,'evidence file close')

    def close(self,primary=None):
        # Even when a prior file close failed, attempt the other original FDs.
        final=Finalizer({},primary)
        if self.failure is not None:
            error=self.failure
            final.attempt('prior uncertain evidence close',lambda:(_ for _ in ()).throw(error))
        # Original acquisition slots are detached before any uncertain close.
        original=tuple(reversed(self._owned_fds));self._owned_fds.clear()
        self.fd=None;self.parent_fd=None
        for fd in original:
            def close(original=fd):
                try: os.close(original)
                except BaseException as error:
                    self.failure=error;_QUARANTINE.append((self,original,error));raise
            final.attempt('evidence original descriptor close',close)
        final.raise_if_failed()
