"""Bounded public-proof memory checks before complete scientific admission.

Only independently hash-pinned public metadata may reach this boundary. It
checks this process's host/cgroup headroom before the larger proof reads. It
does not authenticate the scientific result, admit a complete server phase,
reserve memory, import a backend or permit key/model/ciphertext reads.
"""
from pathlib import Path
import os
from client_role_common import raw_object,obj,integer
from qwen_file_contract import sha,same,hash_value
from qwen_server_admission import ExpectedServerPhasePins
from qwen_server_resource import (POLICY_FIELDS,COVERAGE,PUBLIC_METADATA_SOURCE_FLOOR,
    _kernel,_path,_QUARANTINE)


def authenticate_public_memory(expected_phase_pins,phase_grant_bytes,policy_bytes,review_bytes,
        *,source_manifest_sha256,source_archive_sha256):
    """Pure subset admission for public metadata only; full admission is later."""
    if type(expected_phase_pins)is not ExpectedServerPhasePins:
        raise TypeError('independently supplied exact server phase pins required')
    pins=expected_phase_pins.check()
    same(pins['source_manifest_sha256'],source_manifest_sha256,'bootstrap/public proof source differs')
    same(pins['source_archive_sha256'],source_archive_sha256,'bootstrap/public proof archive differs')
    if sha(phase_grant_bytes)!=pins['phase_grant_sha256']:
        raise ValueError('independent public phase grant bytes differ')
    grant=raw_object(phase_grant_bytes,1<<16,'unentered server phase grant')
    for name in('source_manifest_sha256','source_archive_sha256'):
        same(grant.get(name),pins[name],'public metadata/grant source differs')
    same(grant.get('policies'),pins['policies'],'public metadata/grant policies differ')
    for name,raw in(('resource_policy_sha256',policy_bytes),('resource_review_sha256',review_bytes)):
        if sha(raw)!=pins['policies'][name]:raise ValueError('independent public memory policy bytes differ')
    policy=raw_object(policy_bytes,1<<16,'public memory resource policy')
    obj(policy,POLICY_FIELDS,'public memory resource policy')
    if policy['schema']!='qwen-server-resource-policy-v1':raise ValueError('exact public memory policy schema required')
    integer(policy['public_metadata_headroom_bytes'],PUBLIC_METADATA_SOURCE_FLOOR,'public metadata allowance')
    integer(policy['host_reserve_bytes'],1,'public metadata host reserve')
    cores=policy['cores']
    if type(cores)is not list or not 0<len(cores)<=256 or any(type(c)is not int or c<0 for c in cores)or cores!=sorted(set(cores)):
        raise ValueError('exact ordered public metadata CPU lane required')
    for name,leaf in(('cgroup_memory_current','memory.current'),('cgroup_memory_max','memory.max')):
        selected=_path(policy[name])
        if Path('/sys/fs/cgroup')not in selected.parents or selected.name!=leaf:
            raise ValueError('exact selected cgroup-v2 public memory files required')
    if Path(policy['cgroup_memory_current']).parent!=Path(policy['cgroup_memory_max']).parent:
        raise ValueError('one public metadata cgroup scope required')
    # The independent reasoning review binds the complete policy bytes and
    # explicitly covers JSON materialization, retained proofs and rechecks.
    # This early subset does not claim that other policy semantics passed.
    residency=policy['mapped_residency']
    if type(residency)is not dict:raise ValueError('declared mapped residency review required')
    hash_value(residency.get('reviewed_evidence_sha256'))
    expected=dict(schema='qwen-server-resource-review-v1',approved=True,
        source_manifest_sha256=pins['source_manifest_sha256'],source_archive_sha256=pins['source_archive_sha256'],
        dependency_policy_sha256=pins['policies']['dependency_policy_sha256'],resource_policy_sha256=sha(policy_bytes),
        mapped_residency_evidence_sha256=residency.get('reviewed_evidence_sha256'),
        coverage={name:True for name in COVERAGE},logical_counts_are_peak_bounds=False,
        live_capacity_measured=False,actual_execution_authorized=False)
    same(raw_object(review_bytes,1<<16,'public metadata memory review'),expected,
        'independent complete metadata memory reasoning review required')
    return policy


def check_public_memory(expected_phase_pins,phase_grant_bytes,policy_bytes,review_bytes,
        *,source_manifest_sha256,source_archive_sha256):
    policy=authenticate_public_memory(expected_phase_pins,phase_grant_bytes,policy_bytes,review_bytes,
        source_manifest_sha256=source_manifest_sha256,source_archive_sha256=source_archive_sha256)
    if _QUARANTINE:raise RuntimeError('uncertain public memory descriptor retirement requires process exit')
    if sorted(os.sched_getaffinity(0))!=policy['cores']:
        raise ValueError('public proof process CPU lane differs')
    rows=[line.split()for line in _kernel('/proc/meminfo').splitlines()if line.startswith('MemAvailable:')]
    if len(rows)!=1 or len(rows[0])!=3 or rows[0][2]!='kB'or not rows[0][1].isdecimal():
        raise ValueError('bounded exact host memory observation required')
    available=int(rows[0][1])*1024
    groups=[line.split(':',2)for line in _kernel('/proc/self/cgroup').splitlines()]
    unified=[row[2]for row in groups if len(row)==3 and row[:2]==['0','']]
    if len(unified)!=1:raise ValueError('one current cgroup-v2 membership required')
    current_path=Path('/sys/fs/cgroup')/unified[0].lstrip('/')/'memory.current'
    if str(current_path)!=policy['cgroup_memory_current']:
        raise ValueError('public metadata memory policy is not for this process')
    current_text=_kernel(policy['cgroup_memory_current']).strip()
    maximum_text=_kernel(policy['cgroup_memory_max']).strip()
    if not current_text.isdecimal()or not(maximum_text=='max'or maximum_text.isdecimal()):
        raise ValueError('bounded exact cgroup memory observations required')
    current=int(current_text);maximum=None if maximum_text=='max'else int(maximum_text)
    required=policy['public_metadata_headroom_bytes']+policy['host_reserve_bytes']
    if available<required or(maximum is not None and maximum-current<required):
        raise MemoryError('reviewed public metadata headroom is unavailable')
    # Reauthenticate immutable inputs after the original kernel descriptors
    # have retired. No scientific proof body has been read by this function.
    authenticate_public_memory(expected_phase_pins,phase_grant_bytes,policy_bytes,review_bytes,
        source_manifest_sha256=source_manifest_sha256,source_archive_sha256=source_archive_sha256)
    return dict(public_metadata_only=True,source_manifest_sha256=source_manifest_sha256,
        resource_policy_sha256=sha(policy_bytes),observed_mem_available_bytes=available,
        observed_cgroup_current_bytes=current,observed_cgroup_max_bytes=maximum,
        required_public_metadata_headroom_bytes=required,source_retention_floor_bytes=PUBLIC_METADATA_SOURCE_FLOOR,
        capacity_reserved=False,peak_memory_measured=False,scientific_proofs_authenticated=False,
        resource_admission_complete=False,actual_execution_authorized=False)
