# Retained server snapshot integration — held source only

This isolated successor preserves the exact 387-file parent and the reviewed 390-file first integration separately, and selects the unchanged `qwen_admission_snapshot.py` digest `8790711a1a402f4c21ef444ccdb76f773b4c62cd334f5be07a49d2cd4535b395`. Relative to 387, only process, backend and the entry's explicit local-module name set are code overlays. Relative to 390, only process and backend code changes. `snapshot_integration.json` mechanically lists the parent changes and the 21-file binding callback closure. Older source-selection documents in this tree are preserved historical predecessor evidence; the new external map is the authoritative complete successor inventory.

The process captures the original guard module/spec, exported class/functions and descriptors, code/default identities and source-binding callback. The callback checks its explicit selected local source bytes, canonical file/spec origins and exact environment; it never calls the runtime, guard, packet/phase validators, capacity, audit transitions, or a reader/backend factory. The pure backend module is loaded as declarations before capture, so its original exports are not established after application callbacks. Imported function aliases are retained as exports, and the local checking helpers are compared before invocation. This is the declared trusted Python/native source boundary, not arbitrary-interpreter, private-registry or closure-cell containment.

Complete packet/scientific admission and public proof rereads remain in `admit` and the original finite process boundaries. The full boundary checker brackets replay with guard checks and retains the original public file record tuples. Hot `RuntimeAdmission` and `ServerBackend` checks use the retained packet guard and still perform original core, callback, audit, keyless and scope checks. The actual array map, original FD/root/parent/manifest state checks, bounded headers, hashes/residues, all335 descriptors, security/P coverage and file/engine/loader cleanup paths are unchanged.

Expected IDs are derived through the original phase method once and serialized as exactly seven canonical fields, including the server's null private-manifest hash. The input digest is obtained through its original property once. These original bytes/string and original ID object/dictionary/fields are retained by the runtime closure. Dependencies compare canonical expected IDs and the publisher compares the retained digest; actual request files still authenticate and derive their own upload digest. No scientific validator return value or cross-run PASS result is cached.

An issuer-owned runtime-control registry routes calls to the original closure, rejecting replaced instance `_control` or `.check` seams before use. It is a live ownership registry, not a global proof-result cache. Runtime identity/callback/audit/scope errors permanently deactivate that runtime and retain its original error. Check-only nesting remains valid during full source checks and original audit callbacks. A separate transition marker covers the interval before pending audit activation; nested key/body transitions reject, and caught rejection cannot resume activation. The original pending states still allow the required `require_keys`/`require_bodies` checks inside audit activation.

The original context/loader and runtime body scopes retire first. Full proof/source checks, sticky audit checks, original output close, audit restoration and signal restoration are attempted under the unchanged Finalizer. Only when no error remains does the original snapshot retire. Any earlier error skips that retirement and quarantines the original snapshot state, packet, derived values and owners; a retirement failure also propagates. Existing entry status70 and independent outer terminal receipt remain required.

`qwen_server_resource.py`, `qwen_server_entry_status.json` and `execution_authorization.json` are exact parent bytes. Complete capacity still denies before any core/body enablement, and readiness/actual flags remain false. No factual capacity packet, backend, key/context, actual grant or new server execution is supplied.

No candidate source was imported, collected or executed during this authoring. The earlier 38-source/18-case snapshot proof uses synthetic non-proof values and a recording full-validator seam; it is not proof of real server admission/integration. New focused tests and independent source review are still required. No speed, full-model, encrypted accuracy or body-integrity claim is made.

The second source checkpoint corrects two findings preserved against 390. The
source reader's `read -> finish -> protect_body/select -> is_cleanup/mark` path
uses the existing exact `cleanup_origin.py` bytes, now included in the callback's
source/module/export/code binding. `qwen_finalizer` is not added to this hot read
closure; its existing terminal cleanup remains unchanged.

Process runtime methods/properties and internal check closures retain their
original dispatcher/checker as source-defined defaults. The pure backend import
now occurs after the process dispatcher and RuntimeAdmission declarations, so
backend module loading can retain the original process checker without a late
dynamic import. Backend constructor/check methods retain the original backend
checker. A changed public dispatcher export is therefore checked by the original
registry/control and snapshot guard, where the runtime failure becomes sticky,
before a replacement dispatcher is invoked. Every actual source call uses the
original fixed argument shape; no source call supplies the private retention
keywords. These defaults are internal source-retention plumbing, not an injection
API or a new defense against arbitrary private-global/default/closure mutation.
The live runtime registry, check-only nesting, transition/pending state and
cleanup ordering are unchanged. This correction has source/AST evidence only;
no new integration tests have been collected or executed.
