"""Server dependency policy and Python audit boundary; no backend at import.

Adapted from corrected client464-v2. Actual file admission and complete host/
device authority remain separate process-owned prerequisites. Private key and
/dev access stay denied. No installed policy instance or resource grant exists.
"""
import hashlib
import os
from pathlib import Path
import stat
import sys
import threading
from types import ModuleType,MappingProxyType
from cleanup_origin import protect_body
from qwen_file_contract import canonical,sha,same,hash_value
from qwen_public_parse import parse
from keygen_output import canonical_path,overlap,finish
from qwen_server_resource import authenticate_policy
_QUARANTINE=[]
_PROC_SELF_KERNEL=frozenset(('/proc/self/status','/proc/self/cgroup','/proc/self/mountinfo'))
FORBIDDEN=frozenset(('torch','transformers','tensorflow','flax','torch_xla','safetensors','tokenizers'))
BACKENDS=('jax','jaxlib','numpy','libtpu','jax_plugins')
FILE_ROOTS=('jax','jaxlib','numpy','libtpu')
DEPENDENCY_FIELDS={'schema','interpreter','resolved_interpreter','python_major_minor','cores','environment','installed_sources','library_roots','backend_module_origins'}
ROLE_SCOPE=dict(public_key_arrays=335,logical_matrices=198,physical_matrix_files=197,gamma_vectors=113,response_blocks=38,
    private_key_reads=False,client_codecs=False,key_generation=False,scientific_acceptance=False,coefficient_revision=False)

def _literal_proc_self(value,dir_fd=None):
    # Preserve os.open's original argument before Path normalization. Direct
    # builtin audit events can attest only their already-normalized argument.
    # The wrapper rejects bytes/PathLike, relative and dirfd aliases here.
    return type(value)is str and value in _PROC_SELF_KERNEL and dir_fd is None

def object_bytes(raw,fields,schema,limit=2<<20):
    if type(raw)is not bytes or not 0<len(raw)<=limit:raise ValueError('bounded immutable policy bytes required')
    value=parse(raw)
    if type(value)is not dict or set(value)!=set(fields)or canonical(value)!=raw or value['schema']!=schema:
        raise ValueError('closed canonical policy differs')
    return value

def integer(value,minimum,label):
    if type(value)is not int or value<minimum:raise ValueError('exact positive '+label+' required')
    return value

def cores(value):
    if type(value)is not list or not value or any(type(x)is not int or x<0 for x in value)or value!=sorted(set(value)):
        raise ValueError('exact nonempty ordered CPU lane required')
    return value

def kernel_read(path,limit=1<<20):
    primary=None;fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        blocks=[];size=0
        while size<=limit:
            block=os.read(fd,min(65536,limit+1-size))
            if not block:break
            blocks.append(block);size+=len(block)
        if not 0<size<=limit:raise ValueError('bounded kernel metadata required')
        return b''.join(blocks).decode('ascii')
    except BaseException as error:primary=protect_body(error);raise
    finally:
        original=fd;fd=None
        def close():
            try:os.close(original)
            except BaseException as error:_QUARANTINE.append((path,original,error));raise
        finish(primary,close,'kernel metadata close')

def hash_installed(dep):
    observed={}
    for name,row in dep['installed_sources'].items():
        primary=None;fd=os.open(name,os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW|os.O_CLOEXEC)
        try:
            before=os.fstat(fd)
            if not stat.S_ISREG(before.st_mode)or before.st_size!=row['size']:raise ValueError('installed source extent differs')
            h=hashlib.sha256();count=0
            while count<row['size']:
                block=os.read(fd,min(1<<20,row['size']-count))
                if not block:raise ValueError('installed source truncated')
                h.update(block);count+=len(block)
            after=os.fstat(fd);named=os.stat(name,follow_symlinks=False)
            state=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns,stat.S_IMODE(s.st_mode))
            if state(before)!=state(after)or state(before)!=state(named)or not stat.S_ISREG(named.st_mode)or h.hexdigest()!=row['sha256']:
                raise ValueError('installed source original identity/hash differs')
            observed[name]=h.hexdigest()
        except BaseException as error:primary=protect_body(error);raise
        finally:
            original=fd;fd=None
            def close():
                try:os.close(original)
                except BaseException as error:_QUARANTINE.append((name,original,error));raise
            finish(primary,close,'installed source descriptor close')
    return observed

def environment(dep):
    if not sys.flags.isolated or not sys.dont_write_bytecode:raise ValueError('fresh -I -B required')
    if list(sys.version_info[:2])!=dep['python_major_minor']or os.path.abspath(sys.executable)!=dep['interpreter']:
        raise ValueError('selected interpreter differs')
    if Path(sys.executable).resolve()!=Path(dep['resolved_interpreter']):raise ValueError('independently pinned interpreter resolution differs')
    if sorted(os.sched_getaffinity(0))!=dep['cores']:raise ValueError('actual CPU affinity differs')
    if any(os.environ.get(k)!=v for k,v in dep['environment'].items()):raise ValueError('actual CPU environment differs')

def exact_environment(dep):
    environment(dep)
    if dict(os.environ)!=dep['environment']:raise ValueError('actual environment has an undeclared value')


def _locations(module):
    spec=getattr(module,'__spec__',None)
    a=getattr(module,'__path__',None);b=getattr(spec,'submodule_search_locations',None)
    if a is None and b is None:return None
    if a is None or b is None:raise ValueError('package search locations are incomplete')
    a=list(a);b=list(b)
    if any(type(p)is not str for p in a+b)or a!=b:raise ValueError('original package/spec search locations differ')
    return a


def imported_origins(dep,source_root):
    """Bind every loaded backend origin and package search path explicitly."""
    observed={};root=Path(source_root)
    for name,module in tuple(sys.modules.items()):
        first=name.split('.')[0]
        if first in FORBIDDEN:raise ValueError('forbidden server backend was imported')
        origins=(getattr(module,'__file__',None),getattr(getattr(module,'__spec__',None),'origin',None))
        backend=first in BACKENDS
        if backend:
            if not isinstance(module,ModuleType):raise ValueError('genuine backend module object required')
            policy=dep['backend_module_origins'].get(name)
            if policy is None:raise ValueError('backend module absent from reviewed origin policy')
            locations=_locations(module)
            same(dict(file=origins[0],spec=origins[1],search_locations=locations),policy,'actual backend independent origins differ')
            if locations is not None:
                for value in locations:
                    p=Path(value)
                    if not p.is_absolute()or p.resolve()!=p or not any(p==Path(r)or Path(r)in p.parents for r in dep['library_roots']):
                        raise ValueError('backend package namespace alias/outside installed roots')
        files=[]
        for value in origins:
            if value is None or isinstance(value,str)and value in('built-in','frozen'):continue
            if not isinstance(value,(str,os.PathLike)):
                if backend:raise ValueError('invalid backend module origin')
                continue
            p=Path(value)
            if p==root or root in p.parents:continue  # Complete local/core checks are separate.
            if not p.is_absolute()or p.resolve()!=p or str(p)not in dep['installed_sources']:
                raise ValueError('unbound installed module origin')
            files.append(str(p))
        if backend:observed[name]=dict(file=origins[0],spec=origins[1],search_locations=locations)
        elif files:observed[name]=dict(file=origins[0],spec=origins[1])
    if any(name not in sys.modules for name in BACKENDS):raise ValueError('all reviewed TPU dependency roots must be loaded')
    return observed


def policies(packet):
    from qwen_server_authority_packet import ServerPacket
    if type(packet)is not ServerPacket:raise TypeError('exact fully authenticated server packet required')
    packet.check();pins=packet.phase.expected_pins.check()
    dep=object_bytes(packet.dependency_policy,DEPENDENCY_FIELDS,'qwen-server-tpu-dependencies-v1')
    resource_pins={n:pins[n]for n in('source_manifest_sha256','source_archive_sha256','phase_grant_sha256')}
    resource_pins.update({n:pins['policies'][n]for n in('dependency_policy_sha256','resource_policy_sha256','resource_review_sha256')})
    res=authenticate_policy(packet.phase,packet.resource_policy,packet.resource_review,expected_pins=canonical(resource_pins))
    role=object_bytes(packet.role_policy,('schema','role','actual_entry_ready','scope'),'qwen-server-role-policy-v1',1<<16)
    same(role,dict(schema='qwen-server-role-policy-v1',role='full28_server',actual_entry_ready=True,scope=ROLE_SCOPE),
        'reviewed implemented full28 server policy required')
    for name in('dependency_policy','role_policy','resource_policy','resource_review'):
        if sha(getattr(packet,name))!=pins['policies'][name+'_sha256']:raise ValueError('independent server policy differs')
    cores(dep['cores']);same(dep['cores'],res['cores'],'server CPU lane policies differ')
    if res['device']['platform']!='tpu':raise ValueError('source-fixed TPU server platform required')
    executable=dep['interpreter']
    if(type(executable)is not str or not 1<len(executable)<=4096 or executable.startswith('//')or '\\'in executable or '\x00'in executable
       or not Path(executable).is_absolute()or str(Path(executable))!=executable or '..'in Path(executable).parts):raise ValueError('exact absolute interpreter spelling required')
    canonical_path(dep['resolved_interpreter']);version=dep['python_major_minor']
    if type(version)is not list or len(version)!=2 or any(type(x)is not int or x<0 for x in version):raise ValueError('exact Python version required')
    env=dep['environment']
    if type(env)is not dict or any(type(k)is not str or type(v)is not str or not 0<len(k)<=128 or len(v)>4096 for k,v in env.items()):raise ValueError('bounded exact environment policy required')
    required={'JAX_PLATFORMS':'tpu','JAX_ENABLE_X64':'true','PYTHONDONTWRITEBYTECODE':'1'}
    if any(env.get(k)!=v for k,v in required.items()):raise ValueError('explicit TPU/x64/no-bytecode environment required')
    if 'JAX_PLATFORM_NAME'in env and env['JAX_PLATFORM_NAME']!='tpu':raise ValueError('alternate platform selector forbidden')
    threads=[env.get(n)for n in('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')]
    if any(type(v)is not str or not v.isdecimal()or not 1<=int(v)<=len(dep['cores'])for v in threads)or len(set(threads))!=1:raise ValueError('exact reviewed host thread count required')
    if env.get('CROSS_SKIP_TOPLEVEL_ROTKEYS')=='1':raise ValueError('runtime key generation mode forbidden')
    libraries=dep['library_roots']
    if type(libraries)is not list or not libraries or len(libraries)>32 or libraries!=sorted(set(libraries)):raise ValueError('exact installed library roots required')
    roots=[canonical_path(v)for v in libraries];installed=dep['installed_sources']
    if type(installed)is not dict or not 5<=len(installed)<=16384:raise ValueError('complete bounded installed source closure required')
    for name,row in installed.items():
        p=canonical_path(name)
        if type(row)is not dict or set(row)!={'sha256','size'}:raise ValueError('exact installed file descriptor required')
        hash_value(row['sha256']);integer(row['size'],1,'installed file extent')
        if not any(p==r or r in p.parents for r in roots):raise ValueError('installed source outside declared libraries')
        if p.suffix not in('.py','.pyc','.so','.pyd')and '.so.'not in p.name:raise ValueError('only declared installed code/library files permitted')
    tpu=canonical_path(env.get('TPU_LIBRARY_PATH'))
    if str(tpu)not in installed or(tpu.suffix!='.so'and '.so.'not in tpu.name):raise ValueError('exact independently pinned TPU shared library required')
    origins=dep['backend_module_origins']
    if type(origins)is not dict or not 5<=len(origins)<=32768:raise ValueError('explicit bounded backend origin policy required')
    for name,row in origins.items():
        if(type(name)is not str or len(name)>512 or name.split('.')[0]not in BACKENDS or any(not part.isidentifier()for part in name.split('.'))):raise ValueError('exact backend module name required')
        if type(row)is not dict or set(row)!={'file','spec','search_locations'}:raise ValueError('complete backend origin/search-path policy required')
        for value in(row['file'],row['spec']):
            if value is None or type(value)is str and value in('built-in','frozen'):
                if name in FILE_ROOTS:raise ValueError('genuine file/spec root backend origins required')
                continue
            if type(value)is not str or str(canonical_path(value))not in installed:raise ValueError('backend origin outside installed source policy')
        locations=row['search_locations']
        if locations is not None:
            if type(locations)is not list or not locations or len(locations)>32 or any(type(p)is not str for p in locations)or len(set(locations))!=len(locations):raise ValueError('exact ordered package search locations required')
            for value in locations:
                p=canonical_path(value)
                if not any(p==r or r in p.parents for r in roots):raise ValueError('backend namespace outside declared libraries')
        if name in FILE_ROOTS and row['file']!=row['spec']:raise ValueError('matching genuine backend root origins required')
        if name=='jax_plugins':
            if locations is None:raise ValueError('explicit plugin package search locations required')
            if row['file']in('built-in','frozen')or row['spec']in('built-in','frozen'):raise ValueError('plugin root must be exact namespace or file-backed package')
            if row['file']is None or row['spec']is None:
                if row['file']is not None or row['spec']is not None:raise ValueError('exact plugin namespace origins required')
            elif row['file']!=row['spec']:raise ValueError('plugin package origins differ')
    if not all(name in origins for name in BACKENDS):raise ValueError('all five backend root identities required')
    return dep,res


def _runtime(value,phase):
    from qwen_server_process import RuntimeAdmission
    if type(value)is not RuntimeAdmission or value.phase is not phase:raise PermissionError('exact process-owned server runtime required')
    value.check();return value


def _accessor(value):return(getattr(value,'__self__',None),getattr(value,'__func__',value))

def _same_accessor(a,b):return all(x is y for x,y in zip(_accessor(a),_accessor(b)))


class AccessScope:
    """Exact file sets and explicit process-owned transitions, not an OS sandbox.

    Broad model-protection roots may contain the exact admitted model files.
    always_protected is a separate explicit private/token/calibration scope:
    no file exception can override it. /dev has no selected exception at all.
    """
    def __init__(self,root,source_names,public_paths,phase,profile,dep,res,protected,*,always_protected):
        from qwen_server_admission import ServerPhaseAdmission
        from qwen_key_contract import PublicProfile
        if type(phase)is not ServerPhaseAdmission or type(profile)is not PublicProfile:raise TypeError('exact complete server/public key admission required')
        phase.check();profile.check();same(profile.parameters,phase.public.profile(),'same fixed server key profile required')
        self.phase=phase;self.dep=dep;self.res=res;self.root=Path(root)
        self.denials=[];self.active=True;self.enabled=False;self.keys_enabled=False;self.bodies_enabled=False
        self.local=threading.local();self.original_open=os.open;self.wrapper=None;self.runtime=None;self.runtime_methods=None
        grant=parse(phase.grant_bytes)
        if grant['role']!='full28_server'or Path(grant['source_root'])!=self.root:raise ValueError('exact server source/role audit binding required')
        stores=parse(phase.readiness.report_bytes)['stores']
        same(grant['public_key_store'],stores['public'],'independently generated public key store differs')
        self.private_root=Path(stores['private']['path']);public_root=Path(stores['public']['path'])
        self.key_roots=frozenset((public_root,));self.keys=frozenset({public_root/s.name for s in profile.arrays}|{public_root/'public_manifest.json'})
        if len(profile.arrays)!=335 or len(self.keys)!=336:raise ValueError('exact335 public array files plus manifest required')
        model=phase.model.stores.check();model_roots={n:Path(v['path'])for n,v in model['roots'].items()}
        self.model_roots=frozenset(model_roots.values());self.models=frozenset(model_roots[v['family']]/v['name']for v in model['files'])
        if len(self.models)!=198 or sum(v['family']=='gamma'for v in model['files'])!=1:raise ValueError('exact197 matrices plus gamma container required')
        request=parse(phase.request_bytes);count=request['input']['input_tile_count'];input_root=Path(grant['input']['root']['path'])
        if type(count)is not int or count not in(1,2):raise ValueError('one or two original input tiles required')
        self.input_roots=frozenset((input_root,));self.inputs=frozenset({input_root/f'tile{i:02}.npz'for i in range(count)}|{input_root/'request.json'})
        self.leaves=MappingProxyType({name:Path(row['path'])for name,row in grant['outputs'].items()});self.parents=frozenset(p.parent for p in self.leaves.values())
        response=self.leaves['response'];evidence=self.leaves['evidence']
        self.owned=frozenset({response/f'block{i:02}.npz'for i in range(38)}|{response/'response.json'})
        self.evidence=frozenset((evidence/'report.json',evidence/'failure.json'))
        self.installed=frozenset(map(Path,dep['installed_sources']))
        self.public=frozenset({Path(p)for p in public_paths}|{self.root/n for n in source_names}|set(self.installed))
        self.source_directories=frozenset({self.root}|{p for name in source_names for p in(self.root/name).parents if p==self.root or self.root in p.parents})
        self.protected=tuple(Path(p)for p in protected);self.always_protected=tuple(Path(p)for p in always_protected)+(self.private_root,Path('/dev'))
        self.kernel=frozenset(map(Path,('/proc/meminfo','/proc/self/status','/proc/self/cgroup','/proc/self/mountinfo',res['cgroup_memory_current'],res['cgroup_memory_max'])))
        for p in self.public|self.keys|self.key_roots|self.models|self.model_roots|self.inputs|self.input_roots|self.owned|self.evidence|set(self.leaves.values()):
            if any(overlap(p,r)for r in self.always_protected):raise ValueError('admitted server scope overlaps always-protected private/token/calibration/device scope')
        self._policy_bytes=(canonical(dep),canonical(res));self._fixed=self._state()

    def _state(self):
        return(self.phase,self.dep,self.res,self.root,self.public,self.source_directories,self.leaves,self.parents,self.key_roots,self.keys,
            self.models,self.model_roots,self.inputs,self.input_roots,self.owned,self.evidence,self.protected,self.always_protected,self.kernel,self.installed)

    def _bind_runtime(self,runtime):
        _runtime(runtime,self.phase)
        methods=tuple(getattr(runtime,n)for n in('check','require_public_key_read_scope','require_server_body_scope'))
        if any(not callable(fn)for fn in methods):raise TypeError('original server runtime scope callbacks required')
        if self.runtime is None:self.runtime=runtime;self.runtime_methods=methods
        elif self.runtime is not runtime or any(not _same_accessor(a,b)for a,b in zip(self.runtime_methods,methods)):raise ValueError('original process runtime/scope callbacks changed')
        return methods

    def enable_public_keys(self,runtime):
        self.check()
        if self.keys_enabled:raise PermissionError('public key transition is single-use')
        methods=self._bind_runtime(runtime);methods[1]()
        self.keys_enabled=True

    def enable_server_bodies(self,runtime):
        self.check()
        if not self.keys_enabled or self.bodies_enabled:raise PermissionError('one server-body transition after public-key admission required')
        methods=self._bind_runtime(runtime);methods[2]()
        self.bodies_enabled=True

    def deny(self,kind):
        self.denials.append(kind);raise PermissionError('server audit denied '+kind)

    def resolve(self,value,dir_fd=None):
        if type(value)is int:return Path(os.readlink('/proc/self/fd/'+str(value)))
        p=Path(os.fsdecode(value))
        if not p.is_absolute():p=(Path(os.getcwd())if dir_fd is None else Path(os.readlink('/proc/self/fd/'+str(dir_fd))))/p
        return p

    def access(self,p,flags,*,literal_kernel=False):
        if type(flags)is not int or type(literal_kernel)is not bool or not p.is_absolute()or '..'in p.parts:self.deny('open spelling or flags')
        if any(p==r or r in p.parents for r in self.always_protected):self.deny('always-protected body/device')
        if str(p)in _PROC_SELF_KERNEL:
            allowed=os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NONBLOCK
            if not literal_kernel or p not in self.kernel or flags&~allowed:self.deny('nonliteral or writable proc-self read')
            if any(p==r or r in p.parents for r in self.protected):self.deny('protected body')
            if p.resolve()!=Path('/proc')/str(os.getpid())/p.name:self.deny('foreign proc-self resolution')
            return
        if p.resolve()!=p:self.deny('open alias')
        write=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
        # Only exact read-only model files/roots can override the broad model
        # protection. Neither an output nor another read gains that exception.
        if any(p==r or r in p.parents for r in self.protected)and(write or p not in self.models|self.model_roots):self.deny('protected body')
        if write:
            need=os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW
            if not self.enabled or p not in self.owned|self.evidence or flags&need!=need or flags&(os.O_TRUNC|os.O_APPEND):self.deny('nonexclusive/unselected write')
            if p in self.owned and not self.bodies_enabled:self.deny('response write before complete server body admission')
            return
        if p in self.models|self.model_roots:
            if not self.bodies_enabled:self.deny('model read before server body admission')
            return
        if p in self.owned|self.evidence:
            if not self.enabled or(p in self.owned and not self.bodies_enabled):self.deny('owned read before admission')
            return
        if p in self.keys|self.key_roots:
            if not self.keys_enabled:self.deny('public key read before complete resource admission')
            return
        if p in self.inputs|self.input_roots:
            if not self.bodies_enabled:self.deny('request read before server body admission')
            return
        if p in self.public|self.parents|set(self.leaves.values())|self.kernel|self.source_directories:return
        self.deny('unselected read')

    def install(self):
        if os.open is not self.original_open:raise ValueError('open wrapper changed before server audit')
        def wrapped(path,flags,mode=0o777,*,dir_fd=None):
            selected=self.resolve(path,dir_fd);literal=_literal_proc_self(path,dir_fd)
            self.access(selected,flags,literal_kernel=literal)
            previous=getattr(self.local,'open',None);self.local.open=(path,selected,flags,literal)
            try:return self.original_open(path,flags,mode,dir_fd=dir_fd)
            finally:self.local.open=previous
        self.wrapper=wrapped
        def audit(event,args):
            if not self.active:return
            if event=='open':
                pending=getattr(self.local,'open',None);matched=pending is not None and args[0]==pending[0]
                p=pending[1]if matched else self.resolve(args[0]);literal=pending[3]if matched else _literal_proc_self(args[0])
                self.access(p,args[2],literal_kernel=literal)
            elif event=='import'and args and str(args[0]).split('.')[0]in FORBIDDEN:self.deny('forbidden import')
            elif event.startswith('socket.')or event in('subprocess.Popen','os.fork','os.forkpty','os.posix_spawn','os.posix_spawnp','os.system','os.exec'):
                self.deny('network/process')
            elif event=='os.mkdir':
                p=self.resolve(args[0],args[2]if len(args)>2 and args[2]!=-1 else None)
                if(not self.enabled or p not in self.leaves.values()or args[1]!=0o700 or(p==self.leaves['response']and not self.bodies_enabled)):
                    self.deny('unselected directory creation')
            elif event in('os.remove','os.rmdir','os.rename','os.link','os.symlink','os.truncate','os.chmod','os.chown'):
                self.deny('mutation outside exclusive create')
            elif event=='ctypes.dlopen'and args[0]is not None:
                if Path(str(args[0]))not in self.installed:self.deny('unselected shared library')
        sys.addaudithook(audit);os.open=wrapped

    def check(self):
        if any(a is not b for a,b in zip(self._state(),self._fixed)):raise ValueError('original server audit scope changed')
        if(canonical(self.dep),canonical(self.res))!=self._policy_bytes:raise ValueError('original server dependency/resource policy changed')
        if self.runtime is not None:
            current=tuple(getattr(self.runtime,n)for n in('check','require_public_key_read_scope','require_server_body_scope'))
            if any(not _same_accessor(a,b)for a,b in zip(current,self.runtime_methods)):raise ValueError('original runtime scope methods changed')
        if self.denials:raise PermissionError('sticky server audit denial')
        if not self.active or os.open is not self.wrapper:raise ValueError('original active server audit wrapper changed')

    def close(self):
        primary=None
        try:self.check()
        except BaseException as error:primary=protect_body(error)
        finally:os.open=self.original_open;self.active=False
        if primary is not None:raise primary
