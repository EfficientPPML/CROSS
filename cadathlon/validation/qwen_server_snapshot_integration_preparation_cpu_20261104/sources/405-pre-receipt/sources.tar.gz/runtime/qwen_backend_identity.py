"""Source-bound core aliases for a dedicated, already-admitted actual process.

Importing this helper is stdlib-only. ``install_core`` is not launch authority:
its caller must first authenticate the role/model/grant/source and dependency
policy. The supplied first-position import gate remains authoritative. This
helper stays installed until dedicated-process exit; setup failure is terminal.
No key generation, context construction, dependency import, or file read occurs
in install_core. Loading selected modules is an explicit later operation.
"""
from dataclasses import dataclass
import hashlib
import importlib
import importlib.util
import os
import sys
from types import MappingProxyType

CORE_SHA256 = {'__init__.py': 'fc78b0845c2314a523cb20e490ded0c8ef09c9c05fa50d92eb218ef247533096', 'bconv.py': '53ac0665cf3803fc72672657146ef7c19c823f48f326cf7d54ae87a15ae92f82', 'bootstrapping.py': 'e44f748f5ef51ec68be0f224f4d8ff1068fe6c449f09c04532900a3ac4fcfc49', 'bootstrapping_openfhe_crosscheck.py': '4f9b9ea005d46ab15f4530f689d096b112fca4f09ffa46dcd3990a03d5159ecb', 'bsgs.py': '52a1027be9bf704fd3ffd453251d2b3136ab31a3242c12d341ca1374b1b82aed', 'ckks_ctx.py': 'bc978cb7412b55416f7ed634a689ae616a263b0f47fd9eef996ba244f2505db6', 'composite_prime_gen.py': 'e3e689237d2b8449333774e84fa271a15a5c54ad603a32f7fcbe60ecb26f0317', 'finite_field.py': '54418625f76e303d77a3055f93419e07895bdf71f706acc20ab0f6fe7c8def5e', 'he_ops.py': 'c3b068d04099569cfd1cb5650c4132113bf487a08d1ad837fd623a9668343aa1', 'he_params.py': 'b34f2a938598ef9fd1f9de157db3400c48befcb60866751449742917e2e3fccc', 'headd.py': '53a691d7dc5d330886cfa11a990087d5ad4bb6dbabac47f3b85a281acc395d37', 'hemul.py': '2286a6baa5d1832f617307aaaee6c0f156b2c05b2cd4320caf50312cae37268c', 'herot.py': '112f9ecaa1298b201aeea31aeb5325be724287e29c5aa21e6ef2f02f16d3148c', 'hesub.py': 'baad1322793dd239cb4e66749f05bf4982f58d0932b098abbd305ff2402cbf5e', 'key_gen.py': '742e6af9e1ce9025416fa2ef68ae037bca7e772d48fbbd6ca387cc79820119c8', 'mapping.py': 'c8d035d4b7d743b18324830eeb09b6cd2a562bc4862e6af2ee10702922f6816f', 'nn.py': '189cb48dff9124d32f84e6154b5e8403082d3eed87ab12d5fb1e80f1e21213de', 'ntt_mm.py': '5a0cbff087f48f20c98cb5975f7894756a83d61fbdaaf5af358a1c7c192a1263', 'ntt_sm.py': 'b57ebe4c8c1037288e3d50c9d3e443c4656a31d57bcb215ed7a302717d498a65', 'packing.py': '7496f37b7116b883c14f8e3d5cae6bd1ed7375d0a8d2425f78c8f84e347c0206', 'pedagagy/bat.py': '429786d49ba01b6343a3b0ebde1807f5739cdbfcc7209ffbe55d89cdd74bc1c5', 'pedagagy/modular_reduction.py': '87e2e57cbc99e47bae1a81e99a34b93a9a7d41bddc6b0d3a874b5e0415289da0', 'pedagagy/ntt.py': '8dc8e58c3e17ba8218e51422e0974d038377f3dc5deac66f30ae909aaa1a2cfa', 'pedagagy/util.py': '38c500e8f2af30ac37d5753de176777bbf0f0cde471d7fdf42e214c09e19ca9a', 'polynomial.py': '043e1dcdf9aca02f2df9435ac610c1561859b7d29a7dee1b7254bf9bc3c89a5b', 'profiler.py': '440c7aa2026cfd6b29c37f4b9db78984f1dfbf484c1f7f841caab82ece9da543', 'ptct_mul.py': '2780cb5d261cbf3da611f79fc9a6b6ef98d4759c7508cad26ed5995699f5bf11', 'rescale.py': 'bdfb603bf377fb2d53cd9d75d78066a91ffdf2567e56053eeb47907bae810b20', 'rns.py': '41db559ea26e3149ada36ec8369cfa4a5a79876ae9253e0dbabe32c9c09ef158', 'tabIX.py': '8abf557fd986782a92d8b3517bf0d3470e1ae0ddc135eddd69efee87aabc78b6', 'tabV.py': '385cda2816d6c2342ab39e57367b5a078d49102fdc7deaf165db4faa58fc20b0', 'tabVI.py': '29cae4e85987d894c6944b050677d560340f1d214b329f9f02cab2c6db531310', 'tabVII.py': '90b5f99e6ad2e2e156ea7cd167ec40c7186e99ffbc259edbac7f70668fa83e18', 'util.py': 'b34c675b50ae774cdb0ad913f8fc9c2f955b60bf4745006d3f81d7c013565026'}
CORE_PREFIX = 'runtime/jaxite_word'
# Historical benchmark and pedagogical files remain hash-bound provenance, not
# executable members of the actual client/key-generation import graph.
ACTIVE = frozenset(('bconv','bootstrapping','bsgs','ckks_ctx',
    'composite_prime_gen','finite_field','he_ops','he_params','headd','hemul',
    'herot','hesub','key_gen','mapping','nn','ntt_mm','ntt_sm','packing',
    'polynomial','ptct_mul','rescale','rns','util'))
_INSTALLATION = None


def _accessor(value):
    return (getattr(value, '__self__', None), getattr(value, '__func__', value))


def _same_accessor(left, right):
    a, b = _accessor(left), _accessor(right)
    return a[0] is b[0] and a[1] is b[1]


@dataclass(frozen=True)
class RetainedCallables:
    binding: object
    name: str
    module: object
    values: tuple

    def check(self):
        self.binding.check()
        if self.binding.module(self.name) is not self.module:
            raise RuntimeError('selected core module was replaced')
        for name, original in self.values:
            if getattr(self.module, name) is not original:
                raise RuntimeError('selected core callable or constant was replaced')
        return self


class _Loader:
    def __init__(self, finder, requested, short):
        self.finder, self.requested, self.short = finder, requested, short

    def create_module(self, spec):
        return None

    def exec_module(self, module):
        owner = self.finder
        owner.order_check()
        short = self.short
        if short in owner.records:
            raise ImportError('selected core module must not execute twice')
        relative = '__init__.py' if short is None else short + '.py'
        origin = owner.paths[relative]
        aliases = ('jaxite_word',) if short is None else (short, 'jaxite_word.' + short)
        for alias in aliases:
            current = sys.modules.get(alias)
            if current is not None and current is not module:
                raise ImportError('conflicting selected core alias')
        # Bind BOTH aliases before execution so circular flat imports cannot
        # construct a second class/module identity.
        for alias in aliases:
            sys.modules[alias] = module
        module.__file__ = origin
        module.__cached__ = None
        if short is None:
            module.__path__ = [owner.directory]
        owner.records[short] = (module, self, module.__spec__, aliases)
        try:
            code = compile(owner.blobs[relative], origin, 'exec', dont_inherit=True)
            exec(code, module.__dict__)
            if short is not None:
                package = sys.modules.get('jaxite_word')
                if package is None:
                    raise ImportError('selected core package must load first')
                setattr(package, short, module)
            owner.complete.add(short)
        except BaseException:
            owner.failed = True
            raise


class _Finder:
    def __init__(self, root, blobs, gate):
        self.directory = root + '/' + CORE_PREFIX
        self.paths = MappingProxyType({name: self.directory + '/' + name for name in blobs})
        self.blobs = MappingProxyType(dict(blobs))
        self.gate = gate
        self.gate_accessor = gate.find_spec
        self.records = {}
        self.complete = set()
        self.failed = False

    def order_check(self):
        if (len(sys.meta_path) < 2 or sys.meta_path[0] is not self.gate
                or sys.meta_path[1] is not self
                or not _same_accessor(self.gate.find_spec, self.gate_accessor)):
            raise RuntimeError('selected core must remain behind the original import gate')
        if self.failed:
            raise RuntimeError('failed core import requires dedicated-process exit')

    def find_spec(self, fullname, path=None, target=None):
        if fullname == 'jaxite_word':
            short = None
        elif fullname.startswith('jaxite_word.'):
            short = fullname[len('jaxite_word.'):]
            if short not in ACTIVE:
                raise ImportError('unselected core child import')
        elif fullname in ACTIVE:
            short = fullname
        elif fullname in {name[:-3] for name in CORE_SHA256 if '/' not in name and name.endswith('.py')}:
            raise ImportError('historical core module is not selected for actual execution')
        else:
            return None
        self.order_check()
        if target is not None:
            raise ImportError('selected core reload is forbidden')
        loader = _Loader(self, fullname, short)
        relative = '__init__.py' if short is None else short + '.py'
        return importlib.util.spec_from_file_location(fullname, self.paths[relative],
            loader=loader, submodule_search_locations=[self.directory] if short is None else None)


@dataclass(frozen=True)
class CoreBinding:
    _finder: object
    _source_sha256: tuple

    def check(self):
        finder = self._finder
        finder.order_check()
        if tuple(sorted((name, hashlib.sha256(raw).hexdigest())
                        for name, raw in finder.blobs.items())) != self._source_sha256:
            raise RuntimeError('authenticated core byte binding changed')
        package = sys.modules.get('jaxite_word')
        for short, (module, loader, spec, aliases) in tuple(finder.records.items()):
            if short not in finder.complete:
                raise RuntimeError('selected core import is incomplete')
            relative = '__init__.py' if short is None else short + '.py'
            if (any(sys.modules.get(alias) is not module for alias in aliases)
                    or module.__file__ != finder.paths[relative]
                    or module.__spec__ is not spec or spec.origin != finder.paths[relative]
                    or spec.loader is not loader or module.__loader__ is not loader):
                raise RuntimeError('selected core alias or origin changed')
            if short is None:
                if list(module.__path__) != [finder.directory]:
                    raise RuntimeError('selected core package search path changed')
            elif package is None or vars(package).get(short) is not module:
                raise RuntimeError('selected package attribute is not its flat alias')
        for name, module in tuple(sys.modules.items()):
            if name == 'jaxite_word' or name.startswith('jaxite_word.') or name in {n[:-3] for n in CORE_SHA256 if '/' not in n and n.endswith('.py')}:
                if not any(module is rec[0] and name in rec[3] for rec in finder.records.values()):
                    raise RuntimeError('unbound selected-core module appeared')
        return self

    def load(self, names):
        if type(names) is not tuple or not names or any(type(x) is not str or x not in ACTIVE for x in names):
            raise ValueError('exact tuple of selected flat core names required')
        if len(set(names)) != len(names):
            raise ValueError('duplicate selected core names')
        self._finder.order_check()
        importlib.import_module('jaxite_word')
        for name in names:
            importlib.import_module('jaxite_word.' + name)
        self.check()
        return MappingProxyType({name: self.module(name) for name in names})

    def module(self, name):
        if type(name) is not str or name not in ACTIVE or name not in self._finder.complete:
            raise ValueError('selected core module was not loaded')
        return self._finder.records[name][0]

    def retain(self, name, attributes):
        self.check()
        module = self.module(name)
        if (type(attributes) is not tuple or not attributes
                or any(type(x) is not str or not x or '.' in x for x in attributes)
                or len(set(attributes)) != len(attributes)):
            raise ValueError('exact nonempty attribute tuple required')
        return RetainedCallables(self, name, module,
            tuple((attribute, getattr(module, attribute)) for attribute in attributes))


def install_core(root, blobs, source_map, *, gate):
    """Bind fixed34 byte sources behind a trusted, still-enforcing entry gate.

    root is the already authenticated execution root. blobs/source_map contain
    exact root-relative source bytes and SHA256 values from the caller's closed
    source admission. No paths are opened here. Calls are single-use per process.
    """
    global _INSTALLATION
    if _INSTALLATION is not None:
        raise RuntimeError('core binding is single-use per dedicated process')
    if type(root) is not str or not root.startswith('/') or os.path.normpath(root) != root:
        raise ValueError('canonical absolute authenticated source root required')
    if type(blobs) is not dict or type(source_map) is not dict:
        raise TypeError('authenticated exact source dictionaries required')
    if not sys.meta_path or sys.meta_path[0] is not gate or not callable(getattr(gate, 'find_spec', None)):
        raise ValueError('original first-position source/dependency gate required')
    selected = {}
    for name, expected in CORE_SHA256.items():
        path = CORE_PREFIX + '/' + name
        raw = blobs.get(path)
        if type(raw) is not bytes or source_map.get(path) != expected or hashlib.sha256(raw).hexdigest() != expected:
            raise ValueError('selected fixed core source differs')
        selected[name] = raw
    flat = {name[:-3] for name in CORE_SHA256 if '/' not in name and name.endswith('.py')}
    if any(name == 'jaxite_word' or name.startswith('jaxite_word.') or name in flat for name in sys.modules):
        raise ImportError('core module preloaded before source/dependency admission')
    finder = _Finder(root, selected, gate)
    binding = CoreBinding(finder, tuple(sorted(CORE_SHA256.items())))
    _INSTALLATION = binding
    sys.meta_path.insert(1, finder)
    return binding.check()
