from types import SimpleNamespace
import json,math,pytest
import diagnose as d

@pytest.mark.parametrize('digits,alpha',[(6,17),(8,13)])
def test_fixed_partitions_independent_coverage(digits,alpha):
 for n in range(2,101,2):
  actual=d.partition_indices(n,digits)
  assert [i for group in actual for i in group]==list(range(n))
  assert all(len(group)==alpha for group in actual[:-1])and 1<=len(actual[-1])<=alpha
  assert all(group[0]==i*alpha for i,group in enumerate(actual))

@pytest.mark.parametrize('n,digits',[(True,6),(2.,6),(0,6),(102,6),(2,True),(2,0)])
def test_typed_partition_rejections(n,digits):
 with pytest.raises(ValueError):d.partition_indices(n,digits)

@pytest.mark.parametrize('kind',[ValueError,KeyboardInterrupt,SystemExit])
def test_install_failure_restores_prior_and_primary(kind):
 a=SimpleNamespace(x=object());b=SimpleNamespace(x=object());old=(a.x,b.x);primary=kind('installer');n=0;state=SimpleNamespace()
 def setter(owner,name,value):
  nonlocal n;n+=1
  if n==2:raise primary
  setattr(owner,name,value)
 with pytest.raises(kind)as got:
  with d.patched([(a,'x'),(b,'x')],object(),state,setter=setter):raise AssertionError('must not enter')
 assert got.value is primary and(a.x,b.x)==old and state.restored

@pytest.mark.parametrize('kind',[KeyboardInterrupt,SystemExit])
def test_body_primary_survives_guard_restore_failure(kind):
 a=SimpleNamespace(x=1);b=SimpleNamespace(x=2);primary=kind('body');state=SimpleNamespace();seen=[]
 def setter(owner,name,value):
  if value in (1,2):seen.append(value);raise OSError('restore')
  setattr(owner,name,value)
 with pytest.raises(kind)as got:
  with d.patched([(a,'x'),(b,'x')],0,state,setter=setter):raise primary
 assert got.value is primary and seen==[2,1]and not state.restored

def test_descriptor_has_no_payload():
 x=d.Descriptor(dict(degree=131072,precision=32,degree_layout=(256,512)),parameters={'moduli':[3,5]})
 assert not hasattr(x,'coeffs')and not hasattr(x,'data')
 with pytest.raises(TypeError):x.shapes['degree']=2

def test_parent_and_findings_bind_same_actual_profiles():
 r=json.loads((d.HERE/'parent_report.json').read_bytes());findings=json.loads((d.HERE/'static-findings.json').read_bytes())
 assert len(r['profiles'])==len(findings['profiles'])==3
 for old,row in zip(r['profiles'],findings['profiles']):
  f=old['registration']['fields'];a=(100+f['dnum']-1)//f['dnum'];bits=max(math.prod(f['q_towers'][i:i+a]).bit_length()for i in range(0,100,a))
  assert row['physical_bit_count_lower_bound']==(bits+row['aux_bits']-1)//row['aux_bits']
  assert row['generated_P_count']==len(f['p_towers'])and not row['registered_accepted']

def test_actual_readiness_walker_visits_public_controls_once():
 import ast,inspect
 tree=ast.parse(inspect.getsource(d.construct))
 walker=next(n for n in tree.body[0].body if isinstance(n,ast.FunctionDef)and n.name=='wait_controls')
 outer=ast.parse('def probe(value):\n seen=set()\n ready_count=0\n pass\n wait_controls(value)\n return ready_count\n').body[0]
 outer.body[2]=walker
 module=ast.fix_missing_locations(ast.Module(body=[outer],type_ignores=[]));ns={}
 exec(compile(module,'actual-control-readiness-AST','exec'),ns)
 calls=[]
 class Array:
  def block_until_ready(self):calls.append(self)
 public_type=type('PublicControl',(),{'__module__':'herot'})
 value=public_type();a=Array();b=Array();value.tables={'a':[a,a],'b':(b,)}
 value.cycle=value
 assert ns['probe'](value)==2 and calls==[a,b]
