"""Real public HERot/BConv control construction with descriptor-only polynomials."""
from pathlib import Path
from contextlib import contextmanager
from types import MappingProxyType,SimpleNamespace
import argparse,hashlib,importlib,json,math,os,sys,tarfile,time,io
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'parent/core'))
EXTRAS=('DESIGN.md','static-findings.json','parent_report.json','parent_archive_sha256.json','diagnose.py','test_diagnose.py')
def sha(b):return hashlib.sha256(b).hexdigest()
def sources():
 parent=json.loads((HERE/'parent_report.json').read_bytes())['source_hashes_before']
 result={'parent/'+n:(HERE/'parent'/n).read_bytes()for n in parent}
 if {n:sha(result['parent/'+n])for n in parent}!=parent:raise ValueError('exact frozen parent43 required')
 result.update({n:(HERE/n).read_bytes()for n in EXTRAS});return result
def hashes(raw):return {n:sha(b)for n,b in raw.items()}
def write(p,r):Path(p).write_text(json.dumps(r,sort_keys=True,indent=2,allow_nan=False)+'\n')
def partition_indices(n,d):
 if type(n)is not int or not 0<n<=100 or type(d)is not int or not 1<=d<=100:raise ValueError('typed maxQ100 partition required')
 a=(100+d-1)//d;return [list(range(i,min(i+a,n)))for i in range(0,n,a)]
class Descriptor:
 __slots__=('shapes','parameters')
 def __init__(self,shapes,*,parameters):
  self.shapes=MappingProxyType(dict(shapes));self.parameters=MappingProxyType(dict(parameters))
  if shapes['degree']!=131072 or shapes['precision']!=32 or shapes['degree_layout']!=(256,512):raise ValueError('public descriptor mismatch')

@contextmanager
def patched(targets,deny,state,*,setter=setattr):
 previous=[];primary=None
 try:
  for owner,name in targets:
   old=getattr(owner,name);previous.append((owner,name,old));setter(owner,name,deny)
  state.installed=len(previous);yield
 except BaseException as error:primary=error;raise
 finally:
  errors=[]
  for owner,name,old in reversed(previous):
   try:setter(owner,name,old)
   except BaseException as error:errors.append(error)
  state.restored=not errors
  if primary is not None:
   for e in errors:
    if e is not primary:primary.add_note('public audit guard restoration: '+repr(e))
  elif errors:raise next((e for e in errors if not isinstance(e,Exception)),errors[0])

def runtime():
 hp=importlib.import_module('jaxite_word.he_params');ctx=importlib.import_module('jaxite_word.ckks_ctx')
 poly=importlib.import_module('jaxite_word.polynomial');key=importlib.import_module('jaxite_word.key_gen')
 rot=importlib.import_module('herot');bc=importlib.import_module('bconv');ff=importlib.import_module('finite_field')
 targets=[]
 for m in {hp,importlib.import_module('he_params')}:targets.append((m.HEParameterCache,'__init__'))
 for m in {ctx,importlib.import_module('ckks_ctx')}:
  targets.extend((m.CKKSContext,n)for n in ('__init__','program_initialization','encrypt','encrypt_slots','encrypt_slots_batch','decrypt','decrypt_slots','decrypt_slots_batch','encode','encode_at_level','decode'))
 for m in {poly,importlib.import_module('polynomial')}:targets.append((m.Polynomial,'__init__'))
 for m in {key,importlib.import_module('key_gen')}:
  targets.extend((m,n)for n in ('gen_evaluation_key','gen_rotation_key','gen_pke_pair','key_switch_gen','gen_ternary_uniform_polynomial','gen_uniform_polynomial','gen_gaussian_polynomial'))
 targets.extend((rot._HERotKernel,n)for n in ('setup_rotation','rotate','_rotate_array','_decompose_array','_mod_down_array'))
 targets.extend((bc.BConv,n)for n in ('basis_change','basis_change_bat','_basis_change_dense','_basis_change_bat'))
 targets=list(dict.fromkeys(targets));return SimpleNamespace(hp=hp,rot=rot,bc=bc,ff=ff,targets=targets)

def construct(r,fields,level):
 import numpy as np
 q=fields['q_towers'];p=fields['p_towers'];d=fields['dnum'];n=2*(level+1);parts=partition_indices(n,d);overall=q[:n]+p
 made=[]
 def factory(shapes,*,parameters):x=Descriptor(shapes,parameters=parameters);made.append(x);return x
 kernel=r.rot._HERotKernel(256,512,d,q[:n],p,finite_field_context=r.ff.BarrettContext,polynomial_factory=factory)
 kernel.control_gen(batch=1,degree_layout=(256,512),perf_test=False,keygen_sizeQ=100)
 if kernel.select_tower_index!=parts or kernel.numPartQl!=len(parts)or not kernel._controls_ready or kernel._rotation_ready:raise ValueError('actual control partition/readiness mismatch')
 expected_non=[[i for i in range(len(overall))if i not in part]for part in parts]
 if kernel.non_select_tower_index!=expected_non:raise ValueError('actual nonselected tower list mismatch')
 if len(made)!=len(parts)+4 or any(hasattr(x,'coeffs')or hasattr(x,'data')for x in made):raise ValueError('descriptor-only polynomial factory boundary')
 expected_groups=[([q[i]for i in part],[overall[i]for i in target])for part,target in zip(parts,expected_non)]+[(p,q[:n])]
 actual=list(zip(kernel.bconv.original_moduli,kernel.bconv.target_moduli))
 if actual!=expected_groups:raise ValueError('actual BConv source/target bases mismatch')
 tables=[];exact_entries=0;public_bytes=0
 def completed(value):
  nonlocal public_bytes
  wait=getattr(value,'block_until_ready',None)
  if callable(wait):wait()
  a=np.asarray(value);public_bytes+=a.nbytes;tables.append(dict(shape=list(a.shape),dtype=str(a.dtype),sha256=sha(a.tobytes())));return a
 inv=completed(kernel.PInvModq)
 if inv.tolist()!=[pow(math.prod(p),-1,v)for v in q[:n]]:raise ValueError('P inverse control differs')
 exact_entries+=len(inv)
 for j,(source,target)in enumerate(expected_groups):
  product=math.prod(source);qh=[product//x for x in source]
  inverse=completed(kernel.bconv.QHatInvModq[j]);matrix=completed(kernel.bconv.QHatModp[j]);bat=completed(kernel.bconv.QHatModpBAT[j])
  expected_inverse=[pow(h,-1,x)for h,x in zip(qh,source)]
  expected_matrix=[[h%x for x in target]for h in qh]
  if inverse.tolist()!=expected_inverse or matrix.tolist()!=expected_matrix:raise ValueError('independent exact QHat constants differ')
  expected_bat=np.array([[[((h*(1<<(8*a)))%x)>>(8*b)&255 for b in range(4)]for x in target]for h in qh for a in range(4)],dtype=np.uint8)
  if not np.array_equal(bat,expected_bat):raise ValueError('independent byte-lane table differs')
  exact_entries+=inverse.size+matrix.size+bat.size
 for group in (kernel.restore_indices,kernel._restore_indices_jax,kernel._select_tower_index_jax):
  for v in group:completed(v)
 seen=set();ready_count=0
 def wait_controls(value):
  nonlocal ready_count
  if id(value)in seen:return
  seen.add(id(value))
  wait=getattr(value,'block_until_ready',None)
  if callable(wait):wait();ready_count+=1;return
  if isinstance(value,dict):
   for item in value.values():wait_controls(item)
  elif isinstance(value,(tuple,list)):
   for item in value:wait_controls(item)
  elif not isinstance(value,type)and type(value).__module__ in ('finite_field','jaxite_word.finite_field','bconv','herot'):
   wait_controls(vars(value))
 wait_controls(kernel)
 if math.prod(p)<max(math.prod(q[i]for i in part)for part in parts):raise ValueError('fixed partition P coverage failed')
 return dict(level=level,num_q=n,max_q=100,fixed_alpha=(100+d-1)//d,partitions=parts,active_digits=len(parts),actual_control_sets=len(actual),
  descriptor_count=len(made),descriptor_shapes=[dict(x.shapes)for x in made],P_coverage=True,controls_ready=True,rotation_ready=False,
  exact_public_constant_entries=int(exact_entries),explicit_control_array_bytes=int(public_bytes),completed_public_tables=tables,completed_device_control_buffers=ready_count,
  bat_selected=list(kernel.bconv._use_bat),byte_accounting='Sum of named logical array nbytes; duplicate views may be counted; finite-field context/compiler allocations excluded; not a physical memory bound',scope='Real imported control construction; only polynomial allocation is replaced by metadata descriptors; no key binding or HE')

def run(output):
 if os.environ.get('JAX_PLATFORMS')!='cpu':raise ValueError('explicit CPU only')
 if any(n.startswith(('CROSS_','BOOTSTRAP_','PYTEST_'))for n in os.environ):raise ValueError('inherited runtime/test override forbidden')
 output=Path(output);output.mkdir(exist_ok=False);raw=sources();before=hashes(raw);start=time.monotonic();report=dict(passed=False,pid=os.getpid(),source_hashes_before=before,profiles=[],forbidden_during_controls=None,CPU_backend_initialized=False)
 with tarfile.open(output/'sources.tar.gz','w:gz')as tar:
  for n,b in raw.items():item=tarfile.TarInfo(n);item.size=len(b);tar.addfile(item,io.BytesIO(b))
 report['source_archive_sha256']=sha((output/'sources.tar.gz').read_bytes());write(output/'report.json',report)
 primary=None;calls=[];state=SimpleNamespace(installed=0,restored=False)
 try:
  r=runtime();import jax
  if any(d.platform!='cpu'for d in jax.devices()):raise ValueError('CPU backend only')
  report.update(CPU_backend_initialized=True,devices=[str(d)for d in jax.devices()])
  def deny(*a,**k):calls.append('forbidden state/key/HE');raise RuntimeError('public controls only')
  with patched(r.targets,deny,state):
   for owner,name in r.targets:
    try:getattr(owner,name)(None)
    except RuntimeError as e:
     if str(e)!='public controls only':raise
    else:raise AssertionError('guard probe did not deny')
   exercised=len(calls)
   for previous in json.loads((HERE/'parent_report.json').read_bytes())['profiles']:
    fields=previous['registration']['fields'];target=r.hp.SecurityTarget(128,'classical');row=dict(dnum=fields['dnum'],aux_bits=previous['aux_bits'],P_count=len(fields['p_towers']),levels=[])
    logical=r.hp.estimate_openfhe_aux_prime_count(50,fields['dnum'],61,60,previous['aux_bits']);lower=r.hp.compute_num_p_towers(fields['q_towers'],fields['dnum'],previous['aux_bits'])
    row.update(logical_estimated_P_count=logical,physical_bit_count_lower_bound=lower,generated_P_exact=r.hp.generate_p_towers(fields['q_towers'],fields['dnum'],131072,previous['aux_bits'])==fields['p_towers'],actual_QP_secure=r.hp.qp_is_secure(fields['q_towers'],fields['p_towers'],131072,target))
    try:r.hp.validate_runtime_config(SimpleNamespace(**fields),target);row['registered_accepted']=True
    except (ValueError,TypeError)as e:row.update(registered_accepted=False,registration_rejection=dict(type=type(e).__name__,message=str(e)))
    if row['registered_accepted']or not row['actual_QP_secure']or not row['generated_P_exact']:raise ValueError('frozen diagnosis outcomes changed')
    report['profiles'].append(row)
    for level in range(50):row['levels'].append(construct(r,fields,level))
    write(output/'report.json',report)
   report.update(guard_count=state.installed,installed_guard_denials=exercised,forbidden_during_controls=len(calls)-exercised)
  if report['forbidden_during_controls']!=0:raise ValueError('state/HE invoked by control construction')
  report['passed']=True
 except BaseException as e:primary=e;report['error']=dict(type=type(e).__name__,message=str(e));raise
 finally:
  report.update(source_hashes_after=hashes(sources()),guards_restored=state.restored,elapsed_s=time.monotonic()-start)
  report['source_files_unchanged']=report['source_hashes_after']==before
  with tarfile.open(output/'sources.tar.gz')as tar:report['source_archive_verified']={m.name:sha(tar.extractfile(m).read())for m in tar}==before
  report['passed']=bool(report['passed']and report['source_files_unchanged']and report['source_archive_verified']and state.restored)
  report['scope']='Public controls plus descriptor placeholders only. No CKKS/HEParameterCache/Polynomial instances, keys, ciphertexts, codecs, HE operations, compiled runtime acceptance, profile/validator edits or accuracy/latency claim.'
  try:write(output/'report.json',report)
  except BaseException as e:
   if primary is None:raise
   primary.add_note('public audit report failure: '+repr(e))
 return report
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('output',type=Path);a=p.parse_args();r=run(a.output);print(json.dumps(dict(passed=r['passed'],profiles=len(r['profiles']),prefixes=sum(len(x['levels'])for x in r['profiles']),sources=len(r['source_hashes_before']),elapsed_s=r['elapsed_s'])));raise SystemExit(0 if r['passed']else 1)
