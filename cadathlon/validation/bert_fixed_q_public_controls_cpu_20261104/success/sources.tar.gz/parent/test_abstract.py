"""Real imported structural-method checks with no payload allocation."""
import json
import pytest
import audit,plan

def candidates():
 profile=json.loads((plan.HERE/'inputs/profile.json').read_bytes())['profile'];prior=json.loads((plan.HERE/'inputs/public_profile_audit.json').read_bytes())
 return plan.build(profile,prior)['profiles']

@pytest.mark.parametrize('index',(0,1,2))
def test_baseline_and_candidate_registered_rejections_are_explicit_outcomes(index):
 with audit.guarded_runtime()as runtime:
  profile=candidates()[index];record=audit.registration(runtime.hp,profile)
  assert record['actual_public_security']is True
  assert record['accepted']is False
  assert record['estimated_logical_P_count']in (15,19,18)
  assert 'P towers'in record['rejection']['message']
  assert not runtime.calls

@pytest.mark.parametrize('index,level',((0,0),(0,49),(1,0),(1,17),(1,49),(2,25)))
def test_actual_formatting_and_active_digit_shapes(index,level):
 with audit.guarded_runtime()as runtime:
  profile=candidates()[index];r=audit.abstract_level(runtime,profile,profile['rows'][level])
  assert r['passed']and not r['full_kernel_control_generated']and not r['compiled_HE_executed']
  assert not runtime.calls

def test_wrong_raw_axis_order_rejected_by_actual_formatter():
 import jax
 import jax.numpy as jnp
 with audit.guarded_runtime()as runtime:
  profile=candidates()[1];p=len(profile['P'])
  def wrong(a,b,coef):return audit.descriptor(runtime.hp,profile,a,b,coef).get_rot_key(1,49)
  a=jax.ShapeDtypeStruct((6,131072,100+p),jnp.uint32);coef=jax.ShapeDtypeStruct((131072,),jnp.int32)
  with pytest.raises(TypeError,match='reshape'):jax.eval_shape(wrong,a,a,coef)
  assert not runtime.calls

def test_missing_real_key_fails_before_any_generation():
 with audit.guarded_runtime()as runtime:
  cache=audit.descriptor(runtime.hp,candidates()[1],None,None,None);cache.raw_rotation_keys={}
  with pytest.raises(ValueError,match='secret_key is unavailable'):cache.get_rot_key(1,49)
  assert not runtime.calls
