"""Imported public validation and abstract shape tracing; never creates HE state."""
from pathlib import Path
from types import SimpleNamespace as NS,MethodType
from contextlib import contextmanager
import argparse,hashlib,importlib,json,math,os,sys,tarfile,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'core'))
import plan

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,data):path.write_text(json.dumps(data,indent=2,sort_keys=True,allow_nan=False)+'\n')
def sources():
 origins=json.loads((HERE/'source_origins.json').read_bytes())
 names=(*origins,'source_origins.json','plan.py','test_plan.py','DESIGN.md','public_plan.json','audit.py','test_abstract.py')
 return {n:sha(HERE/n)for n in sorted(names)}

@contextmanager
def guarded_runtime():
 hp=importlib.import_module('jaxite_word.he_params');ckks=importlib.import_module('jaxite_word.ckks_ctx')
 poly=importlib.import_module('jaxite_word.polynomial');keys=importlib.import_module('jaxite_word.key_gen')
 ops=importlib.import_module('he_ops');rot=importlib.import_module('herot')
 calls=[];old=[];seen=set()
 def deny(*args,**kwargs):calls.append('forbidden state/HE entry');raise RuntimeError('public abstract audit forbids state/HE')
 targets=[]
 for module in {hp,importlib.import_module('he_params')}:targets.append((module.HEParameterCache,'__init__'))
 for module in {poly,importlib.import_module('polynomial')}:targets.append((module.Polynomial,'__init__'))
 for module in {ckks,importlib.import_module('ckks_ctx')}:
  targets.extend((module.CKKSContext,n)for n in ('__init__','program_initialization','encrypt','encrypt_slots','encrypt_slots_batch','decrypt','decrypt_slots','decrypt_slots_batch','encode','encode_at_level','decode'))
 for module in {keys,importlib.import_module('key_gen')}:
  targets.extend((module,n)for n in ('gen_evaluation_key','gen_rotation_key','gen_pke_pair','key_switch_gen','gen_ternary_uniform_polynomial','gen_uniform_polynomial','gen_gaussian_polynomial'))
 targets.extend((rot._HERotKernel,n)for n in ('__init__','control_gen','setup_rotation','rotate'))
 state=NS(hp=hp,ops=ops,rot=rot,calls=calls,guard_count=0,restored=False)
 try:
  for owner,name in targets:
   if (owner,name)in seen:continue
   seen.add((owner,name));old.append((owner,name,getattr(owner,name)));setattr(owner,name,deny)
  state.guard_count=len(old);yield state
 finally:
  primary=sys.exception();errors=[]
  for owner,name,value in reversed(old):
   try:setattr(owner,name,value)
   except BaseException as error:errors.append(error)
  state.restored=not errors
  if primary is not None:
   for error in errors:primary.add_note('abstract audit guard restoration: '+type(error).__name__)
  elif errors:raise next((e for e in errors if not isinstance(e,Exception)),errors[0])

def descriptor(hp,profile,raw_a,raw_b,coef):
 fields=profile['registered_full_config_fields'];q=fields['q_towers'];p=fields['p_towers']
 cache=NS(max_level=49,num_q=100,composite_degree=2,q_towers=q,p_towers=p,num_p=len(p),
  r=256,c=512,dnum=profile['dnum'],degree_layout=(256,512),batch=1,perf_test=False,
  per_level_rotation_keys=False,secret_key=None,cache_rotation_keys=False,
  rotation_polynomial_factory=None,raw_rotation_keys={1:{'a':raw_a,'b':raw_b}},
  _formatted_rotation_keys={},coef_maps={1:coef})
 for name in ('_validated_level','_validated_num_q','num_q_at_level','q_moduli_at_level','get_rot_key'):
  setattr(cache,name,MethodType(getattr(hp.HEParameterCache,name),cache))
 cache._validated_index=hp.HEParameterCache._validated_index
 cache._validated_integral=hp.HEParameterCache._validated_integral
 cache.ff_context_cls=importlib.import_module('finite_field').BarrettContext
 return cache

def registration(hp,profile):
 target=hp.SecurityTarget(128,hp.CostModel.CLASSICAL)
 fields=profile['registered_full_config_fields'];cfg=NS(**fields)
 result={'fields':fields,'accepted':False,'target':'128-bit classical uniform ternary',
  'estimated_logical_P_count':hp.estimate_openfhe_aux_prime_count(50,profile['dnum'],61,60,profile['aux_bits'])}
 try:hp.validate_runtime_config(cfg,target);result['accepted']=True
 except (ValueError,TypeError)as error:result['rejection']={'type':type(error).__name__,'message':str(error)}
 result['actual_public_security']=hp.qp_is_secure(fields['q_towers'],fields['p_towers'],131072,target)
 return result

def _shape(value):return {'shape':list(value.shape),'dtype':str(value.dtype)}

def abstract_level(runtime,profile,row):
 import jax
 import jax.numpy as jnp
 hp,ops,rot=runtime.hp,runtime.ops,runtime.rot
 actual_kernel=rot._HERotKernel;dispatch=[]
 class RecordingKernel:
  """Only captures constructor/control arguments; no actual controls or math."""
  def __init__(self,r,c,dnum,q,p,**options):
   self.r=r;self.c=c;self.dnum=dnum;self.q=q;self.p=p;self.sizeQlP=len(q)+len(p)
   dispatch.append(dict(r=r,c=c,dnum=dnum,q_count=len(q),p_count=len(p),backend=options['finite_field_context'].__name__))
  def control_gen(self,*,batch,degree_layout,perf_test,keygen_sizeQ):
   self.numPartQl=math.ceil(len(self.q)/math.ceil(keygen_sizeQ/self.dnum))
   dispatch[-1].update(batch=batch,degree_layout=list(degree_layout),perf_test=perf_test,keygen_sizeQ=keygen_sizeQ,active_digits=self.numPartQl)
  def setup_rotation(self,a,b,coef):
   # Real imported structural validator, using only abstract tracers.
   self.a,self.b=actual_kernel._resolve_evaluation_keys(self,a,b);self.coef=coef
   dispatch[-1]['active_key_shape']=list(a.shape)
 def traced(a,b,coef):
  cache=descriptor(hp,profile,a,b,coef);proxy=NS()
  ops._HERotAtLevel.__init__(proxy,cache,row['level'],1)
  return proxy._herot.a,proxy._herot.b,proxy._herot.coef
 raw=jax.ShapeDtypeStruct(tuple(row['raw_key_shape']),jnp.uint32)
 coef=jax.ShapeDtypeStruct((131072,),jnp.int32)
 original=rot._HERotKernel
 try:
  rot._HERotKernel=RecordingKernel
  graph=jax.make_jaxpr(traced)(raw,raw,coef)
 finally:rot._HERotKernel=original
 assert not graph.consts and len(dispatch)==1
 outputs=[_shape(x)for x in graph.out_avals]
 assert outputs[:2]==[{'shape':row['active_key_shape'],'dtype':'uint32'}]*2
 assert outputs[2]=={'shape':[131072],'dtype':'int32'}
 assert dispatch[0]['keygen_sizeQ']==100 and dispatch[0]['active_digits']==row['active_digits']
 equations=[]
 for eq in graph.jaxpr.eqns:
  name=eq.primitive.name
  if name not in ('copy','transpose','slice','concatenate','reshape','convert_element_type'):
   raise ValueError('unexpected nonstructural primitive: '+name)
  record={'primitive':name,'inputs':[_shape(v.aval)for v in eq.invars],'outputs':[_shape(v.aval)for v in eq.outvars]}
  for key in ('permutation','start_indices','limit_indices','strides','dimension','new_sizes','dimensions'):
   if key in eq.params:record[key]=eq.params[key]
  equations.append(record)
 transposes=[e for e in equations if e['primitive']=='transpose'];assert len(transposes)==2
 assert all(tuple(e['permutation'])==(0,2,1)and e['outputs'][0]['shape']==row['formatted_full_key_shape']for e in transposes)
 slices=[e for e in equations if e['primitive']=='slice'and len(e['inputs'][0]['shape'])==3]
 n=row['num_q'];end=100+len(profile['P'])
 expected_slices={(0,n),(100,end)}
 # At full Q, the original implementation still selects Q then P separately.
 assert len(slices)==4 and {(e['start_indices'][-1],e['limit_indices'][-1])for e in slices}==expected_slices
 return dict(level=row['level'],passed=True,outputs=outputs,dispatch_only=dispatch[0],equations=equations,
  keygen_sizeQ_frozen=True,full_kernel_control_generated=False,compiled_HE_executed=False)

def reject_shape(runtime,shape_a,shape_b,*,active,qp):
 import jax
 import jax.numpy as jnp
 state=NS(r=256,c=512,sizeQlP=qp,numPartQl=active)
 kernel=runtime.rot._HERotKernel
 a=None if shape_a is None else jax.ShapeDtypeStruct(shape_a,jnp.uint32)
 b=None if shape_b is None else jax.ShapeDtypeStruct(shape_b,jnp.uint32)
 try:jax.eval_shape(lambda x,y:kernel._resolve_evaluation_keys(state,x,y),a,b)
 except (ValueError,RuntimeError)as error:return {'rejected':True,'type':type(error).__name__,'message':str(error)}
 raise AssertionError('malformed abstract evaluation key shape accepted')

def evaluate(runtime):
 profile=json.loads((HERE/'inputs/profile.json').read_bytes())['profile'];prior=json.loads((HERE/'inputs/public_profile_audit.json').read_bytes())
 planned=plan.build(profile,prior);result=[]
 for candidate in planned['profiles']:
  record={'dnum':candidate['dnum'],'aux_bits':candidate['aux_bits'],'P':candidate['P'],'registration':registration(runtime.hp,candidate),'levels':[]}
  for row in candidate['rows']:
   traced=abstract_level(runtime,candidate,row);shape=tuple(row['active_key_shape']);active=shape[0];qp=shape[-1]
   traced['negative_shapes']={
    'too_few_digits':reject_shape(runtime,(active-1,*shape[1:]),(active-1,*shape[1:]),active=active,qp=qp),
    'wrong_tail':reject_shape(runtime,(*shape[:-1],qp+1),(*shape[:-1],qp+1),active=active,qp=qp),
    'unpaired':reject_shape(runtime,shape,None,active=active,qp=qp)}
   assert row['P_covers_fixed_partitions']
   traced['independent_fixed_partition_plan']=row
   record['levels'].append(traced)
  result.append(record)
 return result

def run(output):
 output=Path(output);output.mkdir(exist_ok=False);started=time.monotonic();before=sources();runtime=None
 report={'passed':False,'pid':os.getpid(),'scope':'Actual imported registered-validator outcomes plus abstract frozen-maxQ formatting/key-shape checks; no contexts/keys/payloads/compiled HE',
  'source_hashes_before':before,'profiles':[]}
 try:
  write(output/'report.json',report)
  origins=json.loads((HERE/'source_origins.json').read_bytes());assert all(sha(HERE/n)==v['sha256']for n,v in origins.items())
  with tarfile.open(output/'sources.tar.gz','w:gz')as t:
   for n in before:t.add(HERE/n,arcname=n)
  report['source_archive_sha256']=sha(output/'sources.tar.gz')
  with guarded_runtime()as runtime:
   import jax
   report['devices']=[str(d)for d in jax.devices()];assert all(d.platform=='cpu'for d in jax.devices())
   report['CPU_backend_initialized']=True
   methods={'validate_runtime_config':runtime.hp.validate_runtime_config,'get_rot_key':runtime.hp.HEParameterCache.get_rot_key,
    'num_q_at_level':runtime.hp.HEParameterCache.num_q_at_level,'rotation_facade_init':runtime.ops._HERotAtLevel.__init__,
    'resolve_evaluation_keys':runtime.rot._HERotKernel._resolve_evaluation_keys}
   report['actual_methods']={n:{'source':f.__code__.co_filename,'sha256':sha(Path(f.__code__.co_filename))}for n,f in methods.items()}
   assert all(Path(r['source']).resolve().is_relative_to(HERE/'core')for r in report['actual_methods'].values())
   report['profiles']=evaluate(runtime);assert not runtime.calls
   report['passed']=True
 except BaseException as error:report['error']={'type':type(error).__name__,'message':str(error)};raise
 finally:
  primary=sys.exception();errors=[]
  if runtime is not None:report.update(forbidden_calls=runtime.calls,guards_restored=runtime.restored,denied_entrypoints=runtime.guard_count)
  try:
   report['source_hashes_after']=sources();report['source_files_unchanged']=report['source_hashes_after']==before
   with tarfile.open(output/'sources.tar.gz','r:gz')as t:
    hashes={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest()for m in t.getmembers()}
   report['source_archive_verified']=hashes==before
  except BaseException as error:errors.append(error);report['final_source_error']=type(error).__name__
  report['elapsed_s']=time.monotonic()-started
  report['passed']=bool(report['passed']and primary is None and not errors and report.get('guards_restored')and not report.get('forbidden_calls')and report.get('source_files_unchanged')and report.get('source_archive_verified'))
  try:write(output/'report.json',report)
  except BaseException as error:errors.append(error)
  if primary is not None:
   for error in errors:primary.add_note('audit finalization: '+type(error).__name__)
  elif errors:raise next((e for e in errors if not isinstance(e,Exception)),errors[0])
 return report

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('output');args=parser.parse_args();r=run(args.output)
 print(json.dumps({'passed':r['passed'],'sources':len(r['source_hashes_before']),'profiles':[{'dnum':p['dnum'],'aux':p['aux_bits'],'registered':p['registration'],'levels':len(p['levels'])}for p in r['profiles']]}))
 raise SystemExit(0 if r['passed']else 1)
