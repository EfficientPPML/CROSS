"""Experimental two-level full-slot BERT score routing.

This trades more rotations and simultaneous ciphertexts for seven fewer levels
than the independently measured bitwise route. It never refreshes or owns a
context. The caller supplies a keyless initialized CompiledArithmetic owner;
bound-aware arithmetic requires a separate propagated-bound design.
"""
from collections import Counter
from dataclasses import dataclass
import math
import numbers
import numpy as np

SLOTS, ROWS, FEATURES, HEADS, HEAD_WIDTH, KEYS, PAD_HEADS = 65536, 16, 4096, 12, 64, 128, 16


@dataclass(frozen=True)
class ShallowScoreLayout:
    key_tile: int
    offset: int

    def __post_init__(self):
        if (type(self.key_tile) is not int or not 0 <= self.key_tile < 8
                or type(self.offset) is not int or not 0 <= self.offset < ROWS):
            raise ValueError('public tile/offset outside the fixed128-key layout')

    @property
    def row_keys(self):
        return self.key_tile*ROWS + (np.arange(ROWS)+self.offset) % ROWS

    @property
    def source_indices(self):
        return (np.arange(ROWS)[:, None]*FEATURES + np.arange(HEADS)*HEAD_WIDTH).ravel()

    @property
    def target_indices(self):
        return (np.arange(ROWS)[:, None]*FEATURES + self.row_keys[:, None]*PAD_HEADS
                + np.arange(HEADS)).ravel()

    def rotation_indices(self, *, include_inverse=True):
        forward = [63*head for head in range(HEADS)]
        forward += [-PAD_HEADS*int(key) for key in self.row_keys]
        if include_inverse:
            forward += [-shift for shift in forward]
        return tuple(sorted({shift % SLOTS for shift in forward if shift % SLOTS}))

    def head_diagonals(self, *, inverse=False, gain=1.):
        for head in range(HEADS):
            mask = np.zeros(SLOTS)
            positions = np.arange(ROWS)*FEATURES + head*(HEAD_WIDTH if inverse else 1)
            mask[positions] = gain
            mask.setflags(write=False)
            yield ((-1 if inverse else 1)*63*head), mask

    def key_diagonals(self, *, inverse=False):
        for row, key in enumerate(self.row_keys):
            mask = np.zeros(SLOTS)
            positions = row*FEATURES + (0 if inverse else int(key)*PAD_HEADS) + np.arange(HEADS)
            mask[positions] = 1.
            mask.setflags(write=False)
            yield ((1 if inverse else -1)*PAD_HEADS*int(key)), mask


class ShallowScoreRouting:
    """Two actual public weighted sums, each followed by one composite rescale."""
    def __init__(self, arithmetic, layout, *, progress=None):
        from encrypted_packed_qwen import CompiledArithmetic
        if not isinstance(arithmetic, CompiledArithmetic):
            raise TypeError('routing requires a CompiledArithmetic owner')
        if callable(getattr(arithmetic, 'declare_bound', None)):
            raise TypeError('bound-aware arithmetic is outside this component contract')
        if not isinstance(layout, ShallowScoreLayout):
            raise TypeError('expected ShallowScoreLayout')
        if progress is not None and not callable(progress):
            raise TypeError('progress must be callable or None')
        self.arithmetic, self.layout, self.progress = arithmetic, layout, progress
        self.counts = Counter()
        self._guard_context()

    def _guard_context(self):
        context = self.arithmetic.ctx
        cache = getattr(context, '_param_cache', None)
        if cache is None or context.degree != 2*SLOTS or context.num_slots != SLOTS:
            raise ValueError('routing requires an initialized full65536-slot context')
        if (context.secret_key is not None or cache.secret_key is not None
                or context.parameters.get('secret_key') is not None):
            raise ValueError('routing requires a keyless context')
        if cache.batch != 1 or context.composite_degree != 2:
            raise ValueError('routing requires batchone and composite degree two')
        if getattr(self.arithmetic, 'refresher', None) is not None:
            raise ValueError('two-level route does not permit implicit refresh')

    def _validate_ciphertext(self, value):
        self._guard_context()
        from jaxite_word import Polynomial
        from support import require_secure_execution
        if not isinstance(value, Polynomial):
            raise TypeError('routing requires a canonical ciphertext')
        if value.batch != 1 or value.num_elements != 2 or value.degree != 2*SLOTS:
            raise ValueError('routing requires a full-slot two-component ciphertext')
        require_secure_execution(self.arithmetic.ctx, value)
        if self.arithmetic._level(value) < 2:
            raise ValueError('routing requires two remaining levels')
        if not math.isclose(value._ckks_scale, self.arithmetic.scale, rel_tol=1e-12):
            raise ValueError('routing requires canonical input scale')

    def _stage(self, value, diagonals, label):
        level = self.arithmetic._level(value)
        values, weights = [], []
        for shift, mask in diagonals:
            normalized = int(shift) % SLOTS
            values.append(self.arithmetic.rotate(value, normalized) if normalized else value)
            weights.append(mask)
            self.counts['rotations'] += bool(normalized)
        result = self.arithmetic.weighted_sum(values, weights)
        self.counts['public_multiplications'] += len(values)
        self.counts['ciphertext_additions'] += len(values)-1
        self.counts['actual_composite_rescales'] += 1
        self.counts['public_multiplication_levels'] += 1
        if self.arithmetic._level(result) != level-1:
            raise RuntimeError('routing stage did not consume exactly one level')
        if result._ckks_nsd != 1 or not math.isclose(
                result._ckks_scale, self.arithmetic.scale, rel_tol=1e-12):
            raise RuntimeError('routing stage returned noncanonical scale/NSD')
        for name in tuple(vars(result)):
            if name.startswith('_public_'):
                delattr(result, name)
        if self.progress is not None:
            self.progress(label, result, dict(self.counts))
        return result

    def forward(self, value, *, gain=1.):
        if (isinstance(gain, (bool, np.bool_)) or not isinstance(gain, numbers.Real)
                or not math.isfinite(float(gain)) or float(gain) not in (1., .125)):
            raise ValueError('supported public score gains are one and one eighth')
        self._validate_ciphertext(value)
        result = self._stage(value, self.layout.head_diagonals(gain=float(gain)), 'head compaction')
        return self._stage(result, self.layout.key_diagonals(), 'key placement')

    def inverse(self, value):
        self._validate_ciphertext(value)
        result = self._stage(value, self.layout.key_diagonals(inverse=True), 'key extraction')
        return self._stage(result, self.layout.head_diagonals(inverse=True), 'head expansion')
