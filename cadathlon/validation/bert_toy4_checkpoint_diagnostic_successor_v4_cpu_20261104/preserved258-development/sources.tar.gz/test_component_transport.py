"""Real bounded NPZ/manifest parsing with synthetic zero residues; never HE."""
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import sys
from types import ModuleType
import zipfile
import numpy as np
import pytest
import component_contract as c
import component_transport as t
def contract():return c.make_contract('a'*64,'b'*32)


def binding():
    scale=c.numerical_plan()['checkpoints'][5]['scale']
    return c.ciphertext_contract(contract(),'response',5,scale,'ab'*32)


def kwargs():
    return dict(contract=contract(),role='response',tile_index=5,expected_scale=binding()['scale'],input_digest='ab'*32)


def arrays():
    b=binding()
    return dict(payload=np.zeros(b['shape'],dtype=np.uint32),moduli=np.array(b['moduli'],dtype=np.int64),
        degree_layout=np.array(b['layout'],dtype=np.int64),precision=np.array(32,dtype=np.int64),
        scale=np.array(b['scale'],dtype=np.float64),nsd=np.array(1,dtype=np.int64))


def pack(values,compressed=False):
    stream=io.BytesIO();(np.savez_compressed if compressed else np.savez)(stream,**values);return stream.getvalue()


def manifest(b):
    return t._manifest_fields(b)|dict(files={'bundle.json':'01'*32,'ct_0.npz':'02'*32})


def write_tile(path,values=None):
    path.mkdir();bundle=b'{"shape":{"__ct__":0},"count":1}'
    raw=pack(arrays() if values is None else values)
    (path/'bundle.json').write_bytes(bundle);(path/'ct_0.npz').write_bytes(raw)
    m=manifest(binding());m['files']={n:hashlib.sha256((path/n).read_bytes()).hexdigest() for n in m['files']}
    (path/'transport.json').write_bytes(c.canonical(m));return m


def test_actual_npz_readback_is_bounded_and_exact(tmp_path):
    path=tmp_path/'tile';m=write_tile(path)
    payload,scale,b,m2=t.validate_ciphertext(path,**kwargs())
    assert payload.shape==binding()['shape'] and payload.dtype==np.uint32 and not payload.any()
    assert scale==binding()['scale'] and b==binding() and m2==m


@pytest.mark.parametrize('mutation',['int_payload','float_payload','big_endian','object','shape','fortran',
    'moduli_value','moduli_dtype','layout_value','layout_dtype','precision_type','precision_value',
    'nsd_bool','nsd_value','scale_int','scale_nan','scale_inf','scale_zero','scale_wrong','scale_rank',
    'extra','missing','compressed','residue_equal_modulus','trailing_array_bytes'])
def test_payload_rejects_malformed_containers(mutation):
    values=arrays();compressed=False
    if mutation=='int_payload':values['payload']=values['payload'].astype(np.int32)
    elif mutation=='float_payload':values['payload']=values['payload'].astype(np.float32)
    elif mutation=='big_endian':values['payload']=values['payload'].astype('>u4')
    elif mutation=='object':values['payload']=np.array([None],dtype=object)
    elif mutation=='shape':values['payload']=values['payload'].reshape(-1)
    elif mutation=='fortran':values['payload']=np.asfortranarray(values['payload'])
    elif mutation=='moduli_value':values['moduli'][0]-=1
    elif mutation=='moduli_dtype':values['moduli']=values['moduli'].astype(np.uint64)
    elif mutation=='layout_value':values['degree_layout']=np.array([512,256],dtype=np.int64)
    elif mutation=='layout_dtype':values['degree_layout']=values['degree_layout'].astype(np.int32)
    elif mutation=='precision_type':values['precision']=np.array(32.)
    elif mutation=='precision_value':values['precision']=np.array(64,dtype=np.int64)
    elif mutation=='nsd_bool':values['nsd']=np.array(True)
    elif mutation=='nsd_value':values['nsd']=np.array(2,dtype=np.int64)
    elif mutation=='scale_int':values['scale']=np.array(int(binding()['scale']),dtype=np.int64)
    elif mutation=='scale_nan':values['scale']=np.array(float('nan'))
    elif mutation=='scale_inf':values['scale']=np.array(float('inf'))
    elif mutation=='scale_zero':values['scale']=np.array(0.)
    elif mutation=='scale_wrong':values['scale']=np.array(np.nextafter(binding()['scale'],np.inf))
    elif mutation=='scale_rank':values['scale']=np.array([binding()['scale']])
    elif mutation=='extra':values['extra']=np.array(1)
    elif mutation=='missing':values.pop('nsd')
    elif mutation=='compressed':compressed=True
    elif mutation=='residue_equal_modulus':values['payload'][0,0,0,0,0]=binding()['moduli'][0]
    raw=pack(values,compressed)
    if mutation=='trailing_array_bytes':
        old=zipfile.ZipFile(io.BytesIO(raw));stream=io.BytesIO()
        with zipfile.ZipFile(stream,'w') as z:
            for n in old.namelist():z.writestr(n,old.read(n)+(b'x' if n=='nsd.npy' else b''))
        old.close();raw=stream.getvalue()
    with pytest.raises(ValueError):t._payload(raw,binding())


@pytest.mark.parametrize('mutation',['duplicate','claimed_huge','unsupported_npy'])
def test_zip_headers_rejected_before_array_allocation(monkeypatch,mutation):
    raw=pack(arrays());old=zipfile.ZipFile(io.BytesIO(raw));stream=io.BytesIO()
    with zipfile.ZipFile(stream,'w') as z:
        for n in old.namelist():
            body=old.read(n)
            if mutation=='claimed_huge' and n=='payload.npy':
                s=io.BytesIO();np.lib.format.write_array_header_1_0(s,dict(descr='<u4',fortran_order=False,shape=(2**45,)));body=s.getvalue()
            if mutation=='unsupported_npy' and n=='nsd.npy':body=body[:6]+b'\x03\x00'+body[8:]
            z.writestr(n,body)
        if mutation=='duplicate':
            with pytest.warns(UserWarning):z.writestr('nsd.npy',old.read('nsd.npy'))
    old.close()
    def forbidden(*a,**k):raise AssertionError('np.load must not run for hostile header')
    monkeypatch.setattr(np,'load',forbidden)
    with pytest.raises(ValueError):t._payload(stream.getvalue(),binding())


@pytest.mark.parametrize('field',list(t._manifest_fields(binding())))
def test_each_manifest_role_field_is_exact(field):
    m=manifest(binding());m[field]=None
    with pytest.raises(ValueError):t._validate_manifest(m,binding())


@pytest.mark.parametrize('mutation',['extra_file','digest','noncanonical','duplicate_json','symlink_tile',
    'symlink_payload','fifo_payload','missing_manifest','bundle_bool_count','bundle_extra','wrong_case','wrong_input'])
def test_real_directory_and_manifest_denials(tmp_path,mutation):
    path=tmp_path/'tile';m=write_tile(path)
    if mutation=='extra_file':(path/'extra').write_text('extra')
    elif mutation=='digest':(path/'bundle.json').write_bytes(b'{}')
    elif mutation=='noncanonical':(path/'transport.json').write_text(json.dumps(m))
    elif mutation=='duplicate_json':(path/'transport.json').write_bytes(c.canonical(m)[:-2]+b',"role":"response"}\n')
    elif mutation=='symlink_tile':
        real=tmp_path/'real';path.rename(real);path.symlink_to(real,target_is_directory=True)
    elif mutation=='symlink_payload':
        payload=path/'ct_0.npz';real=tmp_path/'real.npz';payload.rename(real);payload.symlink_to(real)
    elif mutation=='fifo_payload':(path/'ct_0.npz').unlink();os.mkfifo(path/'ct_0.npz')
    elif mutation=='missing_manifest':(path/'transport.json').unlink()
    elif mutation in ('bundle_bool_count','bundle_extra'):
        v={'shape':{'__ct__':0},'count':True if mutation=='bundle_bool_count' else 1}
        if mutation=='bundle_extra':v['plaintext']=[1]
        (path/'bundle.json').write_bytes(c.canonical(v));m['files']['bundle.json']=hashlib.sha256((path/'bundle.json').read_bytes()).hexdigest();(path/'transport.json').write_bytes(c.canonical(m))
    elif mutation in ('wrong_case','wrong_input'):
        m['case' if mutation=='wrong_case' else 'input_digest']='noncanonical' if mutation=='wrong_case' else 'cd'*32
        (path/'transport.json').write_bytes(c.canonical(m))
    with pytest.raises((ValueError,OSError)):t.validate_ciphertext(path,**kwargs())


def test_one_input_digest_rejects_missing_or_duplicate_lists():
    ms=[manifest(c.ciphertext_contract(contract(),'request',i,None,None)) for i in range(1)]
    good=t.request_digest(ms,contract());assert len(good)==64
    for bad in ([],ms+[ms[0]],tuple(ms),[ms[0],ms[0]]):
        with pytest.raises(ValueError):t.request_digest(bad,contract())
    changed=copy.deepcopy(ms);changed[0]['files']['ct_0.npz']='03'*32
    assert t.request_digest(changed,contract())!=good


class FakePolynomial:
    """Only the transport metadata interface; no encrypted operation exists."""
    def __init__(self):
        self.data=arrays();self.shape=binding()['shape'];self.degree_layout=(256,512)
        self.precision=32;self._ckks_scale=binding()['scale'];self._ckks_nsd=1
    def validate(self):pass
    def get_moduli(self):return self.data['moduli'].tolist()


def install_fake_writer(monkeypatch,writer=None):
    polynomial=ModuleType('jaxite_word');polynomial.Polynomial=FakePolynomial
    bundle=ModuleType('bundle_io')
    def save(ct,path):
        (path/'bundle.json').write_text('{"shape":{"__ct__":0},"count":1}')
        (path/'ct_0.npz').write_bytes(pack(ct.data))
    bundle.save_bundle=writer or save
    monkeypatch.setitem(sys.modules,'jaxite_word',polynomial);monkeypatch.setitem(sys.modules,'bundle_io',bundle)


def test_write_manifest_last_and_readback_with_explicit_fake_writer(monkeypatch,tmp_path):
    install_fake_writer(monkeypatch);path=tmp_path/'tile'
    m=t.save_ciphertext(FakePolynomial(),path,**kwargs())
    assert t.validate_ciphertext(path,**kwargs())[3]==m and set(p.name for p in path.iterdir())==t.FILES
    assert path.stat().st_mode&0o777==0o700 and (path/'transport.json').stat().st_mode&0o777==0o600
    with pytest.raises(FileExistsError):t.save_ciphertext(FakePolynomial(),path,**kwargs())


@pytest.mark.parametrize('field,value',[('precision',32.),('_ckks_nsd',True),('_ckks_scale',1.),('degree_layout',(256.,512))])
def test_writer_rejects_bad_metadata_before_creating_directory(monkeypatch,tmp_path,field,value):
    install_fake_writer(monkeypatch);ct=FakePolynomial();setattr(ct,field,value);path=tmp_path/'tile'
    with pytest.raises(ValueError):t.save_ciphertext(ct,path,**kwargs())
    assert not path.exists()


def test_no_backend_imports():
    assert not any(n in sys.modules for n in ('jax','jaxlib','torch','transformers','safetensors'))
