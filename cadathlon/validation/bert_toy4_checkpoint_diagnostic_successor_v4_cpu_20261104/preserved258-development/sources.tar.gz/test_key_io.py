"""Tiny synthetic key-format/lifetime tests; never invokes real crypto/backend."""
from pathlib import Path
from types import SimpleNamespace
import importlib.util,os,sys
import numpy as np
import pytest
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('toy4_test_keys',os.environ.get('TOY4_KEYS_SOURCE',str(P/'stage/client_keys.py')));k=importlib.util.module_from_spec(spec);spec.loader.exec_module(k)

@pytest.fixture
def owner(tmp_path):
 o=k._OwnedDirectory(tmp_path/'owned')
 try:yield o
 finally:o.close()

def data(owner):
 a=np.arange(8,dtype=np.uint32).reshape(2,4)
 description=k._store(owner,'array.npy',a,a.shape,[257,769]);return a,description

@pytest.mark.parametrize('operation',['store','write','authenticate'])
def test_constructor_failure_releases_every_owned_descriptor(owner,monkeypatch,operation):
 if operation=='authenticate':a,description=data(owner)
 opened=[];realopen=os.open;realdup=os.dup;realclose=os.close
 def trackopen(*args,**kwargs):fd=realopen(*args,**kwargs);opened.append(fd);return fd
 def trackdup(fd):fd=realdup(fd);opened.append(fd);return fd
 def broken(*args,**kwargs):raise OSError('injected fdopen constructor failure')
 monkeypatch.setattr(k.os,'open',trackopen);monkeypatch.setattr(k.os,'dup',trackdup);monkeypatch.setattr(k.os,'fdopen',broken)
 try:
  with pytest.raises(OSError,match='constructor'):
   if operation=='store':k._store(owner,'new.npy',[[1,2],[3,4]],(2,2),[257,769])
   elif operation=='write':k._write(owner,'new.json',{'synthetic':True})
   else:k._authenticate_array(owner.fd,'array.npy',description,a.shape,[257,769])
  leaks=[]
  for fd in opened:
   try:os.fstat(fd)
   except OSError:pass
   else:leaks.append(fd)
  assert not leaks
 finally:
  for fd in opened:
   try:realclose(fd)
   except OSError:pass

@pytest.mark.parametrize('operation',['store','write'])
@pytest.mark.parametrize('cancellation',[KeyboardInterrupt,SystemExit])
def test_cleanup_only_cancellation_after_stream_error_has_priority(owner,monkeypatch,operation,cancellation):
 realfdopen=os.fdopen;realclose=os.close
 class Stream:
  def __init__(self,*a,**kw):self.s=realfdopen(*a,**kw)
  def __getattr__(self,n):return getattr(self.s,n)
  def close(self):self.s.close();raise OSError('first stream cleanup')
 def close(fd):realclose(fd);raise cancellation('later descriptor cancellation')
 with monkeypatch.context()as m:
  m.setattr(k.os,'fdopen',Stream);m.setattr(k.os,'close',close)
  with pytest.raises(cancellation)as caught:
   if operation=='store':k._store(owner,'new.npy',[[1,2],[3,4]],(2,2),[257,769])
   else:k._write(owner,'new.json',{'synthetic':True})
  assert any('first stream' in n for n in caught.value.__notes__)

@pytest.mark.parametrize('cancellation',[KeyboardInterrupt,SystemExit])
def test_body_error_survives_both_cleanup_failures(owner,monkeypatch,cancellation):
 primary=ValueError('real body');realfdopen=os.fdopen;realclose=os.close
 class Stream:
  def __init__(self,*a,**kw):self.s=realfdopen(*a,**kw)
  def __getattr__(self,n):return getattr(self.s,n)
  def close(self):self.s.close();raise OSError('stream cleanup')
 def close(fd):realclose(fd);raise cancellation('fd cleanup')
 def fail(*a,**kw):raise primary
 with monkeypatch.context()as m:
  m.setattr(k.os,'fdopen',Stream);m.setattr(k.os,'close',close);m.setattr(k.np,'save',fail)
  with pytest.raises(ValueError)as caught:k._store(owner,'new.npy',[[1,2],[3,4]],(2,2),[257,769])
  assert caught.value is primary and len(primary.__notes__)==2

@pytest.mark.parametrize('cancellation',[KeyboardInterrupt,SystemExit])
def test_auth_mapping_and_fd_cleanup_attempt_all(owner,monkeypatch,cancellation):
 a,description=data(owner);events=[];realclose=os.close
 class Mapping:
  def __init__(self):self._mmap=SimpleNamespace(close=self.close)
  def close(self):events.append('mapping');raise OSError('mapping cleanup')
  def __getitem__(self,key):return np.zeros(4,dtype=np.uint32)
 def close(fd):events.append('descriptor');realclose(fd);raise cancellation('descriptor cleanup')
 with monkeypatch.context()as m:
  m.setattr(k.np,'memmap',lambda *a,**kw:Mapping());m.setattr(k.os,'close',close)
  with pytest.raises(cancellation)as caught:k._authenticate_array(owner.fd,'array.npy',description,a.shape,[257,769])
  assert events==['mapping','descriptor'] and any('mapping cleanup'in n for n in caught.value.__notes__)

def test_store_auth_roundtrip_modes_and_no_overwrite(owner):
 a,description=data(owner);k._authenticate_array(owner.fd,'array.npy',description,a.shape,[257,769])
 assert (owner.path/'array.npy').stat().st_mode&0o777==0o600
 with pytest.raises(FileExistsError):k._store(owner,'array.npy',a,a.shape,[257,769])
 k._write(owner,'private_manifest.json',{'opaque':True});assert k._read(owner.fd,'private_manifest.json',1024)==k.canonical({'opaque':True})

@pytest.mark.parametrize('bad',[[[257,0],[0,0]],[[0,0],[-1,0]],[[0.,1.],[2.,3.]]])
def test_invalid_residue_or_coercion_rejected_before_file(owner,bad):
 with pytest.raises(ValueError):k._store(owner,'bad.npy',bad,(2,2),[257,769])
 assert not (owner.path/'bad.npy').exists()

def test_real_profile_resource_private_rns_correction():
 p,rotations=k.public_contract((P/'profile.json').read_bytes(),(P/'public_plan/plan.json').read_bytes());r=k.resources(p,rotations)
 assert len(rotations)==199 and p['dnum']==4 and len(p['q_towers'])==100 and len(p['p_towers'])==24
 assert r['private_array_bytes']==52428800 and r['private_required_bytes']==53481472
 assert r['public_array_count']==401


def test_synthetic_generation_security_first_raw_python_secret_preserved(tmp_path,monkeypatch):
 events=[];p=dict(degree=4,num_slots=2,q_towers=[257,769],p_towers=[1153],composite_degree=2,degree_layout=[2,2],precision=32,max_level=0,scaling_factor=16.,dnum=2,batch=1,sigma=3.190000057220458984375,secret_distribution='uniform_ternary')
 secret=[[1,2,3,4],[5,6,7,8]];shape=(2,3,4)
 def switch():return dict(a=np.zeros(shape,dtype=np.uint32),b=np.ones(shape,dtype=np.uint32),modulus={'Q':p['q_towers'],'P':p['p_towers']},P=p['p_towers'],shape=shape)
 class Crypto:
  __file__=__file__
  def gen_pke_pair(self,*a,**kw):events.append('pair');return dict(public_key=np.zeros((2,2,4),dtype=np.uint32),secret_key=secret)
  def gen_evaluation_key(self,s,**kw):
   assert s is secret and all(type(x)is int for row in s for x in row);events.append('relin');return switch()
  def gen_rotation_key(self,s,q,P,index,**kw):
   assert s is secret and all(type(x)is int for row in s for x in row);events.append('rotation');return {index:switch()}
 def security(p):events.append('security');return {'synthetic':True}
 def crypto():events.append('crypto');return Crypto()
 monkeypatch.setattr(k,'public_contract',lambda *a:(p,(1,)));monkeypatch.setattr(k,'_security_check',security);monkeypatch.setattr(k,'_crypto',crypto)
 r=k.generate(tmp_path/'public',tmp_path/'private',profile_bytes=b'synthetic',plan_bytes=b'synthetic')
 assert events[:4]==['security','crypto','pair','relin']and events[4]=='rotation'
 assert r['private_manifest']['secret']['shape']==[2,4]
 assert r['public_manifest']['rotations']==[1] and (tmp_path/'private').stat().st_mode&0o777==0o700
