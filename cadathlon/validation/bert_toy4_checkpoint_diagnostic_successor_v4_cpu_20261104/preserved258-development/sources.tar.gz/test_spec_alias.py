"""Independent actual-CLI admission checks; stop before helpers or backends.

Only copied source_inventory.json is extended for successor test/helper files.
Original candidate files are unchanged; no runtime, asset, payload or backend
work occurs beyond the stdlib source guard and entry admission.
"""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

import pytest


HERE = Path(__file__).resolve().parent
CASES = (
    "file_only", "spec_only", "both_local", "foreign_file_local_spec",
    "local_file_foreign_spec", "file_symlink", "spec_symlink",
    "file_pathlike", "spec_pathlike", "builtin_file_local_spec",
    "local_file_frozen_spec", "critical_no_origin", "critical_foreign",
)


@pytest.fixture(scope="module")
def admitted_tree(tmp_path_factory):
    outer = tmp_path_factory.mktemp("actual-cli-alias")
    root = outer / "source"
    root.mkdir()
    names = set(json.loads((HERE / "source_inventory.json").read_bytes()))
    names.update(path.name for path in HERE.glob("*.py"))
    assert "test_spec_alias.py" in names
    blobs = {name: (HERE / name).read_bytes() for name in sorted(names)}
    # This is the only rewritten member, only in the synthetic execution copy.
    blobs["source_inventory.json"] = (json.dumps(sorted(names), indent=2) + "\n").encode()
    expected = {name: hashlib.sha256(data).hexdigest() for name, data in blobs.items()}
    for name, data in blobs.items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    manifest = outer / "source_manifest.json"
    manifest.write_text(json.dumps(expected, sort_keys=True) + "\n")
    symlink = outer / "external_source_alias"
    symlink.symlink_to(root, target_is_directory=True)
    yield outer, root, manifest, expected, symlink
    assert {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()} == set(expected)
    assert {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in expected} == expected


def invoke(tree, entry, case):
    outer, root, manifest, _, symlink = tree
    marker = outer / (entry + "." + case + ".marker")
    local = repr(str(root / "component_protocol.py"))
    indirect = repr(str(symlink / "component_protocol.py"))
    foreign = repr(str(outer / "unrelated.py"))
    assignments = {
        "file_only": "m.__file__=" + local,
        "spec_only": "m.__spec__=types.SimpleNamespace(origin=" + local + ")",
        "both_local": "m.__file__=" + local + ";m.__spec__=types.SimpleNamespace(origin=" + local + ")",
        "foreign_file_local_spec": "m.__file__=" + foreign + ";m.__spec__=types.SimpleNamespace(origin=" + local + ")",
        "local_file_foreign_spec": "m.__file__=" + local + ";m.__spec__=types.SimpleNamespace(origin=" + foreign + ")",
        "file_symlink": "m.__file__=" + indirect,
        "spec_symlink": "m.__spec__=types.SimpleNamespace(origin=" + indirect + ")",
        "file_pathlike": "m.__file__=Path(" + local + ")",
        "spec_pathlike": "m.__spec__=types.SimpleNamespace(origin=Path(" + local + "))",
        "builtin_file_local_spec": "m.__file__='built-in';m.__spec__=types.SimpleNamespace(origin=" + local + ")",
        "local_file_frozen_spec": "m.__file__=" + local + ";m.__spec__=types.SimpleNamespace(origin='frozen')",
        "critical_no_origin": "pass",
        "critical_foreign": "m.__file__=" + foreign + ";m.__spec__=types.SimpleNamespace(origin=" + foreign + ")",
    }
    name = "component_protocol" if case.startswith("critical_") else "review_unknown_alias"
    setup = "" if case == "clean" else (
        "m=types.ModuleType(" + repr(name) + ")\n" + assignments[case]
        + "\nsys.modules[" + repr(name) + "]=m\n"
    )
    script = """import runpy,sys,types,importlib.abc
from pathlib import Path
""" + setup + """
class StopBeforeHelpers(importlib.abc.MetaPathFinder):
 def find_spec(self, fullname, path=None, target=None):
  if fullname.split('.')[0] in ('jax','jaxlib','jaxite_word','torch','tensorflow','transformers','numpy'):
   raise RuntimeError('review forbids backend import')
  if fullname=='component_protocol':
   Path(""" + repr(str(marker)) + """).write_text('admitted, stopped before first helper')
   raise RuntimeError('review stopped before helper execution')
sys.meta_path.insert(0,StopBeforeHelpers())
sys.argv=sys.argv[1:]
runpy.run_path(sys.argv[0],run_name='__main__')
"""
    command = [sys.executable, "-I", "-B", "-c", script, str(root / entry),
               "--source-manifest", str(manifest), "--source-manifest-sha256",
               hashlib.sha256(manifest.read_bytes()).hexdigest(), "--help"]
    child = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             start_new_session=True,
                             env={"PATH": "/usr/bin:/bin", "HOME": str(outer),
                                  "PYTHONDONTWRITEBYTECODE": "1"})
    try:
        stdout, stderr = child.communicate(timeout=60)
    except BaseException:
        child.kill()
        child.wait()
        raise
    assert child.returncode == 1
    assert not Path("/proc/" + str(child.pid)).exists()
    with pytest.raises(ProcessLookupError):
        os.killpg(child.pid, 0)
    assert b"review forbids backend import" not in stderr
    return marker.exists(), stdout, stderr


@pytest.mark.parametrize("entry", ("collect.py", "component_worker.py"))
@pytest.mark.parametrize("case", CASES)
def test_actual_cli_rejects_each_local_or_critical_origin(admitted_tree, entry, case):
    advanced, _, stderr = invoke(admitted_tree, entry, case)
    assert not advanced
    assert b"helper/runtime preloaded or unknown local alias before source gate" in stderr


@pytest.mark.parametrize("entry", ("collect.py", "component_worker.py"))
def test_clean_cli_reaches_guarded_boundary_without_backend(admitted_tree, entry):
    advanced, _, stderr = invoke(admitted_tree, entry, "clean")
    assert advanced
    assert b"review stopped before helper execution" in stderr
