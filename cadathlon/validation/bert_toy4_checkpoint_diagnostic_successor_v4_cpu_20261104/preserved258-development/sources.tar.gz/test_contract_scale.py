from pathlib import Path
from types import SimpleNamespace
from fractions import Fraction
import ast,math,random,sys
import numpy as np
import pytest
import component_contract as c
import scale_replay as s

HERE=Path(__file__).resolve().parent
COMMON=HERE/'runtime/cadathlon/common'

def test_exact96_roles_and_original_levels():
    contract=c.make_contract('a'*64,'b'*32);plan=c.numerical_plan()
    request=c.ciphertext_contract(contract,'request',0,None,None)
    assert request['level']==49 and request['shape']==(1,2,256,512,100)
    for i,row in enumerate(plan['checkpoints']):
        actual=c.ciphertext_contract(contract,'response',i,row['scale'],'c'*64)
        assert actual['label']==row['label'] and actual['level']==row['level']
        assert actual['moduli']==plan['profile']['q_towers'][:2*(row['level']+1)]
    assert sum(2*131072*2*(row['level']+1)*4 for row in plan['checkpoints'])==3758096384

@pytest.mark.parametrize('bad',[True,1.0,-1,96,'0',None])
def test_typed_index_reject(bad):
    with pytest.raises(ValueError):c.ciphertext_contract(c.make_contract('a'*64,'b'*32),'response',bad,1.,'c'*64)

@pytest.mark.parametrize('key,value',[('output_count',True),('absolute_gate',1e-5),('nonce','x'),('case_sha256','a'*64)])
def test_binding_reject(key,value):
    contract=c.make_contract('a'*64,'b'*32);contract[key]=value
    with pytest.raises(ValueError):c.validate_contract(contract)

@pytest.mark.parametrize('bad',[True,1,0.,-1.,float('nan'),float('inf'),complex(1),None])
def test_bad_scale_reject(bad):
    with pytest.raises(ValueError):s.check_refresh_scale(bad)

def test_exact_refresh_enclosure_boundaries():
    cert=s.refresh_scale_certificate();u=Fraction(1,2**53);T=Fraction(cert['target'])
    products=cert['product_candidates'];lo=T*(1-u)**2;hi=T*(1+u)**2
    assert Fraction(math.nextafter(products[0],-math.inf))<lo<=Fraction(products[0])
    assert Fraction(products[-1])<=hi<Fraction(math.nextafter(products[-1],math.inf))
    assert cert['accepted_scales']==sorted(set(x/cert['divisor']for x in products))
    assert cert['normal_intermediates_proved'] and len(cert['accepted_scales'])==3
    for x in cert['accepted_scales']:assert s.check_refresh_scale(x)==x
    for x in(math.nextafter(min(cert['accepted_scales']),-math.inf),math.nextafter(max(cert['accepted_scales']),math.inf)):
        with pytest.raises(ValueError):s.check_refresh_scale(x)

def actual_weighted_body():
    # Execute the unchanged production weighted_sum body. Primitive doubles
    #supply the exact production metadata expressions extracted independently.
    tree=ast.parse((COMMON/'encrypted_polynomial.py').read_bytes())
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef)and n.name=='EncryptedPolynomialEvaluator')
    method=next(n for n in cls.body if isinstance(n,ast.FunctionDef)and n.name=='weighted_sum')
    ns=dict(np=np,math=math);exec(compile(ast.Module(body=[method],type_ignores=[]),str(COMMON/'encrypted_polynomial.py'),'exec'),ns)
    primitive=ast.parse((COMMON/'encrypted_primitives.py').read_bytes())
    def expr(name):
        cls=next(n for n in primitive.body if isinstance(n,ast.ClassDef)and n.name==name)
        assignments=[n for n in ast.walk(cls)if isinstance(n,ast.Assign)and any(isinstance(t,ast.Attribute)and t.attr=='_ckks_scale'for t in n.targets)]
        assert len(assignments)==1
        return compile(ast.Expression(assignments[0].value),str(COMMON/'encrypted_primitives.py'),'eval')
    mult=expr('CompiledPlaintextMultiply');rescale=expr('CompiledRescale')
    class Driver:
        def __init__(self,level):
            self.scale=c.numerical_plan()['profile']['scale'];self.level=level
            self.ctx=SimpleNamespace(_param_cache=SimpleNamespace(q_moduli_at_level=lambda l:c.numerical_plan()['profile']['q_towers'][:2*(l+1)]))
            self._plaintext_multiply=SimpleNamespace(multiply=lambda value,plaintext,l:SimpleNamespace(_ckks_scale=eval(mult,dict(math=math,float=float,ciphertext_scale=value._ckks_scale,plaintext_scale=plaintext._ckks_scale)),moduli=value.moduli))
            self._rescale=SimpleNamespace(rescale=lambda value,source,target:SimpleNamespace(_ckks_scale=eval(rescale,dict(math=math,value=value,target_moduli=self.ctx._param_cache.q_moduli_at_level(target)))))
        def _public_slots(self,v):return np.asarray([v],dtype=float)
        def _ensure_capacity(self,values,required):return values
        def _level(self,v):return self.level
        def _prepare(self,l):pass
        def _lower(self,v,l):return v
        def _encode_public(self,w,l,scale):return SimpleNamespace(_ckks_scale=scale)
        def _finish(self,v):return v
    return ns['weighted_sum'],Driver

def test_real_weighted_and_primitive_scale_order():
    weighted,Driver=actual_weighted_body();rng=random.Random(41481)
    sources=[sys.float_info.min,sys.float_info.max,math.ulp(0.),c.numerical_plan()['profile']['scale']]
    sources.extend(math.ldexp(rng.uniform(1.,1.99),rng.randrange(-1022,1024))for _ in range(96))
    for level in(1,3,11,26,49):
        driver=Driver(level)
        for scale in sources:
            value=SimpleNamespace(_ckks_scale=scale,moduli=driver.ctx._param_cache.q_moduli_at_level(level))
            try:actual=weighted(driver,[value],[1.])._ckks_scale
            except(ValueError,OverflowError)as error:
                if 'round away' in str(error):
                    assert(driver.scale*s.divisor(level))/scale<.5
                else:
                    with pytest.raises((ValueError,OverflowError)):s.weighted_scale(scale,level)
                continue
            assert actual==s.weighted_scale(scale,level)
            if level==26:assert actual in s.refresh_scale_certificate()['accepted_scales']

def test_all96_replay_uses_actual_five_scales():
    scales=s.refresh_scale_certificate()['accepted_scales'];result=s.client_replay(tuple(scales[i%3]for i in range(5)))
    assert len(result['trace'])==96 and result['original_toy_clear_gate_passed']
    assert [r['scale']for r in result['trace']if r['kind']=='refresh_after']==[scales[i%3]for i in range(5)]
