"""Preflight import/body audit; synthetic fixtures are explicitly permitted."""
import importlib.abc,json,os,sys
from pathlib import Path
ATTEMPTS=[]
class NoBackend(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0]in('jax','jaxlib','jaxite_word','torch','transformers','safetensors','tensorflow','libtpu'):
            ATTEMPTS.append(dict(kind='backend_import',name=fullname));raise RuntimeError('preflight forbids backend/model imports')
        return None
def pytest_sessionstart(session):
    sys.meta_path.insert(0,NoBackend())
    def audit(event,args):
        if event!='open'or not args or not isinstance(args[0],(str,bytes,os.PathLike)):return
        path=Path(os.fsdecode(args[0])).absolute()
        if str(path).startswith('/dev/shm/')or path.suffix=='.safetensors'or'tokenized_'in path.name:
            ATTEMPTS.append(dict(kind='forbidden_body',name=str(path)));raise RuntimeError('preflight forbids actual key/model/private bodies')
    sys.addaudithook(audit)
def pytest_sessionfinish(session,exitstatus):
    destination=os.environ.get('TOY4_PREFLIGHT_AUDIT_PATH')
    if destination:
        Path(destination).write_text(json.dumps(dict(backend_or_private_attempts=ATTEMPTS,zero_forbidden_attempts=not ATTEMPTS,
            scope='Actual import attempts and known key/checkpoint/token paths; public toy fixture and synthetic temporary bodies permitted.'),indent=2)+'\n')
