"""Preserve cleanup provenance across this dedicated process's helper layers.

The marker is private bookkeeping for caught exceptions, not a security token.
A real body failure keeps its identity. With cleanup-only failures, the first
cancellation outranks ordinary failures even after an intermediate helper exits.
"""
ATTRIBUTE='_cross_toy4_cleanup_origin'

def is_cleanup(error):return error is not None and getattr(error,ATTRIBUTE,False)is True

def mark(error):
    setattr(error,ATTRIBUTE,True)
    return error

def select(primary,errors):
    """Select one exception; errors are labeled cleanup operations, in order."""
    rows=[]
    for label,error in errors:
        if error is None or error is primary:continue
        rows.append((label,mark(error)))
    if primary is not None and not is_cleanup(primary):chosen=primary
    else:
        ordered=([('earlier cleanup',primary)]if primary is not None else[])+rows
        if not ordered:return None
        chosen=next((e for _,e in ordered if not isinstance(e,Exception)),ordered[0][1])
    if primary is not None and primary is not chosen:chosen.add_note('earlier cleanup: '+repr(primary))
    for label,error in rows:
        if error is not chosen:chosen.add_note(label+': '+repr(error))
    return chosen
