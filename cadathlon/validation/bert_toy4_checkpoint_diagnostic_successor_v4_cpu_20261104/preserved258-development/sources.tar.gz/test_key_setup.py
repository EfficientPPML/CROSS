"""Synthetic pre-body descriptor ownership regression; no key/backend work."""
import importlib.util,os
from pathlib import Path
import numpy as np
import pytest
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('setup_keys',os.environ.get('TOY4_KEYS_SOURCE',str(P/'stage/client_keys.py')));k=importlib.util.module_from_spec(spec);spec.loader.exec_module(k)

def test_cleanup_state_failure_precedes_auth_descriptor_acquisition(tmp_path,monkeypatch):
 owner=k._OwnedDirectory(tmp_path/'keys');a=np.zeros((2,4),dtype=np.uint32)
 desc=k._store(owner,'array.npy',a,a.shape,[257,769]);opened=[];realopen=os.open;realclose=os.close
 def tracked(*args,**kwargs):fd=realopen(*args,**kwargs);opened.append(fd);return fd
 def fail():raise MemoryError('cleanup state allocation')
 try:
  with monkeypatch.context()as m:
   m.setattr(k.os,'open',tracked);m.setattr(k,'_CloseState',fail)
   with pytest.raises(MemoryError,match='state allocation'):k._authenticate_array(owner.fd,'array.npy',desc,a.shape,[257,769])
  assert opened==[],'descriptor acquired before cleanup ownership setup'
 finally:
  for fd in opened:
   try:realclose(fd)
   except OSError:pass
  owner.close()
