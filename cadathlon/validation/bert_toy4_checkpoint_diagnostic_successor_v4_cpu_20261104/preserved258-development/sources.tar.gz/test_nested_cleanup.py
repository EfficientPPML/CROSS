import os
import pytest
import component_protocol as p
from publication import OwnedOutput

@pytest.mark.parametrize('origin',['public_read','report_read','report_write'])
def test_cleanup_origin_is_not_promoted_to_body_primary(tmp_path,monkeypatch,origin):
    path=tmp_path/'public';path.write_bytes(b'x')
    owner=OwnedOutput(tmp_path/'owned').acquire();report=owner.path/'report.json';owner.write(report,{'passed':False})
    original_close=os.close;calls=[]
    def close(fd):
        original_close(fd);calls.append(fd)
        if len(calls)==1:raise OSError('nested helper cleanup only')
    try:
        with monkeypatch.context()as patch:
            patch.setattr(os,'close',close)
            if origin=='public_read':p.read(path)
            elif origin=='report_read':owner.read(report)
            else:owner.write(report,{'passed':False,'step':2})
    except OSError as primary:
        late=KeyboardInterrupt('later cleanup cancellation')
        final=p.Finalizer(primary)
        final.attempt('later cleanup',lambda:(_ for _ in()).throw(late))
        with pytest.raises(KeyboardInterrupt)as result:final.raise_failure()
        assert result.value is late
    else:raise AssertionError('expected close failure')


def test_genuine_body_primary_keeps_identity(tmp_path,monkeypatch):
    path=tmp_path/'public';path.write_bytes(b'x');body=ValueError('genuine body');original_close=os.close
    def close(fd):original_close(fd);raise OSError('cleanup')
    def fail(*args):raise body
    try:
        with monkeypatch.context()as patch:
            patch.setattr(os,'close',close);patch.setattr(os,'read',fail);p.read(path)
    except ValueError as primary:
        assert primary is body
        final=p.Finalizer(primary);final.attempt('late',lambda:(_ for _ in()).throw(KeyboardInterrupt('late')))
        with pytest.raises(ValueError)as result:final.raise_failure()
        assert result.value is body
    else:raise AssertionError('body failure missing')
