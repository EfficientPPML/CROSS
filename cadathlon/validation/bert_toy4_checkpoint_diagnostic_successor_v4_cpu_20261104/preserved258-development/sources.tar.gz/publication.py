"""Invocation-bound public publication; no ownership inferred after replacement.

Persistent inode identities bind the fresh directory and each published receipt.
Each IO operation independently holds a directory descriptor and checks it
against that original identity before touching files. This is fail-closed
same-process ownership checking, not an OS sandbox or atomic multi-file lock.
"""
from pathlib import Path
import os,stat
import component_protocol as p
from component_transport import _CloseState,_stream

class OwnedOutput:
    def __init__(self,path):
        self.path=Path(path).absolute();self.identity=None;self.files={}
    def acquire(self):
        if self.identity is not None:raise ValueError('output already acquired')
        self.path.mkdir(mode=0o700,exist_ok=False)
        self.identity=p.identity(self.path)
        return self
    def check(self):
        if self.identity is None:raise ValueError('output not acquired by this invocation')
        p.check_identity(self.path,self.identity)
    def _name(self,path):
        path=Path(path).absolute()
        if path.parent!=self.path or path.name in ('','.','..'):raise ValueError('publication outside acquired output')
        self.check();return path.name
    def _file(self,fd,name,*,may_create=False):
        try:s=os.stat(name,dir_fd=fd,follow_symlinks=False)
        except FileNotFoundError:
            if may_create and name not in self.files:return
            raise
        if name not in self.files or not stat.S_ISREG(s.st_mode)or (s.st_dev,s.st_ino)!=self.files[name]:
            raise ValueError('published file replaced or foreign file collision')
    def write(self,path,value):
        name=self._name(path);state=_CloseState();fd=os.open(self.path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
        try:
            held=os.fstat(fd)
            if [held.st_dev,held.st_ino]!=self.identity:raise ValueError('publication directory changed before open')
            self._file(fd,name,may_create=True);raw=p.canonical(value);temporary=name+'.tmp'
            item=os.open(temporary,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=fd)
            try:
                with _stream(item,'wb',state)as stream:stream.write(raw);stream.flush();os.fsync(item)
            finally:state.close(item)
            self.check();self._file(fd,name,may_create=True)
            os.replace(temporary,name,src_dir_fd=fd,dst_dir_fd=fd);s=os.stat(name,dir_fd=fd,follow_symlinks=False)
            self.files[name]=(s.st_dev,s.st_ino);os.fsync(fd);self.check();self._file(fd,name)
        finally:state.close(fd)
    def read(self,path):
        name=self._name(path);state=_CloseState();fd=os.open(self.path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
        try:
            held=os.fstat(fd)
            if [held.st_dev,held.st_ino]!=self.identity:raise ValueError('publication directory changed before read')
            self._file(fd,name)
            item=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=fd)
            try:
                s=os.fstat(item)
                if (s.st_dev,s.st_ino)!=self.files[name]or s.st_size>16<<20:raise ValueError('owned report inode/size differs')
                data=b''
                while len(data)<=16<<20:
                    part=os.read(item,min(1<<20,(16<<20)+1-len(data)))
                    if not part:break
                    data+=part
                after=os.fstat(item)
                if len(data)!=s.st_size or (s.st_size,s.st_mtime_ns,s.st_ctime_ns)!=(after.st_size,after.st_mtime_ns,after.st_ctime_ns):raise ValueError('owned report changed during read')
            finally:state.close(item)
            self.check();self._file(fd,name);return data
        finally:state.close(fd)

def separate(path,protected):
    value=Path(path).absolute()
    for parent in (value,*value.parents):
        if parent.exists()and parent.is_symlink():raise ValueError('output symlink component forbidden')
    value=value.resolve()
    for item in protected:
        if item is None:continue
        other=Path(item).absolute().resolve()
        if value==other or value.is_relative_to(other)or other.is_relative_to(value):raise ValueError('output overlaps protected source/workspace/evidence')
