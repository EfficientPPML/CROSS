"""Measured filesystem capacity and logical payloads; no peak-memory claim."""
from pathlib import Path
import os,shutil
from component_contract import ROOT,numerical_plan
from stage.client_keys import public_contract,resources

def report(parent):
    parent=Path(parent);p,rotations=public_contract((ROOT/'profile.json').read_bytes(),(ROOT/'public_plan/plan.json').read_bytes())
    keys=resources(p,rotations);proof=numerical_plan();usage=shutil.disk_usage(parent)
    # Keys, one input,96 output envelopes, public toy weights and metadata all
    #live beneath this one explicit owned workspace. Original222 secret estimate
    #is superseded only by the separately archived correction, not edited.
    extra=proof['storage']['checkpoint_disk_budget_bytes']+104857600+(64<<20)
    required=keys['public_required_bytes']+keys['private_required_bytes']+extra
    available=None
    for line in Path('/proc/meminfo').read_text().splitlines():
        if line.startswith('MemAvailable:'):available=int(line.split()[1])*1024
    return dict(keys=keys,checkpoint_logical_payload_bytes=3758096384,input_payload_bytes=104857600,
        workspace_required_bytes=required,parent=str(parent.resolve()),filesystem_device=parent.stat().st_dev,
        filesystem_free_bytes=usage.free,filesystem_total_bytes=usage.total,capacity_passed=usage.free>=required,
        host_mem_available_bytes=available,cpu_affinity=sorted(os.sched_getaffinity(0)),
        scope='Preflight logical disk reserves only; excludes JAX/TPU/compiler caches, active temporaries and failure quarantine. No peak-memory guarantee.')
