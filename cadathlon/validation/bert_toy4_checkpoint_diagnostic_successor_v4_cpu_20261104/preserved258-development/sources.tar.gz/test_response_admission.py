"""Independent synthetic response/root-review admission; no retained data or backend."""
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
import copy
import json
import sys
import numpy as np
import pytest
import component_contract as contract
import component_protocol as protocol
import component_transport as transport
import response_admission as admission


@pytest.fixture
def case(tmp_path, monkeypatch):
    workspace = tmp_path / 'workspace'
    workspace.mkdir(mode=0o700)
    workspace.chmod(0o700)
    outputs = workspace / 'outputs'
    outputs.mkdir(mode=0o700)
    outputs.chmod(0o700)
    for index in range(96):
        (outputs / f'tile{index}').mkdir(mode=0o700)
    request = contract.make_contract('a' * 64, 'b' * 32)
    trace = copy.deepcopy(contract.numerical_plan()['checkpoints'])
    manifests = [dict(index=i, synthetic_payload='no ciphertext') for i in range(96)]
    artifacts = [dict(index=i, metadata=copy.deepcopy(row),
                      manifest_sha256=transport.manifest_digest(manifests[i]))
                 for i, row in enumerate(trace)]
    prior = dict(setup=dict(request_contract=request, input_digest='c' * 64),
                 server=dict(artifacts=artifacts, all96_server_outputs_verified=True,
                             source_archive_sha256='d' * 64,
                             arithmetic=dict(refresh_scales=[1.] * 5)))
    expected = {'synthetic_source.py': 'e' * 64}
    config = dict(stage='validate', workspace=str(workspace),
                  workspace_identity=protocol.identity(workspace), nonce='b' * 32,
                  setup_receipt=str(tmp_path / 'setup.json'), setup_sha256='1' * 64,
                  server_receipt=str(tmp_path / 'server.json'), server_sha256='2' * 64,
                  server_root_review=str(tmp_path / 'root-review.json'),
                  server_root_review_sha256=None)
    events = []
    state = SimpleNamespace(workspace=workspace, outputs=outputs, request=request,
                            trace=trace, manifests=manifests, prior=prior, config=config,
                            expected=expected, events=events, fail_at=None,
                            after_auth=None, private_hook=None, changed_manifest=None)
    def sign(review=None):
        value = admission.review_fields(config, expected, prior) if review is None else review
        raw = contract.canonical(value)
        Path(config['server_root_review']).write_bytes(raw)
        config['server_root_review_sha256'] = protocol.sha(raw)
        return value
    state.sign = sign
    sign()
    monkeypatch.setattr(admission, 'client_replay', lambda values: dict(trace=copy.deepcopy(trace)))
    def public_response(path, **kwargs):
        i = kwargs['tile_index']
        assert path == outputs / f'tile{i}' and kwargs['role'] == 'response'
        assert kwargs['contract'] == request and kwargs['input_digest'] == prior['setup']['input_digest']
        assert kwargs['expected_scale'] == trace[i]['scale']
        events.append(('authenticate', i))
        if i == state.fail_at:
            raise ValueError('synthetic public artifact authentication failure')
        if state.after_auth:
            state.after_auth(i)
        return object(), trace[i]['scale'], {}, copy.deepcopy(manifests[i])
    monkeypatch.setattr(transport, 'validate_ciphertext', public_response)
    return state


def invoke(case):
    return admission.authenticate_all(case.config, case.expected, case.prior)


def test_complete96_authentication_returns_exact_order(case):
    result = invoke(case)
    assert case.events == [('authenticate', i) for i in range(96)]
    assert result['all96_current_responses_authenticated_before_private'] is True
    assert result['output_identity'] == protocol.identity(case.outputs)
    assert result['manifest_sha256'] == [x['manifest_sha256'] for x in case.prior['server']['artifacts']]
    assert result['review']['sha256'] == case.config['server_root_review_sha256']


@pytest.mark.parametrize('field,value', [
    ('approved', False), ('approved', 1), ('artifact_count', 95), ('artifact_count', 96.),
    ('stage', 'setup'), ('setup_receipt_sha256', '0' * 64),
    ('server_receipt_sha256', '0' * 64), ('consumer_source_map_sha256', '0' * 64),
    ('server_source_archive_sha256', '0' * 64), ('request_contract_sha256', '0' * 64),
    ('input_digest', '0' * 64), ('ordered_artifacts_sha256', '0' * 64),
    ('workspace_identity', [True, 2]), ('profile_sha256', '0' * 64),
    ('original_source_archive_sha256', '0' * 64), ('numerical_plan_sha256', '0' * 64),
])
def test_exact_root_review_fields_precede_any_payload(case, field, value):
    review = admission.review_fields(case.config, case.expected, case.prior)
    review[field] = value
    case.sign(review)
    with pytest.raises(ValueError, match='root review'):
        invoke(case)
    assert case.events == []


@pytest.mark.parametrize('mutation', ['missing_pin', 'wrong_pin', 'relative', 'missing_file', 'symlink'])
def test_external_review_admission_never_self_authenticates(case, mutation):
    path = Path(case.config['server_root_review'])
    if mutation == 'missing_pin':
        case.config['server_root_review_sha256'] = None
    elif mutation == 'wrong_pin':
        case.config['server_root_review_sha256'] = '0' * 64
    elif mutation == 'relative':
        case.config['server_root_review'] = 'root-review.json'
    elif mutation == 'missing_file':
        path.unlink()
    else:
        target = path.with_name('renamed-review.json')
        path.rename(target)
        path.symlink_to(target)
    with pytest.raises((ValueError, OSError)):
        invoke(case)
    assert case.events == []


@pytest.mark.parametrize('mutation', ['missing', 'extra', 'output_symlink'])
def test_current96_directory_inventory_before_payload(case, mutation):
    if mutation == 'missing':
        (case.outputs / 'tile95').rmdir()
    elif mutation == 'extra':
        (case.outputs / 'unapproved').mkdir()
    else:
        moved = case.outputs.with_name('original-outputs')
        case.outputs.rename(moved)
        case.outputs.symlink_to(moved, target_is_directory=True)
    with pytest.raises((ValueError, OSError)):
        invoke(case)
    assert case.events == []


@pytest.mark.parametrize('mutation', ['index_bool', 'metadata_level_float', 'metadata_scale', 'manifest_digest', 'missing_row', 'server_flag'])
def test_artifact_and_replay_contract_precedes_payload(case, mutation):
    rows = case.prior['server']['artifacts']
    if mutation == 'index_bool': rows[0]['index'] = False
    elif mutation == 'metadata_level_float': rows[0]['metadata']['level'] = float(rows[0]['metadata']['level'])
    elif mutation == 'metadata_scale': rows[0]['metadata']['scale'] *= 2
    elif mutation == 'manifest_digest': rows[0]['manifest_sha256'] = 'invalid'
    elif mutation == 'missing_row': rows.pop()
    else: case.prior['server']['all96_server_outputs_verified'] = 1
    case.sign()
    with pytest.raises(ValueError):
        invoke(case)
    assert case.events == []


@pytest.mark.parametrize('mutation', ['root_review', 'output_replacement'])
def test_mutation_during_public_authentication_rejected(case, mutation):
    def change(index):
        if index != 95: return
        if mutation == 'root_review':
            Path(case.config['server_root_review']).write_bytes(b'{}')
        else:
            case.outputs.rename(case.outputs.with_name('moved-outputs'))
            case.outputs.mkdir(mode=0o700)
    case.after_auth = change
    with pytest.raises(ValueError):
        invoke(case)
    assert len(case.events) == 96


def worker_double(case, monkeypatch, tmp_path):
    import component_worker as worker
    zeros = np.zeros(65536, dtype=np.float64)
    decoded = [zeros] * 96
    references = [zeros] * 96
    fake_root = tmp_path / 'public-source'
    golden = fake_root / 'runtime/cadathlon/agent_pset/p2_bert/test/test4.out'
    golden.parent.mkdir(parents=True)
    golden.write_text(json.dumps({'logits': [[0., 0.], [0., 0.]]}))
    monkeypatch.setattr(worker, 'HERE', fake_root)
    monkeypatch.setattr(worker, 'fixed_files', lambda: (b'synthetic-profile', b'synthetic-plan'))
    monkeypatch.setattr(worker, '_DECODE_FAILURE_QUARANTINE', [])
    def reference():
        case.events.append(('reference',))
        return {}, references
    monkeypatch.setitem(sys.modules, 'fixture_assets', SimpleNamespace(prepare_client_reference=reference))
    class Context:
        def decrypt_slots(self, value):
            case.events.append(('decode', value.index))
            return decoded[value.index]
    @contextmanager
    def loader(*args, **kwargs):
        assert [x for x in case.events if x[0] == 'authenticate'] == [('authenticate', i) for i in range(96)]
        case.events.append(('private',))
        if case.private_hook: case.private_hook()
        yield SimpleNamespace(ctx=Context(), public_manifest={'context_id': case.request['context_id']})
    monkeypatch.setitem(sys.modules, 'key_contexts', SimpleNamespace(load_client=loader))
    def load(path, **kwargs):
        index = kwargs['tile_index']
        case.events.append(('load', index))
        manifest = copy.deepcopy(case.manifests[index])
        if index == case.changed_manifest: manifest['synthetic_payload'] = 'changed after admission'
        return SimpleNamespace(index=index), manifest
    monkeypatch.setattr(transport, 'load_ciphertext', load)
    return worker, decoded, references


@pytest.mark.parametrize('index', [0, 48, 95])
def test_any_public_failure_prevents_private_entry(case, monkeypatch, tmp_path, index):
    worker, _, _ = worker_double(case, monkeypatch, tmp_path)
    case.fail_at = index
    with pytest.raises(ValueError, match='public artifact'):
        worker.validate(case.config, {}, lambda: None, case.prior, expected_sources=case.expected)
    assert case.events == [('authenticate', i) for i in range(index + 1)]


@pytest.mark.parametrize('mutation', ['missing', 'wrong'])
def test_worker_missing_or_wrong_review_prevents_private_entry(case, monkeypatch, tmp_path, mutation):
    worker, _, _ = worker_double(case, monkeypatch, tmp_path)
    case.config['server_root_review_sha256'] = None if mutation == 'missing' else '0' * 64
    with pytest.raises(ValueError):
        worker.validate(case.config, {}, lambda: None, case.prior, expected_sources=case.expected)
    assert case.events == []


def test_worker_authenticates96_before_references_private_and_decode(case, monkeypatch, tmp_path):
    worker, _, _ = worker_double(case, monkeypatch, tmp_path)
    report = {}
    worker.validate(case.config, report, lambda: None, case.prior, expected_sources=case.expected)
    assert case.events[:98] == [('authenticate', i) for i in range(96)] + [('reference',), ('private',)]
    assert [x for x in case.events if x[0] == 'decode'] == [('decode', i) for i in range(96)]
    assert report['numeric_passed'] is True and report['loader_cleanup_completed'] is True
    assert report['all96_current_responses_authenticated_before_private'] is True
    assert all(x['absolute_gate'] == 1e-6 and x['passed'] for x in report['checks'])


@pytest.mark.parametrize('mutation', ['review', 'output_root'])
def test_replacement_after_admission_stops_before_decode(case, monkeypatch, tmp_path, mutation):
    worker, _, _ = worker_double(case, monkeypatch, tmp_path)
    def change():
        if mutation == 'review': Path(case.config['server_root_review']).write_bytes(b'{}')
        else:
            case.outputs.rename(case.outputs.with_name('moved-after-admission'))
            case.outputs.mkdir(mode=0o700)
    case.private_hook = change
    with pytest.raises(ValueError):
        worker.validate(case.config, {}, lambda: None, case.prior, expected_sources=case.expected)
    assert ('private',) in case.events and not any(x[0] in ('load', 'decode') for x in case.events)


@pytest.mark.parametrize('index', [0, 95])
def test_manifest_change_after_admission_is_retained_as_failure(case, monkeypatch, tmp_path, index):
    worker, _, _ = worker_double(case, monkeypatch, tmp_path)
    case.changed_manifest = index
    report = {}
    with pytest.raises(RuntimeError, match='readbacks failed'):
        worker.validate(case.config, report, lambda: None, case.prior, expected_sources=case.expected)
    assert len(report['checks']) == 96 and report['all96_readbacks_attempted'] is True
    assert report['checks'][index]['decoder_passed'] is False
    assert ('decode', index) not in case.events and len(worker._DECODE_FAILURE_QUARANTINE) == 1
    assert report.get('numeric_passed') is not True


@pytest.mark.parametrize('gate', ['all_slot', 'original_final'])
def test_numeric_failure_does_not_relax_original_gates(case, monkeypatch, tmp_path, gate):
    worker, decoded, references = worker_double(case, monkeypatch, tmp_path)
    index = 7 if gate == 'all_slot' else 95
    value = np.zeros(65536, dtype=np.float64)
    value[0] = 2e-6 if gate == 'all_slot' else .03
    decoded[index] = value
    if gate == 'original_final': references[index] = value.copy()
    report = {}
    worker.validate(case.config, report, lambda: None, case.prior, expected_sources=case.expected)
    assert report['numeric_passed'] is False and report['loader_cleanup_completed'] is True
    if gate == 'all_slot':
        assert report['checks'][7]['passed'] is False and report['checks'][7]['absolute_gate'] == 1e-6
        assert report['original_final_toy_gate_passed'] is True
    else:
        assert all(row['passed'] for row in report['checks'])
        assert report['original_final_toy_gate_passed'] is False
