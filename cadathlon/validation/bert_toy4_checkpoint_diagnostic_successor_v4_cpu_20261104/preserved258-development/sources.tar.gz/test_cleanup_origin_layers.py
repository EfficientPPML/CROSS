"""Nested cleanup provenance only; no actual keys, data, backend or HE."""
from contextlib import contextmanager
from pathlib import Path
import sys
import pytest
import cleanup
from cleanup_origin import mark,is_cleanup,select
from component_protocol import Finalizer
from publication import OwnedOutput
from terminal import terminal_scope
from finish import finish
import component_worker as worker
import component_protocol as protocol

@contextmanager
def identity():yield

@pytest.mark.parametrize('kind',[KeyboardInterrupt,SystemExit])
@pytest.mark.parametrize('genuine',[False,True])
def test_signal_scope_keeps_body_but_upgrades_cleanup_only(monkeypatch,kind,genuine):
 first=OSError('inner close')if not genuine else ValueError('body')
 if not genuine:mark(first)
 later=kind('restore');events=[]
 monkeypatch.setattr(cleanup,'_capture_mask',lambda errors:cleanup._MISSING)
 monkeypatch.setattr(cleanup,'_restore',lambda old,mask,errors:errors.append(('restore',later)))
 chosen=first if genuine else later
 try:
  raise first
 except BaseException:
  with pytest.raises(type(chosen))as caught:
   with cleanup.cleanup_signals():events.append('all cleanup attempted');raise first
 assert caught.value is chosen and events==['all cleanup attempted']

@pytest.mark.parametrize('kind',[KeyboardInterrupt,SystemExit])
@pytest.mark.parametrize('genuine',[False,True])
def test_terminal_scope_final_publication_cancellation_precedence(tmp_path,kind,genuine):
 first=ValueError('body')if genuine else mark(OSError('inner close'));later=kind('terminal close');report=dict(passed=True,cleanup_completed=True)
 @contextmanager
 def shield():
  try:yield
  finally:raise later
 chosen=first if genuine else later
 with pytest.raises(type(chosen))as caught:
  with terminal_scope(report,tmp_path/'report.json',lambda *a:None,shield,lambda:(first,None)):raise first
 assert caught.value is chosen and report['passed']is False and report['terminal_scope_completed']is False

@pytest.mark.parametrize('kind',[KeyboardInterrupt,SystemExit])
@pytest.mark.parametrize('genuine',[False,True])
@pytest.mark.parametrize('at',['read','write','outer'])
def test_finish_preserves_cleanup_origin_across_read_write_outer(tmp_path,kind,genuine,at):
 first=ValueError('body')if genuine else mark(OSError('inner close'));later=kind('later cleanup');report=dict(passed=True)
 def call():raise first
 def read(path):
  if at=='read':raise later
  return b'{}'
 def write(path,value):
  report.update(value)
  if at=='write':raise later
 @contextmanager
 def outer():
  try:yield
  except BaseException as error:
   if at=='outer':raise select(error,[('outer restore',later)])
   raise
 chosen=first if genuine else later
 with pytest.raises(type(chosen))as caught:finish(tmp_path/'report.json',call,write,read,termination=outer,shield=identity)
 assert caught.value is chosen and report['passed']is False

@pytest.mark.parametrize('kind',[KeyboardInterrupt,SystemExit])
@pytest.mark.parametrize('genuine',[False,True])
def test_worker_final_readback_retains_nested_origin(tmp_path,monkeypatch,kind,genuine):
 first=ValueError('body')if genuine else mark(OSError('inner IO close'));later=kind('final source cleanup');events=[]
 owner=OwnedOutput(tmp_path/'out').acquire();workspace=tmp_path/'workspace';workspace.mkdir(mode=0o700)
 config=dict(stage='setup',workspace=str(workspace),workspace_identity=protocol.identity(workspace))
 monkeypatch.setattr(protocol,'check_sources',lambda expected:(_ for _ in()).throw(first))
 monkeypatch.setattr(protocol,'sources',lambda:events.append('final sources attempted')or{})
 monkeypatch.setattr(protocol,'hashes',lambda raw:(_ for _ in()).throw(later))
 chosen=first if genuine else later
 with pytest.raises(type(chosen))as caught:worker.run(config,{},owner.path,publication=owner)
 assert caught.value is chosen and events==['final sources attempted']
 assert protocol.parse(owner.read(owner.path/'report.json'))['passed']is False

@pytest.mark.parametrize('family',['transport','keys'])
def test_origin_crosses_independent_close_states(family):
 if family=='transport':from component_transport import _CloseState
 else:from client_keys import _CloseState
 first=OSError('first close');later=KeyboardInterrupt('second close')
 try:
  _CloseState().cleanup('first',lambda:(_ for _ in()).throw(first))
 except OSError as caught:
  assert caught is first and is_cleanup(first)
  with pytest.raises(KeyboardInterrupt)as result:_CloseState().cleanup('second',lambda:(_ for _ in()).throw(later))
  assert result.value is later and is_cleanup(later)

def test_first_cleanup_cancellation_stays_first():
 first=mark(KeyboardInterrupt('first'));second=SystemExit('second');f=Finalizer(first);f.attempt('second',lambda:(_ for _ in()).throw(second))
 with pytest.raises(KeyboardInterrupt)as caught:f.raise_failure()
 assert caught.value is first

@pytest.mark.parametrize('kind',[KeyboardInterrupt,SystemExit])
def test_success_body_close_failure_then_failure_publication_cancel(tmp_path,kind):
 first=mark(OSError('successful publication close'));later=kind('failure publication close');writes=[]
 def call():return dict(passed=True,terminal_scope_completed=True)
 def write(path,value):
  writes.append(dict(value))
  if len(writes)==1:raise first
  raise later
 with pytest.raises(kind)as caught:finish(tmp_path/'report.json',call,write,lambda p:b'{}',termination=identity,shield=identity)
 assert caught.value is later and writes[0]['passed']is True and writes[1]['passed']is False

def test_source_guard_descriptor_failure_is_cleanup_origin(tmp_path,monkeypatch):
 import source_guard,os
 p=tmp_path/'source.py';p.write_bytes(b'public');close=os.close
 def failed(fd):close(fd);raise OSError('source admission descriptor close')
 with monkeypatch.context()as patch:
  patch.setattr(os,'close',failed)
  with pytest.raises(OSError)as caught:source_guard.read(p)
 assert is_cleanup(caught.value)
