"""Fresh-entry source denial tests, never a backend/actual-role invocation."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,types
import pytest
import source_guard as g

ROOT=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def copied(tmp_path):
 tree=tmp_path/'tree';tree.mkdir();names=json.loads((ROOT/'source_inventory.json').read_bytes());pins={}
 for name in names:
  raw=(ROOT/name).read_bytes();p=tree/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);pins[name]=sha(raw)
 raw=(json.dumps(pins,sort_keys=True,separators=(',',':'))+'\n').encode();manifest=tmp_path/'manifest.json';manifest.write_bytes(raw)
 return tree,pins,manifest,sha(raw)

@pytest.mark.parametrize('entry',['collect.py','component_worker.py'])
@pytest.mark.parametrize('mutation',['helper','entry_hash','extra','bytecode','guard','manifest'])
def test_actual_fresh_entry_rejects_before_local_canary(tmp_path,entry,mutation):
 tree,pins,manifest,pin=copied(tmp_path);marker=tmp_path/'canary'
 body=f"from pathlib import Path\nPath({str(marker)!r}).write_text('executed')\nraise RuntimeError('CANARY')\n"
 if mutation=='helper':(tree/'component_protocol.py').write_text(body)
 elif mutation=='entry_hash':pins[entry]='0'*64;raw=json.dumps(pins).encode();manifest.write_bytes(raw);pin=sha(raw)
 elif mutation=='extra':(tree/'unreviewed.py').write_text(body)
 elif mutation=='bytecode':(tree/'__pycache__').mkdir();(tree/'__pycache__/component_protocol.cpython-313.pyc').write_bytes(b'fake')
 elif mutation=='guard':(tree/'source_guard.py').write_text(body)
 else:pin='0'*64
 child=subprocess.Popen([sys.executable,'-I','-B',str(tree/entry),'--source-manifest',str(manifest),'--source-manifest-sha256',pin,'--help'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
 output=child.communicate()[0];assert child.returncode!=0 and not marker.exists(),output.decode()
 with pytest.raises(ProcessLookupError):os.killpg(child.pid,0)
 assert b'CANARY'not in output

@pytest.mark.parametrize('entry',['collect.py','component_worker.py'])
def test_fresh_verified_help_has_no_backend_or_private_execution(tmp_path,entry):
 tree,pins,manifest,pin=copied(tmp_path)
 # A stdlib audit sentinel is installed before executing the unchanged entry.
 wrapper=tmp_path/'audit_entry.py'
 wrapper.write_text("import sys,runpy\ndef audit(event,args):\n if event=='import' and args[0].split('.')[0] in ('jax','jaxlib','jaxite_word','torch','transformers','safetensors'):raise RuntimeError('BACKEND_ATTEMPT')\nsys.addaudithook(audit)\nsys.argv=sys.argv[1:]\nrunpy.run_path(sys.argv[0],run_name='__main__')\n")
 child=subprocess.run([sys.executable,'-I','-B',str(wrapper),str(tree/entry),'--source-manifest',str(manifest),'--source-manifest-sha256',pin,'--help'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 assert child.returncode==0,child.stdout.decode();assert b'BACKEND_ATTEMPT'not in child.stdout

def test_preloaded_local_alias_is_rejected_without_import(tmp_path):
 tree,pins,manifest,pin=copied(tmp_path);module=types.ModuleType('component_protocol');module.__file__=str(tree/'component_protocol.py')
 with pytest.raises(ValueError,match='preloaded'):g.check(pins,tree,modules={'component_protocol':module})

def test_shadow_resolution_is_rejected(tmp_path):
 tree,pins,manifest,pin=copied(tmp_path);raw=b'raise RuntimeError("shadow")\n';name='stage/component_protocol.py'
 (tree/name).write_bytes(raw);pins[name]=sha(raw)
 inventory=sorted(pins);body=json.dumps(inventory).encode();(tree/'source_inventory.json').write_bytes(body);pins['source_inventory.json']=sha(body)
 # Root wins by declared order, so an unused extra local duplicate is still
 #captured but cannot silently replace the resolved root helper.
 report=g.check(pins,tree,modules={});assert report['static_imports']['component_protocol']=='component_protocol.py'
 (tree/'component_protocol.py').unlink()
 with pytest.raises((ValueError,FileNotFoundError)):g.check(pins,tree,modules={})
