"""Tiny loader and phase mocks; no backend, real key, ciphertext or private data."""
from pathlib import Path
from types import SimpleNamespace
import os,sys
import numpy as np
import pytest
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'stage'))
import client_keys as keys
import key_contexts as loaders

@pytest.fixture
def fake_loader(tmp_path,monkeypatch):
    public_dir=tmp_path/'public';private_dir=tmp_path/'private';public_dir.mkdir(mode=0o700);private_dir.mkdir(mode=0o700)
    params=dict(degree=4,num_slots=2,q_towers=[17,41],p_towers=[73],composite_degree=2,degree_layout=[2,2],precision=32,max_level=0,
        scaling_factor=16.,dnum=1,batch=1,sigma=3.190000057220458984375,secret_distribution='uniform_ternary')
    specs=keys.inventory(params,(1,));public=dict(context_id='a'*64,arrays={name:{}for name in specs});private={'secret':{}}
    for folder,names in((public_dir,(*specs,'public_manifest.json')),(private_dir,('secret.npy','private_manifest.json'))):
        for name in names:(folder/name).write_bytes(b'{}');os.chmod(folder/name,0o600)
    quarantine=[];events=[];mapped=[];contexts=[]
    monkeypatch.setattr(loaders,'_FAILURE_QUARANTINE',quarantine)
    monkeypatch.setattr(keys,'public_contract',lambda *a:(params,(1,)));monkeypatch.setattr(keys,'_security_check',lambda p:{})
    monkeypatch.setattr(loaders,'_read_public',lambda *a:(public,specs,b'public'))
    monkeypatch.setattr(loaders,'_read_private',lambda *a:(private,b'private'))
    monkeypatch.setattr(keys,'_read',lambda fd,name,maximum:b'public'if name=='public_manifest.json'else b'private')
    class Array(np.ndarray):pass
    def mapping(owner,name,description,shape,moduli):
        value=np.zeros(shape,dtype=np.uint32).view(Array);value._mmap=SimpleNamespace(closed=False)
        def close():value._mmap.closed=True;events.append('map-close')
        value._mmap.close=close;mapped.append(value)
        return value,loaders._file_state(os.stat(name,dir_fd=owner.fd))
    monkeypatch.setattr(loaders,'_map_array',mapping)
    def original(*a,**kw):return 'original'
    modules={n:SimpleNamespace(__name__=n,**{method:original for method in loaders.KEYGEN_METHODS})for n in('key_gen','jaxite_word.key_gen')}
    class Context:
        def __init__(self,p,**kwargs):
            contexts.append(self);self.parameters=p;self.secret_key=p.get('secret_key');self.public_key=p.get('public_key')
            self.q_towers=p['q_towers'];self.p_towers=p['p_towers'];self.degree_layout=p['degree_layout']
            for module in modules.values():
                for method in loaders.KEYGEN_METHODS:
                    with pytest.raises(RuntimeError):getattr(module,method)()
        def program_initialization(self,rotations,**kwargs):
            self._param_cache=SimpleNamespace(secret_key=None,per_level_rotation_keys=False,raw_rotation_keys=kwargs['pregenerated_rotation_keys'],coef_maps={i:object()for i in rotations})
            for method in loaders.CODEC_METHODS:
                with pytest.raises(RuntimeError):getattr(self,method)()
    for method in loaders.CODEC_METHODS:setattr(Context,method,original)
    runtime=SimpleNamespace(Context=Context,key_modules=modules,jax=SimpleNamespace(numpy=np,clear_caches=lambda:events.append('cache-clear')),
        ckks=SimpleNamespace(evict_context_caches=lambda ctx:events.append('dispose')),polynomial=SimpleNamespace(_POLYNOMIAL_REGISTRY={}))
    monkeypatch.setattr(loaders,'_crypto',lambda:runtime)
    yield SimpleNamespace(public=public_dir,private=private_dir,quarantine=quarantine,events=events,mapped=mapped,contexts=contexts,modules=modules,original=original)
    for a in mapped:
        if not a._mmap.closed:a._mmap.close()
    quarantine.clear()

@pytest.mark.parametrize('server',[False,True])
def test_success_disposes_maps_context_and_restores(fake_loader,server):
    c=fake_loader;cm=loaders.load_server(c.public,profile_bytes=b'',plan_bytes=b'')if server else loaders.load_client(c.public,c.private,profile_bytes=b'',plan_bytes=b'')
    with cm as handle:ctx=handle.ctx
    assert not vars(ctx)and handle.ctx is None and all(a._mmap.closed for a in c.mapped)and not c.quarantine
    assert'dispose'in c.events and all(getattr(m,n)is c.original for m in c.modules.values()for n in loaders.KEYGEN_METHODS)

@pytest.mark.parametrize('server',[False,True])
@pytest.mark.parametrize('failure',[RuntimeError,KeyboardInterrupt,SystemExit])
def test_any_entered_role_failure_keeps_context_and_backings(fake_loader,server,failure):
    c=fake_loader;error=failure('pending result unknown');cm=loaders.load_server(c.public,profile_bytes=b'',plan_bytes=b'')if server else loaders.load_client(c.public,c.private,profile_bytes=b'',plan_bytes=b'')
    with pytest.raises(failure)as caught:
        with cm as handle:ctx=handle.ctx;raise error
    assert caught.value is error and vars(ctx)and handle.ctx is ctx and len(c.quarantine)==1
    assert c.quarantine[0]['context']is ctx and all(not a._mmap.closed for a in c.quarantine[0]['public_mappings'])
    assert'dispose'not in c.events and any('cleanup incomplete'in n for n in error.__notes__)
    with pytest.raises(RuntimeError,match='quarantined'):
        with loaders.load_server(c.public,profile_bytes=b'',plan_bytes=b''):pass
    assert not loaders._ACTIVE.locked()

def test_private_extra_lifecycle_metadata_not_permitted():assert loaders.PRIVATE_OPTIONAL==frozenset()
