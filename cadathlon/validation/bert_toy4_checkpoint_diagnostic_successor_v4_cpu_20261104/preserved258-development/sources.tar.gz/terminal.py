"""Fail closed if the cleanup scope raises after terminal publication."""
from contextlib import contextmanager
from cleanup_origin import mark,select


@contextmanager
def terminal_scope(report,path,write,shield,prior):
    report['terminal_scope_completed']=False
    try:
        with shield():
            yield
        report['terminal_scope_completed']=True
        write(path,report)
    except BaseException as error:
        primary,cleanup_error=prior()
        chosen=select(primary,[('earlier cleanup',cleanup_error),('cleanup scope',error)])
        report['passed']=False
        report['terminal_scope_completed']=False
        if 'cleanup_completed' in report:report['cleanup_completed']=False
        report.setdefault('error',dict(type=type(chosen).__name__,message=str(chosen)))
        report['terminal_failure_republished']=True
        try:
            with shield():
                write(path,report)
        except BaseException as publication:
            chosen=select(chosen,[('failed terminal republication',publication)])
        raise chosen
