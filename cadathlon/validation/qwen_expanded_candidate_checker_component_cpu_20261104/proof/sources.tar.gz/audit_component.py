"""Fresh-process public synthetic tests, with model/data/backend bodies denied."""
from pathlib import Path
import importlib.abc,json,os,sys
P=Path(__file__).resolve().parent
FORBIDDEN={'torch','transformers','jax','jaxlib','jaxite_word','tensorflow','flax','safetensors','tokenizers'}

def main():
    mode,target=sys.argv[1:];target=Path(target);denials=[]
    class NoBackend(importlib.abc.MetaPathFinder):
        def find_spec(self,fullname,path=None,target=None):
            if fullname.split('.')[0]in FORBIDDEN:
                denials.append('backend:'+fullname);raise ImportError('Synthetic component forbids backend imports')
    def audit(event,args):
        reason=None
        if event=='open'and args and isinstance(args[0],(str,bytes,os.PathLike)):
            path=Path(os.fsdecode(args[0])).absolute();resolved=path.resolve()
            if path.suffix in('.safetensors','.parquet','.npy','.npz')or 'tokenized' in path.name or any(str(x).startswith('/home/jianming_gatech/cross_validation_assets/')for x in(path,resolved)):
                reason='input/model body'
        if event.startswith('socket.')and event in('socket.connect','socket.bind','socket.getaddrinfo'):reason='network'
        if reason:denials.append(reason);raise PermissionError('Synthetic component body/network denied')
    sys.meta_path.insert(0,NoBackend());sys.addaudithook(audit)
    if mode=='component':root=P/'component';names=['test_dispatch.py','test_capture.py']
    elif mode=='harness':root=P;names=['test_harness.py']
    else:raise ValueError('Fixed synthetic mode required')
    sys.path.insert(0,str(root));os.chdir(root)
    code=1;error=None
    try:
        import pytest
        code=pytest.main(['-q','-p','no:cacheprovider','--rootdir='+str(root),*names,'--junitxml='+str(target.with_suffix('.xml'))])
    except BaseException as e:error=type(e).__name__;raise
    finally:
        loaded=sorted(n for n in sys.modules if n.split('.')[0]in FORBIDDEN)
        target.write_text(json.dumps(dict(passed=code==0 and not denials and not loaded,returncode=int(code),denied_attempts=denials,backend_modules=loaded,error_type=error,scope='Synthetic only; no actual input/model/candidate execution'),indent=2)+'\n')
    return int(code)
if __name__=='__main__':raise SystemExit(main())
