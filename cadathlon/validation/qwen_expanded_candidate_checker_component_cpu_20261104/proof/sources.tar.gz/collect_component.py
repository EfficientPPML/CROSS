"""Public synthetic provenance checkpoint. No actual checker/model entrypoint."""
from pathlib import Path
import argparse,hashlib,io,json,os,sys,tarfile,time,xml.etree.ElementTree as ET
from component_processes import OwnedChild
from cleanup import cleanup_signals,termination_signals
from cleanup_origin import protect_body,select
from freeze_io import Output,finish as close_operation
P=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def paths(root):return json.loads((root/'inventory.json').read_bytes())['sources']
def hashes(root):return {name:sha(root/name)for name in paths(root)}
def verify_origins(root):
    for name,row in json.loads((root/'origins.json').read_bytes()).items():
        if sha(root/name)!=row['sha256']:raise ValueError('Copied component/helper source differs')
def archive_map(raw):
    found={}
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz')as tar:
        for m in tar:
            if not m.isfile()or m.name in found or Path(m.name).is_absolute()or '..'in Path(m.name).parts:raise ValueError('Exact unique source archive required')
            found[m.name]=hashlib.sha256(tar.extractfile(m).read()).hexdigest()
    return found
def child_ok(row):return type(row.get('direct_returncode'))is int and row['direct_returncode']==0 and all(row.get(n)is True for n in('direct_child_reaped','group_empty_verified','cleanup_completed'))

def collect(destination):
    output=Output(destination) # Acquire before any failure publication scope.
    start=time.monotonic();active=None;logfd=None;primary=None;before=None;execution=None
    report=dict(passed=False,complete=False,children=[],cleanup_completed=False,termination_scope_completed=False,
        actual_candidate_execution=False,model_or_HE_execution=False,
        scope='Pure candidate dispatcher/capture synthetic proof only; strict numerical/domain adapter and actual worker/collector remain unimplemented',
        acceptance_requires_independent_outer_exit0_and_reap=True,pid=os.getpid())
    def attempt(label,fn):
        nonlocal primary
        try:return fn()
        except BaseException as e:primary=select(primary,[(label,e)]);return None
    try:
        with termination_signals():
            try:
                if sorted(os.sched_getaffinity(0))!=[172,173,174,175]:raise ValueError('Declared synthetic affinity172-175 required')
                output.json('started.json',dict(pid=os.getpid(),source_root=str(P),scope=report['scope']))
                verify_origins(P);before=hashes(P);report['source_hashes_before']=before
                execution=Path(output.path)/'execution';execution.mkdir(mode=0o700)
                buf=io.BytesIO()
                with tarfile.open(fileobj=buf,mode='w:gz')as tar:
                    for name in before:
                        raw=(P/name).read_bytes()
                        if hashlib.sha256(raw).hexdigest()!=before[name]:raise ValueError('Source changed before copy')
                        target=execution/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
                        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
                raw=buf.getvalue();output.write('sources.tar.gz',raw)
                if archive_map(raw)!=before or hashes(execution)!=before:raise ValueError('Archive/execution source mismatch')
                report['source_archive_sha256']=hashlib.sha256(raw).hexdigest();report['execution_root']=str(execution)
                report['execution_hashes_before']=hashes(execution);report['tests']={}
                env=dict(os.environ);env.update(PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
                for mode,expected in [('component',79),('harness',7)]:
                    output.check();logfd=os.open(mode+'.log',os.O_CREAT|os.O_EXCL|os.O_WRONLY|os.O_NOFOLLOW,0o600,dir_fd=output.fd)
                    audit=Path(output.path)/(mode+'-audit.json')
                    active=OwnedChild([sys.executable,'-I','-B',str(execution/'audit_component.py'),mode,str(audit)],cwd=execution,stdout=logfd,env=env)
                    report['children'].append(active.record);code=active.wait()
                    if not child_ok(active.record):raise ValueError('Complete direct wait/owned group absence required')
                    active=None;fd,logfd=logfd,None;close_operation(None,lambda:os.close(fd))
                    data=json.loads(audit.read_bytes());suites=ET.parse(audit.with_suffix('.xml')).getroot().iter('testsuite')
                    suites=list(suites);counts={n:sum(int(s.get(n,0))for s in suites)for n in('tests','errors','failures','skipped')}
                    if counts!=dict(tests=expected,errors=0,failures=0,skipped=0)or code!=0 or data['passed']is not True or data['denied_attempts']or data['backend_modules']:raise ValueError('Complete fixed synthetic checks and zero body/backend reads required')
                    report['tests'][mode]=counts
                report['complete']=True
            except BaseException as e:primary=protect_body(e)
            finally:
                with cleanup_signals():
                    if active is not None:attempt('child retirement',lambda:active.close(primary=primary))
                    if logfd is not None:attempt('log close',lambda:os.close(logfd));logfd=None
                    if before is not None:
                        report['source_hashes_after']=attempt('source readback',lambda:hashes(P))
                        report['execution_hashes_after']=attempt('execution readback',lambda:hashes(execution))
                        report['source_files_unchanged']=before==report['source_hashes_after']==report['execution_hashes_after']
                    attempt('output identity',output.check)
                    report['cleanup_completed']=primary is None and all(child_ok(row)for row in report['children'])
        report['termination_scope_completed']=True
    except BaseException as e:primary=select(primary,[('outer scope',e)])
    finally:
        report['elapsed_s']=time.monotonic()-start;report['cpu_affinity']=sorted(os.sched_getaffinity(0))
        report['passed']=primary is None and report['complete']and report['cleanup_completed']and report['termination_scope_completed']and report.get('source_files_unchanged')is True and len(report['children'])==2
        if primary is not None:report['error_type']=type(primary).__name__
        try:
            with cleanup_signals():output.json('report.json',report)
        except BaseException as e:primary=select(primary,[('terminal publication',e)])
        attempt('output close',lambda:output.close(primary=primary))
    if primary is not None:raise primary
    return report
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',required=True);args=parser.parse_args();r=collect(args.output)
    print(json.dumps(dict(passed=r['passed'],tests=r['tests'],sources=len(r['source_hashes_before']),archive=r['source_archive_sha256'])))
    return 0 if r['passed']else 1
if __name__=='__main__':raise SystemExit(main())
