"""Synthetic NumPy tensor/module doubles. No torch, model or real asset access."""
from types import SimpleNamespace
import numpy as np
import pytest
import capture_base
from native_capture import NativeCaptureWithInputs
from ranges import ObservationError,InvalidInput

class Tensor:
 def __init__(self,data,dtype=np.float32):self.data=np.array(data,dtype=dtype,copy=True);self.dtype=self.data.dtype;self.device=SimpleNamespace(type='cpu')
 @property
 def shape(self):return self.data.shape
 @property
 def ndim(self):return self.data.ndim
 def __getitem__(self,key):return Tensor(self.data[key],self.dtype)
 def detach(self):return self
 def cpu(self):return self
 def numpy(self):return self.data
 def float(self):return Tensor(self.data)
 def pow(self,n):return Tensor(self.data**n)
 def mean(self,axis,keepdim=False):return Tensor(self.data.mean(axis=axis,keepdims=keepdim))
 def transpose(self,a,b):return Tensor(self.data.swapaxes(a,b))
 def reshape(self,*shape):return Tensor(self.data.reshape(*shape))
 def __add__(self,x):return Tensor(self.data+x)
 def __mul__(self,x):return Tensor(self.data*x)

class Handle:
 def __init__(self,hooks,hook,state):self.hooks=hooks;self.hook=hook;self.state=state;self.error=None
 def remove(self):
  self.hooks.remove(self.hook);self.state.removed.append(self)
  if self.error is not None:raise self.error

class Target:
 def __init__(self,state):self.state=state;self.pre=[];self.post=[];self.variance_epsilon=1e-6
 def register(self,hook,hooks):
  self.state.calls+=1
  if self.state.calls==self.state.fail:raise self.state.error
  hooks.append(hook);handle=Handle(hooks,hook,self.state);self.state.handles.append(handle);return handle
 def register_forward_pre_hook(self,hook):return self.register(hook,self.pre)
 def register_forward_hook(self,hook):return self.register(hook,self.post)
 def emit(self,value,result=None):
  if result is None:result=value
  for hook in tuple(self.pre):assert hook(self,(value,))is None
  for hook in tuple(self.post):assert hook(self,(value,),result)is None
  return result

@pytest.fixture
def backend(monkeypatch):
 state=SimpleNamespace(calls=0,fail=None,error=ValueError('install'),handles=[],removed=[]);layers=[]
 for i in range(28):
  layer=Target(state);layer.input_layernorm=Target(state);layer.post_attention_layernorm=Target(state)
  layer.self_attn=SimpleNamespace(layer_idx=i,training=False,num_key_value_groups=2,**{n:Target(state)for n in ('q_norm','k_norm','q_proj','k_proj','v_proj','o_proj')})
  layer.mlp=SimpleNamespace(**{n:Target(state)for n in ('act_fn','gate_proj','up_proj','down_proj')});layers.append(layer)
 model=SimpleNamespace(training=False,model=SimpleNamespace(layers=layers,norm=Target(state)));calls=[];returns=[]
 def original(module,q,k,v,mask,scale,dropout,**kwargs):
  calls.append((module,q,k,v,mask,scale,dropout,kwargs));result=(q.transpose(1,2),object());returns.append(result);return result
 module=SimpleNamespace(eager_attention_forward=original,repeat_kv=lambda x,n:Tensor(np.repeat(x.data,n,axis=1)))
 torch=SimpleNamespace(Tensor=Tensor,float32=np.dtype(np.float32),matmul=lambda a,b:Tensor(a.data@b.data))
 monkeypatch.setattr(capture_base,'_native_dependencies',lambda:(torch,module));return model,state,module,original,calls,returns

def emit(model,module,S):
 x=Tensor(np.arange(S*4).reshape(1,S,4)/10+1);q=Tensor(np.arange(S*8).reshape(1,S,2,4)/20+.1);k=Tensor(np.arange(S*4).reshape(1,S,1,4)/20+.2)
 mask=Tensor(np.where(np.tril(np.ones((S,S),bool)),0.,-np.inf)[None,None]);sent=[]
 for i,layer in enumerate(model.model.layers):
  layer.input_layernorm.emit(x,Tensor(x.data+100));layer.post_attention_layernorm.emit(x,Tensor(x.data+200))
  layer.self_attn.q_norm.emit(q,Tensor(q.data+3));layer.self_attn.k_norm.emit(k,Tensor(k.data+4))
  for n in ('q_proj','k_proj','v_proj','o_proj'):getattr(layer.self_attn,n).emit(x)
  for n in ('gate_proj','up_proj','act_fn','down_proj'):getattr(layer.mlp,n).emit(x)
  sent.append(module.eager_attention_forward(layer.self_attn,q.transpose(1,2),k.transpose(1,2),k.transpose(1,2),mask,.5,0.,unchanged=True))
  layer.emit(x,(Tensor(x.data+i),))
 model.model.norm.emit(x,Tensor(x.data+300));return x,q,k,sent

@pytest.mark.parametrize('S',[1,3,32])
def test_single_wrapper421_outputs113_variances28_blocks_and_original_return(backend,S):
 model,state,module,original,calls,returns=backend
 with NativeCaptureWithInputs(model)as capture:
  _,_,_,inactive=emit(model,module,S);assert not capture.operators and not capture.book.ranges
  capture.begin(S);x,q,k,actual=emit(model,module,S);result=capture.end()
  assert len(result['operators'])==421 and len(result['blocks'])==28
  assert result['inputs']['norm_input_sites']==113 and result['inputs']['silu_gate_sites']==28
  assert len(calls)==56 and all(actual[i]is returns[28+i]for i in range(28))
  assert all(row[-1]=={'unchanged':True}for row in calls)
  # Distinct variance INPUT and learned-weight output namespaces.
  expected=float(np.float32(np.mean(x.data[0,0]**2)+np.float32(1e-6)))
  assert result['inputs']['ranges']['0.input.inverse_sqrt']['minimum']==expected
  np.testing.assert_array_equal(result['operators']['0.input.inverse_sqrt'],x.data.astype(float)+100)
  np.testing.assert_array_equal(result['operators']['0.q.inverse_sqrt'],np.float32(q.data+3).swapaxes(1,2).astype(float))
  np.testing.assert_array_equal(result['operators']['final.inverse_sqrt'],np.float32(x.data[:,-1]+300).astype(float))
  assert result['inputs']['ranges']['final.inverse_sqrt']['count']==1
  assert result['inputs']['score_rows']['0']['1']['centered']['maximum']==0.
  assert not capture.operators and not capture.blocks
 assert module.eager_attention_forward is original and len(state.removed)==len(state.handles)

@pytest.mark.parametrize('fail',[1,3,50,500])
def test_partial_input_or_output_registration_restores_all_handles(backend,fail):
 model,state,module,original,*_=backend;state.fail=fail
 with pytest.raises(ValueError,match='install'):NativeCaptureWithInputs(model).__enter__()
 assert module.eager_attention_forward is original and len(state.removed)==len(state.handles)

@pytest.mark.parametrize('later',[KeyboardInterrupt,SystemExit])
def test_sticky_body_cleanup_preserved_and_all_removal_attempted(backend,later):
 model,state,module,original,*_=backend;primary=ValueError('body')
 with pytest.raises(ValueError)as caught:
  with NativeCaptureWithInputs(model)as capture:
   capture.begin(1);state.handles[0].error=primary;state.handles[1].error=later('remove');raise primary
 assert caught.value is primary and module.eager_attention_forward is original and len(state.removed)==len(state.handles)
 assert capture._failed and capture._failed_captures
 with pytest.raises(ValueError):capture.__enter__()

@pytest.mark.parametrize('label',['_expanded_native_observer','_strict_native_capture','_expanded_candidate_capture'])
def test_competing_existing_wrapper_rejected_before_install(backend,label):
 model,state,module,original,*_=backend;setattr(original,label,True)
 with pytest.raises(ValueError,match='Competing'):NativeCaptureWithInputs(model).__enter__()
 assert state.calls==0

def test_our_wrapper_rejects_nested_old_observer_too(backend):
 model,state,module,original,*_=backend
 with NativeCaptureWithInputs(model):
  before=state.calls
  with pytest.raises(ValueError,match='Nested'):capture_base.NativeObserver(model).__enter__()
  assert state.calls==before

def test_saved_remove_accessor_and_incomplete_capture(backend):
 model,state,module,original,*_=backend
 with NativeCaptureWithInputs(model)as capture:
  state.handles[0].remove=lambda:(_ for _ in()).throw(AssertionError('replacement called'))
  capture.begin(1)
  with pytest.raises(ObservationError,match='Incomplete'):capture.end()
 assert len(state.removed)==len(state.handles)

def test_nonfinite_input_stops_before_output_capture(backend):
 model,state,module,original,*_=backend
 with NativeCaptureWithInputs(model)as capture:
  capture.begin(1)
  with pytest.raises(InvalidInput):model.model.layers[0].input_layernorm.emit(Tensor([[[np.nan]*4]]))
  assert capture.operators=={}
  partial=capture.abort();assert partial['invalid']and not partial['complete']
