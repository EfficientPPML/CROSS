"""Synthetic full ledger; no real calibration/context body or model execution."""
import json
import pytest
import candidate_dispatch as c
from workload import Native,Exact,InvalidObservation

def calibration():
 full=list(range(1000,1032));rows=[]
 for p in range(96):
  for length in range(1,33):rows.append(dict(prompt_ordinal=p,id=f'fixture{p}',sequence_length=length,token_ids=full[:length],original_prefill_member=length in (8,16,32)))
 return dict(prefills=rows,decode_seeds=[dict(seed_ordinal=s,prompt_ordinal=s,id=f'fixture{s}',token_ids=full[:16])for s in range(16)])

def adapters(events,*,choice=7,fail=None,numeric=None,comparison=None):
 def native(prefix,entry):
  events.append(('native',prefix,entry.index))
  if comparison and comparison(entry):raise InvalidObservation('PRIVATE detail')
  return Native(7)
 def exact(prefix,entry,n):events.append(('exact',prefix,entry.index));return Exact(n.token,True)
 def candidate(prefix,entry):
  events.append(('candidate',prefix,entry.index))
  if fail and fail(entry):raise c.CandidateStop('PRIVATE candidate detail')
  return c.Candidate(choice,True,not(numeric and numeric(entry)),True,421,28,151936)
 return dict(native=native,exact=exact,candidate=candidate)

def run(**kw):
 events=[];r=c.run_candidate(calibration(),manifest_sha256='a'*64,**adapters(events,**kw));return r,events

def terminal(r):
 return dict(manifest_sha256=r.manifest_sha256,complete=True,source_verified=True,assets_verified=True,cleanup_completed=True,signal_restoration_completed=True,child_reaped=True,child_group_absent=True,returncode=0 if r.public_report()['passed']else 1)

def test_complete3200_and_unchanged_aggregates():
 r,events=run();p=r.public_report();assert len(events)==9600 and p['passed']and p['ledger_complete']and p['trajectories_complete']
 assert p['original416_members']==416 and p['complete_free_sequences']==16
 assert p['by_kind']['prefill']['top1_matches']==3072 and p['by_kind']['teacher']['top1_matches']==64
 assert [e[0]for e in events[:3]]==['native','exact','candidate']
 for start in range(0,len(events),3):assert len({x[1]for x in events[start:start+3]})==1

def test_own_candidate_free_trace_not_initial_generator_or_teacher():
 r,events=run(choice=11)
 for seed in range(16):
  for step in range(4):
   assert r.records[3072+4*seed+step].prefix[-step:]==(7,)*step if step else True
   assert r.records[3136+4*seed+step].prefix[-step:]==(11,)*step if step else True
 assert r.public_report()['complete_free_sequences']==0 and not r.public_report()['passed']

@pytest.mark.parametrize('step',[0,1,2,3])
def test_finite_numeric_failure_keeps_actual_candidate_suffix(step):
 r,events=run(choice=11,numeric=lambda e:e.kind=='free'and e.seed_ordinal==0 and e.step==step)
 rows=r.records[3136:3140];assert all(x.status=='complete'for x in rows)and rows[-1].prefix[-3:]==(11,11,11)
 assert not rows[step].candidate.numeric_pass and r.public_report()['revision_eligible_ledger']

@pytest.mark.parametrize('kind',['teacher','free','prefill'])
@pytest.mark.parametrize('step',[0,2])
def test_candidate_domain_stop_preserves_denominators_and_teacher_continues(kind,step):
 match=lambda e:e.kind==kind and(e.seed_ordinal==0 and e.step==step if kind!='prefill'else e.index==step)
 r,events=run(fail=match);p=r.public_report();assert len(r.records)==3200 and p['ledger_complete']and not p['passed']
 assert p['by_kind'][kind]['candidate_invalid']==1 and p['revision_eligible_ledger']
 suffix=3-step if kind=='free'else 0;assert p['by_kind'][kind]['unmeasured']==suffix
 if kind=='teacher':assert all(x.prefix is not None for x in r.records[3072:3076])and r.records[3075].prefix[-3:]==(7,7,7)
 r.require_revision(terminal(r));public=json.dumps(p);assert 'PRIVATE'not in public and 'prefix'not in public

@pytest.mark.parametrize('kind',['prefill','teacher','free'])
def test_invalid_native_exact_comparison_never_authorizes_revision(kind):
 r,_=run(comparison=lambda e:e.kind==kind and(e.index==0 if kind=='prefill'else e.seed_ordinal==0 and e.step==1))
 assert r.public_report()['ledger_complete']and not r.public_report()['revision_eligible_ledger']
 with pytest.raises(ValueError):r.require_revision(terminal(r))

@pytest.mark.parametrize('field',['complete','source_verified','assets_verified','cleanup_completed','signal_restoration_completed','child_reaped','child_group_absent','returncode'])
def test_incomplete_terminal_cannot_authorize_revision(field):
 r,_=run(choice=11);receipt=terminal(r);receipt[field]=False if field!='returncode'else 0
 with pytest.raises(ValueError):r.require_revision(receipt)

def test_budget_maximum_three_and_pass_freezes_before_validation():
 budget=c.AttemptBudget()
 for i,pin in enumerate(('a'*64,'b'*64,'c'*64)):
  budget.admit(pin,previous_terminal=None if i==0 else receipt)
  base,_=run(choice=11);r=c.Result(pin,base.records);receipt=terminal(r);budget.complete(r,receipt)
 with pytest.raises(ValueError):budget.admit('d'*64,previous_terminal=receipt)
 b=c.AttemptBudget();b.admit('a'*64);r,_=run();b.complete(r,terminal(r));assert b.frozen=='a'*64
 with pytest.raises(ValueError):b.admit('b'*64)

def test_active_interrupted_attempt_cannot_reset_budget():
 b=c.AttemptBudget();b.admit('a'*64)
 with pytest.raises(ValueError):b.admit('b'*64)
 r,_=run();short=c.Result('a'*64,r.records[:-1])
 with pytest.raises(ValueError):b.complete(short,terminal(r))
 assert b.manifests==['a'*64]and b.active=='a'*64

@pytest.mark.parametrize('bad',[c.Candidate(True,True,True,True,421,28,151936),c.Candidate(7,True,True,True,420,28,151936),c.Candidate(7,False,False,False,1,0,0),c.Candidate(None,False,True,False,1,0,0),c.Candidate(7,True,1,True,421,28,151936)])
def test_strict_candidate_adapter_contract(bad):
 with pytest.raises(ValueError):c.checked(bad)

@pytest.mark.parametrize('error',[KeyboardInterrupt,SystemExit,RuntimeError,MemoryError])
def test_infrastructure_failures_escape_no_complete_ledger(error):
 def native(*args):raise error('failure')
 with pytest.raises(error):c.run_candidate(calibration(),manifest_sha256='a'*64,native=native,exact=None,candidate=None)
