"""Synthetic preparation forbids importing an actual model/HE backend."""
import sys,importlib.abc
class Forbidden(importlib.abc.MetaPathFinder):
 def find_spec(self,name,path=None,target=None):
  if name.split('.')[0]in('torch','transformers','jax','jaxlib','jaxite_word','safetensors','tokenizers'):raise AssertionError('Synthetic checker preparation forbids backend '+name)
sys.meta_path.insert(0,Forbidden())
