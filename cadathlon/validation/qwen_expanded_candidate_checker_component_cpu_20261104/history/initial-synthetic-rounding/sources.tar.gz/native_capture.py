"""Single native eager wrapper for input statistics plus actual output metrics.

No model loader or forward is supplied here. Native tensors remain unchanged;
float64 output copies and scalar statistics are transient client observations.
"""
import numpy as np
import math
import capture_base as base
from ranges import ObservationError

PARTS=('input.inverse_sqrt','post.inverse_sqrt','q.inverse_sqrt','k.inverse_sqrt','q_linear','k_linear','v_linear','q_rope','k_rope','gqa','output_linear','gate_linear','up_linear','silu','gated_mlp')

class NativeCaptureWithInputs(base.NativeObserver):
    def __init__(self,model):
        super().__init__(model)
        self.required=frozenset(f'{i}.{part}'for i in range(28)for part in PARTS)|{'final.inverse_sqrt'}
        self.operators={};self.blocks={};self._failed_captures=[]

    def _store(self,label,value):
        self._check_binding()
        if label not in self.required or label in self.operators:raise ObservationError('Unknown or duplicate native output')
        result=self._array(value)
        if result.size==0 or not np.isfinite(result).all():raise ObservationError('Finite nonempty native output required')
        self.operators[label]=result

    def _output(self,label,target,transform=None):
        def hook(module,args,result):
            if not self.active:return None
            if module is not target:raise ObservationError('Native output target changed')
            self._store(label,transform(result)if transform else result)
            return None
        return hook

    def _register_output(self,target,hook):
        handle=target.register_forward_hook(hook)
        self._handles.append((handle,None))
        self._handles[-1]=(handle,handle.remove)

    def _scores(self,attention_module,query,key,value,attention_mask,scaling,dropout):
        self._check_binding()
        if id(attention_module)not in self._targets or attention_module.training or dropout!=0:
            raise ObservationError('Owned eager evaluation attention required')
        for tensor in (query,key,value):self._tensor(tensor)
        if any(x.ndim!=4 or x.shape[0]!=1 for x in (query,key,value)):raise ObservationError('Batch1 full-prefix native attention required')
        sequence=self.book.sequence_length
        if any(x.shape[-2]!=sequence for x in (query,key,value)):raise ObservationError('Cached native attention is unsupported')
        if isinstance(scaling,bool)or not math.isfinite(float(scaling))or float(scaling)<=0:raise ObservationError('Positive finite native scaling required')
        if sequence>1 and attention_mask is None:raise ObservationError('Native causal mask required')
        if attention_mask is not None:
            mask=self._tensor(attention_mask)[:,:,:,:sequence].detach().cpu().numpy()
            shape=(1,query.shape[1],sequence,sequence);expanded=np.broadcast_to(mask,shape)
            allowed=np.broadcast_to(np.tril(np.ones((sequence,sequence),dtype=bool)),shape)
            if not np.array_equal(expanded==0,allowed)or np.any(~allowed&~((expanded==np.finfo(np.float32).min)|np.isneginf(expanded))):
                raise ObservationError('Native mask differs from unpadded causal contract')
        index=self._targets[id(attention_module)]
        self._store(f'{index}.q_rope',query);self._store(f'{index}.k_rope',key)
        repeated=self._module.repeat_kv(key,attention_module.num_key_value_groups)
        scores=(self._torch.matmul(query,repeated.transpose(2,3))*scaling).detach().cpu().numpy()
        for q in range(sequence):
            row=scores[...,q,:q+1]
            self.book.observe(f'{index}.softmax.raw_valid',row)
            self.book.observe(f'{index}.softmax.centered',row-row.mean(axis=-1,keepdims=True))
        return index

    def __enter__(self):
        if self.entered or self._failed:raise ValueError('Native capture entered or cleanup incomplete')
        torch,module=base._native_dependencies();original=module.eager_attention_forward
        if any(getattr(original,flag,False)for flag in ('_expanded_native_observer','_strict_native_capture','_expanded_candidate_capture')):
            raise ValueError('Competing native eager wrappers forbidden')
        self._torch,self._module,self._original=torch,module,original;self.entered=True
        try:
            for index,layer in enumerate(self.layers):
                if type(layer.self_attn.layer_idx)is not int or layer.self_attn.layer_idx!=index:raise ObservationError('Native layer order differs')
                for part,target in (('input',layer.input_layernorm),('post',layer.post_attention_layernorm),('q',layer.self_attn.q_norm),('k',layer.self_attn.k_norm)):
                    label=f'{index}.{part}.inverse_sqrt';self._register(target,self._norm_hook(label,target))
                    def head(value):
                        if value.ndim!=4:raise ObservationError('Native Q/K output layout differs')
                        return value.transpose(1,2)
                    self._register_output(target,self._output(label,target,head if part in ('q','k')else None))
                gate=layer.mlp.act_fn;self._register(gate,self._silu_hook(f'{index}.silu',gate))
                for label,target in (('q_linear',layer.self_attn.q_proj),('k_linear',layer.self_attn.k_proj),('v_linear',layer.self_attn.v_proj),('output_linear',layer.self_attn.o_proj),('gate_linear',layer.mlp.gate_proj),('up_linear',layer.mlp.up_proj),('silu',gate),('gated_mlp',layer.mlp.down_proj)):
                    self._register_output(target,self._output(f'{index}.{label}',target))
                def block(module,args,result,index=index,target=layer):
                    if not self.active:return None
                    self._check_binding()
                    if module is not target or index in self.blocks or not isinstance(result,tuple)or not result:raise ObservationError('Native block output differs')
                    copied=self._array(result[0])
                    if not copied.size or not np.isfinite(copied).all():raise ObservationError('Finite native block output required')
                    self.blocks[index]=copied
                    return None
                self._register_output(layer,block)
            norm=self.model.model.norm;self._register(norm,self._norm_hook('final.inverse_sqrt',norm,last=True))
            def last(value):
                if value.ndim!=3:raise ObservationError('Native final norm output layout differs')
                return value[:,-1]
            self._register_output(norm,self._output('final.inverse_sqrt',norm,last))
            def attention(attention_module,query,key,value,attention_mask,scaling,dropout=0.,**kwargs):
                if self.active:index=self._scores(attention_module,query,key,value,attention_mask,scaling,dropout)
                result=original(attention_module,query,key,value,attention_mask,scaling,dropout,**kwargs)
                if self.active:
                    if not isinstance(result,tuple)or not result:raise ObservationError('Native eager return tuple required')
                    attended=result[0]
                    if attended.ndim!=4 or attended.shape[:2]!=(query.shape[0],query.shape[-2]):raise ObservationError('Native attended B,S,H,D required')
                    self._store(f'{index}.gqa',attended.reshape(attended.shape[0],attended.shape[1],-1))
                return result
            attention._expanded_candidate_capture=True;attention._strict_native_capture=True;attention._expanded_native_observer=True
            self._wrapper=attention;module.eager_attention_forward=attention
            return self
        except BaseException as error:self._restore(error);raise

    def begin(self,sequence_length):
        super().begin(sequence_length)
        self.operators={};self.blocks={}

    def end(self):
        if not self.active:raise ObservationError('Native context inactive')
        try:
            self._check_binding()
            if set(self.operators)!=self.required or set(self.blocks)!=set(range(28)):raise ObservationError('Incomplete421-output/28-block capture')
            observed=self.book.end()
            result=dict(operators=dict(self.operators),blocks=[self.blocks[i]for i in range(28)],inputs=observed)
            self.operators={};self.blocks={}
            return result
        finally:self.active=False;self.book.active=False

    def abort(self):
        partial=super().abort()
        self._failed_captures.append((self.operators,self.blocks));self.operators={};self.blocks={}
        return partial

    def _restore(self,primary=None):
        if primary is not None:self._failed_captures.append((self.operators,self.blocks))
        try:return super()._restore(primary)
        finally:self.operators={};self.blocks={}
