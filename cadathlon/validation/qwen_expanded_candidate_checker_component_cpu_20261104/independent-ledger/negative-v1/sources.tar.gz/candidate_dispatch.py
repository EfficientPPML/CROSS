"""Pure3200-entry candidate ledger. No files, model imports or source admission.

Authenticated runtime adapters supply actual same-prefix measurements. This
module neither supplies intermediate arrays nor evaluates/fits a polynomial.
"""
from dataclasses import dataclass
import re
from workload import Entry,Native,Exact,InvalidObservation,validate_calibration,workload,_prediction

class CandidateStop(ValueError):
    """Observed candidate-only domain/nonfinite stop before the invalid operator."""

@dataclass(frozen=True)
class Candidate:
    token:int|None
    complete:bool
    numeric_pass:bool
    domain_pass:bool
    operators:int
    blocks:int
    logits:int

@dataclass(frozen=True)
class Record:
    entry:Entry
    prefix:tuple|None
    status:str
    native:Native|None=None
    exact:Exact|None=None
    candidate:Candidate|None=None
    failed_stage:str|None=None
    failure:str|None=None


def digest(value):
    if type(value)is not str or re.fullmatch('[0-9a-f]{64}',value)is None:raise ValueError('Exact manifest SHA256 required')
    return value


def checked(value):
    if type(value)is not Candidate:raise ValueError('Exact candidate adapter result required')
    if any(type(getattr(value,n))is not bool for n in ('complete','numeric_pass','domain_pass')):raise ValueError('Exact candidate boolean required')
    for name,maximum in (('operators',421),('blocks',28),('logits',151936)):
        count=getattr(value,name)
        if type(count)is not int or not 0<=count<=maximum:raise ValueError('Exact bounded metric count required')
    if value.complete:
        if type(value.token)is not int or not 0<=value.token<151936:raise ValueError('Actual complete candidate argmax required')
        if (value.operators,value.blocks,value.logits)!=(421,28,151936)or not value.domain_pass:raise ValueError('Complete candidate capture/domain inventory required')
    elif value.token is not None or value.numeric_pass or value.domain_pass:
        raise ValueError('Stopped candidate cannot supply a token or passing gates')
    return value


@dataclass(frozen=True)
class Result:
    manifest_sha256:str
    records:tuple

    def public_report(self):
        ordered=tuple(r.entry for r in self.records)==workload()
        kinds={}
        for kind,total in (('prefill',3072),('teacher',64),('free',64)):
            rows=[r for r in self.records if r.entry.kind==kind]
            kinds[kind]=dict(expected=total,records=len(rows),complete=sum(r.status=='complete'for r in rows),
                candidate_invalid=sum(r.status=='candidate_invalid'for r in rows),comparison_invalid=sum(r.status=='comparison_invalid'for r in rows),
                unmeasured=sum(r.status=='unmeasured_suffix'for r in rows),
                top1_matches=sum(r.native is not None and r.candidate is not None and r.candidate.complete and r.native.token==r.candidate.token for r in rows),
                top1_denominator=total)
        sequences=0
        for seed in range(16):
            teacher=[r for r in self.records if r.entry.kind=='teacher'and r.entry.seed_ordinal==seed]
            free=[r for r in self.records if r.entry.kind=='free'and r.entry.seed_ordinal==seed]
            trusted=(len(teacher)==len(free)==4 and all(r.native is not None and r.exact is not None and r.exact.semantic_pass and r.exact.token==r.native.token for r in teacher))
            complete=all(r.status=='complete'and r.candidate is not None and r.candidate.complete for r in free)
            sequences+=int(trusted and complete and [r.native.token for r in teacher]==[r.candidate.token for r in free])
        all_complete=ordered and all(r.status=='complete'for r in self.records)
        all_gates=all_complete and all(r.candidate.numeric_pass and r.candidate.domain_pass and r.exact.semantic_pass and r.exact.token==r.native.token for r in self.records)
        gates=dict(all_numeric_semantic_domains=all_gates,prefill_top1=kinds['prefill']['top1_matches']>=2765,
            teacher_top1=kinds['teacher']['top1_matches']>=58,complete_free_sequences=sequences>=12)
        passed=ordered and all(gates.values())
        comparison_failed=any(r.status=='comparison_invalid'for r in self.records)
        return dict(schema='expanded-candidate-ledger-v1',manifest_sha256=self.manifest_sha256,expected_entries=3200,retained_entries=len(self.records),
            ledger_complete=ordered,trajectories_complete=all_complete,by_kind=kinds,complete_free_sequences=sequences,complete_free_denominator=16,
            gates=gates,passed=passed,revision_eligible_ledger=bool(ordered and not passed and not comparison_failed),
            original416_members=sum(r.entry.original416_member for r in self.records),contains_tokens_logits_or_failure_text=False)

    def require_terminal(self,terminal):
        # External authentication is the runtime's obligation. Here enforce the
        # exact already-authenticated receipt contract; never infer it from logs.
        required={'manifest_sha256','complete','source_verified','assets_verified','cleanup_completed','signal_restoration_completed','child_reaped','child_group_absent','returncode'}
        if type(terminal)is not dict or set(terminal)!=required or terminal['manifest_sha256']!=self.manifest_sha256:
            raise ValueError('Exact bound failed-attempt terminal receipt required')
        if any(terminal[n]is not True for n in required-{'manifest_sha256','returncode'})or type(terminal['returncode'])is not int or terminal['returncode']!=(0 if self.public_report()['passed']else 1):
            raise ValueError('Complete failed-attempt retirement/provenance required')

    def require_revision(self,terminal):
        self.require_terminal(terminal)
        if not self.public_report()['revision_eligible_ledger']:raise ValueError('Ledger cannot authorize candidate revision')


def run_candidate(calibration,*,manifest_sha256,native,exact,candidate):
    manifest_sha256=digest(manifest_sha256)
    prefills,seeds=validate_calibration(calibration);records=[];chains={};stopped=set()
    for entry in workload():
        key=(entry.kind,entry.seed_ordinal)
        if entry.kind!='prefill'and key in stopped:
            records.append(Record(entry,None,'unmeasured_suffix'));continue
        prefix=prefills[entry.index]if entry.kind=='prefill'else chains.get(key,seeds[entry.seed_ordinal])
        if len(prefix)!=entry.length:raise AssertionError('Internal candidate prefix length differs')
        n=e=c=None;stage='native'
        try:
            n=_prediction(native(prefix,entry),Native);stage='exact'
            e=_prediction(exact(prefix,entry,n),Exact)
            if not e.semantic_pass or e.token!=n.token:raise InvalidObservation('Native/exact semantic failure')
        except InvalidObservation as error:
            records.append(Record(entry,prefix,'comparison_invalid',n,e,None,stage,str(error)))
            if entry.kind!='prefill':stopped.add(key)
            continue
        try:
            c=checked(candidate(prefix,entry))
            if not c.complete:raise CandidateStop('Candidate domain/nonfinite stop')
        except CandidateStop as error:
            records.append(Record(entry,prefix,'candidate_invalid',n,e,c,'candidate',str(error)))
            if entry.kind=='free':stopped.add(key)
            elif entry.kind=='teacher':chains[key]=prefix+(n.token,)
            continue
        records.append(Record(entry,prefix,'complete',n,e,c))
        if entry.kind!='prefill':chains[key]=prefix+((n.token if entry.kind=='teacher'else c.token),)
    return Result(manifest_sha256,tuple(records))


class AttemptBudget:
    """Pure admission state; callers must authenticate manifests/receipts first."""
    def __init__(self):self.manifests=[];self.active=None;self.frozen=None;self.previous=None
    def admit(self,pin,*,previous_terminal=None):
        digest(pin)
        if self.active is not None or self.frozen is not None or len(self.manifests)>=3 or pin in self.manifests:raise ValueError('No new candidate admission allowed')
        if self.previous is not None:self.previous.require_revision(previous_terminal)
        elif previous_terminal is not None:raise ValueError('First candidate cannot use a prior attempt')
        self.manifests.append(pin);self.active=pin
    def complete(self,result,terminal):
        if type(result)is not Result or result.manifest_sha256!=self.active or not result.public_report()['ledger_complete']:raise ValueError('Exact complete ordered active ledger required')
        result.require_terminal(terminal)
        self.previous=result;self.active=None
        if result.public_report()['passed']:self.frozen=result.manifest_sha256
