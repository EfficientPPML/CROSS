from dataclasses import replace
import pytest
import candidate_dispatch as c
from workload import workload,Native,Exact

def terminal(result):
 return dict(manifest_sha256=result.manifest_sha256,complete=True,source_verified=True,assets_verified=True,cleanup_completed=True,signal_restoration_completed=True,child_reaped=True,child_group_absent=True,returncode=1)

@pytest.mark.parametrize("status",["unmeasured_suffix","unknown_status"])
def test_empty_evidence_ledger_cannot_consume_complete_attempt(status):
 result=c.Result("a"*64,tuple(c.Record(entry,None,status)for entry in workload()))
 budget=c.AttemptBudget();budget.admit("a"*64)
 with pytest.raises(ValueError):budget.complete(result,terminal(result))

def test_legitimate_complete_numeric_failure_control():
 records=tuple(c.Record(entry,(7,)*entry.length,"complete",Native(7),Exact(7,True),c.Candidate(7,True,False,True,421,28,151936))for entry in workload())
 result=c.Result("a"*64,records);budget=c.AttemptBudget();budget.admit("a"*64)
 budget.complete(result,terminal(result));assert result.public_report()["revision_eligible_ledger"]
