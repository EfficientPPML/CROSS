"""Pure expanded-prefix initial-observer dispatcher. No filesystem or backend IO.

Adapters are supplied only by a separately source-frozen, authorized observer.
This module does not load inputs, models, manifests, or historical outcomes.
Private records deliberately retain tokens; public_report never serializes them.
"""
from dataclasses import dataclass

BASELINE_MANIFEST_SHA256 = '7f6478a6bc710f3d2a370198e075e6ba8b0e55c144d981bca0eed59eaf176333'
VOCABULARY = 151936


@dataclass(frozen=True)
class Entry:
    index: int
    kind: str
    prompt_ordinal: int | None
    seed_ordinal: int | None
    step: int | None
    length: int
    original416_member: bool


def workload():
    out = []
    for prompt in range(96):
        for length in range(1, 33):
            out.append(Entry(len(out), 'prefill', prompt, None, None, length,
                             length in (8, 16, 32)))
    for kind in ('teacher', 'free'):
        for seed in range(16):
            for step in range(4):
                out.append(Entry(len(out), kind, None, seed, step, 16 + step, True))
    return tuple(out)


class InvalidObservation(ValueError):
    """A declared invalid input, nonfinite value, or stopped circuit.

The adapter must raise BEFORE evaluating the invalid nonlinear operator.
Its label is private diagnostic data and is never placed in public_report.
"""


@dataclass(frozen=True)
class Native:
    token: int


@dataclass(frozen=True)
class Exact:
    token: int
    semantic_pass: bool


@dataclass(frozen=True)
class Baseline:
    token: int
    domain_pass: bool


@dataclass(frozen=True)
class PrivateRecord:
    entry: Entry
    prefix: tuple | None
    status: str
    native: Native | None = None
    exact: Exact | None = None
    baseline: Baseline | None = None
    failed_stage: str | None = None
    failure: str | None = None


@dataclass(frozen=True)
class InitialResult:
    records: tuple
    baseline_manifest_sha256: str = BASELINE_MANIFEST_SHA256

    def public_report(self):
        """Aggregate counts only: never prefixes, choices, logits or exception text."""
        records = self.records
        by_kind = {}
        for kind, expected in (('prefill', 3072), ('teacher', 64), ('free', 64)):
            rows = [r for r in records if r.entry.kind == kind]
            by_kind[kind] = dict(expected=expected, records=len(rows),
                observed=sum(r.prefix is not None for r in rows),
                complete=sum(r.status == 'complete' for r in rows),
                invalid=sum(r.status == 'invalid' for r in rows),
                unmeasured=sum(r.status == 'unmeasured_suffix' for r in rows),
                semantic_failures=sum(r.exact is not None and
                    (not r.exact.semantic_pass or r.native is None or r.exact.token != r.native.token)
                    for r in rows))
        exact_order = tuple(r.entry for r in records) == workload()
        complete = exact_order and all(r.status == 'complete' for r in records)
        return dict(schema='qwen-expanded-initial-observer-ledger-v1',
            expected_entries=3200, retained_entries=len(records), exact_order=exact_order,
            original416_members=sum(r.entry.original416_member for r in records),
            by_kind=by_kind,
            prefills_by_length={str(n):sum(r.entry.kind == 'prefill' and r.entry.length == n
                                           for r in records) for n in range(1, 33)},
            baseline_manifest_sha256=self.baseline_manifest_sha256,
            baseline_role='initial_free_trace_generator_only',
            new_protocol_candidates_used=0,
            baseline_ranges_in_initial_selection=False,
            complete=complete, initial_selection_admissible=complete,
            contains_tokens_or_logits=False)

    def require_initial_selection(self):
        if not self.public_report()['initial_selection_admissible']:
            raise ValueError('Complete ordered native/exact3200 and baseline64 required')


def _tokens(value, length):
    if type(value) is not list or len(value) != length or any(
            type(x) is not int or not 0 <= x < VOCABULARY for x in value):
        raise ValueError('Exact vocabulary-token list and declared length required')
    return tuple(value)


def validate_calibration(calibration):
    """Check the frozen tokenizer output's schema/order without deduplication."""
    if type(calibration) is not dict or set(calibration) != {'prefills', 'decode_seeds'}:
        raise ValueError('Exact calibration-only schema required')
    rows, seeds = calibration['prefills'], calibration['decode_seeds']
    if type(rows) is not list or len(rows) != 3072 or type(seeds) is not list or len(seeds) != 16:
        raise ValueError('Exact3072 prefills and16 seeds required')
    ids, prefixes, full = [], [], []
    for p in range(96):
        name = None
        current = []
        for length in range(1, 33):
            row = rows[p*32 + length-1]
            if type(row) is not dict or set(row) != {
                    'prompt_ordinal', 'id', 'sequence_length', 'token_ids', 'original_prefill_member'}:
                raise ValueError('Prefill fields differ')
            if (type(row['prompt_ordinal']) is not int or row['prompt_ordinal'] != p or
                type(row['sequence_length']) is not int or row['sequence_length'] != length or
                type(row['original_prefill_member']) is not bool or
                row['original_prefill_member'] is not (length in (8,16,32)) or
                type(row['id']) is not str or not row['id']):
                raise ValueError('Prefill ordinal/length/membership differs')
            if name is None: name = row['id']
            if row['id'] != name: raise ValueError('Prompt ID changed within prefix family')
            current.append(_tokens(row['token_ids'], length))
        if any(value != current[-1][:len(value)] for value in current):
            raise ValueError('Append-only prefill family differs')
        ids.append(name); prefixes.extend(current); full.append(current[-1])
    if len(set(ids)) != 96: raise ValueError('Original prompt IDs must be unique')
    seed_prefixes, seen = [], set()
    for s, row in enumerate(seeds):
        if type(row) is not dict or set(row) != {'seed_ordinal','prompt_ordinal','id','token_ids'}:
            raise ValueError('Seed fields differ')
        p = row['prompt_ordinal']
        if (type(row['seed_ordinal']) is not int or row['seed_ordinal'] != s or
                type(p) is not int or not 0 <= p < 96 or p in seen or row['id'] != ids[p]):
            raise ValueError('Original seed mapping differs')
        values = _tokens(row['token_ids'], 16)
        if values != full[p][:16]: raise ValueError('Seed must be original S16 prefix')
        seen.add(p); seed_prefixes.append(values)
    return tuple(prefixes), tuple(seed_prefixes)


def _prediction(value, cls):
    if type(value) is not cls or type(value.token) is not int or not 0 <= value.token < VOCABULARY:
        raise ValueError('Exact adapter result and valid argmax token required')
    for name in ('semantic_pass', 'domain_pass'):
        if hasattr(value, name) and type(getattr(value, name)) is not bool:
            raise ValueError('Exact boolean adapter gate required')
    return value


def run_initial(calibration, *, native, exact, baseline,
                baseline_manifest_sha256=BASELINE_MANIFEST_SHA256):
    """Run ordered slots with tuple prefixes and separate opaque adapters.

native(prefix, entry)->Native; exact(prefix, entry, native)->Exact;
baseline(prefix, entry)->Baseline. These adapters own their transient arrays
and separately tagged range accumulation. This dispatcher supplies no model
outputs to any other path and performs no coefficient selection.
"""
    if type(baseline_manifest_sha256) is not str or baseline_manifest_sha256 != BASELINE_MANIFEST_SHA256:
        raise ValueError('Initial generator must be exact frozen candidate3')
    prefills, seeds = validate_calibration(calibration)
    records, chains, stopped = [], {}, set()
    for entry in workload():
        key = (entry.kind, entry.seed_ordinal)
        if entry.kind != 'prefill' and key in stopped:
            records.append(PrivateRecord(entry, None, 'unmeasured_suffix'))
            continue
        prefix = prefills[entry.index] if entry.kind == 'prefill' else chains.get(key, seeds[entry.seed_ordinal])
        if len(prefix) != entry.length: raise AssertionError('Internal dispatch length mismatch')
        n = e = b = None
        stage = 'native'
        try:
            n = _prediction(native(prefix, entry), Native)
            stage = 'exact'
            e = _prediction(exact(prefix, entry, n), Exact)
            if not e.semantic_pass or e.token != n.token:
                raise InvalidObservation('Native/exact semantic gate failed')
            if entry.kind == 'free':
                stage = 'baseline'
                b = _prediction(baseline(prefix, entry), Baseline)
                if not b.domain_pass:
                    raise InvalidObservation('Frozen baseline domain gate failed')
        except InvalidObservation as error:
            records.append(PrivateRecord(entry,prefix,'invalid',n,e,b,stage,str(error)))
            if entry.kind != 'prefill': stopped.add(key)
            continue
        records.append(PrivateRecord(entry,prefix,'complete',n,e,b))
        if entry.kind != 'prefill':
            chains[key] = prefix + ((n.token if entry.kind == 'teacher' else b.token),)
    return InitialResult(tuple(records), baseline_manifest_sha256)
