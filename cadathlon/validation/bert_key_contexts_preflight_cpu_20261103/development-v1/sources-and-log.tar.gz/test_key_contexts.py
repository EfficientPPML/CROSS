"""Tiny mocked keys/contexts only: no real keygen, initialization or HE."""
from pathlib import Path
from types import SimpleNamespace
import json,os,stat,subprocess,sys
import numpy as np
import pytest
import key_contexts as loaders
import client_keys as keys
from test_client_keys import mocked,generate,PROFILE,RAW_PLAN

@pytest.fixture
def case(mocked,monkeypatch):
    m=mocked;generated=generate(m);events=[];contexts=[];converted=[]
    def original(*a,**kw):return 'original'
    modules={name:SimpleNamespace(__name__=name,**{n:original for n in loaders.KEYGEN_METHODS}) for name in ('key_gen','jaxite_word.key_gen')}
    class Context:
        def __init__(self,parameters,**kw):
            events.append('construct');contexts.append(self)
            for module in modules.values():
                for name in loaders.KEYGEN_METHODS:
                    with pytest.raises(RuntimeError):getattr(module,name)()
            self.parameters=parameters;self.secret_key=parameters.get('secret_key');self.public_key=parameters.get('public_key');self.evaluation_key=parameters.get('evaluation_key')
            self.q_towers=parameters['q_towers'];self.p_towers=parameters['p_towers'];self.degree_layout=parameters['degree_layout']
        def program_initialization(self,rotations,**kw):
            events.append('initialize');assert self.secret_key is None and self.public_key is None
            for name in loaders.CODEC_METHODS:
                with pytest.raises(RuntimeError):getattr(self,name)()
            self._param_cache=SimpleNamespace(secret_key=None,per_level_rotation_keys=False,raw_rotation_keys=kw['pregenerated_rotation_keys'],coef_maps={i:object() for i in rotations})
    for name in (*loaders.CODEC_METHODS,'encode','encode_at_level'):setattr(Context,name,original)
    def asarray(a,**kw):converted.append(a);return np.array(a,copy=True,**kw)
    def evict(ctx):events.append('evict');assert ctx.__dict__;return 0
    def clear():events.append('clear')
    runtime=SimpleNamespace(Context=Context,key_modules=modules,jax=SimpleNamespace(numpy=SimpleNamespace(asarray=asarray),clear_caches=clear),ckks=SimpleNamespace(evict_context_caches=evict),polynomial=SimpleNamespace(_POLYNOMIAL_REGISTRY={}))
    def crypto():events.append('crypto');return runtime
    monkeypatch.setattr(loaders,'_crypto',crypto)
    return SimpleNamespace(m=m,generated=generated,runtime=runtime,modules=modules,events=events,contexts=contexts,converted=converted,original=original)

def client(c):return loaders.load_client(c.m.public,c.m.private,profile_bytes=PROFILE,plan_bytes=RAW_PLAN)
def server(c):return loaders.load_server(c.m.public,profile_bytes=PROFILE,plan_bytes=RAW_PLAN)

def assert_restored(c):
    assert all(getattr(m,n)is c.original for m in c.modules.values() for n in loaders.KEYGEN_METHODS)
    assert all(getattr(c.runtime.Context,n)is c.original for n in loaders.CODEC_METHODS)
    assert not loaders._ACTIVE.locked()


def test_backend_free_import():
    subprocess.run([sys.executable,'-c','import key_contexts,sys; assert not any(n in sys.modules for n in ("jax","torch","jaxite_word"))'],cwd=Path(loaders.__file__).parent,check=True)


def test_server_guards_before_setup_no_secret_mapping_and_no_store_copy(case):
    c=case
    with server(c) as h:
        ctx=h.ctx;assert not hasattr(h,'private_manifest') and ctx.secret_key is None and ctx.public_key is None
        mapped=[entry[part] for entry in ctx._param_cache.raw_rotation_keys.values() for part in ('a','b')]
        assert all(isinstance(a,np.memmap) and not a.flags.writeable for a in mapped)
        assert len(c.converted)==2 and all(a.shape==(1,3,4) for a in c.converted)
        assert ctx.encode()=='original' and ctx.encode_at_level()=='original'
        for name in loaders.CODEC_METHODS:
            with pytest.raises(RuntimeError):getattr(ctx,name)()
        assert c.events[:3]==['crypto','construct','initialize']
    assert h.ctx is None and not vars(ctx) and all(a._mmap.closed for a in mapped)
    assert c.events[-2:]==['evict','clear'];assert_restored(c)


def test_client_reopens_with_known_metadata_and_no_server_setup(case):
    c=case
    for n in loaders.PRIVATE_OPTIONAL:
        (c.m.private/n).write_text('{}');os.chmod(c.m.private/n,0o600)
    for _ in range(2):
        with client(c) as h:
            ctx=h.ctx;secret=ctx.secret_key;public=ctx.public_key
            assert isinstance(secret,np.memmap) and isinstance(public,np.memmap)
            assert not hasattr(ctx,'_param_cache') and h.private_manifest==c.generated['private_manifest']
            assert ctx.encrypt_slots()=='original' and ctx.decrypt_slots()=='original'
        assert h.ctx is None and not vars(ctx) and secret._mmap.closed and public._mmap.closed
        assert_restored(c)
    assert 'initialize' not in c.events and not c.converted

@pytest.mark.parametrize('name',('secret.npy','private_manifest.json'))
def test_server_never_opens_private_files(case,monkeypatch,name):
    original=loaders.os.open
    def guarded(path,*a,**kw):
        if str(path)==name or str(path)==str(case.m.private):raise AssertionError('private path access')
        return original(path,*a,**kw)
    monkeypatch.setattr(loaders.os,'open',guarded)
    with server(case):pass

@pytest.mark.parametrize('bad',('unknown','symlink_optional','fifo_optional','private_mode','secret_mode','manifest_mode','private_binding'))
def test_private_fail_closed_before_context(case,bad):
    c=case
    if bad=='unknown':(c.m.private/'unexpected').write_text('x')
    elif bad=='symlink_optional':(c.m.private/'requests.json').symlink_to(c.m.private/'secret.npy')
    elif bad=='fifo_optional':os.mkfifo(c.m.private/'completed.json',0o600)
    elif bad=='private_mode':os.chmod(c.m.private,0o755)
    elif bad=='secret_mode':os.chmod(c.m.private/'secret.npy',0o644)
    elif bad=='manifest_mode':os.chmod(c.m.private/'private_manifest.json',0o644)
    else:
        p=c.m.private/'private_manifest.json';m=keys._json(p.read_bytes());m['context_id']='a'*64;p.write_bytes(keys.canonical(m))
    with pytest.raises((ValueError,OSError)): 
        with client(c):pass
    assert 'crypto' not in c.events;assert_restored(c)

@pytest.mark.parametrize('bad',('security','profile','missing_key','unexpected','key_hash','key_residue','key_shape','key_fifo','key_symlink','runtime_mode'))
def test_public_fail_closed_before_context(case,monkeypatch,bad):
    c=case;p=c.m.public/'rot_2_a.npy'
    if bad=='security':
        monkeypatch.setattr(keys,'_security_check',lambda p:(_ for _ in ()).throw(ValueError('security')))
    elif bad=='profile':
        monkeypatch.setattr(keys,'public_contract',lambda p,r:(_ for _ in ()).throw(ValueError('profile')))
    elif bad=='missing_key':p.unlink()
    elif bad=='unexpected':(c.m.public/'secret.npy').write_bytes(b'no')
    elif bad=='runtime_mode':monkeypatch.setenv('CROSS_SKIP_TOPLEVEL_ROTKEYS','1')
    elif bad=='key_fifo':p.unlink();os.mkfifo(p)
    elif bad=='key_symlink':p.rename(c.m.public/'actual');p.symlink_to(c.m.public/'actual')
    else:
        array=np.zeros((1,3,4),dtype=np.uint32)
        if bad=='key_residue':array[0,0,0]=17
        if bad=='key_shape':array=array[:,:,:3]
        np.save(p,array)
        if bad!='key_hash':
            manifest=keys._json((c.m.public/'public_manifest.json').read_bytes());manifest['arrays'][p.name]['sha256']=keys.hashlib.sha256(p.read_bytes()).hexdigest();manifest['arrays'][p.name]['bytes']=p.stat().st_size
            body={k:v for k,v in manifest.items() if k!='context_id'};manifest['context_id']=keys.digest(body);(c.m.public/'public_manifest.json').write_bytes(keys.canonical(manifest))
        else:
            with p.open('r+b') as f:f.seek(-1,2);f.write(b'1')
    with pytest.raises((ValueError,OSError)):
        with server(c):pass
    assert 'crypto' not in c.events;assert_restored(c)

@pytest.mark.parametrize('error',(RuntimeError('stage failed'),KeyboardInterrupt('stage cancelled')))
def test_stage_failure_closes_maps_context_and_restores_guards(case,error):
    c=case
    with pytest.raises(type(error)) as caught:
        with server(c) as h:
            ctx=h.ctx;maps=[v for pair in ctx._param_cache.raw_rotation_keys.values() for v in pair.values()]
            raise error
    assert caught.value is error and h.ctx is None and not vars(ctx)
    assert all(a._mmap.closed for a in maps);assert_restored(c)


def test_partial_setup_failure_restores_and_releases(case,monkeypatch):
    c=case;original=c.runtime.Context.program_initialization
    def fail(ctx,*a,**kw):original(ctx,*a,**kw);raise KeyboardInterrupt('initialization interrupted')
    monkeypatch.setattr(c.runtime.Context,'program_initialization',fail)
    with pytest.raises(KeyboardInterrupt):
        with server(c):pass
    assert len(c.contexts)==1 and not vars(c.contexts[0]);assert_restored(c)

@pytest.mark.parametrize('primary',(False,True))
def test_cleanup_attempts_everything_preserves_primary(case,monkeypatch,primary):
    c=case;error=KeyboardInterrupt('primary');closed=[];original=loaders._ReadDirectory.close
    def close(owner):original(owner);closed.append(owner.path);raise RuntimeError('close failure')
    monkeypatch.setattr(loaders._ReadDirectory,'close',close)
    c.runtime.ckks.evict_context_caches=lambda ctx:(_ for _ in ()).throw(KeyboardInterrupt('cleanup cancellation'))
    with pytest.raises(KeyboardInterrupt) as caught:
        with client(c) as h:
            ctx=h.ctx;sk=ctx.secret_key
            if primary:raise error
    assert caught.value is error if primary else str(caught.value)=='cleanup cancellation'
    assert not vars(ctx) and sk._mmap.closed and closed==[c.m.private,c.m.public]
    assert_restored(c)


def test_nested_loader_rejected_without_perturbing_outer(case):
    with server(case) as h:
        with pytest.raises(RuntimeError):
            with client(case):pass
        with pytest.raises(RuntimeError):h.ctx.decrypt_slots()
    assert_restored(case)

@pytest.mark.parametrize('kind',('file','directory','parent'))
def test_key_replacement_during_stage_rejected_and_replacement_retained(case,kind):
    c=case
    with pytest.raises(ValueError):
        with client(c):
            if kind=='file':
                path=c.m.private/'secret.npy';path.rename(c.m.private/'old-secret.npy');path.write_bytes(b'replacement')
            elif kind=='directory':
                c.m.private.rename(c.m.private.with_name('old-private'));c.m.private.mkdir();(c.m.private/'marker').write_text('replacement')
            else:
                parent=c.m.public.parent;parent.rename(parent.with_name(parent.name+'-old'));parent.mkdir();(parent/'marker').write_text('replacement')
    if kind=='file':assert path.read_bytes()==b'replacement'
    elif kind=='directory':assert (c.m.private/'marker').read_text()=='replacement'
    else:assert (parent/'marker').read_text()=='replacement'
    assert_restored(c)


def test_missing_alias_guard_rejects_before_construct(case):
    case.runtime.key_modules.pop('key_gen')
    with pytest.raises(RuntimeError):
        with server(case):pass
    assert not case.contexts and not loaders._ACTIVE.locked()


def test_server_detects_secret_and_reusable_mode_mutation(case):
    for field in ('secret_key','per_level_rotation_keys'):
        with pytest.raises(ValueError):
            with server(case) as h:setattr(h.ctx._param_cache,field,[] if field=='secret_key' else True)
        assert_restored(case)


def test_partial_map_failure_closes_every_previous_mapping(case,monkeypatch):
    original=loaders._map_array;opened=[]
    def wrapped(owner,name,*args):
        if name=='rot_2_a.npy':raise KeyboardInterrupt('mapping interrupted')
        mapped,state=original(owner,name,*args);opened.append(mapped);return mapped,state
    monkeypatch.setattr(loaders,'_map_array',wrapped)
    with pytest.raises(KeyboardInterrupt):
        with server(case):pass
    assert opened and all(a._mmap.closed for a in opened) and not case.contexts
    assert_restored(case)
