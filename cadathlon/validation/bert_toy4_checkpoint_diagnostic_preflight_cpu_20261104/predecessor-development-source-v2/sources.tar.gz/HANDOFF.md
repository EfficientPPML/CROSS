# Disabled preflight only

Run from the dedicated new lab with the original NumPy2.5.4 interpreter:

    env PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 JAX_PLATFORMS=cpu taskset -c 172-175 /home/jianming_gatech/miniconda3/envs/jaxite/bin/python -B collect.py --output preflight-v1

This has no --execute flag. Actual execution remains disabled. A later exact-source review and explicit root accelerator authorization are required before any fresh keys or HE/TPU work. No queue/lease change is part of this preparation.
