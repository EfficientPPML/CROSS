"""Actual frozen graph bodies over explicit NumPy primitives, not HE evidence."""
from pathlib import Path
from types import SimpleNamespace
import math
import numpy as np
import pytest
import component_arithmetic as component
from component_contract import numerical_plan
from scale_replay import refresh_scale_certificate

def harness(monkeypatch,callback):
    from public_plan import public_graph as public
    original=public.Value.__init__;profile=numerical_plan()['profile']
    class Array:
        dtype='uint32'
        def __init__(self,n):self.shape=(1,2,256,512,n);self.barriers=0
        def block_until_ready(self):self.barriers+=1;return self
    def init(self,slots,level,scale):
        original(self,slots,level,scale);self.batch=1;self.num_elements=2;self.degree=131072;self.precision=32;self.r=256;self.c=512
        self.num_moduli=2*(level+1);self.degree_layout=(256,512);self.moduli=profile['q_towers'][:self.num_moduli]
        self.polynomial=Array(self.num_moduli);self.moduli_array=object()
    monkeypatch.setattr(public.Value,'__init__',init)
    ledger=component.Ledger(callback)
    class FakeRefresh:
        input_level=2;output_level=25
        def refresh(self,value,*,public_bound):
            assert np.max(np.abs(value.slots))<=public_bound
            i=len(ledger.refresh_scales);scale=refresh_scale_certificate()['accepted_scales'][i%3]
            return public.Value(value.slots.copy(),25,scale)
    class Refresh(component.RefreshInstrumentation,FakeRefresh):pass
    class Arithmetic(component.ArithmeticInstrumentation,public.BoundedArithmetic):
        def __init__(self):
            public.Arithmetic.__init__(self,profile['q_towers'],profile['scale']);self.ledger=ledger;self.refresher=Refresh();self.refresher.ledger=ledger
        def record(self,kind,label,value,**extra):return value
    class Graph(component.GraphInstrumentation,public.BoundedPackedTransformer):pass
    graph=Graph.__new__(Graph);graph.layout=public.PackedPairLayout(2,8,64,65536);graph.features=64;graph._head_contract=None;graph.arithmetic=Arithmetic();graph.ctx=graph.arithmetic.ctx
    return public,graph,ledger

def fixed_inputs(public,graph):
    import importlib.util,json
    path=public.ROOT/'cadathlon/agent_pset/p2_bert/src/reference.py';spec=importlib.util.spec_from_file_location('fixed_test4',path);reference=importlib.util.module_from_spec(spec);spec.loader.exec_module(reference)
    case=numerical_plan()['case'];weights,embeddings,mask,expected=reference.make_case(case)
    value=public.Value(graph.layout.pack_client_embeddings(embeddings)[0],49,numerical_plan()['profile']['scale'])
    return value,weights,mask

def execute(public,graph,ledger):
    value,weights,mask=fixed_inputs(public,graph)
    ledger.note('input','original_embeddings',value)
    result=graph.evaluate(value,'bert',numerical_plan()['case']['config'],weights,public.public_toy_approximations('bert'),mask)
    ledger.note('output','classifier',result);return value,result

def test_literal_graph96_allslots_counts_and_actual_scales(monkeypatch):
    rows=[];outputs=[]
    def checkpoint(i,value,row):
        assert value.polynomial.barriers>0;assert i==len(rows);rows.append(dict(row));outputs.append(value.slots.copy())
    public,graph,ledger=harness(monkeypatch,checkpoint);execute(public,graph,ledger)
    from scale_replay import client_replay
    replay=client_replay(tuple(ledger.refresh_scales))
    assert ledger.counts==dict(add=228,weighted=168,multiply=61)and len(rows)==96
    for actual,ref,slots,expected in zip(rows,replay['trace'],outputs,replay['values'],strict=True):
        assert(actual['level'],actual['scale'],actual['nsd'])==(ref['level'],ref['scale'],ref['nsd'])
        assert np.isfinite(slots).all()and float(np.max(np.abs(slots-expected)))<=1e-10
    assert ledger.callback_held==()

@pytest.mark.parametrize('field,value',[('num_moduli',True),('_ckks_nsd',True),('precision',32.0),('r',256.0),('_ckks_scale',float('inf')),('polynomial',object())])
def test_callback_mutates_captured_original_rejected(monkeypatch,field,value):
    saved=[]
    def checkpoint(i,v,row):
        if i==0:saved.append(v)
        if i==1:setattr(saved[0],field,value)
    public,graph,ledger=harness(monkeypatch,checkpoint)
    with pytest.raises((ValueError,AttributeError)):execute(public,graph,ledger)
    assert len(ledger.trace)==1 and ledger.counts==dict(add=0,weighted=0,multiply=0)
    assert ledger.callback_held and ledger.callback_held[0][1]is not None

def test_callback_public_range_tag_mutation_rejected(monkeypatch):
    def checkpoint(i,v,row):
        if i==1:v._public_absolute_bound=0.
    public,graph,ledger=harness(monkeypatch,checkpoint)
    with pytest.raises(ValueError,match='range annotation'):execute(public,graph,ledger)
    assert len(ledger.trace)==1

def test_callback_public_relation_array_content_rejected(monkeypatch):
    def callback(i,v,row):v._public_relation[0]=0.
    public,graph,ledger=harness(monkeypatch,callback);v,_,_=fixed_inputs(public,graph);v._public_relation=np.array([2.,3.])
    with pytest.raises(ValueError,match='range annotation'):ledger.note('input','original_embeddings',v)

@pytest.mark.parametrize('change',['binding','controls','constant_payload'])
def test_callback_live_compiler_controls_retained_and_guarded(monkeypatch,change):
    controls=SimpleNamespace(executable=object(),controls=[object()]);cache={'binding':controls};constant=SimpleNamespace(_polynomial=object());roots=[cache,constant]
    def callback(i,v,row):
        if change=='binding':cache['binding']=SimpleNamespace(executable=object(),controls=[])
        elif change=='controls':controls.controls[0]=object()
        else:constant._polynomial=object()
    public,graph,ledger=harness(monkeypatch,callback);ledger.working=lambda:roots
    with pytest.raises(ValueError,match='compiled control'):execute(public,graph,ledger)
    assert ledger.callback_controls and not ledger.trace

def test_callback_row_mutation_rejected(monkeypatch):
    def checkpoint(i,v,row):row['scale']=1.
    public,graph,ledger=harness(monkeypatch,checkpoint)
    with pytest.raises(ValueError,match='row changed'):execute(public,graph,ledger)
    assert not ledger.trace

@pytest.mark.parametrize('failure',[RuntimeError,KeyboardInterrupt,SystemExit])
def test_callback_primary_preserved_and_original_array_held(monkeypatch,failure):
    problem=failure('callback');saved=[]
    def checkpoint(i,v,row):saved.append(v.polynomial);raise problem
    public,graph,ledger=harness(monkeypatch,checkpoint)
    with pytest.raises(failure)as caught:execute(public,graph,ledger)
    assert caught.value is problem and ledger.callback_held[0][1]is saved[0]

def test_structural_metadata_alias_beforework(monkeypatch):
    public,graph,ledger=harness(monkeypatch,lambda *args:None);v,_,_=fixed_inputs(public,graph);v.num_moduli=100.0
    with pytest.raises(ValueError):ledger.note('input','original_embeddings',v)
    assert not ledger.trace

def control_fixture():
    profile=numerical_plan()['profile'];keys=numerical_plan()['required_rotation_indices']
    cache=SimpleNamespace(secret_key=None,per_level_rotation_keys=False,dnum=4,degree_layout=(256,512),q_towers=profile['q_towers'],p_towers=profile['p_towers'],
        raw_rotation_keys={i:{'a':object(),'b':object()}for i in keys},coef_maps={i:object()for i in keys})
    ctx=SimpleNamespace(_param_cache=cache,secret_key=None,public_key=None,parameters={},degree=131072,num_slots=65536,degree_layout=(256,512),composite_degree=2,max_level=49,q_towers=profile['q_towers'],p_towers=profile['p_towers'])
    def helper():return SimpleNamespace(ctx=ctx,_finish=lambda v:v,clear=lambda:None)
    a=helper();a.low_memory=True;a.scale=profile['scale'];a.strategy='power';a.progress=None;a.preserve_dispatch_cache=True
    evaluator=helper();evaluator.low_memory=True;evaluator.scale=profile['scale'];evaluator.strategy='power';evaluator.progress=None;evaluator.preserve_dispatch_cache=True
    view=SimpleNamespace(_param_cache=cache,degree=131072,num_slots=8192,degree_layout=(256,512),composite_degree=2)
    engine=SimpleNamespace(ctx=view,_cache=cache,_degree=131072,_num_slots=8192,_gap=8,_sparse=True,_composite_degree=2,_level_budget=[4,4],_low_mem=True,_dc_subtract=False)
    for name in('bootstrap','meta_bootstrap','control_gen','setup_key','_stage_checkpoint'):setattr(engine,name,lambda *a:None)
    refresher=helper();refresher.evaluator=evaluator;refresher.engine=engine;refresher.compiled_primitives=tuple(helper()for _ in range(5));refresher.plan={'period':8192};refresher.meta_precision=10
    graph=SimpleNamespace(ctx=ctx,arithmetic=a);provider=object()
    return ctx,graph,refresher,provider

@pytest.mark.parametrize('change',['scale','mode','finish','key','map','helper_context','view_cache','view_slots','engine_gap','engine_sparse','engine_method','actual_q','dnum_bool'])
def test_construction_control_snapshot_rejects_callback_changes(change):
    ctx,graph,refresh,provider=control_fixture();baseline=component.control_state(ctx,graph,refresh,provider)
    ledger=component.Ledger(lambda *a:None);ledger.control=lambda:component.control_state(ctx,graph,refresh,provider);ledger.control_state=baseline
    if change=='scale':graph.arithmetic.scale=math.nextafter(graph.arithmetic.scale,math.inf)
    elif change=='mode':graph.arithmetic.low_memory=1
    elif change=='finish':graph.arithmetic._finish=lambda x:x
    elif change=='key':ctx._param_cache.raw_rotation_keys[1]['a']=object()
    elif change=='map':ctx._param_cache.coef_maps[1]=object()
    elif change=='helper_context':refresh.compiled_primitives[0].ctx=object()
    elif change=='view_cache':refresh.engine.ctx._param_cache=object()
    elif change=='view_slots':refresh.engine.ctx.num_slots=65536
    elif change=='engine_gap':refresh.engine._gap=1
    elif change=='engine_sparse':refresh.engine._sparse=1
    elif change=='engine_method':refresh.engine.meta_bootstrap=lambda *a:None
    elif change=='actual_q':ctx._param_cache.q_towers=ctx._param_cache.q_towers[:-1]+[17]
    else:ctx._param_cache.dnum=True
    with pytest.raises(ValueError):ledger.guard()
