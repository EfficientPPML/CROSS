"""Source-bound three-role diagnostic collector; actual launch is disabled.

No healthy deadline. Original sources and the fresh no-pyc execution tree are
checked before and after each role. Only complete direct-wait/group-empty
receipts authorize the next role. Key/cipher/public-weight bodies remain in an
explicit owned workspace and are never copied into the public archive.
"""
from pathlib import Path
import argparse,json,os,secrets,shutil,sys,tarfile,time
import xml.etree.ElementTree as ET
import component_protocol as p
from component_contract import ROOT,canonical
from component_processes import OwnedChild
from cleanup import cleanup_signals
from terminal import terminal_scope
from finish import finish
EXPECTED_TESTS=198

def snapshot(out):
    raw=p.sources();pins=p.hashes(raw);p.check_sources(pins)
    execution=out/'execution';execution.mkdir(mode=0o700)
    for name,body in raw.items():
        dest=execution/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(body)
    with tarfile.open(out/'sources.tar.gz','x:gz')as tar:
        for name in pins:tar.add(execution/name,arcname=name,recursive=False)
    archive=p.read(out/'sources.tar.gz');p.verify_archive(archive,pins)
    p.write(out/'source_hashes.json',pins)
    return execution,pins,p.sha(archive)

def execution_hashes(execution,pins):return{name:p.sha(p.read(execution/name,8<<20))for name in pins}

def environment(actual):
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',JAX_PLATFORMS='tpu'if actual else'cpu')
    env.pop('CROSS_SKIP_TOPLEVEL_ROTKEYS',None)
    return env

def stage(out,execution,pins,config):
    report=dict(stage=config['stage'],complete=False,passed=False,source_verified=False,worker_verified=False,cleanup_completed=False,child_launch_attempted=False,
        workspace=config['workspace'],workspace_identity=config['workspace_identity'],source_hashes=pins)
    path=out/'report.json';primary=None;active=None;start=time.monotonic()
    p.write(out/'config.json',config);p.write(out/'source_hashes.json',pins)
    try:
        p.write(path,report)
        command=[sys.executable,'-B',str(execution/'component_worker.py'),'--execute','--config',str(out/'config.json'),
            '--config-sha256',p.sha(canonical(config)),'--source-manifest',str(out/'source_hashes.json'),'--output',str(out/'worker')]
        with(out/'worker.log').open('xb')as log:
            report['child_launch_attempted']=True;p.write(path,report)
            active=OwnedChild(command,cwd=execution,stdout=log,env=environment(True));report['child']=active.record;p.write(path,report)
            code=active.wait()
        report['child']=dict(active.record);active=None
        worker_raw=p.read(out/'worker/report.json');worker=p.parse(worker_raw);report['worker_report_sha256']=p.sha(worker_raw)
        archive=p.read(out/'worker/sources.tar.gz');p.verify_archive(archive,pins)
        report['worker_verified']=bool(worker.get('source_archive_sha256')==p.sha(archive)and worker.get('source_hashes_start')==pins and worker.get('source_hashes_end')==pins)
        report['complete']=True
        report['passed']=bool(code==0 and report['worker_verified']and all(worker.get(k)is True for k in('passed','complete','source_verified','cleanup_completed','terminal_scope_completed','termination_scope_completed')))
    except BaseException as error:primary=error;report['error']=dict(type=type(error).__name__,message=str(error))
    finally:
        with terminal_scope(report,path,p.write,cleanup_signals,lambda:(primary,None)):
            cleanup=p.Finalizer(primary)
            if active is not None:
                cleanup.attempt('owned child retirement',lambda:active.close(primary=primary));report['child']=dict(active.record)
            cleanup.attempt('workspace identity',lambda:p.check_identity(config['workspace'],config['workspace_identity']))
            current=cleanup.attempt('original source readback',lambda:p.hashes(p.sources()));copied=cleanup.attempt('execution source readback',lambda:execution_hashes(execution,pins))
            report.update(source_verified=current==pins and copied==pins,source_hashes_end=current,execution_hashes_end=copied,elapsed_s=time.monotonic()-start)
            child=report.get('child',{})
            report['cleanup_completed']=bool(not cleanup.errors and(not report['child_launch_attempted']or all(child.get(k)is True for k in('direct_child_reaped','group_empty_verified','cleanup_completed'))))
            report['cleanup_scope']='Owned OS child/group retirement only. Worker wrapper/map quarantine is separate; retained workspace is not deleted.'
            report['passed']=bool(report['passed']and report['source_verified']and report['cleanup_completed'])
            report['cleanup_errors']=[label+': '+repr(error)for label,error in cleanup.errors]
            cleanup.attempt('terminal publication',lambda:p.write(path,report));cleanup.raise_failure()
    return report

def collect(out,execute,workspace_parent):
    report=dict(schema='toy4-checkpoint-diagnostic-collector-v1',execute=execute,passed=False,complete=False,cleanup_completed=False,
        source_verified=False,roles=[],role_attempts=[],scope='Fixed public toyBERT4 diagnostic, not pretrained/full-model benchmark')
    primary=None;active=None;path=out/'report.json';pins={};execution=None;start=time.monotonic()
    try:
        p.write(path,report);execution,pins,archive_sha=snapshot(out)
        from resource_plan import report as resource_report
        report.update(source_hashes_start=pins,source_archive_sha256=archive_sha,execution_root=str(execution),resource_plan=resource_report(workspace_parent));p.write(path,report)
        if not execute:
            # The preflight test process must enforce zero backend/key/model
            #reads. It exercises tiny mocks and the public fixed toy oracle.
            command=[sys.executable,'-B','-m','pytest','-q','-p','no:cacheprovider','--rootdir=.',
                '--junitxml',str(out/'tests.xml'),*sorted(name for name in pins if name.startswith('test_')and name.endswith('.py'))]
            with(out/'tests.log').open('xb')as log:
                env=environment(False)|dict(TOY4_PREFLIGHT_AUDIT_PATH=str(out/'audit.json'))
                active=OwnedChild(command,cwd=execution,stdout=log,env=env);report['test_child']=active.record;p.write(path,report);code=active.wait()
            report['test_child']=dict(active.record);active=None
            audit=p.parse(p.read(out/'audit.json'));report['preflight_audit']=audit
            tree=ET.fromstring(p.read(out/'tests.xml'));cases=tree.findall('.//testcase')
            xml_ok=len(cases)==EXPECTED_TESTS and not tree.findall('.//failure')and not tree.findall('.//error')and not tree.findall('.//skipped')
            report.update(tests_returncode=code,test_cases=len(cases),expected_test_cases=EXPECTED_TESTS,all_tests_executed_without_skip=bool(xml_ok))
            report['passed']=bool(code==0 and xml_ok and audit.get('zero_forbidden_attempts')is True and audit.get('backend_or_private_attempts')==[])
        else:
            p.require_ready()
            if report['resource_plan']['capacity_passed']is not True:raise OSError('insufficient owned-workspace filesystem capacity')
            nonce=secrets.token_hex(16);workspace=workspace_parent/('toy4-diagnostic-'+nonce);workspace.mkdir(mode=0o700,exist_ok=False)
            ident=p.identity(workspace);report.update(workspace=str(workspace),workspace_identity=ident,workspace_retained=True)
            config=dict(stage='setup',workspace=str(workspace),workspace_identity=ident,nonce=nonce,
                setup_receipt=None,setup_sha256=None,server_receipt=None,server_sha256=None)
            for role in p.STAGES:
                config['stage']=role;folder=out/role;folder.mkdir(mode=0o700,exist_ok=False)
                report['role_attempts'].append(role);p.write(path,report)
                # Acquired directory precedes finish's failure republication.
                receipt=finish(folder/'report.json',lambda:stage(folder,execution,pins,dict(config)),p.write,p.read)
                report['roles'].append(dict(stage=role,report_sha256=p.sha(p.read(folder/'report.json')),passed=receipt['passed']));p.write(path,report)
                if not receipt['passed']:raise RuntimeError('fixed diagnostic role failed: '+role)
                if role in('setup','server'):
                    config[role+'_receipt']=str(folder/'report.json');config[role+'_sha256']=report['roles'][-1]['report_sha256']
            report['passed']=True
        report['complete']=True
    except BaseException as error:primary=error;report['error']=dict(type=type(error).__name__,message=str(error))
    finally:
        with terminal_scope(report,path,p.write,cleanup_signals,lambda:(primary,None)):
            cleanup=p.Finalizer(primary)
            if active is not None:cleanup.attempt('test child retirement',lambda:active.close(primary=primary));report['test_child']=dict(active.record)
            if execution is not None:
                current=cleanup.attempt('original source readback',lambda:p.hashes(p.sources()));copied=cleanup.attempt('execution source readback',lambda:execution_hashes(execution,pins))
                cleanup.attempt('source archive readback',lambda:p.verify_archive(p.read(out/'sources.tar.gz'),pins))
                report.update(source_hashes_end=current,execution_hashes_end=copied,source_verified=current==pins and copied==pins)
            child=report.get('test_child',{})
            role_retirement={}
            for role in report['role_attempts']:
                receipt=cleanup.attempt('role retirement readback '+role,lambda role=role:p.parse(p.read(out/role/'report.json')))
                record={}if not isinstance(receipt,dict)else receipt
                role_retirement[role]=bool(record.get('cleanup_completed')is True and(record.get('child_launch_attempted')is False or all(record.get('child',{}).get(k)is True for k in('direct_child_reaped','group_empty_verified','cleanup_completed'))))
            report['role_retirement']=role_retirement
            retired=all(role_retirement.values())if execute else all(child.get(k)is True for k in('direct_child_reaped','group_empty_verified','cleanup_completed'))
            report['cleanup_completed']=bool(not cleanup.errors and retired)
            report['cleanup_scope']='Owned OS child/group retirement only; key/cipher/public-weight workspace retained, not deleted. Failed worker arrays/maps may remain quarantined until its process exit.'
            report['passed']=bool(report['passed']and report['source_verified']and report['cleanup_completed']);report['elapsed_s']=time.monotonic()-start
            report['cleanup_errors']=[label+': '+repr(error)for label,error in cleanup.errors]
            cleanup.attempt('terminal publication',lambda:p.write(path,report));cleanup.raise_failure()
    return report

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--execute',action='store_true')
    parser.add_argument('--workspace-parent',type=Path,default=Path('/dev/shm'));args=parser.parse_args()
    # Never republish to evidence whose fresh directory acquisition failed.
    args.output.mkdir(mode=0o700,exist_ok=False)
    report=finish(args.output/'report.json',lambda:collect(args.output,args.execute,args.workspace_parent),p.write,p.read)
    return 0 if report['passed']else 1

if __name__=='__main__':raise SystemExit(main())
