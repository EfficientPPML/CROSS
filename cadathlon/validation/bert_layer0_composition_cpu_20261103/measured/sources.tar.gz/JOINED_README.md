# Complete pinned layer-0 ideal composition

This validation-only serial harness joins the unchanged first-attention and
FFN owners. Every returned attention object is passed directly to its matching
FFN tile. Native or independent polynomial activation arrays are never used as
substitute inputs. No ciphertext, real refresh, file-stage or12-layer readiness
claim is made.

The fixed K15 and K128 public fixtures preserve original learned-position
embeddings before compaction. A separate trusted preparation computes native
`BertLayer.forward` outputs using the pinned checkpoint in float64. The
independent dense oracle composes the frozen polynomial softmax, attention
normalization, GELU64 and MLP normalization through the whole block. Every
propagated valid-query domain is checked. Exact dense/native agreement uses
the existing1e-11 oracle gate. Every physical ideal output slot uses the fixed
1e-8 gate. Polynomial/native differences remain diagnostics without a new
block-accuracy threshold; no padded-query-domain assertion is introduced.

One shared identity refresher has a fixed full-slot plan, helper inventory and
static public bounds B2/B16/B128. It changes only declared levels and actual
adjacent binary64 metadata, never slot values. This validates composition and
scale bookkeeping, not refreshed-probability errors, denominator-domain noise
margins or B2 refresh accuracy. Attention outputs atL9 enter two explicit FFN
refreshes and finish atL13. This cannot be fed directly into the L49-specific
attention owner for another layer.

The public inventory is derived from actual pinned dense matrices and the
unchanged graph/bootstrap planners. Expected full-K128 counts excluding all
bootstrap internals are75,408 logical rotations,3,976 ciphertext products,
169,704 plaintext terms,10,592 composite rescales and56 explicit refreshes
(40B2,8B128,8B16). Exact ideal execution checks these counts. No latency or
peak-memory prediction follows from them.

Run with CPU-only fixed-affinity tooling:

```
env JAX_PLATFORMS=cpu OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4 \
  taskset -c 120-123 /home/jianming_gatech/miniconda3/envs/jaxite/bin/python \
  check_layer0_ideal.py --output /tmp/bert-layer0-new-proof
```

The collector runs the exact source snapshot, records versions/commands, checks
both client fixture hashes and every source/archive member, and reaps the test
process. Model weights, native activations, keys and ciphertexts are excluded
from published evidence. `joined_source_origin.json` links the unchanged
owner archives; `native_block_preparation.json` binds the trusted native
reference preparation and pinned assets.
