"""Ciphertext-only scaled Newton iteration with public parameters.

This computes z <- z*(2 - C*x*z), starting from a public positive z0.
Convergence requires a caller-established public input/initialization contract.
Neither the input domain nor CKKS error is inferred from encrypted values.
This helper performs no bootstrap, codec operation or client callback.
"""
from dataclasses import dataclass
import math
from typing import Any

import numpy as np


@dataclass(frozen=True)
class NewtonInverseResult:
    final: Any
    checkpoints: dict[int, Any]
    updates: int


def scaled_newton_inverse(arithmetic, denominator, *, normalization_factor,
                          initial_estimate, updates, capture_updates=()):
    """Run fixed public updates, optionally retaining exact update outputs.

    ``initial_estimate`` is a scalar or one public estimate per CKKS slot.
    This permits separate public domains within one ciphertext. A domain's
    declared output must be selected at its declared update count; continuing
    other slots does not change the already-retained output ciphertext.

    The first update is a single public affine operation. Each subsequent
    update uses CT*CT, public affine, CT*CT in that exact order. Input/outputs
    are ciphertexts; callers may inspect them only after server work finishes.
    """
    if isinstance(normalization_factor, (bool, np.bool_)):
        raise ValueError('normalization_factor must be positive and finite')
    factor = float(normalization_factor)
    if not math.isfinite(factor) or factor <= 0:
        raise ValueError('normalization_factor must be positive and finite')
    if type(updates) is not int or updates < 1:
        raise ValueError('updates must be a positive public integer')
    requested = tuple(capture_updates)
    if (any(type(index) is not int or not 1 <= index <= updates for index in requested)
            or len(set(requested)) != len(requested)):
        raise ValueError('capture updates must be distinct integers within the circuit')
    initial = np.asarray(initial_estimate, dtype=np.float64)
    if initial.ndim not in (0, 1) or (initial.ndim == 1 and initial.shape != (arithmetic.ctx.num_slots,)):
        raise ValueError('initial estimate must be scalar or one public value per slot')
    if not np.isfinite(initial).all() or not (initial > 0).all():
        raise ValueError('initial estimate must contain positive finite public values')
    with np.errstate(over='ignore', invalid='ignore'):
        weight = -factor * initial * initial
        bias = 2. * initial
    if not np.isfinite(weight).all() or not np.isfinite(bias).all():
        raise ValueError('initial public affine coefficients must be finite')
    if initial.ndim == 0:
        weight, bias = float(weight), float(bias)
    else:
        # Public coefficients are detached from any caller-owned array.
        weight, bias = weight.copy(), bias.copy()

    checkpoints = {}
    z = arithmetic.weighted_sum([denominator], [weight], bias=bias)
    if 1 in requested:
        checkpoints[1] = z
    for update in range(2, updates + 1):
        product = arithmetic.multiply(denominator, z)
        correction = arithmetic.weighted_sum([product], [-factor], bias=2.)
        z = arithmetic.multiply(z, correction)
        if update in requested:
            checkpoints[update] = z
    return NewtonInverseResult(z, checkpoints, updates)
