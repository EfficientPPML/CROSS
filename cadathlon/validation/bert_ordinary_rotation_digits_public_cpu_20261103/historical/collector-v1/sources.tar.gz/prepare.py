from pathlib import Path
import ast,hashlib,json,shutil,difflib
HERE=Path(__file__).resolve().parent
SRC=Path('/tmp/bert-server-compute-stage4-successor-v2-20261103/runtime/jaxite_word')
dst=HERE/'checkout/jaxite_word';dst.mkdir(parents=True,exist_ok=False)
for path in SRC.glob('*.py'):shutil.copy2(path,dst/path.name)
raw=(dst/'herot.py').read_text();(HERE/'baseline_herot.py').write_text(raw)
tree=ast.parse(raw);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='_HERotKernel');method=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_rotate_barrett_fused')
text='\n'.join(raw.splitlines()[method.lineno-1:method.end_lineno])+'\n'
text=text.replace('def _rotate_barrett_fused(self, ct_data, eval_a, eval_b, coef_map):','def _rotate_from_digits_array(self, ct_data, digits, eval_a=None, eval_b=None, coef_map=None):')
text=text.replace('    """Run the low-memory Barrett rotation kernel for sub-31-bit moduli."""\n','''    """Complete ordinary rotation using same-input precomputed HYBRID digits.

    Experimental raw seam: caller must bind digits from _decompose_array of
    this exact immutable input and control state. Shape validation alone does
    not authenticate that provenance. No shared owner/cache is introduced.
    """
    self._require_controls()
    if (self._controls_ready is not True or self.ff_context_cls is not BarrettContext
        or any(modulus >= 1 << 31 for modulus in self.overall_moduli)):
      raise ValueError('prepared ordinary rotation requires exact sub31 Barrett controls')
    finite_field.check_rank5_array(
        ct_data, '_HERotKernel._rotate_from_digits_array', batch=self.batch,
        num_elements=2, degree_layout=(self.r, self.c), num_moduli=self.sizeQl)
    expected = (self.numPartQl, self.batch, 1, self.r, self.c, self.sizeQlP)
    if getattr(digits, 'shape', None) != expected or getattr(digits, 'dtype', None) != jnp.uint32:
      raise ValueError('prepared rotation requires exact uint32 digit shape')
    if getattr(ct_data, 'dtype', None) != jnp.uint32:
      raise ValueError('prepared rotation requires uint32 source payload')
    if any(key is not None and getattr(key, 'dtype', None) != jnp.uint32
           for key in (eval_a, eval_b)):
      raise ValueError('prepared rotation requires uint32 explicit key operands')
    if coef_map is not None and getattr(coef_map, 'dtype', None) != jnp.int32:
      raise ValueError('prepared rotation requires int32 coefficient map')
    coef_map = self._resolve_automorphism_map(coef_map)
''')
needle='    in_tower, coeffs = self._prepare_decomposition_inputs(ct_data)\n';assert text.count(needle)==1;text=text.replace(needle,'')
for a,b in [('self._decompose_part(in_tower, coeffs, 0)','digits[0]'),('self._decompose_part(in_tower, coeffs, part + 1)','digits[part + 1]')]:
 assert text.count(a)==1;text=text.replace(a,b)
point=raw.index('  # ---------------------------------------------------------------------------\n  # Runtime state helpers.')
new=raw[:point]+text+'\n'+raw[point:];(dst/'herot.py').write_text(new)
(HERE/'candidate.patch').write_text(''.join(difflib.unified_diff(raw.splitlines(True),new.splitlines(True),fromfile='a/jaxite_word/herot.py',tofile='b/jaxite_word/herot.py')))
profile=Path('/tmp/bert-server-compute-stage4-successor-v2-20261103/runtime/stage/server_inputs/p60_profile_and_refresh.json');shutil.copy2(profile,HERE/profile.name)
origin={'source':str(SRC),'before':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in SRC.glob('*.py')},'scope':'Public raw-array ordinary-completion seam only; no contexts, keygen, encryption or owner integration.'}
(HERE/'source_origin.json').write_text(json.dumps(origin,indent=2)+'\n')
