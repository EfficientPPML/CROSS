"""Source-copy collector for public synthetic raw-array rotation parity only."""
from pathlib import Path
import argparse,hashlib,io,json,os,signal,subprocess,sys,tarfile,time
HERE=Path(__file__).resolve().parent

def sources():
 return {p.relative_to(HERE).as_posix():p.read_bytes() for p in HERE.rglob('*') if p.is_file() and '__pycache__'not in p.parts and (p.parent==HERE or 'checkout' in p.relative_to(HERE).parts) and p.suffix in ('.py','.json','.patch')}
def hashes(raw):return {n:hashlib.sha256(v).hexdigest() for n,v in raw.items()}
def write(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def run(output):
 output=Path(output);output.mkdir(exist_ok=False);start=time.monotonic();primary=None;cleanup=[];child=None;snapshot=None;before={}
 report=dict(passed=False,scope='Actual JAX public canonical-residue/synthetic-key arithmetic only; no CKKSContext, secret, keygen, encryption or decryption. No secure-HE/performance/peak-memory claim.',cpu_affinity=sorted(os.sched_getaffinity(0)),pid=os.getpid())
 def attempt(label,fn):
  try:return fn()
  except BaseException as e:
   cleanup.append(e)
   if primary is not None:primary.add_note(label+': '+repr(e))
 def read_archive():
  with tarfile.open(output/'sources.tar.gz') as t:
   ms=t.getmembers();assert len(ms)==len(before)==len({m.name for m in ms}) and all(m.isfile() for m in ms)
   assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in ms}==before
  return True
 try:
  write(output/'report.json',report);raw=sources();before=hashes(raw);report['source_hashes_before']=before
  with tarfile.open(output/'sources.tar.gz','w:gz') as t:
   for n,v in raw.items():m=tarfile.TarInfo(n);m.size=len(v);t.addfile(m,io.BytesIO(v))
  read_archive();snapshot=output/'snapshot';snapshot.mkdir()
  for n,v in raw.items():p=snapshot/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(v)
  cmd=[sys.executable,str(snapshot/'check_public.py'),'--output',str(output/'public-parity')]
  env=os.environ.copy();env.update(JAX_PLATFORMS='cpu',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONUNBUFFERED='1')
  with (output/'run.log').open('wb') as stream:
   child=subprocess.Popen(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);report['child_pid']=child.pid;write(output/'report.json',report);code=child.wait()
  report.update(returncode=code,process_reaped=True,command=cmd)
  if code!=0:raise RuntimeError('public arithmetic proof failed; failure preserved')
  result=json.loads((output/'public-parity/report.json').read_bytes())
  if result['passed']is not True or len(result['fixtures'])!=12 or result['total_comparisons']!=372 or result['total_negative_guards']!=144 or result['no_context_keygen_modules_loaded']is not True:raise ValueError('complete public proof required')
  report.update(operation_complete=True,public_result=result)
 except BaseException as e:primary=e;report['error']=dict(type=type(e).__name__,message=str(e))
 finally:
  if child is not None and child.poll()is None:
   attempt('stop child',lambda:os.killpg(child.pid,signal.SIGKILL));attempt('reap child',child.wait)
  report['process_reaped']=child is None or child.poll()is not None
  after=attempt('source readback',lambda:hashes(sources()));copied=attempt('snapshot readback',lambda:{n:hashlib.sha256((snapshot/n).read_bytes()).hexdigest() for n in before}) if snapshot else None
  verified=attempt('archive readback',read_archive) if before else False
  report.update(source_hashes_after=after,snapshot_hashes=copied,source_files_unchanged=bool(before) and before==after==copied,source_archive_verified=verified is True,source_count=len(before),cleanup_errors=[repr(e) for e in cleanup],elapsed_s=time.monotonic()-start)
  if (output/'sources.tar.gz').is_file():report['source_archive_sha256']=hashlib.sha256((output/'sources.tar.gz').read_bytes()).hexdigest()
  report['passed']=bool(report.get('operation_complete') and primary is None and not cleanup and report['process_reaped'] and report['source_files_unchanged'] and verified)
  chosen=primary if primary is not None else next((e for e in cleanup if not isinstance(e,Exception)),cleanup[0] if cleanup else None)
  try:write(output/'report.json',report)
  except BaseException as e:
   if chosen is None:raise
   chosen.add_note('final publication: '+repr(e))
  if chosen is not None:raise chosen
 print(json.dumps(dict(passed=True,source_count=len(before),comparisons=report['public_result']['total_comparisons'],source_archive_sha256=report['source_archive_sha256'])));return report
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
 result=run(p.parse_args().output)
 raise SystemExit(0 if result['passed'] else 1)
