"""Isolated encode_at_level boundary experiment; no production monkeypatch.

Only the host encoding expression is replaced. Initialization/level checks,
public LiteCtx normalization, Polynomial construction, NTT ownership, and scale
metadata are copied unchanged from the measured implementation. Encryption,
encode(), _encode_host_array(), and all generic _fast_encode callers remain
outside this experiment.
"""
import inspect
import textwrap
import numpy as np
from jaxite_word import ckks_ctx
from uniform_scalar_codec import try_uniform_array


def try_uniform_context_array(slots, encode_ctx, scale, *, expected_slot_count):
    # encode_at_level currently passes no sparse override: match exactly the
    # LiteCtx slot count that its unchanged _fast_encode call would validate.
    # A private sparse wrapper can pass its explicit slot count separately.
    if type(slots) not in (list, tuple, np.ndarray):
        return None
    try:
        values = np.asarray(slots)
        if values.ndim != 1 or values.size != expected_slot_count:
            return None
    except (TypeError, ValueError):
        return None
    # The guarded routine only accepts real uniform values. Non-real inputs
    # delegate, so the original allow_complex=False boundary retains its
    # exact TypeError (private allow_complex=True callers remain separate).
    return try_uniform_array(
        slots, 2 * encode_ctx.degree, encode_ctx.q_towers, [], scale,
        noise_scale_degree=1,
        max_bits_in_word=encode_ctx.parameters.get('max_bits_in_word',61),
        max_bits_value=encode_ctx.parameters.get('max_bits_value',(1<<63)-(1<<9)-1))


source = textwrap.dedent(inspect.getsource(ckks_ctx.CKKSContext.encode_at_level))
old = 'encoded_rns = _fast_encode(slots, encode_ctx, scale=actual_scale)'
new = '''encoded_rns = try_uniform_context_array(
      slots, encode_ctx, actual_scale, expected_slot_count=encode_ctx.num_slots)
  if encoded_rns is None:
    encoded_rns = _fast_encode(slots, encode_ctx, scale=actual_scale)'''
assert source.count(old) == 1
namespace = dict(vars(ckks_ctx), try_uniform_context_array=try_uniform_context_array)
exec(compile(source.replace(old,new), __file__ + ':isolated_encode_at_level', 'exec'), namespace)
encode_at_level = namespace['encode_at_level']
