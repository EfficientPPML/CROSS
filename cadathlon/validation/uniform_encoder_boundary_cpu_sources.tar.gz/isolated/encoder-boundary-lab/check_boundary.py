import sys,time,json,hashlib,warnings
from pathlib import Path
sys.path[:0]=['/tmp/encoder-boundary-lab','/tmp/refresh-scalar-lab-v2','/home/jianming_gatech/CROSS','/home/jianming_gatech/CROSS/cadathlon/common']
import numpy as np,jax
from jaxite_word import CKKSContext,key_gen,util,he_params,ckks_ctx
from jaxite_word.composite_prime_gen import composite_prime_gen
from encoder_boundary import encode_at_level,namespace
ROOT=Path('/home/jianming_gatech/CROSS');LAB=Path('/tmp/encoder-boundary-lab')
files=[Path(__file__),LAB/'encoder_boundary.py',Path('/tmp/refresh-scalar-lab-v2/uniform_scalar_codec.py'),*sorted((ROOT/'jaxite_word').rglob('*.py'))]
hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
jax.config.update('jax_enable_x64',True);assert jax.default_backend()=='cpu'
start=time.perf_counter();N=16384;depth=6;dnum=8
q=composite_prime_gen(2,2*(depth+1),61,44,2*N,31);p=util.generate_p_towers(q,dnum,N,aux_bits=30)
assert he_params.qp_is_secure(q,p,N,he_params.SecurityTarget(128,'classical'))
k=key_gen.gen_pke_pair(q,[],N);ek=key_gen.gen_evaluation_key(k['secret_key'],q=q,P=p,dnum=dnum)
S=float(q[-2])*q[-1];params=dict(degree=N,num_slots=N//2,scaling_factor=S,output_scale=S,q_towers=q,p_towers=p,composite_degree=2,degree_layout=(128,128),p=44,CKKS_M_FACTOR=1,max_bits_in_word=61,noise_scale_degree=1)
ctx=CKKSContext(dict(params,evaluation_key=[jax.numpy.asarray(ek[name],dtype='uint32').transpose(0,2,1) for name in ('a','b')]))
ctx.program_initialization([],dnum=dnum,r=128,c=128,batch=1)
counts=[];real_fast=namespace['_fast_encode']
def fallback(*args,**kwargs):
 counts.append(True);return real_fast(*args,**kwargs)
namespace['_fast_encode']=fallback
records=[]
def outcome(fn,*args,**kwargs):
 with warnings.catch_warnings(record=True) as notices:
  warnings.simplefilter('always')
  try:result=fn(*args,**kwargs);error=None
  except Exception as exc:result=None;error=(type(exc).__name__,str(exc))
 return result,error,[(w.category.__name__,str(w.message)) for w in notices]
def check(label,slots,level,scale=None,route=None,context=ctx):
 before=len(counts);actual,ae,aw=outcome(encode_at_level,context,slots,level,scale)
 used_fallback=len(counts)>before
 expected,ee,ew=outcome(CKKSContext.encode_at_level,context,slots,level,scale)
 assert ae==ee,(label,ae,ee);assert aw==ew,(label,aw,ew)
 if ae is None:
  np.testing.assert_array_equal(actual.polynomial,expected.polynomial)
  assert actual._ckks_scale==expected._ckks_scale
  assert tuple(actual.moduli)==tuple(expected.moduli)
  assert actual.shape==expected.shape and actual.degree_layout==expected.degree_layout
  assert actual.ntt_ctx is expected.ntt_ctx
  assert actual.__dict__.keys()==expected.__dict__.keys()
 if route is not None:assert used_fallback==(route=='fallback'),(label,used_fallback,route)
 records.append(dict(label=label,level=repr(level),slots=len(slots),scale=repr(scale),route='fallback' if used_fallback else ('boundary_error' if ae else 'uniform'),error=ae,warnings=aw))
for level in (0,1,3,6):
 for scalar in (-14.2,-3e-6,-0.,.75):
  for scale in (None,S,S*S,2.**120):check('initialized_level',np.full(N//2,scalar),level,scale,route='uniform')
for word in (1,31,61,61.5,62,0,-1):
 ctx.parameters['max_bits_in_word']=word
 check('context_word_parameter',np.full(N//2,-.75),3,S*S,route='uniform' if 1<=int(word)<=61 else 'fallback')
ctx.parameters['max_bits_in_word']=61
for bound in (127,2**61-1,2**64,0,-1):
 ctx.parameters['max_bits_value']=bound
 check('context_bound_parameter',np.full(N//2,-.75),3,S,route='fallback')
ctx.parameters.pop('max_bits_value')
for slots in ([.75]*128,[.75]*(N//2-1),[.75]*3,[],np.full((1,N//2),.75),[1j]*(N//2),['.75']*(N//2),np.linspace(-.75,.75,N//2)):
 check('boundary_vector',slots,3,S,route='fallback')
for level in (-1,7,1.5,'1',np.int64(1),True):check('level_contract',[.75]*(N//2),level,S)
for scale in (-1.,0.,np.float64(np.nextafter(0.,1.)),float('nan'),float('inf'),1<<20):
 check('scale_contract',[.75]*(N//2),3,scale,route='fallback')
with np.errstate(all='raise'):
 check('floating_error_policy',[.75]*(N//2),3,S,route='fallback')
uninitialized=CKKSContext(params)
check('uninitialized_context',[.75]*(N//2),3,S,context=uninitialized)
# Private sparse constants remain separate; they must not broaden this public
# encoder boundary merely because the shared codec can represent a period.
assert any(r['label']=='boundary_vector' and r['slots']==128 and r['error'] for r in records)
assert hashes=={str(path):hashlib.sha256(Path(path).read_bytes()).hexdigest() for path in hashes}
report=dict(passed=True,scope='Isolated initialized encode_at_level boundary parity, no production integration or encrypted model/TPU speed claim',degree=N,depth=depth,dnum=dnum,num_q=len(q),num_p=len(p),actual_ring_128_classical=True,cases=len(records),uniform_cases=sum(r['route']=='uniform' for r in records),fallback_cases=sum(r['route']=='fallback' for r in records),source_hashes=hashes,source_hashes_unchanged=True,total_seconds=time.perf_counter()-start,records=records)
(LAB/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ('records','source_hashes')}))
