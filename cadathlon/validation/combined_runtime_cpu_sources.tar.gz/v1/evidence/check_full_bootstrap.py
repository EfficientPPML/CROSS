"""INSECURE N=256 arithmetic regression only; never a security-profile proof."""
import copy
import hashlib
import json
from pathlib import Path
import sys
import time
from unittest import mock

ROOT = Path(__file__).resolve().parents[1] / 'checkout'
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT/'cadathlon/common'))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import jax
import numpy as np
from jaxite_word import CKKSContext, he_params, key_gen, util, ckks_ctx
from jaxite_word.bootstrapping import Bootstrap
from jaxite_word.composite_prime_gen import composite_prime_gen
from encrypted_refresh import _install_compiled_primitives as install_compiled_primitives

source_paths=list((ROOT/'jaxite_word').glob('*.py'))+list((ROOT/'cadathlon/common').glob('*.py'))+list(Path(__file__).resolve().parent.glob('*.py'))
def source_hashes(): return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths}
before=source_hashes()
jax.config.update('jax_enable_x64', True)
degree, dnum, depth = 256, 8, 22
q = composite_prime_gen(2, 2*(depth+1), 61, 56, 2*degree, 31)
p = util.generate_p_towers(q, dnum, degree, aux_bits=30)
scale = float(q[-2])*q[-1]
indices = Bootstrap.required_rotation_indices(degree, 4, (2,2))
keys = key_gen.gen_pke_pair(q, [], degree)
evaluation = key_gen.gen_evaluation_key(keys['secret_key'], q=q, P=p, dnum=dnum)
rotations = {index:key_gen.gen_rotation_key(keys['secret_key'], q,p,index,dnum=dnum)[index] for index in indices}
params = dict(degree=degree, num_slots=degree//2, scaling_factor=scale, output_scale=scale,
              q_towers=q,p_towers=p,composite_degree=2,degree_layout=(16,16),p=56,
              CKKS_M_FACTOR=1,max_bits_in_word=61,noise_scale_degree=1)
client = CKKSContext(dict(params,**keys))
server = CKKSContext(dict(params,evaluation_key=[jax.numpy.asarray(evaluation[n],dtype='uint32').transpose(0,2,1) for n in ('a','b')]))
server.program_initialization(list(indices),dnum=dnum,r=16,c=16,batch=1,pregenerated_rotation_keys=rotations)
assert server.secret_key is None and server._param_cache.secret_key is None
values = np.tile([-.75,-.25,.25,.75],degree//8)
encrypted = client.encrypt_slots(values)
depleted = server.he_level_reduce[depth,1].level_reduce(encrypted)

def engine():
    view=copy.copy(server)
    view.num_slots=4
    bs=Bootstrap(view)
    bs._low_mem=True
    bs.control_gen(level_budget=[2,2])
    bs.setup_key()
    return bs

started=time.perf_counter()
with mock.patch.object(ckks_ctx, '_try_uniform_real_encode', return_value=None):
    baseline=engine()
    expected=baseline.bootstrap(depleted)
jax.block_until_ready(expected.polynomial)
expected_array=np.asarray(expected.polynomial).copy()
eager_seconds=time.perf_counter()-started
print('baseline_seconds',eager_seconds,flush=True)

# This test-only patch allows the compiler arithmetic to be exercised on the
# same explicitly insecure tiny fixture used by the core bootstrap unit tests.
# Production SecureRefresh guards and all real security proofs remain intact.
with mock.patch.object(he_params,'qp_is_secure',return_value=True):
    optimized=engine()
    rotation,relinearization,rescale,plaintext,tensor=install_compiled_primitives(optimized,server)
    timings=[]
    counts=[]
    for repetition in range(2):
        began=time.perf_counter()
        actual=optimized.bootstrap(depleted)
        jax.block_until_ready(actual.polynomial)
        np.testing.assert_array_equal(actual.polynomial,expected_array)
        assert actual._ckks_scale == expected._ckks_scale
        assert actual._ckks_nsd == expected._ckks_nsd
        counts.append([rotation.compile_count,relinearization.compiler.compile_count, rescale.compiler.compile_count, plaintext.compiler.compile_count,tensor.compiler.compile_count])
        timings.append(time.perf_counter()-began)
        print('optimized',repetition,timings[-1],counts[-1],flush=True)
    assert counts[0] == counts[1],counts
report=dict(passed=True,scope='Insecure N256 arithmetic parity only; not a deployment or security proof.',
            degree=degree,depth=depth,dnum=dnum,period=4,backend=jax.default_backend(),
            raw_ciphertext_bit_exact=True,scale_and_nsd_exact=True,source_sha256=before,source_unchanged=source_hashes()==before,
            eager_seconds=eager_seconds,optimized_seconds=timings,compile_counts=counts)
assert report['source_unchanged'], 'combined source changed during proof'
assert report['backend']=='cpu'
Path(__file__).with_name('bootstrap_report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:value for key,value in report.items() if key!='source_sha256'}),flush=True)
