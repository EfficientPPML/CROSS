"""Own/reap the isolated arithmetic-only bootstrap subprocess and provenance."""
import sys,os,json,time,hashlib,subprocess,platform
from pathlib import Path
LAB=Path(__file__).resolve().parents[1];ROOT=LAB/'checkout';OUT=LAB/'evidence'
assert os.environ.get('JAX_PLATFORMS')=='cpu'
def hashes():
 paths=[p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts and p.suffix in ('.py','.json','.in','.out')]
 paths += list(OUT.glob('*.py'))+list(OUT.glob('*.patch'))
 return {str(p.relative_to(LAB)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
before=hashes();started=time.monotonic()
record=dict(passed=False,scope='Insecure N256 complete bootstrap arithmetic regression only; not a secure refresh or model performance claim',source_sha256=before,affinity=sorted(os.sched_getaffinity(0)),python=platform.python_version())
with (OUT/'bootstrap.log').open('w') as log:
 process=subprocess.Popen([sys.executable,str(OUT/'check_full_bootstrap.py')],cwd=ROOT,env=dict(os.environ,CROSS_ROOT=str(ROOT),PYTHONPATH=str(ROOT),JAX_PLATFORMS='cpu',PYTHONUNBUFFERED='1'),stdout=log,stderr=subprocess.STDOUT)
 record['pid']=process.pid;(OUT/'bootstrap_process.json').write_text(json.dumps(record,indent=2)+'\n')
 try:code=process.wait()
 except BaseException:
  process.terminate()
  try:process.wait(timeout=5)
  except subprocess.TimeoutExpired:process.kill();process.wait()
  raise
record.update(returncode=code,elapsed_s=time.monotonic()-started,source_sha256_after=hashes())
record['source_files_unchanged']=before==record['source_sha256_after']
path=OUT/'bootstrap_report.json'
if path.exists():
 result=json.loads(path.read_text());record['passed']=code==0 and result.get('passed') is True and result.get('source_unchanged') is True and result.get('backend')=='cpu' and record['source_files_unchanged']
(OUT/'bootstrap_process.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({key:value for key,value in record.items() if key not in ('source_sha256','source_sha256_after')}),flush=True)
raise SystemExit(0 if record['passed'] else 1)
