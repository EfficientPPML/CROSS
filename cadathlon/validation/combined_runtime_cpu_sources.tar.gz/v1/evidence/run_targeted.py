"""Isolated combined-candidate CPU suite with before/after source evidence."""
import sys,os,json,time,hashlib,platform,resource
from pathlib import Path
import importlib.metadata
LAB=Path(__file__).resolve().parents[1];ROOT=LAB/'checkout';OUT=LAB/'evidence'
assert os.environ.get('JAX_PLATFORMS')=='cpu'
os.environ['CROSS_ROOT']=str(ROOT)
os.environ['CROSS_TEST_SECURE_POLYNOMIAL']='1'
os.environ.pop('CROSS_TEST_SECURE_REFRESH',None);os.environ.pop('CROSS_TEST_BOUNDED_REFRESH',None)
sys.path[:0]=[str(ROOT),str(ROOT/'cadathlon/common')]
os.chdir(ROOT)
def hashes():
 paths=[p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts and p.suffix in ('.py','.json','.in','.out')]
 paths += list(OUT.glob('*.py'))+list(OUT.glob('*.patch'))
 return {str(p.relative_to(LAB)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
before=hashes();started=time.monotonic();records=[]
class Recorder:
 def pytest_runtest_logreport(self,report):
  if report.when=='call' or (report.when=='setup' and report.outcome!='passed'):
   records.append(dict(nodeid=report.nodeid,outcome=report.outcome,seconds=report.duration,phase=report.when))
import pytest
paths=['jaxite_word/codec_preparation_test.py','jaxite_word/uniform_encoding_test.py']
paths += ['cadathlon/tests/'+name+'.py' for name in (
 'test_encrypted_compilation','test_encrypted_rotation','test_encrypted_tensor_only',
 'test_encrypted_primitives','test_encrypted_refresh','test_refresh_validation',
 'test_encrypted_polynomial','test_encrypted_reference_lifecycle','test_transformer_layout',
 'test_transformer_runner','test_packed_qwen','test_packed_transformer',
 'test_bounded_contracts','test_bounded_shared_preparation','test_bounded_reference_preflight',
 'test_bounded_transformer_plan','test_encrypted_bounded_metadata')]
code=int(pytest.main(['-q','--tb=short',*paths],plugins=[Recorder()]))
after=hashes()
from jaxite_word import ckks_ctx
import encrypted_rotation,encrypted_primitives,encrypted_refresh,encrypted_reference,encrypted_bounded_transformer
origins={m.__name__:str(Path(m.__file__).resolve()) for m in (ckks_ctx,encrypted_rotation,encrypted_primitives,encrypted_refresh,encrypted_reference,encrypted_bounded_transformer)}
assert all(Path(path).is_relative_to(ROOT) for path in origins.values()),origins
report=dict(passed=code==0 and before==after,pytest_exit_code=code,source_files_unchanged=before==after,
 scope='Combined isolated candidate CPU tests; secure component tests enabled; large secure bootstrap remains skipped; no TPU/full-model performance claim',
 backend='cpu',affinity=sorted(os.sched_getaffinity(0)),python=platform.python_version(),
 versions={name:importlib.metadata.version(name) for name in ('jax','jaxlib','numpy','torch')},
 seconds=time.monotonic()-started,max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
 source_sha256=before,source_sha256_after=after,module_origins=origins,tests=records,
 counts={outcome:sum(r['outcome']==outcome for r in records) for outcome in ('passed','failed','skipped')})
(OUT/'targeted_report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('source_sha256','source_sha256_after','tests','module_origins')}),flush=True)
raise SystemExit(0 if report['passed'] else 1)
