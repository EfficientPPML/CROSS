import sys,os,json,time,hashlib
from pathlib import Path
LAB=Path(__file__).resolve().parents[1];ROOT=LAB/'checkout';OUT=LAB/'evidence'
assert os.environ.get('JAX_PLATFORMS')=='cpu';os.environ['CROSS_ROOT']=str(ROOT)
sys.path[:0]=[str(ROOT),str(ROOT/'cadathlon/common')];os.chdir(ROOT)
def hashes():
 paths=[p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts and p.suffix in ('.py','.json','.in','.out','.golden','.md')]
 paths+=list(OUT.glob('*.py'))
 return {str(p.relative_to(LAB)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
before=hashes();started=time.monotonic();tests=[]
class Recorder:
 def pytest_runtest_logreport(self,report):
  if report.when=='call' or (report.when=='setup' and report.outcome!='passed'):tests.append(dict(nodeid=report.nodeid,outcome=report.outcome,seconds=report.duration,phase=report.when))
import pytest
names=('test_encrypted_reference_lifecycle','test_transformer_layout','test_transformer_runner','test_packed_qwen','test_packed_transformer','test_bounded_contracts','test_bounded_shared_preparation','test_bounded_reference_preflight','test_bounded_transformer_plan','test_encrypted_bounded_metadata')
code=int(pytest.main(['-q','--tb=short',*['cadathlon/tests/'+name+'.py' for name in names]],plugins=[Recorder()]))
after=hashes();repair=json.loads((OUT/'resource_repair.json').read_text())
report=dict(passed=code==0 and before==after,pytest_exit_code=code,scope='Repaired-resource bounded/packed/lifecycle subset only; overlaps full v1 suite and must not be added to its count',
 backend='cpu',affinity=sorted(os.sched_getaffinity(0)),seconds=time.monotonic()-started,source_files_unchanged=before==after,source_sha256=before,source_sha256_after=after,
 runtime_source_equal_to_v1=repair['runtime_source_equal'],tests=tests,counts={outcome:sum(t['outcome']==outcome for t in tests) for outcome in ('passed','failed','skipped')})
(OUT/'subset_report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ('source_sha256','source_sha256_after','tests')}),flush=True)
raise SystemExit(0 if report['passed'] else 1)
