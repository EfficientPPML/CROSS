"""Fixed public circuit and independent oracle; no encrypted or model run."""
import copy,hashlib,json,math
from pathlib import Path
import numpy as np
import pytest
import plan,public_graph as graph
from protocol import PhaseLedger

@pytest.fixture(scope='module')
def result():return plan.derive()

def test_exact_predecessor_and_case(result):
 assert len(plan.source_gate())==199
 assert result['case_sha256']==hashlib.sha256((graph.ROOT/'cadathlon/agent_pset/p2_bert/test/test4.in').read_bytes()).hexdigest()
 assert result['case']['config']['hidden_size']==24 and result['packing']==dict(batch=2,sequence=8,feature_width=64,period=8192,replicas=8)

def test_all96_independent_allslot_references_and_domains(result):
 assert result['checkpoint_count']==96 and result['all_slot_reference_comparisons']==96*65536
 assert result['independent_all_slot_reference_max_error']<1e-10
 assert all(x['public_reference_error']<1e-10 for x in result['checkpoints'])
 assert len(result['polynomial_domains'])==11 and all(x['passed'] for x in result['polynomial_domains'])
 assert result['ideal_final_toy_gate_passed'] and result['ideal_max_logit_error']<.003

def test_exact_refresh_depth_coefficients_and_scale(result):
 assert result['graph_depth']==93
 assert result['refresh_bounds']==[16.,8.,2.,4.,8.]
 assert [(x['input_level'],x['output_level'],x['required'])for x in result['refresh_events']]==[(2,25,1),(2,25,1),(3,25,3),(2,25,5),(2,25,2)]
 assert result['checkpoints'][-1]['level']==11
 assert all(x['strategy']=='power' for x in result['coefficients'].values())
 assert result['ideal_counts']==dict(add=228,weighted=168,multiply=61)
 assert all(type(x['scale'])is float and math.isfinite(x['scale']) and x['nsd']==1 for x in result['checkpoints'])

@pytest.mark.parametrize('direction',[-1,1])
def test_refresh_actual_adjacent_scale_is_propagated_without_relabel(direction):
 canonical=float(68994011570896900);target=float(np.nextafter(canonical,-np.inf if direction<0 else np.inf))
 r=graph.run(refresh_scale=target)
 assert len(r['refreshes'])==5 and all(x['scale']==target for x in r['trace']if x['kind']=='refresh_after')
 assert r['original_toy_clear_gate_passed'] and r['trace'][-1]['level']==11
 # Payload identity is deliberately a stand-in, not a refreshed CKKS claim.
 for index,row in enumerate(r['trace']):
  if row['kind']=='refresh_before':assert np.array_equal(r['values'][index],r['values'][index+1])

def test_actual199_key_union_and_public_security_arithmetic(result):
 q=result['profile']['q_towers'];p=result['profile']['p_towers'];partitions=[q[i:i+25]for i in range(0,100,25)]
 assert len(q)==100 and len(p)==24 and len(partitions)==4
 assert math.prod(p)>=max(map(math.prod,partitions)) and math.prod(q+p).bit_length()<=3523
 assert len(result['graph_rotation_indices'])==41 and len(result['bootstrap_rotation_indices'])==172
 assert result['required_rotation_indices']==sorted(set(result['graph_rotation_indices'])|set(result['bootstrap_rotation_indices']))
 assert len(result['required_rotation_indices'])==199 and 262143 in result['required_rotation_indices']

def test_storage_is_explicit_raw_payload_budget_not_peak(result):
 s=result['storage'];assert s['one_rotation_pair_bytes']==2*4*124*131072*4
 assert s['raw_rotation_bytes']==199*s['one_rotation_pair_bytes']
 assert s['checkpoint_raw_payload_bytes']==sum(2*131072*2*(r['level']+1)*4 for r in result['checkpoints'])==3758096384
 assert s['checkpoint_disk_budget_bytes']==4832624640
 assert s['maximum_single_checkpoint_payload_bytes']==104857600 and s['not_a_peak_claim']

def test_failed_predecessor_remains_a_failure():
 raw=json.loads((plan.P/'failed_checkpoint/stdout.json').read_bytes())
 assert 'ApproximationErrorTooHigh' in json.dumps(raw) and 'inf' in json.dumps(raw)
 security=json.loads((plan.P/'failed_checkpoint/security_device.json').read_bytes())
 assert security['passed'] is False

def test_predecessor_tamper_rejected(tmp_path,monkeypatch):
 before=json.loads((plan.P/'predecessor.json').read_bytes());(tmp_path/'predecessor.json').write_text(json.dumps(before));root=tmp_path/'predecessor';root.mkdir()
 # No fallback or historical-plan-only authentication if actual source is absent.
 monkeypatch.setattr(plan,'P',tmp_path)
 with pytest.raises(FileNotFoundError):plan.source_gate()

@pytest.fixture
def ledger(result):return PhaseLedger(result['checkpoints'])
def save_all(ledger,result):
 for x in result['checkpoints']:
  ledger.saved(x['index'],kind=x['kind'],label=x['label'],level=x['level'],scale=x['scale'],actual_expected_scale=x['scale'],nsd=1,sha256='a'*64)

def test_all_server_work_precedes_any_decode(ledger,result):
 with pytest.raises(ValueError):ledger.decode(0)
 save_all(ledger,result)
 with pytest.raises(ValueError):ledger.decode(0)
 ledger.seal(source_verified=True,keyless_verified=True,server_group_absent=True)
 assert [ledger.decode(i)for i in range(96)]==[(i,'a'*64)for i in range(96)]

@pytest.mark.parametrize('field,value',[('source_verified',False),('keyless_verified',False),('server_group_absent',False),('source_verified',1)])
def test_seal_rejects_unknown_incomplete_or_typed_alias(ledger,result,field,value):
 save_all(ledger,result);args=dict(source_verified=True,keyless_verified=True,server_group_absent=True);args[field]=value
 with pytest.raises(ValueError):ledger.seal(**args)
 with pytest.raises(ValueError):ledger.decode(0)

@pytest.mark.parametrize('field,value',[('index',True),('index',1),('level',49.),('level',True),('nsd',True),('nsd',1.),('scale',float('nan')),('scale',float('inf')),('scale',0.),('actual_expected_scale',1.),('sha256','bad')])
def test_checkpoint_order_actual_scale_and_metadata_fail_closed(ledger,result,field,value):
 row=result['checkpoints'][0];args=dict(index=0,kind=row['kind'],label=row['label'],level=row['level'],scale=row['scale'],actual_expected_scale=row['scale'],nsd=1,sha256='a'*64);args[field]=value
 with pytest.raises(ValueError):ledger.saved(**args)
 assert ledger.position==0 and not ledger.receipts

def test_failure_never_grants_private_decode(ledger,result):
 save_all(ledger,result);ledger.fail()
 with pytest.raises(ValueError):ledger.decode(0)
 with pytest.raises(ValueError):ledger.seal(source_verified=True,keyless_verified=True,server_group_absent=True)
