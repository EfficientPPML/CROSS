from pathlib import Path
from fractions import Fraction as F
import copy,json
import numpy as np
import pytest
from certificate import derive,rounded_inverse_contract
from frozen_approximate import Arithmetic
M=json.loads((Path(__file__).parent/'candidate_manifest.json').read_text())
def unpack(x):return F(*map(int,x))

def test_base_bound_has_whole_domain_and_rounding_bytes():
    r=derive(M);a=list(map(lambda x:F(float.fromhex(x)),r['actual_power_coefficients']));radius=F(17,32)
    assert unpack(r['base_absolute_upper'])==sum(abs(x)*radius**i for i,x in enumerate(a))<1
    assert r['base_actual_power_degree']==11 and r['base_degree']==12
    for t in (-radius,F(-1,2),F(-1,8),F(),F(1,8),F(1,2),radius):
        value=F()
        for c in reversed(a):value=value*t+c
        assert abs(value)<=unpack(r['base_absolute_upper'])

@pytest.mark.parametrize('denominator',[F(1),F(5,4),F(3,2),F(2),F(2.1)])
def test_actual_first_affine_and_original_count_exact(denominator):
    r=rounded_inverse_contract(M['tanh_reciprocal']);w,b=unpack(r['first_weight']),unpack(r['first_bias']);y=w*denominator+b
    residual=1-denominator*y
    assert abs(residual)<=unpack(r['first_residual_absolute_upper'])
    for _ in range(4):
        y=y*(2-denominator*y);residual=residual*residual
        assert 1-denominator*y==residual and 0<y<=1/denominator
    assert residual<=unpack(r['final_residual_upper'])

@pytest.mark.parametrize('y',[F(-1),F(-7,8),F(-1,4),F(),F(1,4),F(7,8),F(1)])
def test_exact_single_round_preserves_unit_bound(y):
    d=1+y*y;r=rounded_inverse_contract(M['tanh_reciprocal']);inverse=unpack(r['first_weight'])*d+unpack(r['first_bias'])
    for _ in range(4):inverse*=2-d*inverse
    assert abs(2*y*inverse)<=1 and 1<=1+(2*y*inverse)**2<=2

def test_unmodified_float_analogue_diagnostic_without_fitting():
    engine=Arithmetic(M);x=np.linspace(-34.,34.,8193)
    out=engine.tanh(x,M['tanh'],'fixed_public_probe')
    assert np.isfinite(out).all() and np.max(np.abs(out))<2
    assert len(engine.observations)==8
    assert all(not (v['below'] or v['above'] or v['nonfinite']) for v in engine.observations.values())

@pytest.mark.parametrize('change',[('doublings',5),('base_degree',11),('reciprocal_iterations',4),('domain',[-35,35])])
def test_frozen_contract_change_rejected(change):
    m=copy.deepcopy(M);m['tanh'][change[0]]=change[1]
    with pytest.raises(ValueError):derive(m)

def test_doubling_induction_has_six_fixed_original_counts():
    r=derive(M);assert len(r['rounds'])==6
    assert all(v['inverse_iterations']==5 and v['refresh_bound']==2 and unpack(v['output_absolute_upper'])==1 and unpack(v['guarded_output_upper'])==F(9,8) for v in r['rounds'])


def test_conditional_refresh_error_margin_is_not_a_B2_domain_claim():
    r=derive(M);p=r['conditional_refresh_perturbation']
    assert unpack(p['refreshed_absolute_upper'])==1+unpack(p['additive_error_upper'])
    assert 1+unpack(p['refreshed_absolute_upper'])**2==unpack(p['next_denominator_upper'])<F(2.1)
    assert not p['measured_or_certified_CKKS_error']
    assert 1+F(9,8)**2>F(2.1) # Generic bootstrap headroom alone is insufficient.

def test_actual_base_coefficients_match_unchanged_analogue():
    r=derive(M);engine=Arithmetic(M)
    power=engine.coefficients[M['tanh']['base_polynomial']['coefficient_f64le_sha256']][1]
    assert [float(x).hex() for x in power]==r['actual_power_coefficients']
