"""Conditional exact-real B2 envelope for the unchanged BERT-v2 rational tanh."""
from fractions import Fraction as F
import hashlib,math
import numpy as np

def scalar(x):return F(float(x))
def fraction(x):x=F(x);return [str(x.numerator),str(x.denominator)]
def upper(x):
    out=float(x)
    if F(out)<x:out=math.nextafter(out,math.inf)
    return out

def rounded_inverse_contract(rule):
    a,b=map(scalar,rule['domain']);seed=float(rule['seed']);n=rule['iterations']
    if not 0<a<=b or type(n)is not int or n<2:raise ValueError('positive static reciprocal domain and at least2 updates required')
    w,bias=scalar(-seed*seed),scalar(2*seed)
    if w>=0:raise ValueError('frozen first reciprocal slope must be negative')
    points=[a,b];vertex=-bias/(2*w)
    if a<=vertex<=b:points.append(vertex)
    residual=lambda x:1-x*(w*x+bias)
    bound=max(abs(residual(x)) for x in points)
    if not bound<1 or min(w*a+bias,w*b+bias)<=0:raise ValueError('positive first inverse and strict residual contraction required')
    final=bound**(2**(n-1))
    return dict(domain=[fraction(a),fraction(b)],first_weight=fraction(w),first_bias=fraction(bias),
        candidates=[fraction(x) for x in points],first_residual_absolute_upper=fraction(bound),
        final_residual_upper=fraction(final),final_residual_upper_f64=upper(final),iterations=n,
        final_inverse_positive=True,final_inverse_le_reciprocal=True,
        scope='Rounded public first affine followed by exact-real original Newton updates; later floating/encoding/CKKS errors excluded.')

def derive(manifest):
    rule=manifest['tanh'];poly=rule['base_polynomial'];reciprocal=manifest['tanh_reciprocal']
    if (rule['domain']!=[-34,34] or rule['base_degree']!=12 or rule['doublings']!=6 or rule['reciprocal_iterations']!=5
            or poly['domain']!=[-1.,1.] or poly['degree']!=12 or reciprocal['domain']!=[1.,2.1] or reciprocal['iterations']!=5):raise ValueError('frozen tanh contract differs')
    cheb=np.asarray(poly['coefficients'],dtype='<f8')
    if hashlib.sha256(cheb.tobytes()).hexdigest()!=poly['coefficient_f64le_sha256']:raise ValueError('frozen base coefficient hash differs')
    power=np.polynomial.chebyshev.cheb2poly(cheb)
    scale=F(1,2**rule['doublings']);lo,hi=map(float,poly['domain'])
    A=scalar(2/(hi-lo));B=scalar(-(hi+lo)/(hi-lo))
    endpoints=[A*scalar(x)*scale+B for x in rule['domain']];radius=max(map(abs,endpoints))
    base=sum(abs(scalar(c))*radius**n for n,c in enumerate(power))
    if not base<1:raise ValueError('base absolute envelope must be below1')
    inverse=rounded_inverse_contract(reciprocal);a,b=map(lambda x:F(*map(int,x)),inverse['domain'])
    rounds=[];bound=base
    for step in range(6):
        denominator_upper=1+bound*bound
        if not a<=1<=denominator_upper<=b:raise ValueError('shared-square denominator exceeds frozen inverse domain')
        rounds.append(dict(round=step+1,input_absolute_upper=fraction(bound),
            denominator_domain=[fraction(F(1)),fraction(denominator_upper)],
            output_absolute_upper=fraction(F(1)),guarded_output_upper=fraction(F(9,8)),refresh_bound=2,
            inverse_iterations=5,denominator_inside_original_contract=True))
        bound=F(1)
    return dict(base_degree=12,base_actual_power_degree=len(power)-1,input_domain=rule['domain'],doublings=6,
        base_input_scale=fraction(scale),rounded_map_A=fraction(A),rounded_map_B=fraction(B),actual_mapped_endpoints=[fraction(x) for x in endpoints],
        base_coefficient_sha256=poly['coefficient_f64le_sha256'],actual_power_coefficients=[float(x).hex() for x in power],
        actual_power_coefficient_sha256=hashlib.sha256(power.astype('<f8').tobytes()).hexdigest(),
        base_absolute_upper=fraction(base),base_absolute_upper_f64=upper(base),base_guarded_upper=fraction(base*F(9,8)),
        base_refresh_bound=2,conditional_refresh_perturbation=dict(additive_error_upper=fraction(F(1,32)),refreshed_absolute_upper=fraction(F(33,32)),next_denominator_upper=fraction(F(2113,1024)),measured_or_certified_CKKS_error=False,premise='An independently established absolute refresh error<=1/32 around an ideal unit-bounded iterate; subsequent square/numerator share that disturbed value and all arithmetic is exact.'),reciprocal=inverse,rounds=rounds,all_refreshed_iterates_fit_B2_with_9_over_8=True,
        original_input_domain_certified=False,shared_square_required=True,HE_error_certified=False,
        proof='For base t=A*(x/64)+B, |P(t)|<=sum|a_n|M^n<1. The rounded first reciprocal affine has |r1|<1; after4 original Newton updates0<=r5<=R^16<1. Hence0<inverse<=1/d. For d=1+y², |2y*inverse|<=2|y|/(1+y²)<=1, so next d lies in[1,2] subset of unchanged[1,2.1].',
        excludes=['No claim that pooler dense outputs on arbitrary/approximate/encrypted inputs lie in the original[-34,34] contract.',
                  'Refresh must preserve the bound and shared-square relation within a separately justified error allowance; this proof does not certify that perturbation.',
                  'No actual floating-point, encoding, CKKS, refresh accuracy, sign/relative tanh error or classifier/logit gate is certified.',
                  'No coefficients, method, original five-update stopping count or six doublings are changed.'])
