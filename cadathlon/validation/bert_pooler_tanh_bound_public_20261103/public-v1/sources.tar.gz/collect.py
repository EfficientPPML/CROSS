"""Source-bound public rational-tanh certificate and tests; no HE or model."""
from pathlib import Path
import hashlib,io,json,os,subprocess,sys,tarfile,time
import numpy as np
from certificate import derive
HERE=Path(__file__).resolve().parent
SHA='4e2277beea7189aa1d77b168c500c8a175f6c630afa520fcc6b38cb5a179cff9'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    out=HERE/'public-v1';out.mkdir(exist_ok=False);started=time.monotonic();paths=[*HERE.glob('*.py'),HERE/'candidate_manifest.json']
    before={p.name:digest(p) for p in paths};assert before['candidate_manifest.json']==SHA
    with tarfile.open(out/'sources.tar.gz','w:gz') as t:
        for p in paths:b=p.read_bytes();m=tarfile.TarInfo(p.name);m.size=len(b);t.addfile(m,io.BytesIO(b))
    report=dict(passed=False,scope=__doc__,source_hashes_before=before,manifest_sha256=SHA,HE_executed=False,model_evaluated=False,coefficients_changed=False,numpy_version=np.__version__,cpu_affinity=sorted(os.sched_getaffinity(0)))
    try:
        report['certificate']=derive(json.loads((HERE/'candidate_manifest.json').read_text()))
        with (out/'tests.log').open('w') as stream:p=subprocess.run([sys.executable,'-m','pytest','-q','test_certificate.py'],cwd=HERE,stdout=stream,stderr=subprocess.STDOUT)
        report['test_returncode']=p.returncode
        if p.returncode:raise RuntimeError('tests failed')
        if any(n.split('.')[0] in ('torch','transformers','jax','jaxite_word') for n in sys.modules):raise RuntimeError('backend/model unexpectedly imported')
        report['passed']=True
    finally:
        after={p.name:digest(p) for p in paths}
        with tarfile.open(out/'sources.tar.gz') as t:archived={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers()}
        report.update(source_hashes_after=after,source_files_unchanged=before==after==archived,source_archive_sha256=digest(out/'sources.tar.gz'),elapsed_s=time.monotonic()-started)
        report['passed']=report['passed'] and report['source_files_unchanged']
        (out/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    with (out/'verify.log').open('w') as stream:p=subprocess.run([sys.executable,'verify.py',str(out)],cwd=HERE,stdout=stream,stderr=subprocess.STDOUT)
    print(json.dumps(dict(passed=report['passed'] and p.returncode==0,base_bound=report['certificate']['base_absolute_upper_f64'],rounded_inverse_residual=report['certificate']['reciprocal']['final_residual_upper_f64'],elapsed_s=report['elapsed_s'])))
    return 0 if report['passed'] and p.returncode==0 else 1
if __name__=='__main__':raise SystemExit(main())
