"""Actual client input encryption after three externally pinned prerequisites."""
from pathlib import Path
from contextlib import redirect_stdout
import argparse,hashlib,json,os,stat,sys,time
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE/'runtime/stage'),str(HERE/'runtime')]
from cleanup import cleanup_signals,termination_signals
from terminal import terminal_scope
import key_gate,model_gate,boundaries,request_readback


def write(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');tmp.replace(path)
def hashes(expected):
    result={}
    for name in expected:
        path=Path(name)
        if path.is_absolute() or '..' in path.parts:raise ValueError('relative execution source required')
        result[name]=hashlib.sha256((HERE/path).read_bytes()).hexdigest()
    return result

def authenticate(*,key_evidence,key_report_sha256,key_workspace,model_evidence,model_report_sha256,model_workspace,
                 fixture_evidence,fixture_report_sha256,profile_bytes,plan_bytes):
    import input_gate
    keys=key_gate.authenticate(key_evidence,key_report_sha256,key_workspace,profile_bytes=profile_bytes,plan_bytes=plan_bytes)
    model=model_gate.authenticate(model_evidence,model_report_sha256,model_workspace,keys=keys)
    inputs=input_gate.authenticate(fixture_evidence,fixture_report_sha256)
    return keys,model,inputs

def prerequisite_summary(keys,model,inputs):
    return {n:keys[n] for n in ('context_id','key_report_sha256','key_source_archive_sha256')}|{
        n:model[n] for n in ('model_id','model_report_sha256','model_manifest_sha256')}|{
        n:inputs[n] for n in ('input_sha256','fixture_report_sha256','valid_token_count')}

def make_paths(keys,model,inputs,key_workspace,io_workspace):
    import file_stages
    return dict(size=0,batch_size=1,model_id=file_stages.MODEL_ID,model_revision=file_stages.REVISION,
        public_keys=keys['public_keys'],client_private=Path(key_workspace)/'client_private',
        server_data=model['server_data'],preprocessed_input=inputs['preprocessed_input'],
        **{n:Path(io_workspace)/n for n in ('upload','download','server_report','decrypted_results')})

def fresh_paths(paths):
    for name in ('requests.json','completed.json'):
        p=Path(paths['client_private'])/name
        if p.exists() or p.is_symlink():raise FileExistsError('fresh private request/receipt state required')
    for name in ('upload','download','server_report','decrypted_results'):
        p=Path(paths[name])
        if p.exists() or p.is_symlink():raise FileExistsError('fresh owned stage3 I/O paths required')

def remaining(paths):
    result={}
    inventory={n:Path(paths[n]) for n in ('upload','download','server_report','decrypted_results')}|{
        'private_requests':Path(paths['client_private'])/'requests.json','private_completed':Path(paths['client_private'])/'completed.json'}
    for name,path in inventory.items():
        try:info=path.lstat()
        except FileNotFoundError:result[name]=dict(present=False);continue
        result[name]=dict(present=True,device=info.st_dev,inode=info.st_ino,
            kind='directory' if stat.S_ISDIR(info.st_mode) else 'regular' if stat.S_ISREG(info.st_mode) else 'other',size=info.st_size)
    return result


def run(*,key_evidence,key_report_sha256,key_workspace,model_evidence,model_report_sha256,model_workspace,
        fixture_evidence,fixture_report_sha256,io_workspace,snapshot,output,source_manifest):
    start=time.monotonic();primary=None;expected={};calls=[];paths=None;authorized=None
    report=dict(passed=False,scope='Actual size0 client embeddings and encryption plus strict eight-upload readback only; no decryption, encoder/model forward, server compute or accuracy claim.',
        actual_client_encode_started=False,actual_client_encode_completed=False,readback_complete=False,
        decrypt=False,model_forward=False,server_compute=False,pid=os.getpid(),cpu_affinity=sorted(os.sched_getaffinity(0)))
    gate_args=dict(key_evidence=key_evidence,key_report_sha256=key_report_sha256,key_workspace=key_workspace,
        model_evidence=model_evidence,model_report_sha256=model_report_sha256,model_workspace=model_workspace,
        fixture_evidence=fixture_evidence,fixture_report_sha256=fixture_report_sha256)
    try:
        write(output,report)
        if os.environ.get('JAX_PLATFORMS')!='cpu':raise ValueError('explicit CPU client-encryption process required')
        expected=key_gate.parse(key_gate.read(source_manifest));report['source_hashes_start']=hashes(expected)
        if report['source_hashes_start']!=expected:raise ValueError('execution source startup differs')
        profile=(HERE/'runtime/stage/server_inputs/p60_profile_and_refresh.json').read_bytes()
        plan=(HERE/'runtime/stage/server_inputs/twelve_layer_plan.json').read_bytes()
        # All external completion gates precede input and key payload reads.
        authorized=authenticate(**gate_args,profile_bytes=profile,plan_bytes=plan)
        keys,model,inputs=authorized;report['prerequisite']=prerequisite_summary(*authorized)
        paths=make_paths(*authorized,key_workspace,io_workspace);fresh_paths(paths)
        import file_stages,server_public_model
        pins={'model.safetensors':server_public_model.CHECKPOINT_SHA256,'config.json':server_public_model.CONFIG_SHA256}
        assets={n:server_public_model.file_sha(Path(snapshot)/n) for n in pins}
        if assets!=pins:raise ValueError('pinned embedding checkpoint/config differ')
        report['asset_hashes_start']=assets;os.environ['CROSS_BERT_SNAPSHOT']=str(snapshot)
        with boundaries.encryption_only(calls),redirect_stdout(sys.stderr):
            report['actual_client_encode_started']=True;write(output,report)
            result=file_stages.client_encode_encrypt_input(paths)
            report['actual_client_encode_completed']=True
            readback=request_readback.verify(paths,context_id=keys['context_id'],expected_input_sha256=inputs['input_sha256'])
            if (type(result)is not dict or type(result.get('sample_count'))is not int or result['sample_count']!=1
                    or result.get('public_batch_sha256')!=readback['public_batch_sha256'] or readback['sample_count']!=1
                    or readback['tile_count']!=8 or [x['tile'] for x in readback['tiles']]!=list(range(8))
                    or readback['private_binding_verified']is not True or readback['private_request_permissions_verified']is not True):
                raise ValueError('actual handler/eight-tile/private binding differs')
        if calls:raise ValueError('client encryption attempted forbidden action')
        after_assets={n:server_public_model.file_sha(Path(snapshot)/n) for n in pins}
        if after_assets!=assets:raise ValueError('public embedding assets changed during encryption')
        after=authenticate(**gate_args,profile_bytes=profile,plan_bytes=plan)
        if prerequisite_summary(*after)!=report['prerequisite']:raise ValueError('prerequisite identity changed during encryption')
        report.update(passed=True,readback_complete=True,all_eight_ordered_payloads_validated=True,
            keygen_decrypt_native_model_forbidden=True,forbidden_attempts=[],readback=readback,
            asset_hashes_end=after_assets,context_id=keys['context_id'],model_id=model['model_id'])
    except BaseException as error:primary=error;report.update(passed=False,error=dict(type=type(error).__name__,message=str(error)))
    finally:
        with terminal_scope(report,output,write,cleanup_signals,lambda:(primary,None)):
            try:
                after=hashes(expected) if expected else {}
                report.update(source_hashes_end=after,source_files_unchanged=bool(expected) and after==expected,
                    forbidden_attempts=calls,elapsed_s=time.monotonic()-start)
                if paths is not None:report['remaining_artifacts']=remaining(paths)
                report['passed']=bool(report['passed'] and report['source_files_unchanged']);write(output,report)
            except BaseException as error:
                if primary is None:raise
                primary.add_note('stage3 terminal source/publication: '+repr(error))
            if primary is not None:raise primary
    print(json.dumps(dict(passed=report['passed'],context_id=report['context_id'],model_id=report['model_id'],
        public_batch_sha256=report['readback']['public_batch_sha256'],worker_report_sha256=hashlib.sha256(output.read_bytes()).hexdigest(),elapsed_s=report['elapsed_s'])))
    return 0 if report['passed'] else 1

if __name__=='__main__':
    p=argparse.ArgumentParser()
    for name in ('key-evidence','key-workspace','model-evidence','model-workspace','fixture-evidence','io-workspace','snapshot','output','source-manifest'):p.add_argument('--'+name,type=Path,required=True)
    for name in ('key-report-sha256','model-report-sha256','fixture-report-sha256'):p.add_argument('--'+name,required=True)
    args=p.parse_args()
    with termination_signals():exit_code=run(**vars(args))
    raise SystemExit(exit_code)
