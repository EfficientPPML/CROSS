"""Size0 prerequisite rejection order; synthetic private input, no models or HE."""
from pathlib import Path
from types import SimpleNamespace as NS
import io,tarfile
import pytest
import input_gate,key_gate


@pytest.fixture
def case(tmp_path):
    evidence=tmp_path/'evidence';evidence.mkdir()
    workspace=tmp_path/'private';workspace.mkdir(mode=0o700)
    target=workspace/input_gate.INPUT;target.parent.mkdir(parents=True);target.write_bytes(b'private fixture bytes\n');target.chmod(0o600)
    source=b'# fixture\n';pins={'fixture.py':key_gate.digest(source)}
    with tarfile.open(evidence/'sources.tar.gz','w:gz') as t:
        m=tarfile.TarInfo('fixture.py');m.size=len(source);t.addfile(m,io.BytesIO(source))
    files={input_gate.INPUT:key_gate.digest(target.read_bytes())}|{f'other-private-{i}':'a'*64 for i in range(5)}
    report=dict(schema='bert-upstream-size0-input-fixture-v1',passed=True,private_workspace_retained=True,
        sources_unchanged=True,assets_unchanged=True,upstream_originals_unchanged=True,selection_byte_parity=True,
        tokenization_byte_parity=True,model_construction_and_forward_guards=True,private_file_permissions_all_0600=True,
        size=0,base_seed=42,generator_seed=191664963,record_count=1,dataset_record_count=408,
        token_lengths=[128],valid_token_counts=[32],source_hashes_before=pins,source_hashes_after=pins,
        source_archive_sha256=key_gate.digest((evidence/'sources.tar.gz').read_bytes()),
        upstream_original_sha256_before={'upstream.py':'b'*64},upstream_original_sha256_after={'upstream.py':'b'*64},
        asset_file_sha256_before=input_gate.ASSETS,asset_file_sha256_after=input_gate.ASSETS,
        private_workspace=str(workspace),private_workspace_identity=dict(device=workspace.stat().st_dev,inode=workspace.stat().st_ino),
        input_file_sha256=files,preprocessed_input_path=str(target))
    def publish():
        raw=key_gate.canonical(report);(evidence/'report.json').write_bytes(raw);return key_gate.digest(raw)
    return NS(evidence=evidence,workspace=workspace,target=target,report=report,publish=publish)


def check(c):return input_gate.authenticate(c.evidence,c.publish())


def test_complete_input_prerequisite_does_not_read_unneeded_private_files(case):
    r=check(case)
    assert r['preprocessed_input']==case.target and r['input_sha256']==key_gate.digest(case.target.read_bytes())
    assert r['valid_token_count']==32


def test_external_hash_first(case):
    case.publish();case.target.unlink();(case.evidence/'sources.tar.gz').unlink()
    with pytest.raises(ValueError,match='external completed'):
        input_gate.authenticate(case.evidence,'0'*64)


@pytest.mark.parametrize('flag',('passed','private_workspace_retained','sources_unchanged','assets_unchanged',
    'upstream_originals_unchanged','selection_byte_parity','tokenization_byte_parity','model_construction_and_forward_guards',
    'private_file_permissions_all_0600'))
def test_incomplete_report_rejected_before_private_input(case,flag):
    case.report[flag]=False;case.target.unlink()
    with pytest.raises(ValueError,match='complete upstream'):check(case)


@pytest.mark.parametrize('name,value',(('size',False),('base_seed',43),('generator_seed',42),('record_count',2),
    ('dataset_record_count',407),('token_lengths',[128.]),('valid_token_counts',[True]),('valid_token_counts',[129]),
    ('source_hashes_after',{}),('source_archive_sha256','0'*64),('asset_file_sha256_after',{}),
    ('upstream_original_sha256_after',{}),('private_workspace_identity',dict(device=1,inode=2)),
    ('input_file_sha256',{}),('preprocessed_input_path','/tmp/foreign')))
def test_wrong_fixed_binding_rejected(case,name,value):
    case.report[name]=value
    with pytest.raises(ValueError):check(case)


@pytest.mark.parametrize('bad',('bytes','permissions','symlink','workspace_permissions'))
def test_current_private_input_binding_rejected(case,bad):
    if bad=='bytes':case.target.write_bytes(b'changed')
    elif bad=='permissions':case.target.chmod(0o644)
    elif bad=='workspace_permissions':case.workspace.chmod(0o755)
    else:
        other=case.target.with_name('other');case.target.rename(other);case.target.symlink_to(other)
    with pytest.raises((ValueError,OSError)):check(case)


def test_private_inventory_traversal_rejected_before_read(case):
    files=case.report['input_file_sha256'];files.pop('other-private-0');files['../foreign']='a'*64
    case.target.unlink()
    with pytest.raises(ValueError,match='relative private'):check(case)
