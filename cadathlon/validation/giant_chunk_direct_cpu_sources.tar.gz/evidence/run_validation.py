"""Direct-runtime isolated scheduling proof; no production imports or edits."""
import os,sys,json,time,hashlib,resource,platform
from pathlib import Path
from types import SimpleNamespace
LAB=Path(__file__).resolve().parents[1];ROOT=LAB/'checkout';OUT=LAB/'evidence'
assert os.environ.get('JAX_PLATFORMS')=='cpu'
sys.path[:0]=[str(OUT),str(ROOT),str(ROOT/'cadathlon/common')]
os.environ['CROSS_ROOT']=str(ROOT);os.environ['CROSS_TEST_CHUNKED_SECURE']='1'
os.chdir(ROOT)
def hashes():
 paths=[p for p in LAB.rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts and p.suffix in ('.py','.md','.in','.out','.golden','.patch')]
 return {str(p.relative_to(LAB)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
before=hashes();started=time.monotonic();records=[]
class Recorder:
 def pytest_runtest_logreport(self,report):
  if report.when=='call' or (report.when=='setup' and report.outcome!='passed'):
   records.append(dict(nodeid=report.nodeid,outcome=report.outcome,seconds=report.duration))
import pytest
paths=[str(OUT/'test_direct_linear.py'),str(OUT/'test_secure_direct_linear.py')]
paths += [str(ROOT/'cadathlon/tests'/('test_'+name+'.py')) for name in (
 'packed_transformer','bounded_transformer_plan','bounded_shared_preparation','bounded_contracts',
 'bounded_reference_preflight','encrypted_bounded_metadata','encrypted_reference_lifecycle')]
code=int(pytest.main(['-q','--tb=short',*paths],plugins=[Recorder()]))
import encrypted_packed_transformer as packed, encrypted_bounded_transformer as bounded
from jaxite_word import ckks_ctx
accounting=[]
for batch in (1,2,8):
 for level in (49,38,26,25,2,1):
  value=SimpleNamespace(polynomial=SimpleNamespace(shape=(batch,2,256,512,2*(level+1)),dtype='uint32'))
  graph=SimpleNamespace(ctx=SimpleNamespace(_param_cache=SimpleNamespace(num_q_at_level=lambda n:2*(n+1))),arithmetic=SimpleNamespace(_level=lambda _:level))
  size=packed.output_payload_bytes(graph,value);limit=packed.pending_limit(size,64)
  assert (limit-1)*size<=packed.DEFAULT_EXTRA_PAYLOAD_BYTES
  accounting.append(dict(degree=131072,batch=batch,input_level=level,output_level=level-1,output_q_count=2*level,output_payload_bytes=size,pending_limit=limit,extra_pending_payload_bytes=(limit-1)*size))
(OUT/'high_degree_queue_accounting.json').write_text(json.dumps(dict(scope='Public shape accounting only; no high-degree ciphertext allocation or HBM measurement',maximum_extra_payload_bytes=packed.DEFAULT_EXTRA_PAYLOAD_BYTES,rows=accounting),indent=2)+'\n')
after=hashes();origins={m.__name__:str(Path(m.__file__).resolve()) for m in (packed,bounded,ckks_ctx)}
assert all(Path(p).is_relative_to(ROOT) for p in origins.values())
result=dict(passed=code==0 and before==after,pytest_exit_code=code,seconds=time.monotonic()-started,
 source_sha256=before,source_sha256_after=after,source_files_unchanged=before==after,module_origins=origins,
 tests=records,counts={outcome:sum(t['outcome']==outcome for t in records) for outcome in ('passed','failed','skipped')},
 affinity=sorted(os.sched_getaffinity(0)),python=platform.python_version(),max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
 scope='Direct PackedTransformer runtime patch in isolated checkout; exact secure linear component and ideal complete graph regressions; no full encrypted graph/TPU claim')
(OUT/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('source_sha256','source_sha256_after','tests','module_origins')}),flush=True)
raise SystemExit(0 if result['passed'] else 1)
