from pathlib import Path
from types import SimpleNamespace
import ast,hashlib,os,stat,pytest

@pytest.mark.parametrize('kind',['upload','download'])
@pytest.mark.parametrize('failure',[ValueError,KeyboardInterrupt,SystemExit])
def test_tree_body_primary_survives_nested_close(tmp_path,kind,failure):
 raw=Path(__file__).with_name('request_lifecycle.py').read_bytes();tree=ast.parse(raw);fake=SimpleNamespace(**{n:getattr(os,n)for n in dir(os)})
 ns=dict(os=fake,stat=stat,hashlib=hashlib)
 exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in ('_identity','_file_state','_tree')],type_ignores=[]),'<actual tree>','exec'),ns)
 root=tmp_path/kind;root.mkdir();(root/'batch.json').write_bytes(b'{}');nonce='0'*32;sample=root/nonce;sample.mkdir()
 dirs=[sample]
 if kind=='upload':
  dirs=[]
  for i in range(8):p=sample/('tile'+str(i));p.mkdir();dirs.append(p)
 for p in dirs:
  for n in ('bundle.json','transport.json','ct_0.npz'):(p/n).write_bytes(b'ordinary synthetic metadata')
 primary=failure('body');closed=[]
 def observe(name,*a,**kw):
  if name=='ct_0.npz':raise primary
  return os.stat(name,*a,**kw)
 def close(fd):os.close(fd);closed.append(fd);raise OSError('nested close')
 fake.stat=observe;fake.close=close;fd=os.open(root,os.O_RDONLY|os.O_DIRECTORY)
 try:
  with pytest.raises(failure)as got:ns['_tree'](fd,kind,[nonce])
  assert got.value is primary
 finally:os.close(fd)
 assert len(closed)==(2 if kind=='upload'else 1)
