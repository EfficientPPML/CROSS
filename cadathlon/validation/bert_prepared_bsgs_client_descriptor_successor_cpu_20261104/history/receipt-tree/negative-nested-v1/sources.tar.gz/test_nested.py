from pathlib import Path
from types import SimpleNamespace
import ast,hashlib,os,stat,pytest
@pytest.mark.parametrize('kind',[KeyboardInterrupt,SystemExit])
def test_tree_cleanup_then_observe_cancellation(kind,tmp_path):
 t=ast.parse(Path(__file__).with_name('request_lifecycle.py').read_bytes());fake=SimpleNamespace(**{n:getattr(os,n)for n in dir(os)});ns=dict(os=fake,stat=stat,hashlib=hashlib)
 exec(compile(ast.Module(body=[n for n in t.body if isinstance(n,ast.FunctionDef)and n.name in ('_identity','_file_state','_tree','_observe')],type_ignores=[]),'<actual nested receipt>','exec'),ns)
 root=tmp_path/'download';root.mkdir();(root/'batch.json').write_bytes(b'{}');nonce='0'*32;d=root/nonce;d.mkdir()
 for name in ('bundle.json','transport.json','ct_0.npz'):(d/name).write_bytes(b'synthetic')
 calls=[];cancel=kind('outer cleanup cancellation')
 def close(fd):
  os.close(fd);calls.append(fd)
  if len(calls)==1:raise OSError('inner cleanup')
  raise cancel
 fake.close=close
 with pytest.raises(kind)as got:ns['_observe'](root,'download',[nonce])
 assert got.value is cancel and len(calls)==2
