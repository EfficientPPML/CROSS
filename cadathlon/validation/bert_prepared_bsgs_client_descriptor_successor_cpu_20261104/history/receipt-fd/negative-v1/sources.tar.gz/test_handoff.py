from pathlib import Path
from types import SimpleNamespace
import ast
import errno
import hashlib
import os
import stat

import pytest


def test_receipt_reader_fdopen_failure_does_not_leak_duplicated_fd(tmp_path):
    source = Path(__file__).with_name('request_lifecycle.py')
    tree = ast.parse(source.read_bytes())
    nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef)
             and n.name in ('_identity', '_observe')]
    duplicated = []
    primary = ValueError('synthetic fdopen construction failure')

    def duplicate(fd):
        result = os.dup(fd)
        duplicated.append(result)
        return result

    def fail_fdopen(*args, **kwargs):
        raise primary

    fake = SimpleNamespace(**{n: getattr(os, n) for n in dir(os)})
    fake.dup = duplicate
    fake.fdopen = fail_fdopen
    namespace = dict(Path=Path, os=fake, stat=stat, hashlib=hashlib)
    exec(compile(ast.Module(body=nodes, type_ignores=[]),
                 '<actual receipt reader AST>', 'exec'), namespace)
    path = tmp_path / 'synthetic-requests.json'
    path.write_bytes(b'{"synthetic":true}\n')
    try:
        with pytest.raises(ValueError) as error:
            namespace['_observe'](path, 'client_requests', [])
        assert error.value is primary and len(duplicated) == 1
        leaked = []
        for fd in duplicated:
            try:
                os.fstat(fd)
            except OSError as error:
                assert error.errno == errno.EBADF
            else:
                leaked.append(fd)
        assert not leaked, 'fdopen failure leaked a real duplicated descriptor'
    finally:
        # The review process owns these synthetic descriptors; retire leaks
        #after recording the failed assertion, never leave them live.
        for fd in duplicated:
            try:
                os.close(fd)
            except OSError as error:
                assert error.errno == errno.EBADF
