from pathlib import Path
from types import SimpleNamespace
import ast
import errno
import hashlib
import os
import stat

import pytest


def actual_reader(fake_os):
    root = Path(__file__).resolve().parent
    namespace = dict(Path=Path, os=fake_os, stat=stat, hashlib=hashlib,
                     _tree=lambda *_: {'synthetic': 'inventory-double'})
    nodes = []
    for file, names in (('client_keys.py', {'_read'}),
                        ('request_lifecycle.py', {'_identity', '_observe'})):
        nodes.extend(n for n in ast.parse((root / file).read_bytes()).body
                     if isinstance(n, ast.FunctionDef) and n.name in names)
    exec(compile(ast.Module(body=nodes, type_ignores=[]), '<actual receipt reader AST>', 'exec'), namespace)
    return namespace['_observe']


def fixture_path(tmp_path, kind):
    if kind == 'upload':
        path = tmp_path / 'synthetic-upload'
        path.mkdir()
        (path / 'batch.json').write_bytes(b'{"synthetic":true}\n')
    else:
        path = tmp_path / 'synthetic-requests.json'
        path.write_bytes(b'{"synthetic":true}\n')
    return path


def cleanup_duplicates(duplicated):
    for fd in duplicated:
        try:
            os.close(fd)
        except OSError as error:
            assert error.errno == errno.EBADF


@pytest.mark.parametrize('kind', ['client_requests', 'upload'])
def test_fdopen_construction_failure_never_loses_duplicate(tmp_path, kind):
    duplicated = []
    primary = ValueError('synthetic fdopen construction failure')
    fake = SimpleNamespace(**{n: getattr(os, n) for n in dir(os)})

    def duplicate(fd):
        result = os.dup(fd)
        duplicated.append(result)
        return result

    def fail_fdopen(*args, **kwargs):
        raise primary

    fake.dup = duplicate
    fake.fdopen = fail_fdopen
    observe = actual_reader(fake)
    try:
        with pytest.raises(ValueError) as got:
            observe(fixture_path(tmp_path, kind), kind, [])
        assert got.value is primary and len(duplicated) == 1
        leaked = []
        for fd in duplicated:
            try:
                os.fstat(fd)
            except OSError as error:
                assert error.errno == errno.EBADF
            else:
                leaked.append(fd)
        assert not leaked, 'fdopen failed with an unowned live duplicate'
    finally:
        cleanup_duplicates(duplicated)


@pytest.mark.parametrize('kind', ['client_requests', 'upload'])
@pytest.mark.parametrize('primary_type', [ValueError, KeyboardInterrupt, SystemExit])
def test_reader_body_primary_survives_close_failure(tmp_path, kind, primary_type):
    primary = primary_type('synthetic read-body primary')
    close_errors = []
    fake = SimpleNamespace(**{n: getattr(os, n) for n in dir(os)})

    class Stream:
        def __init__(self, fd):
            self.fd = fd

        def __enter__(self):
            return self

        def read(self, maximum):
            raise primary

        def __exit__(self, *args):
            os.close(self.fd)

    def close(fd):
        os.close(fd)
        error = OSError('synthetic post-close failure')
        close_errors.append(error)
        raise error

    fake.fdopen = lambda fd, *args, **kwargs: Stream(fd)
    fake.close = close
    observe = actual_reader(fake)
    with pytest.raises(BaseException) as got:
        observe(fixture_path(tmp_path, kind), kind, [])
    assert close_errors
    assert got.value is primary, 'descriptor close masked the original read-body primary'
