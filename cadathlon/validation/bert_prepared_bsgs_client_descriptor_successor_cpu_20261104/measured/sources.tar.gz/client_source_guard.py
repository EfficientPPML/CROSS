"""Exact89 client parent plus explicit receipt/reader overlays and named successors.

Static resolution and fresh-process rejection occur before any local gate or
runtime import. These checks do not attest arbitrary already-executed code.
"""
from pathlib import Path
import ast,hashlib,importlib.machinery,json,sys
import client_io as io
HERE=Path(__file__).resolve().parent
PARENT_SHA='4caa7697ea5260f0ea88f144452873fc87d71d551e9d8033a909da03cfb48882'
REPORT_SHA='274ec333531f42e0ca76cd8b6ec2ef508dcf0dd9c1366ac9350c3e52f093c424'
OVERLAYS={'runtime/stage/file_stages.py':'f3889816f897f5c96a79c7f16340f851460c7b71b216b818589c2eaa17ee85db',
          'runtime/stage/request_lifecycle.py':'3d8b80f949ca2cdf7ee7cbe88fe848fb654ed79c1356724cc9f4294edb71039a',
          'runtime/stage/client_keys.py':'d6a2aac4e8ecf483e250a793a341cc6e451e2e9471ad8725e7699f720c7cfa76',
          'runtime/stage/key_contexts.py':'056627ee3080f3d6ec7445ceb2f25171b49c7fc08eb256449a656b100f5853f0',
          'runtime/stage/file_stage_io.py':'e50d0ea824ab0be181bd891c725f371ce9f594b79a72e7215b7c8cb8f4e37a42'}
NEW=('client_89_sources.json','client_89_report.json','baseline/file_stages.py','baseline/request_lifecycle.py',
     'combined_server_sources.json','combined_server_preflight.json','combined_server_preflight_sources.tar.gz',
     'client_helper_origin.json','client_io.py','client_source_guard.py','combined_server_gate.py','test_combined_server_gate.py',
     'separate_public_readback.py','separate_client_readback.py','separate_client_worker.py','separate_client_collect.py',
     'client_preflight.py','client_installed_probe.py','client_processes.py','README_CLIENT.md',
     'test_completion_directory.py','test_client_source_guard.py','test_separate_client_worker.py',
     'test_separate_client_collect.py','test_separate_client_readback.py','test_client_io.py','test_receipt_io.py','test_client_descriptor_io.py')
ENTRY=('client_preflight','client_installed_probe','client_io','client_source_guard','combined_server_gate','separate_public_readback','separate_client_readback',
       'separate_client_worker','separate_client_collect','client_processes','key_gate','model_gate','stage3_gate','reference_gate','input_gate','boundaries','cleanup','terminal','client_metrics')

def _read(root,name):
    p=Path(name)
    if p.is_absolute()or '..'in p.parts or p.as_posix()!=name:raise ValueError('relative explicit client source required')
    path=root/p
    for parent in (path,*path.parents):
        if parent==root:break
        if parent.is_symlink():raise ValueError('source symlink forbidden')
    return io.read(path,16<<20)

def raw_sources(root=HERE):
    root=Path(root).resolve();raw=_read(root,'client_89_sources.json')
    if io.digest(raw)!=PARENT_SHA:raise ValueError('reviewed89 source inventory differs')
    parent=io.parse(raw)
    if type(parent)is not dict or len(parent)!=89:raise ValueError('exact89 source parent required')
    if io.digest(_read(root,'client_89_report.json'))!=REPORT_SHA:raise ValueError('reviewed89 report differs')
    result={n:_read(root,n)for n in sorted(set(parent)|set(NEW))}
    for n,h in parent.items():
        if io.digest(result[n])!=OVERLAYS.get(n,h):raise ValueError('unreviewed client parent/overlay bytes: '+n)
    for name in ('file_stages.py','request_lifecycle.py'):
        if io.digest(result['baseline/'+name])!=parent['runtime/stage/'+name]:raise ValueError('original default baseline differs')
    return result

def _resolve(name,roots):
    search=[str(p)for p in roots];spec=None
    for i,part in enumerate(name.split('.')):
        spec=importlib.machinery.PathFinder.find_spec(part,search)
        if spec is None:return None
        if i<len(name.split('.'))-1:
            if spec.submodule_search_locations is None:return None
            search=list(spec.submodule_search_locations)
    if spec.origin in (None,'built-in','frozen'):return None
    return Path(spec.origin).resolve()

def check_sources(expected,root=HERE,*,fresh=False,modules=None):
    if type(fresh)is not bool:raise ValueError('typed fresh phase required')
    root=Path(root).resolve();raw=raw_sources(root);actual=io.hashes(raw)
    if actual!=expected:raise ValueError('exact client source closure differs')
    modules=sys.modules if modules is None else modules
    roots=(root,root/'runtime/stage',root/'runtime',root/'runtime/jaxite_word')
    critical={n:n+'.py'for n in ENTRY}
    for path in expected:
        p=Path(path)
        if p.parent==Path('runtime/stage')and p.suffix=='.py':critical[p.stem]=path
        if p.parent==Path('runtime/jaxite_word')and p.suffix=='.py':
            if p.stem=='__init__':critical['jaxite_word']=path
            else:critical[p.stem]=path;critical['jaxite_word.'+p.stem]=path
    resolved={};external=set();pending=list(critical)
    while pending:
        name=pending.pop()
        if name in resolved or name in external:continue
        path=_resolve(name,roots)
        if path is None or not path.is_relative_to(root):external.add(name);continue
        relative=path.relative_to(root).as_posix()
        if relative not in expected:raise ValueError('reachable uncaptured local client module: '+name)
        resolved[name]=relative;tree=ast.parse(raw[relative])
        for node in ast.walk(tree):
            if isinstance(node,ast.Import):pending.extend(a.name for a in node.names)
            elif isinstance(node,ast.ImportFrom)and node.level==0 and node.module:
                pending.append(node.module)
                pending.extend(node.module+'.'+a.name for a in node.names if a.name!='*'and _resolve(node.module+'.'+a.name,roots)is not None)
    for name,path in critical.items():
        if resolved.get(name)!=path:raise ValueError('critical client module resolution differs: '+name)
    for path,name in (('runtime/stage/file_stages.py','client_decrypt_decode'),('runtime/stage/request_lifecycle.py','record_completed')):
        fn=next(n for n in ast.parse(raw[path]).body if isinstance(n,ast.FunctionDef)and n.name==name)
        defaults={a.arg:b for a,b in zip(fn.args.kwonlyargs,fn.args.kw_defaults)}
        if not isinstance(defaults.get('completion_directory'),ast.Constant)or defaults['completion_directory'].value is not None:raise ValueError('unchanged default completion semantics required')
    loaded={}
    for name,module in tuple(modules.items()):
        if module is None:continue
        file=getattr(module,'__file__',None)
        if name in resolved:
            if fresh and name not in ('client_io','client_source_guard'):raise ValueError('client gate/runtime preloaded before fresh source gate: '+name)
            if not file or Path(file).resolve()!=root/resolved[name]:raise ValueError('preloaded client module path differs: '+name)
        if not file:continue
        path=Path(file).resolve()
        if path.is_relative_to(root)and path.suffix=='.py':
            relative=path.relative_to(root).as_posix()
            if relative not in expected or io.digest(_read(root,relative))!=expected[relative]:raise ValueError('loaded local client source differs')
            origin=getattr(getattr(module,'__spec__',None),'origin',None)
            if origin not in (None,'built-in','frozen')and Path(origin).resolve()!=path:raise ValueError('loaded client source origin differs')
            loaded[name]=dict(path=relative,sha256=expected[relative])
    for n in ('polynomial','ckks_ctx','mapping'):
        if n in modules and 'jaxite_word.'+n in modules and modules[n]is not modules['jaxite_word.'+n]:raise ValueError('split core client module identities')
    return dict(passed=True,source_count=len(expected),parent_source_count=89,overlays=OVERLAYS,
        critical_resolution=critical,reachable_local_modules=resolved,loaded_local_modules=loaded,fresh=fresh,actual_client_decode=False)
