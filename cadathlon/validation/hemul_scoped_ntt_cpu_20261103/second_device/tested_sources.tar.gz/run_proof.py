"""CPU-only isolated optional HEMul NTT provider proof with exact source capture."""
from pathlib import Path
import hashlib,io,json,os,resource,subprocess,sys,tarfile,time
HERE=Path(__file__).resolve().parent;ROOT=HERE/'checkout'
OUT=HERE/sys.argv[1];OUT.mkdir(exist_ok=False)
paths=[Path(__file__),HERE/'pytest_records.py']
for folder in ('jaxite_word','cadathlon/common','cadathlon/tests'):paths.extend((ROOT/folder).glob('*.py'))
paths.extend((ROOT/'cadathlon').rglob('suite_config.json'))
data={str(p.relative_to(HERE)):p.read_bytes() for p in sorted(set(paths))};before={n:hashlib.sha256(b).hexdigest() for n,b in data.items()}
with tarfile.open(OUT/'tested_sources.tar.gz','w:gz') as arc:
 for name,content in data.items():
  info=tarfile.TarInfo(name);info.size=len(content);arc.addfile(info,io.BytesIO(content))
env=dict(os.environ,JAX_PLATFORMS='cpu',PYTHONPATH=str(HERE)+':'+str(ROOT)+':'+str(ROOT/'jaxite_word')+':'+str(ROOT/'cadathlon/common'),CROSS_ROOT=str(ROOT),PROOF_RECORDS=str(OUT/'records.json'))
command=[sys.executable,'-m','pytest','-q','-p','pytest_records',*sys.argv[2:],'--junitxml='+str(OUT/'junit.xml')]
start=time.monotonic()
with (OUT/'stdout.log').open('w') as log:
 child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
 print(json.dumps({'child_pid':child.pid,'output':str(OUT),'command':command}),flush=True)
 status=child.wait()
after={str(p.relative_to(HERE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths))}
report={'scope':__doc__,'passed':status==0 and before==after,'returncode':status,'elapsed_s':time.monotonic()-start,'command':command,'source_files_unchanged':before==after,'source_sha256_before':before,'source_sha256_after':after,'peak_child_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'affinity':sorted(os.sched_getaffinity(0)),'environment':{k:env.get(k) for k in ('JAX_PLATFORMS','XLA_FLAGS','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','CROSS_ROOT','PYTHONPATH')}}
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if not k.startswith('source_sha')}),flush=True)
raise SystemExit(0 if report['passed'] else 1)
