from pathlib import Path
import importlib.metadata,json,os,sys

def pytest_sessionfinish(session,exitstatus):
 records={name:getattr(module,'RECORDS') for name,module in list(sys.modules.items()) if name.startswith('test_') and hasattr(module,'RECORDS')}
 Path(os.environ['PROOF_RECORDS']).write_text(json.dumps({'exitstatus':int(exitstatus),'records':records,'versions':{name:importlib.metadata.version(name) for name in ('jax','jaxlib','numpy','pytest')}},indent=2)+'\n')
