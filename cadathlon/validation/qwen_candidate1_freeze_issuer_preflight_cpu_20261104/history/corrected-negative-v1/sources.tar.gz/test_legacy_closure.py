"""Frozen original synthetic bytes; independent of successor PIN_FIELDS."""
from pathlib import Path
import base64,json
import pytest
import freeze_issuer as f

def test_legacy_multifile_proof_without_helper_source_archive_grant_pins_rejected():
    bundle=json.loads((Path(__file__).parent/'legacy_bundle.json').read_bytes())
    blobs={n:base64.b64decode(raw,validate=True)for n,raw in bundle['blobs'].items()}
    with pytest.raises(ValueError):f.issue(blobs,bundle['pins'])
