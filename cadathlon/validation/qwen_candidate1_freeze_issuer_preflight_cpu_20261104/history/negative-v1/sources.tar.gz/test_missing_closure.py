"""Known multi-file closure gap, synthetic public bytes only."""
import pytest
import freeze_issuer as f
from test_freeze_issuer import pack,skeleton

def test_multifile_reconstruction_without_source_archive_grant_binding_rejected():
    blobs,pins=pack(*skeleton())
    assert set(pins)==set(f.PIN_FIELDS)
    assert not any(k.startswith('reconstruction_')and k!='reconstruction_script_sha256'and k!='reconstruction_outer'for k in pins)
    with pytest.raises(ValueError):
        f.issue(blobs,pins)

def test_stale_script_is_rejected_control():
    blobs,pins=pack(*skeleton());pins['reconstruction_script_sha256']='f'*64
    with pytest.raises(ValueError):f.issue(blobs,pins)
