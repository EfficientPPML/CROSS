"""Synthetic public proofs only; no actual producer outcome or private body."""
import copy
import json
from pathlib import Path
import pytest
import freeze_issuer as f

def h(label):return f.sha(('synthetic '+label).encode())

def skeleton():
    sources=json.loads((Path(__file__).parent/'producer139_sources.json').read_bytes())
    worker=dict(pid=12346,source_manifest_sha256=f.SOURCE,source_hashes_start=sources,source_hashes_end=sources,
        audit_denials=[],expected_entries=3200,retained_entries=3200,candidate_complete=3200,semantic_passes=3200,
        original416_members=416,complete_free_sequences=12,complete_free_denominator=16,
        native_forward_started=3232,native_forward_completed=3232,phase_counts=dict(native=3200,exact=3200,candidate=3200),
        native_invariance_by_length={str(k):True for k in range(1,33)},exact_invariance_by_length={str(k):True for k in range(1,33)},
        native_forward_accounting=dict(expected=3232,started=3232,completed=3232,passed=True),
        input_ranges=dict(native=dict(contexts=3200),exact=dict(contexts=3200),candidate_propagated={}),
        gates=dict(all_numeric_semantic_domains=True,prefill_top1=True,teacher_top1=True,complete_free_sequences=True),
        manifest_sha256=f.CANDIDATE,grant_sha256=f.GRANT,candidate_ordinal=1,initial_report_sha256=f.INITIAL,
        selection_proof_sha256=f.SELECTION,calibration_sha256=f.CALIBRATION,protocol_sha256=f.PROTOCOL)
    for name in f.TERMINAL+('ledger_complete','trajectories_complete','all_length_invariance','complete_measured_context_coverage',
        'candidate_validation_admissible','calibration_reauthenticated','private_directory_handle_closed','private_outputs_retained',
        'external_inputs_never_removed','model_asset_postchecks_completed','model_cleanup_completed','native_capture_cleanup_completed',
        'model_loaded','model_forward'):worker[name]=True
    for name in ('coefficient_selection_performed','encrypted_execution','validation_inputs_read','tokenizer_execution',
        'contains_tokens_logits_or_failure_text','failed_attempt_terminal_candidate','revision_eligible_ledger'):worker[name]=False
    worker['by_kind']={kind:dict(expected=total,records=total,complete=total,candidate_invalid=0,comparison_invalid=0,
        unmeasured=0,top1_matches=matches,top1_denominator=total)for kind,total,matches in(('prefill',3072,2765),('teacher',64,58),('free',64,48))}
    parent=dict(pid=12345,child_pid=12346,child_pgid=12346,child_returncode=0,child_reaped=True,child_group_absent=True,
        actual_candidate_stage=True,candidate_validation_admissible=True,source_manifest_sha256=f.SOURCE,
        source_hashes_start=sources,source_hashes_end=sources,audit_denials=[],source_archive=dict(sha256=h('archive')))
    for name in f.TERMINAL:parent[name]=True
    coverage,gates=f.exact_coverage(worker)
    review=dict(schema='qwen-candidate-recorded-statistic-review-v2',verification_passed=True,scientific_pass=True,
        complete_scientific_failure_eligible=False,candidate_ordinal=1,checks={k:True for k in f.REVIEW_CHECKS},coverage=coverage,gates=gates,
        aggregate_sha256=h('aggregate'),selection_authorized=False,validation_authorized=False,row0_authorized=False,**f.SCOPE)
    return sources,parent,worker,review

def pack(sources,parent,worker,review):
    # Rebind all public hashes after a mutation so negative tests exercise
    # semantic admission, not merely rejection of stale fixture digests.
    worker_raw=f.canonical(worker)
    parent=copy.deepcopy(parent);parent.update(worker=worker,worker_report_sha256=f.sha(worker_raw))
    parent_raw=f.canonical(parent)
    producer=dict(schema='qwen-candidate3200-producer-terminal-v1',report_sha256=f.sha(parent_raw),worker_report_sha256=f.sha(worker_raw),
        source_manifest_sha256=f.SOURCE,source_archive_sha256=h('archive'),candidate_manifest_sha256=f.CANDIDATE,grant_sha256=f.GRANT,
        exit_code=0,reaped=True,process_group_absent=True,worker_exit_code=0,worker_reaped=True,worker_group_absent=True)
    producer_raw=f.canonical(producer)
    review=copy.deepcopy(review)
    review['bindings']=dict(candidate_manifest_sha256=f.CANDIDATE,producer_source_manifest_sha256=f.SOURCE,
        producer_source_archive_sha256=h('archive'),producer_parent_report_sha256=f.sha(parent_raw),producer_worker_report_sha256=f.sha(worker_raw),
        producer_outer_receipt_sha256=f.sha(producer_raw),calibration_sha256=f.CALIBRATION,protocol_sha256=f.PROTOCOL,
        model_pins_sha256=f.MODEL,grant_sha256=f.GRANT,private_inventory_sha256=h('private inventory'),ledger_sha256=h('ledger'),
        **{name:h(name) for name in f.RECONSTRUCTION_PINS})
    review_raw=f.canonical(review)
    outer=dict(schema='qwen-candidate-reconstruction-outer-v2',review_sha256=f.sha(review_raw),script_sha256=h('reviewed script'),
        producer_source_manifest_sha256=f.SOURCE,candidate_manifest_sha256=f.CANDIDATE,producer_outer_receipt_sha256=f.sha(producer_raw),
        returncode=0,direct_child_reaped=True,owned_group_absent=True,publication_completed=True,
        **{name:h(name) for name in f.RECONSTRUCTION_PINS})
    # Exact external source bytes retain their reviewed pretty serialization.
    source_raw=(Path(__file__).parent/'producer139_sources.json').read_bytes()
    assert json.loads(source_raw)==sources
    blobs=dict(parent=parent_raw,worker=worker_raw,producer_outer=producer_raw,review=review_raw,
        reconstruction_outer=f.canonical(outer),source_manifest=source_raw)
    pins={name:f.sha(raw)for name,raw in blobs.items()}
    pins.update(source_archive_sha256=h('archive'),reconstruction_script_sha256=h('reviewed script'),
        **{name:h(name) for name in f.RECONSTRUCTION_PINS})
    return blobs,pins

def test_complete_synthetic_pass_is_compatible_and_has_no_execution_authority():
    blobs,pins=pack(*skeleton());before=copy.deepcopy((blobs,pins))
    raw=f.issue(blobs,pins);value=json.loads(raw)
    assert value['schema']=='qwen-first-complete-calibration-pass-freeze-v2'
    assert value['attempts'][0]['gates']==dict(all_numeric_semantic_domains=True,trajectories_complete=True,
        prefill_matches=2765,teacher_matches=58,whole_free_sequences=12)
    assert value['validation_execution_authorized'] is value['row0_execution_authorized'] is False
    assert value['fresh_array_recomputation'] is value['argmax_recomputed_from_logits'] is False
    assert value['recorded_statistic_reconstruction'] is True and value['ordinal']==1
    assert (blobs,pins)==before
    #48 free-step matches is valid; there is no invented58/64 free-step gate.
    assert json.loads(blobs['worker'])['by_kind']['free']['top1_matches']==48

@pytest.mark.parametrize('field',f.TERMINAL)
def test_worker_requires_every_terminal_flag(field):
    s,p,w,r=skeleton();w[field]=False
    with pytest.raises(ValueError):f.issue(*pack(s,p,w,r))

@pytest.mark.parametrize('field',f.REVIEW_CHECKS)
def test_every_independent_reconstruction_check_required(field):
    s,p,w,r=skeleton();r['checks'][field]=False
    with pytest.raises(ValueError):f.issue(*pack(s,p,w,r))

@pytest.mark.parametrize('kind,matches',[('prefill',2764),('teacher',57)])
def test_threshold_failure_cannot_freeze(kind,matches):
    s,p,w,r=skeleton();w['by_kind'][kind]['top1_matches']=matches
    with pytest.raises(ValueError):f.issue(*pack(s,p,w,r))

def test_incomplete_whole_free_threshold():
    s,p,w,r=skeleton();w['complete_free_sequences']=11
    with pytest.raises(ValueError):f.issue(*pack(s,p,w,r))

@pytest.mark.parametrize('target,key,value',[
    ('w','candidate_ordinal',2),('w','candidate_ordinal',True),('w','native_forward_completed',3231),
    ('w','native_forward_started',3233),('w','candidate_complete',3199),('w','semantic_passes',3199),
    ('w','expected_entries',True),('w','original416_members',415),('w','model_asset_postchecks_completed',False),
    ('w','calibration_reauthenticated',False),('w','private_directory_handle_closed',False),
    ('w','validation_inputs_read',True),('w','encrypted_execution',True),('w','tokenizer_execution',True),
    ('w','failed_attempt_terminal_candidate',True),('w','revision_eligible_ledger',True),
    ('w','manifest_sha256','a'*64),('w','grant_sha256','a'*64),('w','audit_denials',['caught denial']),
    ('w','error_type','KeyboardInterrupt'),('p','child_returncode',False),('p','child_reaped',False),
    ('p','candidate_validation_admissible',False),('p','source_manifest_sha256','b'*64),
    ('r','scientific_pass',False),('r','complete_scientific_failure_eligible',True),
    ('r','verification_passed',False),('r','fresh_array_recomputation',True),
    ('r','recorded_statistic_reconstruction',1),('r','validation_authorized',True)])
def test_semantic_mutation_rejected_with_fresh_hashes(target,key,value):
    s,p,w,r=skeleton();{'p':p,'w':w,'r':r}[target][key]=value
    with pytest.raises(ValueError):f.issue(*pack(s,p,w,r))

@pytest.mark.parametrize('role',f.ROLES)
def test_external_pin_cannot_be_replaced(role):
    blobs,pins=pack(*skeleton());pins[role]='f'*64
    with pytest.raises(ValueError):f.issue(blobs,pins)

@pytest.mark.parametrize('role,field,value',[
    ('producer_outer','exit_code',1),('producer_outer','reaped',1),('producer_outer','worker_reaped',False),
    ('producer_outer','worker_group_absent',False),('producer_outer','report_sha256','a'*64),
    ('reconstruction_outer','returncode',1),('reconstruction_outer','direct_child_reaped',False),
    ('reconstruction_outer','publication_completed',False),('reconstruction_outer','script_sha256','a'*64),
    ('reconstruction_outer','review_sha256','a'*64)])
def test_independent_outer_evidence_is_required(role,field,value):
    blobs,pins=pack(*skeleton());row=json.loads(blobs[role]);row[field]=value
    blobs[role]=f.canonical(row);pins[role]=f.sha(blobs[role])
    with pytest.raises(ValueError):f.issue(blobs,pins)

def test_recorded_coverage_must_match_public_producer():
    s,p,w,r=skeleton();r['coverage']['measured_contexts']=3199
    with pytest.raises(ValueError):f.issue(*pack(s,p,w,r))

def test_recorded_gate_counts_must_match_public_producer():
    s,p,w,r=skeleton();r['gates']['prefill_matches']=3072
    with pytest.raises(ValueError):f.issue(*pack(s,p,w,r))

@pytest.mark.parametrize('raw',[b'[]',b'null',b'{"a":1,"a":1}',b'{"a":NaN}',b'{"a":1e999}'])
def test_malformed_public_json(raw):
    blobs,pins=pack(*skeleton());blobs['parent']=raw;pins['parent']=f.sha(raw)
    with pytest.raises(ValueError):f.issue(blobs,pins)

def test_missing_independently_reviewed_script_pin():
    blobs,pins=pack(*skeleton());pins.pop('reconstruction_script_sha256')
    with pytest.raises(ValueError):f.issue(blobs,pins)

@pytest.mark.parametrize('field',f.RECONSTRUCTION_PINS)
def test_independent_helper_closure_and_grant_pins_required(field):
    blobs,pins=pack(*skeleton());pins.pop(field)
    with pytest.raises(ValueError):f.issue(blobs,pins)

@pytest.mark.parametrize('field',f.RECONSTRUCTION_PINS)
def test_closure_pin_mismatch_cannot_be_borrowed_from_review(field):
    blobs,pins=pack(*skeleton());pins[field]='e'*64
    with pytest.raises(ValueError):f.issue(blobs,pins)

@pytest.mark.parametrize('field',f.RECONSTRUCTION_PINS)
def test_reconstruction_outer_must_bind_full_helper_closure(field):
    blobs,pins=pack(*skeleton());row=json.loads(blobs['reconstruction_outer']);row[field]='d'*64
    blobs['reconstruction_outer']=f.canonical(row);pins['reconstruction_outer']=f.sha(blobs['reconstruction_outer'])
    with pytest.raises(ValueError):f.issue(blobs,pins)
