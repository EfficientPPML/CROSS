"""Source-bound synthetic issuer proof; external final exit/reap still required."""
from pathlib import Path
import argparse,hashlib,json,os,stat,sys,tarfile,xml.etree.ElementTree as ET

def sha(raw):return hashlib.sha256(raw).hexdigest()
def canonical(value):return (json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--manifest',required=True)
    parser.add_argument('--manifest-sha256',required=True)
    parser.add_argument('--output',required=True)
    args=parser.parse_args()
    if not sys.flags.isolated or not sys.dont_write_bytecode:raise ValueError('Fresh -I -B required')
    root=Path(__file__).resolve().parent;output=Path(args.output)
    if not output.is_absolute() or output!=output.resolve() or not output.is_dir():raise ValueError('Canonical owned proof output required')
    raw=Path(args.manifest).read_bytes()
    if sha(raw)!=args.manifest_sha256:raise ValueError('External source manifest differs')
    expected=json.loads(raw)
    required={'freeze_issuer.py','freeze_admission.py','test_freeze_issuer.py','producer139_sources.json','DESIGN.md','proof_driver.py'}
    if type(expected) is not dict or set(expected)!=required:raise ValueError('Exact six-source proof required')
    def inventory():
        found={}
        for path in root.iterdir():
            info=path.lstat()
            if not stat.S_ISREG(info.st_mode) or not 0<info.st_size<=1<<20:raise ValueError('Bounded regular source required')
            found[path.name]=sha(path.read_bytes())
        if found!=expected:raise ValueError('Source inventory differs')
        return found
    before=inventory()
    forbidden=('/tmp/qwen-expanded-candidate-checker-actual-v1-20261104',
        '/tmp/qwen-expanded-candidate-checker-private-v1-20261104',
        '/tmp/qwen-expanded-prefix-observer-actual-v2-20261104',
        '/tmp/qwen-expanded-prefix-observer-private-v2-20261104',
        '/tmp/qwen-expanded-prefix-observer-terminal-root-review-20261104',
        '/tmp/qwen-expanded-prefix-selector-actual-v1-20261104',
        '/tmp/qwen-expanded-prefix-token-inputs-20261104-v1',
        '/home/jianming_gatech/cross_validation_assets',
        '/tmp/qwen-native-calibration-20261103','/tmp/qwen-candidate3-calibration-20261103',
        '/tmp/qwen-candidate3-fresh56-validation-20261103','/tmp/qwen-candidate3-published-regression-20261103')
    backends={'numpy','torch','transformers','jax','jaxlib','jaxite_word','tensorflow','flax','torch_xla','safetensors','tokenizers'}
    denials=[]
    def audit(event,values):
        reason=None
        if event=='open' and values and isinstance(values[0],(str,bytes,os.PathLike)):
            path=str(Path(os.path.abspath(os.fsdecode(values[0]))).resolve())
            if any(path==p or path.startswith(p+'/') for p in forbidden):reason='actual input/model/outcome body'
        elif event.startswith('socket.') or event in ('subprocess.Popen','os.fork','os.forkpty','os.posix_spawn','os.posix_spawnp','os.exec','os.system'):
            reason='network/child execution'
        elif event=='import' and values and str(values[0]).split('.')[0] in backends:reason='model/numerical backend'
        if reason:
            denials.append(reason);raise PermissionError('issuer synthetic audit: '+reason)
    sys.addaudithook(audit)
    sys.path.insert(0,str(root))
    import pytest
    code=pytest.main(['-q','-p','no:cacheprovider','--import-mode=importlib',
        '--basetemp='+str(output/'synthetic'),'--junitxml='+str(output/'tests.xml'),str(root/'test_freeze_issuer.py')])
    xml=ET.parse(output/'tests.xml')
    tests=len(xml.findall('.//testcase'));bad=sum(len(xml.findall('.//'+name))for name in ('failure','error','skipped'))
    after=inventory()
    origins={}
    for name in ('freeze_admission','freeze_issuer','test_freeze_issuer'):
        module=sys.modules.get(name);path=Path(module.__file__).resolve() if module is not None else None
        if path is None or path.parent!=root or sha(path.read_bytes())!=expected[path.name]:raise ValueError('Loaded local origin differs')
        origins[name]=dict(path=path.name,sha256=expected[path.name])
    loaded=sorted(name for name in sys.modules if name.split('.')[0] in backends)
    record=dict(schema='qwen-candidate1-freeze-issuer-synthetic-proof-v1',passed=code==0 and tests==88 and bad==0 and not denials and not loaded,
        tests=tests,pytest_returncode=int(code),xml_bad=bad,pid=os.getpid(),pgid=os.getpgrp(),source_hashes_before=before,
        source_hashes_after=after,source_manifest_sha256=args.manifest_sha256,loaded_local_origins=origins,
        audit_denials=denials,model_backend_modules=loaded,python=sys.version,pytest_version=pytest.__version__,
        actual_model_or_private_body_read=False,actual_candidate_outcome_read=False,actual_freeze_published=False,
        execution_authorized=False,requires_independent_final_exit0_reap_and_report_hash=True)
    with (output/'report.json').open('xb') as stream:
        stream.write(canonical(record));stream.flush();os.fsync(stream.fileno())
    print(json.dumps(dict(passed=record['passed'],tests=tests,pid=record['pid'],pgid=record['pgid'],report_sha256=sha((output/'report.json').read_bytes()))))
    return 0 if record['passed'] else 1

if __name__=='__main__':raise SystemExit(main())
