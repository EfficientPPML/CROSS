"""Source-bound public-only continuation derivation and tests."""
from pathlib import Path
import hashlib,io,json,os,signal,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET
from validation_cleanup import cleanup_signals,termination_signals
from validation_terminal import terminal_scope
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def paths():return [P/n for n in ('plan.py','test_plan.py','collect.py','verify.py','README.md','source_inputs.json','validation_cleanup.py','validation_terminal.py',*json.loads((P/'source_inputs.json').read_bytes()))]
def write(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');tmp.replace(path)
def collect():
    out=P/'source-bound-v1';out.mkdir(exist_ok=False);start=time.monotonic();sources=paths()
    primary=cleanup_error=active=None
    report=dict(passed=False,cleanup_completed=False,children=[],HE=False,model_forward=False,
        scope='Public source/parameter-report/level/binary64 metadata and conditional exact-real certificate only; no actual refresh or joined execution.',
        cpu_affinity=sorted(os.sched_getaffinity(0)),python=sys.version)
    def child(command,filename):
        nonlocal active
        with (out/filename).open('w') as log:
            active=subprocess.Popen(command,cwd=out/'snapshot',stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            row=dict(pid=active.pid,process_reaped=False);report['children'].append(row)
            code=active.wait();row.update(process_reaped=True,exit_code=code);active=None;return code
    try:
        write(out/'report.json',report)
        before={str(p.relative_to(P)):sha(p) for p in sources};report['source_hashes_before']=before
        with tarfile.open(out/'sources.tar.gz','w:gz') as t:
            for source in sources:
                raw=source.read_bytes();name=str(source.relative_to(P));item=tarfile.TarInfo(name);item.size=len(raw)
                t.addfile(item,io.BytesIO(raw));target=out/'snapshot'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
        with tarfile.open(out/'sources.tar.gz') as t:
            ms=t.getmembers();assert len(ms)==len({m.name for m in ms})==len(before)
            assert all(m.isfile() for m in ms)
            assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in ms}==before
        assert {name:sha(out/'snapshot'/name) for name in before}==before
        report['test_exit_code']=child([sys.executable,'-m','pytest','-q','test_plan.py','--rootdir=.',f'--junitxml={out}/tests.xml'],'tests.log')
        report['plan_exit_code']=child([sys.executable,'plan.py'],'plan.log')
        suites=ET.parse(out/'tests.xml').getroot().findall('testsuite')
        report['tests']={name:sum(int(s.get(name,0)) for s in suites) for name in ('tests','errors','failures','skipped')}
        if report['tests']!=dict(tests=113,errors=0,failures=0,skipped=0):raise ValueError('all113 public checks required')
        report['source_archive_sha256']=sha(out/'sources.tar.gz')
        raw=(out/'snapshot/report.json').read_bytes();(out/'plan.json').write_bytes(raw)
        report['plan_sha256']=hashlib.sha256(raw).hexdigest()
        report['snapshot_hashes_after']={name:sha(out/'snapshot'/name) for name in before}
    except BaseException as error:
        primary=error;report['error']=dict(type=type(error).__name__,message=str(error))
    finally:
        with terminal_scope(report,out/'report.json',write,cleanup_signals,lambda:(primary,cleanup_error)):
            try:
                if active is not None:
                    if active.poll() is None:
                        os.killpg(active.pid,signal.SIGTERM)
                        try:active.wait(timeout=5)
                        except subprocess.TimeoutExpired:os.killpg(active.pid,signal.SIGKILL);active.wait()
                    report['children'][-1].update(process_reaped=True,exit_code=active.returncode)
                report['cleanup_completed']=True
            except BaseException as error:cleanup_error=error
            try:
                report['source_hashes_after']={str(p.relative_to(P)):sha(p) for p in sources}
                report['source_files_unchanged']=(report.get('source_hashes_before')==report['source_hashes_after']==report.get('snapshot_hashes_after'))
            except BaseException as error:
                if cleanup_error is None or (not isinstance(error,Exception) and isinstance(cleanup_error,Exception)):cleanup_error=error
                else:cleanup_error.add_note(repr(error))
            report['elapsed_s']=time.monotonic()-start
            report['passed']=(primary is None and cleanup_error is None and report.get('test_exit_code')==report.get('plan_exit_code')==0
                and report.get('source_files_unchanged') is True and all(r['process_reaped'] for r in report['children']))
            write(out/'report.json',report)
    if primary is not None:
        if cleanup_error is not None:primary.add_note(repr(cleanup_error))
        raise primary
    if cleanup_error is not None:raise cleanup_error
    print(json.dumps(dict(passed=report['passed'],tests=report['tests'],sources=len(report['source_hashes_before']),archive=report['source_archive_sha256'])))
    return report
if __name__=='__main__':
    result=None
    try:
        with termination_signals():result=collect()
    except BaseException as error:
        try:
            path=P/'source-bound-v1/report.json';r=json.loads(path.read_bytes());r['passed']=False
            r['termination_scope_failed']=dict(type=type(error).__name__,message=str(error))
            with cleanup_signals():write(path,r)
        except BaseException as publication:error.add_note(repr(publication))
        raise
    raise SystemExit(0 if result['passed'] else 1)
