"""Source-bound client-only embedding fixture checks; never launches encryption.

The client-only/ directory holds local arrays and must be excluded from evidence
archives. The sources tar contains only this collector, module, and test file.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.metadata
import io
import json
import os
import signal
import subprocess
import sys
import tarfile
import time
import xml.etree.ElementTree as ET

HERE=Path(__file__).resolve().parent
FILES=('client_inputs.py','test_client_inputs.py','collect_client_inputs.py')
SNAPSHOT=Path('/home/jianming_gatech/cross_validation_assets/bert/f150c1d609d1e50dd5e2e5408661cfac8339277c')
ASSET_PATHS={name:SNAPSHOT/name for name in ('config.json','model.safetensors','tokenizer.json','tokenizer_config.json','vocab.txt')}
ASSET_PATHS['prior_client_fixtures.npz']=Path('/tmp/bert-first-attention-owner-20261103/client_fixtures.npz')

def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def write(path,value):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');temp.replace(path)
def sources():return {name:(HERE/name).read_bytes() for name in FILES}
def digests(raw):return {name:hashlib.sha256(value).hexdigest() for name,value in raw.items()}
def stop(child):
    if child is None:return
    if child.poll() is None:
        os.killpg(child.pid,signal.SIGTERM)
        try:child.wait(timeout=30)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGKILL);child.wait()
    else:child.wait()
def archive(path,raw):
    with tarfile.open(path,'w:gz') as stream:
        for name,data in raw.items():
            member=tarfile.TarInfo(name);member.size=len(data);stream.addfile(member,io.BytesIO(data))
def verify_archive(path,expected):
    with tarfile.open(path) as stream:
        rows=stream.getmembers()
        if len(rows)!=len(expected) or len({x.name for x in rows})!=len(rows) or any(not x.isfile() for x in rows):return False
        return {x.name:hashlib.sha256(stream.extractfile(x).read()).hexdigest() for x in rows}==expected

def run(output):
    output.mkdir(exist_ok=False);start=time.monotonic();before={};assets={};child=None;primary=None;cleanup_errors=[];cancellation=None
    report=dict(passed=False,scope='Client-only BertEmbeddings and eight-tile packing; no encryption, encoder, pooler, classifier, or five-handler proof.',
                source_count=3,raw_arrays_archived=False,private_target_mapping_archived=False,
                cpu_affinity=sorted(os.sched_getaffinity(0)),fixed_native_numpy_gate=1e-12,
                native_dtype='float64',model_tensor_loads='five bert.embeddings tensors only')
    def attempt(label,fn):
        nonlocal cancellation
        try:return fn()
        except BaseException as error:
            cleanup_errors.append(dict(operation=label,type=type(error).__name__,message=str(error)))
            if primary is not None:primary.add_note(label+': '+repr(error))
            elif not isinstance(error,Exception) and cancellation is None:cancellation=error
            return None
    try:
        write(output/'report.json',report)
        raw=sources();before=digests(raw);archive(output/'sources.tar.gz',raw)
        if not verify_archive(output/'sources.tar.gz',before):raise ValueError('startup archive readback differs')
        report.update(source_hashes_before=before,source_archive_sha256=sha(output/'sources.tar.gz'))
        assets={name:sha(path) for name,path in ASSET_PATHS.items()}
        report.update(asset_hashes_before=assets,versions={name:importlib.metadata.version(name) for name in ('numpy','torch','transformers','tokenizers','safetensors','pytest')},
                      environment={k:os.environ.get(k) for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')})
        cases=output/'case-reports';cases.mkdir();local=output/'client-only';local.mkdir()
        env=dict(os.environ,CLIENT_INPUT_REPORT_DIR=str(cases),CLIENT_INPUT_LOCAL_DIR=str(local))
        command=[sys.executable,'-m','pytest','-q',str(HERE/'test_client_inputs.py'),'--junitxml='+str(output/'tests.xml')]
        with (output/'tests.log').open('wb') as log:
            child=subprocess.Popen(command,cwd=HERE,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            report.update(child_pid=child.pid,command=command);write(output/'report.json',report)
            code=child.wait()
        if code!=0:raise ValueError('client input tests exited '+str(code))
        suite=ET.parse(output/'tests.xml').getroot();groups=list(suite) if suite.tag=='testsuites' else [suite]
        report['tests']={name:sum(int(x.attrib.get(name,0)) for x in groups) for name in ('tests','failures','errors','skipped')}
        if report['tests']['failures'] or report['tests']['errors'] or report['tests']['skipped']:raise ValueError('incomplete client tests')
        reports=[json.loads((cases/f'case{i}.json').read_text()) for i in range(3)]
        if any(x['native_numpy_max_abs']>1e-12 for x in reports):raise ValueError('independent native gate failed')
        report.update(cases=reports,local_array_file_sha256={p.name:sha(p) for p in sorted(local.glob('*.npz'))},passed=True)
    except BaseException as error:
        primary=error;report.update(passed=False,error=dict(type=type(error).__name__,message=str(error)))
    finally:
        attempt('reap owned native test subprocess',lambda:stop(child))
        after=attempt('source readback',lambda:digests(sources()))
        final_assets=attempt('asset readback',lambda:{name:sha(path) for name,path in ASSET_PATHS.items()})
        verified=attempt('archive member readback',lambda:verify_archive(output/'sources.tar.gz',before)) if before else False
        report.update(source_hashes_after=after,asset_hashes_after=final_assets,source_archive_verified=verified is True,
                      source_files_unchanged=bool(before) and before==after,asset_files_unchanged=bool(assets) and assets==final_assets,
                      child_reaped=child is None or child.poll() is not None,cleanup_errors=cleanup_errors,elapsed_s=time.monotonic()-start)
        report['passed']=bool(report['passed'] and report['source_files_unchanged'] and report['asset_files_unchanged'] and verified and report['child_reaped'] and not cleanup_errors)
        try:write(output/'report.json',report)
        except BaseException as error:
            preserved=primary if primary is not None else cancellation
            if preserved is None:raise
            preserved.add_note('terminal report publication: '+repr(error))
        if primary is not None:raise primary
        if cancellation is not None:raise cancellation
    print(json.dumps({k:report[k] for k in ('passed','tests','elapsed_s','source_archive_sha256')}))
    return 0 if report['passed'] else 1

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();raise SystemExit(run(a.output))
