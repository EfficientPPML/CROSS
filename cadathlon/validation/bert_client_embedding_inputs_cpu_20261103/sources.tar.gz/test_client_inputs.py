"""Strict client-schema tests and independent native embedding/packing oracles."""
from pathlib import Path
import copy
import hashlib
import json
import os
import subprocess
import sys
import numpy as np
import pytest
from client_inputs import (ASSETS, EMBEDDING_SHAPES, ClientEmbeddings, ValidatedInput,
    file_sha256, pack_embeddings, read_preprocessed_jsonl, validate_record)

HERE=Path(__file__).resolve().parent
SNAPSHOT=Path('/home/jianming_gatech/cross_validation_assets/bert/f150c1d609d1e50dd5e2e5408661cfac8339277c')
PRIOR=Path('/tmp/bert-first-attention-owner-20261103/client_fixtures.npz')
PRIOR_SHA='184397324e50f8c33cd6ea62f47457b3b0992da85814c001927b412ca6d06ce7'
TOKENIZER_SHA={
 'tokenizer.json':'5b3360be30cdf39081153cf9d30bfb0503c011462fc9f77f097127c83ef0f4d9',
 'tokenizer_config.json':'0f6d13e6f4da6f9e24f22ada6bc3be571123d858d7c0c05a8a7cd55a9c23c2e8',
 'vocab.txt':'eeaa9875b23b04b4c54ef759d03db9d1ba1554838f8fb26c5d96fa551df93d02'}
PAIRS=(
 ('The committee approved the proposal.','The committee approved the proposal.'),
 ('The committee reviews the proposal and discusses the evidence. '*20,
  'Members discuss the proposal before reaching a decision. '*20),
)
NONCONTIGUOUS=(0,1,4,7,15,16,31,63,64,95,127)

def sample(target=9):
    return dict(target_idx=target,input_ids=[101]+[500]*127,
                token_type_ids=[0]*64+[1]*64,attention_mask=[1]*15+[0]*113)

def write_records(path,records):
    path.write_text(''.join(json.dumps(row,allow_nan=False)+'\n' for row in records))

def test_backend_free_import():
    code='import client_inputs,sys; assert not any(x in sys.modules for x in ("torch","jax","transformers","safetensors"))'
    subprocess.run([sys.executable,'-c',code],cwd=HERE,check=True)

def test_jsonl_order_and_private_ids(tmp_path):
    path=tmp_path/'rows.jsonl';write_records(path,[sample(19),sample(3)])
    result=read_preprocessed_jsonl(path)
    assert tuple(x.target_idx for x in result)==(19,3)
    assert all(type(x.input_ids)is tuple for x in result)

@pytest.mark.parametrize('kind',('extra','missing','duplicate_ids','bool_id','float_id','negative_id','string_id',
    'short','long','token_bool','token_float','token_negative','token_high','type_bool','type_high','mask_bool',
    'mask_float','mask_high','no_cls','masked_cls','tuple_tokens','nested'))
def test_schema_rejects_coercions_and_bad_contract(tmp_path,kind):
    row=sample();rows=[row]
    if kind=='extra':row['label']=1
    elif kind=='missing':del row['input_ids']
    elif kind=='duplicate_ids':rows.append(copy.deepcopy(row))
    elif kind in ('bool_id','float_id','negative_id','string_id'):row['target_idx']={'bool_id':True,'float_id':9.,'negative_id':-1,'string_id':'9'}[kind]
    elif kind=='short':row['input_ids'].pop()
    elif kind=='long':row['attention_mask'].append(0)
    elif kind.startswith('token_'):row['input_ids'][1]={'token_bool':True,'token_float':500.,'token_negative':-1,'token_high':28996}[kind]
    elif kind.startswith('type_'):row['token_type_ids'][1]={'type_bool':False,'type_high':2}[kind]
    elif kind.startswith('mask_'):row['attention_mask'][1]={'mask_bool':True,'mask_float':1.,'mask_high':2}[kind]
    elif kind=='no_cls':row['input_ids'][0]=100
    elif kind=='masked_cls':row['attention_mask'][0]=0
    elif kind=='tuple_tokens':
        row['input_ids']=tuple(row['input_ids'])
        with pytest.raises(ValueError):validate_record(row)
        return
    else:row['input_ids'][1]=[1]
    path=tmp_path/'rows.jsonl';write_records(path,rows)
    with pytest.raises(ValueError):read_preprocessed_jsonl(path)

@pytest.mark.parametrize('raw',('', '\n', '{}\n\n', '{"target_idx":1,"target_idx":2}\n', '{"a":NaN}\n','[]\n'))
def test_invalid_jsonl_records(tmp_path,raw):
    path=tmp_path/'rows.jsonl';path.write_text(raw)
    with pytest.raises(ValueError):read_preprocessed_jsonl(path)

def test_nonregular_and_limits(tmp_path):
    path=tmp_path/'rows.jsonl';write_records(path,[sample()])
    with pytest.raises(ValueError):read_preprocessed_jsonl(path,byte_limit=8)
    alias=tmp_path/'alias';alias.symlink_to(path)
    with pytest.raises(OSError):read_preprocessed_jsonl(alias)
    fifo=tmp_path/'fifo';os.mkfifo(fifo)
    with pytest.raises(ValueError):read_preprocessed_jsonl(fifo)
    with pytest.raises(ValueError):read_preprocessed_jsonl(path,byte_limit=True)

@pytest.mark.parametrize('positions',((0,),tuple(range(15)),tuple(range(128)),NONCONTIGUOUS))
def test_distinct_rows_pack_all_slots_and_detach(positions):
    row=sample();row['attention_mask']=[int(i in positions) for i in range(128)]
    record=validate_record(row);values=np.arange(128*768,dtype=np.float64).reshape(128,768)-9876.
    expected=values[list(positions)].copy();prepared=pack_embeddings(record,values)
    assert len(prepared.tiles)==8 and all(t.shape==(65536,) and t.dtype==np.float64 and not t.flags.writeable for t in prepared.tiles)
    assert all(not np.shares_memory(a,b) for i,a in enumerate(prepared.tiles) for b in prepared.tiles[i+1:])
    packed=np.concatenate(prepared.tiles).reshape(128,4096)
    np.testing.assert_array_equal(packed[:len(positions),:768],expected)
    assert np.count_nonzero(packed[:,768:])==0 and np.count_nonzero(packed[len(positions):])==0
    values[:]=12345.;np.testing.assert_array_equal(np.concatenate(prepared.tiles).reshape(128,4096)[:len(positions),:768],expected)
    with pytest.raises(ValueError):prepared.tiles[0].flags.writeable=True
    public=prepared.public_metadata();assert 'target_idx' not in public and 'input_ids' not in public and 'token_type_ids' not in public
    assert public['original_positions']==list(positions) and public['original_attention_mask']==row['attention_mask']
    assert public['valid_rows']==[max(0,min(16,len(positions)-16*i)) for i in range(8)]
    public['original_positions'][0]=99;public['packing']['slots']=1
    assert prepared.public_metadata()['original_positions'][0]==0 and prepared.public_metadata()['packing']['slots']==65536

@pytest.mark.parametrize('kind',('float32','complex','shape','nan','inf'))
def test_pack_rejects_bad_native_boundary(kind):
    x=np.zeros((128,768),dtype=np.float64)
    if kind=='float32':x=x.astype(np.float32)
    elif kind=='complex':x=x.astype(complex)
    elif kind=='shape':x=x[:127]
    else:x[0,0]=np.nan if kind=='nan' else np.inf
    with pytest.raises(ValueError):pack_embeddings(validate_record(sample()),x)

def test_batch_ids_checked_before_native_work():
    owner=object.__new__(ClientEmbeddings);calls=[];owner.prepare=lambda row:calls.append(row)
    with pytest.raises(ValueError):owner.prepare_batch([sample(),sample()])
    assert calls==[]
    bad=sample(2);bad['input_ids'][1]=True
    with pytest.raises(ValueError):owner.prepare_batch([sample(),bad])
    assert calls==[]

@pytest.fixture(scope='module')
def native_case(tmp_path_factory):
    import torch
    import safetensors
    import transformers.models.bert.modeling_bert as bert
    from transformers import AutoTokenizer
    torch.set_num_threads(4)
    assert {k:file_sha256(SNAPSHOT/k) for k in TOKENIZER_SHA}==TOKENIZER_SHA
    assert file_sha256(PRIOR)==PRIOR_SHA
    calls=[];original=safetensors.safe_open
    class Reader:
        def __init__(self,*args,**kwargs):self.reader=original(*args,**kwargs)
        def __enter__(self):self.inner=self.reader.__enter__();return self
        def __exit__(self,*args):return self.reader.__exit__(*args)
        def get_tensor(self,name):calls.append(name);return self.inner.get_tensor(name)
    mp=pytest.MonkeyPatch();mp.setattr(safetensors,'safe_open',Reader)
    def forbidden(*args,**kwargs):raise AssertionError('encoder/pooler/classifier model construction forbidden')
    for name in ('BertModel','BertForSequenceClassification','BertEncoder','BertPooler'):
        mp.setattr(getattr(bert,name),'__init__',forbidden)
    before=torch.random.get_rng_state().clone()
    try:
        owner=ClientEmbeddings(SNAPSHOT)
        assert torch.equal(before,torch.random.get_rng_state())
        assert calls==['bert.embeddings.'+n for n in EMBEDDING_SHAPES]
        tokenizer=AutoTokenizer.from_pretrained(SNAPSHOT,local_files_only=True)
        rows=[]
        for i,pair in enumerate(PAIRS):
            token=tokenizer(*pair,max_length=128,truncation=True,padding='max_length')
            rows.append(dict(target_idx=(81,7)[i],**token))
        extra=copy.deepcopy(rows[1]);extra['target_idx']=29;extra['attention_mask']=[int(i in NONCONTIGUOUS) for i in range(128)]
        rows.append(extra)
        input_file=tmp_path_factory.mktemp('private-inputs')/'fixed.jsonl'
        write_records(input_file,rows)
        records=read_preprocessed_jsonl(input_file)
        assert tuple(r.target_idx for r in records)==(81,7,29)
        yield owner,records
    finally:mp.undo()

def independent_numpy(owner,record):
    p={n:v.detach().numpy() for n,v in owner._module.state_dict().items()}
    # Independent lookups, original0..127 positions, NumPy population moments.
    x=p['word_embeddings.weight'][list(record.input_ids)] + p['token_type_embeddings.weight'][list(record.token_type_ids)]
    x=x+p['position_embeddings.weight'][np.arange(128)]
    centered=x-x.mean(axis=-1,keepdims=True)
    return centered/np.sqrt(np.mean(centered*centered,axis=-1,keepdims=True)+1e-12)*p['LayerNorm.weight']+p['LayerNorm.bias']

@pytest.mark.parametrize('index',(0,1,2))
def test_native_embeddings_independent_oracle_original_positions_and_padding(native_case,index):
    owner,records=native_case;record=records[index]
    native=owner.original_embeddings(record);oracle=independent_numpy(owner,record)
    error=float(np.max(np.abs(native-oracle)));assert error<1e-12
    prepared=owner.prepare(record);positions=prepared.original_positions;K=len(positions)
    assert K==(15,128,len(NONCONTIGUOUS))[index]
    packed=np.concatenate(prepared.tiles).reshape(128,4096)
    np.testing.assert_allclose(packed[:K,:768],oracle[list(positions)],atol=1e-12,rtol=0)
    assert np.count_nonzero(packed[K:])==0 and np.count_nonzero(packed[:,768:])==0
    old_error=None
    if index<2:
        with np.load(PRIOR,allow_pickle=False) as old:
            old_error=float(np.max(np.abs(packed[:K,:768]-old[f'K{K}_embeddings'][:K])))
            assert old_error==0.
    else:
        # A compact-before-position implementation would assign wrong learned positions.
        wrong=ValidatedInput(record.target_idx,record.input_ids,record.token_type_ids,tuple([1]*K+[0]*(128-K)))
        wrong_pos=independent_numpy(owner,wrong)[:K]
        assert float(np.max(np.abs(packed[:K,:768]-wrong_pos)))>.1
    dest=os.environ.get('CLIENT_INPUT_REPORT_DIR')
    if dest:
        dest=Path(dest);dest.mkdir(exist_ok=True)
        hashes=[hashlib.sha256(t.tobytes()).hexdigest() for t in prepared.tiles]
        report=dict(case=index,public_metadata=prepared.public_metadata(),native_numpy_max_abs=error,prior_native_max_abs=old_error,
                    fixed_gate=1e-12,tile_sha256=hashes,asset_sha256=owner.asset_sha256,tensor_sha256=owner.tensor_sha256,
                    private_target_mapping_archived=False,loaded_tensor_names=list(EMBEDDING_SHAPES))
        (dest/f'case{index}.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
        # Client-only artifacts; collector archives hashes, never these arrays/records.
        local=Path(os.environ['CLIENT_INPUT_LOCAL_DIR']);local.mkdir(exist_ok=True)
        np.savez(local/f'case{index}.npz',**{f'tile{i}':t for i,t in enumerate(prepared.tiles)})

def test_native_eval_mode_and_batch_order(native_case):
    owner,records=native_case
    batch=owner.prepare_batch(records);assert tuple(x.target_idx for x in batch)==(81,7,29)
    owner._module.train()
    try:
        with pytest.raises(ValueError):owner.prepare(records[0])
    finally:owner._module.eval()
