from pathlib import Path
import ast,json,pytest
HERE=Path(__file__).resolve().parent

def defs(path):return {n.name:ast.dump(n,include_attributes=False)for n in ast.parse(path.read_bytes()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}

def test_original_handler_byte_exact_no_optional_receipt():
 assert (HERE/'runtime/stage/file_stages.py').read_bytes()==(HERE/'baseline/file_stages.py').read_bytes()
 tree=ast.parse((HERE/'runtime/stage/file_stages.py').read_bytes())
 fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='client_decrypt_decode')
 assert not fn.args.kwonlyargs
 calls=[n for n in ast.walk(fn)if isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id=='record_completed']
 assert len(calls)==1 and all(k.arg!='completion_directory'for k in calls[0].keywords)

def test_only_receipt_tree_observe_changed():
 old=defs(HERE/'baseline/request_lifecycle.py');new=defs(HERE/'runtime/stage/request_lifecycle.py')
 assert old.keys()==new.keys() and {n for n in old if old[n]!=new[n]}=={'_tree','_observe'}
 assert 'completion_path'not in new

def test_default_receipt_path_and_no_retirement_in_selected_worker():
 source=(HERE/'runtime/stage/request_lifecycle.py').read_text();tree=ast.parse(source)
 fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='record_completed')
 assert all(a.arg!='completion_directory'for a in fn.args.kwonlyargs)and "completed.json"in ast.get_source_segment(source,fn)
 selected=ast.parse((HERE/'original_client_worker.py').read_bytes())
 calls=[n for n in ast.walk(selected)if isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and n.func.attr=='client_decrypt_decode']
 assert len(calls)==1 and all(k.arg!='completion_directory'for k in calls[0].keywords)
 assert not any(isinstance(n,ast.Attribute)and n.attr=='retire_completed'for n in ast.walk(selected))

def test_original217_manifest_and_independent_producer_dependencies():
 p=json.loads((HERE/'client_89_sources.json').read_bytes());h=__import__('hashlib').sha256
 for n in ('stage4_gate.py','stage4_source_manifest.json','stage3_gate.py','stage3_source_manifest.json','key_gate.py','key_source_manifest.json','model_gate.py','dependencies.json','client_metrics.py'):
  assert h((HERE/n).read_bytes()).hexdigest()==p[n]
 assert len(json.loads((HERE/'stage4_source_manifest.json').read_bytes()))==217
 assert not (HERE/'combined_server_gate.py').exists()

def test_worker_dispatches_original217_gate_only():
 source=(HERE/'original_client_worker.py').read_text();assert 'combined_server_gate'not in source and 'response_root'not in source
 assert 's.stage4_gate.authenticate('in source

from test_stage4_gate import case,stage3_case
@pytest.mark.parametrize('rewrite_inventory',[False,True])
def test_combined286_source_producer_cannot_replace_original217(case,monkeypatch,rewrite_inventory):
 import stage4_gate as g,key_gate
 expected={f'source{i}.py':'0'*64 for i in range(286)}
 for n in ('source_hashes_start','source_hashes_end','execution_source_hashes_end'):case.report[n]=expected
 for n in ('source_hashes_start','source_hashes_end'):case.worker[n]=expected
 if rewrite_inventory:
  raw=key_gate.canonical(expected);(g.HERE/'stage4_source_manifest.json').write_bytes(raw)
  (g.HERE/'dependencies.json').write_bytes(key_gate.canonical(dict(stage4_source_inventory_sha256=key_gate.digest(raw))))
 with pytest.raises(ValueError,match='exact217|source inventory'):case.check()

def test_exact_allowed_runtime_definition_delta():
 allowed={
  'client_keys.py':({'_CloseState','_stream'},{'_read','_sha_fd'}),
  'key_contexts.py':(set(),{'_map_array'}),
  'file_stage_io.py':(set(),{'new_file','read_manifest'}),
  'request_lifecycle.py':(set(),{'_tree','_observe'}),
 }
 for name,(added,changed)in allowed.items():
  old=defs(HERE/'baseline'/name);new=defs(HERE/'runtime/stage'/name)
  assert new.keys()-old.keys()==added and not old.keys()-new.keys()
  assert {n for n in old.keys()&new.keys()if old[n]!=new[n]}==changed
