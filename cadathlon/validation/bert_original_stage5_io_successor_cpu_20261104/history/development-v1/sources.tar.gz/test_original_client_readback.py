"""Reserved for independent synthetic original-receipt tests; preparation pending."""
