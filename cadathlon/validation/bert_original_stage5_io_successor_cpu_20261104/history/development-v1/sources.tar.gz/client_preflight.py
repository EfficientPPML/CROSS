"""Source-bound synthetic and installed-denial client proof, never actual decode."""
from pathlib import Path
import argparse,json,os,sys,time
import xml.etree.ElementTree as ET
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import client_io as common
import client_source_guard as sources
TESTS=('test_client_io.py','test_client_source_guard.py','test_original_default.py','test_original_client_worker.py','test_original_client_collect.py','test_original_client_readback.py','test_stage4_gate.py','test_receipt_io.py','test_client_descriptor_io.py')

def run(output,*,expected_tests):
    if type(expected_tests)is not int or expected_tests<130:raise ValueError('explicit complete expected test count required')
    output=Path(output);common.outside(output,(HERE,));output.mkdir(mode=0o700,exist_ok=False)
    from cleanup import cleanup_signals,termination_signals
    from client_processes import OwnedChild
    report=dict(passed=False,body_complete=False,termination_scope_completed=False,cleanup_completed=False,
        actual_HE=False,actual_client_decode=False,pid=os.getpid(),children=[],expected_tests=expected_tests,
        scope='Source-bound mocked worker/collector and real installed entrypoint denials; no retained payload, context, key, model or encrypted execution')
    def body(r):
        started=time.monotonic();before={};primary=None;children=[]
        try:
            r['software']=common.software_versions()
            raw=sources.raw_sources(HERE);before=common.hashes(raw);r.update(source_hashes_start=before,source_count=len(before),source_bytes=sum(map(len,raw.values())),initial_guard=sources.check_sources(before,HERE))
            common.archive(output/'sources.tar.gz',sources.raw_sources(HERE));common.check_archive(output/'sources.tar.gz',before)
            common.write(output/'source_manifest.json',before);r['source_archive_sha256']=common.digest(common.read(output/'sources.tar.gz',32<<20))
            env=os.environ.copy();env.update(JAX_PLATFORMS='cpu',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
            for n in tuple(env):
                if n.startswith(('CROSS_','BOOTSTRAP_','PYTEST_','PYTHONINSPECT','PYTHONSTARTUP')):env.pop(n)
            commands=[('tests',[sys.executable,'-m','pytest','--rootdir='+str(HERE),'--confcutdir='+str(HERE),'-q','--tb=short',*TESTS,'--junitxml='+str(output/'tests.xml')]),
                      ('installed',[sys.executable,str(HERE/'client_installed_probe.py'),'--source-manifest',str(output/'source_manifest.json'),
                                    '--source-manifest-sha256',common.digest(common.read(output/'source_manifest.json')),'--output',str(output/'installed.json')])]
            for name,command in commands:
                selected=env|({'PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1'}if name=='tests'else{})
                with (output/(name+'.log')).open('x')as log:
                    child=OwnedChild(command,cwd=HERE,stdout=log,env=selected,term_grace=30.,kill_grace=30.);children.append(child)
                    r['children'].append(dict(name=name,command=command,process=child.record));common.write(output/'report.json',r)
                    code=child.wait()
                if code!=0:raise ValueError('public preflight child failed: '+name)
            cases=list(ET.parse(output/'tests.xml').iter('testcase'));bad=sum(len(x.findall(kind))for x in cases for kind in ('failure','error','skipped'))
            if len(cases)!=expected_tests or bad:raise ValueError('complete fixed test suite required')
            installed=common.parse(common.read(output/'installed.json'))
            if (any(installed.get(n)is not True for n in ('passed','body_complete','termination_scope_completed','cleanup_completed','source_files_unchanged','all_forbidden_entries_restored','allowed_client_entries_unchanged'))
                or installed.get('denied_count')!=21 or installed.get('source_hashes_start')!=before or installed.get('source_hashes_end')!=before):raise ValueError('installed boundary proof incomplete')
            r.update(test_count=len(cases),test_failures=bad,installed_denials=21,installed_report_sha256=common.digest(common.read(output/'installed.json')),
                body_complete=True)
        except BaseException as error:primary=error
        finally:
            final=common.Finalizer(r,primary)
            def cleanup():
                for child in children:final.attempt('owned preflight child',lambda child=child:child.close(primary=primary))
                r['all_started_children_reaped']=all(child.record.get('direct_child_reaped')is True and child.record.get('group_empty_verified')is True and child.record.get('cleanup_completed')is True and not child.record.get('cleanup_errors')for child in children)
                r['source_hashes_end']=final.attempt('source readback',lambda:common.hashes(sources.raw_sources(HERE)))
                r['source_archive_verified']=final.attempt('archive readback',lambda:common.check_archive(output/'sources.tar.gz',before))is True if before else False
                r['final_guard']=final.attempt('loaded origin readback',lambda:sources.check_sources(before,HERE))if before else None
            final.shielded(cleanup_signals,cleanup)
            r.update(source_files_unchanged=bool(before)and r.get('source_hashes_end')==before,cleanup_completed=not r.get('cleanup_errors')and r['all_started_children_reaped'],elapsed_s=time.monotonic()-started)
            r['body_complete']=bool(r.get('body_complete')and r['source_files_unchanged']and r['source_archive_verified']and r['cleanup_completed'])
            final.attempt('preflight terminal publication',lambda:common.write(output/'report.json',r));final.raise_if_failed()
    return common.finish(output/'report.json',report,body,termination_signals,cleanup_signals)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('output',type=Path);p.add_argument('--expected-tests',type=int,required=True);a=p.parse_args()
    r=run(a.output,expected_tests=a.expected_tests);print(json.dumps({n:r[n]for n in ('passed','source_count','test_count','installed_denials','elapsed_s')}));raise SystemExit(0 if r['passed']else 1)
