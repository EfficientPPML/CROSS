from pathlib import Path
from contextlib import nullcontext
from types import SimpleNamespace
import copy,json,pytest
import original_client_collect as c

@pytest.fixture
def proof(tmp_path):
 prereq={n:n for n in ('public_batch_sha256','response_batch_sha256','response_manifest_sha256','input_digest')};expected={'a':'h'}
 flags=('termination_scope_completed','cleanup_completed','source_files_unchanged','public_payload_verified_before_private','private_access_started','actual_client_decode_started','actual_client_decode_completed','readback_complete','operation_complete','original_private_existing_files_unchanged','keygen_encrypt_native_server_forbidden','result_retained','upload_retained','io_retained','download_retained','original_private_retained','external_workspaces_never_removed','completion_receipt_default')
 p={n:True for n in flags};p.update({n:False for n in ('keygen','encryption','server_compute','model_forward','retirement')});p.update(source_hashes_start=expected,source_hashes_end=expected,prerequisite=prereq,result_workspace=str(tmp_path/'result'),result_workspace_identity=[1,2],numeric_gates_passed=True,body_complete=True,passed=True)
 p['readback']=dict(metrics={'passed':True},sample_count=1,private_receipt_validated=True,result_permissions_0600=True,default_completion_receipt=True,retirement_performed=False,public_batch_sha256=prereq['public_batch_sha256'])
 p['public_response_readback']=prereq|dict(passed=True,private_data_read=False)
 process=dict(direct_child_reaped=True,group_empty_verified=True,cleanup_completed=True,direct_returncode=0)
 return p,process,expected,prereq,tmp_path/'result',[1,2]

def test_accepts_completed_pass(proof):assert c.validate_worker(*proof)is True

def test_completed_numeric_failure_stays_failure(proof):
 p,process,*_=proof
 for name in ('passed','body_complete','numeric_gates_passed'):p[name]=False
 p['readback']['metrics']['passed']=False;process['direct_returncode']=1
 assert c.validate_worker(*proof)is False

@pytest.mark.parametrize('field',['termination_scope_completed','public_payload_verified_before_private','original_private_existing_files_unchanged','completion_receipt_default','result_retained','source_files_unchanged'])
def test_incomplete_worker_rejected(proof,field):
 proof[0][field]=False
 with pytest.raises(ValueError):c.validate_worker(*proof)

@pytest.mark.parametrize('bad',[1,0,None,'true'])
def test_metric_exact_boolean(proof,bad):
 proof[0]['readback']['metrics']['passed']=bad
 with pytest.raises(ValueError):c.validate_worker(*proof)

@pytest.mark.parametrize('field',['direct_child_reaped','group_empty_verified','cleanup_completed'])
def test_process_terminal_required(proof,field):
 proof[1][field]=False
 with pytest.raises(ValueError):c.validate_worker(*proof)

def test_mixed_source_and_response_rejected(proof):
 proof[0]['public_response_readback']['response_manifest_sha256']='changed'
 with pytest.raises(ValueError):c.validate_worker(*proof)

@pytest.mark.parametrize('root',['fixture','reference'])
@pytest.mark.parametrize('placement',['inside','alias','ancestor'])
def test_output_containment_before_mkdir(tmp_path,monkeypatch,root,placement):
 fixture=tmp_path/'fixture';reference=tmp_path/'reference'
 for p in (fixture,reference):p.mkdir();(p/'sentinel').write_text('preserve')
 selected={'fixture':fixture,'reference':reference}[root]
 args={n:tmp_path/('held-'+n) for n in ('key_workspace','model_workspace','io_workspace','key_evidence','model_evidence','stage3_evidence','stage4_evidence','fixture_evidence','reference_evidence')}
 args.update(reference_report_sha256='hash')
 fake=SimpleNamespace(worker_services=SimpleNamespace(reference_gate=SimpleNamespace(public_metadata=lambda *a:dict(private_workspace=reference))),worker=SimpleNamespace(fixture_root_public=lambda a:fixture))
 monkeypatch.setattr(c,'services',lambda:fake)
 monkeypatch.setattr(c.worker,'bootstrap',lambda *a:({},{}))
 if placement=='inside':output=selected/'new'
 elif placement=='ancestor':output=tmp_path
 else:alias=tmp_path/'alias';alias.symlink_to(selected,target_is_directory=True);output=alias/'new'
 with pytest.raises(ValueError):c.run(output,result_workspace=tmp_path/'results',source_manifest=tmp_path/'manifest',source_manifest_sha256='synthetic',**args)
 assert sorted(p.name for p in selected.iterdir())==['sentinel']

def test_prepare_only_never_calls_prerequisite_or_private(tmp_path,monkeypatch):
 output=tmp_path/'out';output.mkdir();raw={'a.py':b'pass'};h=c.io.hashes(raw)
 monkeypatch.setattr(c.io,'environment',lambda:{})
 monkeypatch.setattr(c.sources,'raw_sources',lambda *a:raw)
 monkeypatch.setattr(c.sources,'check_sources',lambda *a:{'passed':True})
 def forbidden(*a,**k):raise AssertionError('no actual gate/worker allowed')
 s=SimpleNamespace(worker=SimpleNamespace(public_gates=forbidden),cleanup_signals=nullcontext)
 r={};c.body(r,output=output,result_root=tmp_path/'private',execute=False,args={},worker_python=Path('unused'),s=s)
 assert r['body_complete']and r['preparation_complete']and r['all_processes_reaped']and r['source_hashes_end']==h
 assert not(tmp_path/'private').exists()

@pytest.mark.parametrize('kind',[ValueError,KeyboardInterrupt,SystemExit])
def test_body_source_failure_preserves_primary(tmp_path,monkeypatch,kind):
 out=tmp_path/'out';out.mkdir();error=kind('source')
 monkeypatch.setattr(c.io,'environment',lambda:None)
 def bad(*a):raise error
 monkeypatch.setattr(c.sources,'raw_sources',bad)
 r={}
 with pytest.raises(kind)as got:c.body(r,output=out,result_root=tmp_path/'private',execute=False,args={},worker_python=Path('unused'),s=SimpleNamespace(cleanup_signals=nullcontext))
 assert got.value is error and not r['body_complete']

@pytest.mark.parametrize('accepted',[True,False])
def test_full_collector_mock_executes_separate_child_and_retains(tmp_path,monkeypatch,proof,accepted):
 output=tmp_path/'out';output.mkdir();result=tmp_path/'results';borrowed=tmp_path/'borrowed';borrowed.mkdir();upload=borrowed/'upload';upload.mkdir();(borrowed/'download').mkdir()
 raw={'runtime/stage/server_inputs/p60_profile_and_refresh.json':b'{}','runtime/stage/server_inputs/twelve_layer_plan.json':b'{}','original_client_worker.py':b'pass'};before=c.io.hashes(raw)
 monkeypatch.setattr(c.io,'environment',lambda:None);monkeypatch.setattr(c.sources,'raw_sources',lambda *a:raw);monkeypatch.setattr(c.sources,'check_sources',lambda *a:{'passed':True})
 p,record,*_=proof;prereq=p['prerequisite'];seen=[];authorized=({}, {}, {}, {}, {})
 def public(*a):seen.append('public');return authorized
 fakeworker=SimpleNamespace(public_gates=public,summary=lambda _:prereq,protect_result=lambda *a:None,fixture_root_public=lambda _:tmp_path/'fixture')
 class Child:
  def __init__(self,command,**kw):
   assert command[1]=='-I'and command[2]==str(output/'execution_source/original_client_worker.py')and kw['term_grace']==kw['kill_grace']==30.
   seen.append('child');self.record=copy.deepcopy(record);self.record['direct_returncode']=0 if accepted else 1
   values={command[i][2:].replace('-','_'):command[i+1]for i in range(3,len(command),2)}
   r=copy.deepcopy(p);r.update(source_hashes_start=before,source_hashes_end=before,result_workspace=str(result),result_workspace_identity=json.loads(values['result_identity']),elapsed_s=1.)
   for n in ('passed','body_complete','numeric_gates_passed'):r[n]=accepted
   r['readback']['metrics']['passed']=accepted;c.io.write(Path(values['output']),r)
  def wait(self):return self.record['direct_returncode']
  def close(self,primary=None):seen.append('close')
 s=SimpleNamespace(worker=fakeworker,worker_services=None,cleanup_signals=nullcontext,OwnedChild=Child)
 r={};c.body(r,output=output,result_root=result,execute=True,args=dict(io_workspace=borrowed),worker_python=Path('/synthetic-python'),s=s)
 assert r['operation_complete']and r['actual_client_decode']and r['numeric_gates_passed']is accepted and r['body_complete']is accepted
 assert r['source_files_unchanged']and r['result_retained']and r['all_processes_reaped']and seen==['public','child','public','close']
 assert result.exists()and upload.exists()and(borrowed/'download').exists()

@pytest.mark.parametrize('kind',[ValueError,KeyboardInterrupt,SystemExit])
def test_preflight_outer_restore_failure_is_terminal_false(tmp_path,monkeypatch,kind):
 import client_preflight as p
 from contextlib import contextmanager
 import cleanup,client_processes
 primary=kind('scope restore');out=tmp_path/'preflight';raw={'source.py':b'pass'};hashes=c.io.hashes(raw)
 @contextmanager
 def bad():yield;raise primary
 monkeypatch.setattr(cleanup,'termination_signals',bad)
 monkeypatch.setattr(p.common,'software_versions',lambda:{})
 monkeypatch.setattr(p.sources,'raw_sources',lambda *a:raw)
 monkeypatch.setattr(p.sources,'check_sources',lambda *a:{'passed':True})
 class Child:
  def __init__(self,command,**kw):
   self.record=dict(direct_child_reaped=True,group_empty_verified=True,cleanup_completed=True,cleanup_errors=[])
   if '-m'in command:
    (out/'tests.xml').write_text('<testsuite>'+''.join('<testcase name="x"/>'for _ in range(130))+'</testsuite>')
   else:
    report={n:True for n in ('passed','body_complete','termination_scope_completed','cleanup_completed','source_files_unchanged','all_forbidden_entries_restored','allowed_client_entries_unchanged')}
    report.update(denied_count=21,source_hashes_start=hashes,source_hashes_end=hashes);c.io.write(out/'installed.json',report)
  def wait(self):return 0
  def close(self,primary=None):pass
 monkeypatch.setattr(client_processes,'OwnedChild',Child)
 with pytest.raises(kind)as got:p.run(out,expected_tests=130)
 assert got.value is primary
 r=json.loads((out/'report.json').read_text());assert not r['passed']and not r['termination_scope_completed']and r['body_complete']
