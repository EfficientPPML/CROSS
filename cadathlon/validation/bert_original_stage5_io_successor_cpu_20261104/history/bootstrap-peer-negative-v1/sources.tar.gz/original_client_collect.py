"""Isolated size0 client collector; private results retained, no retirement."""
from pathlib import Path
import argparse,json,os,sys,time
HERE=Path(__file__).resolve().parent

def _cli_bootstrap():
    import hashlib,importlib.util,stat
    if not sys.flags.isolated:raise ValueError('actual client CLI requires isolated Python startup (-I)')
    parser=argparse.ArgumentParser(add_help=False)
    parser.add_argument('--source-manifest',type=Path,required=True);parser.add_argument('--source-manifest-sha256',required=True)
    args,_=parser.parse_known_args()
    def bounded(path):
        fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK);primary=None
        try:
            info=os.fstat(fd)
            if not stat.S_ISREG(info.st_mode)or not 0<info.st_size<=1<<20:raise ValueError('bounded regular bootstrap source required')
            parts=[];left=(1<<20)+1
            while left:
                part=os.read(fd,min(left,65536))
                if not part:break
                parts.append(part);left-=len(part)
            raw=b''.join(parts)
            if len(raw)!=info.st_size:raise ValueError('bootstrap source changed size')
            return raw
        except BaseException as error:primary=error;raise
        finally:
            try:os.close(fd)
            except BaseException as error:
                if primary is None:raise
                if error is not primary:primary.add_note('bootstrap source close: '+repr(error))
    raw=bounded(args.source_manifest)
    if len(raw)>1<<20 or hashlib.sha256(raw).hexdigest()!=args.source_manifest_sha256:raise ValueError('external source manifest digest differs before local imports')
    def pairs(rows):
        out={}
        for key,value in rows:
            if key in out:raise ValueError('duplicate source field')
            out[key]=value
        return out
    expected=json.loads(raw,object_pairs_hook=pairs)
    for name in (Path(__file__).name,'client_bootstrap.py'):
        data=bounded(HERE/name)
        if len(data)>1<<20 or hashlib.sha256(data).hexdigest()!=expected.get(name):raise ValueError('bootstrap/entry bytes differ before local imports')
    if 'client_bootstrap'in sys.modules:raise ValueError('bootstrap helper already loaded before fresh source gate')
    spec=importlib.util.spec_from_file_location('client_bootstrap',HERE/'client_bootstrap.py');module=importlib.util.module_from_spec(spec);sys.modules['client_bootstrap']=module;exec(compile(data,str(HERE/'client_bootstrap.py'),'exec'),module.__dict__)
    return module.verify(HERE,expected,fresh=True)

_CLI_BOOTSTRAP=_cli_bootstrap()if __name__=='__main__'else None

sys.path[:0]=[str(HERE),str(HERE/'runtime/stage'),str(HERE/'runtime')]
import client_io as io
import client_source_guard as sources
import original_client_worker as worker

def services():
    from types import SimpleNamespace
    from client_processes import OwnedChild
    from cleanup import cleanup_signals,termination_signals
    return SimpleNamespace(OwnedChild=OwnedChild,cleanup_signals=cleanup_signals,termination_signals=termination_signals,worker=worker,worker_services=worker.services())

def validate_worker(proof,process,expected,prerequisite,result_root,result_identity):
    flags=('termination_scope_completed','cleanup_completed','source_files_unchanged','public_payload_verified_before_private',
        'private_access_started','actual_client_decode_started','actual_client_decode_completed','readback_complete','operation_complete',
        'original_private_existing_files_unchanged','keygen_encrypt_native_server_forbidden','result_retained','upload_retained','io_retained',
        'download_retained','original_private_retained','external_workspaces_never_removed','completion_receipt_default')
    if (type(proof)is not dict or any(proof.get(n)is not True for n in flags)or proof.get('error')or proof.get('cleanup_errors')or proof.get('forbidden_attempts')
        or any(proof.get(n)is not False for n in ('keygen','encryption','server_compute','model_forward','retirement'))
        or proof.get('source_hashes_start')!=expected or proof.get('source_hashes_end')!=expected
        or proof.get('prerequisite')!=prerequisite or proof.get('result_workspace')!=str(result_root)or proof.get('result_workspace_identity')!=list(result_identity)):
        raise ValueError('complete separate client source/phase/private ownership proof required')
    if any(process.get(n)is not True for n in ('direct_child_reaped','group_empty_verified','cleanup_completed'))or process.get('cleanup_errors')or type(process.get('direct_returncode'))is not int:
        raise ValueError('client direct wait and owned group retirement required')
    readback=proof.get('readback',{});metrics=readback.get('metrics',{});accepted=metrics.get('passed')
    if (type(accepted)is not bool or proof.get('numeric_gates_passed')is not accepted or proof.get('body_complete')is not accepted
        or proof.get('passed')is not accepted or process['direct_returncode']!=(0 if accepted else 1)
        or type(readback.get('sample_count'))is not int or readback['sample_count']!=1
        or any(readback.get(n)is not True for n in ('private_receipt_validated','result_permissions_0600','default_completion_receipt'))
        or readback.get('retirement_performed')is not False or readback.get('public_batch_sha256')!=prerequisite['public_batch_sha256']):
        raise ValueError('separate receipt and unchanged size0 numeric gate proof required')
    public=proof.get('public_response_readback',{})
    if (public.get('passed')is not True or public.get('private_data_read')is not False
        or any(public.get(n)!=prerequisite[n]for n in ('public_batch_sha256','response_batch_sha256','response_manifest_sha256','input_digest'))):
        raise ValueError('public ciphertext authentication must precede private access')
    return accepted

def body(report,*,output,result_root,execute,args,worker_python,s,expected_sources=None):
    started=time.monotonic();primary=None;child=None;result_owner=None;public_owners=[];before={};execution=None
    try:
        io.environment();raw=sources.raw_sources(HERE);before=io.hashes(raw)
        if expected_sources is not None and before!=expected_sources:raise ValueError('collector body differs from external source pin')
        report.update(source_hashes_start=before,source_guard_start=sources.check_sources(before,HERE),source_count=len(before),source_bytes=sum(map(len,raw.values())),software=io.software_versions())
        io.archive(output/'sources.tar.gz',raw);io.check_archive(output/'sources.tar.gz',before)
        execution=output/'execution_source';execution.mkdir(mode=0o700)
        for n,data in raw.items():p=execution/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
        io.write(output/'source_manifest.json',before)
        report.update(source_archive_sha256=io.digest(io.read(output/'sources.tar.gz',32<<20)),source_archive_verified=True)
        if not execute:
            report.update(preparation_complete=True,body_complete=True);return
        profile=raw['runtime/stage/server_inputs/p60_profile_and_refresh.json'];plan=raw['runtime/stage/server_inputs/twelve_layer_plan.json']
        authorized=s.worker.public_gates(s.worker_services,args,profile,plan);report['prerequisite']=s.worker.summary(authorized)
        s.worker.protect_result(result_root,args,authorized[-1],s.worker.fixture_root_public(args))
        for name,path in (('upload',Path(args['io_workspace'])/'upload'),('io',Path(args['io_workspace'])),('download',Path(args['io_workspace'])/'download')):public_owners.append((name,io.HeldDirectory(path)))
        parent=io.HeldDirectory(Path(result_root).parent);parent_primary=None
        try:
            space=os.fstatvfs(parent.fd);available=space.f_bavail*space.f_frsize;required=(1<<30)+(1<<20)
            if available<required:raise OSError('insufficient private result storage')
            Path(result_root).mkdir(mode=0o700,exist_ok=False);report['result_root_created']=True
        except BaseException as error:parent_primary=error;raise
        finally:
            try:parent.close()
            except BaseException as error:
                if parent_primary is None:raise
                parent_primary.add_note('private result parent close: '+repr(error))
        result_owner=io.HeldDirectory(result_root)
        report.update(result_workspace=str(result_root),result_workspace_identity=list(result_owner.identity),
            storage=dict(required_bytes=required,available_bytes=available,scope='private decoded result and original default receipt plus1GiB margin; existing borrowed keys/inputs/responses and runtime memory excluded'))
        work=output/'worker';work.mkdir(mode=0o700);arguments=args|dict(result_workspace=result_root,result_identity=list(result_owner.identity),output=work/'worker_report.json',
            source_manifest=output/'source_manifest.json',source_manifest_sha256=io.digest(io.read(output/'source_manifest.json')))
        command=[str(worker_python),'-I',str(execution/'original_client_worker.py')]
        for n,v in arguments.items():command+=['--'+n.replace('_','-'),json.dumps(v)if n=='result_identity'else str(v)]
        env=os.environ.copy();env.update(JAX_PLATFORMS='cpu',PYTHONUNBUFFERED='1',PYTHONDONTWRITEBYTECODE='1')
        report['actual_execution_attempted']=True;io.write(output/'report.json',report)
        with (work/'worker.log').open('x')as log:
            child=s.OwnedChild(command,cwd=execution,stdout=log,env=env,term_grace=30.,kill_grace=30.)
            report['worker_process']=child.record;io.write(output/'report.json',report);child.wait()
        proof=io.parse(io.read(work/'worker_report.json'));report['worker_report_sha256']=io.digest(io.read(work/'worker_report.json'))
        accepted=validate_worker(proof,child.record,before,report['prerequisite'],result_root,result_owner.identity)
        after=s.worker.public_gates(s.worker_services,args,profile,plan)
        if after!=authorized:raise ValueError('public producer/response binding changed during client decode')
        result_owner.check();report.update(actual_client_decode=True,operation_complete=True,numeric_gates_passed=accepted,
            body_complete=accepted,readback=proof['readback'],public_response_readback=proof['public_response_readback'],
            worker_elapsed_s=proof['elapsed_s'],original_private_existing_files_unchanged=proof['original_private_existing_files_unchanged'])
    except BaseException as error:primary=error
    finally:
        final=io.Finalizer(report,primary)
        def cleanup():
            if child is not None:final.attempt('client child cleanup',lambda:child.close(primary=primary));report['worker_process']=child.record
            report['all_processes_reaped']=child is None or all(child.record.get(n)is True for n in ('direct_child_reaped','group_empty_verified','cleanup_completed'))and not child.record.get('cleanup_errors')
            for name,owner in [*public_owners,*([('result',result_owner)]if result_owner is not None else[])]:
                report[name+'_retained']=final.attempt('retained '+name,owner.check)is True;final.attempt('close '+name,owner.close)
            report['source_hashes_end']=final.attempt('current client source',lambda:io.hashes(sources.raw_sources(HERE)))
            report['execution_source_hashes_end']=final.attempt('execution client source',lambda:{n:io.digest(io.read(execution/n))for n in before})if execution is not None else None
            report['source_guard_end']=final.attempt('loaded client sources',lambda:sources.check_sources(before,HERE))if before else None
            report['source_archive_verified']=final.attempt('client archive readback',lambda:io.check_archive(output/'sources.tar.gz',before))is True if before else False
        final.shielded(s.cleanup_signals,cleanup)
        report.update(cleanup_completed=not report.get('cleanup_errors')and report['all_processes_reaped'],source_files_unchanged=bool(before)and before==report.get('source_hashes_end')==report.get('execution_source_hashes_end'),
            external_workspaces_never_removed=True,elapsed_s=time.monotonic()-started,private_result_policy='retain all owned result artifacts; original default completion receipt is allowed; no retirement')
        report['body_complete']=bool(report.get('body_complete')and report['cleanup_completed']and report['source_files_unchanged']and report['source_archive_verified']and(not execute or report.get('result_retained')))
        final.attempt('client collector final report',lambda:io.write(output/'report.json',report));final.raise_if_failed()

def run(output,*,result_workspace,source_manifest=None,source_manifest_sha256=None,execute=False,worker_python=Path('/tmp/cross-pretrained-validation-env/bin/python'),**args):
    if type(execute)is not bool:raise ValueError('exact client execution boolean required')
    if source_manifest is None or source_manifest_sha256 is None:raise ValueError('external current source manifest required before collector services')
    source_bytes=io.read(source_manifest)
    if io.digest(source_bytes)!=source_manifest_sha256:raise ValueError('external collector source digest changed')
    expected_sources=io.parse(source_bytes)
    if _CLI_BOOTSTRAP is not None and expected_sources!=_CLI_BOOTSTRAP['source_hashes']:raise ValueError('collector source pin differs from fresh bootstrap')
    sources.check_sources(expected_sources,HERE)
    # Discover externally authenticated PUBLIC private-workspace paths before
    #creating evidence, so even a wrong output alias cannot mutate a fixture.
    s=services();ref=s.worker_services.reference_gate.public_metadata(args['reference_evidence'],args['reference_report_sha256']);fixture=s.worker.fixture_root_public(args)
    protected=tuple(args[n]for n in ('key_workspace','model_workspace','io_workspace','key_evidence','model_evidence','stage3_evidence','stage4_evidence','fixture_evidence','reference_evidence'))
    output=io.outside(output,(*protected,ref['private_workspace'],fixture,HERE));result_workspace=io.outside(result_workspace,(*protected,ref['private_workspace'],fixture,HERE,output))
    if Path(result_workspace).exists()or Path(result_workspace).is_symlink():raise FileExistsError('fresh separate private result directory required')
    output.mkdir(mode=0o700,exist_ok=False)
    report=dict(passed=False,body_complete=False,cleanup_completed=False,termination_scope_completed=False,execute=execute,
        actual_execution_attempted=False,actual_client_decode=False,operation_complete=False,source_files_unchanged=False,source_archive_verified=False,
        all_processes_reaped=True,pid=os.getpid(),cpu_affinity=sorted(os.sched_getaffinity(0)),scope='Original217-bound size0 client component; original P2 gates only, no ranked/full-workload claim')
    return io.finish(output/'report.json',report,lambda r:body(r,output=output,result_root=Path(result_workspace),execute=execute,args=args,worker_python=worker_python,s=s,expected_sources=expected_sources),s.termination_signals,s.cleanup_signals)

def main():
    p=argparse.ArgumentParser()
    for n in worker.GATE_NAMES:p.add_argument('--'+n.replace('_','-'),required=True,type=str if n.endswith('sha256')else Path)
    p.add_argument('--source-manifest',required=True,type=Path);p.add_argument('--source-manifest-sha256',required=True)
    p.add_argument('--output',required=True,type=Path);p.add_argument('--result-workspace',required=True,type=Path);p.add_argument('--execute',action='store_true');p.add_argument('--worker-python',type=Path,default=Path('/tmp/cross-pretrained-validation-env/bin/python'))
    r=run(**vars(p.parse_args()));print(json.dumps({n:r.get(n)for n in ('passed','operation_complete','actual_client_decode','numeric_gates_passed','elapsed_s')}));return 0 if r['passed']else 1
if __name__=='__main__':raise SystemExit(main())
