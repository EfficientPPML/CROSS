from pathlib import Path
Path('/tmp/bert-original-client-bootstrap-extra-review-20261104/negative-v1/synthetic-canary').write_text("unexpected extra module execution")
raise RuntimeError("synthetic extra shadow helper executed")
