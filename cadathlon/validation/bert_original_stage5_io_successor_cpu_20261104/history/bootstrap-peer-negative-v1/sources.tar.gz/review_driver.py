from pathlib import Path
import ast,json,hashlib,subprocess,os,tarfile,io
source=Path('/tmp/bert-original-stage5-io-successor-20261104');out=Path('/tmp/bert-original-client-bootstrap-extra-review-20261104/negative-v1');out.mkdir(parents=True,exist_ok=False);root=out/'execution';root.mkdir()
tree=ast.parse((source/'client_bootstrap.py').read_bytes());names=ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='EXPECTED_NAMES'for t in n.targets)))
raw={n:(source/n).read_bytes()for n in names};sha=lambda b:hashlib.sha256(b).hexdigest();expected={n:sha(b)for n,b in raw.items()}
for n,b in raw.items():p=root/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
manifest=out/'expected.json';manifest.write_text(json.dumps(expected,sort_keys=True)+'\n');marker=out/'synthetic-canary'
(root/'platform.py').write_text('from pathlib import Path\nPath('+repr(str(marker))+').write_text("unexpected extra module execution")\nraise RuntimeError("synthetic extra shadow helper executed")\n')
command=['/tmp/cross-pretrained-validation-env/bin/python','-I','-B',str(root/'original_client_collect.py'),'--source-manifest',str(manifest),'--source-manifest-sha256',sha(manifest.read_bytes()),'--help']
child=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
stdout,stderr=child.communicate();(out/'stdout.log').write_text(stdout);(out/'stderr.log').write_text(stderr)
assert child.returncode!=0 and marker.exists(),(child.returncode,stderr)
for fn in [os.kill,os.killpg]:
 try:fn(child.pid,0)
 except ProcessLookupError:pass
 else:raise AssertionError('child/group remains')
assert all((source/n).read_bytes()==b and(root/n).read_bytes()==b for n,b in raw.items())
files={**raw,'platform.py':(root/'platform.py').read_bytes(),'external_expected.json':manifest.read_bytes(),'review_driver.py':Path(__file__).read_bytes()}
with tarfile.open(out/'sources.tar.gz','w:gz')as z:
 for n,b in files.items():m=tarfile.TarInfo(n);m.size=len(b);z.addfile(m,io.BytesIO(b))
report=dict(schema='original-client-extra-import-shadow-negative-v1',old_source_count=len(raw),source_hashes_before=expected,source_hashes_after=expected,extra_file='platform.py',canary_executed=True,expected_rejected_before_helper=False,direct_child_pid=child.pid,exit_code=child.returncode,direct_child_reaped=True,child_and_group_absent=True,source_archive_sha256=sha((out/'sources.tar.gz').read_bytes()),actual_source_unchanged=True,no_private_or_payload_reads=True,scope='Copied public source tree plus harmless extra module; --help only, no service/handler or retained payload work')
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if not k.startswith('source_hashes')}))
