from pathlib import Path
import json,os,sys
import pytest
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE/'runtime/stage'),str(HERE/'runtime')]
import client_readback as r
import request_lifecycle as lifecycle
from transport_contract import canonical,digest

@pytest.fixture
def case(tmp_path):
    nonce='1'*32;batch=dict(public=dict(context_id='c'*64),requests=[dict(contract=dict(request_id=nonce))])
    paths={n:tmp_path/n for n in ('upload','download','server_report','decrypted_results','client_private')}
    paths['client_private'].mkdir(mode=0o700)
    for kind in ('upload','download'):
        paths[kind].mkdir();(paths[kind]/'batch.json').write_bytes(canonical(batch))
        sample=paths[kind]/nonce;sample.mkdir()
        dirs=[]
        if kind=='upload':
            for i in range(8):p=sample/f'tile{i}';p.mkdir();dirs.append(p)
        else:dirs=[sample]
        for directory in dirs:
            for n in ('bundle.json','ct_0.npz','transport.json'):(directory/n).write_bytes(b'mocked public container only')
    paths['server_report'].write_bytes(b'{}')
    paths['decrypted_results'].write_bytes(canonical(dict(target_idx=17,he_logits=[1.,2.])))
    paths['decrypted_results'].chmod(0o600)
    (paths['client_private']/'requests.json').write_bytes(b'{}')
    lifecycle.record_completed(paths,context_id='c'*64,batch=batch)
    return paths,batch,dict(target_idx=17,native_fp32_logits=[1.,2.],approximate_fp64_logits=[1.,2.])

def test_valid_receipt_result_exports_only_aggregates(case):
    paths,batch,ref=case;out=r.validate(paths,request_batch=batch,reference=ref)
    assert out['metrics']['passed'] and out['private_receipt_validated'] and out['public_batch_sha256']==digest(batch)
    assert not {'he_logits','target_idx'}&set(out)

@pytest.mark.parametrize('change',['target','bool_target','extra','complex_text','two_rows','mode'])
def test_result_binding_rejects(case,change):
    paths,batch,ref=case;p=paths['decrypted_results'];row=dict(target_idx=17,he_logits=[1.,2.])
    if change=='target':row['target_idx']=18
    if change=='bool_target':row['target_idx']=True
    if change=='extra':row['extra']=0
    if change=='complex_text':row['he_logits']=['1+1j','2']
    p.write_bytes(canonical(row)*(2 if change=='two_rows' else 1))
    if change=='mode':p.chmod(0o644)
    with pytest.raises(ValueError):r.validate(paths,request_batch=batch,reference=ref)

def test_nested_upload_replacement_rejects_receipt(case):
    paths,batch,ref=case;p=paths['upload']/('1'*32)/'tile7/ct_0.npz'
    p.rename(p.with_suffix('.moved'));p.write_bytes(b'mocked public container only');p.with_suffix('.moved').unlink()
    with pytest.raises(ValueError,match='receipt'):r.validate(paths,request_batch=batch,reference=ref)

def test_receipt_typed_identity_rejects_boolean_alias(case):
    paths,batch,ref=case;p=paths['client_private']/'completed.json';data=json.loads(p.read_text())
    data['objects']['upload']['children']['batch.json']['size']=True;p.write_bytes(canonical(data))
    with pytest.raises(ValueError,match='receipt'):r.validate(paths,request_batch=batch,reference=ref)

def test_numeric_failure_still_validates_receipt(case):
    paths,batch,ref=case;ref['native_fp32_logits']=[10.,20.]
    out=r.validate(paths,request_batch=batch,reference=ref)
    assert not out['metrics']['passed'] and out['private_receipt_validated']
