import json
import numpy as np
import pytest
from client_metrics import compare,vector

def ref(native=(1.,2.),approx=(1.,2.)):
    return dict(native_fp32_logits=native,approximate_fp64_logits=approx)

@pytest.mark.parametrize('value',[[1+1j,2],[1+0j,2],['1','2'],[True,False],np.array([1,2],dtype=object),[1],[[1,2]],[1,np.nan],[1,np.inf]])
def test_real_finite_two_logit_contract(value):
    with pytest.raises(ValueError):vector(value)

def test_published_native_gate_not_tightened_to_circuit_diagnostic():
    r=compare([1.01,2.01],ref(approx=(10.,20.)))
    assert r['passed'] and r['he_vs_frozen_approx_max_abs']>10
    assert r['he_vs_frozen_approx_nrmse']>.5

def test_native_is_rhs_of_relative_tolerance():
    r=compare([0.,1.031],ref(native=(0.,1.),approx=(0.,1.031)))
    assert not r['passed'] and not r['original_P2_logit_gate']
    assert r['he_vs_frozen_approx_max_abs']==0

def test_prediction_is_required_even_inside_tolerance():
    r=compare([.001,0.],ref(native=(0.,.001),approx=(.001,0.)))
    assert r['original_P2_logit_gate'] and not r['prediction_agreement'] and not r['passed']

def test_tie_is_class_one():
    assert compare([0.,0.],ref(native=(0.,.001)))['prediction_agreement']
    assert not compare([0.,0.],ref(native=(.001,0.)))['prediction_agreement']

@pytest.mark.parametrize('which',['native_fp32_logits','approximate_fp64_logits'])
def test_both_reference_operands_guarded(which):
    x=ref();x[which]=[1+1j,2]
    with pytest.raises(ValueError):compare([1.,2.],x)

def test_finite_subtraction_overflow_fails_and_serializes():
    r=compare([1.7e308,1.7e308],ref(native=(-1.7e308,-1.7e308)))
    assert not r['passed'] and r['he_vs_official_max_abs']is None
    json.dumps(r,allow_nan=False)

def test_zero_reference_diagnostic_is_finite():
    r=compare([0.,0.],ref(native=(0.,0.),approx=(0.,0.)))
    assert r['passed'] and r['he_vs_frozen_approx_nrmse']==0
