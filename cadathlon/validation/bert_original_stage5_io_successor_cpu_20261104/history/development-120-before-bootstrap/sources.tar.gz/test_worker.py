from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace as NS
import json,sys
import pytest
import worker as w

def test_server_gate_precedes_private_inputs(monkeypatch):
    events=[]
    for module,label,value in [(w.key_gate,'keys',{}),(w.model_gate,'model',{}),(w.stage3_gate,'stage3',{})]:
        monkeypatch.setattr(module,'authenticate',lambda *a,_label=label,_value=value,**k:(events.append(_label),_value)[1])
    def stop(*a,**k):events.append('stage4');raise ValueError('server incomplete')
    monkeypatch.setattr(w.stage4_gate,'authenticate',stop)
    monkeypatch.setattr(w.input_gate,'authenticate',lambda *a:pytest.fail('private input before completed server'))
    monkeypatch.setattr(w.reference_gate,'public_metadata',lambda *a:pytest.fail('reference before completed server'))
    names=('key_evidence','key_report_sha256','key_workspace','model_evidence','model_report_sha256','model_workspace',
        'stage3_evidence','stage3_report_sha256','stage4_evidence','stage4_report_sha256','io_workspace',
        'fixture_evidence','fixture_report_sha256','reference_evidence','reference_report_sha256','profile_bytes','plan_bytes')
    with pytest.raises(ValueError,match='server incomplete'):w.authenticate(**dict.fromkeys(names,None))
    assert events==['keys','model','stage3','stage4']

@pytest.fixture
def case(tmp_path,monkeypatch):
    monkeypatch.setenv('JAX_PLATFORMS','cpu');events=[];fail={}
    root=tmp_path/'lab';(root/'runtime/stage/server_inputs').mkdir(parents=True)
    for n in ('p60_profile_and_refresh.json','twelve_layer_plan.json'):(root/'runtime/stage/server_inputs'/n).write_text('{}')
    (root/'worker.py').write_text('fixed');monkeypatch.setattr(w,'HERE',root)
    manifest=tmp_path/'sources.json';manifest.write_text(json.dumps(w.hashes({'worker.py':None})))
    result=tmp_path/'private';result.mkdir(mode=0o700)
    auth=(dict(context_id='c'*64,key_report_sha256='1'*64,key_source_archive_sha256='2'*64,public_keys=tmp_path/'public'),
        dict(model_id='m'*64,model_report_sha256='3'*64,model_manifest_sha256='4'*64),
        dict(stage3_report_sha256='5'*64,public_batch_sha256='b'*64,input_digest='d'*64),
        dict(stage4_report_sha256='6'*64),dict(input_sha256='i'*64,fixture_report_sha256='f'*64,preprocessed_input=tmp_path/'input'),
        dict(report_sha256='r'*64,source_archive_sha256='a'*64))
    def authfn(**k):
        events.append('auth')
        if fail.get('auth'):raise fail['auth']
        return auth
    monkeypatch.setattr(w,'authenticate',authfn);monkeypatch.setattr(w.dependencies,'check',lambda:{'ready':True})
    monkeypatch.setattr(w,'local_modules',lambda expected:{})
    monkeypatch.setattr(w,'fresh_paths',lambda *a:events.append('fresh'))
    monkeypatch.setattr(w,'load_private_inputs',lambda *a:(events.append('private'),({},{}))[1])
    @contextmanager
    def guards(calls):
        events.append('guards')
        try:yield
        finally:events.append('restore')
    monkeypatch.setattr(w.boundaries,'client_only',guards)
    def handler(paths):
        events.append('decode')
        if fail.get('decode'):raise fail['decode']
        return dict(sample_count=1,public_batch_sha256='b'*64)
    monkeypatch.setitem(sys.modules,'file_stages',NS(MODEL_ID='fixed',REVISION='pinned',client_decrypt_decode=handler))
    def readback(*a,**k):
        events.append('readback')
        if fail.get('readback'):raise fail['readback']
        return dict(sample_count=1,public_batch_sha256='b'*64,metrics={'passed':not fail.get('numeric',False)})
    monkeypatch.setattr(w.client_readback,'validate',readback)
    names=('key_evidence','key_workspace','model_evidence','model_workspace','stage3_evidence','stage4_evidence',
        'io_workspace','fixture_evidence','reference_evidence')
    args={n:tmp_path/n for n in names}
    args.update({n:'a'*64 for n in ('key_report_sha256','model_report_sha256','stage3_report_sha256','stage4_report_sha256','fixture_report_sha256','reference_report_sha256')})
    args.update(result_workspace=result,output=tmp_path/'report.json',source_manifest=manifest)
    return NS(args=args,events=events,fail=fail,root=root,auth=auth)

def report(case):return json.loads(case.args['output'].read_text())
def test_decode_exact_order_and_no_public_values(case):
    assert w.run(**case.args)==0
    assert case.events==['auth','fresh','private','guards','decode','readback','restore','auth','private','readback']
    r=report(case);assert r['terminal_scope_completed'] and r['passed'] and r['source_files_unchanged']
    assert 'he_logits'not in case.args['output'].read_text()

def test_numeric_failure_is_complete_failed_evidence(case):
    case.fail['numeric']=True;assert w.run(**case.args)==1
    r=report(case);assert not r['passed'] and r['operation_complete'] and r['terminal_scope_completed']

@pytest.mark.parametrize('kind',['auth','decode','readback'])
def test_failure_stays_failed_and_restores(case,kind):
    case.fail[kind]=ValueError(kind)
    with pytest.raises(ValueError,match=kind):w.run(**case.args)
    r=report(case);assert not r['passed'] and not r['terminal_scope_completed']
    if kind=='auth':assert 'private'not in case.events
    else:assert 'restore'in case.events

def test_primary_cancel_survives_final_source_error(case,monkeypatch):
    primary=KeyboardInterrupt('primary');case.fail['decode']=primary
    old=w.hashes;calls=[]
    def hashes(x):
        calls.append(1)
        if len(calls)>1:raise OSError('source')
        return old(x)
    monkeypatch.setattr(w,'hashes',hashes)
    with pytest.raises(KeyboardInterrupt) as e:w.run(**case.args)
    assert e.value is primary and any('source' in n for n in primary.__notes__)
    assert not report(case)['passed']

def test_pending_dependency_before_any_gate_or_private(case,monkeypatch):
    monkeypatch.setattr(w.dependencies,'check',lambda:(_ for _ in ()).throw(RuntimeError('pending')))
    with pytest.raises(RuntimeError,match='pending'):w.run(**case.args)
    assert not case.events

def test_source_startup_mismatch_before_any_gate(case):
    (case.root/'worker.py').write_text('changed')
    with pytest.raises(ValueError,match='source startup'):w.run(**case.args)
    assert not case.events

@pytest.mark.parametrize('has_primary',[False,True])
@pytest.mark.parametrize('cancel',[False,True])
def test_cleanup_scope_exit_cannot_leave_success(case,monkeypatch,has_primary,cancel):
    primary=ValueError('body primary') if has_primary else None
    if primary is not None:case.fail['decode']=primary
    failure=KeyboardInterrupt('scope exit') if cancel else OSError('scope exit');seen=[]
    @contextmanager
    def shield():
        yield
        seen.append(1)
        if len(seen)==1:raise failure
    monkeypatch.setattr(w,'cleanup_signals',shield)
    with pytest.raises(BaseException) as e:w.run(**case.args)
    assert e.value is (primary if primary is not None else failure)
    assert not report(case)['passed'] and not report(case)['terminal_scope_completed']
