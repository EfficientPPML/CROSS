"""Actual metadata schemas with synthetic source/container bytes; no HE payloads."""
from pathlib import Path
from types import SimpleNamespace as NS
import copy,hashlib,io,json,sys,tarfile
import pytest
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE/'runtime/stage'),str(HERE/'joined'),str(HERE/'joined/checkout/cadathlon/common'),str(HERE/'runtime')]
import stage3_gate as g
import key_gate,transport_contract as tc,transport,file_stage_contract as bc,server_public_model as sm

def write(path,value):path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(tc.canonical(value))
def identity(p):s=p.stat();return [s.st_dev,s.st_ino]

@pytest.fixture
def case(tmp_path,monkeypatch):
    evidence=tmp_path/'evidence';evidence.mkdir();io_root=tmp_path/'io';io_root.mkdir();upload=io_root/'upload';upload.mkdir()
    gate=tmp_path/'gate';gate.mkdir();monkeypatch.setattr(g,'HERE',gate)
    p=tc.parameters();keys=dict(context_id='c'*64,key_report_sha256='1'*64,key_source_archive_sha256='2'*64,
        public_manifest=dict(context_id='c'*64,parameters=p))
    modelmanifest=dict(context_id='c'*64,model_id='a'*64,checkpoint_sha256=sm.CHECKPOINT_SHA256,config_sha256=sm.CONFIG_SHA256,
        candidate_sha256=sm.CANDIDATE_SHA256,profile_sha256=sm.PROFILE_SHA256)
    model=dict(context_id='c'*64,model_id='a'*64,server_data=tmp_path/'model',model_report_sha256='3'*64,model_manifest_sha256=tc.digest(modelmanifest))
    write(model['server_data']/keys['context_id']/'model_manifest.json',modelmanifest)
    public=tc.public_identity(modelmanifest|{'parameters':p})
    metadata=dict(schema='bert-client-row-packing-v1',input_tile_count=8,original_positions=list(range(32)),
        original_attention_mask=[int(i<32) for i in range(128)],compact_key_mask=[int(i<32) for i in range(128)],
        key_count=32,query_tiles=2,valid_rows=[16,16,0,0,0,0,0,0],packing=dict(slots=65536,row_pitch=4096,rows_per_tile=16,
        active_features=768,row_order='increasing original positions',positions_applied='before compaction',feature_padding='zero',unused_rows='zero',input_dtype='float64'))
    contract=tc.make_contract(public,'0123456789abcdef',metadata);sample=upload/contract['request_id'];sample.mkdir()
    manifests=[];rows=[]
    for i in range(8):
        d=sample/f'tile{i}';d.mkdir();bound=tc.ciphertext_contract(contract,'request',i,None,None)
        manifest=transport._manifest_fields(bound)|dict(files={'bundle.json':'5'*64,'ct_0.npz':'6'*64})
        write(d/'transport.json',manifest);(d/'bundle.json').write_bytes(b'not read in metadata gate');(d/'ct_0.npz').write_bytes(b'not a ciphertext; never read')
        manifests.append(manifest);rows.append(dict(tile=i,payload_bytes=100<<20,shape=[1,2,256,512,100],scale=p['scaling_factor'],manifest_sha256=transport.manifest_digest(manifest)))
    input_digest=transport.request_digest(manifests,contract);batch=bc.public_batch(public,[dict(contract=contract,input_digest=input_digest)],count=1);write(upload/'batch.json',batch)
    source={f'source{i}.py':f'# source{i}\n'.encode() for i in range(80)};expected={n:hashlib.sha256(b).hexdigest() for n,b in source.items()}
    write(gate/'stage3_source_manifest.json',expected);write(gate/'dependencies.json',dict(stage3_source_inventory_sha256=key_gate.digest((gate/'stage3_source_manifest.json').read_bytes())))
    with tarfile.open(evidence/'sources.tar.gz','w:gz') as tar:
        for n,b in source.items():m=tarfile.TarInfo(n);m.size=len(b);tar.addfile(m,io.BytesIO(b))
    prereq={n:keys[n] for n in ('context_id','key_report_sha256','key_source_archive_sha256')}|{n:model[n] for n in ('model_id','model_report_sha256','model_manifest_sha256')}|dict(input_sha256='7'*64,fixture_report_sha256='8'*64,valid_token_count=32)
    assets={'model.safetensors':sm.CHECKPOINT_SHA256,'config.json':sm.CONFIG_SHA256}
    readback=dict(sample_count=1,tile_count=8,private_binding_verified=True,private_request_permissions_verified=True,
        private_input_sha256='7'*64,public_batch_sha256=tc.digest(batch),input_digest=input_digest,ciphertext_payload_bytes=800<<20,tiles=rows)
    worker=dict(passed=True,decrypt=False,model_forward=False,server_compute=False,actual_client_encode_started=True,actual_client_encode_completed=True,readback_complete=True,
        all_eight_ordered_payloads_validated=True,source_files_unchanged=True,keygen_decrypt_native_model_forbidden=True,terminal_scope_completed=True,
        forbidden_attempts=[],source_hashes_start=expected,source_hashes_end=expected,prerequisite=prereq,asset_hashes_start=assets,asset_hashes_end=assets,
        context_id=keys['context_id'],model_id=model['model_id'],readback=readback)
    report=dict(passed=True,operation_complete=True,external_key_workspace_never_removed=True,execute=True,actual_encryption=True,actual_execution_attempted=True,io_workspace_retained=True,
        all_processes_reaped=True,cleanup_completed=True,terminal_scope_completed=True,source_files_unchanged=True,source_archive_verified=True,
        source_hashes_start=expected,source_hashes_end=expected,execution_source_hashes_end=expected,source_archive_sha256=key_gate.digest((evidence/'sources.tar.gz').read_bytes()),
        prerequisite=prereq,asset_hashes_start=assets,asset_hashes_end=assets,context_id=keys['context_id'],model_id=model['model_id'],readback=readback,
        io_workspace=str(io_root),io_workspace_identity=identity(io_root),upload=str(upload),upload_identity=identity(upload),public_batch_sha256=tc.digest(batch),
        worker_process=dict(returncode=0,process_reaped=True,public_key_store_removed=True,owned_directory_handle_closed=True,
            result=dict(passed=True,context_id=keys['context_id'],model_id=model['model_id'],public_batch_sha256=tc.digest(batch))))
    def save():
        write(evidence/'worker/worker_report.json',worker);report['worker_process']['result']['worker_report_sha256']=key_gate.digest((evidence/'worker/worker_report.json').read_bytes());write(evidence/'report.json',report)
        return key_gate.digest((evidence/'report.json').read_bytes())
    def check():return g.authenticate(evidence,save(),io_root,keys=keys,model=model)
    return NS(check=check,save=save,worker=worker,report=report,evidence=evidence,io=io_root,upload=upload,sample=sample,keys=keys,model=model,readback=readback,expected=expected)

def test_public_gate_accepts_synthetic_metadata_without_payload_reads(case,monkeypatch):
    original=__import__('os').open;opened=[]
    def opening(path,*a,**kw):
        name=str(path);opened.append(name)
        assert not any(x in name for x in ('ct_0.npz','bundle.json','client_private','requests.json','preprocessed'))
        return original(path,*a,**kw)
    monkeypatch.setattr(__import__('os'),'open',opening)
    r=case.check();assert r['tiles']==case.readback['tiles'] and r['upload']==case.upload and len(r['tiles'])==8
    assert any('transport.json' in x for x in opened)

@pytest.mark.parametrize('flag',['passed','execute','actual_encryption','actual_execution_attempted','io_workspace_retained','all_processes_reaped','cleanup_completed','terminal_scope_completed','source_files_unchanged','source_archive_verified','operation_complete','external_key_workspace_never_removed'])
def test_required_outer_completion_flags(case,flag):
    case.report[flag]=False
    with pytest.raises(ValueError,match='terminal proof'):case.check()

@pytest.mark.parametrize('flag',['passed','actual_client_encode_started','actual_client_encode_completed','readback_complete','all_eight_ordered_payloads_validated','source_files_unchanged','keygen_decrypt_native_model_forbidden','terminal_scope_completed'])
def test_required_worker_phase_terminal_flags(case,flag):
    case.worker[flag]=False
    with pytest.raises(ValueError,match='worker/source/terminal'):case.check()

@pytest.mark.parametrize('flag',['process_reaped','public_key_store_removed','owned_directory_handle_closed'])
def test_process_reaping(case,flag):
    case.report['worker_process'][flag]=False
    with pytest.raises(ValueError,match='reaping'):case.check()

def test_caller_hash_checked_before_any_other_read(case,monkeypatch):
    case.save();original=key_gate.read;seen=[]
    def read(path,*a):seen.append(Path(path));return original(path,*a)
    monkeypatch.setattr(key_gate,'read',read)
    with pytest.raises(ValueError,match='externally pinned'):g.authenticate(case.evidence,'0'*64,case.io,keys=case.keys,model=case.model)
    assert seen==[case.evidence/'report.json']

@pytest.mark.parametrize('field',['source_hashes_start','source_hashes_end','execution_source_hashes_end'])
def test_exact_reviewed_source_inventory(case,field):
    case.report[field]={}
    with pytest.raises(ValueError,match='execution source'):case.check()

def test_source_archive_corruption(case):
    (case.evidence/'sources.tar.gz').write_bytes(b'wrong')
    with pytest.raises(ValueError,match='archive digest'):case.check()

def test_retained_upload_replacement(case,tmp_path):
    case.upload.rename(tmp_path/'old-upload');case.upload.mkdir()
    with pytest.raises(ValueError,match='directory identity'):case.check()

def test_noncanonical_public_batch_bytes(case):
    p=case.upload/'batch.json';value=json.loads(p.read_text());p.write_text(json.dumps(value,indent=2))
    with pytest.raises(ValueError,match='canonical'):case.check()

def test_wrong_eighth_transport_manifest(case):
    p=case.sample/'tile7/transport.json';value=json.loads(p.read_text());value['tile_index']=6;write(p,value)
    with pytest.raises(ValueError,match='binding'):case.check()

def test_reordered_attested_tile_list(case):
    case.readback['tiles'].reverse()
    with pytest.raises(ValueError,match='all-eight'):case.check()

def test_private_binding_attestation_required_without_reopening(case):
    case.readback['private_binding_verified']=False
    with pytest.raises(ValueError,match='private binding'):case.check()

def test_wrong_asset_binding(case):
    case.worker['asset_hashes_end']={'config.json':'0'*64}
    with pytest.raises(ValueError,match='embedding asset'):case.check()

def test_wrong_parent_model_binding(case):
    case.model['model_report_sha256']='0'*64
    with pytest.raises(ValueError,match='predecessor identity'):case.check()

def test_wrong_stage3_actual_input_binding(case):
    case.readback['input_digest']='0'*64
    with pytest.raises(ValueError,match='ciphertext digest'):case.check()

@pytest.mark.parametrize('alias',[True,1.0])
def test_shape_metadata_requires_exact_integers(case,alias):
    case.readback['tiles'][0]['shape'][0]=alias
    with pytest.raises(ValueError,match='all-eight'):case.check()

@pytest.mark.parametrize('action',['decrypt','model_forward','server_compute'])
def test_stage3_non_encryption_actions_must_be_explicit_false(case,action):
    case.worker[action]=None
    with pytest.raises(ValueError,match='worker/source/terminal'):case.check()
