"""Private decrypted result and completion receipt checks; no public raw values."""
from pathlib import Path
import hashlib,stat
import key_gate
from client_metrics import compare

def validate(paths,*,request_batch,reference):
    from transport_contract import digest
    import request_lifecycle as lifecycle
    private=Path(paths['client_private']);result_path=Path(paths['decrypted_results'])
    state=result_path.lstat()
    if not stat.S_ISREG(state.st_mode) or stat.S_IMODE(state.st_mode)!=0o600:
        raise ValueError('decoded results must remain private0600')
    raw=key_gate.read(result_path,65536);lines=raw.decode('utf-8').splitlines()
    if len(lines)!=1:raise ValueError('exactly one private size0 result required')
    row=key_gate.parse(lines[0])
    if type(row)is not dict or set(row)!={'target_idx','he_logits'} or type(row['target_idx'])is not int or row['target_idx']!=reference['target_idx']:
        raise ValueError('decoded private target/order differs')
    metrics=compare(row['he_logits'],reference)
    receipt_path=private/'completed.json';state=receipt_path.lstat()
    if not stat.S_ISREG(state.st_mode) or stat.S_IMODE(state.st_mode)!=0o600:raise ValueError('private0600 completion receipt required')
    receipt_raw=key_gate.read(receipt_path,16<<20);receipt=key_gate.parse(receipt_raw)
    nonces=[r['contract']['request_id'] for r in request_batch['requests']]
    objects={kind:lifecycle._observe(path,kind,nonces) for kind,path in lifecycle._paths(paths).items()}
    expected=dict(schema='cross-bert-client-completion-v1',context_id=request_batch['public']['context_id'],
        public_batch_sha256=digest(request_batch),nonces=nonces,objects=objects)
    if key_gate.canonical(receipt)!=key_gate.canonical(expected):raise ValueError('private completed receipt does not match retained artifacts')
    # Raw decoded logits, target ID and receipt contents never leave this API.
    return dict(sample_count=1,metrics=metrics,decoded_result_sha256=hashlib.sha256(raw).hexdigest(),
        completed_receipt_sha256=hashlib.sha256(receipt_raw).hexdigest(),private_receipt_validated=True,
        result_permissions_0600=True,public_batch_sha256=digest(request_batch))
