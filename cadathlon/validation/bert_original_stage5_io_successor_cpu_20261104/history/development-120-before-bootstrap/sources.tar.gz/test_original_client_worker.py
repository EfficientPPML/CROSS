from pathlib import Path
from contextlib import nullcontext,contextmanager
from types import SimpleNamespace
import json,sys
import pytest
import original_client_worker as w

@pytest.fixture
def setup(tmp_path,monkeypatch):
    roots={n:tmp_path/n for n in ('keys','model','io','response','result','evidence','fixture','reference')}
    for p in roots.values():p.mkdir(mode=0o700)
    for p in (roots['keys']/'client_private',roots['io']/'upload',roots['io']/'download',roots['response']/'download'):p.mkdir(mode=0o700)
    private=roots['keys']/'client_private';(private/'requests.json').write_text('synthetic original request');(private/'requests.json').chmod(0o600)
    (roots['io']/'download'/'sentinel').write_text('ordinary still active');(roots['response']/'server_report').write_text('{}')
    keys=dict(context_id='c',key_report_sha256='k',key_source_archive_sha256='ks',public_keys=roots['keys']/'public')
    model=dict(model_id='m',model_report_sha256='mr',model_manifest_sha256='mm')
    requests=dict(upload=roots['io']/'upload',stage3_report_sha256='s3',public_batch_sha256='b',input_digest='i')
    server=dict(stage4_report_sha256='s4',response_batch_sha256='rb',response_manifest_sha256='rm',response_root=str(roots['response']))
    ref=dict(private_workspace=roots['reference'],fixture_report_sha256='f',input_sha256='input',report_sha256='r',source_archive_sha256='rs')
    authorized=(keys,model,requests,server,ref);events=[]
    args=dict(key_workspace=roots['keys'],model_workspace=roots['model'],io_workspace=roots['io'])
    args.update({n:roots['evidence']for n in ('key_evidence','model_evidence','stage3_evidence','stage4_evidence','fixture_evidence','reference_evidence')})
    expected={'one':'hash'}
    def public(*a):events.append('public-gates');return authorized
    monkeypatch.setattr(w,'public_gates',public);monkeypatch.setattr(w,'fixture_root_public',lambda args:roots['fixture'])
    def private_inputs(*a):events.append('private-input');return dict(preprocessed_input=roots['fixture']/'input')
    monkeypatch.setattr(w,'private_inputs',private_inputs)
    def private_load(*a):events.append('private-request-reference');return {'batch':'public'},{'reference':'synthetic'}
    monkeypatch.setattr(w,'load_private',private_load)
    monkeypatch.setattr(w.sources,'check_sources',lambda *a,**kw:{'passed':True})
    monkeypatch.setattr(w.sources,'raw_sources',lambda *a:{'one':b'raw'});monkeypatch.setattr(w.io,'hashes',lambda raw:expected)
    real=w.io.read;monkeypatch.setattr(w.io,'read',lambda p,*a:b'{}'if 'server_inputs'in str(p)else real(p,*a))
    readback=dict(sample_count=1,public_batch_sha256='b',metrics={'passed':True},default_completion_receipt=True)
    def handler(paths):
        events.append('decode');assert paths['download']==roots['io']/'download'
        for p in (roots['result']/'decrypted_results',private/'completed.json'):
            p.write_text('synthetic private output');p.chmod(0o600)
        return dict(sample_count=1,public_batch_sha256='b')
    fake=SimpleNamespace(MODEL_ID='model',REVISION='rev',client_decrypt_decode=handler);monkeypatch.setitem(sys.modules,'file_stages',fake)
    @contextmanager
    def boundary(calls):events.append('guard');yield
    def payload(*a,**kw):events.append('public-body');return dict(passed=True)
    def check(*a,**kw):events.append('private-readback');assert 'completion_directory'not in kw;return readback
    s=SimpleNamespace(boundaries=SimpleNamespace(client_only=boundary),original_public_readback=SimpleNamespace(verify=payload),original_client_readback=SimpleNamespace(validate=check),cleanup_signals=nullcontext)
    report=dict(passed=False,body_complete=False,private_access_started=False,actual_client_decode_started=False)
    kw=dict(expected=expected,args=args,result_root=roots['result'],result_identity=[roots['result'].stat().st_dev,roots['result'].stat().st_ino],output=roots['evidence']/'worker.json',s=s)
    return SimpleNamespace(roots=roots,authorized=authorized,events=events,private=private,args=args,report=report,kw=kw,s=s,handler=fake,readback=readback)

def test_public_body_before_private_and_original_default_completion(setup):
    f=setup;w.body(f.report,**f.kw)
    assert f.report['body_complete']and f.report['original_private_existing_files_unchanged']
    assert f.events.index('public-gates')<f.events.index('public-body')<f.events.index('private-input')<f.events.index('private-request-reference')<f.events.index('decode')
    assert (f.private/'completed.json').exists()and not(f.roots['result']/'completed.json').exists()
    assert(f.roots['io']/'download'/'sentinel').read_text()=='ordinary still active'

@pytest.mark.parametrize('failure',['wrong286','wrong-response','failed-proof'])
def test_public_gate_failure_precedes_private(setup,monkeypatch,failure):
    f=setup
    def bad(*a):f.events.append(failure);raise ValueError(failure)
    monkeypatch.setattr(w,'public_gates',bad)
    with pytest.raises(ValueError):w.body(f.report,**f.kw)
    assert 'private-input'not in f.events and 'public-body'not in f.events and f.report['private_access_started']is False

def test_response_bytes_failure_precedes_private(setup):
    f=setup
    def bad(*a,**kw):raise ValueError('ciphertext bytes changed')
    f.s.original_public_readback.verify=bad
    with pytest.raises(ValueError):w.body(f.report,**f.kw)
    assert 'private-input'not in f.events and f.report['private_access_started']is False

@pytest.mark.parametrize('relative',['nested','ancestor','same','alias'])
def test_disjoint_result_before_private(setup,relative):
    f=setup
    if relative=='nested':p=f.private/'result';p.mkdir(mode=0o700)
    elif relative=='ancestor':p=f.roots['keys'].parent
    elif relative=='same':p=f.private
    else:p=f.roots['result'].parent/'alias';p.symlink_to(f.private,target_is_directory=True)
    f.kw['result_root']=p
    with pytest.raises(ValueError):w.body(f.report,**f.kw)
    assert 'private-input'not in f.events and 'public-body'not in f.events

@pytest.mark.parametrize('kind',[ValueError,KeyboardInterrupt,SystemExit])
def test_decode_failure_retains_private_outputs_and_original(setup,kind):
    f=setup;primary=kind('decode')
    def bad(paths,**kw):p=f.roots['result']/'partial';p.write_text('synthetic');p.chmod(0o600);raise primary
    f.handler.client_decrypt_decode=bad
    with pytest.raises(kind)as got:w.body(f.report,**f.kw)
    assert got.value is primary and(f.roots['result']/'partial').exists()and not(f.private/'completed.json').exists()
    assert f.report['result_retained']and f.report['original_private_existing_files_unchanged']

def test_numerical_failure_is_completed_but_not_passed(setup):
    f=setup;f.readback['metrics']['passed']=False;w.body(f.report,**f.kw)
    assert f.report['operation_complete']and f.report['readback_complete']and not f.report['body_complete']and not f.report['numeric_gates_passed']
    assert(f.private/'completed.json').exists()and not(f.roots['result']/'completed.json').exists()

def test_preexisting_original_request_write_detected(setup):
    f=setup;original=f.handler.client_decrypt_decode
    def wrong(*a,**kw):out=original(*a,**kw);p=f.private/'requests.json';p.write_text('wrong');p.chmod(0o600);return out
    f.handler.client_decrypt_decode=wrong
    with pytest.raises(ValueError,match='files changed'):w.body(f.report,**f.kw)
    assert not f.report['original_private_existing_files_unchanged']and not f.report['body_complete']


from pathlib import Path
import ast,os,json
from types import SimpleNamespace
import pytest
import client_io as io
import original_client_worker as w

@pytest.mark.parametrize('kind',['fixture','reference'])
@pytest.mark.parametrize('failure',['bootstrap','services'])
def test_startup_never_publishes_in_borrowed_private_root(tmp_path,kind,failure):
    private={n:tmp_path/('private-'+n)for n in ('fixture','reference')}
    for p in private.values():p.mkdir(mode=0o700);(p/'sentinel').write_text('untouched synthetic fixture')
    fields=('key_workspace','model_workspace','io_workspace','key_evidence','model_evidence','stage3_evidence','stage4_evidence','fixture_evidence','reference_evidence')
    args={n:tmp_path/n for n in fields}
    for p in args.values():p.mkdir()
    for name in ('fixture','reference'):
        raw=json.dumps({'private_workspace':str(private[name])}).encode();(args[name+'_evidence']/'report.json').write_bytes(raw);args[name+'_report_sha256']=io.digest(raw)
    def bootstrap(*a):
        if failure=='bootstrap':raise ValueError('synthetic source failure')
        return {},{}
    def services():raise ValueError('synthetic import failure')
    scope=dict(Path=Path,io=io,HERE=tmp_path/'source',os=os,bootstrap=bootstrap,services=services)
    tree=ast.parse(Path(w.__file__).read_text());selected=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in ('run','fixture_root_public','public_private_roots')]
    exec(compile(ast.Module(body=selected,type_ignores=[]),'<actual worker.run AST>','exec'),scope)
    output=private[kind]/'new-report.json'
    with pytest.raises(ValueError):scope['run'](source_manifest=tmp_path/'manifest',source_manifest_sha256='unused',result_workspace=tmp_path/'results',result_identity=[1,2],output=output,**args)
    assert not output.exists(),'standalone startup failure published inside borrowed private tree'
    assert(private[kind]/'sentinel').read_text()=='untouched synthetic fixture'
