"""Installed client guard denial/restoration only; no data or HE execution."""
from pathlib import Path
import argparse,hashlib,importlib,importlib.metadata,json,os,sys
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE/'runtime/stage'),str(HERE/'runtime')]
import boundaries,collect

def probe():
    if os.environ.get('JAX_PLATFORMS')!='cpu':raise ValueError('explicit CPU required')
    before=collect.hashes(collect.sources())
    from jaxite_word import CKKSContext
    modules=[importlib.import_module(n) for n in ('key_gen','jaxite_word.key_gen')]
    import file_stages,client_keys,client_inputs,key_contexts,request_lifecycle
    original=[(m,n,getattr(m,n)) for m in modules for n in ('gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen')]
    original += [(CKKSContext,n,getattr(CKKSContext,n)) for n in ('encrypt','encrypt_slots','encrypt_slots_batch','program_initialization')]
    original += [(owner,n,getattr(owner,n)) for owner,n in [(client_keys,'generate'),(client_inputs,'ClientEmbeddings'),(key_contexts,'load_server'),
        (file_stages,'client_key_generation'),(file_stages,'server_preprocess_model'),(file_stages,'client_encode_encrypt_input'),
        (file_stages,'server_encrypted_compute'),(file_stages,'_snapshot'),(request_lifecycle,'retire_completed')]]
    allowed=[(CKKSContext,n,getattr(CKKSContext,n)) for n in ('decrypt','decrypt_slots','decrypt_slots_batch','decode')]
    allowed.append((file_stages,'client_decrypt_decode',file_stages.client_decrypt_decode))
    calls=[]
    with boundaries.client_only(calls):
        for owner,n,_ in original:
            try:getattr(owner,n)(None)
            except RuntimeError as error:
                if not str(error).startswith('forbidden stage5 action:'):raise
            else:raise AssertionError('forbidden installed entrypoint executed')
        if any(getattr(o,n)is not f for o,n,f in allowed):raise AssertionError('allowed decoder entrypoint replaced')
    if len(calls)!=21 or len(set(calls))!=21:raise AssertionError('exact21 distinct installed denials required')
    if any(getattr(o,n)is not f for o,n,f in original):raise AssertionError('installed entrypoint restoration differs')
    if any(n.split('.')[0]in ('torch','transformers') for n in sys.modules):raise AssertionError('native model module loaded')
    after=collect.hashes(collect.sources())
    if after!=before:raise ValueError('probe source drift')
    loaded={}
    for name,module in tuple(sys.modules.items()):
        path=getattr(module,'__file__',None)
        if not path:continue
        path=Path(path).resolve()
        if HERE in path.parents and path.suffix=='.py':
            n=path.relative_to(HERE).as_posix()
            if before.get(n)!=hashlib.sha256(path.read_bytes()).hexdigest():raise ValueError('mixed local source import')
            loaded[name]=n
    return dict(passed=True,scope='Installed entrypoint denial/restoration only; no context, key generation, actual decoder, native model, or private/payload reads.',
        denial_count=len(calls),denied=calls,restored_count=len(original),allowed_entrypoints_unchanged=len(allowed),
        keygen_modules_distinct=modules[0]is not modules[1],native_model_modules_loaded=False,actual_client_decode=False,
        source_hashes_before=before,source_hashes_after=after,source_files_unchanged=True,loaded_local_modules=loaded,
        python=sys.executable,cpu_affinity=sorted(os.sched_getaffinity(0)),versions={n:importlib.metadata.version(n) for n in ('numpy','jax','jaxlib')})

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    report=probe();args.output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(passed=True,denial_count=report['denial_count'],loaded_local_module_count=len(report['loaded_local_modules']))))
