"""Collector boundaries use mocked handlers only; no real keys or backend."""
from pathlib import Path
from types import SimpleNamespace
import hashlib,json,os,sys
import pytest
import collect
sys.path.insert(0,str(collect.STAGE))
import client_keys

@pytest.fixture
def case(tmp_path,monkeypatch):
    monkeypatch.setenv('JAX_PLATFORMS','cpu');parent=tmp_path/'keys';parent.mkdir();output=tmp_path/'proof'
    raw={'worker.py':b'# worker','stage/client_keys.py':b'# keys','stage/server_inputs/p60_profile_and_refresh.json':b'profile','stage/server_inputs/twelve_layer_plan.json':b'plan'}
    monkeypatch.setattr(collect,'sources',lambda:dict(raw))
    keys=SimpleNamespace(_OwnedDirectory=client_keys._OwnedDirectory,public_contract=lambda p,r:({'public':True},(1,2,3)),
        _security_check=lambda p:{'mocked':True},resources=lambda p,r:dict(public_required_bytes=100,private_required_bytes=20),
        preflight=lambda *a,**kw:({},(),{'mocked':True}))
    monkeypatch.setattr(collect,'load_keys',lambda path:keys)
    monkeypatch.setattr(collect.process,'software_versions',lambda:{'mocked':True})
    def complete(command,directory,**kw):
        assert kw==dict(timeout=None,cleanup_grace_s=120.)
        expected=json.loads(Path(command[-1]).read_text());workspace=Path(command[command.index('--workspace')+1])
        (workspace/'public_keys').mkdir();(workspace/'client_private').mkdir();(workspace/'public_keys/key.npy').write_bytes(b'fake payload')
        worker=dict(passed=True,source_hashes_start=expected,source_hashes_end=expected,source_files_unchanged=True,actual_key_generation_completed=True,
            public_manifest=dict(context_id='a'*64,rotations=[1,2,3]),private_binding_verified=True,private_permissions_verified=True,private_file_count=2,elapsed_s=1.)
        collect.write(directory/'worker_report.json',worker)
        record=dict(returncode=0,process_reaped=True,public_key_store_removed=True,owned_directory_handle_closed=True,
                    result=dict(passed=True,worker_report_sha256=collect.process.sha256(directory/'worker_report.json')))
        collect.write(directory/'process.json',record);return record
    monkeypatch.setattr(collect.process,'run_case',complete)
    return SimpleNamespace(parent=parent,output=output,raw=raw,keys=keys,complete=complete)

def run(case,execute=False):return collect.run(case.output,execute=execute,workspace_parents=(case.parent,))
def report(case):return json.loads((case.output/'report.json').read_text())

def test_default_is_public_preflight_only(case,monkeypatch):
    monkeypatch.setattr(collect.process,'run_case',lambda *a,**kw:(_ for _ in ()).throw(AssertionError('no worker authorized')))
    result=run(case);assert result['passed'] and not result['execute'] and not result['actual_key_generation'] and not result['workspace_retained']
    assert not list(case.parent.iterdir()) and collect.check_archive(case.output/'sources.tar.gz',collect.hashes(case.raw))

def test_successful_explicit_execution_retains_only_external_keys(case):
    r=run(case,True);assert r['passed'] and r['workspace_retained'] and r['actual_key_generation']
    assert (Path(r['workspace'])/'public_keys/key.npy').read_bytes()==b'fake payload'
    assert not list(case.output.rglob('*.npy')) and not list(case.output.rglob('*.npz'))
    assert r['all_processes_reaped'] and r['cleanup_completed']

@pytest.mark.parametrize('kind',('false','source','archive','unreaped','bad_worker','bad_stdout_digest'))
def test_failed_strict_worker_gate_removes_only_owned_keys(case,monkeypatch,kind):
    def worker(*args,**kw):
        row=case.complete(*args,**kw);directory=args[1]
        if kind=='false':row['returncode']=1
        elif kind=='source':
            value=json.loads((directory/'worker_report.json').read_text());value['source_hashes_end']={};collect.write(directory/'worker_report.json',value)
        elif kind=='archive':monkeypatch.setattr(collect,'check_archive',lambda *a:False)
        elif kind=='unreaped':row['process_reaped']=False
        elif kind=='bad_worker':(directory/'worker_report.json').write_text('[]')
        else:row['result']['worker_report_sha256']='b'*64
        collect.write(directory/'process.json',row);return row
    monkeypatch.setattr(collect.process,'run_case',worker)
    if kind=='archive':
        r=run(case,True);assert not r['passed']
    else:
        with pytest.raises(ValueError):run(case,True)
    r=report(case);assert not r['passed']
    if kind=='unreaped':assert Path(r['workspace']).exists() and r['workspace_retained']
    else:assert not Path(r['workspace']).exists()

@pytest.mark.parametrize('evidence',('missing','corrupt','nonobject','incomplete','reaped'))
def test_primary_cancellation_and_unknown_active_cleanup_fail_closed(case,monkeypatch,evidence):
    error=KeyboardInterrupt('primary cancel')
    def stop(command,directory,**kw):
        if evidence=='corrupt':(directory/'process.json').write_text('{')
        elif evidence=='nonobject':(directory/'process.json').write_text('[]')
        elif evidence=='incomplete':collect.write(directory/'process.json',{'process_reaped':True})
        elif evidence=='reaped':collect.write(directory/'process.json',dict(process_reaped=True,public_key_store_removed=True,owned_directory_handle_closed=True))
        raise error
    monkeypatch.setattr(collect.process,'run_case',stop)
    with pytest.raises(KeyboardInterrupt) as caught:run(case,True)
    assert caught.value is error;r=report(case);assert not r['passed']
    if evidence=='reaped':assert not Path(r['workspace']).exists()
    else:assert Path(r['workspace']).exists() and r['workspace_retained'] and not r['all_processes_reaped']

@pytest.mark.parametrize('failure',('initial_write','software','source'))
def test_early_metadata_failure_publishes_failed_record(case,monkeypatch,failure):
    if failure=='initial_write':
        original=collect.write;calls=[]
        def write(*args):
            calls.append(1)
            if len(calls)==1:raise OSError('initial transient publication')
            original(*args)
        monkeypatch.setattr(collect,'write',write)
    elif failure=='software':monkeypatch.setattr(collect.process,'software_versions',lambda:(_ for _ in ()).throw(ValueError('metadata')))
    else:monkeypatch.setattr(collect,'sources',lambda:(_ for _ in ()).throw(ValueError('source')))
    with pytest.raises((OSError,ValueError)):run(case)
    assert not report(case)['passed'] and not list(case.parent.iterdir())


def test_final_publication_failure_does_not_mask_primary(case,monkeypatch):
    error=KeyboardInterrupt('primary');original=collect.write
    def worker(*a,**kw):raise error
    monkeypatch.setattr(collect.process,'run_case',worker)
    def write(path,value):
        if path.name=='report.json' and 'elapsed_s'in value:raise OSError('final write')
        original(path,value)
    monkeypatch.setattr(collect,'write',write)
    with pytest.raises(KeyboardInterrupt) as caught:run(case,True)
    assert caught.value is error and any('final write' in n for n in error.__notes__)


def test_workspace_replacement_retained_on_failure(case,monkeypatch):
    def replace(command,directory,**kw):
        workspace=Path(command[command.index('--workspace')+1]);workspace.rename(workspace.with_name(workspace.name+'-original'));workspace.mkdir();(workspace/'marker').write_text('retain')
        collect.write(directory/'process.json',dict(process_reaped=True,public_key_store_removed=True,owned_directory_handle_closed=True));raise KeyboardInterrupt('cancel')
    monkeypatch.setattr(collect.process,'run_case',replace)
    with pytest.raises(KeyboardInterrupt):run(case,True)
    r=report(case);assert (Path(r['workspace'])/'marker').read_text()=='retain' and not r['cleanup_completed']


def test_capacity_choice_is_measured_and_fallback_explicit(case,monkeypatch):
    second=case.parent.with_name('second');second.mkdir()
    monkeypatch.setattr(collect.shutil,'disk_usage',lambda path:SimpleNamespace(total=1000,free=10 if Path(path)==case.parent else 900))
    chosen,observations=collect.choose_parent((case.parent,second),100);assert chosen==second and len(observations)==2
    with pytest.raises(OSError):collect.choose_parent((case.parent,),100)

@pytest.fixture
def worker_case(tmp_path,monkeypatch):
    import worker
    monkeypatch.setenv('JAX_PLATFORMS','cpu');monkeypatch.setattr(worker,'HERE',tmp_path)
    source=tmp_path/'frozen.py';source.write_bytes(b'# frozen source')
    expected={'frozen.py':hashlib.sha256(source.read_bytes()).hexdigest()};manifest=tmp_path/'source.json';manifest.write_text(json.dumps(expected))
    workspace=tmp_path/'workspace';workspace.mkdir();output=tmp_path/'worker_report.json';calls=[]
    def generate(paths):
        calls.append('generate')
        for n in ('public_keys','client_private'):paths[n].mkdir(mode=0o700)
        (paths['public_keys']/'public_manifest.json').write_text(json.dumps(dict(context_id='a'*64)))
        public=dict(context_id='a'*64)
        (paths['client_private']/'private_manifest.json').write_text(json.dumps(dict(context_id='a'*64,public_manifest_sha256=hashlib.sha256(worker.keys_canonical(public)).hexdigest())))
        (paths['client_private']/'secret.npy').write_bytes(b'fake private key')
        for p in paths['client_private'].iterdir():os.chmod(p,0o600)
        return dict(context_id='a'*64)
    stage=SimpleNamespace(MODEL_ID='model',REVISION='revision',_inputs=lambda:({'profile_bytes':b'p','plan_bytes':b'r'},b'm'),client_key_generation=generate)
    keys=SimpleNamespace(preflight=lambda *a,**kw:(calls.append('preflight') or {},(),{'mocked':True}))
    monkeypatch.setitem(sys.modules,'file_stages',stage);monkeypatch.setitem(sys.modules,'client_keys',keys)
    return SimpleNamespace(worker=worker,workspace=workspace,output=output,manifest=manifest,source=source,expected=expected,calls=calls,stage=stage)


def test_worker_source_and_preflight_precede_first_handler(worker_case):
    c=worker_case;assert c.worker.run(c.workspace,c.output,c.manifest)==0
    r=json.loads(c.output.read_text());assert r['passed'] and r['source_hashes_start']==r['source_hashes_end']==c.expected
    assert c.calls==['preflight','generate'] and r['actual_key_generation_started'] and r['actual_key_generation_completed']
    assert not r['encryption'] and not r['full_model_evaluated']


def test_worker_wrong_start_sources_fail_before_preflight_or_keys(worker_case):
    c=worker_case;c.source.write_bytes(b'changed')
    with pytest.raises(ValueError):c.worker.run(c.workspace,c.output,c.manifest)
    r=json.loads(c.output.read_text());assert not r['passed'] and not r['actual_key_generation_started'] and not c.calls


def test_worker_changed_source_after_handler_is_failed_evidence(worker_case):
    c=worker_case;old=c.stage.client_key_generation
    def generate(paths):r=old(paths);c.source.write_bytes(b'changed during keys');return r
    c.stage.client_key_generation=generate
    assert c.worker.run(c.workspace,c.output,c.manifest)==1
    r=json.loads(c.output.read_text());assert not r['passed'] and r['actual_key_generation_completed'] and not r['source_files_unchanged']


def test_worker_primary_cancel_survives_finalwrite_failure(worker_case,monkeypatch):
    c=worker_case;error=KeyboardInterrupt('cancel');write=c.worker.write
    def generate(paths):raise error
    c.stage.client_key_generation=generate
    def publish(path,r):
        if 'elapsed_s'in r:raise OSError('terminal metadata write')
        write(path,r)
    monkeypatch.setattr(c.worker,'write',publish)
    with pytest.raises(KeyboardInterrupt) as caught:c.worker.run(c.workspace,c.output,c.manifest)
    assert caught.value is error and any('terminal metadata write' in n for n in error.__notes__)


def test_worker_evidence_omits_private_manifest_and_secret_descriptor(worker_case):
    c=worker_case;c.worker.run(c.workspace,c.output,c.manifest);r=json.loads(c.output.read_text())
    assert r['private_binding_verified'] and r['private_permissions_verified'] and r['private_file_count']==2
    assert 'private_manifest' not in r and 'secret' not in r and 'secret.npy' not in c.output.read_text()

@pytest.mark.parametrize('kind',('collector','worker'))
def test_repeated_all_three_signals_cannot_interrupt_primary_failure_publication(case,worker_case,monkeypatch,kind):
    import signal
    signals=(signal.SIGINT,signal.SIGTERM,signal.SIGHUP);old={s:signal.getsignal(s) for s in signals};error=KeyboardInterrupt('original interruption')
    if kind=='collector':
        original=collect.write
        def abort(command,directory,**kw):
            collect.write(directory/'process.json',dict(process_reaped=True,public_key_store_removed=True,owned_directory_handle_closed=True));raise error
        monkeypatch.setattr(collect.process,'run_case',abort)
        def write(path,r):
            if path.name=='report.json' and 'elapsed_s'in r:
                for s in (*signals,*signals):os.kill(os.getpid(),s)
            original(path,r)
        monkeypatch.setattr(collect,'write',write)
        with pytest.raises(KeyboardInterrupt) as caught:run(case,True)
        assert not report(case)['passed'] and not list(case.parent.iterdir())
    else:
        c=worker_case;original=c.worker.write
        c.stage.client_key_generation=lambda paths:(_ for _ in ()).throw(error)
        def write(path,r):
            if 'elapsed_s'in r:
                for s in (*signals,*signals):os.kill(os.getpid(),s)
            original(path,r)
        monkeypatch.setattr(c.worker,'write',write)
        with pytest.raises(KeyboardInterrupt) as caught:c.worker.run(c.workspace,c.output,c.manifest)
        assert not json.loads(c.output.read_text())['passed']
    assert caught.value is error and {s:signal.getsignal(s) for s in signals}==old

@pytest.mark.parametrize('first',('SIGINT','SIGTERM','SIGHUP'))
def test_local_termination_handler_shields_repeated_cleanup_signals(first):
    import signal
    from cleanup import termination_signals,SIGNALS
    old={s:signal.getsignal(s) for s in SIGNALS};sig=getattr(signal,first)
    with pytest.raises(KeyboardInterrupt if sig==signal.SIGINT else SystemExit):
        with termination_signals():
            try:os.kill(os.getpid(),sig)
            finally:
                for repeat in SIGNALS:os.kill(os.getpid(),repeat)
    assert {s:signal.getsignal(s) for s in SIGNALS}==old
