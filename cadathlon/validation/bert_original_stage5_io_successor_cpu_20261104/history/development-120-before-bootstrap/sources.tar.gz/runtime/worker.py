"""Actual first file-stage key generation; invoked only by explicit collector execution."""
from pathlib import Path
import argparse,contextlib,hashlib,json,os,stat,sys,time
from cleanup import cleanup_signals,termination_signals
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE/'stage'),str(HERE)]

def keys_canonical(value):return (json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def write(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');tmp.replace(path)
def read_hashes(expected):
    actual={}
    for name in expected:
        p=Path(name)
        if p.is_absolute() or '..' in p.parts:raise ValueError('relative source member required')
        actual[name]=hashlib.sha256((HERE/p).read_bytes()).hexdigest()
    return actual

def run(workspace,output,expected_path):
    started=time.monotonic();primary=None;expected={};report=dict(passed=False,actual_key_generation_started=False,
        scope='Actual client key generation for the first of five handlers only; no input, model forward, encryption or server inference.',
        encryption=False,full_model_evaluated=False,pid=os.getpid(),cpu_affinity=sorted(os.sched_getaffinity(0)))
    try:
        write(output,report)
        if os.environ.get('JAX_PLATFORMS')!='cpu':raise ValueError('explicit CPU key-generation process required')
        expected=json.loads(expected_path.read_text())
        report['source_hashes_start']=read_hashes(expected)
        if report['source_hashes_start']!=expected:raise ValueError('source startup binding differs')
        import file_stages,client_keys
        paths=dict(size=0,batch_size=1,model_id=file_stages.MODEL_ID,model_revision=file_stages.REVISION,
                   public_keys=workspace/'public_keys',client_private=workspace/'client_private')
        inputs,_=file_stages._inputs()
        _,_,preflight=client_keys.preflight(paths['public_keys'],paths['client_private'],**inputs)
        report['preflight_before_keygen']=preflight;report['actual_key_generation_started']=True;write(output,report)
        with contextlib.redirect_stdout(sys.stderr):result=file_stages.client_key_generation(paths)
        public=json.loads((paths['public_keys']/'public_manifest.json').read_text());private=json.loads((paths['client_private']/'private_manifest.json').read_text())
        if (result['context_id']!=public['context_id'] or private['context_id']!=public['context_id']
                or private['public_manifest_sha256']!=hashlib.sha256(keys_canonical(public)).hexdigest()):raise ValueError('completed handler identity differs')
        private_paths=paths['client_private']
        if (set(x.name for x in private_paths.iterdir())!={'secret.npy','private_manifest.json'}
                or stat.S_IMODE(private_paths.lstat().st_mode)!=0o700
                or any(not stat.S_ISREG((private_paths/n).lstat().st_mode) or stat.S_IMODE((private_paths/n).lstat().st_mode)!=0o600 for n in ('secret.npy','private_manifest.json'))):
            raise ValueError('private key inventory/permissions differ')
        report.update(passed=True,handler_result=result,public_manifest=public,private_binding_verified=True,private_permissions_verified=True,private_file_count=2,
            retained_key_workspace=str(workspace),actual_key_generation_completed=True)
    except BaseException as e:primary=e;report.update(passed=False,error=dict(type=type(e).__name__,message=str(e)))
    finally:
        with cleanup_signals():
            try:
                after=read_hashes(expected) if expected else {};report.update(source_hashes_end=after,source_files_unchanged=bool(expected) and after==expected,
                    elapsed_s=time.monotonic()-started)
                report['passed']=bool(report['passed'] and report['source_files_unchanged']);write(output,report)
            except BaseException as e:
                if primary is None:raise
                primary.add_note('worker source/publication: '+repr(e))
            if primary is not None:raise primary

    print(json.dumps(dict(passed=report['passed'],context_id=report['public_manifest']['context_id'],
        worker_report_sha256=hashlib.sha256(output.read_bytes()).hexdigest(),elapsed_s=report['elapsed_s'])));return 0 if report['passed'] else 1
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--workspace',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--source-manifest',type=Path,required=True);a=p.parse_args()
    with termination_signals():raise SystemExit(run(a.workspace,a.output,a.source_manifest))
