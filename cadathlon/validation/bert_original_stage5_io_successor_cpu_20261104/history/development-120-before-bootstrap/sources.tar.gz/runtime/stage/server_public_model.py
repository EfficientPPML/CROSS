"""Pinned public BERT server weights cache; no client inputs, codec or inference.

The caller authenticates context_id against its complete public key manifest.
This module links that identity to the exact checkpoint and nonlinear circuit.
"""
from pathlib import Path
import hashlib,json,math,os,re,shutil,stat
import numpy as np
CHECKPOINT_SHA256='e1f8085ef673c9eb8a1a93a84270742e8aa0ccbceadef01eef15e26c44b46034'
CONFIG_SHA256='ec2b6cd6ce741dda6c972aea96f9d1a449cbb4b5349e688c5370a9b2f6872d30'
CANDIDATE_SHA256='4e2277beea7189aa1d77b168c500c8a175f6c630afa520fcc6b38cb5a179cff9'
PROFILE_SHA256='fe2408637f9d6de19ac6aef9f6f749aaef9dd56ccbb37b5334293cd223ede035'
TENSOR_SHA256={'bert.encoder.layer.0.attention.output.LayerNorm.bias': '2c76aba351fd94b34a299abf2cf8e2d12d2b903bf63f00e66bea6ed20773cc0d',
 'bert.encoder.layer.0.attention.output.LayerNorm.weight': '75757855791f359399f2b35e7fb16db0bc93d08a3476cf7fdd8c523027029d03',
 'bert.encoder.layer.0.attention.output.dense.bias': 'b80a500392b9bff59848d76a2d89d77a43cb132747beb292261f7b07bad800f3',
 'bert.encoder.layer.0.attention.output.dense.weight': 'e00c6a53896c0ed3d2a4fe73edd1313952d23e80bfc88e40402b2b9fd2df3e70',
 'bert.encoder.layer.0.attention.self.key.bias': 'aee8e9d6fb2d9f305221ee344c00e6a026bac065717dfd5191d86bcf8b0cdc4f',
 'bert.encoder.layer.0.attention.self.key.weight': '854e6ccfbdd78eb9108127baaf3374ec8a69120994aae532b1985cab67103981',
 'bert.encoder.layer.0.attention.self.query.bias': '85b53d121a7751dbd243a12ce73c6be48132471667f817fde6020e1baaaed9c4',
 'bert.encoder.layer.0.attention.self.query.weight': '1a8914c482024a643b1503123f2c1bac81ce565d0ab7c98f06d8951d8b277f47',
 'bert.encoder.layer.0.attention.self.value.bias': 'dab39da7473f97300c2380a0cff1028e91062f1da40efa95fc3c419cfa19cff9',
 'bert.encoder.layer.0.attention.self.value.weight': 'd21b08742d7d298ef2139215a704546011010b5ed40fd315ae430af9b50eb174',
 'bert.encoder.layer.0.intermediate.dense.bias': 'b279856af79c545cdb2f914e02e9a953204152319f160e484ebfcc8d6b825774',
 'bert.encoder.layer.0.intermediate.dense.weight': '9a0c8aa79b2bac48fc35f37b6695d253080f7eedd556b70b65411aab9c319fd3',
 'bert.encoder.layer.0.output.LayerNorm.bias': '5ca80117e32d77fbf91306d6bce9dc1a4b93548c158312825d493346857d6a2d',
 'bert.encoder.layer.0.output.LayerNorm.weight': 'e10771889f781626f1a16ea0ad106b3f88ee65df412cd0021b37bdf3c93c007e',
 'bert.encoder.layer.0.output.dense.bias': '744629ad72bdc326f22cd92c6429610c06ed41dd3a2fedd307d3f01f861638b9',
 'bert.encoder.layer.0.output.dense.weight': '754a718ad071ca9ec27790aee1b82dc9db41cc3ef90c6c73a90ada8668f6fa0d',
 'bert.encoder.layer.1.attention.output.LayerNorm.bias': 'de6025ff142a079ff70501a73e0ec02ce524c4e1e28f85715bdb2875d8ff6a9f',
 'bert.encoder.layer.1.attention.output.LayerNorm.weight': '6316372e1a432e72debc360260c15857d0e454188bf4e7a876ea04f88bb54339',
 'bert.encoder.layer.1.attention.output.dense.bias': 'b8fee71f9fbb7d927b53ff114d3f3edb20b82bcdee207fbeb580af658e0664fb',
 'bert.encoder.layer.1.attention.output.dense.weight': '2982eb9d01df73c738b011a29003ed53ed54c86a4726a9ab72b617209b6463ed',
 'bert.encoder.layer.1.attention.self.key.bias': 'f42de7a66bb0be8a92cce047d0972993867dd5320368d2b449bcc89d68a8caf3',
 'bert.encoder.layer.1.attention.self.key.weight': '38f71be6a7ed0164b622e1b191657ac5d2ce2beb95f17f0281315e5f2fc85bac',
 'bert.encoder.layer.1.attention.self.query.bias': '05a82acd3c3e7f382a8ba269a06805d8e5e7fcf8a3bf71b89926fbf3d068c186',
 'bert.encoder.layer.1.attention.self.query.weight': 'c9f862a497b34b7f69052d756be7383e68a37d453af9a8d2638bd750cb092ee7',
 'bert.encoder.layer.1.attention.self.value.bias': '13f5c02ab6b0f5196803ae0ea68922a0cc8056918916b5c9e0cc5f683ca2cb4c',
 'bert.encoder.layer.1.attention.self.value.weight': '2e667d23de4b6ee92f432a2b3e67def4f8a4eb324ea388273bf8ef5fdf9f9873',
 'bert.encoder.layer.1.intermediate.dense.bias': '1178f6555a12ebab731d65f1ef4e86825c41cc218266f37601fb2bfbd290af93',
 'bert.encoder.layer.1.intermediate.dense.weight': '1f0484087c7995968611527bec325da22ff1557b59aec586b749ffd7bc80e16d',
 'bert.encoder.layer.1.output.LayerNorm.bias': '98f9a1bacb0067f1d0b8f0b9ad2d36e328c4c220c28e197db0a29c8605c1e823',
 'bert.encoder.layer.1.output.LayerNorm.weight': 'b2bf9b467392cccee9b2c8681a0901e0a6b10562e76e580d404943c1eb7f28c5',
 'bert.encoder.layer.1.output.dense.bias': 'e85913bbdead5aaba5eb28544040cac7d020f8b943d509dcf23064c7eac3c40d',
 'bert.encoder.layer.1.output.dense.weight': '5cbdc79e05f28dd68d3a57c30834a0b2beec337b7a8c27bed15885eda997cb35',
 'bert.encoder.layer.10.attention.output.LayerNorm.bias': 'aea7d92865aa1cc9c9ee70ff6b86b63cda2e1fd50211a78409fea8e2641294a8',
 'bert.encoder.layer.10.attention.output.LayerNorm.weight': '0b2aa95da210df8b4b520d20a02bc0c362cfd6ea1e6506c2171bc48eb5e6b0cc',
 'bert.encoder.layer.10.attention.output.dense.bias': 'bd94d971f68d4acab3761afa34f36ff0200bb159bc4755588b6854d0725b8ce3',
 'bert.encoder.layer.10.attention.output.dense.weight': 'f7b051c69aed15190f741a18859a02d86bd367442ef3bbebf2645b9eedf7ea6d',
 'bert.encoder.layer.10.attention.self.key.bias': '58f3d13df25c11b4ceb0780148c8b8b6bd05623f79faaf1f97365149b0227d5b',
 'bert.encoder.layer.10.attention.self.key.weight': '0ad0e4b440d37c1613bf2289fcf34faf99ca0c18ed3d81c52a7662ddf37154fe',
 'bert.encoder.layer.10.attention.self.query.bias': 'a7a732ddb395515f5d7cfbf9c345ab7e78815f21e1e8500cad0a780263b70ceb',
 'bert.encoder.layer.10.attention.self.query.weight': '917515dc0349b552f972e377ac15c578329ba34468265e15ca354ebdd6645fda',
 'bert.encoder.layer.10.attention.self.value.bias': 'd4c2db7ed619f3da6353eff1bcf5aba21e5badd7d8816682d09f0416dfc64cd7',
 'bert.encoder.layer.10.attention.self.value.weight': '0f197113a7358a9397b1d50419c0dca0b4919fc79b4c359c6ecd728f63e5d9e3',
 'bert.encoder.layer.10.intermediate.dense.bias': '48e30b1e29626dd37ffeac20c4a165cde0c832782361d95e1995eddec2b245e4',
 'bert.encoder.layer.10.intermediate.dense.weight': 'aba24dbc1bd8d8e73ef200cc5071088123cf758e7cfcbade9001f2b3465b19ff',
 'bert.encoder.layer.10.output.LayerNorm.bias': '05d598681c1073c38c1271044b023d04c20aa57e23901102f835b1810cc0f3d1',
 'bert.encoder.layer.10.output.LayerNorm.weight': 'fbe7c68512c3bd200f33260dff3683cde107250c60a52758f9afb8748c3cafc6',
 'bert.encoder.layer.10.output.dense.bias': 'eb641b20b75160d24248f3f957dcaa7aa085669c0a0e7ae1bc6656fc72d754e1',
 'bert.encoder.layer.10.output.dense.weight': 'c55d5c68b6656e4b90f50356bb556107800f0eea23da2da47dfe9ccc287d8402',
 'bert.encoder.layer.11.attention.output.LayerNorm.bias': '7ced907e09f765f162f2b64b31c263668ba7275d721504eb9c830e6e37ab880c',
 'bert.encoder.layer.11.attention.output.LayerNorm.weight': 'a08386ea70d634ea2f284a174268381f3646e57e17f5faba41512534b5782905',
 'bert.encoder.layer.11.attention.output.dense.bias': 'e33bf5de8d1e95175269dc3b4e8f7738c2cfa21f6eb3b26520b1791dcb25244b',
 'bert.encoder.layer.11.attention.output.dense.weight': '33205f2ccd48e5af2c3bd4a7acbc50824e1517ab3bf8cb089a8a100be1470fb7',
 'bert.encoder.layer.11.attention.self.key.bias': '8cfb7c00002e803e74f9888cd1d183ff1956fc1c25e0715a929aa330fb3e37c7',
 'bert.encoder.layer.11.attention.self.key.weight': '7f79ce6d2c0b25b00c9c2ae030d7cb77257effabe7949d8ee5fc8e548517d245',
 'bert.encoder.layer.11.attention.self.query.bias': '676c6ea772d73dfe1f48b72acb9ededb4d138dc753e316c7c4d7fa55a4d9d174',
 'bert.encoder.layer.11.attention.self.query.weight': '4e1b3ca86271a7e1e1fa8a31bd40e7a6fa2d785c143015e2bbff48ee60fb1511',
 'bert.encoder.layer.11.attention.self.value.bias': '610aa95016d249975fdf4c1a1d96347a47befd5352e5b77977b0feeb0294ee72',
 'bert.encoder.layer.11.attention.self.value.weight': 'd4923074ea6129b6d4290a85d33a3d912b692aecdcfd00d6b6654d4d8b930640',
 'bert.encoder.layer.11.intermediate.dense.bias': '020fdadeea09418c1bf7d4010ba16cb713bd2b1ecfc896e6968a60667fa36cb6',
 'bert.encoder.layer.11.intermediate.dense.weight': '22890cc787dbf0b573a397d7e41a6ffe1e3b3161abc14e6cff5e65767ed57b9e',
 'bert.encoder.layer.11.output.LayerNorm.bias': '1f119fd4768af7863ad2f8c7b29be7c4212ccc3ca6926f66e00e875ff87b5516',
 'bert.encoder.layer.11.output.LayerNorm.weight': '353fa2eacc234dbc765fbe46b46199d98bba5f569397572a51ec685769784d27',
 'bert.encoder.layer.11.output.dense.bias': '69960b262fba7bad0d288e83780d2835e709c0ae6a1156c27100b618153a30b3',
 'bert.encoder.layer.11.output.dense.weight': '08c251bd3b1bb6826b27deb59d6d9c51ecd21d2a4d7320736bad6b7ea9753623',
 'bert.encoder.layer.2.attention.output.LayerNorm.bias': '2a1bffd76ca29eb4853976511ba8858dd8ad6b1beeb0b2b54620c25a7ae36951',
 'bert.encoder.layer.2.attention.output.LayerNorm.weight': '766e6edfa879e2913e4f9cf3c3e1274e27ed57d2861e62a278238483ea59fe29',
 'bert.encoder.layer.2.attention.output.dense.bias': 'd46eb89b63d5cf0574af3b039bbab877f729435b50a5410b7d389119a5b686f8',
 'bert.encoder.layer.2.attention.output.dense.weight': '8485f025b291676573172cb0954e1385ffbaaa97bc17c1803ed94e42f4bd1550',
 'bert.encoder.layer.2.attention.self.key.bias': 'a8579b07eb47bcc0af039233e2dc5413759ffaa522a28873c32d5ca4bda9e02b',
 'bert.encoder.layer.2.attention.self.key.weight': '73f70e2f5d3ee7d808a2f92f65116599f3f447f6717771cdbde2815e599e51f3',
 'bert.encoder.layer.2.attention.self.query.bias': '40c022afb06a11cde7aebc0fd78cb1236afa23a8f0e9ce4c6d6093ae71fca71f',
 'bert.encoder.layer.2.attention.self.query.weight': '4b88541805cbd00f1a80c4f54c37f92bb9d3b3c50e03de33b49b1cc34ce6c68b',
 'bert.encoder.layer.2.attention.self.value.bias': 'c4e3343c0e9edd27c2e5ec9c9b93d2c09b0ee4acaeb8e7c6bd0765db933a8ee4',
 'bert.encoder.layer.2.attention.self.value.weight': 'c0485f3a0d31da4c43d9b08d068619dc71fdbba19a198df05ce95ad70e839bf5',
 'bert.encoder.layer.2.intermediate.dense.bias': 'fbe47ae7b52ce92fafdfaf78d0f6401afef34a09e4ab9e635d764b126c13897a',
 'bert.encoder.layer.2.intermediate.dense.weight': '51a2ee2649dc7b60d5979dbff4878adea194e3be8f1740759826454a2c171fc2',
 'bert.encoder.layer.2.output.LayerNorm.bias': '657c6ef663d7d144bdaac360b2f8705a5ae40a98a2bb88632e0dca0a6a702e07',
 'bert.encoder.layer.2.output.LayerNorm.weight': '21de0868829773e3a3de564347bb1606170d9a6911059f84a91478d640d0af5d',
 'bert.encoder.layer.2.output.dense.bias': 'cf57db5e9f5c392b9e7e2bbe89d1e9a96542c3458b19e029b5ee4ddbb46e195a',
 'bert.encoder.layer.2.output.dense.weight': '805a2f6ad0d3ab65df5571b3cd29069250b708215fb1b5b09e6e2aac54aa2674',
 'bert.encoder.layer.3.attention.output.LayerNorm.bias': 'b6c2fb26593c69dc75f7a02eb914e10ca12879e30a5bb91c829291dacbd225cf',
 'bert.encoder.layer.3.attention.output.LayerNorm.weight': 'c90eecee0a6db1608381fb53441abde728c70041d9e208bf70b6492828b2b490',
 'bert.encoder.layer.3.attention.output.dense.bias': '250f33e14330280f866a509d8be873e41ffdc44a8fdaded9680e5743ec682e4f',
 'bert.encoder.layer.3.attention.output.dense.weight': 'b3d8e903e298eec2dd6dd3bd090fe62cc871d144efd0b1b974b6992403a2e9e1',
 'bert.encoder.layer.3.attention.self.key.bias': 'b4cbc7156af0c51b1c87851f71871d8441a59a2526f2da3f6a55a107b0c3e942',
 'bert.encoder.layer.3.attention.self.key.weight': 'f1ca2672af6e718cb0cdf9ead92de1d0d90996fd132765ddebf036262af4b328',
 'bert.encoder.layer.3.attention.self.query.bias': '5b4ea89f51fcd032d824c5f320859c4328033216fb49ca4366f6ed05fc4a201a',
 'bert.encoder.layer.3.attention.self.query.weight': 'e4c5edf3e1ffe4394ca84e221e3815377e30d6dc08df6b44ab9c9e87e68e85c1',
 'bert.encoder.layer.3.attention.self.value.bias': 'be1bbc2faff886e35132779b66d5c07d1d5e4d0788a99ed1fadfce3b3c9cb561',
 'bert.encoder.layer.3.attention.self.value.weight': '9650a2fce3491b190fae63817e4fffde0fbfd59c6df63b22721e4e7fc56f1f5e',
 'bert.encoder.layer.3.intermediate.dense.bias': '69799a8b95a65ecf4f1704773880a292b60e341993fed3db70cbb220b5e1f253',
 'bert.encoder.layer.3.intermediate.dense.weight': 'b0fbb462453815217117759dfbc7ccf01d901714fdc46020037c967cd60784b4',
 'bert.encoder.layer.3.output.LayerNorm.bias': '53b8cd99fd37507ad3257f7c0e5fcfc779b6b35f6e955f127c42949878a2e336',
 'bert.encoder.layer.3.output.LayerNorm.weight': '874cdec928501b7bdce137ef169d835dd5ab3ab1abba92b11821fdd390903d5a',
 'bert.encoder.layer.3.output.dense.bias': '51acba7460387d88652e3d066447d7d80f2f6812fa400144339d10d9d55df9fd',
 'bert.encoder.layer.3.output.dense.weight': '0a6e6ad2670ae04df7515948eebae3d44969fbe50669bda9e56ed7cb1134bba3',
 'bert.encoder.layer.4.attention.output.LayerNorm.bias': '2c60603f7ea87a5b12e16e150514b1045fe700892cdc4b3e9b1a3c09e870d978',
 'bert.encoder.layer.4.attention.output.LayerNorm.weight': '2aa9d933667e1512ba42bb76385126edef60776fab407e5498a8fea2e31665e4',
 'bert.encoder.layer.4.attention.output.dense.bias': '85e77fa755fbeb35787efbb1ddbe9c09eb7873a2dee3fc294e03f8c239adc69a',
 'bert.encoder.layer.4.attention.output.dense.weight': '61d0c4f6170fea5208c345732295294cae46001cf33e357f9e18172dede432df',
 'bert.encoder.layer.4.attention.self.key.bias': 'd40d4e221c78e0773799d3c704cbfdf271f61173b117e08bf4b51266e7778fe2',
 'bert.encoder.layer.4.attention.self.key.weight': '98dc8b9244e8502db77d8e921d899993f46d4cdadf1dffe346541e5d3ea320ba',
 'bert.encoder.layer.4.attention.self.query.bias': '4b5c3cc214c36b953d0c9c92aa371dd1fbd3e7076a9a03e8adaab355585014de',
 'bert.encoder.layer.4.attention.self.query.weight': 'f1840ec37f5699d94d9fbe4854e86091b12c91cba6170077f503d7c1f2a45d69',
 'bert.encoder.layer.4.attention.self.value.bias': '15afa95cc2e4045ca1df6475e455ed54348f31fafaf28bdcd1813ce63061695b',
 'bert.encoder.layer.4.attention.self.value.weight': '9ce8311b7390516a49657d650db18d52057d0c8f226b7f72c2c333ec3ed667cc',
 'bert.encoder.layer.4.intermediate.dense.bias': '4e69519448ce87cd5cf68c210bb2347d36df5d3f9f228f7cd4ed755b117b6ac7',
 'bert.encoder.layer.4.intermediate.dense.weight': '7357293696739a774307362c023afdd3f663dc3fce5d2aaa97f630173b484504',
 'bert.encoder.layer.4.output.LayerNorm.bias': 'c5077ccefde4b688c95e76424635533410ec6e5b096a3ad40d7b11521144b656',
 'bert.encoder.layer.4.output.LayerNorm.weight': '8f27ad4c14ef5885d60674f9db441d8e96801feb6dc8ce9c21ffc822c7bcd431',
 'bert.encoder.layer.4.output.dense.bias': '88899dc48d4dedefc59e3972c5cded3af2941a71842806a5e24ef0d51a1bdf7c',
 'bert.encoder.layer.4.output.dense.weight': 'b81897cc9b3dd3e89c1eeb9b65212db130346f309a339feab088dfc8db3ec495',
 'bert.encoder.layer.5.attention.output.LayerNorm.bias': '75a5f349d1589356067d0bfce00e63db33afeeedee9e8955aa9536e3ec90533a',
 'bert.encoder.layer.5.attention.output.LayerNorm.weight': '932fd1c0f0f294958b0599369b76667593d0edd2cf9ce3ed42d65e42ab0a89d6',
 'bert.encoder.layer.5.attention.output.dense.bias': '4c13d388d808008927022d0eb925f7d7108ce5db63c1dec10d68666cf06b60e8',
 'bert.encoder.layer.5.attention.output.dense.weight': '82bbc3524ee47ca3167df906e64009d3c731fd7e777fef71b21a7b37bb94ba52',
 'bert.encoder.layer.5.attention.self.key.bias': 'dc5ff95b347ea57d3dae6bcae19c469c633789f28e777b77db4a6e98a00aa61f',
 'bert.encoder.layer.5.attention.self.key.weight': 'defe0eaa581bc5ea993c8d6289e891ace2b27f83c48525a5cf62016a9cb66f10',
 'bert.encoder.layer.5.attention.self.query.bias': '59d15b8e5ced60279910cf2ce286eeee13263ee58c898f9c2dfc5d43bde641f6',
 'bert.encoder.layer.5.attention.self.query.weight': 'b3605e8f7b40b67ecdb8c0fcfef41756282fc48c01273fb56f64f8f089682c89',
 'bert.encoder.layer.5.attention.self.value.bias': '5654e69b38f0197fad4b106f4db0361afbbcf2ff34126bbb50a7d28fe8ddcb2d',
 'bert.encoder.layer.5.attention.self.value.weight': '0208a0751d7815192e0e3466d0fa7c8e765811604dad531073242279d3fbb3cf',
 'bert.encoder.layer.5.intermediate.dense.bias': '0a725fee4ce0dec55902a00f0e624649ba079d0c99448df821328cf80406422f',
 'bert.encoder.layer.5.intermediate.dense.weight': '595fa1ca028cb6b3ed1e59314cfcce33d9c930949a0508d2952a6274fa4ca8dd',
 'bert.encoder.layer.5.output.LayerNorm.bias': '62f69fac1683ce32b31690de751c607c6a559ba62d342c6b69a142d65acb3428',
 'bert.encoder.layer.5.output.LayerNorm.weight': 'd8aaf2650fadff6c393dad1b73702cf59411cdabed2d6ce1d3c44b673fa426c6',
 'bert.encoder.layer.5.output.dense.bias': '82f83d9b89060ee88d6cb1d36a927c28104c140ff4a109140bca3f67b785acde',
 'bert.encoder.layer.5.output.dense.weight': '3c681293ab1fbb222e49d36caaa95662e663c441c9751cf88b6fc624f63cbb57',
 'bert.encoder.layer.6.attention.output.LayerNorm.bias': '4010bdcbd7d42f338ab3835d87356cea38b8469fa01708f209c32a294e7fe131',
 'bert.encoder.layer.6.attention.output.LayerNorm.weight': 'b5fea01335a751278baeddf1a31cb083e095f29ad7796dc8af7c4ab6118950a9',
 'bert.encoder.layer.6.attention.output.dense.bias': '56af0d6cd545e01b8fc07da5de011d5bbeb245b38d27a53db3c683dfe0409303',
 'bert.encoder.layer.6.attention.output.dense.weight': 'b78d1d07f783859285f13eb4275ea46c02671e167badb57cadc097113fa883bb',
 'bert.encoder.layer.6.attention.self.key.bias': '3853b60a0bdbd37028fddc1a0cbff66e5a82cefd548ddc6121a05c0c064c57e8',
 'bert.encoder.layer.6.attention.self.key.weight': '95fbd56520a76ab5b840836e327a24b4c48905c5d131024547bb6181008385c9',
 'bert.encoder.layer.6.attention.self.query.bias': '425aecc047ea4297a0693ca3b49c1a0ee85fb35fe8610cb75152d9c4758dad32',
 'bert.encoder.layer.6.attention.self.query.weight': '028ed3cc30f8f70f0e55ca4556995146fe110ff521e7690ed591f191adcecb62',
 'bert.encoder.layer.6.attention.self.value.bias': 'b28932739a0e0ce87bb2335773af18340bac872deb7c1b0ae2f0651e1b43cce1',
 'bert.encoder.layer.6.attention.self.value.weight': '3c258dacc1563cc344339a412049fe66ae8d92de2fa426b6aa2c8b81c442258d',
 'bert.encoder.layer.6.intermediate.dense.bias': '8eaefee26791f3b39a906f4e47afe423ac29da46978e0054599ab7308e414a46',
 'bert.encoder.layer.6.intermediate.dense.weight': '938a41ec46eefaf709eb1638ec1e9d3105d05636678fc77846147c69ab32061e',
 'bert.encoder.layer.6.output.LayerNorm.bias': '768d8e5e5ae955b01806a36744c7123688aa45d2a561e709fc165e3febeaec4f',
 'bert.encoder.layer.6.output.LayerNorm.weight': '441bc873242233cc5a9d72c0f50bff95770831f45637259470b2c759d028f9df',
 'bert.encoder.layer.6.output.dense.bias': '61f197a77d3d8bf78770ac27f01ad1e26082008d52d4aa746bd2bf081cc840e0',
 'bert.encoder.layer.6.output.dense.weight': 'b4230f3018a58784346b104c86d8acdd60459cd12d43983194ffb02e5e1bfadb',
 'bert.encoder.layer.7.attention.output.LayerNorm.bias': '83d7f85d9ea16e31d44c901a7638703fc346d867641514fe852a8ff92b8fe71a',
 'bert.encoder.layer.7.attention.output.LayerNorm.weight': '4a2af000c606b7cf37092ced2f0ad5e201cfddcb1f772114c463b536179b1ff0',
 'bert.encoder.layer.7.attention.output.dense.bias': '09eedba2b4599e861eaf8c70c370d13f5ab31518e0b6ca592eb5e19b478c19b5',
 'bert.encoder.layer.7.attention.output.dense.weight': 'd60e98bf59a48917213a3cc736d663eb95f5f8b7b5d7b615448a2d54a5de347c',
 'bert.encoder.layer.7.attention.self.key.bias': 'a947516d702e2b6dff0ddc05b8def55bcc41d0f7a0e7f146908e9e88ee11fae8',
 'bert.encoder.layer.7.attention.self.key.weight': 'f707df3329e59aa3b40250d02d69112974c0c7aa8d2c341645d7c2281a42a9d1',
 'bert.encoder.layer.7.attention.self.query.bias': '7d182baf26420584da6146153cfab4531ef2b7cba9fcc4a4e7e16052c17a3de3',
 'bert.encoder.layer.7.attention.self.query.weight': '6863090655477c7c073f8308c9d77b19c328a9b7da356a8d2a550fa6a2d622b5',
 'bert.encoder.layer.7.attention.self.value.bias': '15882948edc5571e3941cd924808cb077f38b77cb065ec39167044ca230823e6',
 'bert.encoder.layer.7.attention.self.value.weight': 'f54850961bf33cb3b804b6131fa4d3aeae985453cca8361d652992e1e5fb4184',
 'bert.encoder.layer.7.intermediate.dense.bias': 'b82b75188bcfaeb69883b9551f3ae50bae4ea679c8a0b2248ede339361a0a6ba',
 'bert.encoder.layer.7.intermediate.dense.weight': 'f3ed256a2a9ea1c76fa600bc7960e835a6160e789fca9d04c75486dcfa09e773',
 'bert.encoder.layer.7.output.LayerNorm.bias': '0b51077b40dc93207ea596df9db71899d32757b2e788d59e3ebf657d934aee22',
 'bert.encoder.layer.7.output.LayerNorm.weight': '04dc58c809616a5ec5c96b1181e6993c36997bdf37b45e7ce40b742741a574eb',
 'bert.encoder.layer.7.output.dense.bias': '2026af55894c9ab1bccaa5d5ce3ab6c4884e1992f0f8fea6345aafbfd8f1e55a',
 'bert.encoder.layer.7.output.dense.weight': 'ee98097cc9d95744f093ec1bca068de96bd02ec2325b75fdf3c88403488e66b1',
 'bert.encoder.layer.8.attention.output.LayerNorm.bias': '7662023d46f64eded53be93004c4acc43ed31c8fd25dc0f6f5db144f35eb9eae',
 'bert.encoder.layer.8.attention.output.LayerNorm.weight': 'a2091edec061f6e5a577f96f43eab3b8d31ac4833e89886cbb2e362b72467d06',
 'bert.encoder.layer.8.attention.output.dense.bias': '0beb1640b98f79c39216e73e2ae0f6cf7f469ab1d295aadfcf67bdc8eda41989',
 'bert.encoder.layer.8.attention.output.dense.weight': 'bca5c017de2bfb5198bd10614a5131443a2e0efcc2368bc42f86e272fd7e9f4e',
 'bert.encoder.layer.8.attention.self.key.bias': 'a2f227587519aa581692d2fe4049c18bd5ef27e7179970aedd80c7e6c87bbaae',
 'bert.encoder.layer.8.attention.self.key.weight': '86d07569791fec467dbe5ba1a673623d2874ebcc59402b207b72a121ab7d1c99',
 'bert.encoder.layer.8.attention.self.query.bias': '0d8a144876192a5f062289868876dc04460e84c76bd2178e73c6e24648793a2d',
 'bert.encoder.layer.8.attention.self.query.weight': '0a6bba60973e576c01f4d61cc92424aaf86a0cfa81839bb76225bb2102f14497',
 'bert.encoder.layer.8.attention.self.value.bias': '0f0eb333af3ca9ac6e0ace7af4840eb79f55eec2f2588c955fc319463dc95699',
 'bert.encoder.layer.8.attention.self.value.weight': 'c6e196efe9d996be35049d9af35931fc79975162e4ad32d53b95897bf5bbfd5d',
 'bert.encoder.layer.8.intermediate.dense.bias': '0613cfd3daed9169e5bd462456e9803bbb291c03b0bb513cc3c240c8a2a79a6a',
 'bert.encoder.layer.8.intermediate.dense.weight': '95bb55ddc5b9ff05165c5974f38dad86aafc13c732d6084ae8a198f8c0c1f9b5',
 'bert.encoder.layer.8.output.LayerNorm.bias': 'f9a9a41c863cc21ef0e7a8f9ffde427db7d08a3cb6195cb6fe6ecb47c1d83bdc',
 'bert.encoder.layer.8.output.LayerNorm.weight': '2c3445b33cc113a96648bb3332eda535ff72f09489274808435ad8dcd61b7893',
 'bert.encoder.layer.8.output.dense.bias': '31066e27803904a84bd6bfc048473bb374ccf52d212c4be0296464a86867da6c',
 'bert.encoder.layer.8.output.dense.weight': '677a5f5938c959783d926209ed6974e8bed0a59a1ae04fb6b5529f89710de2ec',
 'bert.encoder.layer.9.attention.output.LayerNorm.bias': '6b44b62033253f32ca446c198535f7aa37ee26ed072bd454a5b47a037cdea880',
 'bert.encoder.layer.9.attention.output.LayerNorm.weight': 'c9efcd7bf3a015c9f228f8a3165d49fba019cf8043318a0a04ef0c87fdf481a8',
 'bert.encoder.layer.9.attention.output.dense.bias': '19b2847b05b5742a53dc20f57ec8eb2ff70923fcf1a14773821596a2b9b3e6ee',
 'bert.encoder.layer.9.attention.output.dense.weight': '49c5f59b00d61cc28f1864edde39542ae08baf31597bd803b513e52f90dfb712',
 'bert.encoder.layer.9.attention.self.key.bias': '05743bbf26b91802b4636394c31c3b243f1588453e65eb81775271f07a708551',
 'bert.encoder.layer.9.attention.self.key.weight': '33187d38f26549bf0d75221517336b1b1c44e4369c4299906a17daba050af150',
 'bert.encoder.layer.9.attention.self.query.bias': 'f4464531e5d31f13399086413768893b710cd6a38b43b2fb99f33c8fcdc1acd2',
 'bert.encoder.layer.9.attention.self.query.weight': '99b4f78364476cffe12f359b14dbfda08d8d1de8dae9608458fc90747955c077',
 'bert.encoder.layer.9.attention.self.value.bias': '07552494558a382b9712c4c145b780050dc6184bf083b4e3bedd726b4bb1d3dc',
 'bert.encoder.layer.9.attention.self.value.weight': '8a5d8c7c2ec3b1d3bed6546102648e24e6c2067663202b379a6d51d36f769b78',
 'bert.encoder.layer.9.intermediate.dense.bias': 'fef4a372b34dd291728adbc23eb944b888841adea998f1bbcd0c3fe7e601e7e3',
 'bert.encoder.layer.9.intermediate.dense.weight': '7e03b05477e1e30da50fdad94f4208f5c910652aa3d841f7a6c2be8af27a8c5f',
 'bert.encoder.layer.9.output.LayerNorm.bias': 'a45de94be812eb7d01aed2d8944418d7bb17a0b45e76a066304923770b98c97f',
 'bert.encoder.layer.9.output.LayerNorm.weight': '6aa522f2876743fe43850117918163a0cf213c69dbc84d55a12fef83fa7b2c03',
 'bert.encoder.layer.9.output.dense.bias': '7ff247b3200b8ef5a717fdde467afaaeca19b78144d486f238b0e70c4d30de81',
 'bert.encoder.layer.9.output.dense.weight': '3437ecc7e00a1efd8c90e0b30188b1b3da7c7fdc52058b25d51258dd30a44bd1',
 'bert.pooler.dense.bias': '9950db2634ea18cb363ea8ca10e6fac1fc8ac485e82b270f9bea2804c4408847',
 'bert.pooler.dense.weight': '41fa4a1811934ec7009a4a94ccefd8c1834a15d3c863c744aa78135c0e0e5bd3',
 'classifier.bias': '2a5f1ee5fdb9203159bdd9c08109829d2873ea8d24d3b75ccd7e7296edc58685',
 'classifier.weight': 'e691bd558c442e6a67f2ed611c25e378bdd88e8f3abd696659f0d36ceea76d3e'}
SHA=re.compile(r'[0-9a-f]{64}\Z')
SCHEMA='cross-bert-full-public-model-v1'
PACKING=dict(slots=65536,features=4096,rows_per_tile=16,input_width=768,ffn_width=3072,heads=12,head_width=64,sequence_length=128,encoder_layers=12,classifier_width=2)
def tensor_shapes():
    result={}
    for i in range(12):
        p=f'bert.encoder.layer.{i}.'
        for name in ('attention.self.query','attention.self.key','attention.self.value','attention.output.dense'):
            result[p+name+'.weight']=(768,768);result[p+name+'.bias']=(768,)
        result[p+'intermediate.dense.weight']=(3072,768);result[p+'intermediate.dense.bias']=(3072,)
        result[p+'output.dense.weight']=(768,3072);result[p+'output.dense.bias']=(768,)
        for name in ('attention.output.LayerNorm','output.LayerNorm'):
            result[p+name+'.weight']=(768,);result[p+name+'.bias']=(768,)
    result.update({'bert.pooler.dense.weight':(768,768),'bert.pooler.dense.bias':(768,),'classifier.weight':(2,768),'classifier.bias':(2,)})
    assert len(result)==196
    return dict(sorted(result.items()))
def canonical(value):return (json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def digest(value):return hashlib.sha256(canonical(value)).hexdigest()
def file_sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def _object(pairs):
    out={}
    for k,v in pairs:
        if k in out:raise ValueError('duplicate JSON field')
        out[k]=v
    return out
def _json(raw):
    def invalid(value):raise ValueError('nonfinite JSON value')
    return json.loads(raw,object_pairs_hook=_object,parse_constant=invalid)
def _read(path,maximum):
    fd=os.open(path,os.O_RDONLY|os.O_NONBLOCK|getattr(os,'O_NOFOLLOW',0))
    try:
        s=os.fstat(fd)
        if not stat.S_ISREG(s.st_mode) or s.st_size>maximum:raise ValueError('unexpected public artifact type/size')
        with os.fdopen(fd,'rb',closefd=False) as f:raw=f.read(maximum+1)
        if len(raw)>maximum:raise ValueError('public artifact exceeds bound')
        return raw
    finally:os.close(fd)
def _identity(context_id):
    if type(context_id)is not str or not SHA.fullmatch(context_id):raise ValueError('authenticated public context digest required')
def _base(context_id):
    _identity(context_id)
    return dict(schema=SCHEMA,context_id=context_id,checkpoint_sha256=CHECKPOINT_SHA256,config_sha256=CONFIG_SHA256,
                candidate_sha256=CANDIDATE_SHA256,profile_sha256=PROFILE_SHA256,packing=dict(PACKING),representation='little-endian-float32-public-checkpoint-tensors')
def open_owned_directory(path):
    """Pin the just-created directory inode until cleanup completes.

    This detects path replacement and prevents inode reuse. It is not an OS
    sandbox against a same-user child moving other entries into its own tree.
    """
    descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        status = os.fstat(descriptor)
        return descriptor, {'device': status.st_dev, 'inode': status.st_ino}
    except BaseException as error:
        try:
            os.close(descriptor)
        except BaseException as cleanup_error:
            error.add_note(f'Directory handle cleanup also failed: {cleanup_error}')
        raise

def remove_owned_directory(path, descriptor, identity):
    """Remove only the still-identical directory; retain moved/replaced paths.

    The identity check is a concurrency guard, not an atomic defense against
    arbitrary same-user directory manipulation during recursive deletion.
    """
    if descriptor is None or identity is None:
        raise RuntimeError('owned directory identity was not acquired; retained')
    held = os.fstat(descriptor)
    if {'device': held.st_dev, 'inode': held.st_ino} != identity:
        raise RuntimeError('owned directory descriptor identity changed; retained')
    try:
        current = path.lstat()
    except FileNotFoundError:
        if held.st_nlink == 0:
            return True  # The actual original directory was already removed.
        raise RuntimeError('owned directory was moved; original files retained')
    if stat.S_ISLNK(current.st_mode):
        raise RuntimeError('owned directory was replaced by a symlink; retained')
    if (not stat.S_ISDIR(current.st_mode)
            or {'device': current.st_dev, 'inode': current.st_ino} != identity):
        raise RuntimeError('owned directory identity was replaced; retained')
    shutil.rmtree(path)
    return not path.exists() and not path.is_symlink()

def check_owned_directory(path, descriptor, identity):
    held=os.fstat(descriptor);current=path.lstat()
    if (identity!={'device':held.st_dev,'inode':held.st_ino} or not stat.S_ISDIR(current.st_mode)
            or identity!={'device':current.st_dev,'inode':current.st_ino}):
        raise RuntimeError('owned public cache directory moved or replaced')

def preprocess(snapshot,output,*,context_id,candidate_bytes,profile_bytes):
    """Write only196 public server tensors into a newly owned directory."""
    _identity(context_id);snapshot=Path(snapshot);output=Path(output)
    if type(candidate_bytes)is not bytes or hashlib.sha256(candidate_bytes).hexdigest()!=CANDIDATE_SHA256:raise ValueError('frozen candidate bytes differ')
    if type(profile_bytes)is not bytes or hashlib.sha256(profile_bytes).hexdigest()!=PROFILE_SHA256:raise ValueError('frozen common profile bytes differ')
    model=snapshot/'model.safetensors';config=snapshot/'config.json'
    if file_sha(model)!=CHECKPOINT_SHA256 or file_sha(config)!=CONFIG_SHA256:raise ValueError('pinned public checkpoint/config differs')
    output.mkdir(exist_ok=False);records={};descriptor=None;identity=None;primary=None
    try:
        descriptor,identity=open_owned_directory(output)
        with model.open('rb') as f:
            n=int.from_bytes(f.read(8),'little')
            if not 0<n<=2**20:raise ValueError('unexpected checkpoint header size')
            header=_json(f.read(n));base=8+n
            for index,(name,shape) in enumerate(tensor_shapes().items()):
                d=header[name]
                if d['dtype']!='F32' or d['shape']!=list(shape):raise ValueError('public checkpoint tensor shape/dtype differs')
                a,b=d['data_offsets'];f.seek(base+a);raw=f.read(b-a)
                if len(raw)!=math.prod(shape)*4 or hashlib.sha256(raw).hexdigest()!=TENSOR_SHA256[name]:raise ValueError('public checkpoint tensor byte count differs')
                array=np.frombuffer(raw,dtype='<f4').reshape(shape)
                if not np.isfinite(array).all():raise ValueError('nonfinite public checkpoint tensor')
                check_owned_directory(output,descriptor,identity)
                filename=f'tensor_{index:03d}.npy';np.save(output/filename,array,allow_pickle=False)
                check_owned_directory(output,descriptor,identity)
                records[name]=dict(file=filename,shape=list(shape),dtype='<f4',tensor_sha256=hashlib.sha256(raw).hexdigest(),file_sha256=file_sha(output/filename))
        if file_sha(model)!=CHECKPOINT_SHA256 or file_sha(config)!=CONFIG_SHA256:raise ValueError('public assets changed during extraction')
        body=_base(context_id)|dict(tensors=records)
        check_owned_directory(output,descriptor,identity)
        manifest=body|dict(model_id=digest(body));(output/'model_manifest.json').write_bytes(canonical(manifest))
        check_owned_directory(output,descriptor,identity)
        return manifest
    except BaseException as error:
        primary=error
        try:remove_owned_directory(output,descriptor,identity)
        except BaseException as cleanup:error.add_note('Owned public cache cleanup also failed: '+repr(cleanup))
        raise
    finally:
        if descriptor is not None:
            try:os.close(descriptor)
            except BaseException as cleanup:
                if primary is None:raise
                primary.add_note('Owned public cache handle close also failed: '+repr(cleanup))

def load(output,*,context_id):
    """Authenticate full cache and return immutable exact FP64 public lifts."""
    output=Path(output);base=_base(context_id);manifest=_json(_read(output/'model_manifest.json',2**20))
    if type(manifest)is not dict or set(manifest)!=set(base)|{'tensors','model_id'}:raise ValueError('public model manifest fields differ')
    # Canonical bytes preserve exact JSON types, so True cannot impersonate1.
    if any(canonical(manifest[k])!=canonical(v) for k,v in base.items()):raise ValueError('public model/circuit/context identity differs')
    body={k:v for k,v in manifest.items() if k!='model_id'}
    if manifest['model_id']!=digest(body):raise ValueError('public model manifest digest differs')
    expected=tensor_shapes();records=manifest['tensors']
    if type(records)is not dict or set(records)!=set(expected):raise ValueError('exact196 public server tensors required')
    files={'model_manifest.json'};arrays={}
    for index,(name,shape) in enumerate(expected.items()):
        record=records[name];filename=f'tensor_{index:03d}.npy'
        if (type(record)is not dict or set(record)!={'file','shape','dtype','tensor_sha256','file_sha256'}
                or record['tensor_sha256']!=TENSOR_SHA256[name] or record['file']!=filename or canonical(record['shape'])!=canonical(list(shape)) or record['dtype']!='<f4'
                or any(type(record[k])is not str or not SHA.fullmatch(record[k]) for k in ('tensor_sha256','file_sha256'))):raise ValueError('public tensor descriptor differs')
        files.add(filename)
    if {p.name for p in output.iterdir()}!=files:raise ValueError('public cache inventory differs')
    for name,shape in expected.items():
        record=records[name];raw=_read(output/record['file'],math.prod(shape)*4+512)
        if hashlib.sha256(raw).hexdigest()!=record['file_sha256']:raise ValueError('public tensor file digest differs')
        import io
        with io.BytesIO(raw) as stream:
            if np.lib.format.read_magic(stream)!=(1,0):raise ValueError('public tensor NPY version differs')
            declared_shape,fortran,dtype=np.lib.format.read_array_header_1_0(stream,max_header_size=512)
            offset=stream.tell()
        if (type(declared_shape)is not tuple or any(type(x)is not int for x in declared_shape)
                or declared_shape!=shape or fortran is not False or dtype.str!='<f4'
                or len(raw)!=offset+math.prod(shape)*4):raise ValueError('public tensor header shape/dtype/order/byte count differs')
        array=np.frombuffer(raw,dtype='<f4',offset=offset,count=math.prod(shape)).reshape(shape)
        if (array.dtype.str!='<f4' or array.shape!=shape or not np.isfinite(array).all()
                or hashlib.sha256(array.tobytes()).hexdigest()!=record['tensor_sha256']):raise ValueError('public tensor payload differs')
        arrays[name]=np.frombuffer(array.astype('<f8').tobytes(),dtype='<f8').reshape(shape)
    return arrays,manifest
