from pathlib import Path
from types import SimpleNamespace
from contextlib import contextmanager,nullcontext
import os,json,pytest
import client_io as io

@pytest.mark.parametrize('kind',[ValueError,KeyboardInterrupt,SystemExit])
def test_primary_survives_all_cleanup(kind):
 p=kind('body');r={};f=io.Finalizer(r,p);seen=[]
 for secondary in (OSError('close'),KeyboardInterrupt('cancel')):
  f.attempt('cleanup',lambda s=secondary:(_ for _ in ()).throw(s))
 f.attempt('later',lambda:seen.append(1))
 with pytest.raises(kind)as got:f.raise_if_failed()
 assert got.value is p and seen==[1]and len(r['cleanup_errors'])==2

@pytest.mark.parametrize('kind',[KeyboardInterrupt,SystemExit])
def test_cleanup_only_cancel_priority(kind):
 f=io.Finalizer({});first=OSError('ordinary');cancel=kind('cancel')
 for e in (first,cancel):f.attempt('release',lambda e=e:(_ for _ in ()).throw(e))
 with pytest.raises(kind)as got:f.raise_if_failed()
 assert got.value is cancel

def test_failed_shield_installer_still_retires_once():
 @contextmanager
 def bad():raise OSError('install');yield
 f=io.Finalizer({});seen=[];f.shielded(bad,lambda:seen.append(1))
 assert seen==[1]
 with pytest.raises(OSError):f.raise_if_failed()

@pytest.mark.parametrize('phase',['initial','terminal','restore'])
def test_finish_fail_closed_publication(tmp_path,monkeypatch,phase):
 p=tmp_path/'report';r={'passed':False};original=io.write;calls=[]
 def write(*a):
  calls.append(1)
  if (phase=='initial'and len(calls)==1)or(phase=='terminal'and len(calls)==2):raise OSError('write')
  original(*a)
 @contextmanager
 def termination():
  yield
  if phase=='restore':raise OSError('restore')
 monkeypatch.setattr(io,'write',write)
 with pytest.raises(OSError):io.finish(p,r,lambda r:r.update(body_complete=True,cleanup_completed=True),termination,nullcontext)
 assert json.loads(p.read_text())['passed']is False and r['termination_scope_completed']is False

def test_body_primary_survives_republication(tmp_path,monkeypatch):
 primary=KeyboardInterrupt('body');n=0
 def write(*args):
  nonlocal n;n+=1
  if n>1:raise OSError('publication')
 monkeypatch.setattr(io,'write',write)
 with pytest.raises(KeyboardInterrupt)as got:io.finish(tmp_path/'report',{},lambda r:(_ for _ in ()).throw(primary),nullcontext,nullcontext)
 assert got.value is primary

def test_success_only_after_restoration(tmp_path):
 seen=[]
 @contextmanager
 def scope():yield;seen.append('restored')
 r={};io.finish(tmp_path/'r',r,lambda r:r.update(body_complete=True,cleanup_completed=True),scope,nullcontext)
 assert seen==['restored']and r['passed']and r['termination_scope_completed']

def test_uncertain_directory_close_is_never_retried(tmp_path,monkeypatch):
 owner=io.HeldDirectory(tmp_path);fd=owner.fd;real=os.close;calls=[];failure=OSError('uncertain')
 def close(n):calls.append(n);raise failure
 monkeypatch.setattr(io,'os',SimpleNamespace(close=close))
 for _ in range(2):
  with pytest.raises(OSError)as got:owner.close()
  assert got.value is failure
 assert calls==[fd]and owner in io._QUARANTINE
 real(fd)

def test_read_open_identity_check(tmp_path,monkeypatch):
 p=tmp_path/'data';p.write_bytes(b'abc');old=io.os.open
 def replace(*args):p.rename(tmp_path/'old');p.write_bytes(b'abc');return old(*args)
 monkeypatch.setattr(io,'os',SimpleNamespace(**{n:getattr(os,n)for n in ('O_RDONLY','O_NOFOLLOW','O_NONBLOCK','fstat','read','close')},open=replace))
 with pytest.raises(ValueError,match='replaced'):io.read(p)

@pytest.mark.parametrize('kind',['symlink','oversize','empty'])
def test_read_rejects_nonregular_bounds(tmp_path,kind):
 p=tmp_path/'data';p.write_bytes(b'abc')
 if kind=='symlink':q=tmp_path/'link';q.symlink_to(p);p=q
 if kind=='empty':p.write_bytes(b'')
 with pytest.raises(ValueError):io.read(p,2 if kind=='oversize'else 100)

def test_archive_full_inventory(tmp_path):
 raw={'a.py':b'a','x/b.json':b'{}'};p=tmp_path/'s.tar.gz';io.archive(p,raw);assert io.check_archive(p,io.hashes(raw))
 with pytest.raises(ValueError):io.check_archive(p,{'a.py':io.digest(b'a')})

@pytest.mark.parametrize('kind',['same','child','parent','alias'])
def test_disjoint_paths(tmp_path,kind):
 protected=tmp_path/'held';protected.mkdir();path={'same':protected,'child':protected/'new','parent':tmp_path}.get(kind)
 if kind=='alias':path=tmp_path/'alias';path.symlink_to(protected,target_is_directory=True)
 with pytest.raises(ValueError):io.outside(path,[protected])
