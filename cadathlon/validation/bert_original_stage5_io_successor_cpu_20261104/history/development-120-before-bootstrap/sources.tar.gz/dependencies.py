from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent
def check():
    record=json.loads((HERE/'dependencies.json').read_bytes())
    if record.get('ready')is not True:raise RuntimeError('stage5 dependencies remain pending root review')
    for name,field in [('runtime/stage/key_contexts.py','key_contexts_sha256'),('cleanup.py','cleanup_sha256'),('terminal.py','terminal_sha256')]:
        if hashlib.sha256((HERE/name).read_bytes()).hexdigest()!=record[field]:raise ValueError('reviewed stage5 cleanup dependency differs')
    return record
