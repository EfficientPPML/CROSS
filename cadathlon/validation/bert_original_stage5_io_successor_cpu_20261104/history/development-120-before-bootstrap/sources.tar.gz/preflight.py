"""Frozen source-copy mock tests only; no actual prerequisite/private reads."""
from pathlib import Path
import argparse,hashlib,io,json,os,platform,signal,subprocess,sys,tarfile,time
HERE=Path(__file__).resolve().parent
import collect
from cleanup import termination_signals,cleanup_signals
from terminal import terminal_scope

def run(output):
    output=Path(output);output.mkdir(parents=True,exist_ok=False);start=time.monotonic();primary=None;child=None;before={};snapshot=None;cleanup=[]
    report=dict(passed=False,scope='Source-bound stage5 mocked prerequisite/worker/collector/metric/receipt checks only; no actual reference, input, key, model or ciphertext payload reads.',
        actual_client_decode=False,actual_server_execution=False,private_payloads_read=False,pid=os.getpid(),cpu_affinity=sorted(os.sched_getaffinity(0)))
    try:
        collect.write(output/'report.json',report)
        raw=collect.sources();before=collect.hashes(raw);report['source_hashes_before']=before
        collect.archive(output/'sources.tar.gz',raw)
        if not collect.check_archive(output/'sources.tar.gz',before):raise ValueError('startup archive differs')
        snapshot=output/'snapshot';snapshot.mkdir()
        for n,v in raw.items():p=snapshot/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(v)
        tests=sorted(n for n in raw if '/'not in n and n.startswith('test_') and n.endswith('.py'))
        command=[sys.executable,'-m','pytest','-q',*tests,'--junitxml='+str(output/'tests.xml')]
        env=os.environ.copy();env.update(PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',JAX_PLATFORMS='cpu')
        with (output/'tests.log').open('wb') as stream:
            child=subprocess.Popen(command,cwd=snapshot,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
            report['child_pid']=child.pid;code=child.wait()
        report.update(command=command,returncode=code,process_reaped=True)
        if code!=0:raise RuntimeError('mock suite failed; raw log preserved')
        import xml.etree.ElementTree as ET
        tree=ET.parse(output/'tests.xml');suites=tree.getroot().findall('testsuite')
        counts={k:sum(int(s.attrib.get(k,0)) for s in suites) for k in ('tests','failures','errors','skipped')}
        if counts['failures'] or counts['errors']:raise ValueError('mock test failures')
        report.update(test_counts=counts,operation_complete=True,python=platform.python_version())
    except BaseException as error:primary=error;report['error']=dict(type=type(error).__name__,message=str(error))
    finally:
        with terminal_scope(report,output/'report.json',collect.write,cleanup_signals,
                lambda:(primary,next((e for e in cleanup if not isinstance(e,Exception)),cleanup[0] if cleanup else None))):
            def attempt(label,fn):
                try:return fn()
                except BaseException as e:
                    cleanup.append(e)
                    if primary is not None:primary.add_note(label+': '+repr(e))
            if child is not None and child.poll()is None:
                attempt('stop owned mock child',lambda:os.killpg(child.pid,signal.SIGKILL));attempt('reap mock child',child.wait)
            report['process_reaped']=child is None or child.poll()is not None
            after=attempt('current source audit',lambda:collect.hashes(collect.sources()))
            copied=attempt('copied source audit',lambda:{n:hashlib.sha256((snapshot/n).read_bytes()).hexdigest() for n in before}) if snapshot else None
            verified=attempt('archive audit',lambda:collect.check_archive(output/'sources.tar.gz',before)) if before else False
            report.update(source_hashes_after=after,snapshot_hashes=copied,source_count=len(before),source_files_unchanged=bool(before) and before==after==copied,
                source_archive_verified=verified is True,elapsed_s=time.monotonic()-start,cleanup_errors=[repr(e) for e in cleanup])
            if (output/'sources.tar.gz').is_file():report['source_archive_sha256']=hashlib.sha256((output/'sources.tar.gz').read_bytes()).hexdigest()
            report['passed']=bool(report.get('operation_complete') and primary is None and not cleanup and report['process_reaped'] and report['source_files_unchanged'] and verified)
            collect.write(output/'report.json',report)
            if primary is not None:raise primary
            if cleanup:raise next((e for e in cleanup if not isinstance(e,Exception)),cleanup[0])
    print(json.dumps({n:report[n] for n in ('passed','test_counts','source_count','source_archive_sha256')}));return report

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    with termination_signals():report=run(parser.parse_args().output)
    raise SystemExit(0 if report['passed'] else 1)
