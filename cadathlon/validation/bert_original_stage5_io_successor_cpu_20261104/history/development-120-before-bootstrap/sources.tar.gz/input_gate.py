"""Externally authenticated, complete upstream size0 client input prerequisite."""
from pathlib import Path
import io,os,stat,tarfile
import key_gate

MODEL=Path('/home/jianming_gatech/cross_validation_assets/bert/f150c1d609d1e50dd5e2e5408661cfac8339277c')
DATA=Path('/home/jianming_gatech/cross_validation_assets/mrpc/bcdcba79d07bc864c1c254ccfcedcce55bcc9a8c/validation.parquet')
ASSETS={
    str(MODEL/'config.json'):'ec2b6cd6ce741dda6c972aea96f9d1a449cbb4b5349e688c5370a9b2f6872d30',
    str(MODEL/'model.safetensors'):'e1f8085ef673c9eb8a1a93a84270742e8aa0ccbceadef01eef15e26c44b46034',
    str(MODEL/'tokenizer.json'):'5b3360be30cdf39081153cf9d30bfb0503c011462fc9f77f097127c83ef0f4d9',
    str(MODEL/'tokenizer_config.json'):'0f6d13e6f4da6f9e24f22ada6bc3be571123d858d7c0c05a8a7cd55a9c23c2e8',
    str(MODEL/'vocab.txt'):'eeaa9875b23b04b4c54ef759d03db9d1ba1554838f8fb26c5d96fa551df93d02',
    str(DATA):'33c007dbf5bfa8463d87a13e6226df8c0fcf2596c2cd39d0f3bb79754e00f50f',
}
INPUT='io/single/intermediate/client_preprocessed_input'


def authenticate(evidence,expected_report_sha256):
    evidence=Path(evidence)
    raw=key_gate.read(evidence/'report.json')
    if key_gate.digest(raw)!=key_gate.sha_field(expected_report_sha256):
        raise ValueError('external completed input-fixture report differs')
    report=key_gate.parse(raw)
    flags=('passed','private_workspace_retained','sources_unchanged','assets_unchanged','upstream_originals_unchanged',
           'selection_byte_parity','tokenization_byte_parity','model_construction_and_forward_guards','private_file_permissions_all_0600')
    if (type(report)is not dict or report.get('schema')!='bert-upstream-size0-input-fixture-v1'
            or any(report.get(n)is not True for n in flags) or report.get('error') or report.get('cleanup_errors')):
        raise ValueError('complete upstream tokenizer-only fixture required')
    for name,value in dict(size=0,base_seed=42,generator_seed=191664963,record_count=1,dataset_record_count=408).items():
        if type(report.get(name))is not int or report[name]!=value:raise ValueError('fixed upstream size0 selection differs')
    if (type(report.get('token_lengths'))is not list or report['token_lengths']!=[128]
            or type(report['token_lengths'][0])is not int or type(report.get('valid_token_counts'))is not list
            or len(report['valid_token_counts'])!=1 or type(report['valid_token_counts'][0])is not int
            or not 1<=report['valid_token_counts'][0]<=128):raise ValueError('fixed tokenization dimensions differ')
    before=report.get('source_hashes_before')
    if type(before)is not dict or not before or before!=report.get('source_hashes_after'):
        raise ValueError('unchanged fixture sources required')
    for name,value in before.items():
        if type(name)is not str or Path(name).is_absolute() or '..' in Path(name).parts:raise ValueError('relative source member required')
        key_gate.sha_field(value)
    source=key_gate.read(evidence/'sources.tar.gz',16<<20)
    if key_gate.digest(source)!=key_gate.sha_field(report.get('source_archive_sha256')):raise ValueError('fixture source archive differs')
    with tarfile.open(fileobj=io.BytesIO(source)) as archive:
        members=archive.getmembers()
        if (len(members)!=len(before) or len({m.name for m in members})!=len(members)
                or any(not m.isfile() or m.size>2<<20 for m in members) or sum(m.size for m in members)>16<<20):
            raise ValueError('bounded exact fixture source inventory required')
        if {m.name:key_gate.digest(archive.extractfile(m).read()) for m in members}!=before:
            raise ValueError('fixture source archive readback differs')
    original=report.get('upstream_original_sha256_before')
    if type(original)is not dict or not original or original!=report.get('upstream_original_sha256_after'):
        raise ValueError('upstream source identities changed')
    if any(report.get(n)!=ASSETS for n in ('asset_file_sha256_before','asset_file_sha256_after')):
        raise ValueError('fixed dataset/tokenizer/model asset identities differ')
    name=report.get('private_workspace');identity=report.get('private_workspace_identity')
    if (type(name)is not str or not Path(name).is_absolute() or type(identity)is not dict
            or set(identity)!={'device','inode'} or any(type(v)is not int for v in identity.values())):
        raise ValueError('private fixture workspace identity required')
    workspace=Path(name);info=workspace.lstat()
    if (not stat.S_ISDIR(info.st_mode) or stat.S_IMODE(info.st_mode)!=0o700
            or [info.st_dev,info.st_ino]!=[identity['device'],identity['inode']]):
        raise ValueError('private fixture workspace identity or permissions differ')
    files=report.get('input_file_sha256')
    if type(files)is not dict or INPUT not in files or len(files)!=6:raise ValueError('complete private fixture inventory required')
    for relative,digest in files.items():
        if type(relative)is not str or Path(relative).is_absolute() or '..' in Path(relative).parts:
            raise ValueError('relative private input file required')
        key_gate.sha_field(digest)
    input_path=workspace/INPUT
    if report.get('preprocessed_input_path')!=str(input_path):raise ValueError('fixed upstream input path differs')
    # Only after the caller-pinned successful producer and all public evidence
    #has been checked do we read the private input needed by the next handler.
    input_bytes=key_gate._read_descriptor(input_path,16<<20,mode=0o600)
    if key_gate.digest(input_bytes)!=files[INPUT]:raise ValueError('private input bytes differ from completed fixture')
    return dict(preprocessed_input=input_path,input_sha256=files[INPUT],fixture_report_sha256=expected_report_sha256,
                private_workspace=workspace,valid_token_count=report['valid_token_counts'][0])
