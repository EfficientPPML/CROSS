from types import ModuleType,SimpleNamespace as NS
import sys
import pytest
import boundaries as b

@pytest.fixture
def fake(monkeypatch):
    names=('key_gen','jaxite_word.key_gen','file_stages','client_keys','client_inputs','key_contexts','request_lifecycle')
    modules={n:ModuleType(n) for n in names};old=[]
    def populate(owner,n):
        f=lambda *a,**k:None;setattr(owner,n,f);old.append((owner,n,f))
    ctx=type('CKKSContext',(),{})
    for n in ('encrypt','encrypt_slots','encrypt_slots_batch','program_initialization','decrypt_slots'):populate(ctx,n)
    package=ModuleType('jaxite_word');package.CKKSContext=ctx
    monkeypatch.setitem(sys.modules,'jaxite_word',package)
    for name,module in modules.items():monkeypatch.setitem(sys.modules,name,module)
    for name in ('key_gen','jaxite_word.key_gen'):
        for n in ('gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen'):populate(modules[name],n)
    for name,methods in {'file_stages':('client_key_generation','server_preprocess_model','client_encode_encrypt_input','server_encrypted_compute','_snapshot','client_decrypt_decode'),
        'client_keys':('generate',),'client_inputs':('ClientEmbeddings',),'key_contexts':('load_server',),'request_lifecycle':('retire_completed',)}.items():
        for n in methods:populate(modules[name],n)
    return NS(modules=modules,ctx=ctx,old=old)

def test_guard_all_forbidden_entrypoints_restores_and_allows_decode(fake):
    calls=[]
    with b.client_only(calls):
        fake.ctx.decrypt_slots();fake.modules['file_stages'].client_decrypt_decode()
        targets=[(owner,n) for owner,n,old in fake.old if n not in ('decrypt_slots','client_decrypt_decode')]
        for owner,n in targets:
            with pytest.raises(RuntimeError,match='forbidden'):getattr(owner,n)()
    assert len(calls)==21 and all(getattr(o,n)is f for o,n,f in fake.old)

def test_primary_cancel_restores_all(fake):
    primary=KeyboardInterrupt('primary')
    with pytest.raises(KeyboardInterrupt) as e:
        with b.client_only([]):raise primary
    assert e.value is primary and all(getattr(o,n)is f for o,n,f in fake.old)

@pytest.mark.parametrize('name',['torch','transformers'])
def test_native_preload_rejected(fake,monkeypatch,name):
    monkeypatch.setitem(sys.modules,name,ModuleType(name))
    with pytest.raises(ValueError,match='preload'):
        with b.client_only([]):pytest.fail('native process entered')

def test_partial_patch_install_restores(fake,monkeypatch):
    del fake.modules['key_gen'].gen_evaluation_key
    with pytest.raises(AttributeError):
        with b.client_only([]):pytest.fail('partial guards entered')
    assert all(getattr(o,n,None)is f for o,n,f in fake.old if not (o is fake.modules['key_gen'] and n=='gen_evaluation_key'))
