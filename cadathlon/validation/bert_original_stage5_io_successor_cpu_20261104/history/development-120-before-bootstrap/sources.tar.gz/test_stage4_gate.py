from pathlib import Path
from types import SimpleNamespace as NS
import io,json,os,stat,tarfile
import pytest
from test_stage3_gate import case as stage3_case,write,identity
import stage4_gate as g
import key_gate,transport_contract as tc,transport,file_stage_contract as bc

@pytest.fixture
def case(stage3_case,tmp_path,monkeypatch):
    old=stage3_case;requests=old.check();root=old.io;keys=old.keys;model=old.model
    evidence=tmp_path/'server-evidence';evidence.mkdir();gate=tmp_path/'server-gate';gate.mkdir();monkeypatch.setattr(g,'HERE',gate)
    batch=json.loads((root/'upload/batch.json').read_bytes());original=batch['requests'][0];nonce=original['contract']['request_id']
    download=root/'download';download.mkdir();sample=download/nonce;sample.mkdir();scale=keys['public_manifest']['parameters']['scaling_factor']
    binding=tc.ciphertext_contract(original['contract'],'response',0,scale,requests['input_digest'])
    manifest=transport._manifest_fields(binding)|dict(files={'bundle.json':'5'*64,'ct_0.npz':'6'*64})
    write(sample/'transport.json',manifest)
    for name in ('bundle.json','ct_0.npz'):(sample/name).write_bytes(b'not an encrypted payload; gate never opens it')
    response=bc.response_batch(batch,[dict(request_id=nonce,input_digest=requests['input_digest'],scale=scale,response_manifest_sha256=transport.manifest_digest(manifest))])
    write(download/'batch.json',response);write(root/'server_report',dict(full_model_compute_and_transport_seconds=12.))
    source={f'source{i}.py':f'# public{i}\n'.encode() for i in range(217)}
    expected={n:key_gate.digest(v) for n,v in source.items()};write(gate/'stage4_source_manifest.json',expected)
    write(gate/'dependencies.json',dict(stage4_source_inventory_sha256=key_gate.digest((gate/'stage4_source_manifest.json').read_bytes())))
    with tarfile.open(evidence/'sources.tar.gz','w:gz') as tar:
        for n,v in source.items():m=tarfile.TarInfo(n);m.size=len(v);tar.addfile(m,io.BytesIO(v))
    req=dict(sample_count=1,tile_count=8,public_batch_sha256=requests['public_batch_sha256'],input_digest=requests['input_digest'],
        ciphertext_payload_bytes=800<<20,tiles=requests['tiles'])
    resp=dict(sample_count=1,response_count=1,input_digest=requests['input_digest'],public_batch_sha256=requests['public_batch_sha256'],
        response_batch_sha256=tc.digest(response),response_manifest_sha256=transport.manifest_digest(manifest),payload_bytes=6<<20,
        shape=[1,2,256,512,6],scale=scale,level=2,full_model_compute_and_transport_seconds=12.)
    remaining={}
    for name in ('upload','download','server_report'):
        s=(root/name).stat();remaining[name]=dict(present=True,device=s.st_dev,inode=s.st_ino,size=s.st_size,
            kind='directory' if stat.S_ISDIR(s.st_mode) else 'regular')
    pre={n:keys[n] for n in ('context_id','key_report_sha256','key_source_archive_sha256')}|{
        n:model[n] for n in ('model_id','model_report_sha256','model_manifest_sha256')}|{
        n:requests[n] for n in ('stage3_report_sha256','public_batch_sha256','input_digest')}
    worker=dict(passed=True,actual_server_compute_started=True,actual_server_compute_completed=True,request_readback_complete=True,
        response_readback_complete=True,source_files_unchanged=True,keygen_codecs_native_private_forbidden=True,terminal_scope_completed=True,
        source_hashes_start=expected,source_hashes_end=expected,prerequisite=pre,context_id=keys['context_id'],model_id=model['model_id'],
        request_readback=req,response_readback=resp,remaining_artifacts=remaining)
    report=dict(passed=True,execute=True,actual_server_compute=True,actual_execution_attempted=True,all_processes_reaped=True,
        external_workspaces_never_removed=True,operation_complete=True,cleanup_completed=True,terminal_scope_completed=True,
        source_files_unchanged=True,source_archive_verified=True,io_workspace_retained=True,source_hashes_start=expected,source_hashes_end=expected,
        execution_source_hashes_end=expected,source_archive_sha256=key_gate.digest((evidence/'sources.tar.gz').read_bytes()),
        prerequisite=pre,context_id=keys['context_id'],model_id=model['model_id'],io_workspace=str(root),io_workspace_identity=identity(root),
        request_readback=req,response_readback=resp,remaining_artifacts=remaining,
        worker_process=dict(returncode=0,process_reaped=True,public_key_store_removed=True,owned_directory_handle_closed=True,
            result=dict(passed=True,context_id=keys['context_id'],model_id=model['model_id'],public_batch_sha256=requests['public_batch_sha256'])))
    def save():
        write(evidence/'worker/worker_report.json',worker)
        report['worker_process']['result']['worker_report_sha256']=key_gate.digest((evidence/'worker/worker_report.json').read_bytes())
        write(evidence/'report.json',report);return key_gate.digest((evidence/'report.json').read_bytes())
    def check():return g.authenticate(evidence,save(),root,keys=keys,model=model,requests=requests)
    return NS(check=check,save=save,report=report,worker=worker,evidence=evidence,root=root,keys=keys,model=model,requests=requests,resp=resp,sample=sample,response=response)

def test_complete_synthetic_server_metadata_gate_no_payload_or_private_reads(case,monkeypatch):
    old=os.open;opened=[]
    def opening(path,*a,**kw):
        opened.append(str(path));assert not any(n in str(path) for n in ('ct_0.npz','bundle.json','client_private','requests.json','preprocessed'))
        return old(path,*a,**kw)
    monkeypatch.setattr(os,'open',opening)
    result=case.check();assert result['response_manifest_sha256']==case.resp['response_manifest_sha256']
    assert any('transport.json'in x for x in opened)

@pytest.mark.parametrize('flag',['passed','execute','actual_server_compute','actual_execution_attempted','all_processes_reaped',
    'external_workspaces_never_removed','operation_complete','cleanup_completed','terminal_scope_completed','source_files_unchanged','source_archive_verified','io_workspace_retained'])
def test_incomplete_actual_server_stops_before_private(case,flag):
    case.report[flag]=False
    with pytest.raises(ValueError,match='completed actual'):case.check()

@pytest.mark.parametrize('flag',['passed','actual_server_compute_started','actual_server_compute_completed','request_readback_complete',
    'response_readback_complete','source_files_unchanged','keygen_codecs_native_private_forbidden','terminal_scope_completed'])
def test_incomplete_worker_rejected(case,flag):
    case.worker[flag]=False
    with pytest.raises(ValueError,match='server-only'):case.check()

@pytest.mark.parametrize('flag',['process_reaped','public_key_store_removed','owned_directory_handle_closed'])
def test_worker_cleanup_explicit_success_required(case,flag):
    case.report['worker_process'][flag]=False
    with pytest.raises(ValueError,match='reaping'):case.check()

@pytest.mark.parametrize('field,value',[('level',1),('payload_bytes',1),('shape',[True,2,256,512,6]),('input_digest','0'*64),('scale',1.)])
def test_wrong_rehashed_response_summary_rejected(case,field,value):
    case.resp[field]=value
    with pytest.raises(ValueError,match='readback'):case.check()

def test_outer_external_hash_first(case,monkeypatch):
    case.save();old=g.key_gate.read;reads=[]
    def reading(path,*a):reads.append(Path(path));return old(path,*a)
    monkeypatch.setattr(g.key_gate,'read',reading)
    with pytest.raises(ValueError,match='external'):g.authenticate(case.evidence,'0'*64,case.root,keys=case.keys,model=case.model,requests=case.requests)
    assert reads==[case.evidence/'report.json']

def test_independent_actual_scale_guard_rejects_rehashed_bad_scale(case):
    case.response['responses'][0]['scale']=1.;write(case.root/'download/batch.json',case.response)
    with pytest.raises(ValueError,match='scale'):case.check()

def test_replacement_output_directory_rejected(case,tmp_path):
    (case.root/'download').rename(tmp_path/'retained');(case.root/'download').mkdir()
    with pytest.raises(ValueError,match='identity'):case.check()

def test_worker_source_drift_rejected(case):
    case.worker['source_hashes_end']=dict(case.worker['source_hashes_end'],extra='0'*64)
    with pytest.raises(ValueError,match='server-only'):case.check()
