from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace as NS
import ast
import pytest

@pytest.mark.parametrize('name',['worker.py','collect.py'])
@pytest.mark.parametrize('restore_failure',[False,True])
def test_intentional_exit_follows_termination_scope(name,restore_failure):
    path=Path(__file__).parent/name;node=ast.parse(path.read_text()).body[-1]
    assert isinstance(node,ast.If);failure=OSError('restore failure')
    @contextmanager
    def scope():
        primary=None
        try:yield
        except BaseException as e:primary=e
        if primary is not None:raise primary
        if restore_failure:raise failure
    class Parser:
        def add_argument(self,*a,**k):pass
        def parse_args(self):return NS()
    namespace=dict(__name__='__main__',Path=Path,argparse=NS(ArgumentParser=Parser),parser=Parser,
        termination_signals=scope,run=lambda **kw:0 if name=='worker.py' else {'passed':True})
    with pytest.raises(BaseException) as e:exec(compile(ast.Module(body=[node],type_ignores=[]),str(path),'exec'),namespace)
    if restore_failure:assert e.value is failure
    else:assert isinstance(e.value,SystemExit) and e.value.code==0
