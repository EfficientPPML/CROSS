"""Authenticated client reference metadata, with private reads as a later step."""
from pathlib import Path
import hashlib,io,json,os,stat,tarfile
import key_gate
FIXTURE_SHA='2218282c9d4ef468a448d00d6e7afeebc9c3a9fa0e9f3834227afe299ea28e10'
INPUT_SHA='c30ffc79d8150cf6cf3d544bca23a07150d8a0d0f7b7924788e91df3aa55991f'
CANDIDATE_SHA='4e2277beea7189aa1d77b168c500c8a175f6c630afa520fcc6b38cb5a179cff9'
CHECKPOINT_SHA='e1f8085ef673c9eb8a1a93a84270742e8aa0ccbceadef01eef15e26c44b46034'

def public_metadata(evidence,expected_report_sha256):
    evidence=Path(evidence);raw=key_gate.read(evidence/'report.json')
    if key_gate.digest(raw)!=key_gate.sha_field(expected_report_sha256):raise ValueError('external completed client-reference report differs')
    r=key_gate.parse(raw)
    flags=('passed','approximate_complete','source_files_unchanged','source_archive_verified','assets_unchanged','original_fixture_unchanged',
           'no_jax_or_he_modules_loaded','private_workspace_retained','private_reference_permissions_0600','prediction_agreement_official_fp32')
    if any(r.get(n)is not True for n in flags) or r.get('error') or r.get('cleanup_errors'):
        raise ValueError('complete successful client reference required')
    if (r.get('schema')!='bert-size0-client-reference-v1' or r.get('fixture_report_sha256')!=FIXTURE_SHA
            or r.get('input_sha256')!=INPUT_SHA or r.get('candidate_sha256')!=CANDIDATE_SHA
            or type(r.get('record_count'))is not int or r['record_count']!=1
            or type(r.get('key_count'))is not int or r['key_count']!=32
            or r.get('official_native',{}).get('dtype')!='float32'
            or r.get('approximate_vs_official_fp32',{}).get('passed')is not True):raise ValueError('fixed size0 reference contract differs')
    before=r.get('source_hashes_before')
    if type(before)is not dict or len(before)!=23 or before!=r.get('source_hashes_after'):
        raise ValueError('complete unchanged reference source inventory required')
    source=key_gate.read(evidence/'sources.tar.gz',16<<20)
    if key_gate.digest(source)!=key_gate.sha_field(r.get('source_archive_sha256')):raise ValueError('reference source archive differs')
    with tarfile.open(fileobj=io.BytesIO(source)) as t:
        ms=t.getmembers()
        if len(ms)!=23 or len({m.name for m in ms})!=23 or any(not m.isfile() or m.size>8<<20 for m in ms) or sum(m.size for m in ms)>32<<20:
            raise ValueError('bounded exact reference source archive required')
        if {m.name:key_gate.digest(t.extractfile(m).read()) for m in ms}!=before:raise ValueError('reference archive bytes differ')
    root=Path(r['private_workspace']);path=Path(r['private_reference_path'])
    if not root.is_absolute() or path!=root/'references.json':raise ValueError('fixed absolute private reference path required')
    identity=r['private_workspace_identity']
    if type(identity)is not dict or set(identity)!={'device','inode'} or any(type(x)is not int for x in identity.values()):raise ValueError('private reference owner identity required')
    return dict(report_sha256=expected_report_sha256,source_archive_sha256=r['source_archive_sha256'],input_sha256=INPUT_SHA,
        fixture_report_sha256=FIXTURE_SHA,private_workspace=root,private_reference=path,identity=identity,
        private_reference_sha256=key_gate.sha_field(r['private_reference_sha256']))

def load_private(metadata,record):
    # Caller must finish completed key/model/input/server prerequisites first.
    root=metadata['private_workspace'];s=root.lstat()
    if not stat.S_ISDIR(s.st_mode) or stat.S_IMODE(s.st_mode)!=0o700 or {'device':s.st_dev,'inode':s.st_ino}!=metadata['identity']:
        raise ValueError('private reference owner identity differs')
    owner=None;fd=None;primary=None;failure=None
    try:
        owner=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
        held=os.fstat(owner)
        if {'device':held.st_dev,'inode':held.st_ino}!=metadata['identity']:raise ValueError('opened private owner differs')
        fd=os.open('references.json',os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=owner)
        state=os.fstat(fd)
        if not stat.S_ISREG(state.st_mode) or stat.S_IMODE(state.st_mode)!=0o600 or not 0<state.st_size<=65536:
            raise ValueError('bounded private0600 reference required')
        chunks=[];total=0
        while total<=65536:
            part=os.read(fd,65537-total)
            if not part:break
            chunks.append(part);total+=len(part)
        raw=b''.join(chunks)
        if len(raw)>65536:raise ValueError('private reference byte bound exceeded')
        current=root.lstat()
        if {'device':current.st_dev,'inode':current.st_ino}!=metadata['identity']:raise ValueError('private owner moved during read')
    except BaseException as error:primary=error;raise
    finally:
        for label,descriptor in (('private reference',fd),('private owner',owner)):
            if descriptor is None:continue
            try:os.close(descriptor)
            except BaseException as error:
                if primary is not None:primary.add_note(label+' descriptor close: '+repr(error))
                elif failure is None:failure=error
                elif not isinstance(error,Exception) and isinstance(failure,Exception):
                    error.add_note('earlier cleanup: '+repr(failure));failure=error
                else:failure.add_note(label+' descriptor close: '+repr(error))
        if primary is None and failure is not None:raise failure
    if key_gate.digest(raw)!=metadata['private_reference_sha256']:raise ValueError('private reference bytes differ')
    r=key_gate.parse(raw)
    expected={'schema','target_idx','input_sha256','fixture_report_sha256','candidate_sha256','checkpoint_sha256','original_positions',
        'native_fp32_logits','native_fp64_logits','independent_exact_fp64_logits','approximate_fp64_logits'}
    if type(r)is not dict or set(r)!=expected or r['schema']!='bert-size0-private-reference-v1':raise ValueError('exact private reference schema required')
    if type(r['target_idx'])is not int or r['target_idx']!=record.target_idx or r['input_sha256']!=INPUT_SHA or r['fixture_report_sha256']!=FIXTURE_SHA or r['candidate_sha256']!=CANDIDATE_SHA or r['checkpoint_sha256']!=CHECKPOINT_SHA:
        raise ValueError('private input/target/model reference binding differs')
    positions=[i for i,x in enumerate(record.attention_mask) if x]
    if len(positions)!=32 or r['original_positions']!=positions or any(type(x)is not int for x in r['original_positions']):raise ValueError('original input positions differ')
    from client_metrics import vector
    for name in expected:
        if name.endswith('_logits'):vector(r[name])
    return r
