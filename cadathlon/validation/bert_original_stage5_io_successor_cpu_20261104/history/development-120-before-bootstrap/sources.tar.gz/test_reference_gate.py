from pathlib import Path
from types import SimpleNamespace as NS
import hashlib,io,json,os,tarfile
import pytest
import reference_gate as g

@pytest.fixture
def case(tmp_path):
    private=tmp_path/'private';private.mkdir(mode=0o700)
    values=dict(schema='bert-size0-private-reference-v1',target_idx=17,input_sha256=g.INPUT_SHA,fixture_report_sha256=g.FIXTURE_SHA,
        candidate_sha256=g.CANDIDATE_SHA,checkpoint_sha256=g.CHECKPOINT_SHA,original_positions=list(range(32)),
        native_fp32_logits=[1.,2.],native_fp64_logits=[1.,2.],independent_exact_fp64_logits=[1.,2.],approximate_fp64_logits=[1.,2.])
    path=private/'references.json';path.write_bytes(g.key_gate.canonical(values));path.chmod(0o600);s=private.stat()
    meta=dict(private_workspace=private,private_reference=path,identity=dict(device=s.st_dev,inode=s.st_ino),private_reference_sha256=g.key_gate.digest(path.read_bytes()))
    return NS(meta=meta,values=values,record=NS(target_idx=17,attention_mask=(1,)*32+(0,)*96),path=path)

def test_private_binding_valid(case):assert g.load_private(case.meta,case.record)==case.values

@pytest.mark.parametrize('name,value',[('target_idx',18),('target_idx',True),('candidate_sha256','0'*64),('original_positions',[True]+list(range(1,32))),('native_fp32_logits',['1','2'])])
def test_rehashed_private_wrong_binding_fails(case,name,value):
    case.values[name]=value;case.path.write_bytes(g.key_gate.canonical(case.values));case.meta['private_reference_sha256']=g.key_gate.digest(case.path.read_bytes())
    with pytest.raises(ValueError):g.load_private(case.meta,case.record)

def test_permissions_checked(case):
    case.path.chmod(0o644)
    with pytest.raises(ValueError,match='0600'):g.load_private(case.meta,case.record)

def test_owner_replacement_rejected(case,tmp_path):
    root=case.meta['private_workspace'];root.rename(tmp_path/'moved');root.mkdir(mode=0o700)
    with pytest.raises(ValueError,match='owner identity'):g.load_private(case.meta,case.record)

def test_symlink_private_rejected(case,tmp_path):
    case.path.rename(tmp_path/'target');case.path.symlink_to(tmp_path/'target')
    with pytest.raises(OSError):g.load_private(case.meta,case.record)

@pytest.mark.parametrize('body_failure',[False,True])
def test_two_close_cancellation_priority(case,monkeypatch,body_failure):
    original=g.os.close;closes=[];cancel=KeyboardInterrupt('later cleanup')
    def close(fd):
        original(fd);closes.append(fd)
        if len(closes)==1:raise OSError('first cleanup')
        raise cancel
    monkeypatch.setattr(g.os,'close',close)
    if body_failure:
        primary=ValueError('body');monkeypatch.setattr(g.os,'read',lambda *a:(_ for _ in ()).throw(primary))
        with pytest.raises(ValueError) as e:g.load_private(case.meta,case.record)
        assert e.value is primary and len(primary.__notes__)==2
    else:
        with pytest.raises(KeyboardInterrupt) as e:g.load_private(case.meta,case.record)
        assert e.value is cancel and 'first cleanup'in cancel.__notes__[0]
    assert len(closes)==2

def test_external_report_pin_precedes_any_archive_or_private_read(tmp_path,monkeypatch):
    path=tmp_path/'report.json';path.write_bytes(b'{}');calls=[];old=g.key_gate.read
    def read(p,*a):calls.append(Path(p));return old(p,*a)
    monkeypatch.setattr(g.key_gate,'read',read)
    with pytest.raises(ValueError,match='external'):g.public_metadata(tmp_path,'0'*64)
    assert calls==[path]

@pytest.fixture
def public_case(case,tmp_path):
    e=tmp_path/'evidence';e.mkdir();source={f'source{i}.py':f'# {i}\n'.encode() for i in range(23)}
    with tarfile.open(e/'sources.tar.gz','w:gz') as tar:
        for n,v in source.items():info=tarfile.TarInfo(n);info.size=len(v);tar.addfile(info,io.BytesIO(v))
    expected={n:g.key_gate.digest(v) for n,v in source.items()}
    flags=('passed','approximate_complete','source_files_unchanged','source_archive_verified','assets_unchanged','original_fixture_unchanged',
        'no_jax_or_he_modules_loaded','private_workspace_retained','private_reference_permissions_0600','prediction_agreement_official_fp32')
    r=dict.fromkeys(flags,True)
    r.update(schema='bert-size0-client-reference-v1',fixture_report_sha256=g.FIXTURE_SHA,input_sha256=g.INPUT_SHA,
        candidate_sha256=g.CANDIDATE_SHA,record_count=1,key_count=32,official_native=dict(dtype='float32'),approximate_vs_official_fp32=dict(passed=True),
        source_hashes_before=expected,source_hashes_after=expected,source_archive_sha256=g.key_gate.digest((e/'sources.tar.gz').read_bytes()),
        private_workspace=str(case.meta['private_workspace']),private_reference_path=str(case.path),
        private_workspace_identity=case.meta['identity'],private_reference_sha256=case.meta['private_reference_sha256'])
    def check():
        raw=g.key_gate.canonical(r);(e/'report.json').write_bytes(raw)
        return g.public_metadata(e,g.key_gate.digest(raw))
    return NS(check=check,report=r,evidence=e,private=case)

def test_public_reference_metadata_without_private_reads(public_case,monkeypatch):
    old=g.key_gate.read
    def read(path,*args):
        assert public_case.private.meta['private_workspace'] not in Path(path).parents
        return old(path,*args)
    monkeypatch.setattr(g.key_gate,'read',read)
    r=public_case.check();assert r['private_reference_sha256']==public_case.private.meta['private_reference_sha256']

@pytest.mark.parametrize('name,value',[('passed',False),('record_count',True),('key_count',31),('candidate_sha256','0'*64),('official_native',dict(dtype='float64'))])
def test_rehashed_reference_contract_fails(public_case,name,value):
    public_case.report[name]=value
    with pytest.raises(ValueError):public_case.check()

def test_duplicate_reference_archive_member_fails(public_case):
    p=public_case.evidence/'sources.tar.gz'
    with tarfile.open(p,'r:gz') as tar:values=[(m.name,tar.extractfile(m).read()) for m in tar.getmembers()]
    with tarfile.open(p,'w:gz') as tar:
        for n,v in values+[values[0]]:m=tarfile.TarInfo(n);m.size=len(v);tar.addfile(m,io.BytesIO(v))
    public_case.report['source_archive_sha256']=g.key_gate.digest(p.read_bytes())
    with pytest.raises(ValueError,match='archive'):public_case.check()
