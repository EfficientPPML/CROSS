"""Completed stage3 gate: public metadata only, no private or payload reads.

The caller pins the final report after observing outer process reaping. Private
binding flags are producer attestations, never permission to reopen private data.
The separate transport readback validates all ciphertext bytes before the handler.
"""
from pathlib import Path
import math,stat
import key_gate
HERE=Path(__file__).resolve().parent


def _directory(path,identity):
    info=Path(path).lstat()
    if (type(identity)is not list or len(identity)!=2 or any(type(x)is not int for x in identity)
            or not stat.S_ISDIR(info.st_mode) or [info.st_dev,info.st_ino]!=identity):
        raise ValueError('retained stage3 public directory identity differs')


def authenticate(evidence,report_sha256,io_workspace,*,keys,model):
    evidence=Path(evidence);io_workspace=Path(io_workspace)
    raw=key_gate.read(evidence/'report.json')
    if key_gate.digest(raw)!=key_gate.sha_field(report_sha256):raise ValueError('externally pinned completed stage3 report differs')
    report=key_gate.parse(raw)
    flags=('passed','execute','actual_encryption','actual_execution_attempted','io_workspace_retained',
        'all_processes_reaped','cleanup_completed','terminal_scope_completed','source_files_unchanged','source_archive_verified',
        'operation_complete','external_key_workspace_never_removed')
    if type(report)is not dict or any(report.get(n)is not True for n in flags) or report.get('error') or report.get('cleanup_errors'):
        raise ValueError('completed actual stage3 terminal proof required')
    expected_raw=key_gate.read(HERE/'stage3_source_manifest.json',1<<20)
    dependencies=key_gate.parse(key_gate.read(HERE/'dependencies.json'))
    if key_gate.digest(expected_raw)!=dependencies['stage3_source_inventory_sha256']:
        raise ValueError('reviewed stage3 source inventory changed')
    expected=key_gate.parse(expected_raw)
    if type(expected)is not dict or len(expected)!=80:raise ValueError('exact reviewed stage3-v3 source closure required')
    if any(report.get(n)!=expected for n in ('source_hashes_start','source_hashes_end','execution_source_hashes_end')):
        raise ValueError('completed stage3 execution source differs')
    source=key_gate.read(evidence/'sources.tar.gz',16<<20)
    if key_gate.digest(source)!=key_gate.sha_field(report.get('source_archive_sha256')):raise ValueError('completed stage3 source archive digest differs')
    key_gate.verify_source_archive(source,expected)
    process=report.get('worker_process')
    if (type(process)is not dict or type(process.get('returncode'))is not int or process['returncode']!=0 or process.get('error')
            or any(process.get(n)is not True for n in ('process_reaped','public_key_store_removed','owned_directory_handle_closed'))):
        raise ValueError('completed stage3 worker reaping required')
    result=process.get('result')
    if type(result)is not dict or result.get('passed')is not True:raise ValueError('successful stage3 worker result required')
    worker_raw=key_gate.read(evidence/'worker/worker_report.json')
    if key_gate.digest(worker_raw)!=key_gate.sha_field(result.get('worker_report_sha256')):raise ValueError('stage3 worker report linkage differs')
    worker=key_gate.parse(worker_raw)
    worker_flags=('passed','actual_client_encode_started','actual_client_encode_completed','readback_complete',
        'all_eight_ordered_payloads_validated','source_files_unchanged','keygen_decrypt_native_model_forbidden','terminal_scope_completed')
    if (type(worker)is not dict or any(worker.get(n)is not True for n in worker_flags) or worker.get('error') or worker.get('forbidden_attempts')
            or any(worker.get(n)is not False for n in ('decrypt','model_forward','server_compute'))
            or any(worker.get(n)!=expected for n in ('source_hashes_start','source_hashes_end'))):
        raise ValueError('complete stage3 worker/source/terminal proof required')
    prerequisite={n:keys[n] for n in ('context_id','key_report_sha256','key_source_archive_sha256')}|{
        n:model[n] for n in ('model_id','model_report_sha256','model_manifest_sha256')}
    for proof in (report,worker):
        bound=proof.get('prerequisite')
        if type(bound)is not dict or any(bound.get(n)!=v for n,v in prerequisite.items()):raise ValueError('stage3 predecessor identity differs')
    if worker['prerequisite']!=report['prerequisite']:raise ValueError('stage3 input prerequisite binding differs')
    import server_public_model
    assets={'model.safetensors':server_public_model.CHECKPOINT_SHA256,'config.json':server_public_model.CONFIG_SHA256}
    if any(obj.get(name)!=assets for obj in (report,worker) for name in ('asset_hashes_start','asset_hashes_end')):
        raise ValueError('fixed stage3 public embedding asset identities differ')
    for proof in (report,worker,result):
        if proof.get('context_id')!=keys['context_id'] or proof.get('model_id')!=model['model_id']:raise ValueError('stage3 context/model identity differs')
    if report.get('io_workspace')!=str(io_workspace):raise ValueError('stage3 retained I/O path differs')
    _directory(io_workspace,report.get('io_workspace_identity'));upload=io_workspace/'upload'
    if report.get('upload')!=str(upload):raise ValueError('stage3 retained upload path differs')
    _directory(upload,report.get('upload_identity'))
    readback=worker.get('readback')
    if (type(readback)is not dict or readback!=report.get('readback') or type(readback.get('sample_count'))is not int
            or readback['sample_count']!=1 or type(readback.get('tile_count'))is not int or readback['tile_count']!=8
            or any(readback.get(n)is not True for n in ('private_binding_verified','private_request_permissions_verified'))
            or readback.get('private_input_sha256')!=report['prerequisite'].get('input_sha256')):
        raise ValueError('completed strict size0/private binding attestation required')
    from file_stage_io import read_manifest
    from transport_contract import digest,ciphertext_contract
    from transport import _validate_manifest,manifest_digest,request_digest
    import file_stage_contract as batches,file_stages
    manifest=read_manifest(Path(model['server_data'])/keys['context_id']/'model_manifest.json')
    if digest(manifest)!=model['model_manifest_sha256']:raise ValueError('retained model metadata changed')
    public=file_stages._public(keys['public_manifest'],manifest)
    batch=batches.validate_public_batch(read_manifest(upload/'batch.json'),public=public,count=1);actual=digest(batch)
    if any(obj.get('public_batch_sha256')!=actual for obj in (report,result,readback)):raise ValueError('stage3 retained public batch digest differs')
    request=batch['requests'][0];nonce=request['contract']['request_id'];sample=upload/nonce
    if request['input_digest']!=readback.get('input_digest'):raise ValueError('stage3 ordered ciphertext digest differs')
    if ({p.name for p in upload.iterdir()}!={nonce,'batch.json'} or not stat.S_ISDIR(sample.lstat().st_mode)
            or {p.name for p in sample.iterdir()}!={f'tile{i}' for i in range(8)}):raise ValueError('exact stage3 sample/tile directory inventory required')
    rows=readback.get('tiles');p=keys['public_manifest']['parameters'];shape=[1,2,*p['degree_layout'],len(p['q_towers'])];payload_bytes=math.prod(shape)*4
    if (type(rows)is not list or len(rows)!=8 or any(type(row)is not dict or set(row)!={'tile','payload_bytes','shape','scale','manifest_sha256'}
            or type(row['tile'])is not int or row['tile']!=i or type(row['payload_bytes'])is not int or row['payload_bytes']!=payload_bytes
            or type(row['shape'])is not list or any(type(x)is not int for x in row['shape'])
            or row['shape']!=shape or type(row['scale'])is not float or row['scale']!=p['scaling_factor'] for i,row in enumerate(rows))
            or type(readback.get('ciphertext_payload_bytes'))is not int or readback['ciphertext_payload_bytes']!=8*payload_bytes):
        raise ValueError('completed all-eight canonical request metadata differs')
    manifests=[]
    for i,row in enumerate(rows):
        directory=sample/f'tile{i}'
        if not stat.S_ISDIR(directory.lstat().st_mode) or {p.name for p in directory.iterdir()}!={'transport.json','bundle.json','ct_0.npz'}:
            raise ValueError('exact request container inventory required')
        bound=ciphertext_contract(request['contract'],'request',i,None,None)
        transport=_validate_manifest(read_manifest(directory/'transport.json'),bound)
        if manifest_digest(transport)!=key_gate.sha_field(row['manifest_sha256']):raise ValueError('stage3 ordered transport metadata differs')
        manifests.append(transport)
    if request_digest(manifests,request['contract'])!=request['input_digest']:raise ValueError('ordered public transport manifest digest differs')
    return dict(context_id=keys['context_id'],model_id=model['model_id'],upload=upload,stage3_report_sha256=report_sha256,
        public_batch_sha256=actual,input_digest=request['input_digest'],tiles=rows)
