from pathlib import Path
from contextlib import contextmanager
from types import SimpleNamespace as NS
import json,sys
import pytest
import collect as c

@pytest.fixture
def case(tmp_path,monkeypatch):
    monkeypatch.setenv('JAX_PLATFORMS','cpu');events=[];fail={};owners=[]
    dirs={n:tmp_path/n for n in ('keys','model','io','ke','me','se','server','fixture','reference','fixture_private','reference_private')}
    for p in dirs.values():p.mkdir()
    (dirs['keys']/'sentinel').write_bytes(b'untouched')
    auth=(dict(context_id='c'*64,public_keys=dirs['keys']/'public_keys',key_report_sha256='1'*64,key_source_archive_sha256='2'*64),
        dict(model_id='m'*64,model_report_sha256='3'*64,model_manifest_sha256='4'*64),
        dict(stage3_report_sha256='5'*64,public_batch_sha256='b'*64,input_digest='d'*64),
        dict(stage4_report_sha256='6'*64),dict(input_sha256='i'*64,fixture_report_sha256='f'*64,preprocessed_input=tmp_path/'input'),
        dict(report_sha256='r'*64,source_archive_sha256='a'*64,private_workspace=dirs['reference_private']))
    raw={'worker.py':b'# mock\n','marker.py':b'# fixed\n','runtime/stage/server_inputs/p60_profile_and_refresh.json':b'{}',
         'runtime/stage/server_inputs/twelve_layer_plan.json':b'{}'}
    monkeypatch.setattr(c,'sources',lambda:dict(raw));monkeypatch.setattr(c.dependencies,'check',lambda:{'ready':True})
    monkeypatch.setattr(c.reference_gate,'public_metadata',lambda *a:auth[-1])
    monkeypatch.setattr(c,'fixture_private',lambda *a:dirs['fixture_private'])
    monkeypatch.setattr(c.process,'software_versions',lambda:{'mock':True})
    def authenticate(**kw):
        events.append('gates')
        if fail.get('gate'):raise fail['gate']
        return auth
    monkeypatch.setattr(c.worker,'authenticate',authenticate)
    monkeypatch.setattr(c.worker,'fresh_paths',lambda *a:None)
    monkeypatch.setitem(sys.modules,'file_stages',NS(MODEL_ID='fixed',REVISION='pinned'))
    old=c.BorrowedDirectory
    class Borrowed(old):
        def __init__(self,*a,**k):super().__init__(*a,**k);owners.append(self)
        def close(self):
            events.append('close');super().close()
            errors=fail.get('closes',[])
            if errors:raise errors.pop(0)
    monkeypatch.setattr(c,'BorrowedDirectory',Borrowed)
    def mkdtemp(**kw):
        p=tmp_path/'new_private';p.mkdir(mode=0o700);return str(p)
    monkeypatch.setattr(c.tempfile,'mkdtemp',mkdtemp)
    def launch(command,directory,**kw):
        events.append('launch');assert kw==dict(timeout=None,cleanup_grace_s=120.)
        assert Path(command[1]).parent.name=='execution_source'
        if fail.get('launch'):raise fail['launch']
        before=c.hashes(raw);passed=not fail.get('numeric',False)
        rb=dict(sample_count=1,public_batch_sha256='b'*64,private_receipt_validated=True,result_permissions_0600=True,
            metrics=dict(passed=passed,original_P2_logit_gate=passed,prediction_agreement=True))
        proof=dict(passed=passed,operation_complete=True,actual_client_decode_started=True,actual_client_decode_completed=True,
            readback_complete=True,source_files_unchanged=True,keygen_encrypt_native_server_forbidden=True,
            terminal_scope_completed=True,external_workspaces_never_removed=True,keygen=False,encryption=False,
            server_compute=False,model_forward=False,forbidden_attempts=[],source_hashes_start=before,source_hashes_end=before,
            prerequisite=c.worker.prerequisite_summary(*auth),reviewed_dependencies={'ready':True},readback=rb,elapsed_s=1.)
        proof.update(fail.get('proof',{}));c.write(directory/'worker_report.json',proof)
        record=dict(returncode=0 if passed else 1,process_reaped=True,public_key_store_removed=True,owned_directory_handle_closed=True,
            result=dict(passed=passed,operation_complete=True,worker_report_sha256=c.process.sha256(directory/'worker_report.json')))
        if not passed:record['error']='runner exited 1; see stderr.log'
        record.update(fail.get('process',{}));c.write(directory/'process.json',record)
        if fail.get('source'):raw['marker.py']=b'# changed\n'
        return record
    monkeypatch.setattr(c.process,'run_case',launch)
    args=dict(output=tmp_path/'evidence',key_evidence=dirs['ke'],key_report_sha256='1'*64,key_workspace=dirs['keys'],
        model_evidence=dirs['me'],model_report_sha256='3'*64,model_workspace=dirs['model'],stage3_evidence=dirs['se'],
        stage3_report_sha256='5'*64,stage4_evidence=dirs['server'],stage4_report_sha256='6'*64,io_workspace=dirs['io'],
        fixture_evidence=dirs['fixture'],fixture_report_sha256='f'*64,reference_evidence=dirs['reference'],reference_report_sha256='r'*64,execute=True)
    return NS(args=args,dirs=dirs,events=events,fail=fail,owners=owners,raw=raw)

def report(case):return json.loads((case.args['output']/'report.json').read_text())
def test_success_retains_private_and_external_paths(case):
    r=c.run(**case.args)
    assert r['passed'] and r['actual_client_decode'] and r['terminal_scope_completed'] and r['private_result_workspace_retained']
    assert case.events[:3]==['gates','launch','gates'] and all(o.fd is None for o in case.owners)
    assert (case.dirs['keys']/'sentinel').read_bytes()==b'untouched'
    assert Path(r['private_result_workspace']).stat().st_mode&0o777==0o700

def test_numeric_failure_retains_complete_failed_result(case):
    case.fail['numeric']=True;r=c.run(**case.args)
    assert not r['passed'] and r['operation_complete'] and r['cleanup_completed'] and r['terminal_scope_completed']
    assert r['actual_client_decode'] and r['private_result_workspace_retained'] and not r.get('error')

def test_preflight_does_not_launch_or_create_private_output(case):
    case.args['execute']=False;r=c.run(**case.args)
    assert r['passed'] and not r['actual_client_decode'] and 'launch'not in case.events
    assert 'private_result_workspace'not in r

@pytest.mark.parametrize('where',['keys','model','io','fixture_private','reference_private'])
@pytest.mark.parametrize('alias',[False,True])
def test_output_containment_before_writes(case,tmp_path,where,alias):
    root=case.dirs[where]
    if alias:
        p=tmp_path/'alias';p.symlink_to(root,target_is_directory=True);root=p
    case.args['output']=root/'forbidden'
    with pytest.raises(ValueError,match='outside'):c.run(**case.args)
    assert not case.args['output'].exists() and not case.events

def test_pending_dependency_before_gates(case,monkeypatch):
    monkeypatch.setattr(c.dependencies,'check',lambda:(_ for _ in ()).throw(RuntimeError('pending')))
    with pytest.raises(RuntimeError,match='pending'):c.run(**case.args)
    assert not case.events and not report(case)['passed']

def test_failed_server_gate_precedes_private_output_and_launch(case):
    case.fail['gate']=ValueError('server pending')
    with pytest.raises(ValueError,match='pending'):c.run(**case.args)
    assert case.events==['gates'] and not case.owners

@pytest.mark.parametrize('field',['terminal_scope_completed','readback_complete','keygen_encrypt_native_server_forbidden'])
def test_incomplete_worker_cannot_pass(case,field):
    case.fail['proof']={field:False}
    with pytest.raises(ValueError,match='complete client'):c.run(**case.args)
    assert not report(case)['passed'] and report(case)['private_result_workspace_retained']

def test_source_drift_fails_after_completed_operation(case):
    case.fail['source']=True;r=c.run(**case.args)
    assert not r['passed'] and not r['source_files_unchanged'] and r['private_result_workspace_retained']

def test_primary_cancel_unknown_process_retains_everything(case):
    primary=KeyboardInterrupt('primary');case.fail['launch']=primary
    with pytest.raises(KeyboardInterrupt) as e:c.run(**case.args)
    assert e.value is primary and not report(case)['all_processes_reaped']
    assert report(case)['private_result_workspace_retained'] and all(o.fd is None for o in case.owners)

def test_cleanup_only_later_cancel_has_precedence_and_all_close(case):
    case.fail['closes']=[OSError('first'),KeyboardInterrupt('later')]
    with pytest.raises(KeyboardInterrupt,match='later'):c.run(**case.args)
    r=report(case);assert not r['passed'] and not r['terminal_scope_completed'] and not r['cleanup_completed']
    assert all(o.fd is None for o in case.owners) and len(r['cleanup_errors'])==2

def test_missing_archive_write_preserves_failed_report(case,monkeypatch):
    monkeypatch.setattr(c,'archive',lambda *a:(_ for _ in ()).throw(OSError('archive')))
    with pytest.raises(OSError,match='archive'):c.run(**case.args)
    assert not report(case)['passed'] and not case.events

@pytest.mark.parametrize('has_primary',[False,True])
@pytest.mark.parametrize('cancel',[False,True])
def test_cleanup_scope_exit_cannot_publish_success(case,monkeypatch,has_primary,cancel):
    primary=ValueError('body primary') if has_primary else None
    if primary is not None:case.fail['gate']=primary
    failure=KeyboardInterrupt('scope exit') if cancel else OSError('scope exit');seen=[]
    @contextmanager
    def shield():
        yield
        seen.append(1)
        if len(seen)==1:raise failure
    monkeypatch.setattr(c,'cleanup_signals',shield)
    with pytest.raises(BaseException) as e:c.run(**case.args)
    assert e.value is (primary if primary is not None else failure)
    r=report(case);assert not r['passed'] and not r['terminal_scope_completed'] and not r['cleanup_completed']
