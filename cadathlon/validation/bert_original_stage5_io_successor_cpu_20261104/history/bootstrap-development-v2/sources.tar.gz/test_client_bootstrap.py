"""Fresh isolated actual CLI canaries; no services/context/private data."""
from pathlib import Path
import json,os,subprocess,sys,hashlib,pytest
import client_source_guard as g
HERE=Path(__file__).resolve().parent

@pytest.fixture
def tree(tmp_path):
 root=tmp_path/'source';root.mkdir();raw=g.raw_sources()
 for n,b in raw.items():p=root/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 expected=g.io.hashes(raw);manifest=tmp_path/'manifest.json';manifest.write_text(json.dumps(expected,sort_keys=True))
 return root,manifest,expected,tmp_path/'canary'

def run(tree,entry,*,digest=None,preload=None):
 root,manifest,expected,canary=tree;args=[str(root/entry),'--source-manifest',str(manifest),'--source-manifest-sha256',digest or hashlib.sha256(manifest.read_bytes()).hexdigest(),'--help']
 if preload:
  code="import sys,types,runpy;sys.modules[%r]=types.SimpleNamespace(__file__='/wrong/source.py');sys.argv=%r;runpy.run_path(sys.argv[0],run_name='__main__')"%(preload,args)
  command=[sys.executable,'-I','-c',code]
 else:command=[sys.executable,'-I',*args]
 return subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=30,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})

@pytest.mark.parametrize('entry',['original_client_worker.py','original_client_collect.py'])
@pytest.mark.parametrize('helper',['key_gate.py','client_io.py','client_source_guard.py'])
def test_changed_helper_never_executes(tree,entry,helper):
 root,manifest,expected,canary=tree
 (root/helper).write_text("from pathlib import Path\nPath(%r).write_text('executed')\n"%str(canary))
 p=run(tree,entry)
 assert p.returncode!=0 and not canary.exists()
 assert 'before local imports'in p.stderr or 'externally bound source differs'in p.stderr

@pytest.mark.parametrize('entry',['original_client_worker.py','original_client_collect.py'])
def test_valid_bootstrap_help_does_no_actual_work(tree,entry):
 p=run(tree,entry);assert p.returncode==0,p.stderr
 assert '--source-manifest-sha256'in p.stdout and not tree[3].exists()

@pytest.mark.parametrize('entry',['original_client_worker.py','original_client_collect.py'])
def test_wrong_external_digest_before_import(tree,entry):
 p=run(tree,entry,digest='0'*64);assert p.returncode!=0 and 'digest differs before local imports'in p.stderr

@pytest.mark.parametrize('mutation',['missing','extra'])
def test_malformed_source_inventory_rejected_before_import(tree,mutation):
 root,manifest,expected,canary=tree
 if mutation=='missing':expected.pop('key_gate.py')
 else:expected['extra.py']='0'*64
 manifest.write_text(json.dumps(expected));p=run(tree,'original_client_collect.py')
 assert p.returncode!=0 and 'exact explicit successor source inventory'in p.stderr

@pytest.mark.parametrize('module',['client_io','key_gate'])
def test_preloaded_wrong_origin_rejected_before_local_import(tree,module):
 p=run(tree,'original_client_collect.py',preload=module)
 assert p.returncode!=0 and 'already loaded before fresh source gate'in p.stderr


@pytest.mark.parametrize('kind',['symlink','fifo'])
def test_nonregular_external_manifest_rejected_before_read(tree,kind):
 root,manifest,expected,canary=tree;old=manifest.with_name('original.json');manifest.rename(old)
 if kind=='symlink':manifest.symlink_to(old)
 else:os.mkfifo(manifest)
 p=run(tree,'original_client_collect.py',digest=hashlib.sha256(old.read_bytes()).hexdigest())
 assert p.returncode!=0 and not canary.exists()
