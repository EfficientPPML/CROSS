"""Run only after parent releases CPU work; preserve exact isolated sources."""
import os,sys,json,time,hashlib,resource,platform
from pathlib import Path
LAB=Path(__file__).resolve().parent
assert os.environ.get('JAX_PLATFORMS')=='cpu'
sys.path[:0]=[str(LAB),str(LAB/'runtime'),str(LAB/'runtime/common')]
os.environ['CROSS_TEST_CHUNKED_SECURE']='1'
os.chdir(LAB)
def hashes():
 return {str(p.relative_to(LAB)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(LAB.rglob('*.py')) if '__pycache__' not in p.parts}
before=hashes();started=time.monotonic();records=[]
class Recorder:
 def pytest_runtest_logreport(self,report):
  if report.when=='call' or (report.when=='setup' and report.outcome!='passed'):
   records.append(dict(nodeid=report.nodeid,outcome=report.outcome,seconds=report.duration))
import pytest
code=int(pytest.main(['-q','--tb=short','tests/test_chunked_linear.py','tests/test_secure_chunked_linear.py'],plugins=[Recorder()]))
after=hashes()
import chunked_linear,encrypted_packed_transformer,encrypted_bounded_transformer
from jaxite_word import ckks_ctx
origins={m.__name__:str(Path(m.__file__).resolve()) for m in (chunked_linear,encrypted_packed_transformer,encrypted_bounded_transformer,ckks_ctx)}
assert all(Path(p).is_relative_to(LAB) for p in origins.values())
result=dict(passed=code==0 and before==after,pytest_exit_code=code,seconds=time.monotonic()-started,
 source_sha256=before,source_sha256_after=after,source_files_unchanged=before==after,
 module_origins=origins,tests=records,affinity=sorted(os.sched_getaffinity(0)),python=platform.python_version(),
 max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
 scope='Isolated bounded giant-group scheduling; component numerical tests only, no TPU or full graph claim')
(LAB/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('source_sha256','source_sha256_after','tests','module_origins')}),flush=True)
raise SystemExit(0 if result['passed'] else 1)
