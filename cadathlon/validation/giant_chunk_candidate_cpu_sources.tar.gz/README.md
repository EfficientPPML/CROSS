# Isolated giant-group scheduling candidate

Status: implementation and test preparation only. No tests, benchmarks, or
production integration have been run. Await root's post-calibration CPU release.

The candidate retains existing within-group arithmetic and group accumulation
order. It computes a bounded number of independent giant inner sums before
rotating/adding them. Bias remains a single operation after accumulation.
BoundedPackedTransformer's existing semantic wrapper is retained through MRO.

The queue contains at most `min(groups, 8, 1 + floor(256MiB / output_bytes))`
outputs. `output_bytes` is public batch/components/degree/output-Q-limbs/dtype
payload size. Thus additional pending payload beyond the singleton baseline
is at most 256MiB, including first-group identity rotations. If one payload is
larger than the allowance, the schedule remains singleton. Symbolic planners
without physical payload metadata also use singleton scheduling.

This is not a total-HBM bound: input babies, accumulator, rotation/PTCT/rescale
controls, live NTT contexts, plaintexts, and primitive working buffers already
exist outside this queue. Same-level completed outputs use the existing weak
NTT sharing mechanism. Secure tests must verify that sharing rather than assume
that payload capping alone controls all memory.

Validation planned: exact ciphertext residues, scale/NSD/moduli, masked public
linear maps, zero/bias-only maps, original reduction order, bounded metadata,
actual peak queue references at chunk boundaries, singleton fallback and public
byte accounting. Measure cache-clear/compile/control-build counts separately
from optional CPU timings. No full-model or TPU speed claim is justified.
