from pathlib import Path
import json,hashlib,subprocess,sys,os,tarfile,xml.etree.ElementTree as ET
P=Path('/tmp/bert-prepared-bsgs-compatibility-plan-20261103');O=P/'final-public-tests';O.mkdir()
measurement=json.loads((P/'actual-v2/report.json').read_bytes());before=measurement['source_hashes_before'];own=Path(__file__).resolve()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(P/n)==h for n,h in before.items())
with tarfile.open(O/'sources.tar.gz','w:gz')as t:
 for n in before:t.add(P/n,arcname=n)
 t.add(own,arcname='external/check.py')
allhash=before|{'external/check.py':sha(own)}
env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
with (O/'tests.log').open('w')as log:
 process=subprocess.Popen([sys.executable,'-m','pytest','--rootdir='+str(P),'--confcutdir='+str(P),'-q','test_public_audit.py','--junitxml='+str(O/'tests.xml')],cwd=P,env=env,stdout=log,stderr=subprocess.STDOUT)
 code=process.wait()
cases=list(ET.parse(O/'tests.xml').getroot().iter('testcase'));bad=sum(len(c.findall(k))for c in cases for k in ('failure','error','skipped'))
with tarfile.open(O/'sources.tar.gz','r:gz')as t:archive={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest()for m in t.getmembers()}
after={n:sha(P/n)for n in before}|{'external/check.py':sha(own)}
report=dict(passed=code==0 and len(cases)==15 and bad==0 and allhash==after==archive,child_pid=process.pid,returncode=code,reaped=True,tests=len(cases),bad=bad,source_hashes_before=allhash,source_hashes_after=after,source_archive_sha256=sha(O/'sources.tar.gz'),source_archive_verified=archive==allhash,scope='15 public/synthetic tests;39proofsources=38audit+externaldriver; no retained tensor reread')
(O/'report.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps({k:report[k]for k in ['passed','tests','bad','source_archive_sha256']}));raise SystemExit(0 if report['passed']else 1)
