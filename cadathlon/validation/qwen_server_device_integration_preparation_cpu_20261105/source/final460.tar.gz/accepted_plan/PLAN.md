# Focused full28 device403 integration proof architecture — source only

Target exact held403 at /tmp/qwen-server-device-integration-runtime-v4-20261104.
Its only code change from402 is the pure native open-flags policy; source inventory
and one explicit history record are the other changes. The immutable402 statistics
and corrected401 owner remain exact. Root source receipt c4da90ac admits only this
source delta; it is not a run grant. Exact map/archive pins are in scope.json.

The complete prior49-node plan is preserved under history/plan402, including its
401 draft. All49 original node rows, ordering, oracles and seams are unchanged.
Ten appended pure flag-policy cases yield59 prospective fresh children. This plan
authors no fixture, executable test or enclosing harness. The predecessor400,
device6 and completed30/36 proofs remain separate historical evidence, with no
inherited PASS or collection claim.

The proof would establish conditional Python ownership, admission ordering and
failure behavior under explicit source-owned recordings. It cannot establish
native compatibility, a lease, current capacity, real key/model/CT authentication,
numerical accuracy or an actual full28 run. Native acquire/check/synchronize and
entry readiness remain unchanged and denied in target403. Positive owner cases
use explicitly recorded native effects; one control retains the original denial.

## Source and import selection

A future test successor nests exact403 under runtime/ and adds only reviewed
fixture/child/parent/test metadata. Parent and enclosing collector authenticate
that complete map/archive, and pytest collects exactly the proposed node list
before any fixture executes. No inherited test directory is collected.

Each case is a new isolated -I -B child with pytest autoload disabled in its
parent, fixed reviewed CPU lane112–115, sanitized environment and no healthy
wall-clock cutoff. The child verifies exact403 and the complete new source map
before loading a selected local definition. A fixed finder/audit denies genuine
NumPy/JAX/JAXLIB/libtpu/plugin/core/numerical model imports, device/native dlopen,
network/process creation after its own launch, and all existing model/key/CT/
private/token/calibration roots. Target cases select no /dev, /proc, /sys or real capacity reads. Direct
proc-path policy checks below do not open them. Separately declared harness-only
ownership evidence may read only original owned child /proc/PID/stat metadata
for startticks; it is not a host capacity or device observation.

Keep the real process, backend declarations, DeviceOwner, selected device controller,
DevicePacket, snapshot/control, selected loader/stage/engine bodies, shared
Finalizer/cleanup and terminal_status. The required local closure is derived
from actual constructor-facing imports, with an explicit selected helper map;
no package-wide discovery or whole-module origin stamping is allowed. All
loaded real modules must have genuine matching __file__/__spec__.origin under
the selected runtime root. The literal29 snapshot-binding source names remain
unchanged and hash-checked.

For owner initialization only, load a new source-owned recording_jax.py under
the temporary name jax using its actual file/spec/hash. It provides tiny Array,
Device, configuration/default-device context, enumeration and method counters;
it is not an installed backend. The synthetic allocator document pins that exact
owned source file. Do not copy the device50 recording process module: the five
qwen_server_process hooks must remain the exact original top-level default-free,
closure-free functions and dispatch through their original _DEVICE_HOOK tuple.
An empty owned numpy ModuleType may be installed only for definitions that need
it (reader/composition constructors); it has no fake runtime source origin and
cannot satisfy an ndarray or numeric operation. No jax.numpy submodule discovery
or genuine _runtime_dependencies/_materialize execution is allowed.

The original _capture_snapshot requires __main__ to be the exact entry source
file with specNone. A child launched from a test script cannot satisfy this
honestly as a genuine CLI. Use the reviewed definition-only fixture: parse exact
entry AST, exclude only the known final `if __name__ == '__main__': raise
SystemExit(main())` node, execute the remaining definitions with the original
entry filename, and temporarily expose that module as __main__. Preserve exact
AST exclusion/provenance. Original snapshot/origins/terminal functions stay
unchanged. This proves those functions under an explicit main-module fixture;
it makes no real bootstrap, CLI readiness or actual launch claim. Restore the
original test main module during child cleanup.

## Seam groups and real code retained

Seams are installed before source snapshot/owner capture and individually named
with original owner, export, hash, installation/restoration time and case group.
Intentional mutation cases are separate from fixture seams. Never pass private
retention keywords to bypass default-captured original functions. Callback
arguments requiring FunctionType use named plain local delegates, not bound
fixture methods; this preserves the prior404 setup failure lesson.

P — public policy/sidecar: use real DevicePacket.inspect/authenticate_packet,
qwen_device_policy.authenticate, qwen_server_resource.authenticate_policy and
logical_facts. Adapt the source-only synthetic device50 document builder, updating
the402 resource COVERAGE/PUBLIC_METADATA_SOURCE_FLOOR requirements and the403
required native flags described below. Historical device50 open_flags=0 must not
be reused as a clean fixture.
Exactly ServerPhaseAdmission.check and ExpectedServerPhasePins.check are recording
methods. Public geometry/keys remain descriptor metadata, with no payloads.
Profile actual validator/code calls using original code objects, then restore the
profile observer. No whole resource/device validator is replaced.

O — original owner/device controller: retain real DeviceOwner.create/actions,
all five process hooks, selected controller issuance/observations and original selected
snapshot binding where applicable. Before capture, explicitly record only
native.acquire/check/synchronize, install_core/Core.load, owner hash_installed/
imported_origins and genuine-host observation effects. The recorded lease is an
exact source type with a conspicuous synthetic marker and no hardware authority.
Original native-denial case replaces none of acquire/check/synchronize and must
reject before core/JAX/default-scope/key/body entry. Real original owner methods
and returned arrays are used throughout; never write owner/permit registries to
simulate a stage. Positives drive the valid registration/evaluation/terminal
methods in order. Inspect private registries only to assert retention/status;
never reset _ISSUED, clear quarantines or recycle failed capabilities.

S — original scientific snapshot/control: construct all13 original immutable
scientific graph types with explicit unadmitted marker bytes. PublicContract's
constructor bypass is declared. Recording ServerPacket.check and the guard's
_FULL_PACKET_CHECK must be the same counter function. The two phase check
methods and GeneratedKeyReadiness.expected_ids are recordings; original phase
expected_ids/input_digest derivation, _capture_snapshot, runtime/control,
backend checks and source/origin callbacks remain real. Use real exact file reads
for selected source and new tiny public fixture records. This is not a full
scientific/model/key proof. No whole source-stamped selected module is replaced.

L — actual-only loader path: use original _load_selected/_admit_selected and exact
ActualServerDependencies with the real constructor/check path where possible.
Record actual read_public/map_array/ReadDirectory/security/context/native transfer
effects using335 descriptors, not335 physical arrays. Four tiny setup transfer
returns (two asarray and two transpose) are source-owned Array objects. The
original Context constructor/initialization/keyless/disposal call shapes are
recorded; no CKKSContext or core is imported. Only exact fake FD/names may use
recorded terminal os.stat/os.listdir; everything else forwards to the original
or denies. Record all mapping/transfer/context/patch cleanup. Assert registration
before yield and key/body transition; failures release the original serial lock
and attempt cleanup without losing original transfers. RecordingDependencies
None behavior remains a separate control. Do not claim all166 formatted pairs or
unreturned native/NTT work are covered by those four returns.

E — stage/engine boundary: retain actual _server_selected, actual factory callback
capture, BorrowedServerEngine.__init__/_check/run and Finalizer. Use declared
recording request/parameter/public admission/ParameterCatalog/_full_contract and
numerical constructor seams only; return exact Dependencies with tiny recorded
ciphertext-shaped objects. Original metadata/snapshot/identity methods are used
where their contract applies to the recording objects. No _materialize or actual
numerical owner runs. Recorded full owner returns38 tiny objects with declared
metadata, not valid RNS bodies. Assert post_keys before RequestFiles/body entry,
original owner/prepared capture before before_evaluation, and callback immediately
before evaluate. Positive None recording behavior is preserved. Callback failure
must stop evaluation/publication and enter real original cleanup/quarantine.

A — genuine audit/wrapper on owned files: use real AccessScope constructor and
methods with exact typed synthetic public profile/phase/store metadata; list any
additional PublicContract.profile/model-store/profile-check recordings separately.
No current store metadata or body is read. Native scope uses an actual issued
DeviceOwner from O. Its policy's device node may name a tiny newly owned regular
fixture solely for this explicit stat seam. Replace lstat/fstat only when path or
FD equals that exact owned fixture, returning declared synthetic character-device
mode/rdev. Original os.open/close remain real; opened-FD mismatch must close the
original descriptor once. No real /dev node is opened and no success is called a
native device test. Negative attempts only open then close on unexpected success;
they never read an unselected target. Protected-body and own-proc policies are
checked by access()/literal helper directly without opening those paths. Every
audit child retires its original wrapper then exits because audit hooks cannot
be unregistered.

R — process/finalizer orchestration: retain original process.run, _runtime,
snapshot, owner, terminal_status and Finalizer. Use O/S and named recordings for
public admit, audit constructor where not A, public key binding/files, backend/
stage body and signal scopes. The stage recording drives owner registration,
post_keys, pre_evaluation and handle retirement with original owners. It does not
assert actual role scope simply because source run() emits a prospective report.
Store such output only as labeled recording fixture data. EvidenceOutput tests
use real tiny owned files, original parent/leaf identities and2MiB cap. No actual
borrowed stores, parameter body readers, key reader or HE engine is selected in R.

## Case design and reachability

nodes.json is the explicit proposed order. Cases assert a clean control reaches
the intended boundary, then require the negative at that boundary with forbidden
later counters zero. For public negative documents, re-pin only fixture-owned
bytes needed to reach the intended semantic check; never treat those bytes as
independently admitted actual proof. Distinguish hash rejection from semantic
rejection in observations.

All mutation cases restore exports/fields to their original values, make the
recording hook mode benign, and invoke the original next public action again.
The original owner/permit must remain failed, with no new initializer, hook,
array/sampling or publication calls. A second issuance rejection alone does not
prove this. Sentinel __instancecheck__ must remain uncalled when jax.Array was
replaced; both default-device factory and __enter__ mutation points are covered.
Prepared wrappers and partial getter results remain strongly retained before
validation. Original selected-device identity is required, not merely singleton
cardinality. Check barrier/device descriptors before waiting on them.

The clean process path records runtime retirement before device retirement,
followed by exactly one original default-scope exit, evidence/audit closure,
signal restoration and snapshot retirement. Device retirement's source hook must
not invoke the retired RuntimeAdmission. Body/cleanup failures attempt independent
original cleanup and preserve primary/cancellation precedence. A late evidence
close failure can occur after local runtime/device guard retirement; assert
outer exit70 and retained failure graph, not the false claim that nothing retired.

The narrow402 statistics successor is now selected. A dedicated recording case
returns a valid typed stats dictionary, captures its original content, then
mutates that original dictionary in a post-comparison binding or lease hook.
The reported statistics and required-capacity calculation must still describe
the original immutable snapshot. Retain the original mutable dictionary and
snapshot tuple as distinct ownership evidence. The comparison must not be
recomputed from the mutated dictionary, and a clean result is not a claim that
the later mutated values were measured or admitted. Preserve device6/401 as
historical sources;403 is the prospective focused proof target and retains the
402 statistics implementation exactly.

## Native flags and independent synthetic re-pinning

403 accepts only exact integer flags whose mode is RDONLY or RDWR, whose bits
include CLOEXEC|NOFOLLOW|NONBLOCK, and which contain no bit outside ACCMODE plus
those three flags. This is a pure policy constraint before native initialization.
It closes the source-observed window in which named lstat could be followed by a
blocking FIFO open or symlink-following open before the wrapper's FD check. No
such substitution was executed or observed in this preparation.

Every clean P/O/S/L/E/A/R fixture must construct access with
RDONLY|CLOEXEC|NOFOLLOW|NONBLOCK before deriving any hashes. The appended RDWR
case exercises the second allowed mode without opening a path. For the nine
semantic negatives, clone fixture-owned documents and choose the bad flag before
rebuilding access → selection → resource policy/review → phase grant/expected
pins → device review/lease → device pins → outer packet/hash. Update every
dependent link actually consumed by the real gate. Neither a stale digest failure
nor a mocked whole policy validator satisfies these cases. Phase.check and its
expected-pin check remain the two explicit P/F recordings. No real policy or
independent authority is manufactured.

Missing NOFOLLOW, CLOEXEC or NONBLOCK and extra CREAT, TRUNC, APPEND or1<<30 must
raise the dedicated required/allowed-flags message. WRONLY and reserved access
mode3 must raise the dedicated access-mode message. Independently validate a clean
safe-flags packet reaches the same real function, then require zero owner issue,
native initialization, open, hook and sample deltas on each negative. These are
59 planned cases, not executed flag truth-table tests. The audit wrong-flags case
keeps its selected RDONLY baseline, so requesting RDWR there is an unselected
flag tuple even though a separately authenticated RDWR policy is permitted.

## Parent ownership, evidence and closed inspection

The proposed parent owns each child immediately after Popen, captures PID/PGID
and command before fallible work, waits/reaps without a healthy timeout, and
writes an early terminal receipt before checking child success or outputs. A
setup failure must still retain its log and authoritative parent receipt. Do not
repeat the historical secondary-inspector failure by requiring every positive
artifact before publishing an incomplete outer failure record.


All operations after Popen, including getpgid/starttick observation, live receipt
publication and output inspection, must be inside the original child-ownership
try/except/finally. If group cleanup raises, a nested finally still attempts the
original direct child.wait; attach cleanup/publication/absence-check secondary
errors to the original primary. Set direct_wait_completed only after that
original wait returns normally, not from returncode or process absence. Publish
an early parent terminal record before positive-result inspection. Child terminal
PGID must be an exact int equal to original Popen PID even if a fast child escaped
the parent's optional getpgid observation; compare any observed group as well.
Original PID/startticks/argv are joined across early/child/parent records whenever
observed. Record an unavailable observation honestly, never invent a starttick.
Successful-case claims require the child-reported original startticks and exact
PID/PGID joins; external live observation remains separately attributed.

Each successful case produces exactly four regular files under a generated
case-specific owned path: parent-terminal.json, child-terminal.json, result.json,
child.log. Proposed59 positives therefore yield236 such regular records. The
parent receipt joins exact case/source/PID/PGID/return status to child result and
terminal hashes. Result includes explicit seams/restoration/counters/retained
owner status, no object repr or model/key/array payload. Missing positive files
on failure are listed as missing, never invented.

Tiny I/O/metadata fixtures have their own exact per-case filename/size/hash table
outside those236 evidence records. Inspector reads only declared public metadata
and report results; payload fixtures are never recursively harvested. Two tiny
metadata/ciphertext-shaped fixture families do not become actual parameter data.
Any pytest `*current` symlinks are lstat/readlink-only alias records; never follow
them. Exact paths and aggregate counts are derived statically when sources are
authored, not guessed from a glob or historical run. Reject all unlisted regular
files/directories in the inspected evidence subtree while preserving them as
unreviewed failure evidence rather than deleting them.

The enclosing collector independently verifies exact source/current/execution/
before/after/archive maps,59 ordered collection/XML, declared child receipts,
backend-denial record and restoration, and no remaining owned PID/PGID members.
Its own direct wait authority remains separate from peer/root live observations.
Capture all source/harness hashes before launch; late failures use reserved70.
The entire run remains synthetic/source-owned and supplies no capacity or actual
scientific authority. No execution authorization is part of this plan.
