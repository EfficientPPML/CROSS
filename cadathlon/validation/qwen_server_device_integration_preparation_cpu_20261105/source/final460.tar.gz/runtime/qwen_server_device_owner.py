"""Issuer-owned device lifetime for one dedicated full28 process.

The unchanged device6 state machine performs finite full authentication and
observations. This owner retains original callbacks/arrays and supplies the
five source-fixed process hooks. Native lease/synchronization authority is
currently a selected unconditional denial, not a successful recording seam.
"""
import os
import sys
import threading
from types import FunctionType
from qwen_file_contract import canonical,sha
from qwen_server_device_packet import DevicePacket
from qwen_device_policy import DevicePolicyAdmission,STAGES,parse
import qwen_device_capacity as capacity
import qwen_server_native_authority as native
from qwen_backend_identity import install_core
from qwen_server_dependencies import hash_installed,imported_origins
from qwen_server_resource import check_host_capacity
from qwen_finalizer import Finalizer

_ISSUED=False
_OWNERS={}
_FAILED=[]

def _accessor(fn):return(getattr(fn,'__self__',None),getattr(fn,'__func__',fn))
def _function(fn):
    if type(fn)is not FunctionType:raise TypeError('original source callback must be a plain function')
    return(fn,fn.__code__,fn.__defaults__,fn.__kwdefaults__,tuple((fn.__kwdefaults__ or {}).items()))
def _function_check(row):
    fn,code,defaults,kw,items=row
    if fn.__code__ is not code or fn.__defaults__ is not defaults or fn.__kwdefaults__ is not kw:
        raise ValueError('original device owner callback changed')
    if kw is not None and(set(kw)!=set(n for n,v in items)or any(kw[n]is not v for n,v in items)):
        raise ValueError('original device owner callback defaults changed')

def _record(owner):
    row=_OWNERS.get(id(owner))
    if type(owner)is not DeviceOwner or row is None or row['owner']is not owner:
        raise PermissionError('original issuer-owned device lifetime required')
    if row['pid']!=os.getpid()or row['thread']is not threading.current_thread():
        row['failure']=RuntimeError('device owner process/thread differs');raise row['failure']
    return row

def _fail(row,error):
    if row['failure']is None:row['failure']=error
    if not row['quarantined']:_FAILED.append(row);row['quarantined']=True

def _identity(row):
    if row['failure']is not None:raise PermissionError('failed original device owner requires process exit')
    packet_fields=object.__getattribute__(row['packet'],'__dict__')
    if packet_fields is not row['packet_dict']or set(packet_fields)!=set(n for n,v in row['packet_fields'])or any(packet_fields[n]is not v for n,v in row['packet_fields']):
        raise ValueError('original device packet dictionary/fields changed')
    policy=row['policy'];fields=object.__getattribute__(policy,'__dict__')
    if fields is not row['policy_dict']or set(fields)!= {'phase','blobs','expected_pins'}:
        raise ValueError('original device policy dictionary changed')
    if any(fields[n]is not v for n,v in row['policy_fields']):raise ValueError('original policy field identity changed')
    for module,name,fn,saved in row['exports']:
        if getattr(module,name,None)is not fn:raise ValueError('original device/native helper export changed')
        _function_check(saved)
    _function_check(row['binding_function']);_function_check(row['full_function'])
    if row['audit'] is not row['original_audit']:raise ValueError('original device audit owner changed')
    flags=(row['audit'].keys_enabled,row['audit'].bodies_enabled)
    if any(type(flag)is not bool for flag in flags):raise ValueError('exact original device/body scope flags required')
    allowed={(False,False)}
    if row['stage']=='post_init':allowed={(False,False),(True,False)}
    elif row['stage']=='post_keys':allowed={(True,False),(True,True)}
    elif row['stage']in('pre_evaluation','terminal'):allowed={(True,True)}
    if flags not in allowed:raise PermissionError('device observation does not permit current key/body scope')
    for name,original in row['audit_methods'].items():
        if any(a is not b for a,b in zip(_accessor(getattr(row['audit'],name)),_accessor(original))):
            raise ValueError('original device audit accessor changed')
    if canonical(row['dep'])!=row['dep_bytes']or canonical(row['expected'])!=row['expected_bytes']:
        raise ValueError('original device source/dependency dictionaries changed')
    if set(row['source_blobs'])!=set(n for n,b in row['original_blobs'])or any(row['source_blobs'][n]is not b for n,b in row['original_blobs']):
        raise ValueError('original device selected source bytes changed')
    if row['native_audit_binding']is not None:
        if row['audit'].native_binding is not row['native_audit_binding']or row['audit'].initialization_enabled is not True:
            raise ValueError('original native audit inventory changed')
    if row['array_type']is not None:
        if sys.modules.get('jax')is not row['jax']or getattr(row['jax'],'Array',None)is not row['array_type']:
            raise ValueError('original JAX Array export changed')
    for value,payload,moduli in row['ciphertexts']:
        if value.polynomial is not payload or value.moduli_array is not moduli:
            raise ValueError('original ciphertext payload/moduli identity changed')
    if row['default_enter_completed']:
        jax=row['jax'];device=row['device'];saved=row['jax_binding']
        if sys.modules.get('jax')is not jax or jax.__spec__ is not saved[0]or jax.Device is not saved[1]or type(device)is not saved[1]:
            raise ValueError('original device/JAX owner changed')
        if jax.config.jax_default_device is not device or jax.config.jax_enable_x64 is not True:
            raise ValueError('original selected device/default/x64 scope changed')
        for name,fn,code in saved[2]:
            if getattr(jax,name)is not fn or getattr(fn,'__code__',None)is not code:raise ValueError('original selected-device callable changed')
        if canonical({n:getattr(device,n)for n in('platform','id','process_index','local_hardware_id','device_kind')})!=saved[3]:
            raise ValueError('original selected device descriptor changed')
        manager=row['default_scope']
        for name,original in row['default_methods']:
            if any(a is not b for a,b in zip(_accessor(getattr(manager,name)),_accessor(original))):
                raise ValueError('original default-device scope accessor changed')

def _guard(row):
    # Never enters RuntimeAdmission or a device transition. The retained
    # caller checks original snapshot/source/environment/audit directly.
    _identity(row);row['binding_check']();_identity(row)
    if row['core']is not None:row['core'].check()

def _array(row,value):
    row['raw_returns'].append(value)  # retain before any property/descriptor access
    _guard(row)
    if row['array_type']is None:raise PermissionError('original JAX Array class was not captured')
    if not isinstance(value,row['array_type']):raise TypeError('genuine selected JAX array required')
    _guard(row)
    cls=type(value);devices=getattr(cls,'devices',None);barrier=getattr(cls,'block_until_ready',None)
    if devices is None or barrier is None:raise TypeError('original array device/barrier descriptors required')
    saved=(value,cls,devices,barrier,devices.__get__(value,cls),barrier.__get__(value,cls))
    row['arrays'].append(saved);_array_check(row,saved)
    return saved

def _array_check(row,saved):
    _identity(row)
    value,cls,devices,barrier,device_fn,barrier_fn=saved
    if type(value)is not cls or getattr(cls,'devices',None)is not devices or getattr(cls,'block_until_ready',None)is not barrier:
        raise ValueError('original array device/barrier binding changed')
    selected=device_fn()
    if type(selected)is not set or len(selected)!=1 or next(iter(selected))is not row['device']:
        raise ValueError('every original array must belong to the retained selected singleton')
    _identity(row)

def _retain_ciphertext(row,value):
    # Retain each partial result before the next foreign accessor or validation.
    row['raw_returns'].append(value)
    payload=value.polynomial;row['raw_returns'].append(payload)
    moduli=value.moduli_array;row['raw_returns'].append(moduli)
    saved=(value,payload,moduli);row['ciphertexts'].append(saved)
    return saved

def _synchronize(row,stage):
    seen=set()
    for saved in row['arrays']:
        if id(saved[0])in seen:continue
        seen.add(id(saved[0]));_array_check(row,saved);saved[5]();_array_check(row,saved)
    # Explicit transfers do not establish readiness of unreturned native
    # initialization, NTT/cache or compiler work. The genuine adapter is
    # separately required and presently denies; never substitute effects_barrier.
    row['native_synchronize'](row['lease'],stage,row['context'],tuple(saved[0]for saved in row['arrays']))
    _guard(row)

def _initialize(row):
    if row['core']is not None or row['initialization_entered']:raise PermissionError('one original initialization attempt')
    row['initialization_entered']=True;row['mode']='initializing'
    row['native_check'](row['lease'],row['phase'],row['blobs']);_guard(row)
    row['audit_methods']['enable_initialization'](row['owner'],row['documents']['access'])
    row['native_audit_binding']=row['audit'].native_binding
    _guard(row)
    row['installed_before']=hash_installed(row['dep'])
    row['core']=install_core(row['root'],row['source_blobs'],row['expected'],gate=row['gate'])
    row['gate'].core_enabled=True
    # All imports/enumeration below are real native actions behind the exact
    # initialization permit. No backend work occurs at module import.
    row['core'].load(('he_params','key_gen','ckks_ctx','polynomial'))
    import jax
    row['jax']=jax
    chosen=parse(row['documents']['selection'],'selection')['device']
    devices=jax.devices(backend='tpu');row['native_returns'].append(devices)
    matches=[d for d in devices if {n:getattr(d,n)for n in chosen}==chosen]
    if len(matches)!=1:raise ValueError('unique independently selected genuine TPU required')
    device=matches[0];row['device']=device
    # Capture before the foreign default-device factory/enter can run. Later
    # checks use this exact original class, never a replaceable module lookup.
    row['array_type']=jax.Array
    if not isinstance(row['array_type'],type):raise TypeError('original JAX Array class required')
    _guard(row)
    # Bind before entering: an enter may change configuration then raise.
    manager=jax.default_device(device);row['default_scope']=manager
    row['default_methods']=(('__enter__',manager.__enter__),('__exit__',manager.__exit__))
    _guard(row)
    row['default_enter_attempted']=True;row['default_methods'][0][1]()
    row['default_enter_completed']=True
    row['jax_binding']=(jax.__spec__,jax.Device,tuple((n,getattr(jax,n),getattr(getattr(jax,n),'__code__',None))for n in('devices','local_devices','process_count')),canonical(chosen))
    row['origins']=imported_origins(row['dep'],row['root'])
    if hash_installed(row['dep'])!=row['installed_before']:raise ValueError('original installed sources changed during initialization')
    row['mode']='initialized';_guard(row)
    return device

def hook(action,phase,blobs,*args):
    # Only original top-level process hooks call this captured dispatcher.
    matches=[r for r in _OWNERS.values()if r['phase']is phase and r['blobs']is blobs]
    if len(matches)!=1:raise PermissionError('original device hook owner required')
    row=matches[0]
    try:
        _record(row['owner']);_guard(row)
        if action=='bindings':
            if row['core']is not None:
                imported_origins(row['dep'],row['root'])
                if hash_installed(row['dep'])!=row['installed_before']:raise ValueError('installed device sources changed')
            return None
        if action=='lease':
            if row['lease']is None:
                row['lease_attempted']=True
                lease=row['native_acquire'](phase,blobs);row['lease']=lease
                _guard(row)
                if type(lease)is not native.NativeLease:raise TypeError('exact original native lease owner required')
            row['native_check'](row['lease'],phase,blobs);_guard(row);return None
        if action=='host':
            stage=args[0]
            if stage not in('before_init',*STAGES):raise ValueError('fixed host observation stage required')
            observation=check_host_capacity(phase,row['documents']['resource_policy'],row['documents']['resource_review'],expected_pins=row['resource_pins'],after_import=stage!='before_init')
            raw=canonical(dict(schema='qwen-device-host-observation-v1',pid=row['pid'],stage=stage,
                resource_policy_sha256=sha(row['documents']['resource_policy']),observation=observation))
            row['host'].append(raw);_guard(row);return raw
        if action=='initialize':return _initialize(row)
        if action=='synchronize':_synchronize(row,args[0]);return None
        raise ValueError('unselected device hook')
    except BaseException as error:_fail(row,error);raise

def _observe(row,stage):
    if row['pending']is not None:raise RuntimeError('nested original device stage is forbidden')
    index=len(row['observations'])
    if index>=len(STAGES)or STAGES[index]!=stage:raise PermissionError('ordered original device observation required')
    row['pending']=stage
    try:
        admission=row['observe'](row['permit'],stage);row['current']=admission
        raw=row['require'](row['permit'],admission,stage)
        row['observations'].append(raw);row['stage']=stage;_guard(row)
        return raw
    finally:row['pending']=None

def _dispatch(owner,action,arg=None):
    row=_record(owner)
    try:
        _guard(row)
        if action=='check':return None
        if action=='access':
            if row['mode']not in('initializing','initialized','observed')or not row['initialization_entered']or row['lease']is None:
                raise PermissionError('original initialization/native access scope required')
            return None
        if action=='start':
            if row['permit']is not None or row['mode']!='prepared':raise PermissionError('one original initialization permit')
            # Issue may fail before returning; device6 and this owner retain
            # the entire attempt. No retry or replacement lease is permitted.
            row['mode']='issuing';row['permit']=row['issue'](row['policy'])
            row['initialize'](row['permit']);_observe(row,'post_init');row['mode']='observed'
            return row['core'],tuple(row['origins'].items())
        if action=='require':
            if row['stage']!=arg or row['current']is None:raise PermissionError('exact current device stage required')
            return row['require'](row['permit'],row['current'],arg)
        if action=='loaded':
            handle,transfers=arg
            if row['stage']!='post_init'or row['handle']is not None or type(transfers)is not tuple:raise PermissionError('one original loader device registration')
            row['handle']=handle;row['context']=handle.ctx;row['transfers']=transfers
            if handle.ctx is None:raise ValueError('original loaded keyless context required')
            for array in transfers:_array(row,array)
            _guard(row);return None
        if action=='post_keys':
            if arg is not row['handle']or arg.ctx is not row['context']:raise ValueError('original registered loader handle/context differs')
            return _observe(row,'post_keys')
        if action=='ciphertext':
            value,payload,moduli=_retain_ciphertext(row,arg)
            _array(row,payload);_array(row,moduli);_guard(row);return None
        if action=='evaluation':
            ctx,handle,full_owner,prepared=arg
            if row['evaluation']is not None or row['stage']!='post_keys'or ctx is not row['context']or handle is not row['handle']or type(prepared)is not tuple:
                raise PermissionError('one evaluation with original loaded owners required')
            row['evaluation']=(ctx,handle,full_owner,prepared)
            _function_check(row['full_function']);row['full_boundary']();_guard(row)
            prepared_refs=tuple(_retain_ciphertext(row,value)for value in prepared)
            _guard(row)
            for value,payload,moduli in prepared_refs:
                _array(row,payload);_array(row,moduli)
            _observe(row,'pre_evaluation');return None
        if action=='terminal':
            if row['handle']is None or row['handle'].ctx is not None:raise ValueError('original loader must retire before terminal device observation')
            return _observe(row,'terminal')
        if action=='retire':
            if row['stage']!='terminal':raise PermissionError('all four device observations required')
            result=row['retire'](row['permit'])
            if result!=tuple(row['observations']):raise ValueError('original ordered device observations changed')
            row['mode']='guard_retired';return result
        if action=='evidence':
            return dict(packet_sha256=row['packet_sha'],expected_pins_sha256=sha(row['policy'].expected_pins),
                documents={n:sha(b)for n,b in row['blobs']},observations=[parse(raw,'device observation')for raw in row['observations']],
                host_observations=[parse(raw,'host observation')for raw in row['host']],capacity_reserved=False,
                global_free_memory_measured=False,external_lease_release_claimed=False,native_python_sandbox_claimed=False)
        raise ValueError('unselected original device owner action')
    except BaseException as error:_fail(row,error);raise

class DeviceOwner:
    __slots__=()
    def check(self,*,_original=_dispatch):return _original(self,'check')
    def require_initialization_scope(self,*,_original=_dispatch):return _original(self,'access')
    def start(self,*,_original=_dispatch):return _original(self,'start')
    def require_stage(self,stage,*,_original=_dispatch):return _original(self,'require',stage)
    def register_loaded(self,handle,transfers,*,_original=_dispatch):return _original(self,'loaded',(handle,transfers))
    def post_keys(self,handle,*,_original=_dispatch):return _original(self,'post_keys',handle)
    def ciphertext(self,value,*,_original=_dispatch):return _original(self,'ciphertext',value)
    def before_evaluation(self,ctx,handle,owner,prepared,*,_original=_dispatch):return _original(self,'evaluation',(ctx,handle,owner,prepared))
    def terminal(self,*,_original=_dispatch):return _original(self,'terminal')
    def retire_guard(self,*,_original=_dispatch):return _original(self,'retire')
    def evidence(self,*,_original=_dispatch):return _original(self,'evidence')

def create(packet,*,root,expected,source_blobs,dep,gate,binding_check,full_boundary,audit,audit_methods,resource_pins):
    global _ISSUED
    if _ISSUED:
        for row in _OWNERS.values():_fail(row,RuntimeError('second device owner creation attempt'))
        raise PermissionError('one original device owner per process')
    _ISSUED=True;owner=DeviceOwner()
    if type(packet)is not DevicePacket:raise TypeError('exact independently admitted device sidecar required')
    policy=packet.policy
    row=dict(owner=owner,pid=os.getpid(),thread=threading.current_thread(),failure=None,quarantined=False,
        packet=packet,packet_dict=object.__getattribute__(packet,'__dict__'),packet_fields=tuple(object.__getattribute__(packet,'__dict__').items()),
        packet_check=type(packet).check,packet_sha=packet.expected_sha256,policy=policy,policy_dict=None,policy_fields=(),phase=None,blobs=None,
        root=root,expected=expected,expected_bytes=canonical(expected),source_blobs=source_blobs,original_blobs=tuple(source_blobs.items()),
        dep=dep,dep_bytes=canonical(dep),gate=gate,binding_check=binding_check,binding_function=None,
        full_boundary=full_boundary,full_function=None,native_audit_binding=None,
        audit=audit,original_audit=audit,audit_methods=dict(audit_methods),resource_pins=resource_pins,mode='prepared',
        exports=(),documents=None,lease=None,lease_attempted=False,core=None,jax=None,array_type=None,device=None,jax_binding=None,
        default_scope=None,default_methods=(),default_enter_attempted=False,default_enter_completed=False,default_exit_attempted=False,
        initialization_entered=False,installed_before=None,origins=None,native_returns=[],raw_returns=[],arrays=[],ciphertexts=[],
        permit=None,current=None,pending=None,stage=None,host=[],observations=[],handle=None,context=None,transfers=None,evaluation=None)
    _OWNERS[id(owner)]=row
    try:
        row['binding_function']=_function(binding_check);row['full_function']=_function(full_boundary)
        if type(policy)is not DevicePolicyAdmission:raise TypeError('exact admitted device policy required')
        fields=object.__getattribute__(policy,'__dict__');row['policy_dict']=fields;row['policy_fields']=tuple(fields.items())
        if set(fields)!= {'phase','blobs','expected_pins'}:raise ValueError('exact device policy field set required')
        row['phase']=policy.phase;row['blobs']=policy.blobs;row['documents']=dict(policy.blobs)
        rows=[]
        for module,names in((capacity,('issue_initialization','initialize_once','observe_capacity','require_current','retire')),
                             (native,('acquire','check','synchronize'))):
            for name in names:
                fn=getattr(module,name);rows.append((module,name,fn,_function(fn)))
        row['exports']=tuple(rows)
        row.update(issue=rows[0][2],initialize=rows[1][2],observe=rows[2][2],require=rows[3][2],retire=rows[4][2],
            native_acquire=rows[5][2],native_check=rows[6][2],native_synchronize=rows[7][2])
        _guard(row);row['packet_check'](packet,policy.phase);_guard(row);return owner
    except BaseException as error:_fail(row,error);raise

def close_default_scope(owner,primary=None):
    """Only a clean retired device guard permits original scope exit.

    Failed/partial initialization remains strongly held for dedicated process
    exit; there is no invented backend close or external lease release.
    """
    row=_record(owner)
    if primary is not None or row['failure']is not None or row['mode']!='guard_retired':
        error=primary or row['failure']or RuntimeError('device guard was not cleanly retired')
        _fail(row,error);return
    final=Finalizer({},None)
    if row['default_enter_attempted']and not row['default_exit_attempted']:
        original=row['default_methods'][1][1]
        final.attempt('original device owner before default scope exit',lambda:_guard(row))
        row['default_exit_attempted']=True
        final.attempt('original selected default-device scope exit',lambda:original(None,None,None))
    error=final.selected()
    if error is not None:_fail(row,error);raise error
    row['mode']='retired'
    # Keep the original external lease and evidence until process retirement.
    # Runtime consumers are already retired; no capacity reuse is authorized.
