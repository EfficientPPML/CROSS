"""Closed public device sidecar; independent launch SHA is the authority root.

No filesystem, backend, capacity observation or execution permission. The
scientific ServerPacket and its thirteen retained graph types stay unchanged.
"""
from dataclasses import dataclass
from qwen_file_contract import canonical,sha,hash_value,same
from client_role_common import raw_object,obj
from qwen_device_policy import ROLES,authenticate

PACKET_LIMIT=16<<20
INNER_LIMIT=256<<10
RAW_RETENTION_FLOOR=PACKET_LIMIT+11*INNER_LIMIT

def _inner(value,label):
    if type(value)is not str:raise TypeError('exact public device UTF-8 string required: '+label)
    raw=value.encode('utf-8')
    if not 0<len(raw)<=INNER_LIMIT:raise ValueError('bounded device inner bytes required: '+label)
    return raw

def inspect(raw,expected_sha256):
    hash_value(expected_sha256)
    if type(raw)is not bytes or not 0<len(raw)<=PACKET_LIMIT or sha(raw)!=expected_sha256:
        raise ValueError('independently pinned bounded device sidecar required')
    value=raw_object(raw,PACKET_LIMIT,'device sidecar')
    obj(value,('schema','expected_pins','documents'),'device sidecar')
    same(value['schema'],'qwen-server-device-packet-v1','device sidecar schema differs')
    obj(value['documents'],ROLES,'exact ten public device documents')
    pins=_inner(value['expected_pins'],'independent pins')
    rows=tuple((name,_inner(value['documents'][name],name))for name in ROLES)
    # Real device authentication enforces all closed canonical inner schemas.
    # Structural inspection does not claim that any factual policy passed.
    return pins,rows

@dataclass(frozen=True)
class DevicePacket:
    raw:bytes
    expected_sha256:str
    policy:object
    def check(self,phase):
        if type(self)is not DevicePacket:raise TypeError('exact original device sidecar required')
        pins,rows=inspect(self.raw,self.expected_sha256)
        if self.policy.phase is not phase or self.policy.expected_pins!=pins or self.policy.blobs!=rows:
            raise ValueError('original sidecar/policy/phase binding differs')
        return authenticate(phase,rows,expected_pins=pins)
    @property
    def execution_authorized(self):return False

def authenticate_packet(phase,raw,*,expected_sha256,resource_policy,resource_review,dependency_policy):
    pins,rows=inspect(raw,expected_sha256)
    policies=dict(rows)
    for name,original in(('resource_policy',resource_policy),('resource_review',resource_review),('dependency_policy',dependency_policy)):
        if type(original)is not bytes or policies[name]!=original:
            raise ValueError('device and original scientific packet policy bytes differ')
    policy=authenticate(phase,rows,expected_pins=pins)
    return DevicePacket(raw,expected_sha256,policy)
