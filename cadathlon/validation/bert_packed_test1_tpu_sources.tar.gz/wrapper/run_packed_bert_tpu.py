import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
root=Path('/home/jianming_gatech/CROSS')
sys.path.insert(0,str(root/'cadathlon/common'))
from encrypted_transformer import public_toy_approximations
prefix=Path('/tmp/cross-bert-packed-tpu-test1-v1')
os.environ['CROSS_PUBLIC_KEY_DIRECTORY']='/dev/shm'
def key_filesystem():
    usage=shutil.disk_usage(os.environ['CROSS_PUBLIC_KEY_DIRECTORY'])
    return dict(path=os.environ['CROSS_PUBLIC_KEY_DIRECTORY'],total_bytes=usage.total,used_bytes=usage.used,free_bytes=usage.free,observed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
def wrapper_hash():return hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
sources=list((root/'jaxite_word').glob('*.py'))+[root/'cadathlon/common'/name for name in ('encrypted_reference.py','encrypted_packed_transformer.py','encrypted_packed_qwen.py','encrypted_polynomial.py','encrypted_transformer.py','encrypted_refresh.py','encrypted_compilation.py','encrypted_primitives.py','encrypted_rotation.py','transformer_runner.py','support.py')]+[root/'cadathlon/agent_pset/p2_bert/src'/name for name in ('runner.py','bert_packed_reference.py','reference.py')]+[root/'cadathlon/agent_pset/p2_bert/test'/name for name in ('test1.in','test1.out')]
def hashes():
    return {str(path.relative_to(root)):hashlib.sha256(path.read_bytes()).hexdigest() for path in sources}
command=[sys.executable,'cadathlon/agent_pset/p2_bert/src/runner.py','--case','cadathlon/agent_pset/p2_bert/test/test1.in','--implementation','cadathlon/agent_pset/p2_bert/src/bert_packed_reference.py','--require-tpu','--warmups','0','--repeats','1']
evidence={'scope':'Experimental real encrypted packed public toy BERT test1; not pretrained BERT, file-harness integration, or calibrated baseline','command':command,'wrapper_sha256_start':wrapper_hash(),'execution_environment':{name:os.environ.get(name) for name in ('JAX_PLATFORMS','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','CROSS_LEVEL_PARAMS_MAX','CROSS_BARRETT_NTT_CONTEXT_CACHE_CAPACITY','CROSS_PUBLIC_KEY_DIRECTORY')},'public_key_filesystem_before':key_filesystem(),'approximation_contracts':{name:{'domain':poly.domain,'degree':len(poly.coefficients)-1,'coefficients':poly.coefficients,'input_power_basis':poly.input_power_basis} for name,poly in public_toy_approximations('bert').items()},'source_hashes_start':hashes(),'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
started=time.perf_counter()
with open(str(prefix)+'.json','w') as output,open(str(prefix)+'.log','w') as log:
    process=subprocess.Popen(command,cwd=root,stdout=output,stderr=log)
    evidence['pid']=process.pid
    Path(str(prefix)+'.evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
    print('BERT_PID',process.pid,'EVIDENCE',str(prefix)+'.evidence.json',flush=True)
    code=process.wait()
evidence.update(returncode=code,total_wall_s=time.perf_counter()-started,source_hashes_end=hashes(),wrapper_sha256_end=wrapper_hash(),public_key_filesystem_after=key_filesystem())
evidence['source_files_unchanged']=evidence['source_hashes_start']==evidence['source_hashes_end'] and evidence['wrapper_sha256_start']==evidence['wrapper_sha256_end']
try:
    evidence['result']=json.loads(Path(str(prefix)+'.json').read_text())
except Exception as error:
    evidence['result_read_error']=str(error)
Path(str(prefix)+'.evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
print('BERT_EXIT',code,'WALL_S',evidence['total_wall_s'],flush=True)
sys.exit(code if code else (0 if evidence['source_files_unchanged'] else 2))
