# Frozen layer-indexed initial-softmax prefix and tail

The new isolated owner preserves the exact BERT-v2 manifest and exp8 power
circuit, including the original static six-update reciprocal. Layer indices
select the frozen centered domains and divisors16/32/64. The prefix computes
the masked valid-key mean and normalized t; the tail never recenters t.

The intended continuation is scores21→mean19→normalized_t18, explicit
full-slot B2 refresh25, then base_exp21→mean_exp19→inverse8→product7→masked
probabilities6. Prefix and tail consume3 and19 levels. No extra pre-power mask
is inserted: all exponential coefficients/bias and the mean/final outputs use
their unchanged public masks. Tests inject bounded nonzero values into refreshed
padding to verify ideal masking without claiming bootstrap padding errors vanish.

`BertSplitInitialSoftmax.prefix` and `.tail` can be called separately.
`.evaluate_tile` performs the explicit B2 refresh between them, guarding the
original score input throughout. The borrowed arithmetic/context, refresher,
full rotation/helper inventory, layer contract, public masks and original query
positions are construction-bound. Current/retained/captured values are checked
after callbacks; callback-added public bounds are removed from owned results.
No input annotation is changed, no codec is called, and borrowed owners are not
closed. Cancellation clears only local references and preserves its exception.

Full-slot ideal arithmetic covers every public K1..128 for each distinct
divisor, with independent rows/heads, partial query tiles and hostile original
padding. Every frozen layer has exact endpoint fixtures; all1536 layer/K
metadata schedules include canonical and adjacent binary64 scales. The fixed
all-slot ideal comparison gate is1e-11. Independent dense oracles use the
original polynomial and Newton formulas, with no clipping or model-output fit.

These are ideal-slot/metadata tests. No ciphertext, real refresh, checkpoint
model forward, or file stage is executed. Valid-input domains, B2 all-slot
range/error behavior and subsequent composition remain caller obligations.
The selected5/6/7 normalized squaring rounds are outside this initial owner.
