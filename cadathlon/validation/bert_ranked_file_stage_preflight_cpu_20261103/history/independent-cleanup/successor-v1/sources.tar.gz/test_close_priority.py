import os
from pathlib import Path
import pytest
import ranked_readback

@pytest.mark.parametrize('cancel',[KeyboardInterrupt,SystemExit])
def test_cleanup_only_cancel_supersedes_file_close_error(tmp_path,monkeypatch,cancel):
    tmp_path.chmod(0o700);p=tmp_path/'value';p.write_bytes(b'[]');p.chmod(0o600)
    real_close=os.close;attempts=[]
    def close(fd):
        real_close(fd);attempts.append(fd)
        if len(attempts)==1:raise OSError('first file cleanup failed')
        raise cancel('later directory cleanup cancelled')
    with monkeypatch.context() as m:
        m.setattr(os,'close',close)
        with pytest.raises(cancel,match='later directory'):
            ranked_readback._private_read(p,1024)
    assert len(attempts)==2
