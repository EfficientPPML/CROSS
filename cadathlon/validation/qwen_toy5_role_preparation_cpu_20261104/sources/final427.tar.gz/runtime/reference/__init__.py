"""Explicit client-only package for unchanged public Q5 diagnostic references."""
