from pathlib import Path
Path('/tmp/qwen-expanded-preparation-entry-root-replay-20261104/corrected/declared_helper_control/owned-output/tmp/declared-or-unbound-helper-executed.txt').write_text("synthetic canary only\n")
raise RuntimeError("canary stops before derivation or pytest")
