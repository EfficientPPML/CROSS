def derive():
    return {'scope':'Synthetic startup only; no full model plan/runtime.'}
