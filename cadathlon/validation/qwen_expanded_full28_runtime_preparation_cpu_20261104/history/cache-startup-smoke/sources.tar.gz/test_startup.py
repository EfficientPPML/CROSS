from pathlib import Path
import sys
import numpy as np
import pytest
def test_actual_import_pytest_startup():
    assert np.array_equal(np.arange(4),[0,1,2,3])
    assert pytest.__version__ and sys.dont_write_bytecode is True
    assert sys.pycache_prefix and Path(sys.pycache_prefix).is_dir()
    assert not any(Path(sys.pycache_prefix).iterdir())
