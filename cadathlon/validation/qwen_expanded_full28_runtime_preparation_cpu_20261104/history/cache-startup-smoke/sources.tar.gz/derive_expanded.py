def verify_generated():
    return {}
