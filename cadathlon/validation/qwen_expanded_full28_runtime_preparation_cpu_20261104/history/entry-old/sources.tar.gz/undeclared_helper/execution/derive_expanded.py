from pathlib import Path
Path('/tmp/qwen-expanded-preparation-entry-root-probe-20261104/old-v1/undeclared_helper/owned-output/tmp/declared-or-unbound-helper-executed.txt').write_text("synthetic canary only\n")
raise RuntimeError("canary stops before derivation or pytest")
