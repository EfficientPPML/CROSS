from pathlib import Path
Path('/tmp/qwen-expanded-preparation-entry-root-probe-20261104/old-v1/nonisolated_startup/owned-output/tmp/declared-or-unbound-helper-executed.txt').write_text("synthetic canary only\n")
raise RuntimeError("canary stops before derivation or pytest")
