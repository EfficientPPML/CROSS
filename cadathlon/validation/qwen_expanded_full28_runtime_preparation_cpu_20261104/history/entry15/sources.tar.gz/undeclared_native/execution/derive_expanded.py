from pathlib import Path
Path('/tmp/qwen-expanded-preparation-entry-all-boundaries-20261104/undeclared_native/owned-output/tmp/declared-or-unbound-helper-executed.txt').write_text("synthetic canary only\n")
raise RuntimeError("canary stops before derivation or pytest")
