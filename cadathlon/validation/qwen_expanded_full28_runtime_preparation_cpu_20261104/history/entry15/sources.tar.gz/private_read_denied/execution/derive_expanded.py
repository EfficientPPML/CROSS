from pathlib import Path
Path('/tmp/qwen-expanded-preparation-entry-all-boundaries-20261104/private_read_denied/synthetic-private-like.json').read_bytes()
from pathlib import Path
Path('/tmp/qwen-expanded-preparation-entry-all-boundaries-20261104/private_read_denied/owned-output/tmp/declared-or-unbound-helper-executed.txt').write_text("synthetic canary only\n")
raise RuntimeError("canary stops before derivation or pytest")
