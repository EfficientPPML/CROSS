"""Capture isolated engine cleanup tests and every exact source byte."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    output = ROOT / sys.argv[1]
    negative = '--negative' in sys.argv[2:]
    output.mkdir(exist_ok=False)
    paths = {p.relative_to(ROOT).as_posix(): p for group in ('candidate', 'before')
             for p in sorted((ROOT / group).glob('*.py'))}
    paths.update({'collect.py': ROOT / 'collect.py', 'origins.json': ROOT / 'origins.json'})
    before = {n: sha(p) for n, p in paths.items()}
    start = time.monotonic()
    report = dict(passed=False, negative=negative, source_hashes_before=before,
                  scope='Mocked engine owners and isolated single-thread signal tests; no model/crypto or process-wide signal atomicity claim.',
                  cpu_affinity=sorted(os.sched_getaffinity(0)), python=sys.version)
    with tarfile.open(output / 'sources.tar.gz', 'w:gz') as tar:
        for name, path in paths.items():
            tar.add(path, arcname=name, recursive=False)
    names = ['test_mask_capture.py', '-k', 'post_mutation_block_failure'] if negative else [
        'test_full_model_engine.py', 'test_cleanup_regressions.py', 'test_signal_installation.py', 'test_mask_capture.py']
    command = [sys.executable, '-m', 'pytest', '-q', '--tb=short', *names,
               '--junitxml=' + str(output / 'tests.xml')]
    with (output / 'tests.log').open('wb') as log:
        child = subprocess.run(command, cwd=ROOT / 'candidate', stdout=log, stderr=subprocess.STDOUT,
                               env={**os.environ, 'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1',
                                    'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1'})
    report['test_exit_code'] = child.returncode
    report['child_reaped'] = True
    suites = ET.parse(output / 'tests.xml').getroot()
    report['tests'] = {k: sum(int(s.attrib.get(k, 0)) for s in suites)
                       for k in ('tests', 'failures', 'errors', 'skipped')}
    report['source_hashes_after'] = {n: sha(p) for n, p in paths.items()}
    report['sources_unchanged'] = before == report['source_hashes_after']
    report['source_archive_sha256'] = sha(output / 'sources.tar.gz')
    with tarfile.open(output / 'sources.tar.gz') as tar:
        members = tar.getmembers()
        report['archive_verified'] = (len(members) == len(before) == len({m.name for m in members})
            and all(m.isfile() for m in members)
            and {m.name: hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in members} == before)
    origins = json.loads((ROOT / 'origins.json').read_bytes())
    report['original_frozen_sources_unchanged'] = all(sha(Path(p)) == h for p, h in origins.items())
    integrity = report['sources_unchanged'] and report['archive_verified'] and report['original_frozen_sources_unchanged']
    report['negative_reproduced'] = negative and child.returncode == 1 and report['tests'] == dict(tests=8, failures=8, errors=0, skipped=0)
    report['passed'] = not negative and child.returncode == 0 and report['tests'] == dict(tests=37, failures=0, errors=0, skipped=0) and integrity
    report['elapsed_s'] = time.monotonic() - start
    (output / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({k: report[k] for k in ('passed', 'negative_reproduced', 'tests', 'elapsed_s', 'source_archive_sha256')}))
    return 0 if integrity and (report['passed'] or report['negative_reproduced']) else 1


if __name__ == '__main__':
    raise SystemExit(main())
