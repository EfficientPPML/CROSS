"""Pinned completed prepared/BSGS server proof, public metadata only.

The existing upload and new response root are distinct borrowed directories.
This gate never decrypts, reads CT bodies, creates receipts, or retires paths.
The caller must hold/recheck the returned observed identities and authenticate
CT payloads before opening private client state. No completed actual server
report is supplied by this module; its digest must come from the caller.
"""
from pathlib import Path
import hashlib,io,json,math,stat,tarfile
import key_gate
HERE=Path(__file__).resolve().parent
SOURCE_MANIFEST_SHA='3699090915c2fa08783fdf1fe57e7d3acd84131dfd858b27bfbcac329da544c4'
PREFLIGHT_SHA='31f9120534e1d23843b3f7a5ec7e68c77963ac7456e5e0b492557aedd26b4315'
PREFLIGHT_ARCHIVE_SHA='fd46274e075565bcec545cca13f03470d4b9506b6327ffd7f403a756acbcaa94'

def _need(condition,message):
    if not condition:raise ValueError(message)
def _same(a,b,message):_need(key_gate.canonical(a)==key_gate.canonical(b),message)
def _sha(value):return key_gate.sha_field(value)
def _flags(value,names,message):
    _need(type(value)is dict and all(value.get(n)is True for n in names)and not value.get('error')and not value.get('cleanup_errors'),message)
def _archive(raw,expected):
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz')as tar:
        rows=tar.getmembers()
        _need(len(rows)==len(expected)and len({r.name for r in rows})==len(rows),'unique complete286 source archive required')
        _need(all(r.isfile()and 0<=r.size<=16<<20 and not Path(r.name).is_absolute()and '..'not in Path(r.name).parts for r in rows)and sum(r.size for r in rows)<=32<<20,'bounded regular public source archive required')
        for row in rows:
            _need(row.name in expected,'unexpected source archive member')
            with tar.extractfile(row)as stream:body=stream.read(row.size+1)
            _need(len(body)==row.size and key_gate.digest(body)==expected[row.name],'source archive bytes differ')

def _process(value):
    _flags(value,('direct_child_reaped','group_empty_verified','cleanup_completed'),'successful server direct-child/group retirement required')
    _need(type(value.get('direct_returncode'))is int and value['direct_returncode']==0,'zero actual worker exit required')
    for n in ('pid','process_group'):_need(type(value.get(n))is int and value[n]>0,'typed producer process identity required')

def _reviewed_sources():
    raw=key_gate.read(HERE/'combined_server_sources.json',1<<20)
    _need(key_gate.digest(raw)==SOURCE_MANIFEST_SHA,'reviewed286 source inventory pin differs')
    expected=key_gate.parse(raw);_need(type(expected)is dict and len(expected)==286,'exact286 reviewed server sources required')
    for name,digest in expected.items():
        _need(type(name)is str and not Path(name).is_absolute()and '..'not in Path(name).parts,'relative source name required');_sha(digest)
    raw=key_gate.read(HERE/'combined_server_preflight.json',8<<20)
    _need(key_gate.digest(raw)==PREFLIGHT_SHA,'reviewed server preflight pin differs')
    proof=key_gate.parse(raw)
    _flags(proof,('passed','body_complete','cleanup_completed','termination_scope_completed','all_started_children_reaped','source_files_unchanged','source_archive_verified'),'successful reviewed server preparation required')
    _need(proof.get('actual_HE')is False and proof.get('actual_server_launch')is False,'preparation scope must remain public-only')
    for n,value in [('source_count',286),('test_count',157),('expected_tests',157),('test_failures',0),('installed_denials',25)]:
        _need(type(proof.get(n))is int and proof[n]==value,'complete typed public preparation counts required')
    for n in ('source_hashes_start','source_hashes_end'):_same(proof.get(n),expected,'reviewed preparation source inventory differs')
    children=proof.get('children');_need(type(children)is list and len(children)==2 and {c.get('name')for c in children}=={'tests','installed'},'both public preparation children required')
    for child in children:_process(child.get('process'))
    archive=key_gate.read(HERE/'combined_server_preflight_sources.tar.gz',32<<20)
    _need(key_gate.digest(archive)==PREFLIGHT_ARCHIVE_SHA==proof.get('source_archive_sha256'),'reviewed server preflight archive differs');_archive(archive,expected)
    readiness=proof.get('dependency_readiness',{})
    _flags(readiness,('passed','ready','dependencies_authenticated'),'completed technical prerequisites required')
    _need(readiness.get('execution_authorized')is False and readiness.get('actual_HE')is False and readiness.get('pending')==[],'preflight cannot supply actual launch authority')
    return expected,readiness

def _path(path):
    path=Path(path)
    _need(path.is_absolute()and path==path.resolve(),'absolute non-symlink retained path required')
    return path

def _identity(path,kind,expected=None):
    path=Path(path);info=path.lstat()
    _need(stat.S_ISDIR(info.st_mode)if kind=='directory'else stat.S_ISREG(info.st_mode),'ordinary retained '+kind+' required')
    identity=[info.st_dev,info.st_ino]
    if expected is not None:
        _need(type(expected)is list and len(expected)==2 and all(type(v)is int and v>=0 for v in expected),'typed retained directory identity required')
        _same(identity,expected,'retained response/upload identity changed')
    return dict(device=info.st_dev,inode=info.st_ino,size=info.st_size,mtime_ns=info.st_mtime_ns,ctime_ns=info.st_ctime_ns,kind=kind)

def _prepared_mode(worker):
    _need(worker.get('prepared_rotation_cache')is True and worker.get('refresh_rotation_cache')=='ordinary','prepared graph/ordinary refresh mode required')
    for n,v in [('prepared_graph_owners',2),('prepared_max_entries_per_owner',2),('prepared_max_bytes_per_owner',2<<30),('prepared_aggregate_logical_bytes',4<<30)]:
        _need(type(worker.get(n))is int and worker[n]==v,'fixed two-owner prepared limits required')

def authenticate(evidence,report_sha256,io_workspace,response_root,*,keys,model,requests):
    # External terminal identity is checked before any other source or retained
    # path read. A worker cannot authorize its own pending/incomplete report.
    evidence=Path(evidence);raw=key_gate.read(evidence/'report.json',8<<20)
    _need(key_gate.digest(raw)==_sha(report_sha256),'external completed combined-server report differs')
    report=key_gate.parse(raw)
    _flags(report,('passed','execute','body_complete','actual_server_compute','actual_execution_attempted','all_processes_reaped','external_workspaces_never_removed','operation_complete','cleanup_completed','termination_scope_completed','source_files_unchanged','source_archive_verified','upload_retained','response_root_retained'),'completed actual combined-server proof required before private reads')
    expected,readiness=_reviewed_sources()
    _need(type(report.get('source_count'))is int and report['source_count']==286,'actual286 producer source count required')
    for n in ('source_hashes_start','source_hashes_end','execution_source_hashes_end'):_same(report.get(n),expected,'completed server source inventory differs')
    _same(report.get('reviewed_dependencies'),readiness,'completed server prerequisite proof differs')
    archive=key_gate.read(evidence/'sources.tar.gz',32<<20)
    _need(key_gate.digest(archive)==_sha(report.get('source_archive_sha256')),'actual server source archive hash differs');_archive(archive,expected)
    _process(report.get('worker_process'))
    worker_raw=key_gate.read(evidence/'worker/worker_report.json',8<<20)
    _need(key_gate.digest(worker_raw)==_sha(report.get('worker_report_sha256')),'completed worker report linkage differs')
    worker=key_gate.parse(worker_raw)
    _flags(worker,('passed','body_complete','termination_scope_completed','cleanup_completed','actual_server_compute_started','actual_server_compute_completed','request_readback_complete','response_readback_complete','upload_payloads_unchanged','keygen_codecs_native_private_forbidden','source_files_unchanged','upload_retained','response_root_retained','external_workspaces_never_removed'),'complete server-only worker proof required')
    _need(worker.get('forbidden_attempts')==[]and all(worker.get(n)is False for n in ('key_generation','encryption','decryption','native_model_forward','client_private_read')),'server must retain exact keyless/phase boundaries')
    _prepared_mode(worker)
    for n in ('source_hashes_start','source_hashes_end'):_same(worker.get(n),expected,'server-only source inventory differs')
    _same(worker.get('reviewed_dependencies'),readiness,'worker prerequisite proof differs')
    prerequisite={n:keys[n]for n in ('context_id','key_report_sha256','key_source_archive_sha256')}|{n:model[n]for n in ('model_id','model_report_sha256','model_manifest_sha256')}|{n:requests[n]for n in ('stage3_report_sha256','public_batch_sha256','input_digest')}
    for proof in (report,worker):_same(proof.get('prerequisite'),prerequisite,'completed producer key/model/input chain differs')
    _need(worker.get('context_id')==keys['context_id']and worker.get('model_id')==model['model_id'],'server worker context/model differs')
    root=_path(io_workspace);response=_path(response_root)
    _need(root!=response and root not in response.parents and response not in root.parents,'upload and response roots must be separate')
    _need(Path(requests['upload'])==root/'upload','authenticated original upload path differs')
    upload_state=_identity(root/'upload','directory');response_state=_identity(response,'directory')
    contract=dict(schema='prepared-bsgs-separate-response-v1',upload=str(root/'upload'),upload_identity=[upload_state['device'],upload_state['inode']],response_root=str(response),response_root_identity=[response_state['device'],response_state['inode']],download=str(response/'download'),server_report=str(response/'server_report'),prerequisite=prerequisite,sample_count=1,request_tile_count=8,expected_response_level=2,client_successor_required=True,original_io_download_used=False)
    for proof in (report,worker):_same(proof.get('response_contract'),contract,'separate response-root contract or identity differs')
    _need({p.name for p in response.iterdir()}=={'download','server_report'},'exact separate response root inventory required')
    download_state=_identity(response/'download','directory');timing_state=_identity(response/'server_report','regular')
    rows=requests['tiles'];_need(type(rows)is list and len(rows)==8 and all(type(r.get('payload_bytes'))is int for r in rows),'all8 typed original request tiles required')
    request_expected=dict(sample_count=1,tile_count=8,public_batch_sha256=requests['public_batch_sha256'],input_digest=requests['input_digest'],ciphertext_payload_bytes=sum(r['payload_bytes']for r in rows),tiles=rows)
    _same(report.get('authenticated_tiles'),rows,'collector stage3 tile binding differs')
    for proof in (report,worker):_same(proof.get('request_readback'),request_expected,'completed original request readback differs')
    from file_stage_io import read_manifest
    import file_stage_contract as batches,file_stages
    from transport_contract import digest,ciphertext_contract
    from transport import _validate_manifest,manifest_digest
    batch=read_manifest(root/'upload/batch.json');_need(digest(batch)==requests['public_batch_sha256'],'original public request batch changed')
    inputs,candidate=file_stages._inputs()
    response_batch=batches.validate_response_batch(read_manifest(response/'download/batch.json'),batch,check_scale=file_stages._scale_checker(inputs,candidate))
    _need(len(response_batch['responses'])==1 and len(batch['requests'])==1,'complete original size0 batch required')
    row=response_batch['responses'][0];original=batch['requests'][0];nonce=row['request_id'];directory=response/'download'/nonce
    _need({p.name for p in (response/'download').iterdir()}=={'batch.json',nonce},'exact one-response directory inventory required')
    sample_state=_identity(directory,'directory')
    _need({p.name for p in directory.iterdir()}=={'bundle.json','transport.json','ct_0.npz'},'complete response container required')
    for name in ('bundle.json','transport.json','ct_0.npz'):_identity(directory/name,'regular')
    binding=ciphertext_contract(original['contract'],'response',0,row['scale'],requests['input_digest'])
    manifest=_validate_manifest(read_manifest(directory/'transport.json'),binding)
    _need(manifest_digest(manifest)==row['response_manifest_sha256'],'retained response transport digest changed')
    timing=read_manifest(response/'server_report');seconds=timing.get('full_model_compute_and_transport_seconds')
    _need(set(timing)=={'full_model_compute_and_transport_seconds'}and type(seconds)in (int,float)and math.isfinite(seconds)and seconds>=0,'finite server diagnostic timing required')
    p=keys['public_manifest']['parameters'];shape=[1,2,*p['degree_layout'],6]
    summary=dict(sample_count=1,response_count=1,input_digest=requests['input_digest'],public_batch_sha256=requests['public_batch_sha256'],response_batch_sha256=digest(response_batch),response_manifest_sha256=manifest_digest(manifest),payload_bytes=math.prod(shape)*4,shape=shape,scale=row['scale'],level=2,full_model_compute_and_transport_seconds=seconds)
    for proof in (report,worker):_same(proof.get('response_readback'),summary,'completed server response readback differs')
    for path,kind,old in [(root/'upload','directory',upload_state),(response,'directory',response_state),(response/'download','directory',download_state),(response/'server_report','regular',timing_state),(directory,'directory',sample_state)]:
        _same(_identity(path,kind),old,'retained public artifact changed during gate')
    return dict(stage4_report_sha256=report_sha256,source_archive_sha256=report['source_archive_sha256'],context_id=keys['context_id'],model_id=model['model_id'],public_batch_sha256=requests['public_batch_sha256'],input_digest=requests['input_digest'],response_batch_sha256=summary['response_batch_sha256'],response_manifest_sha256=summary['response_manifest_sha256'],response_root=str(response),upload_identity=upload_state,response_root_identity=response_state,download_identity=download_state,server_report_identity=timing_state,source_count=286,public_metadata_only=True,payload_verification_still_required=True)
