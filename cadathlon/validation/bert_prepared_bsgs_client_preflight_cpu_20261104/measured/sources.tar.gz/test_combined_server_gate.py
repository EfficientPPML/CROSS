from pathlib import Path
from types import SimpleNamespace as NS
import copy,json,os,shutil,io,tarfile
import pytest
from test_stage4_gate import case as predecessor_case
from test_stage3_gate import case as stage3_case,write
import combined_server_gate as g
import key_gate

@pytest.fixture
def case(predecessor_case,tmp_path):
    old=predecessor_case;response=tmp_path/'separate_response';response.mkdir(mode=0o700)
    (old.root/'download').rename(response/'download');(old.root/'server_report').rename(response/'server_report')
    sources=key_gate.parse(key_gate.read(g.HERE/'combined_server_sources.json'))
    preflight=key_gate.parse(key_gate.read(g.HERE/'combined_server_preflight.json'))
    shutil.copyfile(g.HERE/'combined_server_preflight_sources.tar.gz',old.evidence/'sources.tar.gz')
    def ident(path):s=path.stat();return [s.st_dev,s.st_ino]
    contract=dict(schema='prepared-bsgs-separate-response-v1',upload=str(old.root/'upload'),upload_identity=ident(old.root/'upload'),response_root=str(response),response_root_identity=ident(response),download=str(response/'download'),server_report=str(response/'server_report'),prerequisite=old.report['prerequisite'],sample_count=1,request_tile_count=8,expected_response_level=2,client_successor_required=True,original_io_download_used=False)
    worker=dict(old.worker)
    worker.update(body_complete=True,termination_scope_completed=True,cleanup_completed=True,upload_payloads_unchanged=True,upload_retained=True,response_root_retained=True,external_workspaces_never_removed=True,
        source_hashes_start=sources,source_hashes_end=sources,reviewed_dependencies=preflight['dependency_readiness'],response_contract=contract,
        forbidden_attempts=[],key_generation=False,encryption=False,decryption=False,native_model_forward=False,client_private_read=False,
        prepared_rotation_cache=True,prepared_graph_owners=2,prepared_max_entries_per_owner=2,prepared_max_bytes_per_owner=2<<30,prepared_aggregate_logical_bytes=4<<30,refresh_rotation_cache='ordinary')
    report=dict(old.report)
    report.update(body_complete=True,termination_scope_completed=True,upload_retained=True,response_root_retained=True,
        source_count=286,source_hashes_start=sources,source_hashes_end=sources,execution_source_hashes_end=sources,
        source_archive_sha256=key_gate.digest((old.evidence/'sources.tar.gz').read_bytes()),reviewed_dependencies=preflight['dependency_readiness'],
        response_contract=contract,authenticated_tiles=old.requests['tiles'],worker_process=dict(direct_returncode=0,direct_child_reaped=True,group_empty_verified=True,cleanup_completed=True,cleanup_errors=[],pid=1001,process_group=1001))
    def save():
        write(old.evidence/'worker/worker_report.json',worker);report['worker_report_sha256']=key_gate.digest((old.evidence/'worker/worker_report.json').read_bytes());write(old.evidence/'report.json',report)
        return key_gate.digest((old.evidence/'report.json').read_bytes())
    def check():return g.authenticate(old.evidence,save(),old.root,response,keys=old.keys,model=old.model,requests=old.requests)
    return NS(check=check,save=save,report=report,worker=worker,evidence=old.evidence,root=old.root,response=response,keys=old.keys,model=old.model,requests=old.requests,resp=old.resp,batch=old.response,sources=sources)

def test_complete_synthetic_separate_response_no_payload_private_reads(case,monkeypatch):
    original=os.open;opened=[]
    def opening(path,*a,**kw):
        opened.append(str(path));assert not any(n in str(path)for n in ('ct_0.npz','bundle.json','client_private','requests.json','preprocessed'))
        return original(path,*a,**kw)
    monkeypatch.setattr(os,'open',opening);result=case.check()
    assert result['response_root']==str(case.response)and result['source_count']==286
    assert result['response_manifest_sha256']==case.resp['response_manifest_sha256']and result['payload_verification_still_required']is True
    assert not(case.root/'download').exists()and not(case.root/'server_report').exists()
    assert any('transport.json'in p for p in opened)

def test_external_terminal_hash_precedes_any_other_reads(case,monkeypatch):
    case.save();original=g.key_gate.read;seen=[]
    def reading(path,*a):seen.append(Path(path));return original(path,*a)
    monkeypatch.setattr(g.key_gate,'read',reading)
    with pytest.raises(ValueError,match='external'):g.authenticate(case.evidence,'0'*64,case.root,case.response,keys=case.keys,model=case.model,requests=case.requests)
    assert seen==[case.evidence/'report.json']

@pytest.mark.parametrize('flag',['passed','execute','body_complete','actual_server_compute','actual_execution_attempted','all_processes_reaped','external_workspaces_never_removed','operation_complete','cleanup_completed','termination_scope_completed','source_files_unchanged','source_archive_verified','upload_retained','response_root_retained'])
def test_actual_parent_flags_require_exact_true(case,flag):
    case.report[flag]=1
    with pytest.raises(ValueError,match='completed actual'):case.check()

@pytest.mark.parametrize('flag',['passed','body_complete','termination_scope_completed','cleanup_completed','actual_server_compute_started','actual_server_compute_completed','request_readback_complete','response_readback_complete','upload_payloads_unchanged','keygen_codecs_native_private_forbidden','source_files_unchanged','upload_retained','response_root_retained','external_workspaces_never_removed'])
def test_actual_worker_flags_require_exact_true(case,flag):
    case.worker[flag]=1
    with pytest.raises(ValueError,match='server-only'):case.check()

@pytest.mark.parametrize('flag',['key_generation','encryption','decryption','native_model_forward','client_private_read'])
def test_actual_worker_forbidden_phases_require_exact_false(case,flag):
    case.worker[flag]=0
    with pytest.raises(ValueError,match='boundaries'):case.check()

@pytest.mark.parametrize('field,value',[('direct_returncode',False),('direct_child_reaped',1),('group_empty_verified',1),('cleanup_completed',1),('cleanup_errors',['failure']),('pid',True)])
def test_direct_wait_and_owned_group_evidence(case,field,value):
    case.report['worker_process'][field]=value
    with pytest.raises(ValueError):case.check()

@pytest.mark.parametrize('field,value',[('prepared_rotation_cache',1),('prepared_graph_owners',True),('prepared_max_entries_per_owner',3),('prepared_max_bytes_per_owner',1<<30),('prepared_aggregate_logical_bytes',2<<30),('refresh_rotation_cache','prepared')])
def test_exact_prepared_owner_limits(case,field,value):
    case.worker[field]=value
    with pytest.raises(ValueError):case.check()

@pytest.mark.parametrize('field,value',[('level',1),('payload_bytes',1),('shape',[True,2,256,512,6]),('input_digest','0'*64),('scale',1.)])
def test_rehashed_wrong_response_summary_rejected(case,field,value):
    case.resp[field]=value
    with pytest.raises(ValueError,match='response readback'):case.check()

@pytest.mark.parametrize('field,value',[('response_root_identity',[1,2]),('upload_identity',[1,2]),('response_root','/tmp/other'),('sample_count',True),('original_io_download_used',True)])
def test_response_contract_is_typed_and_same_input_bound(case,field,value):
    case.report['response_contract'][field]=value
    with pytest.raises(ValueError,match='contract'):case.check()

def test_original_io_and_response_cannot_alias(case):
    with pytest.raises(ValueError):g.authenticate(case.evidence,case.save(),case.root,case.root,keys=case.keys,model=case.model,requests=case.requests)

def test_replaced_response_root_rejected(case,tmp_path):
    case.response.rename(tmp_path/'retained');case.response.mkdir()
    with pytest.raises(ValueError,match='identity'):case.check()

def test_symlink_response_root_rejected(case,tmp_path):
    target=tmp_path/'retained';case.response.rename(target);case.response.symlink_to(target,target_is_directory=True)
    with pytest.raises(ValueError,match='symlink'):case.check()

def test_symlink_download_subtree_rejected(case,tmp_path):
    path=case.response/'download';target=tmp_path/'retained-download';path.rename(target);path.symlink_to(target,target_is_directory=True)
    with pytest.raises(ValueError,match='ordinary'):case.check()

def test_payload_symlink_rejected_without_body_read(case,tmp_path):
    directory=case.response/'download'/case.batch['responses'][0]['request_id'];path=directory/'ct_0.npz';path.unlink();path.symlink_to(tmp_path/'never-read')
    with pytest.raises(ValueError,match='ordinary'):case.check()

def test_bad_final_scale_rejected_by_independent_plan(case):
    case.batch['responses'][0]['scale']=1.;write(case.response/'download/batch.json',case.batch)
    with pytest.raises(ValueError,match='scale'):case.check()

def test_worker_source_drift(case):
    case.worker['source_hashes_end']=dict(case.sources,extra='0'*64)
    with pytest.raises(ValueError,match='source inventory'):case.check()

def test_context_model_request_prerequisite_drift(case):
    case.worker['prerequisite']=dict(case.worker['prerequisite'],input_digest='0'*64)
    with pytest.raises(ValueError,match='chain'):case.check()

def test_changed_dependency_readiness_rejected(case):
    case.worker['reviewed_dependencies']=dict(case.worker['reviewed_dependencies'],ready=False)
    with pytest.raises(ValueError,match='prerequisite'):case.check()

@pytest.mark.parametrize('name',['combined_server_sources.json','combined_server_preflight.json','combined_server_preflight_sources.tar.gz'])
def test_local_reviewed_pin_rejects_substitution(case,monkeypatch,name):
    old=g.key_gate.read
    monkeypatch.setattr(g.key_gate,'read',lambda path,*a:old(path,*a)+(b' 'if Path(path)==g.HERE/name else b''))
    with pytest.raises(ValueError):case.check()

def test_archive_duplicate_rejected():
    raw=io.BytesIO()
    with tarfile.open(fileobj=raw,mode='w:gz')as tar:
        for _ in range(2):m=tarfile.TarInfo('x');m.size=1;tar.addfile(m,io.BytesIO(b'x'))
    with pytest.raises(ValueError,match='unique'):g._archive(raw.getvalue(),{'x':key_gate.digest(b'x')})
