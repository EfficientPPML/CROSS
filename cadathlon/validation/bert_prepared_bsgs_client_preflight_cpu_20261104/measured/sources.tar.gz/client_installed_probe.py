"""Fresh source-gated installed client denials; no context, key or data access."""
from pathlib import Path
import argparse,inspect,json,os,sys
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE/'runtime/stage'),str(HERE/'runtime')]
import client_io as io
import client_source_guard as sources

def run(source_manifest,source_manifest_sha256,output):
    if Path(output).exists()or Path(output).is_symlink():raise FileExistsError('fresh installed probe report required')
    io.environment();raw=io.read(source_manifest)
    if io.digest(raw)!=source_manifest_sha256:raise ValueError('external client source manifest differs')
    expected=io.parse(raw);initial=sources.check_sources(expected,HERE,fresh=True)
    from cleanup import termination_signals,cleanup_signals
    report=dict(passed=False,body_complete=False,cleanup_completed=False,termination_scope_completed=False,pid=os.getpid(),
        source_hashes_start=expected,source_guard_start=initial,actual_client_decode=False,actual_contexts=False,actual_keys=False,
        payload_reads=False,private_reads=False,native_model=False,scope='Installed client entrypoint denials/restoration and optional receipt API only')
    def body(r):
        import boundaries,client_keys,client_inputs,key_contexts,file_stages,request_lifecycle
        from jaxite_word import CKKSContext
        import key_gen
        from jaxite_word import key_gen as package_keys
        pairs=[(m,n)for m in (key_gen,package_keys)for n in ('gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen')]
        pairs += [(CKKSContext,n)for n in ('encrypt','encrypt_slots','encrypt_slots_batch','program_initialization')]
        pairs += [(client_keys,'generate'),(client_inputs,'ClientEmbeddings'),(key_contexts,'load_server'),
            (file_stages,'client_key_generation'),(file_stages,'server_preprocess_model'),(file_stages,'client_encode_encrypt_input'),
            (file_stages,'server_encrypted_compute'),(file_stages,'_snapshot'),(request_lifecycle,'retire_completed')]
        originals=[getattr(owner,name)for owner,name in pairs]
        allowed=[(CKKSContext,n,getattr(CKKSContext,n))for n in ('decrypt','decrypt_slots','decrypt_slots_batch','decode')]
        allowed.extend([(file_stages,'client_decrypt_decode',file_stages.client_decrypt_decode),(key_contexts,'load_client',key_contexts.load_client)])
        calls=[]
        with boundaries.client_only(calls):
            for owner,name in pairs:
                try:getattr(owner,name)(None)
                except RuntimeError as error:
                    if not str(error).startswith('forbidden stage5 action:'):raise
                else:raise ValueError('installed forbidden client entrypoint executed')
            if any(getattr(o,n)is not fn for o,n,fn in allowed):raise ValueError('allowed decode/load client changed')
        if len(calls)!=21 or len(set(calls))!=21 or any(getattr(o,n)is not fn for(o,n),fn in zip(pairs,originals)):raise ValueError('exact installed denial/restoration differs')
        for fn in (file_stages.client_decrypt_decode,request_lifecycle.record_completed):
            param=inspect.signature(fn).parameters['completion_directory']
            if param.kind is not inspect.Parameter.KEYWORD_ONLY or param.default is not None:raise ValueError('default completion API changed')
        if any(n.split('.')[0]in ('torch','transformers')for n in sys.modules):raise ValueError('native model module imported')
        r.update(denied_entries=calls,denied_count=21,all_forbidden_entries_restored=True,allowed_client_entries_unchanged=True,
            optional_completion_api_verified=True,source_guard_end=sources.check_sources(expected,HERE),source_hashes_end=io.hashes(sources.raw_sources(HERE)),
            body_complete=True,cleanup_completed=True,software=io.software_versions())
        r['source_files_unchanged']=r['source_hashes_end']==expected
        if not r['source_files_unchanged']:raise ValueError('installed client probe source drift')
    return io.finish(output,report,body,termination_signals,cleanup_signals)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source-manifest',type=Path,required=True);p.add_argument('--source-manifest-sha256',required=True);p.add_argument('--output',type=Path,required=True)
    r=run(**vars(p.parse_args()));print(json.dumps(dict(passed=r['passed'],denied_count=r['denied_count'])));raise SystemExit(0 if r['passed']else 1)
