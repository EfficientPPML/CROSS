"""Two fixed full-slot initial-softmax probes; client validation after all server work."""
from pathlib import Path
import gc,hashlib,math,os,sys,tempfile,time
import numpy as np
from lifecycle import CleanupTracker
from fixtures import definitions,make_scores,client_oracles,diagnostics,checkpoint_error,CHECKPOINTS
from public_contract import HERE,ROOT,preflight,INPUT_LEVEL
sys.path[:0]=[str(ROOT),str(ROOT/'cadathlon/common')]

def digest(value):return hashlib.sha256(np.asarray(value).tobytes()).hexdigest()
def keyless(context):
    if context.secret_key is not None or context._param_cache.secret_key is not None or context.parameters.get('secret_key') is not None:
        raise ValueError('server has secret key material')
def fingerprint(value,ops):
    metadata=tuple((name,type(getattr(value,name,None)).__name__,getattr(value,name,None)) for name in
        ('_ckks_scale','_ckks_nsd','batch','num_elements','degree','degree_layout','moduli'))
    return digest(value.polynomial),metadata,ops._level(value)

def run(report,phase):
    if os.environ.get('JAX_PLATFORMS')!='cpu':raise ValueError('explicit CPU backend required')
    import jax
    from jaxite_word import CKKSContext,ckks_ctx,key_gen
    from encrypted_ntt import enable_scoped_ntt_subsets
    from encrypted_packed_qwen import CompiledArithmetic
    from encrypted_refresh import ClientRotationKeyStore
    from encrypted_bert_initial_softmax import BertInitialSoftmax,InitialSoftmaxContract
    from encrypted_score_reduction import ScoreReductionLayout
    from support import require_secure_execution
    jax.config.update('jax_enable_x64',True)
    if jax.default_backend()!='cpu' or any(d.platform!='cpu' for d in jax.devices()):raise ValueError('CPU backend not honored')
    # The actual core security check and P coverage precede every keygen call.
    ring=preflight(actual_security=True);report['ring']=ring
    if ring['current_key_storage_free_bytes']<ring['raw_all_owned_public_key_bytes']+ring['additional_storage_margin_bytes']:
        raise ValueError('insufficient tmpfs key storage plus4GiB margin')
    contract=InitialSoftmaxContract.from_manifest_bytes((HERE/'candidate_manifest.json').read_bytes())
    client=server=ops=provider=store=parent=keys=evaluation=None
    graph=ct=value=output=checkpoints=layout=None
    inputs={};references={};input_fingerprints={};retained={};patches=[];codec_patches=[]
    def forbidden(*args,**kwargs):raise AssertionError('client codec/runtime key generation during keyless server arithmetic')
    try:
        parent=tempfile.TemporaryDirectory(prefix='cross-initial-softmax-keys-',dir='/dev/shm')
        report['owned_public_key_directory']=parent.name
        q,p,N,dnum=ring['q_towers'],ring['p_towers'],ring['degree'],ring['dnum']
        rotations=ring['rotation_indices'];scale=ring['scale']
        phase('actual secure profile and independent client fixture preflight complete')
        report['key_generation_started']=True;phase('client key generation starting')
        keys=key_gen.gen_pke_pair(q,[],N)
        evaluation=key_gen.gen_evaluation_key(keys['secret_key'],q=q,P=p,dnum=dnum)
        store=ClientRotationKeyStore.generate(keys['secret_key'],q,p,degree=N,dnum=dnum,rotations=rotations,directory=parent.name)
        report['actual_public_rotation_store_bytes']=sum(f.stat().st_size for f in Path(parent.name).rglob('*.npy'))
        params=dict(degree=N,num_slots=65536,scaling_factor=scale,output_scale=scale,q_towers=q,p_towers=p,
            composite_degree=2,degree_layout=(256,512),p=60,CKKS_M_FACTOR=1,max_bits_in_word=61,noise_scale_degree=1)
        client=CKKSContext(dict(params,**keys))
        server=CKKSContext(dict(params,evaluation_key=[jax.numpy.asarray(evaluation[n],dtype='uint32').transpose(0,2,1) for n in ('a','b')]))
        modules={key_gen,sys.modules.get('key_gen')}-{None}
        if {m.__name__ for m in modules}!={'jaxite_word.key_gen','key_gen'}:raise RuntimeError('both keygen aliases required')
        for module in modules:
            for name in ('gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen'):
                patches.append((module,name,getattr(module,name)));setattr(module,name,forbidden)
        report['key_generation_guards']={m.__name__:['gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen'] for m in modules}
        server.program_initialization(rotations,dnum=dnum,r=256,c=512,batch=1,pregenerated_rotation_keys=store.keys)
        keyless(server);report['keyless_server_initialized']=True
        client._polynomial_ntt_ctx=server._param_cache.ntt_q_max
        provider=enable_scoped_ntt_subsets(server)
        ops=CompiledArithmetic(server,low_memory=True,preserve_dispatch_cache=True)
        keys=evaluation=None
        for item in definitions():
            scores=make_scores(item);references[item['name']],details=client_oracles(scores,item,contract.exponential_coefficients)
            report['encryption_started']=True
            ct=client.encrypt_slots(scores)
            # Genuine level-prefix reduction preserves the represented input and
            # supplies the facade's explicit NSD1 state. No scale relabeling.
            ct=server.he_level_reduce[49,INPUT_LEVEL].level_reduce(ct)
            if type(ct._ckks_nsd)is not int or ct._ckks_nsd!=1 or ct._ckks_scale!=scale:raise RuntimeError('input metadata differs')
            require_secure_execution(server,ct);inputs[item['name']]=ct;input_fingerprints[item['name']]=fingerprint(ct,ops)
        scores=ct=None
        for name in ('encrypt','decrypt','encrypt_slots','decrypt_slots','encrypt_slots_batch','decrypt_slots_batch','decode'):
            codec_patches.append((CKKSContext,name,getattr(CKKSContext,name)));setattr(CKKSContext,name,forbidden)
        report['codec_guards']=[name for _,name,_ in codec_patches]
        phase('two independent inputs encrypted and reduced to level38; all codecs guarded')
        for item in definitions():
            layout=ScoreReductionLayout(item['key_mask'],valid_rows=item['valid_rows'])
            def progress(label,value,counts,fixture=item['name']):
                keyless(server);value.polynomial.block_until_ready()
                phase(fixture+' '+label,dict(level=ops._level(value),scale=value._ckks_scale,nsd=value._ckks_nsd,counts=counts))
            graph=BertInitialSoftmax(ops,layout,contract,progress=progress)
            output,checkpoints=graph.evaluate_tile(inputs[item['name']],capture_checkpoints=True)
            if set(checkpoints)!=set(CHECKPOINTS):raise RuntimeError('checkpoint inventory differs')
            for name,value in checkpoints.items():value.polynomial.block_until_ready();retained[(item['name'],name)]=value
            graph=output=checkpoints=value=None
            ops._clear_working_caches();phase(item['name']+' seven ciphertext checkpoints complete')
        keyless(server)
        report['input_payload_and_metadata_unchanged']=all(fingerprint(ct,ops)==input_fingerprints[name] for name,ct in inputs.items())
        if not report['input_payload_and_metadata_unchanged']:raise RuntimeError('server changed input ciphertext')
        if len(retained)!=14:raise RuntimeError('expected14 server checkpoints')
        report['server_complete_before_any_decode']=True;phase('all14 ciphertext checkpoints complete; final client validation begins')
        for module,name,original in codec_patches:setattr(module,name,original)
        codec_patches.clear()
        report['checks']={};report['final_diagnostics']={}
        levels=ring['plan']['levels'];scales={name:scale for name in CHECKPOINTS}
        scales['inverse']=ring['plan']['static_inverse_scale_plan']['rows'][-1]['scale'];scales['base_times_inverse']=ring['plan']['actual_product_scale']
        for item in definitions():
            layout=ScoreReductionLayout(item['key_mask'],valid_rows=item['valid_rows'])
            for name in CHECKPOINTS:
                value=retained[(item['name'],name)];decoded=np.asarray(client.decrypt_slots(value));expected=references[item['name']][name]
                check=checkpoint_error(decoded,expected);finite=check['shape_and_finite']
                metadata=ops._level(value)==levels[name] and type(value._ckks_nsd)is int and value._ckks_nsd==1 and value._ckks_scale==scales[name]
                check.update(passed=bool(check['passed'] and metadata),slots_checked=65536,
                    level=ops._level(value),scale=value._ckks_scale,nsd=value._ckks_nsd,
                    expected_scale=scales[name],metadata_ok=metadata,execution_rings=require_secure_execution(server,value))
                if name in ('normalized_t','mean_exp'):
                    bounds=(-1.,1.) if name=='normalized_t' else (.5,2.)
                    check['declared_domain_diagnostic']={'domain':bounds,'all_decoded_values_in_domain':bool(finite and np.all((decoded>=bounds[0])&(decoded<=bounds[1])))}
                report['checks'][item['name']+':'+name]=check
                if name=='probabilities':report['final_diagnostics'][item['name']]=diagnostics(decoded,item,layout.input_mask)
        report['provider_stats']=dict(provider.stats)
        report['passed']=len(report['checks'])==14 and all(x['passed'] for x in report['checks'].values())
        phase('client all-slot validation complete')
    finally:
        tracker=CleanupTracker(sys.exception());attempt=tracker.attempt
        for module,name,original in codec_patches:attempt('restore codec',lambda:setattr(module,name,original))
        if provider is not None:attempt('provider.close',provider.close)
        if ops is not None:
            attempt('rotation.clear',lambda:ops.rotation.clear(executables=True))
            for helper in (ops._plaintext_multiply,ops._rescale):attempt('primitive.clear',lambda:helper.clear(executables=True))
            attempt('multiply compiler.clear',ops._multiplication_compiler.clear_executables)
        for context in (server,client):
            if context is not None:attempt('evict context',lambda:ckks_ctx.evict_context_caches(context))
        graph=ct=value=output=checkpoints=layout=keys=evaluation=ops=server=client=None
        retained.clear();inputs.clear();references.clear();input_fingerprints.clear()
        attempt('jax.clear_caches',jax.clear_caches);attempt('gc.collect',gc.collect)
        if store is not None:attempt('store.close',store.close)
        if parent is not None:attempt('owned key parent cleanup',parent.cleanup)
        for module,name,original in patches:attempt('restore keygen',lambda:setattr(module,name,original))
        report['cleanup_errors']=tracker.errors
        report['cleanup_completed']=not tracker.errors
        report['owned_key_directory_removed']=parent is None or not Path(parent.name).exists()
        report['passed']=bool(report.get('passed') and not tracker.errors and report['owned_key_directory_removed'])
        tracker.finish()
