"""Source-bound serializer/schema tests, not encrypted numerical evidence."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time,shutil,stat,signal
LAB=Path('/tmp/bert-full-model-transport-20261103');OUT=LAB/'source-bound-v1'
FILES={n:LAB/n for n in ('transport.py','transport_contract.py','test_transport.py','bundle_io.py','p60_profile_and_refresh.json','README.md')}
FILES.update({'client_inputs.py':Path('/tmp/bert-full-model-file-stages-20261103/client_inputs.py'),
 'historical_ffn_transport.py':Path('/tmp/bert-ffn-file-component-20261103/prototype/transport.py'),
 'check_full_model_transport.py':Path(__file__)})
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
 OUT.mkdir(exist_ok=False);before={n:sha(p) for n,p in FILES.items()}
 archive=OUT/'sources.tar.gz'
 with tarfile.open(archive,'w:gz') as tf:
  for n,p in FILES.items():tf.add(p,arcname=n,recursive=False)
 with tarfile.open(archive) as tf:
  ms=tf.getmembers();assert len(ms)==len(before)==len({m.name for m in ms}) and all(m.isfile() for m in ms)
  assert {m.name:hashlib.sha256(tf.extractfile(m).read()).hexdigest() for m in ms}==before
 workspace=OUT/'owned-test-workspace';workspace.mkdir();fd=os.open(workspace,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW);ident=os.fstat(fd)
 command=[sys.executable,'-m','pytest','-q','test_transport.py','--basetemp',str(workspace/'pytest')]
 p=None;primary=None;cleanup=[];removed=False;closed=False;start=time.monotonic();rc=None
 env=dict(os.environ,OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',MKL_NUM_THREADS='4')
 try:
  with (OUT/'tests.log').open('w') as log:
   p=subprocess.Popen(command,cwd=LAB,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);rc=p.wait()
 except BaseException as error:primary=error
 finally:
  if p is not None and p.poll() is None:
   try:os.killpg(p.pid,signal.SIGKILL);rc=p.wait()
   except BaseException as error:cleanup.append(repr(error))
  try:
   held=os.fstat(fd);current=workspace.lstat()
   if (held.st_dev,held.st_ino)!=(ident.st_dev,ident.st_ino) or (current.st_dev,current.st_ino)!=(ident.st_dev,ident.st_ino) or not stat.S_ISDIR(current.st_mode):raise RuntimeError('test workspace replaced; retained')
   if p is not None and p.poll() is None:raise RuntimeError('test process not reaped; retained')
   shutil.rmtree(workspace);removed=True
  except BaseException as error:cleanup.append(repr(error))
  try:os.close(fd);closed=True
  except BaseException as error:cleanup.append(repr(error))
 after={n:sha(p) for n,p in FILES.items()}
 report=dict(passed=primary is None and rc==0 and not cleanup and removed and closed and before==after,
  tests=71,scope=__doc__,exit_code=rc,child_pid=None if p is None else p.pid,child_reaped=p is not None and p.poll() is not None,
  owned_workspace_removed=removed,owned_handle_closed=closed,cleanup_errors=cleanup,error=None if primary is None else repr(primary),
  source_before=before,source_after=after,source_files_unchanged=before==after,source_files=len(before),source_archive_sha256=sha(archive),
  elapsed_s=time.monotonic()-start,command=command,cpu_affinity=sorted(os.sched_getaffinity(0)),
  thread_caps={k:env[k] for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')},python=sys.version,
  raw_payloads_archived=False,actual_ciphertexts_tested=False)
 (OUT/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
 print(json.dumps({k:report[k] for k in ('passed','tests','exit_code','child_reaped','source_files','source_archive_sha256','elapsed_s')}))
 if primary is not None:raise primary
 return 0 if report['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
