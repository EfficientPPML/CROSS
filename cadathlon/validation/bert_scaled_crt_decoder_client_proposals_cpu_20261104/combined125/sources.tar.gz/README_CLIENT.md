# Separate-response size0 client preparation

This isolated successor authenticates the completed 286-source prepared-cache/BSGS server and its separate response root. It does not launch a client or server, establish encrypted accuracy, or authorize a ranked workload. The original ordinary server, download and request ledger remain owned by their existing jobs.

The historical115 predecessor retained the reviewed89 client with five initial overlays: three reader cleanup changes in client_keys/key_contexts/file_stage_io and two receipt API changes: `file_stages.client_decrypt_decode(..., completion_directory=None)` and `request_lifecycle.record_completed(..., completion_directory=None)`. Defaults preserve the original path and call. An explicit private 0700 result root receives both decoded output and completion receipt; the original `client_private` keys and requests remain read-only. No retirement is performed. Synthetic AST comparisons bind original default behavior.

The fresh worker validates every selected source and installed local origin before gate/runtime imports. Externally hashed public fixture/reference reports identify protected private roots before any worker report publication; startup failures before that authorization leave the worker report unwritten and are captured by its parent. All result/evidence roots must be disjoint from borrowed roots, including ancestor/nested/resolved aliases.

Public gates bind key/model/input producers, the exact reviewed 286-source server preparation and actual terminal server proof, ordered request and response metadata, and a separate response inode. Public response payload headers/residues/digests are validated before the first private input/reference/key access. Metadata-only gate acceptance alone is insufficient. Private readback verifies the same target, unchanged size0 P2 absolute/relative and prediction checks, the isolated receipt and original request binding. A completed numerical failure remains failed while retaining useful result evidence. This is a single K32 size0 contract; ranked acceptance is different and not implemented here.

All attempts retain owned outputs and all borrowed workspaces. Held inodes are checked around the handler and final receipt. Cleanup attempts every release, preserves a body primary and cleanup-only cancellation priority, and quarantines uncertain closes without blind retries. A successful report is published only after termination handler restoration. The collector creates an immutable execution copy, binds worker reports instead of stdout, requires direct reaping and empty owned process group, and uses 30-second graceful TERM/KILL cleanup only after failure or cancellation; healthy work has no timeout.

`client_preflight.py OUTPUT --expected-tests N` runs the explicit synthetic suite plus a fresh native-environment installed probe. The probe invokes and denies all 21 forbidden keygen/encryption/server/native/retirement entrypoints, verifies restoration and unchanged allowed decode/load-client methods, and constructs no context/key/model. It reads no retained ciphertext or private body. Source archives use explicit 16 MiB/member and 32 MiB total bounds. Only public source/report/log/XML evidence may be archived; private result/reference/key/payload files must never be copied.

Successor v2 preserves the completed115-source predecessor unchanged in its original lab/archive. The copied receipt observer uses bounded os.read for direct and batch metadata; nested tree and observation scopes share the same cleanup-origin state. The copied client_keys readers use bounded descriptor reads/hashing; key_contexts uses non-owning stream wrappers for NPY/memmap parsing and mapped-owner cleanup; file_stage_io passes shared cleanup state through read_manifest. These changes preserve genuine body primary identity, promote cleanup-only cancellation over ordinary cleanup errors, attempt each owned release once, and retain uncertain owners without retry. Successful formats/schema and default destinations remain unchanged, and key-generation provenance values are preserved. Original negative capsules and narrow development repairs remain separate evidence. New synthetic tests cover all confirmed reachable reader variants; no retained data/key/ciphertext bodies are used.

## New separately frozen successor of117

This fresh lab preserves the exact117 parent archive and ports the reviewed original122 active-reader and actual CLI bootstrap fixes. Additional reader changes are only top-level key_gate/input_gate and runtime transport; all combined286 metadata gate, separate response ownership, optional completion_directory/default semantics, arithmetic and original P2 gates remain unchanged. Both actual CLIs require externally pinned source-manifest bytes before local imports and isolated no-bytecode startup (-I -B). Fresh trees reject undeclared importable source/package/bytecode/native shadows and preloaded local aliases. Collector source identity remains bound through archive/execution copy. Actual client still requires independently completed286 evidence and a distinct launch grant.

The explicit closure contains125 sources. Against original89 there are9 permitted overlays and80 unchanged files; all new changes relative to historical117 are separately reviewable. The selected reader map is READERS.md. Historical117 is not relabeled as launch-ready. No private/retained payload reads occur in preparation, and no original request/completion ledger is written by this component.

## Source-only decoder proposal

This new isolated proposal copies the completed clean consumer closure and adds
the reviewed `ckks_ctx.py` decoder SHA 9675b300d507fd9c6a3d03656c9df325d8da68a9331b4c92def0512784d0dc26.
It changes only the host conversion of centered CRT coefficients: the existing
`float(value) * scale_inv` path remains exact when conversion succeeds, and an
overflowing conversion uses the exact binary64 scale ratio. FFT, approximation
validation, decryption, ciphertext/key formats, parameter profile, lifecycle and
P2 acceptance are unchanged. The local guard explicitly admits this decoder;
all old producer source maps and gates remain literal predecessor bytes.

Only four files differ from the clean122/125 parent: this README, the decoder,
the guard's overlay dictionary, and the existing source-guard test expectation
plus decoder/alias assertions. No new test case or selected entrypoint is added.
The historical client preflight does not attest these new bytes: this proposal
has had source/AST/hash inspection only, with no backend import, installed probe,
full preflight, payload/private read or client execution. A separately reviewed
complete client proof and launch grant remain required.

The authenticated final BERT L2 response has six fixed Q towers: their product
is181 bits and centered coefficients are at most180 bits. This final boundary
therefore uses the unchanged successful-float path. The proposal is compatible
decoder robustness preparation, not a claimed fix for an observed full-BERT
failure, evidence of numerical accuracy, or recovery of the separate toy5 run.
Keep the actual source copy free of bytecode/import shadows and launch only via
the existing isolated externally pinned CLI. Do not rewrite old producer maps
to the new consumer hash or touch any current server response/request ledger.
