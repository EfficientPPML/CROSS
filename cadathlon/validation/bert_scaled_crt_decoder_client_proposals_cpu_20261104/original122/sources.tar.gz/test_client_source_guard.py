from pathlib import Path
from types import SimpleNamespace
import shutil,sys,pytest
import client_source_guard as g

@pytest.fixture
def source(tmp_path):
 raw=g.raw_sources();root=tmp_path/'source';root.mkdir()
 for n,b in raw.items():p=root/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 return root,g.io.hashes(raw)

def test_complete_static_closure_and_eight_overlays(source):
 root,expected=source;r=g.check_sources(expected,root,modules={})
 assert r['passed']and r['parent_source_count']==89 and len(r['overlays'])==8
 assert r['critical_resolution']['file_stages']=='runtime/stage/file_stages.py'
 assert r['critical_resolution']['client_installed_probe']=='client_installed_probe.py'
 assert r['overlays']['runtime/jaxite_word/ckks_ctx.py']=='9675b300d507fd9c6a3d03656c9df325d8da68a9331b4c92def0512784d0dc26'
 assert r['critical_resolution']['ckks_ctx']==r['critical_resolution']['jaxite_word.ckks_ctx']=='runtime/jaxite_word/ckks_ctx.py'
 assert all(v in expected for v in r['reachable_local_modules'].values())

@pytest.mark.parametrize('name',['client_io.py','original_client_worker.py','stage4_gate.py','runtime/stage/transport.py'])
def test_missing_source_rejected(source,name):
 root,expected=source;(root/name).unlink()
 with pytest.raises((ValueError,FileNotFoundError)):g.check_sources(expected,root,modules={})

@pytest.mark.parametrize('name',['client_io.py','runtime/stage/file_stages.py','baseline/request_lifecycle.py'])
def test_changed_source_rejected(source,name):
 root,expected=source;(root/name).write_bytes((root/name).read_bytes()+b'\n# drift\n')
 with pytest.raises(ValueError):g.check_sources(expected,root,modules={})

@pytest.mark.parametrize('name',['file_stages','client_io','key_gate'])
def test_wrong_preloaded_module_path(source,tmp_path,name):
 root,expected=source;wrong=tmp_path/'wrong.py';wrong.write_text('pass')
 with pytest.raises(ValueError,match='path differs'):g.check_sources(expected,root,modules={name:SimpleNamespace(__file__=str(wrong))})

@pytest.mark.parametrize('name',['key_gate','boundaries','file_stages','original_client_worker'])
def test_fresh_rejects_preloaded_runtime(source,name):
 root,expected=source;r=g.check_sources(expected,root,modules={});path=root/r['critical_resolution'][name]
 with pytest.raises(ValueError,match='preloaded'):g.check_sources(expected,root,fresh=True,modules={name:SimpleNamespace(__file__=str(path))})

def test_preloaded_spec_origin_rejected(source,tmp_path):
 root,expected=source;m=SimpleNamespace(__file__=str(root/'client_io.py'),__spec__=SimpleNamespace(origin=str(tmp_path/'wrong.py')))
 with pytest.raises(ValueError,match='origin'):g.check_sources(expected,root,modules={'client_io':m})

def test_uncaptured_local_import_rejected(source):
 root,expected=source;p=root/'client_io.py';p.write_text(p.read_text()+'\nimport unrecorded_local\n');(root/'unrecorded_local.py').write_text('pass')
 expected=expected|{'client_io.py':g.io.digest(p.read_bytes())}
 with pytest.raises(ValueError,match='uncaptured'):g.check_sources(expected,root,modules={})

def test_static_shadow_rejected(source):
 root,expected=source;(root/'file_stages.py').write_text('pass')
 with pytest.raises(ValueError,match='uncaptured|resolution'):g.check_sources(expected,root,modules={})

def test_source_symlink_rejected(source):
 root,expected=source;p=root/'client_io.py';p.rename(root/'saved');p.symlink_to(root/'saved')
 with pytest.raises(ValueError,match='symlink'):g.check_sources(expected,root,modules={})
