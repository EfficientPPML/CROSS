# Original217 stage5 descriptor successor (preparation)

Exact89 parent plus five named runtime IO overlays, two top-level consumer reader overlays and one reviewed decoder overlay. The handler, original default completion receipt destination, old217 server source gate, all prior producer identities, encrypted arithmetic and P2 gates are unchanged; the decoder change is described below. The modern source-gated worker/collector and bounded private readback are explicit new consumer files; historical wrappers remain captured and unselected. No combined286 gate, response root or optional completion API is imported or accepted. Current preparation uses synthetic inputs only, with installed denied-entry probes. Actual decode needs independent completed217 evidence and a separate root launch grant.

The selected entrypoints are `original_client_worker.py` and `original_client_collect.py`; inherited `worker.py`, `collect.py`, `preflight.py` and the old consumer `dependencies.check()` are provenance only and unselected. The old dependency JSON remains exact because the original217 producer gate uses its separately reviewed source inventory. The successor's loader identity is checked by the explicit current source guard, never substituted into old key-generation or producer provenance.

The private readback uses bounded descriptor IO from `client_io`; the original P2 comparator is unchanged. Completed numeric failure produces complete retained evidence with `passed:false` and exit1. An original completed receipt must be absent before decoding. Only that default receipt may be added to the original private directory; every preexisting key/request file and its metadata remain checked. No receipt or borrowed artifact is retired. Result/evidence paths must be disjoint from all borrowed trees, including both publicly authenticated private fixture/reference roots, before publication. Source bootstrap failure cannot write a worker report into an unauthenticated location.

The static source guard captures122 sources (89 parent plus33 explicitly named files), with exactly eight replacements (six runtime, two top-level gates) and81 unchanged parent files. The new source archive uses32MiB total/16MiB member limits; original producer bounds remain unchanged. Preparation includes all confirmed descriptor/read/stream/tree/write cleanup regressions, source/phase/terminal tests, the exact old217 gate, default receipt tests and21 installed forbidden entrypoint calls. No retained input, reference, key, model or ciphertext is read during preparation. The source-bound run executes from frozen HERE; the actual collector, if separately authorized later, creates an exact execution copy.

The selected reader call graph and explicit exclusions are in READERS.md. The earlier114 draft is preserved separately before the expanded key_gate/input_gate/transport repairs. Public producer authentication logic and independently pinned inventories remain unchanged even where their shared current-consumer byte reader is repaired.

Actual entry CLIs require isolated Python startup (`python -I -B`) and caller-pinned `--source-manifest`/`--source-manifest-sha256`. Before importing any local helper, inline stdlib bootstrap verifies entry and bootstrap bytes against that external manifest digest, then the authenticated bootstrap checks every explicit source and rejects preloaded local helpers. Only then are client helpers/gates importable. The collector passes an exact current execution manifest to its isolated worker. In-process test APIs are not an untrusted import sandbox; fresh actual CLI bootstrap is the claimed boundary.

Fresh actual source trees must contain no undeclared Python source, bytecode or native-extension file, including namespace-package shadows. Bootstrap rejects all source-tree symlinks and unknown-name preloaded modules whose file or spec origin points inside the source tree. The actual isolated collector/worker disable bytecode writes; source copies are made only from the explicit manifest. This detects ordinary import substitution and does not claim an OS sandbox against concurrent same-user mutation.

## Source-only decoder proposal

This new isolated proposal copies the completed clean consumer closure and adds
the reviewed `ckks_ctx.py` decoder SHA 9675b300d507fd9c6a3d03656c9df325d8da68a9331b4c92def0512784d0dc26.
It changes only the host conversion of centered CRT coefficients: the existing
`float(value) * scale_inv` path remains exact when conversion succeeds, and an
overflowing conversion uses the exact binary64 scale ratio. FFT, approximation
validation, decryption, ciphertext/key formats, parameter profile, lifecycle and
P2 acceptance are unchanged. The local guard explicitly admits this decoder;
all old producer source maps and gates remain literal predecessor bytes.

Only four files differ from the clean122/125 parent: this README, the decoder,
the guard's overlay dictionary, and the existing source-guard test expectation
plus decoder/alias assertions. No new test case or selected entrypoint is added.
The historical client preflight does not attest these new bytes: this proposal
has had source/AST/hash inspection only, with no backend import, installed probe,
full preflight, payload/private read or client execution. A separately reviewed
complete client proof and launch grant remain required.

The authenticated final BERT L2 response has six fixed Q towers: their product
is181 bits and centered coefficients are at most180 bits. This final boundary
therefore uses the unchanged successful-float path. The proposal is compatible
decoder robustness preparation, not a claimed fix for an observed full-BERT
failure, evidence of numerical accuracy, or recovery of the separate toy5 run.
Keep the actual source copy free of bytecode/import shadows and launch only via
the existing isolated externally pinned CLI. Do not rewrite old producer maps
to the new consumer hash or touch any current server response/request ledger.
