"""Closed stdlib-only focused tests; no original bodies or actual backends."""
import importlib.abc
from pathlib import Path
import sys
import pytest

ROOT=Path(__file__).parent
FORBIDDEN={'numpy','jax','jaxlib','jaxite_word','libtpu','torch','tensorflow','flax','torch_xla','transformers','safetensors','tokenizers'}
assert not any(n.split('.')[0]in FORBIDDEN for n in sys.modules)
class Deny(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0]in FORBIDDEN:raise PermissionError('actual backend forbidden in focused stdlib fixtures')
sys.meta_path.insert(0,Deny())
sys.path.insert(0,str(ROOT/'runtime'))

@pytest.fixture(autouse=True)
def no_actual_backend():
    yield
    assert not any(n.split('.')[0]in FORBIDDEN for n in sys.modules)

@pytest.fixture
def runtime_root():return ROOT/'runtime'
