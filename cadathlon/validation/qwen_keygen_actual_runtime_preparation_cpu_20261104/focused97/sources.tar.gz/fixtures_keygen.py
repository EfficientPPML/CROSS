"""Explicit non-authoritative fake policies/owners, with tiny new owned files.

No actual proof, key material, numerical arrays, core primitive or RNG appears.
These fixtures isolate new process wiring; pure authority semantics have their
own previously admitted suites and are not claimed to run here.
"""
import hashlib,json,os,stat
from pathlib import Path
from types import SimpleNamespace,ModuleType
from qwen_file_contract import canonical,sha
import keygen_dependencies as kd

def H(text):return hashlib.sha256(text.encode()).hexdigest()
def parent_bytes(path):
    s=path.lstat();return canonical(dict(path=str(path),device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode)))
def lexical(value):
    if type(value)is not str or not value.startswith('/')or '..'in Path(value).parts:raise ValueError('synthetic canonical path')
    return Path(value)

def policy_fixture(tmp_path,monkeypatch):
    # Policy parsing uses only declared lexical paths. No real kernel path is
    # inspected; capacity tests replace kernel_read/statvfs/listdir explicitly.
    monkeypatch.setattr(kd,'canonical_path',lexical)
    library=tmp_path/'installed';library.mkdir()
    files={}
    for name in ('jax.py','jaxlib.py','numpy.py'):
        p=library/name;p.write_text('# synthetic installed source, never imported\n')
        files[str(p)]=dict(sha256=sha(p.read_bytes()),size=p.stat().st_size)
    source=H('SYNTHETIC current source');archive=H('SYNTHETIC source archive')
    dep=dict(schema='qwen-keygen-cpu-dependencies-v1',interpreter=str(tmp_path/'python-link'),resolved_interpreter=str(tmp_path/'python-real'),
        python_major_minor=[3,13],cores=[112,113,114,115],environment=dict(JAX_PLATFORMS='cpu',JAX_ENABLE_X64='true',CROSS_NP_KEYGEN='1',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',MKL_NUM_THREADS='4'),
        installed_sources=files,library_roots=[str(library)],backend_module_origins={name:dict(file=str(library/(name+'.py')),spec=str(library/(name+'.py')))for name in ('jax','jaxlib','numpy')})
    res=dict(schema='qwen-keygen-runtime-resources-v1',cores=[112,113,114,115],threads=4,import_headroom_bytes=8<<30,working_headroom_bytes=32<<30,host_reserve_bytes=8<<30,live_object_allowance_bytes=8<<30,descriptor_margin=16,minimum_soft_nofile=512,evidence_disk_bytes=1<<20,cgroup_memory_current='/sys/fs/cgroup/FAKE/memory.current',cgroup_memory_max='/sys/fs/cgroup/FAKE/memory.max')
    from keygen_authority import GRANT_SCOPE
    role=dict(schema='qwen-keygen-runtime-role-policy-v1',role='generate_fresh_qwen166_keys',source_manifest_sha256=source,scope=GRANT_SCOPE)
    def build(dep=dep,res=res,role=role):
        raws=dict(dependency_policy_sha256=canonical(dep),resource_policy_sha256=canonical(res),role_policy_sha256=canonical(role))
        review=dict(schema='qwen-keygen-resource-policy-review-v1',passed=True,source_manifest_sha256=source,source_archive_sha256=archive,dependency_policy_sha256=sha(raws['dependency_policy_sha256']),resource_policy_sha256=sha(raws['resource_policy_sha256']),working_assumptions_reviewed=True,actual_execution_authorized=False)
        raws['resource_review_sha256']=canonical(review);return raws,{n:sha(v)for n,v in raws.items()}
    return SimpleNamespace(dep=dep,res=res,role=role,source=source,archive=archive,build=build)

def install_generation_recording(monkeypatch,tmp_path,*,fault=None,body=None):
    import keygen_process as kp
    events=[];owners=[];secret=[[1,-1]];rotations=tuple(range(1,167));shape=(1,2,2)
    class Spec:
        def __init__(self,name):self.name=name;self.shape=shape
        def validate(self,row):assert row['synthetic'] is True
    specs=[Spec('public_key.npy'),Spec('relin_a.npy'),Spec('relin_b.npy')]+[Spec(f'rot_{i}_{p}.npy')for i in rotations for p in('a','b')]
    profile=SimpleNamespace(parameters=dict(q_towers=[3],p_towers=[5],degree=2,dnum=1,sigma=1.),arrays=tuple(specs),secret=Spec('secret.npy'),rotations=rotations)
    paths={n:str(tmp_path/n)for n in('public_root','private_root','evidence_root')}
    iv=dict(paths=paths,model_id=H('model'),request_producer_source_manifest_sha256=H('request'),response_consumer_source_manifest_sha256=H('response'))
    grant=canonical(dict(parents={n:json.loads(parent_bytes(tmp_path))for n in paths}))
    launch=SimpleNamespace(intent=SimpleNamespace(check=lambda:iv),grant_bytes=grant,check=lambda:events.append('launch_check'))
    class Store:
        def __init__(self,path,specs,*,expected_parent,private,shield):
            assert expected_parent==parent_bytes(tmp_path)
            self.root=Path(path);self.parent_path=tmp_path;self.role='private'if private else'public';self.records={};self.files=[];self.closed=False
            events.append('construct_'+self.role)
            if fault=='second_constructor'and private:raise body
            self.root.mkdir();self.parent=SimpleNamespace(fd=os.open(tmp_path,os.O_RDONLY|os.O_DIRECTORY))
            self.directory=SimpleNamespace(fd=os.open(self.root,os.O_RDONLY|os.O_DIRECTORY));owners.append(self)
        def check(self):events.append('check_'+self.role)
        def identity(self):return 'synthetic-only'
        def write_array(self,name,value):
            assert type(value)is list or type(value)is str
            if name=='secret.npy':assert value is secret
            self.records[name]=dict(synthetic=True);events.append(('array',name));return self.records[name]
        def verify(self):return dict(self.records)
        def write_manifest(self,raw):
            p=self.root/(self.role+'_manifest.json');fd=os.open(p,os.O_RDWR|os.O_CREAT|os.O_EXCL,0o600);os.write(fd,raw)
            self.files.append(SimpleNamespace(name=p.name,fd=fd,readback=lambda:None));events.append('manifest_'+self.role);return raw
        def close(self,primary=None):
            events.append('close_'+self.role)
            for f in self.files:os.close(f.fd)
            os.close(self.directory.fd);os.close(self.parent.fd);self.closed=True
            if fault=='close_cleanup':
                if self.role=='private':raise OSError('SYNTHETIC cleanup only')
                raise KeyboardInterrupt('SYNTHETIC later cancellation')
            if fault=='body_close_rethrow':raise body
    fake=ModuleType('qwen_key_store');fake.KeyStore=Store;monkeypatch.setitem(__import__('sys').modules,'qwen_key_store',fake)
    def switch():return dict(a='SYNTHETIC a',b='SYNTHETIC b',modulus=dict(Q=[3],P=[5]),P=[5],shape=shape)
    def pke(q,P,degree,**kw):events.append('pke');assert(q,P,degree)==([3],[],2);return dict(public_key='SYNTHETIC pke',secret_key=secret)
    def evk(s,**kw):events.append('evk');assert s is secret;return switch()
    def rotate(s,q,P,index,**kw):
        events.append(('rotate',index));assert s is secret
        if index==2 and fault in('rotation_body','body_close_rethrow'):raise body
        if index==2 and fault=='replace_close':owners[0].close=lambda **kw:events.append('MUTATED_CLOSE_CALLED')
        return {index:switch()}
    values=(('gen_pke_pair',pke),('gen_evaluation_key',evk),('gen_rotation_key',rotate),('KEY_GENERATION_VERSION',3))
    core=SimpleNamespace(check=lambda:events.append('core_check'),retain=lambda n,a:SimpleNamespace(values=values,check=lambda:events.append('lease_check')))
    monkeypatch.setattr(kp,'public_body',lambda profile,arrays,keygen:dict(arrays=arrays,synthetic=True))
    monkeypatch.setattr(kp,'authenticate_public',lambda raw,*a,**kw:raw)
    monkeypatch.setattr(kp,'authenticate_private',lambda raw,*a,**kw:None)
    from contextlib import nullcontext
    monkeypatch.setattr(kp,'cleanup_signals',nullcontext)
    checks={n:False for n in kp.CHECK_NAMES};counts=dict(pke_pairs=0,evaluation_key_pairs=0,rotation_key_pairs=0,primitive_calls=0,public_arrays=0,private_arrays=0,public_files=0,private_files=0)
    return SimpleNamespace(module=kp,launch=launch,profile=profile,core=core,checks=checks,counts=counts,events=events,owners=owners,secret=secret,source_check=lambda:events.append('source_check'))
