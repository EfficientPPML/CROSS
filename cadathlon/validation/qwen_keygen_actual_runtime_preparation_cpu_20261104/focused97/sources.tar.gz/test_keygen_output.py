"""New tiny owned filesystem fixtures only; no existing stores are touched."""
import json,os,stat
from pathlib import Path
import pytest
from qwen_file_contract import canonical
import keygen_output as out
from fixtures_keygen import parent_bytes

@pytest.mark.parametrize('case',['missing','mutable','pretty','bool_inode','extra','wrong_path'])
def test_parent_binding_is_required_canonical_typed_before_open(tmp_path,monkeypatch,case):
    raw=parent_bytes(tmp_path);v=json.loads(raw);calls=[]
    if case=='mutable':raw=bytearray(raw)
    elif case=='pretty':raw=(json.dumps(v,indent=2)+'\n').encode()
    elif case=='bool_inode':v['inode']=True;raw=canonical(v)
    elif case=='extra':v['ready']=True;raw=canonical(v)
    elif case=='wrong_path':v['path']=str(tmp_path/'other');raw=canonical(v)
    def deny(*a,**kw):calls.append(a);raise AssertionError('opened before validating external parent')
    with monkeypatch.context()as m:
        m.setattr(out.os,'open',deny)
        with pytest.raises((TypeError,ValueError)):
            if case=='missing':out.Output(str(tmp_path/'new'))
            else:out.Output(str(tmp_path/'new'),expected_parent=raw)
    assert calls==[]

def test_parent_replacement_between_precheck_and_open_rejects_before_mkdir(tmp_path,monkeypatch):
    parent=tmp_path/'parent';parent.mkdir();raw=parent_bytes(parent);native=os.open;observed=[]
    def opening(path,*args,**kw):
        if Path(path)==parent and not observed:
            parent.rename(tmp_path/'original_parent');parent.mkdir()
            fd=native(path,*args,**kw);observed.append(fd);return fd
        return native(path,*args,**kw)
    with monkeypatch.context()as m:
        m.setattr(out.os,'open',opening)
        with pytest.raises(ValueError,match='parent identity'):out.Output(str(parent/'leaf'),expected_parent=raw)
    assert not(parent/'leaf').exists()and not(tmp_path/'original_parent'/'leaf').exists()
    with pytest.raises(OSError):os.fstat(observed[0])

@pytest.mark.parametrize('case',['untrusted_uid','writable_nonsticky','sticky_owned'])
def test_parent_uid_sticky_policy_uses_disclosed_stat_seam(tmp_path,monkeypatch,case):
    owner=out.Output(str(tmp_path/'leaf'),expected_parent=parent_bytes(tmp_path))
    from types import SimpleNamespace
    native=out.os.fstat;orig_lstat=Path.lstat
    uid=os.geteuid()+10000 if case=='untrusted_uid'else os.geteuid()
    mode=0o777 if case=='writable_nonsticky'else 0o1777 if case=='sticky_owned'else stat.S_IMODE(tmp_path.stat().st_mode)
    # This source-only policy seam models stat results; it is not a real UID or permission change.
    v=json.loads(owner.expected_parent);v['mode']=mode
    owner.expected_parent=canonical(v);owner.parent_expectation=(str(tmp_path),v['device'],v['inode'],mode)
    owner._fixed=(owner.path,owner.parent,owner.expected_parent,owner.parent_expectation,owner.effective_uid)
    owner.parent_uid=uid;owner._parent_uid_fixed=uid
    def altered(s):return SimpleNamespace(st_mode=stat.S_IFDIR|mode,st_dev=s.st_dev,st_ino=s.st_ino,st_uid=uid)
    with monkeypatch.context()as m:
        m.setattr(out.os,'fstat',lambda fd:altered(native(fd))if fd==owner.parent_fd else native(fd))
        m.setattr(Path,'lstat',lambda p,*a,**kw:altered(orig_lstat(p,*a,**kw))if p==tmp_path else orig_lstat(p,*a,**kw))
        if case=='sticky_owned':owner._parent_check()
        else:
            with pytest.raises(ValueError,match='trusted owned or sticky'):owner._parent_check()
    owner.close()

def test_tiny_evidence_write_and_reopen_keep_external_parent_and_original_uid(tmp_path):
    owner=out.Output(str(tmp_path/'evidence'),expected_parent=parent_bytes(tmp_path))
    owner.write('report.json',b'{"synthetic":true}\n');binding=owner.binding();old=(owner.parent_fd,owner.fd);owner.close()
    for fd in old:
        with pytest.raises(OSError):os.fstat(fd)
    reopened=out.Output.reopen(binding)
    try:
        assert reopened.binding()==binding
        assert (tmp_path/'evidence'/'report.json').read_bytes()==b'{"synthetic":true}\n'
        with pytest.raises(FileExistsError):reopened.write('report.json',b'{}')
        with pytest.raises(ValueError):reopened.write('private.npy',b'no')
    finally:reopened.close()

@pytest.mark.parametrize('case',['expected_bytes','effective_uid','parent_uid'])
def test_later_captured_parent_binding_tampering_rejects(tmp_path,case):
    owner=out.Output(str(tmp_path/'leaf'),expected_parent=parent_bytes(tmp_path))
    if case=='expected_bytes':owner.expected_parent=b'{}'
    elif case=='effective_uid':owner.effective_uid+=1
    else:owner.parent_uid+=1
    with pytest.raises(ValueError):owner.check()
    original=(owner.fd,owner.parent_fd);owner.close()
    for fd in original:
        with pytest.raises(OSError):os.fstat(fd)

def test_original_fd_retirement_attempts_all_and_preserves_genuine_body(tmp_path,monkeypatch):
    owner=out.Output(str(tmp_path/'leaf'),expected_parent=parent_bytes(tmp_path));original=(owner.fd,owner.parent_fd);calls=[];native=os.close
    body=ValueError('SYNTHETIC genuine body')
    def close(fd):
        calls.append(fd);native(fd)
        if fd==original[0]:raise KeyboardInterrupt('SYNTHETIC after-close cancellation')
    with monkeypatch.context()as m:
        m.setattr(out.os,'close',close)
        with pytest.raises(ValueError)as caught:owner.close(primary=body)
    assert caught.value is body and calls==list(original)
    for fd in original:
        with pytest.raises(OSError):os.fstat(fd)
