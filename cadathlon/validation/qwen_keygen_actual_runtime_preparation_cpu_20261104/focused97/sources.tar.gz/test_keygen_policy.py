"""Synthetic external policy documents and explicitly fake kernel observations."""
import copy,os,stat
from types import SimpleNamespace,ModuleType
import pytest
import keygen_dependencies as kd
from fixtures_keygen import policy_fixture,H

def test_policy_requires_exact_referenced_bytes_not_digest_shapes(tmp_path,monkeypatch):
    f=policy_fixture(tmp_path,monkeypatch);raw,pins=f.build();dep,res=kd.policies(raw,pins,f.source,f.archive)
    assert dep==f.dep and res==f.res
    pins=dict(pins);pins['dependency_policy_sha256']=H('different pinned content')
    with pytest.raises(ValueError,match='policy bytes'):kd.policies(raw,pins,f.source,f.archive)

@pytest.mark.parametrize('case',['boolean_threads','duplicate_core','wrong_cpu','missing_origin','null_root_origin','unlisted_origin','small_live_floor','role_source','review_archive'])
def test_repinned_policies_reject_semantic_and_typed_failures(tmp_path,monkeypatch,case):
    f=policy_fixture(tmp_path,monkeypatch);dep=copy.deepcopy(f.dep);res=copy.deepcopy(f.res);role=copy.deepcopy(f.role)
    if case=='boolean_threads':res['threads']=True
    elif case=='duplicate_core':dep['cores']=[112,112]
    elif case=='wrong_cpu':dep['environment']['JAX_PLATFORMS']='tpu'
    elif case=='missing_origin':dep['backend_module_origins'].pop('jax')
    elif case=='null_root_origin':dep['backend_module_origins']['numpy']['spec']=None
    elif case=='unlisted_origin':dep['backend_module_origins']['jax']['file']='/unopened/foreign.py'
    elif case=='small_live_floor':res['live_object_allowance_bytes']=1
    elif case=='role_source':role['source_manifest_sha256']=H('another source')
    raws,pins=f.build(dep,res,role)
    with pytest.raises(ValueError):kd.policies(raws,pins,f.source,H('another archive')if case=='review_archive'else f.archive)

@pytest.mark.parametrize('case',['declared_fileless_child','undeclared_child','foreign_spec','foreign_file'])
def test_loaded_backend_origins_use_explicit_independent_policy(tmp_path,monkeypatch,case):
    f=policy_fixture(tmp_path,monkeypatch);modules={}
    for name,row in f.dep['backend_module_origins'].items():
        m=ModuleType(name);m.__file__=row['file'];m.__spec__=SimpleNamespace(origin=row['spec']);modules[name]=m
    if case in('declared_fileless_child','undeclared_child'):
        m=ModuleType('jax.synthetic_child');modules[m.__name__]=m
        if case=='declared_fileless_child':f.dep['backend_module_origins'][m.__name__]=dict(file=None,spec=None)
    elif case=='foreign_spec':modules['jax'].__spec__.origin='/unopened/foreign.py'
    else:modules['jax'].__file__='/unopened/foreign.py'
    monkeypatch.setattr(kd,'sys',SimpleNamespace(modules=modules))
    if case=='declared_fileless_child':assert kd.imported_origins(f.dep,tmp_path/'source')['jax.synthetic_child']==dict(file=None,spec=None)
    else:
        with pytest.raises(ValueError):kd.imported_origins(f.dep,tmp_path/'source')

@pytest.mark.parametrize('case',['valid','soft_limit','wrong_cgroup','combined_disk','tmpfs_memory'])
def test_capacity_uses_declared_fake_kernel_baseline_and_shared_device_sums(tmp_path,monkeypatch,case):
    f=policy_fixture(tmp_path,monkeypatch);res=f.res
    paths={n:str(tmp_path/n)for n in('public_root','private_root','evidence_root')}
    intent=dict(paths=paths,logical_storage=dict(retained_store_descriptors=342,store_temporary_allowance=8,public_required_bytes=100<<30,private_required_bytes=2<<30))
    fake={'/proc/self/cgroup':'0::/FAKE\n','/proc/meminfo':'MemAvailable: 83886080 kB\n','/proc/self/status':'VmRSS: 1024 kB\n',
        '/sys/fs/cgroup/FAKE/memory.current':'0\n','/sys/fs/cgroup/FAKE/memory.max':'max\n',
        '/proc/self/mountinfo':f'1 0 8:1 / {tmp_path} rw - '+('tmpfs'if case=='tmpfs_memory'else'ext4')+' fake rw\n'}
    if case=='wrong_cgroup':fake['/proc/self/cgroup']='0::/OTHER\n'
    reads=[]
    def kernel(path,limit=1<<20):reads.append(path);return fake[path]
    monkeypatch.setattr(kd,'kernel_read',kernel)
    monkeypatch.setattr(kd.resource,'getrlimit',lambda _:((350 if case=='soft_limit'else 8192),8192))
    real_listdir=os.listdir
    monkeypatch.setattr(kd.os,'listdir',lambda p:[str(x)for x in range(100)]if p=='/proc/self/fd'else real_listdir(p))
    monkeypatch.setattr(kd.os,'statvfs',lambda p:SimpleNamespace(f_bavail=(101 if case=='combined_disk'else 256)*(1<<30),f_frsize=1))
    if case=='valid':
        result=kd.capacity(intent,res,after_import=True)
        assert result['open_fd_baseline']==100 and result['required_fd_capacity']==466
        assert result['required_free_memory_bytes']==40<<30 and result['tmpfs_new_store_charge_bytes']==0
    else:
        with pytest.raises(ValueError):kd.capacity(intent,res,after_import=True)
    assert all(p in fake for p in reads)  # Every kernel result above is fabricated.
