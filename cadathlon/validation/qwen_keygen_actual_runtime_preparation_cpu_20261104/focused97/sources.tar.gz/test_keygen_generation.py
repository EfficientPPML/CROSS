"""Actual new generate function with tiny recorded owners/primitives only."""
import pytest
from fixtures_keygen import install_generation_recording

def test_recorded168_calls_preserve_original_secret_and_complete_335_order(tmp_path,monkeypatch):
    f=install_generation_recording(monkeypatch,tmp_path)
    result=f.module.generate(f.launch,f.profile,f.core,f.source_check,f.checks,f.counts)
    assert f.counts==dict(pke_pairs=1,evaluation_key_pairs=1,rotation_key_pairs=166,primitive_calls=168,public_arrays=335,private_arrays=1,public_files=336,private_files=2)
    assert [e[1]for e in f.events if type(e)is tuple and e[0]=='rotate']==list(range(1,167))
    assert f.events.index('manifest_private')<f.events.index('manifest_public')<f.events.index('close_private')<f.events.index('close_public')
    assert f.events.index('source_check')<f.events.index('pke')
    assert f.checks['cleanup_completed']is True and all(o.closed for o in f.owners)
    assert set(result['stores'])=={'public','private'}
    assert f.profile.parameters['degree']==2  # Explicit tiny recording, never an actual profile/ready proof.

@pytest.mark.parametrize('fault',['second_constructor','rotation_body','body_close_rethrow'])
def test_recorded_body_failure_preserves_identity_and_attempts_original_owners(tmp_path,monkeypatch,fault):
    body=ValueError('SYNTHETIC genuine body');f=install_generation_recording(monkeypatch,tmp_path,fault=fault,body=body)
    with pytest.raises(ValueError)as caught:f.module.generate(f.launch,f.profile,f.core,f.source_check,f.checks,f.counts)
    assert caught.value is body and all(o.closed for o in f.owners)
    assert f.checks['cleanup_completed']is False
    assert f.counts['rotation_key_pairs']<166
    assert f.module._QUARANTINE[-1][-1]is body

def test_recorded_close_accessor_replacement_calls_original_and_fails(tmp_path,monkeypatch):
    f=install_generation_recording(monkeypatch,tmp_path,fault='replace_close')
    with pytest.raises(ValueError,match='accessor changed'):f.module.generate(f.launch,f.profile,f.core,f.source_check,f.checks,f.counts)
    assert 'MUTATED_CLOSE_CALLED'not in f.events
    assert 'close_private'in f.events and 'close_public'in f.events and all(o.closed for o in f.owners)
    assert f.checks['cleanup_completed']is False

def test_cleanup_only_ordinary_error_yields_to_later_cancellation(tmp_path,monkeypatch):
    f=install_generation_recording(monkeypatch,tmp_path,fault='close_cleanup')
    with pytest.raises(KeyboardInterrupt):f.module.generate(f.launch,f.profile,f.core,f.source_check,f.checks,f.counts)
    assert f.events.index('close_private')<f.events.index('close_public')and all(o.closed for o in f.owners)
    assert f.checks['cleanup_completed']is False and f.counts['rotation_key_pairs']==166
