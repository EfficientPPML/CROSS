"""Actual entry functions and actual run cleanup with declared recording seams."""
import hashlib,json,os,signal,subprocess,sys
from contextlib import nullcontext
from pathlib import Path
from types import SimpleNamespace,ModuleType
import pytest
import keygen_entry as ke
import keygen_process as kp
import keygen_dependencies as kd
from qwen_file_contract import canonical,sha
from fixtures_keygen import H

@pytest.mark.parametrize('case',['normal0','normal1','bool','none','systemexit0','systemexit1','oserror','keyboard'])
def test_terminal_status_accepts_only_exact_normal_integers(case):
    def call():
        if case=='systemexit0':raise SystemExit(0)
        if case=='systemexit1':raise SystemExit(1)
        if case=='oserror':raise OSError('SYNTHETIC ordinary failure')
        if case=='keyboard':raise KeyboardInterrupt()
        return {'normal0':0,'normal1':1,'bool':True,'none':None}[case]
    assert ke.terminal_status(call)==(0 if case=='normal0'else 1 if case=='normal1'else 70)

def test_failed_diagnostic_cannot_replace_reserved_infrastructure_exit(monkeypatch):
    class Broken:
        def write(self,*a):raise SystemExit(1)
        def flush(self):raise SystemExit(0)
    with monkeypatch.context()as m:
        m.setattr(ke.sys,'stderr',Broken())
        assert ke.terminal_status(lambda:(_ for _ in()).throw(OSError('SYNTHETIC')))==70

@pytest.mark.parametrize('name',['keygen_entry_status.json','keygen_static_policy.json'])
def test_exact_old_encoding_rejects_and_v2_same_object_parses(runtime_root,name):
    old=(runtime_root.parent/'history'/name).read_bytes();new=(runtime_root/name).read_bytes();value=json.loads(new)
    assert old!=new and json.loads(old)==value and new==canonical(value)
    with pytest.raises(ValueError,match='canonical'):kp.parsed(old,set(value),value['schema'])
    assert kp.parsed(new,set(value),value['schema'])==value

def test_default_actual_entry_denies_before_argument_or_public_read(runtime_root,monkeypatch):
    class Bomb:
        def __getattribute__(self,name):raise AssertionError('argument touched before deny')
    calls=[]
    monkeypatch.setattr(kp,'read',lambda *a,**kw:calls.append(a))
    with pytest.raises(PermissionError):
        kp.admit(Bomb(),b'',{}, {'keygen_entry_status.json':(runtime_root/'keygen_entry_status.json').read_bytes()})
    assert calls==[]

@pytest.mark.parametrize('case',['expected_digest','source_map','source_digest','body_suffix'])
def test_external_public_pin_source_failures_stop_before_later_roles(tmp_path,runtime_root,monkeypatch,case):
    p=tmp_path/'expected.json';p.write_bytes(b'{}\n');reads=[];real_read=kp.read
    def read(path,**kw):reads.append(Path(path));return real_read(path,**kw)
    monkeypatch.setattr(kp,'read',read)
    expected={'source.py':H('source')};raw_map=canonical(expected)
    pv=dict(source_map=expected,source_manifest_sha256=sha(raw_map))
    if case=='source_map':pv['source_map']={'other.py':H('other')}
    if case=='source_digest':pv['source_manifest_sha256']=H('wrong map bytes')
    monkeypatch.setattr(kp,'ExpectedLaunchPins',lambda raw:SimpleNamespace(check=lambda:pv))
    args=SimpleNamespace(expected_pins=str(p)if case!='body_suffix'else str(tmp_path/'unopened.npy'),expected_pins_sha256=H('wrong content')if case=='expected_digest'else sha(p.read_bytes()),manifest_sha256=sha(raw_map))
    blobs={'keygen_entry_status.json':canonical(dict(schema='qwen-keygen-entry-status-v1',actual_entry_ready=True)),
        'keygen_static_policy.json':canonical(dict(schema='qwen-keygen-static-policy-v1',protected_paths=[]))}
    with pytest.raises(ValueError):kp.admit(args,raw_map,expected,blobs)
    assert reads==([]if case=='body_suffix'else[p])
    assert json.loads((runtime_root/'keygen_entry_status.json').read_bytes())['actual_entry_ready']is False

def test_real_cli_closed_source_default_denial_has_no_output_or_backend(tmp_path,runtime_root):
    mapping={p.relative_to(runtime_root).as_posix():sha(p.read_bytes())for p in sorted(runtime_root.rglob('*'))if p.is_file()}
    manifest=tmp_path/'source-map.json';manifest.write_bytes(canonical(mapping))
    command=[sys.executable,'-I','-B',str(runtime_root/'keygen_entry.py'),'--role','generate_fresh_qwen166_keys','--manifest',str(manifest),'--manifest-sha256',sha(manifest.read_bytes())]
    for role in('grant','bundle','expected-pins'):command+=['--'+role,str(tmp_path/(role+'.json')),'--'+role+'-sha256','0'*64]
    child=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,
        env=dict(PATH='/usr/bin:/bin',HOME=str(tmp_path),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1'))
    try:
        stdout,stderr=child.communicate()
    except BaseException:
        try:
            try:os.killpg(child.pid,signal.SIGKILL)
            except ProcessLookupError:pass
        finally:child.wait()
        raise
    assert child.returncode==70 and b'PermissionError'in stderr and stdout==b''
    with pytest.raises(ProcessLookupError):os.killpg(child.pid,0)
    assert sorted(p.name for p in tmp_path.iterdir())==['source-map.json']

def test_swallowed_audit_denial_remains_sticky_through_original_restore(tmp_path,monkeypatch):
    hooks=[];native=os.open
    monkeypatch.setattr(kd.sys,'addaudithook',hooks.append)
    dep=dict(installed_sources={});res=dict(cgroup_memory_current='/sys/fs/cgroup/FAKE/memory.current',cgroup_memory_max='/sys/fs/cgroup/FAKE/memory.max')
    intent=dict(paths={n:str(tmp_path/n)for n in('public_root','private_root','evidence_root')})
    audit=kd.AccessScope(tmp_path,{},[],intent,SimpleNamespace(arrays=[]),dep,res,[])
    audit.install()
    try:
        try:hooks[0]('socket.connect',())
        except PermissionError:pass
        try:audit.close()
        except PermissionError:caught=True
        else:caught=False
    finally:
        os.open=native;audit.active=False
    assert caught and audit.denials==['network/process']and os.open is native

@pytest.mark.parametrize('case',['normal','late_swallowed_audit','late_close_systemexit0'])
def test_actual_run_publication_and_retirement_boundary_with_recording_dependencies(tmp_path,monkeypatch,case):
    # No candidate backend is imported. Temporary module-name doubles are
    # removed before the autouse no-backend postcheck; their APIs only record.
    import qwen_backend_identity as identity
    events=[];blobs={};expected={};raw_map=canonical(expected)
    iv=dict(paths=dict(evidence_root=str(tmp_path/'evidence')),model_id=H('model'),request_producer_source_manifest_sha256=H('request'),response_consumer_source_manifest_sha256=H('response'),core_source_manifest_sha256=H('core'))
    pv=dict(policies={'dependency_policy_sha256':H('dep')},source_archive_sha256=H('archive'),model_evidence={},role_evidence={})
    launch=SimpleNamespace(intent=SimpleNamespace(check=lambda:iv,raw=b'{}'),expected_pins=SimpleNamespace(check=lambda:pv),grant_bytes=canonical(dict(source_root=str(tmp_path),parents={'evidence_root':{}})),check=lambda:events.append('launch'))
    p=dict(q_towers=[3],p_towers=[5],degree=2,dnum=1,sigma=1.,secret_distribution='SYNTHETIC')
    profile=SimpleNamespace(parameters=p)
    hp=dict(SecurityTarget=lambda *a:None,qp_is_secure=lambda *a:True,assert_p_coverage=lambda *a:None,q_partition_products=lambda *a:[3],DEFAULT_SIGMA=1.,SECRET_DISTRIBUTION='SYNTHETIC')
    core=SimpleNamespace(check=lambda:events.append('core'),load=lambda names:{'key_gen':SimpleNamespace(KEY_GENERATION_VERSION=3)},retain=lambda *a:SimpleNamespace(values=tuple(hp.items()),check=lambda:None))
    jax=ModuleType('jax');jax.devices=lambda:[SimpleNamespace(platform='cpu')];jax.config=SimpleNamespace(jax_enable_x64=True)
    numpy=ModuleType('numpy')
    class Audit:
        def __init__(self,*a):self.deny=False;self.enabled=False
        def install(self):events.append('audit_install')
        def check(self):
            events.append('audit_check')
            if self.deny:raise PermissionError('SYNTHETIC swallowed late denial')
        def close(self):events.append('audit_restore')
    audit=Audit()
    class Output:
        def __init__(self,*a,**kw):events.append('output_acquired')
        def check(self):events.append('output_check')
        def write(self,name,raw):
            events.append(('publication',name))
            if name=='report.json'and case=='late_swallowed_audit':audit.deny=True
        def close(self,primary=None):
            events.append('original_output_close')
            if case=='late_close_systemexit0':raise SystemExit(0)
    def generate(launch,profile,core,check,checks,counts):
        events.append('recorded_generation');checks.update({n:True for n in checks})
        return dict(context_id=H('context'),public_manifest_sha256=H('public'),private_manifest_sha256=H('private'),stores={})
    with monkeypatch.context()as m:
        m.setitem(sys.modules,'jax',jax);m.setitem(sys.modules,'numpy',numpy)
        m.setattr(identity,'install_core',lambda *a,**kw:core)
        for name,value in dict(admit=lambda *a:(launch,(),profile,{}, {},{},()),environment=lambda *a:None,capacity=lambda *a,**kw:{},hash_installed=lambda *a:{},imported_origins=lambda *a:{},AccessScope=lambda *a:audit,Output=Output,generate=generate,termination_signals=nullcontext,cleanup_signals=nullcontext).items():m.setattr(kp,name,value)
        status=ke.terminal_status(lambda:kp.run(None,raw_map,expected,blobs,SimpleNamespace(core_enabled=False),lambda m:blobs,lambda *a,**kw:None))
    assert status==(0 if case=='normal'else 70)
    assert ('publication','report.json')in events
    assert events.index(('publication','report.json'))<events.index('original_output_close')<events.index('audit_restore')
    assert events.count('original_output_close')==1
