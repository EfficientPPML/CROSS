"""Synthetic matrix/planner checks; no real parameter body reads."""
from pathlib import Path
import hashlib,io,json,subprocess,sys
import numpy as np
import pytest
import public_plan as p

@pytest.mark.parametrize('shape',[(2048,1024),(1024,1024),(1024,2048),(3072,1024),(1024,3072),(4096,1024),(384,1024)])
def test_dense_shape_exact_diagonal_inventory(shape):
    r=p.matrix_plan(np.ones(shape));assert not r['absent_diagonals'] and r['active_diagonal_count']==sum(shape)-1
    assert r['n1']*r['n2']==65536 and all(0<k<65536 for k in r['required_keys'])
    assert r['nonzero_rotation_calls']==sum(bool(k%65536) for k in (*r['baby_steps'],*r['giant_steps'],r['final_giant']))

def test_actual_sparse_gaps_change_required_keys():
    weight=np.zeros((20,20));weight[0,0]=1;weight[0,7]=2;weight[18,0]=3
    ns=p.production_planner();source=ns['MatrixDiagonals'](weight,65536,4096)
    assert source.active==tuple(sorted((0,7,65536-18)))
    r=p.matrix_plan(weight,planner=ns);assert r['absent_diagonals']
    plan=ns['linear_rotation_plan'](source,strategy='chained')
    expected={x%65536 for x in (*plan.baby_steps,*plan.giant_steps,plan.final_giant) if x%65536}
    assert r['required_keys']==sorted(expected) and r['required_keys']!=p.matrix_plan(np.ones((20,20)))['required_keys']

def test_zero_matrix_has_no_rotations():
    r=p.matrix_plan(np.zeros((20,20)));assert r['active_diagonal_count']==0 and r['required_keys']==[] and r['nonzero_rotation_calls']==0

@pytest.mark.parametrize('bad',[np.zeros((4097,1)),np.zeros((1,4097)),np.zeros((0,2)),np.zeros(3),np.array([[np.inf]]),np.array([[np.nan]])])
def test_bad_public_matrix_rejected(bad):
    with pytest.raises(ValueError):p.matrix_plan(bad)

def test_partial_vocabulary_coverage():
    rows=[(start,min(start+4096,151936)) for start in range(0,151936,4096)]
    assert len(rows)==38 and rows[0][0]==0 and rows[-1][1]==151936 and rows[-1][1]-rows[-1][0]==384
    assert sum(hi-lo for lo,hi in rows)==151936 and all(a[1]==b[0] for a,b in zip(rows,rows[1:]))

def test_authenticated_small_matrix_load_and_payload_binding(tmp_path):
    a=np.arange(6,dtype='<f8').reshape(2,3);path=tmp_path/'matrix.npy';np.save(path,a,allow_pickle=False)
    row=dict(file=path.name,file_sha256=p.io.file_sha(path),sha256=p.payload_sha(a),shape=list(a.shape))
    got=p.load_matrix(tmp_path,row);assert not got.flags.writeable and np.array_equal(got,a)
    row['sha256']='0'*64
    with pytest.raises(ValueError):p.load_matrix(tmp_path,row)

@pytest.mark.parametrize('name',['../matrix.npy','/tmp/matrix.npy','child/matrix.npy'])
def test_direct_filename_required(tmp_path,name):
    with pytest.raises(ValueError):p.load_matrix(tmp_path,dict(file=name))

def test_public_import_has_no_backend():
    subprocess.run([sys.executable,'-c','import public_plan as p;p.io.backend_gate();p.production_planner()'],cwd=p.HERE,check=True)
