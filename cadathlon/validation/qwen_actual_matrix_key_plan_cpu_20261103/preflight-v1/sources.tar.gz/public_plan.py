"""Exact public-matrix chained rotation gaps; no backend or key generation."""
from pathlib import Path
from dataclasses import dataclass
from numbers import Integral,Real
from typing import Optional,Tuple
import argparse,ast,hashlib,json,math,os,sys,time
import numpy as np
import export_decoder as io
from finish import finish
HERE=Path(__file__).resolve().parent
QKV_SHA='c707068e1a247f4ef14fda3493a3e2edf9dea2f11ec19e94531a64d80dbcf48b'
DECODER_SHA='60c556376e42358f227a2978edb6b2addf59dc9e694b65e17265b15e813d65c3'
QKV=Path('/tmp/qwen-qkv-attention-join-20261103/public_qkv_parameters')
DECODER=Path('/tmp/qwen-decoder-parameters-20261103/actual-v1/public_matrices')

def prerequisites():
    origins=json.loads((HERE/'source_origins.json').read_bytes())
    for name,row in origins.items():
        if io.file_sha(HERE/name)!=row['sha256']:raise ValueError('fixed public prerequisite changed')
    qkv=(HERE/'inputs/qkv_parameters.json').read_bytes();decoder=(HERE/'inputs/decoder_parameters.json').read_bytes()
    if io.digest(qkv)!=QKV_SHA or io.digest(decoder)!=DECODER_SHA:raise ValueError('externally reviewed parameter manifests required')
    qkv=json.loads(qkv);decoder=json.loads(decoder)
    for manifest in (qkv,decoder):
        if (manifest['candidate_sha256']!=io.CANDIDATE or manifest['checkpoint_sha256']!=io.CHECKPOINT
            or manifest['config_sha256']!=io.CONFIG):raise ValueError('same fixed public checkpoint/candidate required')
    if len(qkv['matrices'])!=84 or len(decoder['matrices'])!=114:raise ValueError('complete public parameter descriptors required')
    return qkv,decoder

def production_planner():
    """Execute complete unchanged selected AST definitions, not module imports."""
    ns=dict(np=np,math=math,Integral=Integral,Real=Real,Optional=Optional,Tuple=Tuple,dataclass=dataclass,__name__=__name__)
    for filename,names in (('bsgs.py',{'compute_bsgs_params'}),('packed_qwen.py',{'MatrixDiagonals'}),
                           ('chained_linear.py',{'validate_rotation_strategy','LinearRotationPlan','linear_rotation_plan'})):
        source=(HERE/'references'/filename).read_bytes();tree=ast.parse(source)
        selected=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names]
        if len(selected)!=len(names):raise ValueError('exact public planner definitions required')
        exec(compile(ast.Module(body=selected,type_ignores=[]),filename,'exec'),ns)
    return ns

def matrix_plan(weight,*,planner=None):
    if planner is None:planner=production_planner()
    source=planner['MatrixDiagonals'](weight,65536,4096)
    actual=planner['linear_rotation_plan'](source,strategy='chained')
    dense={d%65536 for d in range(-(weight.shape[0]-1),weight.shape[1])}
    absent=sorted(dense-set(source.active))
    return dict(shape=list(weight.shape),active_diagonal_count=len(source.active),
        active_diagonals_sha256=io.digest(io.canonical(list(source.active))),absent_diagonals=absent,
        n1=source.n1,n2=source.n2,required_keys=list(actual.required_keys),
        baby_steps=list(actual.baby_steps),giant_steps=list(actual.giant_steps),final_giant=actual.final_giant,
        nonzero_rotation_calls=actual.nonzero_rotation_calls,weighted_giant_groups=len(actual.giant_indices),
        ciphertext_depth=1,scope='Actual public weight diagonal gaps in the unchanged chained linear schedule.')

def payload_sha(array):
    h=hashlib.sha256()
    for start in range(0,array.shape[0],4096):h.update(np.asarray(array[start:start+4096],dtype='<f8').tobytes())
    return h.hexdigest()

def load_matrix(root,row):
    name=row['file']
    if type(name)is not str or Path(name).name!=name:raise ValueError('direct public matrix filename required')
    path=root/name
    if io.file_sha(path)!=row['file_sha256']:raise ValueError('authenticated matrix file differs')
    with io.owned_stream(path) as f:array=np.load(f,allow_pickle=False,max_header_size=1024)
    if (type(array)is not np.ndarray or array.dtype.str!='<f8' or list(array.shape)!=row['shape']
        or not np.isfinite(array).all() or payload_sha(array)!=row['sha256']):raise ValueError('exact promoted public matrix required')
    array.setflags(write=False)
    return array

def run(output):
    output=Path(output);output.mkdir(mode=0o700,exist_ok=False);start=time.monotonic()
    report=dict(passed=False,operation_complete=False,termination_scope_completed=False,pid=os.getpid(),
        backend_imported=False,model_forward=False,key_generation=False,HE=False)
    try:
        io.backend_gate();qkv,decoder=prerequisites();planner=production_planner();records=[];files={}
        for group,manifest,root in (('qkv',qkv,QKV),('decoder',decoder,DECODER)):
            for name,row in manifest['matrices'].items():
                # The authenticated tied alias has no separate homomorphic map.
                if name=='model.embed_tokens.weight':
                    head=manifest['matrices']['lm_head.weight']
                    if row['storage_alias_of']!='lm_head.weight' or row['file']!=head['file'] or row['sha256']!=head['sha256'] or row['source_raw_sha256']!=head['source_raw_sha256']:
                        raise ValueError('actual tied alias metadata differs')
                    continue
                weight=load_matrix(root,row);files[group+'/'+row['file']]=row['file_sha256']
                if name=='lm_head.weight':
                    for index,start_row in enumerate(range(0,151936,4096)):
                        stop=min(start_row+4096,151936);part=weight[start_row:stop]
                        records.append(matrix_plan(part,planner=planner)|dict(name=name,block=index,rows=[start_row,stop],
                            full_tensor_sha256=row['sha256'],block_sha256=payload_sha(part)))
                    del part
                else:
                    records.append(matrix_plan(weight,planner=planner)|dict(name=name,block=None,rows=None,full_tensor_sha256=row['sha256']))
                if payload_sha(weight)!=row['sha256'] or io.file_sha(root/row['file'])!=row['file_sha256']:
                    raise ValueError('public matrix changed during exact gap planning')
                del weight
        if len(records)!=234 or len(files)!=197:raise ValueError('all196 layer maps and38 vocabulary blocks required')
        soft=json.loads((HERE/'inputs/softmax_plan.json').read_bytes())
        rms=json.loads((HERE/'inputs/rms_plan.json').read_bytes())
        full=json.loads((HERE/'inputs/full_plan.json').read_bytes())
        profile=next(x for x in json.loads((HERE/'inputs/profile_audit.json').read_bytes())['profiles'] if x['name']=='depth49_p60_d8')
        nonmatrix=set(soft['keys']['combined_component_indices'])
        for site in rms['sites']:nonmatrix.update(site['norm_rotation_keys'])
        actual={key for row in records for key in row['required_keys']};union=sorted(nonmatrix|actual)
        dense={key for row in full['linear_maps'].values() for key in row['required_keys_dense_case']}
        dense.update(key for row in full['vocabulary']['maps'] for key in row['required_keys_dense_case'])
        if 262143 not in nonmatrix:raise ValueError('bootstrap conjugation automorphism must remain unreduced')
        io.backend_gate();prerequisites()
        result=dict(passed=True,scope='Public actual-matrix rotation planning for the described F4096 S1..32 graph; no runtime key store or full HE readiness.',
            candidate_manifest_sha256=io.CANDIDATE,checkpoint_sha256=io.CHECKPOINT,qkv_manifest_sha256=QKV_SHA,decoder_manifest_sha256=DECODER_SHA,
            matrices=records,matrix_map_count=234,layer_map_count=196,vocabulary_blocks=38,
            actual_matrix_keys=sorted(actual),prior_dense_matrix_keys=sorted(dense),nonmatrix_keys=sorted(nonmatrix),
            combined_keys=union,combined_key_count=len(union),new_matrix_keys=sorted(actual-dense),
            prior_dense_matrix_keys_absent=sorted(dense-actual),matrix_maps_with_absent_diagonals=sum(bool(r['absent_diagonals']) for r in records),
            all_layer_linear_rotation_calls_per_row_tile=sum(r['nonzero_rotation_calls'] for r in records if r['block']is None),
            vocabulary_rotation_calls_last_row=sum(r['nonzero_rotation_calls'] for r in records if r['block']is not None),
            raw_rotation_pair_bytes=profile['rotation_pair_bytes'],raw_rotation_keys_bytes=len(union)*profile['rotation_pair_bytes'],
            exclusions=['Relinearization/public/secret keys, controls, ciphertexts, model arrays, compiler/backend/host-device duplicate memory.',
                'No genuine key inventory or actual-context security preflight; no key generation, ciphertext calculation or timing.',
                'Known row/head/causal/PV/norm/bootstrap geometry for S1..32 only. Any changed owner/layout/output compaction requires replanning.',
                'Conditional nonlinear domains/refresh errors and unimplemented full file/block joins remain unresolved.'])
        io.write_json(output/'plan.json',result)
        report.update(passed=True,operation_complete=True,plan_sha256=io.file_sha(output/'plan.json'),
            matrix_map_count=234,combined_key_count=len(union),public_matrix_file_hashes=files,elapsed_s=time.monotonic()-start)
    except BaseException as error:
        report.update(passed=False,error=dict(type=type(error).__name__,message=str(error)),elapsed_s=time.monotonic()-start)
        try:io.write_json(output/'report.json',report)
        except BaseException as secondary:error.add_note('failure publication: '+type(secondary).__name__)
        raise
    io.write_json(output/'report.json',report);return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True,type=Path);a=p.parse_args()
    r=finish(a.output/'report.json',lambda:run(a.output),io.write_json,io.public_report)
    print(json.dumps({k:r[k] for k in ('passed','matrix_map_count','combined_key_count','elapsed_s')}))
