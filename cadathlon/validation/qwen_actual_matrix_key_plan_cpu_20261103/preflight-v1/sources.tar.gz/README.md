# Actual public Qwen matrix rotation planning

This analysis replaces the earlier dense-shape matrix assumptions with the
actual authenticated public weights:84 QKV maps,112 O/MLP maps and all38
vocabulary blocks (37x4096 outputs plus384). It executes unchanged public AST
definitions of MatrixDiagonals, compute_bsgs_params and linear_rotation_plan;
the surrounding backend modules are not imported. Actual absent diagonals can
change chained gaps, so a dense upper count is not treated as a key inventory.

The public matrix manifests bind the unchanged candidate/checkpoint/config.
Every file and promoted payload digest is checked before and after planning.
The vocabulary/embedding alias is already proved by the public export; embedding
lookup occurs at the client and adds no server matrix map. Nonmatrix keys come
from the authenticated softmax/routing/PV/bootstrap and113-site RMS plans. The
bootstrap conjugation automorphism262143 is preserved without slot reduction.

The combined key set describes this specific F4096 row-tile graph for S1..32.
It is not a generated/authenticated key store, actual-context security pass,
memory peak, full-model implementation, benchmark or HE numerical evidence.
Changes to routing, refresh, layouts or output packing require a new plan.
Conditional nonlinear domains and refresh error bounds remain unresolved.
No model forward, backend, codec, key generation or encrypted operation runs.
Matrix bodies remain outside public source/result archives.
