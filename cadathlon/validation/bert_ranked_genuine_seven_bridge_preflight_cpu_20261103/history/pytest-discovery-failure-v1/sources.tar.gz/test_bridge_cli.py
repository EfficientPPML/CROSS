"""Exact-main regression: returned failure must never imply exit zero."""
from pathlib import Path
from types import SimpleNamespace as NS
import ast,json
import pytest
HERE=Path(__file__).resolve().parent

@pytest.mark.parametrize('passed',[False,True])
def test_preflight_returned_report_exit_status(passed,tmp_path):
    tree=ast.parse((HERE/'bridge_preflight.py').read_bytes())
    node=next(n for n in tree.body if isinstance(n,ast.If) and ast.unparse(n.test)=="__name__ == '__main__'")
    class Parser:
        def add_mutually_exclusive_group(self,**kw):return self
        def add_argument(self,*a,**kw):pass
        def parse_args(self):return NS(test_worker=None,output=tmp_path)
    value=dict(passed=passed,source_count=300,tests={},source_archive_sha256='a'*64)
    ns=dict(__name__='__main__',Path=Path,argparse=NS(ArgumentParser=Parser),finish=lambda p,f,w:f(),collect=lambda p:value,c=NS(write=lambda *a:None),json=json)
    with pytest.raises(SystemExit) as seen:exec(compile(ast.Module(body=[node],type_ignores=[]),'bridge_preflight.py','exec'),ns)
    assert seen.value.code==(0 if passed else 1)

@pytest.mark.parametrize('source',['bridge_worker.py','bridge_collect.py'])
def test_new_executable_uses_successor_terminal_and_explicit_status(source):
    tree=ast.parse((HERE/source).read_bytes());node=next(n for n in tree.body if isinstance(n,ast.If) and ast.unparse(n.test)=="__name__ == '__main__'")
    assert any(isinstance(n,ast.ImportFrom) and n.module=='bridge_terminal' for n in ast.walk(node))
    assert isinstance(node.body[-1],ast.Raise) and 'SystemExit' in ast.unparse(node.body[-1])

def test_original_timer_dispatch_default_and_logsize_untouched():
    import bridge_common as c,ranked_timing as t
    t.verify_harness_sources({n:(HERE/'upstream/harness'/n).read_bytes() for n,_ in t.SOURCE_PINS})
    tree=ast.parse((HERE/'upstream/harness/run_submission.py').read_bytes());text=ast.unparse(tree)
    positions=[text.index("exec_dir, '"+n+"'") for n in c.NAMES]
    assert positions==sorted(positions)
    assert text.index("'Encrypted input'")>text.index("'Input encryption'") and text.index("'Encrypted input'")<text.index("exec_dir, 'server_encrypted_compute'")
    assert text.index("'Encrypted results'")>text.index("'Encrypted computation'") and text.index("'Encrypted results'")<text.index("exec_dir, 'client_decrypt_decode'")
    assert "np.random.default_rng(seed)" in text and "harness_dir, 'cleartext_impl'" in text
