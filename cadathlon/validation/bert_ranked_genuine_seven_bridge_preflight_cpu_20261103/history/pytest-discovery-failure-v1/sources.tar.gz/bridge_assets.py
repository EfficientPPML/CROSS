"""Read-only offline default-model authentication for unmodified HF calls.

No cache is populated or changed. Only a later authorized genuine harness may
call authenticate; preflight tests supply newly owned small public fixtures.
"""
from pathlib import Path
import hashlib,os,stat
import input_gate
REVISION='f150c1d609d1e50dd5e2e5408661cfac8339277c'
MODEL_DIRECTORY='models--google-bert--bert-base-cased-finetuned-mrpc'
EXPECTED={Path(n).name:h for n,h in input_gate.ASSETS.items() if str(input_gate.MODEL) in n}
UNCERTAIN=[]

def hub_cache():
    if os.environ.get('TRANSFORMERS_CACHE'):raise ValueError('legacy separate transformers cache override is not authenticated')
    a=os.environ.get('HF_HUB_CACHE');b=os.environ.get('HUGGINGFACE_HUB_CACHE')
    if a and b and Path(a).resolve()!=Path(b).resolve():raise ValueError('conflicting hub caches')
    home=Path(os.environ.get('HF_HOME',str(Path.home()/'.cache/huggingface')))
    return Path(a or b or home/'hub').resolve(strict=True)

def _hash(path,maximum):
    if UNCERTAIN:raise RuntimeError('public cache descriptor retirement uncertain')
    # HF snapshot entries normally link to immutable content-addressed blobs;
    #bind the resolved regular file, stream hash, then recheck the link target.
    target=path.resolve(strict=True);fd=os.open(target,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK);primary=None
    try:
        before=os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or not 0<before.st_size<=maximum:raise ValueError('bounded regular public cache asset required')
        h=hashlib.sha256();total=0
        while total<=maximum:
            raw=os.read(fd,min(1<<20,maximum+1-total))
            if not raw:break
            h.update(raw);total+=len(raw)
        after=os.fstat(fd);state=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
        if total!=before.st_size or state(before)!=state(after) or path.resolve(strict=True)!=target or state(target.stat())!=state(before):raise ValueError('public cache asset changed during authentication')
        return h.hexdigest(),list(state(before)),str(target)
    except BaseException as error:primary=error;raise
    finally:
        try:os.close(fd)
        except BaseException as error:
            UNCERTAIN.append(fd)
            if primary is None:raise
            primary.add_note('cache descriptor close: '+type(error).__name__)

def authenticate():
    hub=hub_cache();repo=hub/MODEL_DIRECTORY;ref=repo/'refs/main'
    # Both common exact representations of the pinned reference are accepted.
    ref_hash,identity,target=_hash(ref,128)
    if ref_hash not in {hashlib.sha256(s.encode()).hexdigest() for s in (REVISION,REVISION+'\n')}:raise ValueError('original default model revision is not the pinned checkpoint')
    snapshot=repo/'snapshots'/REVISION;assets={};states={}
    # These optional files can change HF loader selection/tokenization. They
    #are absent from the five-file pinned asset contract and cannot float.
    optional=('special_tokens_map.json','added_tokens.json','tokenizer.model','pytorch_model.bin','model.safetensors.index.json','pytorch_model.bin.index.json')
    if any((snapshot/n).exists() or (snapshot/n).is_symlink() for n in optional):raise ValueError('unpinned optional loader asset in default snapshot')
    for name,expected in EXPECTED.items():
        h,state,resolved=_hash(snapshot/name,1<<30)
        if h!=expected:raise ValueError('default HF model/tokenizer asset differs from frozen pins')
        assets[name]=h;states[name]=dict(identity=state,resolved=resolved)
    # A public link mutation between asset reads cannot silently select a new ref.
    if _hash(ref,128)!=(ref_hash,identity,target):raise ValueError('default model reference changed')
    return dict(hub_cache=str(hub),revision=REVISION,assets=assets,asset_states=states,reference_sha256=ref_hash,reference_identity=identity,reference_target=target)
