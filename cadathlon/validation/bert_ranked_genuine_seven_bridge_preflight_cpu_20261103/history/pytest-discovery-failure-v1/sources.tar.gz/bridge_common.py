"""Exact public closure and unmodified original harness for genuine bridge preparation."""
from pathlib import Path
import os,sys
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE/'runtime/stage'),str(HERE/'joined'),str(HERE/'joined/checkout/cadathlon/common'),str(HERE/'runtime')]
import key_gate
NAMES=('client_key_generation','server_preprocess_model','client_preprocess_input','client_encode_encrypt_input','server_encrypted_compute','client_decrypt_decode','client_postprocess')
COUNTS={1:100,2:200,3:408}

def read(path,limit=16<<20):return key_gate.parse(key_gate.read(path,limit))
def digest(raw):return key_gate.digest(raw)
def canonical(value):return key_gate.canonical(value)
def write(path,value):
    p=Path(path);q=p.with_suffix('.tmp');q.write_bytes(canonical(value));q.replace(p)
def sources():
    pins=read(HERE/'bridge_parent_manifest.json')
    raw={n:(HERE/n).read_bytes() for n in pins}
    if {n:digest(b) for n,b in raw.items()}!=pins:raise ValueError('unchanged272 parent differs')
    for p in HERE.iterdir():
        if p.is_file() and p.suffix in ('.py','.json'):raw[p.name]=p.read_bytes()
    for directory in ('upstream','authorization_inputs'):
        if (HERE/directory).exists():
            for p in (HERE/directory).rglob('*'):
                if p.is_file() and p.suffix in ('.py','.json','.md'):raw[p.relative_to(HERE).as_posix()]=p.read_bytes()
    return dict(sorted(raw.items()))
def hashes(raw):return {n:digest(b) for n,b in raw.items()}
def reject_test_environment():
    allowed={'CROSS_PUBLIC_KEY_DIRECTORY'} # inert owned process-helper directory
    bad=[name for name in os.environ if
         (name.startswith(('CROSS_','BOOTSTRAP_')) and name not in allowed)
         or name.startswith(('PYTEST_','PYTHONINSPECT','PYTHONSTARTUP'))]
    if bad:raise ValueError('genuine bridge rejects inherited synthetic/test/runtime switches')
    if os.environ.get('JAX_DISABLE_JIT','').lower() not in ('','0','false') or os.environ.get('XLA_FLAGS',''):
        raise ValueError('fixed genuine runtime rejects JIT/XLA overrides')
    if any(n=='synthetic_backend' or n.startswith('synthetic_modules') for n in sys.modules):raise ValueError('synthetic backend already loaded')
