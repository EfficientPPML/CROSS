"""Independent source-bound partial producer contracts, public synthetic evidence."""
from pathlib import Path
import copy
import pytest
import bridge_common as c,bridge_protocol as p,bridge_collect as collect
from test_bridge_contract import envelope

@pytest.fixture
def fixture(tmp_path):
    e=envelope('client_encode_encrypt_input');e['partial']['evidence']=str(tmp_path)
    expected={'a.py':c.digest(b'# source\n')};bindings={'case_binding':{'count':100,'input_sha256':'e'*64},'context_id':'1'*64}
    predecessor=dict(e,phase='client_preprocess_input',partial=None)
    summary=dict(sample_count=100,input_sha256='f'*64,preprocessed_input_sha256='e'*64)
    worker=dict(stage=3,passed=True,actual_stage_started=True,actual_stage_completed=True,readback_complete=True,
        source_files_unchanged=True,cleanup_completed=True,terminal_scope_completed=True,termination_scope_completed=True,
        bindings=bindings,bridge_phase=predecessor['phase'],bridge_binding=p.binding(predecessor,expected,bindings),source_hashes_start=expected,source_hashes_end=expected,
        invoked_entrypoints=[predecessor['phase']],phases=p.declared_phases(predecessor['phase']),actual_preprocessing_completed=True,readback=summary)
    (tmp_path/'worker').mkdir();c.write(tmp_path/'worker/worker_report.json',worker)
    record=dict(returncode=0,process_reaped=True,public_key_store_removed=True,owned_directory_handle_closed=True,result=dict(passed=True,worker_report_sha256=c.digest((tmp_path/'worker/worker_report.json').read_bytes())))
    collect.archive(tmp_path/'sources.tar.gz',{'a.py':b'# source\n'})
    report=dict(schema='cross-bert-ranked-split-phase-proof-v1',stage=3,passed=True,execute=True,actual_execution_attempted=True,operation_complete=True,all_processes_reaped=True,
        owned_artifacts_retained=True,cleanup_completed=True,source_files_unchanged=True,source_archive_verified=True,terminal_scope_completed=True,termination_scope_completed=True,
        bridge_phase=predecessor['phase'],bridge_binding=worker['bridge_binding'],bindings=bindings,source_hashes_start=expected,source_hashes_end=expected,execution_source_hashes_end=expected,
        source_archive_sha256=c.digest((tmp_path/'sources.tar.gz').read_bytes()),worker_process=record,readback=summary)
    def publish():
        c.write(tmp_path/'worker/worker_report.json',worker);record['result']['worker_report_sha256']=c.digest((tmp_path/'worker/worker_report.json').read_bytes())
        c.write(tmp_path/'report.json',report);e['partial']['report_sha256']=c.digest((tmp_path/'report.json').read_bytes())
    publish();return e,expected,bindings,report,worker,publish

def test_complete_partial_authentication(fixture):
    e,x,b,r,w,publish=fixture;assert p.authenticate_partial(e,x,b)==w

@pytest.mark.parametrize('field',['execute','operation_complete','all_processes_reaped','cleanup_completed','terminal_scope_completed','termination_scope_completed','source_files_unchanged','source_archive_verified','owned_artifacts_retained'])
def test_partial_flag_failure_even_rehashed(fixture,field):
    e,x,b,r,w,publish=fixture;r[field]=False;publish()
    with pytest.raises(ValueError):p.authenticate_partial(e,x,b)

@pytest.mark.parametrize('field',['actual_stage_started','actual_stage_completed','readback_complete','actual_preprocessing_completed','terminal_scope_completed','termination_scope_completed'])
def test_partial_worker_flag_failure_even_rehashed(fixture,field):
    e,x,b,r,w,publish=fixture;w[field]=False;publish()
    with pytest.raises(ValueError):p.authenticate_partial(e,x,b)

@pytest.mark.parametrize('target',['report','worker'])
@pytest.mark.parametrize('stage',[3.0,True,5])
def test_partial_exact_stage_type(fixture,target,stage):
    e,x,b,r,w,publish=fixture;({'report':r,'worker':w}[target])['stage']=stage;publish()
    with pytest.raises(ValueError):p.authenticate_partial(e,x,b)

def test_partial_cannot_claim_two_physical_calls(fixture):
    e,x,b,r,w,publish=fixture;w['invoked_entrypoints'].append('client_encode_encrypt_input');publish()
    with pytest.raises(ValueError):p.authenticate_partial(e,x,b)

def test_partial_cannot_claim_encryption_during_preprocess(fixture):
    e,x,b,r,w,publish=fixture;w['phases']['encryption']=True;publish()
    with pytest.raises(ValueError):p.authenticate_partial(e,x,b)

def test_partial_context_or_authorization_replay(fixture):
    e,x,b,r,w,publish=fixture;e['authorization']['storage_sha256']='7'*64
    with pytest.raises(ValueError):p.authenticate_partial(e,x,b)

def test_partial_input_bytes_bound(fixture):
    e,x,b,r,w,publish=fixture;w['readback']['preprocessed_input_sha256']='a'*64;publish()
    with pytest.raises(ValueError):p.authenticate_partial(e,x,b)
