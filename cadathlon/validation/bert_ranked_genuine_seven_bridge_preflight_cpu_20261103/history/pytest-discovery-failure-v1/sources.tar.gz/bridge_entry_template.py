"""One original timed subprocess; phase proof completion precedes return."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'_source'))
from bridge_integration import entry_main
if __name__=='__main__':
    try:entry_main(Path(__file__).stem,ROOT)
    except BaseException as error:
        print(__import__('json').dumps({'passed':False,'error_type':type(error).__name__,'private_error_text_withheld':True}))
        raise SystemExit(130 if not isinstance(error,Exception) else 1)
