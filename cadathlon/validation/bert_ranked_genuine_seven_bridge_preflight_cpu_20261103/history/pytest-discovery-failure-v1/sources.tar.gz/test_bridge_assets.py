from pathlib import Path
import hashlib,os
import pytest
import bridge_assets as a

@pytest.fixture
def cache(tmp_path,monkeypatch):
    hub=tmp_path/'hub';repo=hub/a.MODEL_DIRECTORY;(repo/'refs').mkdir(parents=True);(repo/'refs/main').write_text(a.REVISION)
    snapshot=repo/'snapshots'/a.REVISION;snapshot.mkdir(parents=True);blobs=repo/'blobs';blobs.mkdir();pins={}
    for n in ('config.json','model.safetensors','tokenizer.json','tokenizer_config.json','vocab.txt'):
        raw=('public synthetic '+n).encode();h=hashlib.sha256(raw).hexdigest();(blobs/h).write_bytes(raw);(snapshot/n).symlink_to(blobs/h);pins[n]=h
    monkeypatch.setattr(a,'EXPECTED',pins);monkeypatch.setattr(a,'UNCERTAIN',[])
    for name in ('HF_HUB_CACHE','HUGGINGFACE_HUB_CACHE','TRANSFORMERS_CACHE'):monkeypatch.delenv(name,raising=False)
    monkeypatch.setenv('HF_HUB_CACHE',str(hub));return hub,repo,snapshot

def test_default_model_pinned_without_importing_model(cache):
    r=a.authenticate();assert r['revision']==a.REVISION and len(r['assets'])==5
    assert a.authenticate()==r

def test_default_revision_cannot_float(cache):
    _,repo,_=cache;(repo/'refs/main').write_text('0'*40)
    with pytest.raises(ValueError,match='default model revision'):a.authenticate()

def test_changed_model_byte_rejected(cache):
    _,_,snapshot=cache;(snapshot/'model.safetensors').resolve().write_bytes(b'wrong')
    with pytest.raises(ValueError,match='asset differs'):a.authenticate()

def test_conflicting_model_cache_rejected(cache,tmp_path,monkeypatch):
    other=tmp_path/'other';other.mkdir();monkeypatch.setenv('HUGGINGFACE_HUB_CACHE',str(other))
    with pytest.raises(ValueError):a.authenticate()

def test_legacy_transformers_override_rejected(cache,monkeypatch):
    monkeypatch.setenv('TRANSFORMERS_CACHE','/synthetic/unbound')
    with pytest.raises(ValueError):a.authenticate()

def test_fifo_rejected_without_block(cache):
    _,_,snapshot=cache;p=snapshot/'vocab.txt';p.unlink();os.mkfifo(p)
    with pytest.raises(ValueError,match='regular'):a.authenticate()

@pytest.mark.parametrize('name',['special_tokens_map.json','added_tokens.json','pytorch_model.bin'])
def test_optional_unpinned_loader_artifacts_rejected(cache,name):
    _,_,snapshot=cache;(snapshot/name).write_text('{}')
    with pytest.raises(ValueError,match='optional'):a.authenticate()
