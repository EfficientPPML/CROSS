"""Fresh staged-path/seven-phase/outer completion wiring with explicit test doubles."""
from pathlib import Path
from dataclasses import replace
from types import SimpleNamespace as NS
from contextlib import contextmanager
import copy,json
import pytest
import bridge_common as c,bridge_integration as b,bridge_protocol as protocol,bridge_collect,bridge_terminal,ranked_case_gate as cases
HERE=Path(__file__).resolve().parent

@pytest.fixture
def prepared(tmp_path,monkeypatch):
    base=cases.authenticate(HERE/'public_evidence/fixture',cases.FIXTURE_REPORT_SHA,HERE/'public_evidence/reference',cases.REFERENCE_REPORT_SHA)
    fixture=tmp_path/'keepfixture';reference=tmp_path/'keepreference';fixture.mkdir();reference.mkdir()
    def ws(p):s=p.stat();return cases.Workspace(p,s.st_dev,s.st_ino)
    base=replace(base,cases=tuple(replace(x,fixture_workspace=ws(fixture),reference_workspace=ws(reference)) for x in base.cases),fixture_workspace=ws(fixture),reference_workspace=ws(reference))
    monkeypatch.setattr(cases,'authenticate',lambda *a:base);monkeypatch.setattr(c,'reject_test_environment',lambda:None)
    # Only this test creates a small source double; production collection is exact272+new closure.
    raw={str(p.relative_to(HERE)):p.read_bytes() for p in (HERE/'upstream').rglob('*') if p.is_file()}
    raw['bridge_entry_template.py']=(HERE/'bridge_entry_template.py').read_bytes()
    monkeypatch.setattr(c,'sources',lambda:dict(raw));events=[]
    def allow(e,expected,case,**kw):
        assert not Path(e['request']['staged_root']).exists();events.append(('authorization',kw['check_storage']))
    monkeypatch.setattr(protocol,'authorize',allow)
    def prepare(size=1,seed=42):
        root=tmp_path/f'attempt{size}-{seed}';evidence=tmp_path/f'evidence{size}-{seed}'
        cfg=b.prepare(root,size=size,seed=seed,fixture_evidence=tmp_path/'fixtureproof',fixture_report_sha256='1'*64,reference_evidence=tmp_path/'refproof',reference_report_sha256='2'*64,
            authorization=dict(size0_evidence='/tmp/mocksize0',size0_report_sha256='c'*64,storage_path='/tmp/mockgrant',storage_sha256='d'*64),evidence_root=evidence,hardware_policy_sha256='3'*64,cache_policy_sha256='4'*64)
        return root,cfg
    return NS(prepare=prepare,events=events,raw=raw,tmp=tmp_path)

@pytest.mark.parametrize('size',(1,2,3))
@pytest.mark.parametrize('seed',(42,43,44))
def test_all_nine_fresh_original_roots_and_seven_wrappers(prepared,size,seed):
    root,cfg=prepared.prepare(size,seed);actual,state=b.invocation(root)
    assert actual==cfg and state==dict(next_phase=0,proofs=[])
    assert set(p.name for p in (root/'submissions').iterdir())=={n+'.py' for n in c.NAMES}
    assert prepared.events==[('authorization',True)]
    assert not (root/'io').exists() # upstream exclusively owns original initialization
    assert cfg['num_runs']==1 and not any('synthetic' in n for n in cfg['source_hashes'])

def test_missing_authorization_creates_nothing(prepared,monkeypatch):
    failure=ValueError('size0 incomplete')
    monkeypatch.setattr(protocol,'authorize',lambda *a,**kw:(_ for _ in ()).throw(failure))
    with pytest.raises(ValueError) as seen:prepared.prepare()
    assert seen.value is failure and not (prepared.tmp/'attempt1-42').exists() and not (prepared.tmp/'evidence1-42').exists()

def test_original_init_alias_rejected(prepared,tmp_path):
    root,cfg=prepared.prepare();outside=tmp_path/'outside';outside.mkdir();sentinel=outside/'keep';sentinel.write_text('keep')
    (root/'io').symlink_to(outside,target_is_directory=True)
    with pytest.raises(ValueError):b.invocation(root)
    assert sentinel.read_text()=='keep'

def fake_collect(output,request_path,sha,*,execute):
    assert execute is True;raw=request_path.read_bytes();assert c.digest(raw)==sha;env=json.loads(raw)
    output.mkdir();proof=dict(passed=True,execute=True,operation_complete=True,all_processes_reaped=True,cleanup_completed=True,terminal_scope_completed=True,
        request_sha256=sha,source_hashes_start=c.hashes(c.sources()),bridge_phase=env['phase'])
    c.write(output/'report.json',proof);return proof

def test_exact_seven_phases_only_advance_after_terminal(prepared,monkeypatch):
    root,cfg=prepared.prepare();monkeypatch.setattr(bridge_collect,'run',fake_collect)
    for n,name in enumerate(c.NAMES):
        b.run_phase(name,root);_,state=b.invocation(root);assert state['next_phase']==n+1;b.verify_receipts(cfg,state)
        proof=c.read(Path(state['proofs'][-1]['evidence'])/'report.json');assert proof['termination_scope_completed']
    with pytest.raises(ValueError):b.run_phase(c.NAMES[-1],root)

def test_failed_outer_cleanup_does_not_advance(prepared,monkeypatch):
    root,cfg=prepared.prepare();monkeypatch.setattr(bridge_collect,'run',fake_collect)
    @contextmanager
    def fail_exit():
        yield
        raise RuntimeError('restoration')
    old=bridge_terminal.finish
    monkeypatch.setattr(bridge_terminal,'finish',lambda p,f,w:old(p,f,w,termination=fail_exit))
    with pytest.raises(RuntimeError):b.run_phase(c.NAMES[0],root)
    assert c.read(root/'bridge_state.json')['next_phase']==0
    assert c.read(Path(cfg['evidence_root'])/'00/report.json')['passed']is False

def test_no_implicit_retry_after_failed_request_publication(prepared,monkeypatch):
    root,cfg=prepared.prepare();monkeypatch.setattr(bridge_collect,'run',lambda *a,**kw:(_ for _ in ()).throw(ValueError('incomplete')))
    with pytest.raises(ValueError):b.run_phase(c.NAMES[0],root)
    with pytest.raises(FileExistsError):b.run_phase(c.NAMES[0],root)

def test_changed_prior_phase_report_rejected(prepared,monkeypatch):
    root,cfg=prepared.prepare();monkeypatch.setattr(bridge_collect,'run',fake_collect);b.run_phase(c.NAMES[0],root)
    p=Path(cfg['evidence_root'])/'00/report.json';r=c.read(p);r['operation_complete']=False;c.write(p,r)
    with pytest.raises(ValueError):b.run_phase(c.NAMES[1],root)
