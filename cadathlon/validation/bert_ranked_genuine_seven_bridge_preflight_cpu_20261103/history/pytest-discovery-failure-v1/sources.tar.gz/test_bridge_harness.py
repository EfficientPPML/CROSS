"""Outer process lifecycle only; no upstream/model/key execution."""
from pathlib import Path
from types import SimpleNamespace as NS
from contextlib import contextmanager
import pytest
import bridge_common as c,bridge_protocol as protocol,bridge_harness as h
from test_bridge_integration import prepared

@pytest.fixture
def outer(prepared,monkeypatch):
    root,cfg=prepared.prepare();monkeypatch.setattr(protocol,'authorize',lambda *a,**kw:None);fault={};events=[]
    def child(command,directory,*,timeout,cleanup_grace_s):
        assert timeout is None and cleanup_grace_s==180.;events.append('child')
        assert Path(command[1]).name=='bridge_harness.py'
        if fault.get('raise'):raise fault['raise']
        proof=dict(passed=True,termination_scope_completed=True,source_hashes_start=cfg['source_hashes'],source_hashes_end=cfg['source_hashes']);proof.update(fault.get('proof',{}))
        c.write(root/'bridge_harness_report.json',proof)
        record=dict(returncode=0,process_reaped=True,public_key_store_removed=True,owned_directory_handle_closed=True,result=dict(passed=True,genuine=True,report_sha256=c.digest((root/'bridge_harness_report.json').read_bytes())))
        record.update(fault.get('record',{}));c.write(directory/'process.json',record);return record
    monkeypatch.setattr(h.process,'run_case',child)
    return NS(root=root,cfg=cfg,fault=fault,events=events,target=prepared.tmp/'outer')

def test_complete_outer_terminal_and_reaping(outer):
    r=h.run_prepared(outer.root,outer.target)
    assert r['passed'] and r['terminal_scope_completed'] and r['termination_scope_completed'] and r['all_processes_reaped']

@pytest.mark.parametrize('field',['process_reaped','public_key_store_removed','owned_directory_handle_closed'])
def test_incomplete_outer_cleanup_cannot_pass(outer,field):
    outer.fault['record']={field:False}
    with pytest.raises(ValueError):h.run_prepared(outer.root,outer.target)
    report=c.read(outer.target/'result.json');assert not report['passed'] and not report['all_processes_reaped']

def test_outer_primary_cancellation_and_unknown_process(outer):
    primary=KeyboardInterrupt('synthetic');outer.fault['raise']=primary
    with pytest.raises(KeyboardInterrupt) as seen:h.run_prepared(outer.root,outer.target)
    assert seen.value is primary
    r=c.read(outer.target/'result.json');assert not r['passed'] and not r['all_processes_reaped']

def test_outer_cannot_mutate_attempt_before_containment(outer):
    with pytest.raises(ValueError):h.run_prepared(outer.root,outer.root/'forbidden')
    assert not (outer.root/'forbidden').exists() and not outer.events

def test_changed_sources_fail_closed_after_child(outer):
    outer.fault['proof']={'source_hashes_end':{}}
    with pytest.raises(ValueError):h.run_prepared(outer.root,outer.target)
    assert c.read(outer.target/'result.json')['passed']is False
