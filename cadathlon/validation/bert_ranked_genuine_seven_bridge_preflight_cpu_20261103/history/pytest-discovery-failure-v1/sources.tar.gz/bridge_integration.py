"""Fresh genuine seven-executable wiring; no synthetic backend or key fallback."""
from pathlib import Path
import os,stat,sys
import bridge_common as common,bridge_protocol as protocol
import ranked_execution as execution,ranked_case_gate as cases

def prepare(root,*,size,seed,fixture_evidence,fixture_report_sha256,reference_evidence,reference_report_sha256,authorization,evidence_root,hardware_policy_sha256,cache_policy_sha256,num_runs=1):
    if type(num_runs)is not int or num_runs!=1:raise ValueError('initial genuine bridge preserves original default num_runs1 only')
    if type(size)is not int or size not in common.COUNTS or type(seed)is not int or seed not in (42,43,44):raise ValueError('ranked original size/seed required')
    common.reject_test_environment()
    for value in (hardware_policy_sha256,cache_policy_sha256):__import__('key_gate').sha_field(value)
    authorized=cases.authenticate(fixture_evidence,fixture_report_sha256,reference_evidence,reference_report_sha256);case=authorized.case(size,seed)
    root=execution.outside(root,execution.protected(case));evidence=execution.outside(evidence_root,execution.protected(case)+(root,fixture_evidence,reference_evidence))
    if root.exists() or root.is_symlink() or evidence.exists() or evidence.is_symlink():raise FileExistsError('fresh attempt and evidence roots required')
    raw=common.sources();expected=common.hashes(raw)
    base=dict(stage=1,size=size,seed=seed,staged_root=str(root),attempt_sha256='0'*64,fixture_evidence=str(fixture_evidence),fixture_report_sha256=fixture_report_sha256,
        reference_evidence=str(reference_evidence),reference_report_sha256=reference_report_sha256,key_evidence=None,key_report_sha256=None,model_evidence=None,model_report_sha256=None,predecessors=[])
    envelope=dict(schema='cross-ranked-genuine-seven-request-v1',request=base,phase=common.NAMES[0],partial=None,authorization=authorization)
    protocol.validate_envelope(envelope);protocol.authorize(envelope,expected,case,check_storage=True) # before mkdir/key/model/input work
    attempt=execution.initialize_attempt(root,case);evidence.mkdir(mode=0o700)
    source=root/'_source';source.mkdir(mode=0o700)
    for name,data in raw.items():
        p=source/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    pins=common.read(common.HERE/'upstream/manifest.json')
    for name,h in pins.items():
        data=raw['upstream/'+name]
        if common.digest(data)!=h:raise ValueError('original harness pin differs')
        p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    (root/'submissions').mkdir()
    for name in common.NAMES:(root/'submissions'/(name+'.py')).write_bytes(raw['bridge_entry_template.py'])
    base['attempt_sha256']=attempt
    cfg=dict(schema='cross-ranked-genuine-seven-invocation-v1',base_request=base,authorization=authorization,evidence_root=str(evidence),num_runs=1,
        source_hashes=expected,source_inventory_sha256=common.digest(common.canonical(expected)),harness_hashes=pins,
        root_identity=list(_identity(root)),evidence_identity=list(_identity(evidence)),genuine_launch_authorized=True,hardware_policy_sha256=hardware_policy_sha256,cache_policy_sha256=cache_policy_sha256)
    common.write(root/'bridge_invocation.json',cfg);common.write(root/'bridge_state.json',dict(next_phase=0,proofs=[]))
    return cfg

def _identity(path):
    info=Path(path).lstat()
    if not stat.S_ISDIR(info.st_mode) or stat.S_IMODE(info.st_mode)!=0o700:raise ValueError('owned0700 directory required')
    return info.st_dev,info.st_ino

def invocation(root):
    root=Path(root).absolute();config=common.read(root/'bridge_invocation.json');base=config['base_request']
    if config.get('schema')!='cross-ranked-genuine-seven-invocation-v1' or type(config.get('num_runs'))is not int or config['num_runs']!=1 or config.get('genuine_launch_authorized')is not True:raise ValueError('genuine default-one invocation required')
    if str(root)!=base['staged_root'] or list(_identity(root))!=config['root_identity'] or list(_identity(config['evidence_root']))!=config['evidence_identity']:raise ValueError('attempt/evidence identity differs')
    state=common.read(root/'bridge_state.json')
    if type(state)is not dict or set(state)!={'next_phase','proofs'} or type(state['next_phase'])is not int or not 0<=state['next_phase']<=7 or len(state['proofs'])!=state['next_phase']:raise ValueError('ordered phase state differs')
    current=common.hashes(common.sources())
    if current!=config['source_hashes'] or common.digest(common.canonical(current))!=config['source_inventory_sha256']:raise ValueError('genuine source inventory differs')
    pins=common.read(common.HERE/'upstream/manifest.json')
    if pins!=config['harness_hashes'] or {n:common.digest((root/n).read_bytes()) for n in pins}!=pins:raise ValueError('original complete harness differs')
    for name in common.NAMES:
        if (root/'submissions'/(name+'.py')).read_bytes()!=(common.HERE/'bridge_entry_template.py').read_bytes():raise ValueError('literal stage wrapper differs')
    # These aliases must be rejected before original rm -rf and dataset setup.
    folder=execution.NAMES[base['size']]
    for rel in ('io','datasets','measurements','harness','submissions','_source',f'io/{folder}',f'io/{folder}/intermediate','io/server_data',f'datasets/{folder}',f'datasets/{folder}/intermediate',f'measurements/{folder}'):
        if (root/rel).is_symlink():raise ValueError('owned upstream path alias rejected')
    return config,state

def envelope_for(config,state,phase):
    i=state['next_phase']
    if i>=7 or phase!=common.NAMES[i]:raise ValueError('literal original phase order differs')
    base=dict(config['base_request'],stage=protocol.STAGES[phase]);proofs=state['proofs']
    if i>=1:base.update(key_evidence=proofs[0]['evidence'],key_report_sha256=proofs[0]['report_sha256'])
    if i>=2:base.update(model_evidence=proofs[1]['evidence'],model_report_sha256=proofs[1]['report_sha256'])
    base['predecessors']=[dict(stage=s,evidence=proofs[k]['evidence'],report_sha256=proofs[k]['report_sha256']) for s,k in ((3,3),(4,4)) if s<base['stage']]
    partial=None if phase not in protocol.REQUIRES else dict(phase=protocol.REQUIRES[phase],evidence=proofs[i-1]['evidence'],report_sha256=proofs[i-1]['report_sha256'])
    return protocol.validate_envelope(dict(schema='cross-ranked-genuine-seven-request-v1',request=base,phase=phase,partial=partial,authorization=config['authorization']))

def verify_receipts(config,state):
    for i,item in enumerate(state['proofs']):
        if type(item)is not dict or set(item)!={'phase','evidence','report_sha256'} or item['phase']!=common.NAMES[i] or Path(item['evidence'])!=Path(config['evidence_root'])/f'{i:02d}':raise ValueError('ordered evidence descriptor differs')
        raw=__import__('key_gate').read(Path(item['evidence'])/'report.json',16<<20)
        if common.digest(raw)!=item['report_sha256']:raise ValueError('previous phase report changed')
        p=__import__('key_gate').parse(raw)
        if any(p.get(n)is not True for n in ('passed','execute','operation_complete','all_processes_reaped','cleanup_completed','terminal_scope_completed','termination_scope_completed')) or p.get('error'):raise ValueError('previous phase incomplete')
        old=envelope_for(config,dict(next_phase=i,proofs=state['proofs'][:i]),common.NAMES[i])
        if p.get('request_sha256')!=common.digest(common.canonical(old)) or p.get('source_hashes_start')!=config['source_hashes']:raise ValueError('phase request/source chain differs')

def run_phase(phase,root):
    import bridge_collect,bridge_terminal
    config,state=invocation(root);verify_receipts(config,state);envelope=envelope_for(config,state,phase)
    folder=Path(config['evidence_root']);request=folder/f"request-{state['next_phase']:02d}.json"
    if request.exists() or request.is_symlink():raise FileExistsError('phase retry requires explicit recovery; no overwrite')
    common.write(request,envelope);target=folder/f"{state['next_phase']:02d}"
    proof=bridge_terminal.finish(target/'report.json',lambda:bridge_collect.run(target,request,common.digest(request.read_bytes()),execute=True),common.write)
    if any(proof.get(n)is not True for n in ('passed','operation_complete','termination_scope_completed')):raise ValueError('complete phase required before advance')
    # Advance only after worker+collector+outer cleanup succeeds.
    state['proofs'].append(dict(phase=phase,evidence=str(target),report_sha256=common.digest((target/'report.json').read_bytes())))
    state['next_phase']+=1;common.write(Path(root)/'bridge_state.json',state)
    return proof

def entry_main(phase,root):
    config,_=invocation(root)
    if len(sys.argv)!=2 or sys.argv[1]!=str(config['base_request']['size']):raise ValueError('exact original single size argument required')
    run_phase(phase,root)
