"""Public split-stage proof contracts. No payload reader or implicit authorization."""
from pathlib import Path
import bridge_common as common
import key_gate,ranked_worker as parent,ranked_stage_gate as gate
NAMES=common.NAMES
STAGES=dict(zip(NAMES,(1,2,3,3,4,5,5)))
PARTIAL=('client_preprocess_input','client_decrypt_decode')
REQUIRES={'client_encode_encrypt_input':'client_preprocess_input','client_postprocess':'client_decrypt_decode'}
AUTH_FIELDS={'size0_evidence','size0_report_sha256','storage_path','storage_sha256'}

def validate_envelope(value):
    if type(value)is not dict or set(value)!={'schema','request','phase','partial','authorization'} or value['schema']!='cross-ranked-genuine-seven-request-v1':raise ValueError('exact genuine bridge envelope required')
    phase=value['phase'];r=value['request']
    if type(phase)is not str or phase not in STAGES or type(r)is not dict or set(r)!=parent.REQUEST_FIELDS or type(r['stage'])is not int or r['stage']!=STAGES[phase]:raise ValueError('literal seven phase and parent stage mismatch')
    if type(value['authorization'])is not dict or set(value['authorization'])!=AUTH_FIELDS:raise ValueError('external size0/storage authorization required')
    for n in ('size0_report_sha256','storage_sha256'):key_gate.sha_field(value['authorization'][n])
    part=value['partial']
    if phase in REQUIRES:
        if type(part)is not dict or set(part)!={'phase','evidence','report_sha256'} or part['phase']!=REQUIRES[phase]:raise ValueError('completed ordered partial phase required')
        key_gate.sha_field(part['report_sha256'])
    elif part is not None:raise ValueError('unexpected partial producer')
    return value

def authorize(envelope,expected,case,*,check_storage=False):
    common.reject_test_environment()
    import launch_authorization
    a=envelope['authorization']
    return launch_authorization.authenticate(**a,case_binding=gate.case_binding(case),source_inventory_sha256=common.digest(common.canonical(expected)),staged_parent=Path(envelope['request']['staged_root']).parent,check_storage=check_storage)

def binding(envelope,expected,bindings):
    return dict(schema='cross-ranked-genuine-phase-binding-v1',phase=envelope['phase'],bindings=bindings,
        attempt_sha256=envelope['request']['attempt_sha256'],staged_root=str(Path(envelope['request']['staged_root']).absolute()),
        source_inventory_sha256=common.digest(common.canonical(expected)),authorization=envelope['authorization'],
        partial_report_sha256=None if envelope['partial'] is None else envelope['partial']['report_sha256'])

def declared_phases(phase):
    if phase=='client_preprocess_input':
        return dict(encryption=False,decryption=False,server_compute=False,model_forward=False,key_generation=False,input_preprocessing=True)
    stage=STAGES[phase]
    if stage<3:return __import__('ranked_setup').phases(stage)
    # Complete postprocess proof composes its authenticated genuine decode
    #producer. invoked_entrypoints distinguishes the current physical work.
    return dict(encryption=stage==3,decryption=stage==5,server_compute=stage==4,model_forward=False,key_generation=False)


def require_fresh(paths,phase):
    import ranked_execution as execution
    if phase=='client_encode_encrypt_input':
        names=('upload','download','decrypted_results','predictions','server_report')
        if not paths['preprocessed_input'].is_file():raise ValueError('authenticated preprocessing output required')
        for name in ('requests.json','completed.json'):
            p=paths['client_private']/name
            if p.exists() or p.is_symlink():raise FileExistsError('fresh request ledger required')
    elif phase=='client_postprocess':names=('predictions',)
    else:return execution.require_fresh(paths,STAGES[phase])
    for n in names:
        if paths[n].exists() or paths[n].is_symlink():raise FileExistsError('split output already exists')

def _worker_record(directory,record,expected,bindings,envelope):
    if (type(record)is not dict or type(record.get('returncode'))is not int or record['returncode']!=0 or record.get('error')
        or any(record.get(n)is not True for n in ('process_reaped','public_key_store_removed','owned_directory_handle_closed'))):raise ValueError('split phase process not cleanly reaped')
    raw=key_gate.read(Path(directory)/'worker_report.json',16<<20);proof=key_gate.parse(raw);result=record.get('result')
    if type(result)is not dict or result.get('passed')is not True or result.get('worker_report_sha256')!=common.digest(raw):raise ValueError('split phase worker digest differs')
    if (type(proof)is not dict or any(proof.get(n)is not True for n in ('passed','actual_stage_started','actual_stage_completed','readback_complete','source_files_unchanged','cleanup_completed','terminal_scope_completed','termination_scope_completed'))
        or proof.get('error') or proof.get('cleanup_errors') or proof.get('forbidden_attempts') or proof.get('bindings')!=bindings
        or type(proof.get('stage'))is not int or proof['stage']!=STAGES[envelope['phase']]
        or proof.get('bridge_phase')!=envelope['phase'] or proof.get('bridge_binding')!=binding(envelope,expected,bindings)
        or any(proof.get(n)!=expected for n in ('source_hashes_start','source_hashes_end'))):raise ValueError('split phase terminal/source/identity differs')
    if common.canonical(proof.get('phases'))!=common.canonical(declared_phases(envelope['phase'])):raise ValueError('physical/aggregate phase flags differ')
    if proof.get('invoked_entrypoints')!=[envelope['phase']]:raise ValueError('exactly one literal entrypoint per timed process required')
    return proof

def partial_summary(proof,phase,case_binding):
    data=proof.get('readback');count=case_binding['count']
    if type(data)is not dict or type(data.get('sample_count'))is not int or data['sample_count']!=count:raise ValueError('complete partial record count required')
    if phase=='client_preprocess_input':
        if proof.get('actual_preprocessing_completed')is not True or data.get('preprocessed_input_sha256')!=case_binding['input_sha256']:raise ValueError('partial preprocessing binding differs')
        key_gate.sha_field(data.get('input_sha256'))
    elif (data.get('private_receipt_validated')is not True or data.get('result_permissions_0600')is not True
            or data.get('metrics',{}).get('all_ordered_finite_logits_validated')is not True
            or data.get('metrics',{}).get('postprocessed_predictions_validated')is not False):raise ValueError('complete decode-only receipt required')
    else:
        for name in ('decoded_result_sha256','completed_receipt_sha256','public_batch_sha256'):key_gate.sha_field(data.get(name))
    return data

def completed_worker(directory,record,expected,bindings,stage,*,case,previous,envelope):
    proof=_worker_record(directory,record,expected,bindings,envelope)
    if envelope['phase'] not in PARTIAL:
        import ranked_collect
        ranked_collect.completed_worker(directory,record,expected,bindings,stage,case=case,previous=previous)
    else:partial_summary(proof,envelope['phase'],gate.case_binding(case))
    return proof


def authenticate_partial(envelope,expected,bindings):
    part=envelope['partial']
    if part is None:return None
    evidence=Path(part['evidence']);raw=key_gate.read(evidence/'report.json',16<<20)
    if common.digest(raw)!=part['report_sha256']:raise ValueError('externally pinned partial producer differs')
    report=key_gate.parse(raw)
    predecessor=dict(envelope,phase=part['phase'],partial=None)
    if (type(report)is not dict or type(report.get('stage'))is not int or report['stage']!=STAGES[part['phase']] or report.get('schema')!='cross-bert-ranked-split-phase-proof-v1'
        or any(report.get(n)is not True for n in ('passed','execute','actual_execution_attempted','operation_complete','all_processes_reaped','owned_artifacts_retained','cleanup_completed','source_files_unchanged','source_archive_verified','terminal_scope_completed','termination_scope_completed'))
        or report.get('error') or report.get('cleanup_errors') or report.get('bridge_binding')!=binding(predecessor,expected,bindings)
        or report.get('bridge_phase')!=part['phase'] or report.get('bindings')!=bindings
        or any(report.get(n)!=expected for n in ('source_hashes_start','source_hashes_end','execution_source_hashes_end'))):raise ValueError('complete source-bound partial producer required')
    archived=key_gate.read(evidence/'sources.tar.gz',16<<20)
    if common.digest(archived)!=report.get('source_archive_sha256'):raise ValueError('partial archive digest differs')
    gate._archive(archived,expected)
    proof=_worker_record(evidence/'worker',report.get('worker_process'),expected,bindings,predecessor)
    partial_summary(proof,part['phase'],bindings['case_binding'])
    if proof.get('readback')!=report.get('readback'):raise ValueError('partial readback producer differs')
    return proof
