from pathlib import Path
import hashlib,json,subprocess,sys,time
from extract import source_files
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'source-bound-v1';OUT.mkdir(exist_ok=False)
def inventory():return {n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in source_files().items()}
started=time.monotonic();before=inventory();commands=[]
for name,cmd in [('tests',[sys.executable,'-m','pytest','-q','test_public.py']),('extract',[sys.executable,'extract.py','--output',str(ROOT/'public-v1')])]:
    with (OUT/(name+'.log')).open('w') as log:result=subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=False)
    commands.append(dict(name=name,command=cmd,returncode=result.returncode))
    if result.returncode:break
after=inventory();report=dict(passed=len(commands)==2 and all(c['returncode']==0 for c in commands) and before==after,
    commands=commands,source_hashes_before=before,source_hashes_after=after,source_files_unchanged=before==after,elapsed_s=time.monotonic()-started)
(OUT/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(json.dumps({k:v for k,v in report.items() if not k.startswith('source_hashes')},indent=2))
raise SystemExit(0 if report['passed'] else 1)
