"""Narrow pinned-safetensors BF16 reader; direct exact FP32 promotion only."""
from pathlib import Path
import hashlib,json,math
import numpy as np
from exact_rows import promote

class Reader:
    def __init__(self,path):
        self.path=Path(path);self.records={}
        with self.path.open('rb') as f:
            prefix=f.read(8)
            if len(prefix)!=8:raise ValueError('missing header')
            length=int.from_bytes(prefix,'little')
            if not 0<length<=16*1024*1024:raise ValueError('invalid header size')
            raw=f.read(length)
            if len(raw)!=length:raise ValueError('truncated header')
        self.header=json.loads(raw);self.base=8+length
        if not isinstance(self.header,dict):raise ValueError('invalid header')
    def chunks(self,name,shape,chunk_rows=1024):
        if type(chunk_rows)is not int or chunk_rows<1:raise ValueError('chunk rows')
        desc=self.header[name]
        if desc['dtype']!='BF16' or desc['shape']!=list(shape):raise ValueError('pinned BF16 tensor contract')
        lo,hi=desc['data_offsets'];width=math.prod(shape[1:])
        if type(lo)is not int or type(hi)is not int or lo<0 or hi-lo!=math.prod(shape)*2 or self.base+hi>self.path.stat().st_size:raise ValueError('tensor extent')
        rawhash=hashlib.sha256();promotedhash=hashlib.sha256()
        with self.path.open('rb') as f:
            f.seek(self.base+lo)
            for start in range(0,shape[0],chunk_rows):
                count=min(chunk_rows,shape[0]-start);raw=f.read(count*width*2)
                if len(raw)!=count*width*2:raise ValueError('truncated tensor')
                words=np.frombuffer(raw,dtype='<u2').reshape((count,)+tuple(shape[1:]))
                promoted=promote(words);rawhash.update(raw);promotedhash.update(promoted.tobytes())
                yield start,words,promoted
        self.records[name]=dict(shape=list(shape),source_dtype='BF16',source_raw_bytes=hi-lo,
            source_raw_sha256=rawhash.hexdigest(),promoted_dtype='<f4',promoted_sha256=promotedhash.hexdigest(),promotion_exact=True)
    def read(self,name,shape):return np.concatenate([p for _,_,p in self.chunks(name,shape)],axis=0)
