"""Exact BF16 stored-value square/sums; no floating summation is used."""
from fractions import Fraction as F
import math
import numpy as np


def endpoints(value):
    value=F(value);nearest=float(value)
    if not math.isfinite(nearest):raise ValueError('finite endpoint required')
    return dict(fraction=[str(value.numerator),str(value.denominator)],
                lower_binary64=math.nextafter(nearest,-math.inf) if F(nearest)>value else nearest,
                upper_binary64=math.nextafter(nearest,math.inf) if F(nearest)<value else nearest)


def promote(words):
    words=np.asarray(words)
    if words.dtype!=np.dtype('<u2'):raise TypeError('exact BF16 uint16 words required')
    bits=words.astype('<u4')<<np.uint32(16)
    array=bits.view('<f4')
    if not np.isfinite(array).all():raise ValueError('nonfinite BF16 public tensor')
    if not np.array_equal(array.view('<u4')>>np.uint32(16),words):raise ValueError('inexact promotion')
    return array


def square_sums(words):
    words=np.asarray(words)
    if words.dtype!=np.dtype('<u2') or words.ndim!=2 or not words.size:raise ValueError('nonempty BF16 row matrix required')
    exponent=((words>>7)&255).astype(np.int64)
    if np.any(exponent==255):raise ValueError('nonfinite BF16')
    mantissa=(words&127).astype(np.uint64)
    mantissa[exponent!=0]|=np.uint64(128)
    power=2*np.where(exponent==0,-133,exponent-134)
    for mant,powers in zip(mantissa,power):
        active=mant!=0
        if not np.any(active):yield F();continue
        low=int(powers[active].min())
        total=sum(m*m << (e-low) for m,e in zip(mant[active].tolist(),powers[active].tolist()))
        yield F(total<<low) if low>=0 else F(total,1<<-low)


def pair_products(q,k):
    q,k=np.asarray(q),np.asarray(k)
    if q.dtype!=np.float32 or k.dtype!=np.float32 or q.shape!=(128,) or k.shape!=(128,) or not np.isfinite(q).all() or not np.isfinite(k).all():raise ValueError('two finite public binary32 head vectors required')
    q=[abs(F(float(v))) for v in q];k=[abs(F(float(v))) for v in k]
    global_product=max(q)*max(k)
    paired=max(max(q[i],q[i+64])*max(k[i],k[i+64]) for i in range(64))
    same=max(x*y for x,y in zip(q,k))
    assert same<=paired<=global_product
    return dict(global_gamma_product=global_product,rope_pair_gamma_product=paired,same_position_gamma_product=same)


def sqrt_upper(value):
    value=F(value);out=math.sqrt(float(value))
    if not math.isfinite(out):raise ValueError('finite root required')
    while F(out)*F(out)<value:out=math.nextafter(out,math.inf)
    return out
