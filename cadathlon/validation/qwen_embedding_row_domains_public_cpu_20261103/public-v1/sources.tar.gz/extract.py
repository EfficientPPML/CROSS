"""Exact public embedding-row RMS interval and pair-preserving RoPE bounds."""
from pathlib import Path
from fractions import Fraction as F
import argparse,hashlib,io,json,os,sys,tarfile,time
import numpy as np
from exact_rows import endpoints,promote,square_sums,pair_products,sqrt_upper
from tensor_reader import Reader
HERE=Path(__file__).resolve().parent
SNAPSHOT=Path('/home/jianming_gatech/cross_validation_assets/qwen/c1899de289a04d12100db370d81485cdf75e47ca')
OUTER_SHA='5fb9e98bd0baaaf9f6591fa8842752c114cc50877f8abc880b69311d141f5fa8'
PINS_SHA='6ce7cff55898969d0b4f60140179ebf8ce34a3b26de886e21f2c0beaba3415f5'


def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def write(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')


def source_files():
    return {str(p.relative_to(HERE)):p for p in HERE.rglob('*') if p.is_file() and p.suffix in ('.py','.json','.md')
        and not any(part.startswith('public-') or part.startswith('source-bound-') for part in p.relative_to(HERE).parts[:-1])
        and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts}


def run(output):
    output.mkdir(exist_ok=False);started=time.monotonic();primary=None;files={};before={};assets={}
    report=dict(passed=False,complete=False,scope=__doc__,model_forward=False,coefficient_selection=False,
        model_inputs_or_tokens_read=False,HE_or_backend_initialized=False,errors=[],cpu_affinity=sorted(os.sched_getaffinity(0)))
    try:
        write(output/'report.json',report)
        files=source_files();before={n:sha(p) for n,p in files.items()}
        with tarfile.open(output/'sources.tar.gz','w:gz') as t:
            for name,path in files.items():
                raw=path.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);t.addfile(info,io.BytesIO(raw))
        with tarfile.open(output/'sources.tar.gz') as t:
            members=t.getmembers()
            if len(members)!=len(before) or len({m.name for m in members})!=len(before) or any(not m.isfile() for m in members):raise ValueError('source archive inventory')
            if {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in members}!=before:raise ValueError('source archive bytes')
        report.update(source_hashes_before=before,source_archive_sha256=sha(output/'sources.tar.gz'))
        if sha(HERE/'inputs/outer_domains.json')!=OUTER_SHA or sha(HERE/'inputs/model_pins.json')!=PINS_SHA:raise ValueError('frozen public input changed')
        outer=json.loads((HERE/'inputs/outer_domains.json').read_text());pins=json.loads((HERE/'inputs/model_pins.json').read_text())
        assets={name:sha(SNAPSHOT/name) for name in pins['asset_sha256']}
        if assets!=pins['asset_sha256']:raise ValueError('pinned model assets changed')
        report['asset_sha256_before']=assets
        config=json.loads((SNAPSHOT/'config.json').read_text())
        for name,value in dict(hidden_size=1024,vocab_size=151936,head_dim=128,num_attention_heads=16,num_key_value_heads=8,num_hidden_layers=28,attention_bias=False).items():
            if type(config[name]) is not type(value) or config[name]!=value:raise ValueError('fixed architecture changed '+name)
        eps=F(config['rms_norm_eps']);eps32=F(float(np.float32(config['rms_norm_eps'])))
        if eps<=0 or not outer['passed'] or outer['sites_count']!=113:raise ValueError('public contract invalid')
        reader=Reader(SNAPSHOT/'model.safetensors')
        if sorted(set(reader.header)-{'__metadata__'})!=outer['tensor_inventory']:raise ValueError('whole tensor/bias inventory differs')
        count=151936;width=1024;name='model.embed_tokens.weight';seen=0;stream=hashlib.sha256();low=high=None;lo_index=hi_index=None
        low_words=high_words=None;coordinate=np.zeros(width,dtype=np.float32)
        selected=set(i*(count-1)//63 for i in range(64));checks=[]
        squares_f32_exact=True;minimum_nonzero_square=None
        for start,words,values in reader.chunks(name,(count,width)):
            coordinate=np.maximum(coordinate,np.max(np.abs(values),axis=0))
            # Observational arithmetic property of public stored weights only;
            # native mean/add instruction order is not inferred from this check.
            exact_products=values.astype(np.float64)**2;rounded=exact_products.astype(np.float32).astype(np.float64)
            squares_f32_exact=squares_f32_exact and bool(np.array_equal(exact_products,rounded))
            nonzero=exact_products[exact_products>0]
            if nonzero.size:
                m=float(nonzero.min());minimum_nonzero_square=m if minimum_nonzero_square is None else min(minimum_nonzero_square,m)
            for i,total in enumerate(square_sums(words)):
                index=start+i;stream.update(f'{index}:{total.numerator}/{total.denominator}\n'.encode());seen+=1
                if low is None or total<low:low,lo_index,low_words=total,index,words[i].copy()
                if high is None or total>high:high,hi_index,high_words=total,index,words[i].copy()
                if index in selected:
                    independent=sum((F(float(x))**2 for x in values[i]),F())
                    if independent!=total:raise AssertionError('independent rational row sum mismatch')
                    checks.append(dict(row=index,sum_squares=endpoints(total)))
            if seen%32768==0 or seen==count:print(json.dumps(dict(rows_complete=seen,total=count,elapsed_s=time.monotonic()-started)),flush=True)
        if seen!=count or len(checks)!=64:raise AssertionError('embedding coverage')
        for index,words,total in [(lo_index,low_words,low),(hi_index,high_words,high)]:
            if sum((F(float(x))**2 for x in promote(words)),F())!=total:raise AssertionError('extremal row sum mismatch')
        if coordinate.astype(np.float64).tolist()!=outer['embedding_coordinate_upper']:raise ValueError('prior coordinate envelope changed')
        coord_upper=sum((F(float(x))**2 for x in coordinate),F())/width+eps
        expected=F(*map(int,outer['sites']['0.input.inverse_sqrt']['upper_fraction']))
        if coord_upper!=expected:raise AssertionError('coordinate bound comparison')
        denominator_low=low/width+eps;denominator_high=high/width+eps
        assert eps<=denominator_low<=denominator_high<=coord_upper
        report['embedding']=dict(rows=seen,width=width,sum_squares_minimum=endpoints(low),sum_squares_maximum=endpoints(high),
            minimum_row=lo_index,maximum_row=hi_index,exact_row_sum_stream_sha256=stream.hexdigest(),
            denominator_interval=dict(lower=endpoints(denominator_low),upper=endpoints(denominator_high)),
            configured_binary64_epsilon=endpoints(eps),binary32_epsilon=endpoints(eps32),
            epsilon_binary32_minus_configured=endpoints(eps32-eps),
            exact_stored_squares_with_binary32_epsilon_interval=dict(lower=endpoints(low/width+eps32),upper=endpoints(high/width+eps32)),
            prior_coordinate_upper=endpoints(coord_upper),upper_tightening_ratio=endpoints(coord_upper/denominator_high),
            lower_improvement_ratio=endpoints(denominator_low/eps),condition_ratio=endpoints(denominator_high/denominator_low),
            prior_condition_ratio=endpoints(coord_upper/eps),independent_fraction_rows=checks,
            extrema_independently_checked=True,all_stored_embedding_squares_exact_binary32=squares_f32_exact,
            minimum_nonzero_stored_square=minimum_nonzero_square,
            native_float32_reduction_equivalence_claimed=False,
            note='Exact BF16→FP32 stored values squared/summed in rational arithmetic. Configured binary64 epsilon defines the primary interval. Alternate binary32 epsilon is isolated; native pow/mean/add rounding and implementation order are not certified.')
        score=[];root=F(sqrt_upper(F(128)));delta=F(1,10**6)
        for layer in range(28):
            prefix=f'model.layers.{layer}.self_attn.'
            q=reader.read(prefix+'q_norm.weight',(128,));k=reader.read(prefix+'k_norm.weight',(128,))
            products=pair_products(q,k);row=dict(layer=layer)
            for kind,product in products.items():
                bound=root*product
                row[kind]=dict(gamma_product=endpoints(product),exact_native_score_abs_upper=endpoints(bound),
                    K32_centered_abs_upper=endpoints(2*F(31,32)*bound),
                    conditional_uniform_norm_delta_1e6_score_abs_upper=endpoints(bound*(1+delta)**2))
            row['pair_bound_tightening_ratio']=endpoints(products['global_gamma_product']/products['rope_pair_gamma_product'])
            score.append(row)
        if len(reader.records)!=57:raise AssertionError('public tensor coverage')
        for tensor,record in reader.records.items():
            if record!=outer['tensor_records'][tensor]:raise ValueError('exact public tensor identity differs '+tensor)
        forbidden=('jax','jaxlib','jaxite_word','torch','transformers')
        clean=not any(n.split('.')[0] in forbidden for n in sys.modules)
        report.update(complete=True,passed=clean,tensors_read=len(reader.records),tensor_records=reader.records,
            no_backend_or_model_imported=clean,post_qk_norm_score_bounds=score,
            score_bound_proof='For exact native RMS with positive epsilon, pre-gamma head norm≤sqrt128. Half-split RoPE preserves each coordinate pair(i,i+64). The norm of diag(gamma_q) Rq.T Rk diag(gamma_k) is at most the largest pairwise product of gamma maxima; same-position rotations cancel exactly. Multiply by128/sqrt128. The rational endpoint encloses sqrt128 outward.',
            limitations=['Public weights only; no prompt/token sequence, model forward or coefficient selection.',
                'The row interval tightens only the first embedding normalization, not later residual or head-projection sites.',
                'Exact-native bounds exclude floating point and CKKS/refresh error; exact orthogonal RoPE is assumed.',
                'The conditional approximate score bound needs uniform relative error at both Q/K norms and the same feature/variance relation; it is not an approximate-graph certificate.',
                'Same-position gamma-product bounds cannot be used for different-position Q/K pairs.',
                'No weights, raw rows, hidden values, keys or ciphertexts are published; exact public aggregate extrema/selected rational sums and tensor hashes are recorded.'])
    except BaseException as exc:
        primary=exc;report['passed']=False;report['errors'].append(dict(phase='body',type=type(exc).__name__,message=str(exc)))
    finally:
        try:
            after={n:sha(p) for n,p in files.items()};report.update(source_hashes_after=after,source_files_unchanged=bool(before) and before==after)
            report['asset_sha256_after']={n:sha(SNAPSHOT/n) for n in assets};report['assets_unchanged']=bool(assets) and report['asset_sha256_after']==assets
            report['passed']=report['passed'] and report['source_files_unchanged'] and report['assets_unchanged']
        except BaseException as exc:
            report['passed']=False;report['errors'].append(dict(phase='final_provenance',type=type(exc).__name__,message=str(exc)))
            if primary is None:primary=exc
            else:primary.add_note('Final provenance: '+repr(exc))
        report['elapsed_s']=time.monotonic()-started
        try:write(output/'report.json',report)
        except BaseException as exc:
            if primary is None:raise
            primary.add_note('Final publication: '+repr(exc))
    if primary is not None:raise primary
    return 0 if report['passed'] else 1

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,required=True)
    raise SystemExit(run(parser.parse_args().output))
