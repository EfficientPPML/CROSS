from fractions import Fraction as F
import io,json,math
import numpy as np
import pytest
from exact_rows import square_sums,promote,endpoints,pair_products,sqrt_upper
from tensor_reader import Reader

@pytest.mark.parametrize('raw',[
 [[0,0x8000,1,0x8001],[0x3f80,0xbf80,0x4000,0xc000]],
 [[0x007f,0x0080,0x7f7f,0xff7f]],
 [[0x3d01,0xbeff,0x4401,0x0400]],
])
def test_exact_squares_against_fraction(raw):
    words=np.asarray(raw,dtype='<u2');values=promote(words)
    assert list(square_sums(words))==[sum((F(float(x))**2 for x in row),F()) for row in values]

@pytest.mark.parametrize('seed',range(4))
def test_random_exact_rows(seed):
    rng=np.random.default_rng(seed);words=rng.integers(0,65536,(7,17),dtype=np.uint16)
    words[(words&0x7f80)==0x7f80]=0
    assert list(square_sums(words))==[sum((F(float(x))**2 for x in row),F()) for row in promote(words)]

@pytest.mark.parametrize('word',[0x7f80,0xff80,0x7fc1])
def test_reject_nonfinite(word):
    with pytest.raises(ValueError):list(square_sums(np.array([[word]],dtype='<u2')))
    with pytest.raises(ValueError):promote(np.array([word],dtype='<u2'))

@pytest.mark.parametrize('v',[F(1,10),F(1,10**6),F(2)**-266,F(3)**2,F(2)**250])
def test_outward_endpoints(v):
    e=endpoints(v);assert F(e['lower_binary64'])<=v<=F(e['upper_binary64'])
    assert F(sqrt_upper(v))**2>=v


def test_pair_bound_improves_separated_maxima():
    q=np.ones(128,dtype=np.float32);k=q.copy();q[0]=10;k[1]=9
    p=pair_products(q,k)
    assert p==dict(global_gamma_product=F(90),rope_pair_gamma_product=F(10),same_position_gamma_product=F(10))
    # Same half-split pair can align under rotation, unlike same-position.
    k[1]=1;k[64]=9
    p=pair_products(q,k);assert p['rope_pair_gamma_product']==90 and p['same_position_gamma_product']==10


def test_pair_rotation_bound_on_public_grid():
    q=np.linspace(-3,4,128,dtype=np.float32);k=np.linspace(5,-2,128,dtype=np.float32)
    bound=float(pair_products(q,k)['rope_pair_gamma_product'])
    for i in range(64):
        for t in np.linspace(-math.pi,math.pi,31):
            a=np.diag(q[[i,i+64]].astype(float));b=np.diag(k[[i,i+64]].astype(float))
            rotation=np.array([[math.cos(t),-math.sin(t)],[math.sin(t),math.cos(t)]])
            assert np.linalg.norm(a@rotation@b,2)<=bound*(1+1e-14)


def file(path,raw,shape=(2,2),dtype='BF16'):
    header=json.dumps({'w':dict(dtype=dtype,shape=list(shape),data_offsets=[0,len(raw)])}).encode()
    path.write_bytes(len(header).to_bytes(8,'little')+header+raw)


def test_reader_exact_inventory(tmp_path):
    path=tmp_path/'x';words=np.array([[0x3f80,0x4000],[0x0080,0x8000]],dtype='<u2');file(path,words.tobytes())
    r=Reader(path);assert np.array_equal(r.read('w',(2,2)),promote(words));assert r.records['w']['source_raw_bytes']==8

@pytest.mark.parametrize('kind',['dtype','shape','truncated','extent'])
def test_reader_rejections(tmp_path,kind):
    path=tmp_path/'x';raw=np.zeros((2,2),dtype='<u2').tobytes()
    file(path,raw,dtype='F32' if kind=='dtype' else 'BF16')
    r=Reader(path)
    if kind=='truncated':path.write_bytes(path.read_bytes()[:-1])
    if kind=='extent':r.header['w']['data_offsets']=[0,10000]
    with pytest.raises(ValueError):list(r.chunks('w',(3,2) if kind=='shape' else (2,2)))
