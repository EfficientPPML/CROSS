# Isolated BERT layer-0 first-attention composition

This candidate composes the actual public matrix/rotation algorithms and
nonlinear owners on ideal NumPy slots. It is not an encrypted result, a complete
BERT block, a file-stage implementation, or evidence of repeated-refresh error.
The refresh double preserves slot values exactly and returns the declared real
profile's level25 with adjacent binary64 scales. Crypto helper stubs raise if
called. Production refresh planning is executed from unchanged public AST
methods, with the complete rotation inventory and five helper identities.

`BertFirstAttention` borrows static arithmetic, a promoted
`ChainedStreamingLinear`, and a bounded refresh engine. It never owns their
keys/context or closes them. Inputs are exactly eight fresh canonical-scale,
level49 ciphertext tiles in a compacted valid-token frame. Original learned
position embeddings are formed before compaction; public original positions
are retained. K/V project all eight tiles; valid query tiles execute scores,
the initial softmax and five normalization rounds, final B2 refresh/mask, PV,
output projection, residual and the pinned attention LayerNorm. The resulting
level path is 49→48→45→24→21→20→9. No domain is inferred from ciphertext.

The schema binds all four pinned layer0 projections, exact ring/scale/layout,
eight request descriptors, context/request identities and original positions.
Response descriptors require the caller's actual output scale. The schema is
not a ciphertext serializer or one of the five full file-stage handlers.

The K15 and K128 fixtures use two fixed public text pairs and pinned BERT
revision f150c1d609d1e50dd5e2e5408661cfac8339277c. Tests execute the actual
chained BSGS loops and full-slot QK/PV routes, with separate dense polynomial
and native float64 references. The unchanged ideal gate is1e-8 on every
physical output slot; an independent exact NumPy/native agreement gate is
1e-11. Polynomial/native differences are reported as diagnostics, without a
new block-accuracy threshold. All propagated valid-query domains are checked.
No padded-query nonlinear-domain claim is made.

Run with the pinned client fixture kept outside the source snapshot:

```
env JAX_PLATFORMS=cpu OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4 \
  taskset -c 120-123 /home/jianming_gatech/miniconda3/envs/jaxite/bin/python \
  check_first_attention_ideal.py --output /tmp/first-attention-new-proof
```

The collector archives exact source bytes and aggregate records, excludes model
and activation arrays, checks source/fixture identity after execution, and
reaps its test process. Existing development snapshots and expected-negative
guard results remain historical. Full layer0 joining, actual encrypted
execution, public-domain/noise margins and common-profile B2 refresh behavior
remain separate required evidence.
