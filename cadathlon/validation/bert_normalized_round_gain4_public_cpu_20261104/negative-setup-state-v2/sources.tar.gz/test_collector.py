"""Public fixture and failure-publication tests; no encrypted execution."""
from pathlib import Path
from types import SimpleNamespace
import hashlib,io,json,sys,tarfile
import numpy as np
import pytest
import collect,public_contract
from fixtures import definitions,make_probabilities,client_oracles,diagnostics,checkpoint_names,derived_checks
from encrypted_bert_normalization_round import NormalizationRoundContract
from encrypted_score_reduction import ScoreReductionLayout

@pytest.fixture
def collector(tmp_path,monkeypatch):
    monkeypatch.setenv('JAX_PLATFORMS','cpu')
    monkeypatch.setattr(collect,'sources',lambda:{'a.py':b'fixed'})
    monkeypatch.setattr(collect.importlib.metadata,'version',lambda n:'test')
    monkeypatch.setattr(public_contract,'preflight',lambda **kw:dict(current_key_storage_free_bytes=100,raw_all_owned_public_key_bytes=1,additional_storage_margin_bytes=1))
    return SimpleNamespace(output=tmp_path/'attempt',preflight=True)

def test_collector_preflight_archives_every_source_and_never_encrypts(collector):
    assert collect.collect(collector)==0
    r=json.loads((collector.output/'report.json').read_text())
    assert r['passed'] and r['complete'] and r['source_archive_verified'] and r['source_files_unchanged']
    assert not r['key_generation_started'] and not r['encryption_started']

@pytest.mark.parametrize('where',('initial_publication','initial_sources','public_preflight','component','final_sources'))
def test_failure_keeps_terminal_evidence_and_primary_cancellation(collector,monkeypatch,where):
    failure=KeyboardInterrupt(where);real_write=collect.write
    if where=='initial_publication':
        calls=[]
        def writer(path,data):
            calls.append(1)
            if len(calls)==1:raise failure
            real_write(path,data)
        monkeypatch.setattr(collect,'write',writer)
    elif where in ('initial_sources','final_sources'):
        calls=[]
        def sources():
            calls.append(1)
            if where=='initial_sources' and len(calls)==1 or where=='final_sources' and len(calls)==2:raise failure
            return {'a.py':b'fixed'}
        monkeypatch.setattr(collect,'sources',sources)
    elif where=='public_preflight':monkeypatch.setattr(public_contract,'preflight',lambda **k:(_ for _ in ()).throw(failure))
    else:
        collector.preflight=False;monkeypatch.setitem(sys.modules,'component',SimpleNamespace(run=lambda *a:(_ for _ in ()).throw(failure)))
    with pytest.raises(KeyboardInterrupt) as caught:collect.collect(collector)
    assert caught.value is failure
    r=json.loads((collector.output/'report.json').read_text());assert not r['passed']
    assert r['errors'] or r['collector_cleanup_errors']

def test_primary_failure_survives_final_publication_error(collector,monkeypatch):
    primary=KeyboardInterrupt('primary');real_write=collect.write;calls=[]
    monkeypatch.setattr(public_contract,'preflight',lambda **k:(_ for _ in ()).throw(primary))
    def write(path,data):
        calls.append(1)
        if len(calls)>1:raise OSError('publication')
        return real_write(path,data)
    monkeypatch.setattr(collect,'write',write)
    with pytest.raises(KeyboardInterrupt) as caught:collect.collect(collector)
    assert caught.value is primary and any('publication' in note for note in primary.__notes__)

@pytest.mark.parametrize('kind',('duplicate','different','symlink'))
def test_source_archive_exact_member_readback(tmp_path,kind):
    path=tmp_path/'source.tar.gz';raw=b'one';expected={'a':hashlib.sha256(raw).hexdigest()}
    with tarfile.open(path,'w:gz') as t:
        member=tarfile.TarInfo('a');member.size=3
        if kind=='symlink':member.type=tarfile.SYMTYPE;member.linkname='else';member.size=0;t.addfile(member)
        else:
            t.addfile(member,io.BytesIO(b'two' if kind=='different' else raw))
            if kind=='duplicate':t.addfile(member,io.BytesIO(raw))
    with pytest.raises(ValueError):collect.verify_archive(path,expected)

@pytest.mark.parametrize('kind',('extreme_difference','wide_finite','nan','wrong_shape','wrong_dtype','accurate'))
def test_checkpoint_failure_metrics_are_json_serializable(kind):
    from fixtures import checkpoint_error
    limit=np.finfo(np.float64).max
    expected=np.ones(65536);decoded=expected.copy()
    if kind=='extreme_difference':decoded.fill(limit);expected.fill(-limit)
    elif kind=='wide_finite':decoded=np.full(65536,np.finfo(np.longdouble).max,dtype=np.longdouble)
    elif kind=='nan':decoded[7]=np.nan
    elif kind=='wrong_shape':decoded=decoded.reshape(256,256)
    elif kind=='wrong_dtype':decoded=decoded.astype(object)
    result=checkpoint_error(decoded,expected)
    json.dumps(result,allow_nan=False)
    assert result['passed'] is (kind=='accurate')
    if kind!='accurate':assert result['max_abs_error'] is None
    if kind=='extreme_difference':assert result['shape_and_finite'] and not result['error_arithmetic_finite']

@pytest.mark.parametrize('kind',('extreme_sum','wide_finite','nan','wrong_shape','valid'))
def test_final_probability_diagnostics_survive_overflow_and_invalid_arrays(kind):
    item=definitions()[0];layout=ScoreReductionLayout(item['key_mask'],valid_rows=item['valid_rows'])
    decoded=layout.mean_weight.copy()
    if kind=='extreme_sum':decoded.fill(np.finfo(np.float64).max)
    elif kind=='wide_finite':decoded=np.full(65536,np.finfo(np.longdouble).max,dtype=np.longdouble)
    elif kind=='nan':decoded[7]=np.nan
    elif kind=='wrong_shape':decoded=decoded[:-1]
    result=diagnostics(decoded,item,layout.input_mask)
    json.dumps(result,allow_nan=False)
    if kind=='valid':assert result['maximum_active_mass_defect']==0 and result['reduction_arithmetic_finite']
    else:assert result['maximum_active_mass_defect'] is None and not result['reduction_arithmetic_finite']
    if kind=='extreme_sum':assert result['shape_and_finite']


def test_round_public_actual_profile_and_checkpoint_metadata():
    r=public_contract.preflight(actual_security=False)
    assert (r['degree'],r['depth'],r['scale_bits'],r['dnum'],len(r['q_towers']),len(r['p_towers']))==(131072,49,60,8,100,14)
    assert r['input_level']==25 and r['expected_checkpoint_count']==54 and r['extra_diagnostic_ciphertext_products']==2
    assert r['production_ciphertext_products']==46
    for case in r['fixtures']:
        plan=r['plans'][case['name']];states=r['checkpoint_metadata'][case['name']]
        assert len(states)==2*case['updates']+4
        assert states[f"e{case['updates']:02}"]['diagnostic_only'] is True
        assert states[f"e{case['updates']:02}"]['level']==plan['levels']['inverse']
        assert states['probabilities']['level']==25-case['updates']-5

@pytest.mark.parametrize('corruption',('none','nan','finite_overflow','wrong_shape','wide_finite'))
def test_all_derived_round_gates_remain_finite_json_on_failure(corruption):
    item=definitions()[0];raw=(Path(__file__).parent/'candidate_manifest.json').read_bytes()
    contract=NormalizationRoundContract(raw,item['key_count']);refs,_=client_oracles(make_probabilities(item),item,contract)
    decoded={n:refs[n].copy() for n in checkpoint_names(contract.updates)}
    if corruption=='nan':decoded['y13'][0]=np.nan
    elif corruption=='finite_overflow':decoded['y13'].fill(np.finfo(np.float64).max);decoded['denominator'].fill(np.finfo(np.float64).max)
    elif corruption=='wrong_shape':decoded['y13']=decoded['y13'][:-1]
    elif corruption=='wide_finite':decoded['y13']=np.full(65536,np.finfo(np.longdouble).max,dtype=np.longdouble)
    result=derived_checks(decoded,refs,contract.updates)
    json.dumps(result,allow_nan=False)
    assert len(result)==2*contract.updates+3
    assert all(x['passed'] for x in result.values()) is (corruption=='none')
