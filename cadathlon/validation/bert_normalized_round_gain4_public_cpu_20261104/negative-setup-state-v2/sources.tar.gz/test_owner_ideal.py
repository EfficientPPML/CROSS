"""Independent full-slot plaintext/level model, not an encrypted numerical proof."""
from pathlib import Path
from types import SimpleNamespace
import sys,copy,json,math,hashlib
import numpy as np
import pytest
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE/'checkout/cadathlon/common')]
import encrypted_bert_normalization_round as round_module
import tracked_reciprocal as tracked
from encrypted_score_reduction import ScoreReductionLayout,ScoreReduction,SLOTS

PROFILE=next(x for x in json.loads((HERE/'actual_profile_audit.json').read_text())['profiles'] if x['name']=='depth49_p60_d8')
Q=tuple(PROFILE['q']);DELTA=PROFILE['canonical_scale']
MANIFEST=(HERE/'candidate_manifest.json').read_bytes()

class Value:
    batch=1;degree=2*SLOTS;num_elements=2
    def __init__(self,data,level=38,scale=DELTA):
        self.data=np.array(data,dtype=np.float64,copy=True);self.polynomial=self.data
        self.level=level;self._ckks_scale=scale;self._ckks_nsd=1
        self.moduli=Q[:2*(level+1)];self.ntt_ctx=None;self._public_row_l2_bound='stale'

class Arithmetic:
    scale=DELTA;refresher=None
    def __init__(self):
        self.ctx=SimpleNamespace(degree=2*SLOTS,num_slots=SLOTS,composite_degree=2,secret_key=None,parameters={},
            _param_cache=SimpleNamespace(secret_key=None,batch=1,q_towers=list(Q),p_towers=list(PROFILE['p']),q_moduli_at_level=lambda L:Q[:2*(L+1)]))
        self.calls=[]
    def _level(self,value):
        if type(value._ckks_nsd)is not int or value._ckks_nsd!=1:raise ValueError('invalid NSD')
        return value.level
    def rotate(self,value,shift):self.calls.append('rotate');return Value(np.roll(value.data,-shift),value.level,value._ckks_scale)
    def add(self,left,right):self.calls.append('add');return Value(left.data+right.data,min(left.level,right.level),left._ckks_scale)
    def weighted_sum(self,values,weights,*,bias=0.):
        self.calls.append('weighted_sum');level=min(v.level for v in values)
        divisor=Q[2*level]*Q[2*level+1]
        # Independent literal transcription of PTCT + HEAdd(first) + rescale.
        before=self.scale*divisor
        term_scales=[float(v._ckks_scale)*float(before/v._ckks_scale) for v in values]
        return Value(sum(v.data*w for v,w in zip(values,weights))+bias,level-1,term_scales[0]/divisor)
    def multiply(self,left,right):
        self.calls.append('multiply');L=min(left.level,right.level)
        return Value(left.data*right.data,L-1,left._ckks_scale*right._ckks_scale/(Q[2*L]*Q[2*L+1]))

@pytest.fixture(autouse=True)
def ideal_primitives(monkeypatch):
    monkeypatch.setitem(sys.modules,'encrypted_packed_qwen',SimpleNamespace(CompiledArithmetic=Arithmetic))
    monkeypatch.setitem(sys.modules,'jaxite_word',SimpleNamespace(Polynomial=Value))
    monkeypatch.setitem(sys.modules,'support',SimpleNamespace(require_secure_execution=lambda *a:None))
    def affine(arithmetic,value,weight,bias,*,output_scale):
        arithmetic.calls.append('initial_affine');L=value.level;divisor=Q[2*L]*Q[2*L+1]
        encoded=output_scale*divisor/value._ckks_scale
        return Value(value.data*weight+bias,L-1,value._ckks_scale*encoded/divisor)
    def integer(arithmetic,value,multiplier,*,bias=0.):
        arithmetic.calls.append('integer_affine');return Value(value.data*multiplier+bias,value.level,value._ckks_scale)
    monkeypatch.setattr(tracked,'affine_at_scale',affine);monkeypatch.setattr(tracked,'integer_affine',integer)
    monkeypatch.setattr(tracked,'_require_unbounded_keyless_owner',lambda owner:owner.ctx)



def independent(values,layout,contract):
    masked=values*layout.input_mask;square=masked*masked;den=np.ones(SLOTS)
    for row in range(layout.valid_rows):
        keys=np.flatnonzero(layout.key_mask[row])
        for head in range(12):
            index=row*4096+keys*16+head;broadcast=row*4096+np.arange(128)*16+head
            d=np.dot(masked[index],masked[index]);assert contract.domain[0]<=d<=contract.domain[1]
            den[broadcast]=d
    y=den*contract.first_weight+contract.first_bias
    ys=[y.copy()]
    for _ in range(1,contract.updates):y=y*(2-den*y);ys.append(y.copy())
    return dict(masked_input=masked,squared_numerator=square,denominator=den,inverse=y,probabilities=square*y),ys


def values_for(layout,keys):
    values=np.random.default_rng(2026110300+keys+layout.valid_rows).uniform(-16,16,SLOTS)
    for row in range(layout.valid_rows):
        selected=np.flatnonzero(layout.key_mask[row])
        for head in range(12):
            index=row*4096+selected*16+head
            raw=1.2+.19*np.sin(selected*.37+head*.23+row*.41)
            values[index]=raw/raw.sum()
    return values

@pytest.mark.parametrize('keys',range(1,129))
@pytest.mark.parametrize('valid_rows',(1,7,16))
def test_all_public_K_partial_rows_and_hostile_padding(keys,valid_rows):
    positions=np.arange(128);mask=np.array([((positions+7*row)%128)<keys for row in range(16)])
    layout=ScoreReductionLayout(mask,valid_rows=valid_rows);contract=round_module.NormalizationRoundContract(MANIFEST,keys)
    ops=Arithmetic();graph=round_module.BertNormalizationRound(ops,layout,contract)
    values=values_for(layout,keys);source=Value(values,25);before=copy.deepcopy(vars(source))
    output,stages,steps=graph.evaluate_tile(source,capture_checkpoints=True)
    expected,original_ys=independent(values,layout,contract)
    for name,oracle in expected.items():np.testing.assert_allclose(stages[name].data,oracle,rtol=3e-13,atol=2e-12)
    assert len(steps)==contract.updates and steps[-1][2] is None
    d=expected['denominator'];e1=1-d*original_ys[0]
    for i,y,e in steps:
        np.testing.assert_allclose(y.data,original_ys[i-1],rtol=3e-13,atol=2e-12)
        if e is not None:
            np.testing.assert_allclose(e.data,e1**(2**(i-1)),rtol=1e-11,atol=3e-15)
            np.testing.assert_allclose(e.data,1-d*y.data,rtol=1e-10,atol=3e-13)
    assert output.level==25-contract.updates-5 and output._ckks_scale==graph.last_plan['scales']['probabilities']
    assert abs(output._ckks_scale/DELTA-1)<1e-12 and np.all(output.data[layout.input_mask==0]==0)
    assert ops.calls.count('multiply')==2*contract.updates and ops.calls.count('rotate')==14
    assert ops.calls.count('weighted_sum')==2 and ops.calls.count('initial_affine')==1
    assert not graph.last_plan['final_mask_or_scale_assignment']
    for value in stages.values():assert not any(k.startswith('_public_') for k in vars(value))
    np.testing.assert_array_equal(source.data,before['data']);assert source._public_row_l2_bound=='stale'
    assert 'jax' not in sys.modules

@pytest.mark.parametrize('keys',(1,15,128))
@pytest.mark.parametrize('fraction',(0.,.5,1.))
def test_declared_denominator_endpoints_and_interior(keys,fraction):
    layout=ScoreReductionLayout(np.arange(128)<keys,valid_rows=1);contract=round_module.NormalizationRoundContract(MANIFEST,keys)
    # Keep a small directed numerical gap at the endpoints for this float64
    # ideal test; the declared interval itself is unchanged.
    lo,hi=contract.domain;den=lo+(hi-lo)*fraction
    if fraction==0:den=np.nextafter(den,np.inf)
    if fraction==1:den=np.nextafter(den,0.)
    values=np.zeros(SLOTS)
    for head in range(12):values[np.arange(keys)*16+head]=math.sqrt(den/keys)
    graph=round_module.BertNormalizationRound(Arithmetic(),layout,contract)
    expected,_=independent(values,layout,contract)
    out=graph.evaluate_tile(Value(values,25))
    np.testing.assert_allclose(out.data,expected['probabilities'],rtol=2e-12,atol=2e-12)

@pytest.mark.parametrize('bad',(True,1.0))
@pytest.mark.parametrize('target',('input','output'))
def test_callback_typed_metadata_cannot_continue(bad,target):
    ops=Arithmetic();ops._level=lambda value:value.level;source=Value(np.ones(SLOTS),25)
    def progress(label,value,counts):(setattr(source if target=='input' else value,'_ckks_nsd',bad))
    graph=round_module.BertNormalizationRound(ops,ScoreReductionLayout(np.ones(128,bool)),
        round_module.NormalizationRoundContract(MANIFEST,128),progress=progress)
    with pytest.raises(ValueError):graph.evaluate_tile(source)
    assert ops.calls==['weighted_sum']


def test_contract_layout_capacity_and_refresh_rejections_before_primitives():
    for K in (True,0,129,1.0):
        with pytest.raises(ValueError):round_module.NormalizationRoundContract(MANIFEST,K)
    with pytest.raises(ValueError):round_module.NormalizationRoundContract(MANIFEST+b' ',128)
    ops=Arithmetic();layout=ScoreReductionLayout(np.ones(128,bool));contract=round_module.NormalizationRoundContract(MANIFEST,128)
    with pytest.raises(ValueError):round_module.BertNormalizationRound(ops,layout,round_module.NormalizationRoundContract(MANIFEST,1))
    graph=round_module.BertNormalizationRound(ops,layout,contract)
    with pytest.raises(ValueError):graph.evaluate_tile(Value(np.zeros(SLOTS),19))
    ops.refresher=object()
    with pytest.raises(ValueError):graph.evaluate_tile(Value(np.zeros(SLOTS),25))
    assert ops.calls==[]

@pytest.mark.parametrize('mutation',('payload','nsd_bool','scale'))
def test_retained_numerator_cannot_be_changed_by_a_later_callback(mutation):
    ops=Arithmetic();ops._level=lambda value:value.level;saved={};after=[]
    def progress(label,value,counts):
        if label=='normalization round squared_numerator':saved['value']=value
        if label=='normalization denominator anchors':
            target=saved['value']
            if mutation=='payload':target.polynomial=target.polynomial.copy()
            elif mutation=='nsd_bool':target._ckks_nsd=True
            else:target._ckks_scale*=2
            after.append(len(ops.calls))
    graph=round_module.BertNormalizationRound(ops,ScoreReductionLayout(np.ones(128,bool)),
        round_module.NormalizationRoundContract(MANIFEST,128),progress=progress)
    with pytest.raises(ValueError):graph.evaluate_tile(Value(np.full(SLOTS,1/128),25))
    assert len(after)==1 and after[0]==len(ops.calls)

@pytest.mark.parametrize('phase',('before','first','final'))
@pytest.mark.parametrize('replacement',('arithmetic','layout','contract','reduction'))
def test_constructor_bound_owners_cannot_be_substituted(phase,replacement):
    ops=Arithmetic();other_ops=Arithmetic();layout=ScoreReductionLayout(np.ones(128,bool))
    contract=round_module.NormalizationRoundContract(MANIFEST,128);observed=[]
    def substitute():
        choices=dict(arithmetic=other_ops,layout=ScoreReductionLayout(np.ones(128,bool)),
            contract=round_module.NormalizationRoundContract(MANIFEST,128),
            reduction=ScoreReduction(ops,layout))
        setattr(graph,replacement,choices[replacement]);observed.append(len(ops.calls))
    callbacks=[]
    def progress(label,value,counts):
        callbacks.append(label)
        if phase=='first' and len(callbacks)==1 or phase=='final' and label=='normalization round probabilities':substitute()
    graph=round_module.BertNormalizationRound(ops,layout,contract,progress=progress)
    if phase=='before':substitute()
    with pytest.raises(ValueError):graph.evaluate_tile(Value(np.full(SLOTS,1/128),25))
    assert len(observed)==1 and len(ops.calls)==observed[0] and not other_ops.calls
    if phase=='before':assert not ops.calls
    if phase=='first':assert ops.calls==['weighted_sum']
    assert graph.last_plan is None

@pytest.mark.parametrize('phase',('before','first','final'))
@pytest.mark.parametrize('field,replacement',[
    ('key_count',True),('key_count',1.0),('updates',True),('updates',6.0),
    ('seed',True),('first_weight',True),('first_weight',-.5),('first_bias',True),
    ('domain',[.5,2.]),('domain',(.5,True)),('manifest_bytes',b'invalid'),
])
def test_frozen_rule_dict_mutations_fail_before_next_primitive(phase,field,replacement):
    ops=Arithmetic();layout=ScoreReductionLayout(np.arange(128)==127);contract=round_module.NormalizationRoundContract(MANIFEST,1)
    changed=[];callbacks=[]
    def mutate():contract.__dict__[field]=replacement;changed.append(len(ops.calls))
    def progress(label,value,counts):
        callbacks.append(label)
        if phase=='first' and len(callbacks)==1 or phase=='final' and label=='normalization round probabilities':mutate()
    graph=round_module.BertNormalizationRound(ops,layout,contract,progress=progress)
    if phase=='before':mutate()
    with pytest.raises(ValueError):graph.evaluate_tile(Value(np.ones(SLOTS),25))
    assert len(changed)==1 and len(ops.calls)==changed[0] and graph.last_plan is None
    if phase=='before':assert not ops.calls
    if phase=='first':assert ops.calls==['weighted_sum']


def test_public_plan_and_constructor_reconstruct_the_exact_rule():
    for field,bad in [('updates',7),('first_weight',-.2),('domain',(.1,2.)),('key_count',True)]:
        rule=round_module.NormalizationRoundContract(MANIFEST,1);object.__setattr__(rule,field,bad)
        with pytest.raises(ValueError):round_module.normalization_round_plan(Q[:52],input_level=25,canonical_scale=DELTA,contract=rule)
        ops=Arithmetic()
        with pytest.raises(ValueError):round_module.BertNormalizationRound(ops,ScoreReductionLayout(np.arange(128)==127),rule)
        assert not ops.calls

@pytest.mark.parametrize('scale',(np.nextafter(DELTA,0.),np.nextafter(DELTA,np.inf),DELTA*(1+2e-13)))
@pytest.mark.parametrize('K',(1,15,128))
def test_actual_original_input_scale_drives_round_metadata(scale,K):
    layout=ScoreReductionLayout(np.arange(128)<K,valid_rows=7);ops=Arithmetic()
    contract=round_module.NormalizationRoundContract(MANIFEST,K)
    owner=round_module.BertNormalizationRound(ops,layout,contract)
    source=Value(values_for(layout,K),25,float(scale))
    output,stages,_=owner.evaluate_tile(source,capture_checkpoints=True)
    expected,_=independent(source.data,layout,contract)
    np.testing.assert_allclose(output.data,expected['probabilities'],rtol=3e-13,atol=2e-12)
    assert owner.last_plan['input_scale']==float(scale)
    for name,value in stages.items():assert value._ckks_scale==owner.last_plan['scales'][name]
