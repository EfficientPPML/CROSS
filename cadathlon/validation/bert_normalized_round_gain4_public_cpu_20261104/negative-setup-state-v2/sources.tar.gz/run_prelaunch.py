"""Source-bound normalized-round test/public preflight wrapper; no HE launch."""
from pathlib import Path
import io,json,subprocess,sys,tarfile,time
import collect
P=Path(__file__).resolve().parent

def main():
    out=P/'prelaunch-v1';out.mkdir(exist_ok=False);start=time.monotonic()
    raw=collect.sources();before={n:collect.sha(b) for n,b in raw.items()};report=dict(passed=False,source_hashes_before=before,scope=__doc__)
    with tarfile.open(out/'sources.tar.gz','w:gz') as t:
        for n,b in raw.items():m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
    try:
        for name,args in [('tests',['-m','pytest','-q','test_owner_ideal.py','test_collector.py','test_component_phase.py','test_round_fixture.py']),
                          ('actual_preflight',['collect.py','--preflight','--output',str(out/'actual-ring-preflight')])]:
            with (out/(name+'.log')).open('w') as log:r=subprocess.run([sys.executable,*args],cwd=P,stdout=log,stderr=subprocess.STDOUT)
            report[name+'_exit_code']=r.returncode
            if r.returncode:raise ValueError(name+' failed')
        proof=json.loads((out/'actual-ring-preflight/report.json').read_text())
        if not proof['passed'] or not proof['preflight_only'] or proof['key_generation_started'] or proof['encryption_started']:raise ValueError('not a successful non-encrypting preflight')
        if proof['source_hashes_before']!=before or proof['source_hashes_after']!=before:raise ValueError('nested preflight closure differs')
        report['passed']=True
    finally:
        after={n:collect.sha(b) for n,b in collect.sources().items()};verified=collect.verify_archive(out/'sources.tar.gz',before)
        report.update(source_hashes_after=after,source_files_unchanged=before==after,source_archive_verified=verified,
            source_archive_sha256=collect.sha((out/'sources.tar.gz').read_bytes()),elapsed_s=time.monotonic()-start)
        report['passed']=bool(report['passed'] and before==after and verified)
        collect.write(out/'report.json',report)
    return 0 if report['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
