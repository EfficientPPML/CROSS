"""Independent public fixture/oracle checks; no backend or encrypted execution."""
from pathlib import Path
from fractions import Fraction
import json,sys,types
import numpy as np
import pytest
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE/'checkout/cadathlon/common')]
import fixtures as f
from encrypted_bert_normalization_round import NormalizationRoundContract
REDUCTION_ROUNDING_ALLOWANCE=128*np.finfo(np.float64).eps
RAW=(HERE/'candidate_manifest.json').read_bytes()
ITEMS=f.definitions()

def oracle(item):
    value=f.make_probabilities(item);contract=NormalizationRoundContract(RAW,item['key_count'])
    refs,details=f.client_oracles(value,item,contract)
    return value,contract,refs,details


def independent_layout(item,values):
    blocks=values.reshape(16,4096)
    cells=blocks[:,:2048].reshape(16,128,16)
    active=np.zeros((16,128,16),bool);active[:,:,:12]=item['key_mask'][:,:,None]
    guarded=np.where(active,cells,0.)
    denominator=np.ones((16,4096))
    sums=np.sum(guarded*guarded,axis=1)
    denominator[:,:2048].reshape(16,128,16)[:item['valid_rows'],:,:12]=sums[:item['valid_rows'],None,:12]
    masked=np.zeros_like(blocks);masked[:,:2048]=guarded.reshape(16,2048)
    active_slots=np.zeros_like(blocks,dtype=bool);active_slots[:,:2048]=active.reshape(16,2048)
    return masked.ravel(),denominator.ravel(),active_slots.ravel()


@pytest.mark.parametrize('item',ITEMS,ids=lambda x:x['name'])
def test_distinct_rows_heads_masks_padding_and_probability_regimes(item):
    values,contract,refs,details=oracle(item)
    assert values.shape==(65536,) and values.dtype==np.float64
    assert item['key_mask'].dtype==bool and item['key_mask'].shape==(16,128)
    assert np.all(item['key_mask'][:item['valid_rows']].sum(axis=1)==item['key_count'])
    assert not item['key_mask'][item['valid_rows']:].any()
    np.testing.assert_array_equal(values,f.make_probabilities(item))
    assert not np.array_equal(values[:32768],values[32768:])
    masked,denominator,active=independent_layout(item,values)
    assert np.max(np.abs(values[~active]))>10 and np.count_nonzero(values[~active])==np.count_nonzero(~active)
    cells=masked.reshape(16,4096)[:,:2048].reshape(16,128,16)
    np.testing.assert_allclose(cells.sum(axis=1)[:item['valid_rows'],:12],1.,atol=REDUCTION_ROUNDING_ALLOWANCE,rtol=0.)
    assert np.unique(denominator[active]).size>item['valid_rows']
    assert details['nearuniform_vectors']>0 and details['concentrated_vectors']>0
    if item['key_count']==15:
        assert np.unique(item['key_mask'][:item['valid_rows']],axis=0).shape[0]==item['valid_rows']
        assert not np.all(np.diff(np.flatnonzero(item['key_mask'][0]))==1) # wrap-around shifted mask
    np.testing.assert_array_equal(refs['masked_input'],masked)
    np.testing.assert_allclose(refs['denominator'],denominator,rtol=0.,atol=REDUCTION_ROUNDING_ALLOWANCE)
    np.testing.assert_array_equal(refs['squared_numerator'],masked*masked)
    assert np.all((contract.domain[0]<=denominator)&(denominator<=contract.domain[1]))
    assert np.all(denominator.reshape(16,4096)[:,2048:]==1.)
    assert np.all(denominator.reshape(16,4096)[:,:2048].reshape(16,128,16)[:,:,12:]==1.)


@pytest.mark.parametrize('item',ITEMS,ids=lambda x:x['name'])
def test_original_newton_closed_form_residual_and_true_quotient(item):
    values,contract,refs,_=oracle(item)
    masked,denominator,active=independent_layout(item,values)
    # Recompute from the independently assembled denominator, not refs' inverse.
    d=denominator.astype(np.longdouble)
    first=d*np.longdouble(contract.first_weight)+np.longdouble(contract.first_bias)
    e=1-d*first
    for update in range(1,contract.updates+1):
        closed=(1-e)/d
        np.testing.assert_allclose(refs[f'y{update:02}'],np.asarray(closed,float),atol=2e-12,rtol=0.)
        np.testing.assert_allclose(refs[f'e{update:02}'],np.asarray(e,float),atol=2e-15,rtol=2e-12)
        e=e*e
    exact=(masked*masked)/denominator
    np.testing.assert_allclose(refs['true_quotient'],exact,atol=REDUCTION_ROUNDING_ALLOWANCE,rtol=0.)
    np.testing.assert_allclose(refs['probabilities'],exact,atol=1e-10,rtol=0.)
    assert np.max(np.abs(refs[f'y{contract.updates:02}']-1/denominator))<1e-6
    assert not np.any(refs['probabilities'][~active])
    output_cells=exact.reshape(16,4096)[:,:2048].reshape(16,128,16)
    np.testing.assert_allclose(output_cells.sum(axis=1)[:item['valid_rows'],:12],1.,rtol=0.,atol=REDUCTION_ROUNDING_ALLOWANCE)
    names=f.checkpoint_names(contract.updates)
    assert len(set(names))==len(names)==4+2*contract.updates
    assert set(names)==set(refs)-{'true_quotient'} and names[-1]=='probabilities'
    diag=f.diagnostics(refs['probabilities'],item,active)
    assert diag['reduction_arithmetic_finite'] and diag['maximum_active_mass_defect']<1e-10
    assert diag['maximum_padding_magnitude']==0.
    json.dumps(diag,allow_nan=False)


@pytest.mark.parametrize('fault',('negative','nan','mass','wrong_K','domain'))
def test_client_oracle_rejects_broken_fixture_contract(fault):
    item=ITEMS[1];values=f.make_probabilities(item);contract=NormalizationRoundContract(RAW,15)
    idx=int(np.flatnonzero(item['key_mask'][0])[0])*16
    if fault=='negative':values[idx]=-.1
    if fault=='nan':values[idx]=np.nan
    if fault=='mass':values[idx]+=.1
    if fault=='wrong_K':contract=NormalizationRoundContract(RAW,16)
    if fault=='domain':contract=types.SimpleNamespace(key_count=15,domain=(2.,3.))
    with pytest.raises(ValueError):f.client_oracles(values,item,contract)


@pytest.mark.parametrize('fault',('nan','inf','shape','complex','object','huge_finite','overflow_subtract'))
def test_checkpoint_failure_is_finite_json(fault):
    expected=np.zeros(65536);actual=expected.copy()
    if fault=='nan':actual[-1]=np.nan
    if fault=='inf':actual[-1]=np.inf
    if fault=='shape':actual=actual[:-1]
    if fault=='complex':actual=actual.astype(complex)
    if fault=='object':actual=actual.astype(object)
    if fault=='huge_finite':actual[-1]=1e308
    if fault=='overflow_subtract':actual[-1]=1e308;expected[-1]=-1e308
    result=f.checkpoint_error(actual,expected)
    assert result['passed'] is False
    json.dumps(result,allow_nan=False)


def test_checkpoint_gate_covers_every_slot_and_exact_declared_threshold():
    expected=np.zeros(65536);actual=expected.copy();actual[-1]=1e-6
    assert f.checkpoint_error(actual,expected)['passed']
    actual[-1]=np.nextafter(1e-6,np.inf)
    assert not f.checkpoint_error(actual,expected)['passed']


@pytest.mark.parametrize('fault',('nan','inf','shape','complex','overflow_sum'))
def test_diagnostics_fail_closed_on_nonfinite_reduction(fault):
    item=ITEMS[1];values=f.make_probabilities(item);_,_,active=independent_layout(item,values)
    x=np.zeros(65536)
    if fault=='nan':x[0]=np.nan
    if fault=='inf':x[0]=np.inf
    if fault=='shape':x=x[:-1]
    if fault=='complex':x=x.astype(complex)
    if fault=='overflow_sum':x[:]=1e308
    result=f.diagnostics(x,item,active)
    assert not result['reduction_arithmetic_finite']
    json.dumps(result,allow_nan=False)
