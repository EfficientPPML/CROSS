"""Exact worker/supervise AST with synthetic resources, no actual I/O."""
import ast,json,time,os,sys
from pathlib import Path
from contextlib import contextmanager
from types import SimpleNamespace
import pytest
from cleanup_origin import cleanup_origin,protect_body,choose

ROOT=Path(__file__).parent

def extract(path,names,namespace):
    tree=ast.parse(path.read_bytes())
    nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))and n.name in names]
    assert {n.name for n in nodes}==set(names)
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),namespace)

@pytest.mark.parametrize('failure',[ValueError('after read'),KeyboardInterrupt('after read'),SystemExit(2)])
def test_completed_read_stays_reported_when_later_execution_fails(monkeypatch,tmp_path,failure):
    check(monkeypatch,tmp_path,failure,True)

def test_no_read_failure_control(monkeypatch,tmp_path):
    check(monkeypatch,tmp_path,ValueError('before read'),False)

def check(monkeypatch,tmp_path,failure,did_read):
    reports=[];events=[]
    binding=SimpleNamespace(mode='heldout',manifest_sha256='a'*64,frozen=SimpleNamespace(receipt_sha256='b'*64))
    args=SimpleNamespace(output=str(tmp_path/'worker'),private_output=str(tmp_path/'private'),manifest_sha256='c'*64,grant_sha256='d'*64)
    class Output:
        def __init__(self,path):self.path=path;self.owner=(1,2)
        @classmethod
        def reopen(cls,path,owner):return cls(path)
        def close(self):events.append('private_close'if self.path==args.private_output else'public_close')
        def json(self,name,row):reports.append(dict(row))
    class Reader:
        def __init__(self,*args):self.loaded=False
        def recheck(self):events.append('input_recheck')
    @contextmanager
    def signals(state=None,shield=False):
        if state is not None:state['restored']=False
        try:yield
        finally:
            if state is not None:state['restored']=True
    namespace=dict(os=os,json=json,time=time,Output=Output,cleanup_origin=cleanup_origin,protect_body=protect_body,choose=choose,
        signals=signals,source_end=lambda *a:{},admit=lambda *a:(binding,lambda:events.append('proof_recheck')),
        install_audit=lambda *a,**k:[],dependencies=lambda *a:{},enable_model_imports=lambda:None,reject_denials=lambda x:None)
    extract(ROOT/'checker_process.py',('accumulate','supervise'),namespace)
    extract(ROOT/'heldout_process.py',('worker',),namespace)
    def execute(blobs,authorization,reader,private,progress):
        reader.loaded=did_read
        raise failure
    monkeypatch.setitem(sys.modules,'heldout_input_gate',SimpleNamespace(ValidationReader=Reader))
    monkeypatch.setitem(sys.modules,'heldout_runtime',SimpleNamespace(execute_heldout=execute))
    with pytest.raises(type(failure))as caught:namespace['worker'](args,{}, {},{},tmp_path/'source')
    assert caught.value is failure
    assert all(n in events for n in ('input_recheck','proof_recheck','private_close','public_close'))
    assert reports[-1]['passed'] is False
    assert reports[-1]['validation_reauthenticated'] is did_read
    assert reports[-1]['validation_inputs_read'] is did_read
