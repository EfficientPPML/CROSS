"""Synthetic public receipts only; never open retained inputs or model bodies."""
from dataclasses import replace
from pathlib import Path
import copy
import json
import pytest
import heldout_authorization as gate
import freeze_admission as f
from test_input_gate import blobs as input_blobs
from test_freeze_admission import receipt


def encoded(value): return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False)+'\n').encode()


def fixture(mode='heldout', passed=True):
    data=input_blobs(); root=Path(__file__).parent
    for name in ('execution_authorization.json','heldout_runtime_policy.json','checker_protected_paths.json','heldout_protected_paths.json',
                 'candidate_proof/candidate-manifest.json'):
        data[name]=(root/name).read_bytes()
    external=json.loads(data['external_inputs.json']);producer=external['producer']
    validation=json.loads(data['public/tokenizer_worker_report.json'])['private_outputs']['validation']
    row=receipt(validation_sha=validation['sha256']);a=row['attempts'][0]
    row.update(manifest_sha256=gate.CANDIDATE,model_pins_sha256=f.sha(data['public/model_pins.json']),
        tokenizer_report_sha256=producer['tokenizer_report_sha256'],tokenizer_review_sha256=producer['tokenizer_root_review_sha256'])
    a.update(manifest_sha256=gate.CANDIDATE,source_manifest_sha256=gate.CALIBRATION_SOURCE,grant_sha256=gate.CALIBRATION_GRANT)
    outer=dict(schema='qwen-candidate3200-producer-terminal-v1',report_sha256=a['parent_report_sha256'],
        worker_report_sha256=a['worker_report_sha256'],source_manifest_sha256=a['source_manifest_sha256'],
        source_archive_sha256=a['source_archive_sha256'],candidate_manifest_sha256=a['manifest_sha256'],
        grant_sha256=a['grant_sha256'],exit_code=0,reaped=True,process_group_absent=True,
        worker_exit_code=0,worker_reaped=True,worker_group_absent=True)
    producer_raw=encoded(outer);a['producer_outer_receipt_sha256']=f.sha(producer_raw)
    reconstruction=dict(schema='qwen-candidate-reconstruction-outer-v2',review_sha256=a['independent_review_sha256'],
        script_sha256=a['reconstruction_script_sha256'],producer_source_manifest_sha256=a['source_manifest_sha256'],
        **{k:a[k]for k in gate.CLOSURE},candidate_manifest_sha256=gate.CANDIDATE,
        producer_outer_receipt_sha256=a['producer_outer_receipt_sha256'],returncode=0,
        direct_child_reaped=True,owned_group_absent=True,publication_completed=True)
    root_raw=encoded(reconstruction);a['reconstruction_outer_receipt_sha256']=f.sha(root_raw)
    evidence=dict(freeze=encoded(row),producer_outer_1=producer_raw,reconstruction_outer_1=root_raw)
    source=f.sha(b'synthetic complete heldout source map')
    grant=dict(schema=gate.SCHEMA,execute=True,mode=mode,
        scope='first-frozen-candidate-heldout1088'if mode=='heldout'else'first-frozen-candidate-row0',
        candidate_ordinal=1,candidate_manifest_sha256=gate.CANDIDATE,freeze_receipt_sha256=f.sha(evidence['freeze']),
        model_pins_sha256=row['model_pins_sha256'],protocol_sha256=f.PROTOCOL,
        tokenizer_report_sha256=row['tokenizer_report_sha256'],tokenizer_review_sha256=row['tokenizer_review_sha256'],
        source_manifest_sha256=source,runtime_policy=json.loads(data['heldout_runtime_policy.json']),
        evidence_output='/tmp/synthetic-heldout-gate-public-'+mode,private_output='/tmp/synthetic-heldout-gate-private-'+mode,
        model_forward=True,coefficient_selection=False,encrypted_execution=False,selection_permanently_closed=True,
        validation_read=mode=='heldout',public_evidence={},reviewed_script_sha256=[a['reconstruction_script_sha256']],
        reviewed_reconstruction_pins=[{k:a[k]for k in gate.CLOSURE}],
        preflight_report_sha256=f.sha(b'synthetic preflight'),independent_review_sha256=f.sha(b'synthetic reviewed grant'))
    if mode=='row0':
        frozen=f.authenticate(evidence['freeze'],f.sha(evidence['freeze']))
        parent=prior(frozen,source,passed)
        evidence['heldout_report']=encoded(parent);evidence['heldout_outer']=encoded(prior_outer(parent,evidence['heldout_report']))
    for name,raw in evidence.items():grant['public_evidence'][name]=dict(path='/tmp/synthetic-public-evidence/'+name+'.json',sha256=f.sha(raw),bytes=len(raw))
    return data,grant,evidence


def prior(frozen,source,passed):
    flags=dict.fromkeys((*gate.TERMINAL_FLAGS,*gate.WORKER_FLAGS),True)
    hashes={'synthetic.py':f.sha(b'synthetic source')}
    worker=dict(flags,schema='qwen-heldout-workflow-worker-v1',workload_mode='heldout',passed=passed,
        source_manifest_sha256=source,source_hashes_start=hashes,source_hashes_end=hashes,
        manifest_sha256=gate.CANDIDATE,freeze_receipt_sha256=frozen.receipt_sha256,grant_sha256=f.sha(b'prior heldout grant'),
        audit_denials=[],selection_permanently_closed=True,revision_eligible_ledger=False,candidate_ordinal=1,
        retained_entries=1088,expected_entries=1088,coefficient_selection_performed=False,encrypted_execution=False,
        tokenizer_execution=False,validation_inputs_read=True,validation_read_status='confirmed',contains_tokens_logits_or_failure_text=False,
        native_forward_accounting=dict(expected=1120,started=1120,completed=1120,passed=True),
        native_forward_started=1120,native_forward_completed=1120,trajectories_complete=True,
        all_length_invariance=True,complete_measured_context_coverage=True,phase_counts=dict(native=1088,exact=1088,candidate=1088))
    parent=dict.fromkeys(gate.TERMINAL_FLAGS,True)
    parent.update(schema='qwen-heldout-workflow-parent-v1',workload_mode='heldout',passed=passed,
        source_manifest_sha256=source,source_hashes_start=hashes,source_hashes_end=hashes,
        manifest_sha256=gate.CANDIDATE,freeze_receipt_sha256=frozen.receipt_sha256,grant_sha256=worker['grant_sha256'],
        selection_permanently_closed=True,revision_eligible_ledger=False,audit_denials=[],
        worker=worker,worker_report_sha256=f.sha(encoded(worker)),source_archive=dict(sha256=f.sha(b'synthetic source archive')),
        child_returncode=0 if passed else 1,child_reaped=True,child_group_absent=True)
    return parent


def prior_outer(parent,raw):
    code=0 if parent['passed']else 1
    return dict(schema='qwen-heldout-workflow-outer-v1',mode='heldout',report_sha256=f.sha(raw),
        worker_report_sha256=parent['worker_report_sha256'],source_manifest_sha256=parent['source_manifest_sha256'],
        source_archive_sha256=parent['source_archive']['sha256'],candidate_manifest_sha256=parent['manifest_sha256'],
        freeze_receipt_sha256=parent['freeze_receipt_sha256'],grant_sha256=parent['grant_sha256'],
        exit_code=code,worker_exit_code=code,reaped=True,process_group_absent=True,worker_reaped=True,
        worker_group_absent=True,publication_completed=True)


def admit(data,grant,evidence,**changes):
    raw=encoded(grant)
    args=dict(mode=grant['mode'],source_manifest_sha256=grant['source_manifest_sha256'],
        evidence_output=grant['evidence_output'],private_output=grant['private_output'],blobs=data)
    args.update(changes)
    return gate.authenticate(raw,f.sha(raw),evidence,**args)


def rebind(grant,evidence,name,raw):
    evidence[name]=raw;grant['public_evidence'][name].update(sha256=f.sha(raw),bytes=len(raw))
    if name=='freeze':grant['freeze_receipt_sha256']=f.sha(raw)


@pytest.mark.parametrize('mode,passed',[('heldout',True),('row0',True),('row0',False)])
def test_complete_public_chain_and_distinct_grant_admit_without_io(mode,passed,monkeypatch):
    data,grant,evidence=fixture(mode,passed)
    with monkeypatch.context() as isolated:
        isolated.setattr(gate.input_gate,'read',lambda *a,**k:pytest.fail('external read'))
        isolated.setattr(gate.input_gate.os,'stat',lambda *a,**k:pytest.fail('external stat'))
        isolated.setattr(gate.input_gate.os,'open',lambda *a,**k:pytest.fail('external open'))
        value=admit(data,grant,evidence)
        assert value.mode==mode and value.frozen.ordinal==1 and value.frozen.execution_authorized is False
        assert gate.require_authorized(value,data)==value
        assert value.manifest_sha256==gate.CANDIDATE and f.sha(value.manifest_bytes)==gate.CANDIDATE
        assert value.validation_descriptor['path'].endswith('/validation_inputs.json')


@pytest.mark.parametrize('key,value',[
    ('execute',False),('execute',1),('candidate_ordinal',True),('candidate_ordinal',2),('validation_read',False),
    ('coefficient_selection',True),('encrypted_execution',True),('selection_permanently_closed',False),
    ('model_forward',False),('protocol_sha256','0'*64),('scope','row0'),('candidate_manifest_sha256','0'*64),
    ('model_pins_sha256','0'*64),('tokenizer_report_sha256','0'*64),('tokenizer_review_sha256','0'*64)])
def test_rehashed_grant_cannot_change_fixed_contract(key,value):
    data,g,e=fixture();g[key]=value
    with pytest.raises(ValueError):admit(data,g,e)


@pytest.mark.parametrize('key,value',[('cores',[108,109,110,112]),('torch_threads',True),('heldout_entries',1087),
    ('heldout_native_forwards',1119),('row0_native_forwards',1),('candidate_revision',True)])
def test_resource_and_workload_policy_exact(key,value):
    data,g,e=fixture();g['runtime_policy'][key]=value
    with pytest.raises(ValueError):admit(data,g,e)
    data['heldout_runtime_policy.json']=encoded(g['runtime_policy'])
    with pytest.raises(ValueError):admit(data,g,e)


@pytest.mark.parametrize('kind',['default_ready','source_added','source_changed','source_missing','forged_manifest',
    'forged_policy','forged_validation','forged_mode','forged_frozen','duplicate_evidence','mutable_evidence'])
def test_direct_entry_replays_all_immutable_bindings(kind):
    data,g,e=fixture();value=admit(data,g,e)
    if kind=='default_ready':data['execution_authorization.json']=encoded({'execute':True})
    elif kind=='source_added':data['new.py']=b'not in original source closure'
    elif kind=='source_changed':data['public/model_pins.json']+=b' '
    elif kind=='source_missing':data.pop('checker_protected_paths.json')
    elif kind=='forged_manifest':value=replace(value,manifest_bytes=b'{}')
    elif kind=='forged_policy':value=replace(value,policy_bytes=b'{}')
    elif kind=='forged_validation':value=replace(value,validation_bytes=b'{}')
    elif kind=='forged_mode':value=replace(value,mode='row0')
    elif kind=='forged_frozen':value=replace(value,frozen=replace(value.frozen,ordinal=True))
    elif kind=='duplicate_evidence':value=replace(value,evidence_bytes=value.evidence_bytes+(value.evidence_bytes[0],))
    else:value=replace(value,evidence_bytes=list(value.evidence_bytes))
    with pytest.raises((ValueError,KeyError)):gate.require_authorized(value,data)


def test_returned_dict_views_and_input_dict_mutation_cannot_mutate_binding():
    data,g,e=fixture();value=admit(data,g,e)
    value.runtime_policy['cores'].clear();value.validation_descriptor['identity'].clear();value.public_evidence.clear()
    g.clear();e.clear()
    assert gate.require_authorized(value,data)==value


@pytest.mark.parametrize('name',['freeze','producer_outer_1','reconstruction_outer_1'])
def test_missing_extra_mutable_wrong_size_or_digest_role_rejected(name):
    data,g,e=fixture();original=e[name]
    for bad in (None,bytearray(original),original+b' '):
        e[name]=bad
        with pytest.raises(ValueError):admit(data,g,e)
    e[name]=original;del e[name]
    with pytest.raises(ValueError):admit(data,g,e)
    e[name]=original;e['unexpected']=b'{}'
    with pytest.raises(ValueError):admit(data,g,e)


@pytest.mark.parametrize('field',['reconstruction_source_manifest_sha256','reconstruction_source_archive_sha256',
    'reconstruction_grant_sha256'])
def test_closure_pins_are_external_to_self_consistent_root_receipt(field):
    data,g,e=fixture();g['reviewed_reconstruction_pins'][0][field]='0'*64
    with pytest.raises(ValueError,match='Independently reviewed'):admit(data,g,e)


@pytest.mark.parametrize('name,field,value',[('freeze','first_complete_calibration_pass',False),
    ('freeze','validation_previously_read',True),('producer_outer_1','reaped',False),
    ('producer_outer_1','exit_code',True),('reconstruction_outer_1','publication_completed',False),
    ('reconstruction_outer_1','producer_source_manifest_sha256','0'*64)])
def test_rehashed_public_proofs_do_not_bypass_semantics(name,field,value):
    data,g,e=fixture();row=json.loads(e[name]);row[field]=value;rebind(g,e,name,encoded(row))
    with pytest.raises(ValueError):admit(data,g,e)


@pytest.mark.parametrize('path',['relative.json','/tmp/a/../b','/tmp//b','/tmp/./b','//tmp/b','/tmp/b/',
    '/', '/tmp/\x00bad', '/tmp/\\bad'])
def test_noncanonical_paths_reject_before_role_reads(path):
    _,g,_=fixture();g['public_evidence']['freeze']['path']=path
    with pytest.raises(ValueError):gate.public_requests(encoded(g))


@pytest.mark.parametrize('which',['same_roles','nested_roles','public_private','proof_in_output','proof_ancestor_output',
    'validation','model','prior_private','candidate_private','candidate_public','source'])
def test_protected_paths_and_output_overlap_reject(which):
    data,g,e=fixture();roles=g['public_evidence']
    if which=='same_roles':roles['freeze']['path']=roles['producer_outer_1']['path']
    elif which=='nested_roles':roles['freeze']['path']=roles['producer_outer_1']['path']+'/child'
    elif which=='public_private':g['private_output']=g['evidence_output']+'/child'
    elif which=='proof_in_output':roles['freeze']['path']=g['evidence_output']+'/freeze.json'
    elif which=='proof_ancestor_output':roles['freeze']['path']='/tmp'
    elif which=='validation':roles['freeze']['path']=json.loads(data['external_inputs.json'])['calibration']['path'].replace('calibration','validation')
    elif which=='model':roles['freeze']['path']=json.loads(data['external_inputs.json'])['model_root']+'/config.json'
    elif which=='prior_private':roles['freeze']['path']=json.loads(data['checker_protected_paths.json'])['paths'][0]+'/ledger.json'
    elif which in ('candidate_private','candidate_public'):
        roles['freeze']['path']=json.loads(data['heldout_protected_paths.json'])['paths'][which=='candidate_public']+'/ledger.json'
    else:roles['freeze']['path']=str(Path(__file__).parent/'synthetic.json')
    with pytest.raises(ValueError):admit(data,g,e)


def test_role_bounds_exact_no_large_allocations():
    _,g,_=fixture('row0')
    for name in g['public_evidence']:
        maximum=(16 if name=='heldout_report'else 1)<<20
        old=g['public_evidence'][name]['bytes'];g['public_evidence'][name]['bytes']=maximum
        assert gate.public_requests(encoded(g))[name]['bytes']==maximum
        for invalid in (maximum+1,0,True,1.0):
            g['public_evidence'][name]['bytes']=invalid
            with pytest.raises(ValueError):gate.public_requests(encoded(g))
        g['public_evidence'][name]['bytes']=old


@pytest.mark.parametrize('raw',[b'{"schema":1,"schema":2}',b'{"x":NaN}',b'{"x":1e999}',b'[]'])
def test_duplicate_nonfinite_nondict_grant_denied(raw):
    with pytest.raises(ValueError):gate.public_requests(raw)


@pytest.mark.parametrize('level,key,value',[
    ('parent','child_group_absent',False),('parent','child_reaped',False),('parent','child_returncode',True),
    ('parent','complete',False),('parent','signal_restoration_completed',False),('parent','audit_denials',['network']),
    ('parent','error_type','OSError'),('parent','source_files_unchanged',False),('parent','worker_report_sha256','0'*64),
    ('worker','private_directory_handle_closed',False),('worker','model_asset_postchecks_completed',False),
    ('worker','model_cleanup_completed',False),('worker','native_capture_cleanup_completed',False),
    ('worker','ledger_complete',False),('worker','retained_entries',1087),('worker','expected_entries',True),
    ('worker','selection_permanently_closed',False),('worker','revision_eligible_ledger',True),
    ('worker','validation_reauthenticated',False),('worker','candidate_validation_admissible',True),
    ('worker','validation_read_attempted',False),('worker','validation_input_authenticated',False),
    ('worker','validation_read_status','attempted'),('worker','validation_inputs_read',None),
    ('worker','native_forward_completed',1119),('worker','grant_sha256','0'*64),
    ('worker','workload_mode','row0'),('worker','error_type','KeyboardInterrupt')])
def test_row0_requires_terminal_heldout_even_when_scientifically_failed(level,key,value):
    data,g,e=fixture('row0',False);parent=json.loads(e['heldout_report'])
    target=parent if level=='parent'else parent['worker'];target[key]=value
    if not(level=='parent'and key=='worker_report_sha256'):parent['worker_report_sha256']=f.sha(encoded(parent['worker']))
    raw=encoded(parent);rebind(g,e,'heldout_report',raw)
    rebind(g,e,'heldout_outer',encoded(prior_outer(parent,raw)))
    with pytest.raises(ValueError):admit(data,g,e)


@pytest.mark.parametrize('key,value',[('reaped',False),('worker_reaped',False),('process_group_absent',False),
    ('worker_group_absent',False),('publication_completed',False),('exit_code',1),('worker_exit_code',1),
    ('source_manifest_sha256','0'*64),('source_archive_sha256','0'*64),('freeze_receipt_sha256','0'*64),
    ('grant_sha256','0'*64),('candidate_manifest_sha256','0'*64),('report_sha256','0'*64)])
def test_row0_outer_is_independent_exact_terminal_link(key,value):
    data,g,e=fixture('row0');outer=json.loads(e['heldout_outer']);outer[key]=value
    rebind(g,e,'heldout_outer',encoded(outer))
    with pytest.raises(ValueError):admit(data,g,e)


def test_distinct_mode_and_external_pin_cannot_be_substituted():
    data,g,e=fixture();raw=encoded(g)
    with pytest.raises(ValueError):gate.authenticate(raw,'0'*64,e,mode='heldout',source_manifest_sha256=g['source_manifest_sha256'],evidence_output=g['evidence_output'],private_output=g['private_output'],blobs=data)
    for changes in (dict(mode='row0'),dict(source_manifest_sha256='0'*64),dict(private_output='/tmp/other-private'),dict(evidence_output='/tmp/other-public')):
        with pytest.raises(ValueError):admit(data,g,e,**changes)
