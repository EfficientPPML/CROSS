"""Synthetic public attestations only; never real producer reports or inputs."""
import copy,json
from dataclasses import replace
import pytest
import freeze_admission as f

def attempt(ordinal,passed):
    row=dict(ordinal=ordinal,outcome='complete_pass'if passed else'complete_scientific_failure')
    for i,name in enumerate(('manifest_sha256','parent_report_sha256','worker_report_sha256','source_manifest_sha256',
        'source_archive_sha256','grant_sha256','producer_outer_receipt_sha256',
        'reconstruction_outer_receipt_sha256','reconstruction_script_sha256','independent_review_sha256')):
        row[name]=f.sha(f'synthetic {ordinal} {i}'.encode())
    flags=('parent_reaped','parent_group_absent','worker_reaped','worker_group_absent','source_verified',
        'assets_verified','cleanup_completed','signal_restoration_completed','ordered_ledger_independently_verified',
        'all_metric_and_domain_records_independently_verified')
    row['terminal']=dict.fromkeys(flags,True);row['terminal'].update(parent_exit_code=0 if passed else 1,worker_exit_code=0 if passed else 1)
    row['coverage']=dict(ledger_entries=3200,measured_contexts=3200,candidate_complete=3200,candidate_invalid=0,
        unmeasured_free_suffixes=0,comparison_invalid=0,semantic_passes=3200,native_forward_started=3232,
        native_forward_completed=3232,all_length_invariance=True,phase_counts=dict(native=3200,exact=3200,candidate=3200))
    row['gates']=dict(all_numeric_semantic_domains=passed,trajectories_complete=True,prefill_matches=3072,teacher_matches=64,whole_free_sequences=16)
    return row

def receipt(ordinal=1,validation_sha='a'*64):
    rows=[attempt(n,n==ordinal)for n in range(1,ordinal+1)]
    return dict(schema=f.SCHEMA,protocol_sha256=f.PROTOCOL,arithmetic_sha256=f.ARITHMETIC,reference_sha256=f.REFERENCE,
        first_complete_calibration_pass=True,selection_permanently_closed=True,
        recorded_statistic_reconstruction=True,fresh_array_recomputation=False,
        argmax_recomputed_from_logits=False,invariance_recomputed_from_arrays=False,validation_previously_read=False,
        row0_previously_evaluated=False,validation_execution_authorized=False,row0_execution_authorized=False,
        metric_contract=dict(operators=421,blocks=28,logits=151936,normalization_inputs=113,
            operator_block_nrmse=.05,full_logit_nrmse=.10,semantic_nrmse=1e-5,
            semantic_max_abs=.001,semantic_top1=True,nrmse_floor=.01,all_propagated_domains=True),
        row0=dict(token_id=0,original_position=0,sequence_length=1,excluded_from_selection=True),attempts=rows,
        manifest_sha256=rows[-1]['manifest_sha256'],ordinal=ordinal,validation_input_sha256=validation_sha,
        tokenizer_report_sha256='b'*64,tokenizer_review_sha256='c'*64,model_pins_sha256='d'*64)

def admit(value):
    raw=f.canonical(value);return f.authenticate(raw,f.sha(raw))

@pytest.mark.parametrize('ordinal',[1,2,3])
def test_first_complete_pass_binds_distinct_history_without_authorizing_execution(ordinal):
    value=admit(receipt(ordinal));assert value.ordinal==ordinal and value.execution_authorized is False
    assert f.require_frozen(value)==value

@pytest.mark.parametrize('key',['first_complete_calibration_pass','selection_permanently_closed',
    'validation_previously_read','row0_previously_evaluated','validation_execution_authorized','row0_execution_authorized'])
def test_no_selection_feedback_or_early_data_read(key):
    value=receipt();value[key]=not value[key]
    with pytest.raises(ValueError):admit(value)

@pytest.mark.parametrize('key',['parent_reaped','parent_group_absent','worker_reaped','worker_group_absent',
    'source_verified','assets_verified','cleanup_completed','signal_restoration_completed',
    'ordered_ledger_independently_verified','all_metric_and_domain_records_independently_verified'])
def test_terminal_or_independent_review_missing_cannot_freeze(key):
    value=receipt();value['attempts'][0]['terminal'][key]=False
    with pytest.raises(ValueError):admit(value)

@pytest.mark.parametrize('change',['only_failure','earlier_pass','fourth','duplicate','wrong_last','history_gap'])
def test_first_pass_and_budget_cannot_be_bypassed(change):
    value=receipt(2)
    if change=='only_failure':value['attempts'][-1]=attempt(2,False)
    elif change=='earlier_pass':value['attempts'][0]=attempt(1,True)
    elif change=='fourth':value=receipt(4)
    elif change=='duplicate':value['attempts'][0]['manifest_sha256']=value['manifest_sha256']
    elif change=='wrong_last':value['manifest_sha256']='0'*64
    else:value['attempts'].pop(0)
    with pytest.raises(ValueError):admit(value)

@pytest.mark.parametrize('key,value',[('ledger_entries',3199),('measured_contexts',True),('comparison_invalid',1),
    ('semantic_passes',3199),('native_forward_completed',3231),('all_length_invariance',1),('candidate_invalid',1)])
def test_incomplete_or_comparison_invalid_attempt_cannot_freeze(key,value):
    row=receipt(2);row['attempts'][0]['coverage'][key]=value
    with pytest.raises(ValueError):admit(row)

def test_legitimate_candidate_only_stopped_free_suffix_is_complete_failed_history():
    row=receipt(2);first=row['attempts'][0];c=first['coverage'];c.update(measured_contexts=3197,
        candidate_complete=3196,candidate_invalid=1,unmeasured_free_suffixes=3,semantic_passes=3197,
        native_forward_started=3229,native_forward_completed=3229,phase_counts=dict(native=3197,exact=3197,candidate=3197))
    first['gates'].update(trajectories_complete=False,whole_free_sequences=15)
    assert admit(row).ordinal==2

@pytest.mark.parametrize('path,value',[(('ordinal',),True),(('row0','token_id'),False),
    (('row0','original_position'),0.),(('attempts',0,'terminal','parent_exit_code'),False),
    (('attempts',0,'coverage','phase_counts','candidate'),3200.)])
def test_type_aliases_rejected(path,value):
    row=receipt();part=row
    for key in path[:-1]:part=part[key]
    part[path[-1]]=value
    with pytest.raises(ValueError):admit(row)

@pytest.mark.parametrize('mutation',['manifest','ordinal','authorized','raw','sha'])
def test_constructed_or_mutated_frozen_binding_rechecked(mutation):
    value=admit(receipt())
    values={'manifest':dict(manifest_sha256='0'*64),'ordinal':dict(ordinal=True),
        'authorized':dict(execution_authorized=True),'raw':dict(receipt_bytes=b'{}'),'sha':dict(receipt_sha256='0'*64)}
    with pytest.raises(ValueError):f.require_frozen(replace(value,**values[mutation]))

def test_wrong_external_hash_duplicate_and_nonfinite_rejected():
    raw=f.canonical(receipt())
    with pytest.raises(ValueError):f.authenticate(raw,'0'*64)
    for raw in (b'{"a":1,"a":2}',b'{"a":NaN}',b'{"a":1e999}'):
        with pytest.raises(ValueError):f.authenticate(raw,f.sha(raw))

@pytest.mark.parametrize('name,value',[('operators',420),('blocks',27),('logits',151935),('normalization_inputs',112),
    ('operator_block_nrmse',.051),('full_logit_nrmse',.101),('semantic_nrmse',1e-4),
    ('semantic_max_abs',.01),('semantic_top1',1),('nrmse_floor',.1),('all_propagated_domains',False)])
def test_metric_inventory_and_unchanged_gates_are_in_freeze_receipt(name,value):
    row=receipt();row['metric_contract'][name]=value
    with pytest.raises(ValueError):admit(row)
