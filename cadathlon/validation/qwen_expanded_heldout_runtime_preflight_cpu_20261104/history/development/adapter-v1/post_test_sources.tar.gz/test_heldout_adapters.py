"""Fullarchitecture probes plus synthetic1088 scheduling; no actual bodies/model."""
import copy
from dataclasses import replace
import pytest
import heldout_adapters as h
import heldout_dispatch as d
import freeze_admission as f
from strict_metrics import StructuralFailure
from test_checker_runtime import setup as measured_setup
from test_freeze_admission import receipt,admit
from test_heldout_dispatch import inputs


def setup(mode='heldout',**problems):
    base,sink,arrays,calls,progress=measured_setup(**problems)
    raw=f.canonical(inputs());row=receipt(validation_sha=f.sha(raw))
    row['manifest_sha256']=row['attempts'][-1]['manifest_sha256']=base.manifest_pin
    frozen=admit(row)
    adapter=h.HeldoutAdapters(frozen=frozen,mode=mode,native_forward=base.forward,capture_owner=base.capture,
        config=base.config,weights=base.weights,manifest=base.manifest,manifest_sha256=base.manifest_pin,
        private_output=sink,progress=progress.append,exact_forward=base.exact_forward,plain_forward=base.plain_forward,candidate_forward=base.candidate_forward)
    return adapter,raw,sink,arrays,calls,progress


@pytest.mark.parametrize('S',[1,8,32])
def test_inherited_real_fullarchitecture_metrics_and_independent_embeddings(S):
    a,_,sink,arrays,calls,_=setup();entry=h.WORKLOAD[S-1];prefix=tuple(range(S))
    n=a.native(prefix,entry);e=a.exact(prefix,entry,n);c=a.candidate(prefix,entry)
    assert c==d.Candidate(7,True,True,True,421,28,151936)and e.semantic_pass
    assert calls==[prefix,prefix]and len(arrays)==3
    assert all(x.shape==(1,S,1024)for _,x in arrays)
    assert all(arrays[i][1]is not arrays[j][1]for i in range(3)for j in range(i))
    row=sink.rows[f'{entry.index:04d}-candidate.json']
    assert len(row['operator_metrics'])==421 and len(row['block_metrics'])==28 and row['full_logit_metric']['count']==151936
    assert len(row['observations']['normalization_variance'])==113 and a.pending is None


def test_row0_actual_adapter_path_two_native_calls_separate_ledger():
    a,_,sink,arrays,calls,_=setup('row0');report=a.run()
    assert report['passed']and report['expected_entries']==report['retained_entries']==1
    assert report['phase_counts']==dict(native=1,exact=1,candidate=1)
    assert report['native_invariance_by_length']=={'1':True}and calls==[(0,),(0,)]
    assert report['validation_inputs_read']is False and report['revision_eligible_ledger']is False
    assert len(sink.rows['ledger.json']['records'])==1 and sink.rows['ledger.json']['workload_mode']=='row0'
    with pytest.raises(PermissionError):a.run()


@pytest.mark.parametrize('problem',['operator_numeric','logit_numeric','domain','nonfinite'])
def test_row0_preserves_failed_metric_or_domain_outcome_without_revision(problem):
    a,_,sink,*_=setup('row0',candidate_problem=problem);report=a.run()
    assert not report['passed']and report['ledger_complete']and not report['revision_eligible_ledger']
    assert report['selection_permanently_closed']and report['validation_inputs_read']is False
    assert report['status']==('complete'if problem in('operator_numeric','logit_numeric')else'candidate_invalid')


@pytest.mark.parametrize('fault',['manifest','frozen','mode','row0_token','entry_bool'])
def test_bound_frozen_identity_and_workload_reject_before_native_call(fault):
    a,_,sink,_,calls,_=setup('row0');entry=d.ROW0;prefix=(0,)
    if fault=='manifest':a.manifest_pin='b'*64
    elif fault=='frozen':a.frozen=replace(a.frozen,ordinal=True)
    elif fault=='mode':a.mode='heldout'
    elif fault=='row0_token':prefix=(1,)
    else:entry=replace(entry,index=False)
    with pytest.raises((ValueError,StructuralFailure)):a.native(prefix,entry)
    assert calls==[]and sink.rows=={}


def synthetic_scheduler(a,*,bad_numeric=False,stop=None):
    seen=[];native_calls=[]
    def native(prefix,entry):
        a.binding(prefix,entry);seen.append((entry,prefix))
        if len(prefix)not in a.native_invariance:native_calls.append(prefix)
        native_calls.append(prefix);a.native_invariance[len(prefix)]=True
        a.phase_counts['native']+=1;a.native_ranges.contexts+=1
        return d.Native(7)
    def exact(prefix,entry,n):
        a.exact_invariance[len(prefix)]=True;a.phase_counts['exact']+=1
        a.exact_ranges.contexts+=1;a.semantic_passes+=1;return d.Exact(n.token,True)
    def candidate(prefix,entry):
        a.phase_counts['candidate']+=1
        if stop and stop(entry):raise d.CandidateStop('synthetic stop')
        a.candidate_complete+=1
        return d.Candidate(11 if bad_numeric and entry.kind=='free'else 7,True,not bad_numeric,True,421,28,151936)
    a.native=native;a.exact=exact;a.candidate=candidate
    return seen,native_calls


def test_full1088_synthetic_schedule_counts_and_firstshape_native_controls():
    a,raw,sink,*_=setup();seen,calls=synthetic_scheduler(a);report=a.run(raw)
    assert report['passed']and len(seen)==1088 and len(calls)==1120
    assert report['complete_measured_context_coverage']and report['all_length_invariance']
    assert report['phase_counts']==dict(native=1088,exact=1088,candidate=1088)
    assert report['gates']==dict(all_numeric_semantic_domains=True,prefill_top1=True,teacher_top1=True,complete_free_sequences=True)
    assert report['by_kind']['prefill']['top1_matches']==1024 and report['complete_free_sequences']==8
    assert report['revision_eligible_ledger']is False and len(sink.rows['ledger.json']['records'])==1088


def test_numeric_failure_uses_actual_own_free_tokens_and_denominators():
    a,raw,sink,*_=setup();seen,calls=synthetic_scheduler(a,bad_numeric=True);report=a.run(raw)
    assert not report['passed']and report['complete_measured_context_coverage']and len(calls)==1120
    assert seen[-1][1][-3:]==(11,11,11)and report['by_kind']['free']['top1_denominator']==32
    assert not report['revision_eligible_ledger']and report['selection_permanently_closed']


@pytest.mark.parametrize('kind',['teacher','free'])
def test_candidate_stop_continuation_matches_kind_without_revision(kind):
    a,raw,sink,*_=setup();seen,calls=synthetic_scheduler(a,stop=lambda e:e.kind==kind and e.seed_ordinal==0 and e.step==1)
    report=a.run(raw);assert report['ledger_complete']and not report['passed']and not report['revision_eligible_ledger']
    assert report['by_kind'][kind]['candidate_invalid']==1
    assert report['by_kind'][kind]['unmeasured']==(2 if kind=='free'else 0)
    assert len(sink.rows['ledger.json']['records'])==1088
    if kind=='teacher':assert next(prefix for entry,prefix in seen if entry.kind=='teacher'and entry.seed_ordinal==0 and entry.step==3)[-3:]==(7,7,7)


def test_bad_validation_body_rejects_before_adapter_callback_and_consumes_local_attempt():
    a,raw,sink,_,calls,_=setup()
    with pytest.raises(ValueError):a.run(raw+b' ')
    assert calls==[]and sink.rows=={}
    with pytest.raises(PermissionError):a.run(raw)


def test_row0_forbids_any_validation_bytes_before_forward():
    a,raw,sink,_,calls,_=setup('row0')
    with pytest.raises(StructuralFailure):a.run(raw)
    assert calls==[]and sink.rows=={}


def test_measurement_functions_are_inherited_identically_not_reimplemented():
    for name in('native','exact','candidate','embeddings','journal','merge_candidate'):
        assert getattr(h.HeldoutAdapters,name)is getattr(h.measured.ContextAdapters,name)
