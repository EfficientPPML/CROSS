"""Workload-only adapters over unchanged checker measurements and arithmetic."""
from dataclasses import asdict
import copy
from pathlib import Path
import checker_runtime as measured
import heldout_dispatch as dispatch
from freeze_admission import require_frozen
from strict_metrics import StructuralFailure

WORKLOAD = dispatch.workload()


class HeldoutAdapters(measured.ContextAdapters):
    def __init__(self, *, frozen, mode, **kwargs):
        if type(mode) is not str or mode not in ('heldout','row0'):
            raise StructuralFailure('Exact heldout or separate row0 mode required')
        value=require_frozen(frozen)
        if kwargs.get('manifest_sha256') != value.manifest_sha256:
            raise StructuralFailure('Frozen first-PASS manifest differs')
        super().__init__(**kwargs)
        self.frozen=value;self.mode=mode;self._frozen=value;self._mode=mode
        self._started=False

    def _guard(self):
        if self.frozen is not self._frozen or self.mode != self._mode or type(self.mode) is not str:
            raise StructuralFailure('Construction-bound frozen workload changed')
        value=require_frozen(self.frozen)
        if value.manifest_sha256 != self.manifest_pin:
            raise StructuralFailure('Frozen manifest changed')
        return value

    def binding(self,prefix,entry):
        self._guard()
        wanted_rows=WORKLOAD if self.mode=='heldout'else (dispatch.ROW0,)
        if type(entry)is not dispatch.Entry or type(entry.index)is not int or not 0<=entry.index<len(wanted_rows):
            raise StructuralFailure('Exact frozen workload entry required')
        wanted=wanted_rows[entry.index]
        if any(type(getattr(entry,k))is not type(v)or getattr(entry,k)!=v for k,v in vars(wanted).items()):
            raise StructuralFailure('Typed heldout/row0 workload entry differs')
        if type(prefix)is not tuple or len(prefix)!=entry.length or any(type(t)is not int or not 0<=t<151936 for t in prefix):
            raise StructuralFailure('Exact actual heldout prefix required')
        if self.mode=='row0'and prefix!=(0,):
            raise StructuralFailure('Separate row0 requires token0 at original position0')
        return (entry.index,prefix,self.manifest_pin)

    def run(self,raw=None):
        self._guard()
        if self._started is not False:
            raise PermissionError('Frozen heldout/row0 outcomes cannot trigger a retry')
        self._started=True
        expected=1088 if self.mode=='heldout'else 1
        lengths=set(range(1,33))if self.mode=='heldout'else {1}
        if self.mode=='heldout':
            result=dispatch.run_validation(raw,frozen=self.frozen,native=self.native,exact=self.exact,candidate=self.candidate)
            report=result.public_report();records=result.records
        else:
            if raw is not None:
                raise StructuralFailure('Row0 may not consume a validation body')
            result=dispatch.run_row0(frozen=self.frozen,native=self.native,exact=self.exact,candidate=self.candidate)
            report=result.public_report();records=(result.record,)
            report.update(expected_entries=1,retained_entries=1,ledger_complete=True,trajectories_complete=report['complete'])
        invariance=(set(self.native_invariance)==set(self.exact_invariance)==lengths and
                    all(v is True for v in self.native_invariance.values())and all(v is True for v in self.exact_invariance.values()))
        coverage=(self.phase_counts==dict(native=expected,exact=expected,candidate=expected)and
                  self.semantic_passes==self.candidate_complete==self.native_ranges.contexts==self.exact_ranges.contexts==expected)
        report.update(phase_counts=dict(self.phase_counts),semantic_passes=self.semantic_passes,candidate_complete=self.candidate_complete,
            native_invariance_by_length={str(k):v for k,v in self.native_invariance.items()},
            exact_invariance_by_length={str(k):v for k,v in self.exact_invariance.items()},all_length_invariance=invariance,
            complete_measured_context_coverage=coverage,
            input_ranges=dict(native=self.native_ranges.report(),exact=self.exact_ranges.report(),candidate_propagated=copy.deepcopy(self.candidate_ranges)),
            limits=dict(operator_block_nrmse=.05,full_logit_nrmse=.10,semantic_nrmse=1e-5,semantic_max_abs=.001,nrmse_floor=.01),
            coefficient_selection_performed=False,encrypted_execution=False,
            validation_inputs_read=self.mode=='heldout',revision_eligible_ledger=False,
            selection_permanently_closed=True,workload_mode=self.mode,
            freeze_receipt_sha256=self.frozen.receipt_sha256)
        report['passed']=report['passed']and invariance and coverage
        report['complete']=report['ledger_complete']
        self._guard()
        self.private.json('ledger.json',dict(manifest_sha256=self.manifest_pin,freeze_receipt_sha256=self.frozen.receipt_sha256,
            workload_mode=self.mode,records=[asdict(r)for r in records],summary=report))
        return report
