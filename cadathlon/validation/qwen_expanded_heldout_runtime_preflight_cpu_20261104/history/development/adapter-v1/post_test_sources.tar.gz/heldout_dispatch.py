"""Pure heldout1088 dispatcher and separate fixed row0 regression.

No filesystem/model IO or selection. Adapters supply same-prefix results;
freeze authentication is a prerequisite, never an execution grant.
"""
from dataclasses import dataclass
from candidate_dispatch import Candidate, CandidateStop, Record, checked, digest
from workload import Entry, Native, Exact, InvalidObservation, _prediction, _tokens
from freeze_admission import FrozenCandidate, require_frozen, parse, sha


def workload():
    rows=[]
    for prompt in range(32):
        for length in range(1,33):rows.append(Entry(len(rows),'prefill',prompt,None,None,length,False))
    for kind in ('teacher','free'):
        for seed in range(8):
            for step in range(4):rows.append(Entry(len(rows),kind,None,seed,step,16+step,False))
    return tuple(rows)


def validation_inputs(raw,frozen):
    require_frozen(frozen)
    if type(raw)is not bytes or not 0<len(raw)<=4<<20 or sha(raw)!=frozen.validation_input_sha256:
        raise ValueError('Exactly frozen heldout input bytes required')
    # The receipt parser has a1MiB public bound; token metadata can use4MiB.
    import json
    def pairs(items):
        out={}
        for name,value in items:
            if name in out:raise ValueError('Duplicate input field')
            out[name]=value
        return out
    def invalid(value):raise ValueError('Nonfinite input metadata')
    value=json.loads(raw,object_pairs_hook=pairs,parse_constant=invalid)
    if type(value)is not dict or set(value)!={'prefills','decode_seeds','natural_token_lengths'}:
        raise ValueError('Exact frozen tokenizer validation schema required')
    rows,seeds,lengths=value['prefills'],value['decode_seeds'],value['natural_token_lengths']
    if type(rows)is not list or len(rows)!=1024 or type(seeds)is not list or len(seeds)!=8:
        raise ValueError('Exact1024 prefills and8 seeds required')
    if type(lengths)is not list or len(lengths)!=32 or any(type(n)is not int or n<32 for n in lengths):
        raise ValueError('Exact natural tokenizer lengths required')
    prefixes=[];full=[]
    for prompt in range(32):
        family=[]
        for length in range(1,33):
            row=rows[prompt*32+length-1]
            if type(row)is not dict or set(row)!={'prompt_ordinal','sequence_length','token_ids'}:
                raise ValueError('Exact heldout prefill fields required')
            if type(row['prompt_ordinal'])is not int or row['prompt_ordinal']!=prompt or type(row['sequence_length'])is not int or row['sequence_length']!=length:
                raise ValueError('Exact fixed prompt/prefix order required')
            family.append(_tokens(row['token_ids'],length))
        if any(x!=family[-1][:len(x)]for x in family):raise ValueError('Original append-only prefix family required')
        prefixes.extend(family);full.append(family[-1])
    seed_values=[]
    for index,row in enumerate(seeds):
        if type(row)is not dict or set(row)!={'seed_ordinal','prompt_ordinal','token_ids'}:
            raise ValueError('Exact heldout seed fields required')
        if type(row['seed_ordinal'])is not int or row['seed_ordinal']!=index or type(row['prompt_ordinal'])is not int or row['prompt_ordinal']!=4*index:
            raise ValueError('Fixed0,4,...28 seed prompt mapping required')
        tokens=_tokens(row['token_ids'],16)
        if tokens!=full[4*index][:16]:raise ValueError('Original S16 seed required')
        seed_values.append(tokens)
    return tuple(prefixes),tuple(seed_values)


@dataclass(frozen=True)
class Result:
    frozen:FrozenCandidate
    records:tuple

    @property
    def manifest_sha256(self):return require_frozen(self.frozen).manifest_sha256

    def validate(self):
        """Validate evidence and continuation, including manually built ledgers.

        This does not authenticate adapter measurements. It rejects structural
        forgeries; heldout outcomes can never admit candidate revision.
        """
        digest(self.manifest_sha256)
        expected=workload()
        if type(self.records)is not tuple or len(self.records)>len(expected):
            raise ValueError('Exact bounded record tuple required')
        chains={};stopped=set();seeds={};prefills={}
        for row,wanted in zip(self.records,expected):
            if type(row)is not Record or type(row.entry)is not Entry:
                raise ValueError('Exact record and entry required')
            if any(type(getattr(row.entry,k))is not type(v)or getattr(row.entry,k)!=v
                   for k,v in vars(wanted).items()):
                raise ValueError('Exact ordered typed workload entry required')
            e=row.entry;key=(e.kind,e.seed_ordinal)
            if type(row.status)is not str or row.status not in ('complete','candidate_invalid','comparison_invalid','unmeasured_suffix'):
                raise ValueError('Declared record status required')
            if key in stopped:
                if row.status!='unmeasured_suffix' or any(getattr(row,k)is not None for k in
                        ('prefix','native','exact','candidate','failed_stage','failure')):
                    raise ValueError('Stopped suffix must retain no fabricated measurement')
                continue
            if row.status=='unmeasured_suffix':raise ValueError('Unmeasured suffix requires earlier dependent stop')
            prefix=row.prefix
            if type(prefix)is not tuple or len(prefix)!=e.length or any(type(t)is not int or not 0<=t<151936 for t in prefix):
                raise ValueError('Exact measured prefix required')
            if e.kind=='prefill':
                if e.length>1 and prefix[:-1]!=prefills[e.prompt_ordinal]:
                    raise ValueError('Prefill family must retain original append-only prefixes')
                prefills[e.prompt_ordinal]=prefix
            else:
                if e.step==0:
                    if e.kind=='teacher':
                        if prefix!=prefills[4*e.seed_ordinal][:16]:raise ValueError('Decode seed must match original S16 family')
                        seeds[e.seed_ordinal]=prefix
                    elif prefix!=seeds[e.seed_ordinal]:raise ValueError('Teacher/free seeds differ')
                elif prefix!=chains.get(key):raise ValueError('Continuation differs from actual preceding argmax')
            if row.status=='comparison_invalid':
                if row.failed_stage not in ('native','exact')or type(row.failure)is not str or row.candidate is not None:
                    raise ValueError('Comparison failure evidence differs')
                if row.failed_stage=='native':
                    if row.native is not None or row.exact is not None:raise ValueError('Native stop cannot supply comparison evidence')
                else:
                    n=_prediction(row.native,Native)
                    if row.exact is not None:
                        x=_prediction(row.exact,Exact)
                        if x.semantic_pass and x.token==n.token:raise ValueError('Successful comparison cannot be labeled invalid')
                if e.kind!='prefill':stopped.add(key)
                continue
            n=_prediction(row.native,Native);x=_prediction(row.exact,Exact)
            if not x.semantic_pass or x.token!=n.token:raise ValueError('Trusted native/exact comparison required')
            if row.status=='candidate_invalid':
                if row.failed_stage!='candidate'or type(row.failure)is not str:raise ValueError('Candidate stop evidence differs')
                if row.candidate is not None and checked(row.candidate).complete:raise ValueError('Stopped candidate cannot supply complete output')
                if e.kind=='free':stopped.add(key)
                elif e.kind=='teacher':chains[key]=prefix+(n.token,)
                continue
            if row.failed_stage is not None or row.failure is not None:raise ValueError('Complete record cannot contain failure evidence')
            candidate=checked(row.candidate)
            if not candidate.complete:raise ValueError('Complete record requires all candidate measurements')
            if e.kind!='prefill':chains[key]=prefix+((n.token if e.kind=='teacher'else candidate.token),)
        return len(self.records)==len(expected)

    def public_report(self):
        ordered=self.validate()
        kinds={}
        for kind,total in (('prefill',1024),('teacher',32),('free',32)):
            rows=[r for r in self.records if r.entry.kind==kind]
            kinds[kind]=dict(expected=total,records=len(rows),complete=sum(r.status=='complete'for r in rows),
                candidate_invalid=sum(r.status=='candidate_invalid'for r in rows),comparison_invalid=sum(r.status=='comparison_invalid'for r in rows),
                unmeasured=sum(r.status=='unmeasured_suffix'for r in rows),
                top1_matches=sum(r.native is not None and r.candidate is not None and r.candidate.complete and r.native.token==r.candidate.token for r in rows),
                top1_denominator=total)
        sequences=0
        for seed in range(8):
            teacher=[r for r in self.records if r.entry.kind=='teacher'and r.entry.seed_ordinal==seed]
            free=[r for r in self.records if r.entry.kind=='free'and r.entry.seed_ordinal==seed]
            trusted=(len(teacher)==len(free)==4 and all(r.native is not None and r.exact is not None and r.exact.semantic_pass and r.exact.token==r.native.token for r in teacher))
            complete=all(r.status=='complete'and r.candidate is not None and r.candidate.complete for r in free)
            sequences+=int(trusted and complete and [r.native.token for r in teacher]==[r.candidate.token for r in free])
        all_complete=ordered and all(r.status=='complete'for r in self.records)
        all_gates=all_complete and all(r.candidate.numeric_pass and r.candidate.domain_pass and r.exact.semantic_pass and r.exact.token==r.native.token for r in self.records)
        gates=dict(all_numeric_semantic_domains=all_gates,prefill_top1=kinds['prefill']['top1_matches']>=922,
            teacher_top1=kinds['teacher']['top1_matches']>=29,complete_free_sequences=sequences>=6)
        passed=ordered and all(gates.values())
        return dict(schema='qwen-heldout1088-ledger-v1',manifest_sha256=self.manifest_sha256,expected_entries=1088,retained_entries=len(self.records),
            ledger_complete=ordered,trajectories_complete=all_complete,by_kind=kinds,complete_free_sequences=sequences,complete_free_denominator=8,
            gates=gates,passed=passed,revision_eligible_ledger=False,freeze_receipt_sha256=self.frozen.receipt_sha256,
            selection_permanently_closed=True,free_step_agreement_is_diagnostic=True,
            prefill_by_length={str(n):dict(expected=32,records=sum(r.entry.kind=='prefill'and r.entry.length==n for r in self.records),
                top1_matches=sum(r.entry.kind=='prefill'and r.entry.length==n and r.native is not None and r.candidate is not None and r.candidate.complete and r.native.token==r.candidate.token for r in self.records))for n in range(1,33)},
            contains_tokens_logits_or_failure_text=False)

    def require_revision(self,*args,**kwargs):
        raise PermissionError('Heldout outcomes never authorize new selection or candidate revision')

def measure(prefix,entry,*,native,exact,candidate):
    n=e=c=None;stage='native'
    try:
        n=_prediction(native(prefix,entry),Native);stage='exact'
        e=_prediction(exact(prefix,entry,n),Exact)
        if not e.semantic_pass or e.token!=n.token:raise InvalidObservation('Native/exact semantic failure')
    except InvalidObservation as error:
        return Record(entry,prefix,'comparison_invalid',n,e,None,stage,str(error))
    try:
        c=checked(candidate(prefix,entry))
        if not c.complete:raise CandidateStop('Candidate domain/nonfinite stop')
    except CandidateStop as error:
        return Record(entry,prefix,'candidate_invalid',n,e,c,'candidate',str(error))
    return Record(entry,prefix,'complete',n,e,c)

def run_validation(raw,*,frozen,native,exact,candidate):
    require_frozen(frozen)
    prefills,seeds=validation_inputs(raw,frozen);rows=[];chains={};stopped=set()
    for entry in workload():
        key=(entry.kind,entry.seed_ordinal)
        if entry.kind!='prefill'and key in stopped:
            rows.append(Record(entry,None,'unmeasured_suffix'));continue
        prefix=prefills[entry.index]if entry.kind=='prefill'else chains.get(key,seeds[entry.seed_ordinal])
        if len(prefix)!=entry.length:raise ValueError('Internal prefix length differs')
        row=measure(prefix,entry,native=native,exact=exact,candidate=candidate);rows.append(row)
        if row.status=='comparison_invalid':
            if entry.kind!='prefill':stopped.add(key)
        elif row.status=='candidate_invalid':
            if entry.kind=='free':stopped.add(key)
            elif entry.kind=='teacher':chains[key]=prefix+(row.native.token,)
        elif entry.kind!='prefill':chains[key]=prefix+((row.native.token if entry.kind=='teacher'else row.candidate.token),)
    result=Result(frozen,tuple(rows));result.validate();return result

ROW0=Entry(0,'row0',None,None,None,1,False)

@dataclass(frozen=True)
class Row0Result:
    frozen:FrozenCandidate
    record:Record

    def public_report(self):
        require_frozen(self.frozen);row=self.record
        if type(row)is not Record or type(row.entry)is not Entry or any(type(getattr(row.entry,n))is not type(v)or getattr(row.entry,n)!=v for n,v in vars(ROW0).items()):
            raise ValueError('Exact separate row0 record required')
        if type(row.prefix)is not tuple or len(row.prefix)!=1 or type(row.prefix[0])is not int or row.prefix[0]!=0:
            raise ValueError('Original token0 at position0 required')
        if row.status=='complete':
            n=_prediction(row.native,Native);e=_prediction(row.exact,Exact);c=checked(row.candidate)
            if row.failed_stage is not None or row.failure is not None or not c.complete or not e.semantic_pass or e.token!=n.token:
                raise ValueError('Complete row0 requires full comparison/candidate evidence')
            passed=c.numeric_pass and c.domain_pass
            match=c.token==n.token
        elif row.status=='candidate_invalid':
            n=_prediction(row.native,Native);e=_prediction(row.exact,Exact)
            if not e.semantic_pass or e.token!=n.token or row.failed_stage!='candidate'or type(row.failure)is not str or row.candidate is not None and checked(row.candidate).complete:
                raise ValueError('Stopped row0 candidate evidence differs')
            passed=False;match=False
        elif row.status=='comparison_invalid':
            if row.candidate is not None or row.failed_stage not in('native','exact')or type(row.failure)is not str:
                raise ValueError('Row0 comparison failure evidence differs')
            if row.failed_stage=='native':
                if row.native is not None or row.exact is not None:raise ValueError('Stopped native cannot supply evidence')
            else:
                n=_prediction(row.native,Native)
                if row.exact is not None:
                    e=_prediction(row.exact,Exact)
                    if e.semantic_pass and e.token==n.token:raise ValueError('Successful comparison mislabeled')
            passed=False;match=False
        else:raise ValueError('Declared row0 status required')
        return dict(schema='qwen-row0-postfreeze-regression-v1',manifest_sha256=self.frozen.manifest_sha256,
            freeze_receipt_sha256=self.frozen.receipt_sha256,status=row.status,complete=row.status=='complete',passed=bool(passed),
            top1_match=match,selection_permanently_closed=True,revision_eligible=False,
            scope='Separate checkpoint embedding row0/token0 S1/originalposition0; never heldout1088 coverage or selection extrema',
            original_frozen_failure_unchanged=True,contains_tokens_logits_or_failure_text=False)

def run_row0(*,frozen,native,exact,candidate):
    require_frozen(frozen)
    result=Row0Result(frozen,measure((0,),ROW0,native=native,exact=exact,candidate=candidate))
    result.public_report();return result

class FrozenWorkflow:
    """Pure single-attempt state; runtime must authenticate persistent receipts.

    No read or execution capability is conferred by construction. A reviewed
    worker must perform grants/body-read admission separately.
    """
    def __init__(self,frozen):
        self.frozen=require_frozen(frozen);self._original=self.frozen
        self.validation_started=False;self.row0_started=False
    def _guard(self):
        if self.frozen is not self._original:raise ValueError('Construction-bound frozen candidate changed')
        require_frozen(self.frozen)
    def validation(self,raw,**adapters):
        self._guard()
        if self.validation_started:raise PermissionError('Validation outcome cannot trigger retry or tuning here')
        self.validation_started=True
        return run_validation(raw,frozen=self.frozen,**adapters)
    def row0(self,**adapters):
        self._guard()
        if self.row0_started:raise PermissionError('Row0 outcome cannot trigger retry or tuning here')
        self.row0_started=True
        return run_row0(frozen=self.frozen,**adapters)
    def admit_candidate(self,*args,**kwargs):
        raise PermissionError('First complete calibration PASS permanently closes selection')

