"""Full synthetic1088 ledgers. No real tokens, reports, assets or models."""
import copy,json
from dataclasses import replace
import pytest
import heldout_dispatch as h
import freeze_admission as f
from test_freeze_admission import receipt,admit

def inputs():
    rows=[];full=[]
    for p in range(32):
        values=list(range(1000+p*32,1032+p*32));full.append(values)
        for length in range(1,33):rows.append(dict(prompt_ordinal=p,sequence_length=length,token_ids=values[:length]))
    return dict(prefills=rows,decode_seeds=[dict(seed_ordinal=s,prompt_ordinal=4*s,token_ids=full[4*s][:16])for s in range(8)],natural_token_lengths=[64]*32)

def fixture(value=None):
    raw=f.canonical(inputs()if value is None else value);return raw,admit(receipt(validation_sha=f.sha(raw)))

def adapters(events,*,choice=None,stop=None,numeric=None,comparison=None,structural=None):
    def native(prefix,entry):
        events.append(('native',prefix,entry))
        if comparison and comparison(entry):raise h.InvalidObservation('PRIVATE failure detail')
        return h.Native(7)
    def exact(prefix,entry,n):events.append(('exact',prefix,entry));return h.Exact(n.token,True)
    def candidate(prefix,entry):
        events.append(('candidate',prefix,entry))
        if structural and structural(entry):raise RuntimeError('structure failed')
        if stop and stop(entry):raise h.CandidateStop('PRIVATE candidate detail')
        token=7 if choice is None else choice(entry)
        return h.Candidate(token,True,not(numeric and numeric(entry)),True,421,28,151936)
    return dict(native=native,exact=exact,candidate=candidate)

def run(**kwargs):
    raw,frozen=fixture();events=[]
    result=h.run_validation(raw,frozen=frozen,**adapters(events,**kwargs));return result,events

def test_complete_fixed1088_order_full_counts_and_public_privacy():
    result,events=run();report=result.public_report()
    assert report['passed']and report['retained_entries']==1088 and len(events)==3264
    assert report['by_kind']['prefill']['top1_matches']==1024
    assert report['by_kind']['teacher']['top1_matches']==report['by_kind']['free']['top1_matches']==32
    assert report['complete_free_sequences']==8 and all(r['records']==32 for r in report['prefill_by_length'].values())
    assert all(len({x[1]for x in events[i:i+3]})==1 for i in range(0,len(events),3))
    public=json.dumps(report);assert all(word not in public for word in ['PRIVATE','token_ids','prefix"'])
    assert not report['revision_eligible_ledger']and report['selection_permanently_closed']

@pytest.mark.parametrize('miss,passed',[(102,True),(103,False)])
def test_prefill_922_gate_is_aggregate_not_per_length(miss,passed):
    result,_=run(choice=lambda e:8 if e.kind=='prefill'and e.index<miss else 7)
    report=result.public_report();assert report['passed']is passed
    assert report['by_kind']['prefill']['top1_matches']==1024-miss

@pytest.mark.parametrize('miss,passed',[(3,True),(4,False)])
def test_teacher_29_of32_gate(miss,passed):
    result,_=run(choice=lambda e:8 if e.kind=='teacher'and e.index-1024<miss else 7)
    assert result.public_report()['passed']is passed

@pytest.mark.parametrize('wrong_sequences,passed',[(2,True),(3,False)])
def test_whole_free_six_ofeight_and_no_unlisted_free_step_gate(wrong_sequences,passed):
    result,events=run(choice=lambda e:11 if e.kind=='free'and e.seed_ordinal<wrong_sequences else 7)
    report=result.public_report();assert report['passed']is passed
    assert report['complete_free_sequences']==8-wrong_sequences
    assert report['by_kind']['free']['top1_matches']==32-4*wrong_sequences
    if wrong_sequences==2:assert report['by_kind']['free']['top1_matches']==24 and report['passed']
    rows=[r for r in result.records if r.entry.kind=='free'and r.entry.seed_ordinal==0]
    assert rows[-1].prefix[-3:]==(11,11,11)

@pytest.mark.parametrize('step',range(4))
def test_finite_failure_keeps_own_candidate_free_argmax(step):
    result,_=run(choice=lambda e:11 if e.kind=='free'else 7,numeric=lambda e:e.kind=='free'and e.seed_ordinal==0 and e.step==step)
    rows=result.records[1056:1060];assert all(r.status=='complete'for r in rows)
    assert rows[-1].prefix[-3:]==(11,11,11)and not rows[step].candidate.numeric_pass
    assert not result.public_report()['passed']

@pytest.mark.parametrize('kind',['prefill','teacher','free'])
@pytest.mark.parametrize('step',[0,2])
def test_candidate_stop_preserves_denominators_and_teacher_continuation(kind,step):
    def stop(e):return e.kind==kind and(e.index==step if kind=='prefill'else e.seed_ordinal==0 and e.step==step)
    result,_=run(stop=stop);report=result.public_report()
    assert report['ledger_complete']and not report['passed']and report['retained_entries']==1088
    assert report['by_kind'][kind]['candidate_invalid']==1
    assert report['by_kind'][kind]['unmeasured']==(3-step if kind=='free'else 0)
    if kind=='teacher':assert result.records[1027].prefix[-3:]==(7,7,7)
    with pytest.raises(PermissionError):result.require_revision({})

@pytest.mark.parametrize('kind',['prefill','teacher','free'])
def test_comparison_failure_stops_only_dependent_chain_without_feedback(kind):
    result,_=run(comparison=lambda e:e.kind==kind and(e.index==0 if kind=='prefill'else e.seed_ordinal==0 and e.step==1))
    report=result.public_report();assert not report['passed']and not report['revision_eligible_ledger']
    assert report['by_kind'][kind]['comparison_invalid']==1
    assert report['by_kind'][kind]['unmeasured']==(0 if kind=='prefill'else 2)

@pytest.mark.parametrize('mutation',['all_unmeasured','unknown','native_missing','counter_bool','wrong_seed','wrong_append','wrong_freeze'])
def test_manually_forged_ledgers_reject(mutation):
    result,_=run();rows=list(result.records)
    if mutation=='all_unmeasured':rows=[h.Record(r.entry,None,'unmeasured_suffix')for r in rows]
    elif mutation=='unknown':rows[0]=replace(rows[0],status='unknown')
    elif mutation=='native_missing':rows[0]=replace(rows[0],native=None)
    elif mutation=='counter_bool':rows[0]=replace(rows[0],candidate=replace(rows[0].candidate,operators=True))
    elif mutation=='wrong_seed':rows[1024]=replace(rows[1024],prefix=rows[32+15].prefix)
    elif mutation=='wrong_append':rows[1057]=replace(rows[1057],prefix=rows[1057].prefix[:-1]+(8,))
    else:result=replace(result,frozen=replace(result.frozen,ordinal=True))
    with pytest.raises(ValueError):replace(result,records=tuple(rows)).public_report()

@pytest.mark.parametrize('mutation',['bool_token','wrong_order','seed_mapping','nonappend','natural_alias','extra','missing'])
def test_actual_tokenizer_schema_is_strict_without_body_IO(mutation):
    value=inputs()
    if mutation=='bool_token':value['prefills'][0]['token_ids']=[True]
    elif mutation=='wrong_order':value['prefills'][0]['prompt_ordinal']=1
    elif mutation=='seed_mapping':value['decode_seeds'][0]['prompt_ordinal']=4
    elif mutation=='nonappend':value['prefills'][1]['token_ids'][0]=3
    elif mutation=='natural_alias':value['natural_token_lengths'][0]=64.
    elif mutation=='extra':value['old_outcomes']=[]
    else:value['prefills'].pop()
    raw,frozen=fixture(value)
    with pytest.raises(ValueError):h.validation_inputs(raw,frozen)

def test_wrong_body_or_unfrozen_state_rejected_before_any_callback():
    raw,frozen=fixture();events=[]
    for payload,binding in [(raw,None),(raw+b' ',frozen)]:
        with pytest.raises(ValueError):h.run_validation(payload,frozen=binding,**adapters(events))
    assert not events

def test_row0_is_separate_fixed_original_position_regression():
    raw,frozen=fixture();events=[]
    result=h.run_row0(frozen=frozen,**adapters(events));report=result.public_report()
    assert report['passed']and report['complete']and all(x[1]==(0,)and x[2]==h.ROW0 for x in events)
    assert report['original_frozen_failure_unchanged']and not report['revision_eligible']
    stopped=h.run_row0(frozen=frozen,**adapters([],stop=lambda e:True))
    assert not stopped.public_report()['passed']and stopped.public_report()['status']=='candidate_invalid'
    with pytest.raises(ValueError):replace(result,record=replace(result.record,prefix=(False,))).public_report()

def test_no_feedback_after_any_heldout_outcome_or_infrastructure_stop():
    raw,frozen=fixture();workflow=h.FrozenWorkflow(frozen)
    with pytest.raises(RuntimeError):workflow.validation(raw,**adapters([],structural=lambda e:True))
    with pytest.raises(PermissionError):workflow.validation(raw,**adapters([]))
    with pytest.raises(PermissionError):workflow.admit_candidate('new')
    result=workflow.row0(**adapters([],stop=lambda e:True));assert not result.public_report()['passed']
    with pytest.raises(PermissionError):workflow.row0(**adapters([]))

def test_row0_requires_freeze_and_workflow_cannot_replace_it():
    raw,frozen=fixture();events=[]
    with pytest.raises(ValueError):h.run_row0(frozen=None,**adapters(events))
    workflow=h.FrozenWorkflow(frozen);workflow.frozen=admit(receipt(2,validation_sha=f.sha(raw)))
    with pytest.raises(ValueError):workflow.validation(raw,**adapters(events))
    with pytest.raises(ValueError):workflow.row0(**adapters(events))
    assert events==[]
