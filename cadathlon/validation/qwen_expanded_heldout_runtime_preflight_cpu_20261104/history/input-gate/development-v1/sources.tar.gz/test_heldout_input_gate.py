"""Public-metadata admission and newly owned synthetic reader fixtures only."""
from pathlib import Path
import copy,hashlib,json
import pytest
import heldout_input_gate as gate
import input_gate
import freeze_admission
from freeze_io import json_bytes
from test_input_gate import blobs
from test_freeze_admission import receipt,admit


def public_fixture():
    data=blobs();worker=json.loads(data['public/tokenizer_worker_report.json'])
    producer=json.loads(data['external_inputs.json'])['producer']
    row=receipt(validation_sha=worker['private_outputs']['validation']['sha256'])
    row.update(tokenizer_report_sha256=producer['tokenizer_report_sha256'],
               tokenizer_review_sha256=producer['tokenizer_root_review_sha256'],
               model_pins_sha256=input_gate.sha(data['public/model_pins.json']))
    return data,admit(row)


def test_public_inspection_and_constructor_never_stat_or_open_external(monkeypatch):
    data,frozen=public_fixture()
    monkeypatch.setattr(input_gate,'read',lambda *a,**k:pytest.fail('external body read'))
    monkeypatch.setattr(input_gate.os,'stat',lambda *a,**k:pytest.fail('external stat'))
    monkeypatch.setattr(input_gate.os,'open',lambda *a,**k:pytest.fail('external open'))
    result=gate.inspect_validation(data,frozen);reader=gate.ValidationReader(data,frozen)
    assert result==reader.description
    assert result['path'].endswith('/validation_inputs.json')and result['bytes']==334763
    assert result['sha256']==frozen.validation_input_sha256
    assert reader.loaded is False and reader.start is None
    reader.recheck()


def test_reader_methods_are_exact_inherited_implementations():
    assert gate.ValidationReader.__call__ is input_gate.Reader.__call__
    assert gate.ValidationReader.recheck is input_gate.Reader.recheck
    assert set(gate.ValidationReader.__dict__)-{'__module__','__doc__'}=={'__init__'}


@pytest.mark.parametrize('field',['validation_input_sha256','model_pins_sha256','tokenizer_report_sha256','tokenizer_review_sha256'])
def test_freeze_public_metadata_must_match_producer(field):
    data,frozen=public_fixture();row=freeze_admission.parse(frozen.receipt_bytes);row[field]='0'*64
    with pytest.raises(ValueError):gate.inspect_validation(data,admit(row))


@pytest.mark.parametrize('name',['public/tokenizer_report.json','public/tokenizer_worker_report.json',
    'public/tokenizer_root_review.json','public/tokenizer_sources.tar.gz','public/tokenizer_grant.json'])
def test_inherited_producer_authentication_precedes_validation_descriptor(name,monkeypatch):
    data,frozen=public_fixture();data[name]+=b' '
    monkeypatch.setattr(gate,'require_frozen',lambda *a:pytest.fail('freeze after damaged producer admitted'))
    with pytest.raises(ValueError):gate.inspect_validation(data,frozen)


@pytest.mark.parametrize('change',['descriptor_bool_bytes','descriptor_extra','descriptor_mode','descriptor_identity_bool',
    'descriptor_review','parent_identity','same_calibration_inode','generated_tokens','missing_mapping',
    'wrong_count','count_bool','unknown_length','length_count','overlap_mismatch','prefill_bool'])
def test_malformed_public_validation_metadata_rejects(change,monkeypatch):
    data,frozen=public_fixture();external=input_gate.inspect(data)
    worker=json.loads(data['public/tokenizer_worker_report.json']);review=json.loads(data['public/tokenizer_root_review.json'])
    row=worker['private_outputs']['validation'];counts=review['counts_by_length']
    if change=='descriptor_bool_bytes':row['bytes']=True
    elif change=='descriptor_extra':row['path']='/tmp/other'
    elif change=='descriptor_mode':row['mode']='0644'
    elif change=='descriptor_identity_bool':row['identity'][0]=True
    elif change=='descriptor_review':review['private_outputs']['validation']['sha256']='0'*64
    elif change=='parent_identity':review['private_root_identity']=[0,0]
    elif change=='same_calibration_inode':
        row['identity']=external['calibration']['identity'];review['private_outputs']['validation']['identity']=list(row['identity'])
    elif change=='generated_tokens':review['generated_decode_contexts']=True
    elif change=='missing_mapping':review['all_five_original_inputs_and_four_tokenizer_assets_reauthenticated']=False
    elif change=='wrong_count':counts['validation_workload_entries']=1087
    elif change=='count_bool':counts['frozen_validation_seed_entries']=True
    elif change=='unknown_length':counts['validation_prefills']['33']=counts['validation_prefills']['32']
    elif change=='length_count':counts['validation_prefills']['1']['entries']=31
    elif change=='overlap_mismatch':worker['overlap']['passed']=False
    elif change=='prefill_bool':review['validation_prefills']=True
    if change!='overlap_mismatch':worker['overlap']=copy.deepcopy(counts)
    data['public/tokenizer_worker_report.json']=json_bytes(worker);data['public/tokenizer_root_review.json']=json_bytes(review)
    # Exercise validation-specific checks independently of the unchanged producer
    # digest gate. The preceding test proves damaged bytes fail that real gate.
    monkeypatch.setattr(input_gate,'inspect',lambda blobs:copy.deepcopy(external))
    with pytest.raises(ValueError):gate.inspect_validation(data,frozen)


def synthetic_reader(tmp_path,monkeypatch):
    root=tmp_path/'synthetic';root.mkdir(mode=0o700);root.chmod(0o700)
    path=root/'validation_inputs.json';path.write_bytes(b'{"synthetic_validation":true}');path.chmod(0o600)
    info=path.stat();parent=root.stat();d=dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        bytes=info.st_size,identity=[info.st_dev,info.st_ino],parent_identity=[parent.st_dev,parent.st_ino],mode='0600',parent_mode='0700')
    monkeypatch.setattr(gate,'inspect_validation',lambda *a:copy.deepcopy(d))
    return path,d,gate.ValidationReader({},None)


def test_inherited_read_and_recheck_only_selected_synthetic_validation(tmp_path,monkeypatch):
    path,d,reader=synthetic_reader(tmp_path,monkeypatch)
    raw=reader(path,d['sha256'],limit=d['bytes']);assert raw==b'{"synthetic_validation":true}'
    reader.recheck();assert reader.loaded
    for wrong in (path.parent/'calibration_inputs.json',path.parent/'model.json'):
        with pytest.raises(PermissionError):reader(wrong,d['sha256'])
    with pytest.raises(PermissionError):reader(path,'0'*64)
    path.write_bytes(b'changed');path.chmod(0o600)
    with pytest.raises(ValueError):reader.recheck()


@pytest.mark.parametrize('change',['file','parent','symlink','mode'])
def test_synthetic_ownership_changes_reject_before_body(tmp_path,monkeypatch,change):
    path,d,reader=synthetic_reader(tmp_path,monkeypatch)
    if change=='mode':path.chmod(0o644)
    elif change=='symlink':
        moved=path.with_name('old');path.rename(moved);path.symlink_to(moved)
    elif change=='file':
        path.rename(path.with_name('old'));path.write_bytes(b'{}');path.chmod(0o600)
    else:
        path.parent.rename(path.parent.with_name('old'));path.parent.mkdir(mode=0o700);path.write_bytes(b'{}');path.chmod(0o600)
    monkeypatch.setattr(input_gate,'read',lambda *a,**k:pytest.fail('body before identity authentication'))
    with pytest.raises(ValueError):reader(path,d['sha256'],limit=d['bytes'])
