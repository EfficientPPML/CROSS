"""Actual process paths with synthetic boundaries; no external bodies."""
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
import sys
import pytest
import heldout_process as p
from test_input_gate import blobs as input_blobs
from test_freeze_admission import receipt,admit


def data():
    b=input_blobs();b['checker_protected_paths.json']=(Path(__file__).parent/'checker_protected_paths.json').read_bytes();b['heldout_protected_paths.json']=(Path(__file__).parent/'heldout_protected_paths.json').read_bytes();return b


def args(tmp_path,mode='heldout-worker'):
    return SimpleNamespace(mode=mode,output=str(tmp_path/'public'/'worker'),private_output=str(tmp_path/'private'),manifest=str(tmp_path/'manifest.json'),manifest_sha256='a'*64,grant=None,grant_sha256=None)


def binding(mode='heldout'):
    frozen=admit(receipt());return SimpleNamespace(frozen=frozen,mode=mode,manifest_sha256=frozen.manifest_sha256,
        runtime_policy=dict(cores=[108,109,110,111]),validation_descriptor=dict(path='/synthetic/validation_inputs.json'))


def terminal(b,a,expected,passed=True):
    n=1088 if b.mode=='heldout'else 1;count=1120 if n==1088 else 2
    row=dict(schema='qwen-heldout-workflow-worker-v1',workload_mode=b.mode,passed=passed,complete=True,cleanup_completed=True,
        signal_restoration_completed=True,source_files_unchanged=True,terminal_after_body_cleanup_and_signal_restoration_attempts=True,
        acceptance_requires_independent_exit0_reap_and_exact_report_hash=True,public_proofs_reauthenticated=True,
        private_directory_handle_closed=True,private_outputs_retained=True,external_inputs_never_removed=True,
        model_asset_postchecks_completed=True,model_cleanup_completed=True,native_capture_cleanup_completed=True,
        ledger_complete=True,selection_permanently_closed=True,audit_denials=[],source_manifest_sha256=a.manifest_sha256,
        source_hashes_start=expected,source_hashes_end=expected,manifest_sha256=b.manifest_sha256,freeze_receipt_sha256=b.frozen.receipt_sha256,
        grant_sha256=a.grant_sha256,expected_entries=n,retained_entries=n,candidate_ordinal=1,revision_eligible_ledger=False,
        coefficient_selection_performed=False,encrypted_execution=False,tokenizer_execution=False,validation_inputs_read=b.mode=='heldout',
        validation_reauthenticated=b.mode=='heldout',validation_read_attempted=b.mode=='heldout',validation_input_authenticated=b.mode=='heldout',
        validation_read_status='confirmed'if b.mode=='heldout'else'not_started',contains_tokens_logits_or_failure_text=False,model_loaded=True,
        complete_measured_context_coverage=passed,trajectories_complete=passed,all_length_invariance=True,
        native_forward_started=count,native_forward_completed=count,phase_counts=dict(native=n,exact=n,candidate=n))
    return row


@pytest.mark.parametrize('mode',['heldout','row0'])
def test_both_complete_outcomes_remain_no_feedback(tmp_path,mode):
    a=args(tmp_path,mode+'-worker');b=binding(mode);ex={'synthetic':'e'*64}
    for passed in (True,False):
        row=terminal(b,a,ex,passed);assert p.accept_worker(row,0 if passed else 1,ex,a,b)is row
        assert not row['revision_eligible_ledger']


@pytest.mark.parametrize('name,value',[('cleanup_completed',False),('signal_restoration_completed',False),('public_proofs_reauthenticated',False),
    ('private_directory_handle_closed',False),('selection_permanently_closed',False),('audit_denials',['denial']),('source_hashes_end',{}),
    ('manifest_sha256','0'*64),('freeze_receipt_sha256','0'*64),('retained_entries',1087),('candidate_ordinal',True),
    ('revision_eligible_ledger',True),('coefficient_selection_performed',True),('validation_reauthenticated',False),
    ('native_forward_started',1119),('native_forward_completed',True),('phase_counts',dict(native=1088,exact=1088,candidate=1)),
    ('candidate_validation_admissible',True),('failed_attempt_terminal_candidate',True)])
def test_worker_terminal_rejects_provenance_counter_or_feedback(tmp_path,name,value):
    a=args(tmp_path);b=binding();ex={'synthetic':'e'*64};row=terminal(b,a,ex);row[name]=value
    with pytest.raises(ValueError):p.accept_worker(row,0,ex,a,b)


def test_admission_denial_precedes_output_or_runtime(tmp_path,monkeypatch):
    calls=[]
    def deny(*a):calls.append('auth');raise PermissionError('no grant')
    monkeypatch.setattr(p,'admit',deny);monkeypatch.setattr(p,'Output',lambda *a:pytest.fail('created output'))
    with pytest.raises(PermissionError):p.worker(args(tmp_path),{},data(),{},tmp_path/'source')
    assert calls==['auth']


def test_actual_no_grant_denies_without_public_or_private_read(tmp_path,monkeypatch):
    a=args(tmp_path);monkeypatch.setattr(p,'read',lambda *a,**k:pytest.fail('read without grant'))
    # The authorization module import is a source helper only.
    monkeypatch.setitem(sys.modules,'heldout_authorization',SimpleNamespace())
    with pytest.raises(PermissionError):p.admit(a,data(),tmp_path/'source')
    assert not Path(a.output).exists()


@pytest.mark.parametrize('target',['model','calibration','protected','source','own'])
def test_public_role_cannot_open_body_or_owned_tree(tmp_path,monkeypatch,target):
    b=data();a=args(tmp_path);a.grant=str(tmp_path/'grant.json');a.grant_sha256='f'*64
    ext=p.input_gate.inspect(b);root=tmp_path/'source'
    path={'model':ext['model_root']+'/config.json','calibration':ext['calibration']['path'],'protected':ext['protected_paths'][0]+'/secret.json',
          'source':str(root/'fake.json'),'own':a.private_output+'/ledger.json'}[target]
    monkeypatch.setitem(sys.modules,'heldout_authorization',SimpleNamespace(public_requests=lambda raw:{'freeze':dict(path=path,sha256='d'*64,bytes=2)}))
    calls=[]
    def read(path,*a,**kw):calls.append(str(path));return b'{}'
    monkeypatch.setattr(p,'read',read)
    with pytest.raises(ValueError,match='Public evidence'):p.admit(a,b,root)
    assert calls==[a.grant]


def worker_fixture(tmp_path,monkeypatch,mode='heldout',body=None,close_error=None,proof_error=None):
    a=args(tmp_path,mode+'-worker');b=binding(mode);events=[];reports=[];denials=[]
    def recheck():
        events.append('proof_recheck')
        if proof_error:raise proof_error
    monkeypatch.setattr(p,'admit',lambda *a:(b,recheck))
    monkeypatch.setattr(p,'install_audit',lambda *a,**k:denials)
    monkeypatch.setattr(p,'dependencies',lambda b:{})
    monkeypatch.setattr(p,'enable_model_imports',lambda:events.append('imports_allowed'))
    class Out:
        def __init__(self,path):self.path=path;self.owner=(1,2);events.append('create_private'if path==a.private_output else'create_public')
        @classmethod
        def reopen(cls,path,owner):events.append('reopen');return cls(path)
        def close(self):
            events.append('private_close'if self.path==a.private_output else'public_close')
            if self.path==a.private_output and close_error:raise close_error
        def json(self,name,row):reports.append(dict(row));events.append('publish')
    monkeypatch.setattr(p,'Output',Out);monkeypatch.setattr(p.life,'Output',Out)
    @contextmanager
    def signals(state=None,shield=False):
        if state is not None:state['restored']=False
        try:yield
        finally:
            if state is not None:state['restored']=True
    monkeypatch.setattr(p.life,'signals',signals);monkeypatch.setattr(p.life,'source_end',lambda *a:events.append('source_end')or {})
    class Reader:
        loaded=False
        def __init__(self,*a):events.append('reader_construct')
        def __call__(self,*a,**k):self.loaded=True;events.append('reader_call');return b'synthetic'
        def recheck(self):events.append('reader_recheck')
    import heldout_input_gate
    monkeypatch.setattr(heldout_input_gate,'ValidationReader',Reader)
    def execute(blobs,authorization,reader,private,progress):
        events.append('execute');assert authorization is b and (reader is None)is(mode=='row0')
        if reader is not None:assert reader('synthetic','a'*64)==b'synthetic'
        if body:raise body
        progress(dict(stage='model_loaded',model_loaded=True));calls=1120 if mode=='heldout'else 2
        for i in range(calls):
            progress(dict(stage='native_forward_started',native_forward_started=i+1));progress(dict(stage='native_forward_completed',native_forward_completed=i+1))
        report=terminal(b,a,{})
        forbidden=('schema','cleanup_completed','signal_restoration_completed','source_files_unchanged','terminal_after_body_cleanup_and_signal_restoration_attempts',
        'acceptance_requires_independent_exit0_reap_and_exact_report_hash','public_proofs_reauthenticated','private_directory_handle_closed',
        'private_outputs_retained','external_inputs_never_removed','audit_denials','source_manifest_sha256','source_hashes_start','source_hashes_end','grant_sha256','validation_reauthenticated','validation_read_attempted','validation_input_authenticated','validation_read_status')
        for k in forbidden:report.pop(k,None)
        return report
    monkeypatch.setitem(sys.modules,'heldout_runtime',SimpleNamespace(execute_heldout=execute))
    return a,b,events,reports,denials


@pytest.mark.parametrize('mode',['heldout','row0'])
def test_actual_worker_mocked_lifecycle_reports_separate_mode(tmp_path,monkeypatch,mode):
    a,b,e,reports,_=worker_fixture(tmp_path,monkeypatch,mode)
    code=p.worker(a,{},data(),{},tmp_path/'source');assert code==0
    assert e.index('execute')<e.index('proof_recheck')<e.index('private_close')<e.index('publish')
    assert ('reader_construct'in e)is(mode=='heldout')and ('reader_recheck'in e)is(mode=='heldout')
    assert p.accept_worker(reports[-1],code,{},a,b)is reports[-1]


@pytest.mark.parametrize('body',[ValueError('body'),KeyboardInterrupt('body'),SystemExit(2)])
def test_worker_attempts_all_cleanup_preserves_real_body(tmp_path,monkeypatch,body):
    a,b,e,reports,_=worker_fixture(tmp_path,monkeypatch,'row0',body=body,close_error=KeyboardInterrupt('close'),proof_error=OSError('proof'))
    with pytest.raises(type(body))as got:p.worker(a,{},data(),{},tmp_path/'source')
    assert got.value is body and all(k in e for k in('proof_recheck','private_close','source_end','public_close','publish'))
    assert reports[-1]['passed']is False and reports[-1]['cleanup_completed']is False


def test_swallowed_audit_denial_vetoes_success(tmp_path,monkeypatch):
    a,b,e,reports,denials=worker_fixture(tmp_path,monkeypatch,'row0');denials.append('caught forbidden access')
    with pytest.raises(PermissionError):p.worker(a,{},data(),{},tmp_path/'source')
    assert reports[-1]['passed']is False and e.count('private_close')==1


@pytest.mark.parametrize('mode,passed',[('heldout',True),('heldout',False),('row0',True),('row0',False)])
def test_actual_collector_pins_child_command_and_reports(tmp_path,monkeypatch,mode,passed):
    a=args(tmp_path,'collect-'+mode);a.output=str(tmp_path/'public');a.grant=str(tmp_path/'grant.json');a.grant_sha256='9'*64
    b=binding(mode);root=tmp_path/'source';root.mkdir();expected={'heldout_entry.py':'d'*64};blobs={'heldout_entry.py':b'# synthetic'};raw=b'{}';events=[]
    monkeypatch.setattr(p,'validate_paths',lambda *a:None);monkeypatch.setattr(p,'admit',lambda *a:(b,lambda:events.append('proof_recheck')))
    monkeypatch.setattr(p,'install_audit',lambda *a,**k:[]);monkeypatch.setattr(p,'dependencies',lambda b:{})
    monkeypatch.setattr(p,'source_end',lambda *a:expected);monkeypatch.setattr(p.life,'source_end',lambda *a:expected)
    @contextmanager
    def signals(state=None,shield=False):
        if state is not None:state['restored']=False
        try:yield
        finally:
            if state is not None:state['restored']=True
    monkeypatch.setattr(p.life,'signals',signals);monkeypatch.setattr(p,'group_absent',lambda pid:True)
    monkeypatch.setattr(p,'child_environment',lambda:{'synthetic':'true'})
    command=[]
    class Child:
        pid=123456;returncode=None
        def __init__(self,cmd,**kw):
            command.extend(cmd);assert kw['start_new_session']and kw['env']=={'synthetic':'true'}
            worker=Path(a.output)/'worker';worker.mkdir()
            row=terminal(b,a,expected,passed)
            (worker/'report.json').write_text(__import__('json').dumps(row))
        def wait(self):self.returncode=0 if passed else 1;return self.returncode
    monkeypatch.setattr(p.subprocess,'Popen',Child);monkeypatch.setattr(p,'retire',lambda child:events.append('retire'))
    code=p.collect(a,raw,expected,blobs,{},root)
    assert code==(0 if passed else 1)
    row=p.parse((Path(a.output)/'report.json').read_bytes())
    assert row['schema']=='qwen-heldout-workflow-parent-v1'and row['workload_mode']==mode and row['passed']is passed
    assert row['public_proofs_reauthenticated']and row['child_reaped']and row['child_group_absent']
    assert row['source_hashes_end']==expected and row['source_archive']['sha256']
    assert command[:3]==[sys.executable,'-I','-B']and command[3].endswith('/execution_source/heldout_entry.py')
    assert command[command.index('--mode')+1]==mode+'-worker'
    assert command[command.index('--grant-sha256')+1]==a.grant_sha256 and command[command.index('--manifest-sha256')+1]==a.manifest_sha256
    assert events==['retire','proof_recheck']


def test_lifecycle_helpers_are_borrowed_exactly():
    for name in('supervise','source_end','retire','group_absent','dependencies','child_environment','enable_model_imports'):
        assert getattr(p,name)is getattr(p.life,name)


@pytest.mark.parametrize('event',['os.fork','os.forkpty','os.posix_spawn','subprocess.Popen','os.system','socket.connect'])
def test_actual_worker_audit_denies_process_or_network(tmp_path,monkeypatch,event):
    hooks=[];monkeypatch.setattr(p.sys,'addaudithook',hooks.append)
    denials=p.install_audit(data(),tmp_path/'source',binding=binding('row0'))
    with pytest.raises(PermissionError):hooks[0](event,())
    assert len(denials)==1


def test_audit_distinguishes_public_ancestor_directory_from_protected_body(tmp_path,monkeypatch):
    hooks=[];monkeypatch.setattr(p.sys,'addaudithook',hooks.append);b=data();external=p.input_gate.inspect(b)
    denials=p.install_audit(b,tmp_path/'source')
    parent=str(Path(external['calibration']['path']).parent.parent)
    hooks[0]('open',(parent,'r',p.os.O_RDONLY|p.os.O_DIRECTORY))
    assert denials==[]
    with pytest.raises(PermissionError):hooks[0]('open',(external['calibration']['path'],'r',p.os.O_RDONLY))
    assert len(denials)==1


@pytest.mark.parametrize('failure',[ValueError('late body'),KeyboardInterrupt('late body'),SystemExit(4)])
def test_confirmed_validation_read_survives_later_runtime_failure(tmp_path,monkeypatch,failure):
    a,b,e,reports,_=worker_fixture(tmp_path,monkeypatch,'heldout')
    import heldout_input_gate
    class Reader:
        def __init__(self,*args):self.loaded=False
        def __call__(self,*args,**kw):self.loaded=True;return b'synthetic'
        def recheck(self):e.append('reader_recheck')
    monkeypatch.setattr(heldout_input_gate,'ValidationReader',Reader)
    def execute(blobs,binding,reader,*args):assert reader('synthetic','a'*64)==b'synthetic';raise failure
    monkeypatch.setitem(sys.modules,'heldout_runtime',SimpleNamespace(execute_heldout=execute))
    with pytest.raises(type(failure))as got:p.worker(a,{},data(),{},tmp_path/'source')
    assert got.value is failure
    row=reports[-1];assert row['validation_inputs_read']is True and row['validation_read_attempted']is True
    assert row['validation_input_authenticated']is True and row['validation_read_status']=='confirmed'and row['validation_reauthenticated']is True
    assert row['passed']is False


@pytest.mark.parametrize('confirmed',[False,True])
def test_reader_exception_never_claims_no_read(tmp_path,monkeypatch,confirmed):
    error=OSError('synthetic hash or cleanup failure');a,b,e,reports,_=worker_fixture(tmp_path,monkeypatch,'heldout')
    import heldout_input_gate
    class Reader:
        def __init__(self,*args):self.loaded=False
        def __call__(self,*args,**kw):self.loaded=confirmed;raise error
        def recheck(self):e.append('reader_recheck')
    monkeypatch.setattr(heldout_input_gate,'ValidationReader',Reader)
    def execute(blobs,binding,reader,*args):reader('synthetic','a'*64)
    monkeypatch.setitem(sys.modules,'heldout_runtime',SimpleNamespace(execute_heldout=execute))
    with pytest.raises(OSError)as got:p.worker(a,{},data(),{},tmp_path/'source')
    assert got.value is error
    row=reports[-1];assert row['validation_read_attempted']is True
    assert row['validation_inputs_read']is(True if confirmed else None)
    assert row['validation_input_authenticated']is confirmed
    assert row['validation_read_status']==('confirmed'if confirmed else'attempted')


@pytest.mark.parametrize('name',['private','public'])
def test_candidate_prior_outcome_trees_blocked_without_stat_or_read(tmp_path,monkeypatch,name):
    b=data();guard=p.parse(b['heldout_protected_paths.json'])['paths'][0 if name=='private'else 1];a=args(tmp_path)
    a.output=guard+'/injected-report'
    with pytest.raises(ValueError):p.validate_paths(a,b,tmp_path/'source')
    hooks=[];monkeypatch.setattr(p.sys,'addaudithook',hooks.append);p.install_audit(b,tmp_path/'source')
    with pytest.raises(PermissionError):hooks[0]('open',(guard+'/report.json','r',p.os.O_RDONLY))


def test_successful_tracked_read_survives_failed_final_reauthentication(tmp_path,monkeypatch):
    a,b,e,reports,_=worker_fixture(tmp_path,monkeypatch,'heldout');failure=OSError('final recheck')
    import heldout_input_gate
    class Reader:
        loaded=False
        def __init__(self,*a):pass
        def __call__(self,*a,**kw):self.loaded=True;return b'synthetic'
        def recheck(self):raise failure
    monkeypatch.setattr(heldout_input_gate,'ValidationReader',Reader)
    with pytest.raises(OSError)as got:p.worker(a,{},data(),{},tmp_path/'source')
    assert got.value is failure
    row=reports[-1];assert row['validation_read_attempted']and row['validation_inputs_read']and row['validation_input_authenticated']
    assert row['validation_read_status']=='confirmed'and row['validation_reauthenticated']is False and row['passed']is False


@pytest.mark.parametrize('key',['validation_read_attempted','validation_input_authenticated','validation_read_status','validation_reauthenticated','public_proofs_reauthenticated','private_directory_handle_closed'])
def test_runtime_cannot_overwrite_process_read_or_cleanup_authority(tmp_path,monkeypatch,key):
    a,b,e,reports,_=worker_fixture(tmp_path,monkeypatch,'row0');original=sys.modules['heldout_runtime'].execute_heldout
    def execute(*args):
        result=original(*args);result[key]=False;return result
    monkeypatch.setitem(sys.modules,'heldout_runtime',SimpleNamespace(execute_heldout=execute))
    with pytest.raises(ValueError,match='authority'):p.worker(a,{},data(),{},tmp_path/'source')
    assert reports[-1]['passed']is False


@pytest.mark.parametrize('started,completed',[(1040,1040),(1072,32)])
def test_complete_known_comparison_failure_publishes_nonzero_scientific_result(tmp_path,monkeypatch,started,completed):
    a,b,e,reports,_=worker_fixture(tmp_path,monkeypatch,'heldout')
    def execute(blobs,binding,reader,private,progress):
        reader('synthetic','a'*64);progress(dict(stage='model_loaded',model_loaded=True))
        for i in range(started):
            progress(dict(stage='native_forward_started',native_forward_started=i+1))
            if i<completed:progress(dict(stage='native_forward_completed',native_forward_completed=i+1))
        return dict(passed=False,complete=True,ledger_complete=True,manifest_sha256=b.manifest_sha256,
            freeze_receipt_sha256=b.frozen.receipt_sha256,workload_mode='heldout',selection_permanently_closed=True,
            revision_eligible_ledger=False,model_loaded=True,native_forward_started=started,native_forward_completed=completed,
            native_forward_accounting=dict(expected=1072,started=started,completed=completed,passed=False),
            validation_inputs_read=True,expected_entries=1088,retained_entries=1088,candidate_ordinal=1,
            coefficient_selection_performed=False,encrypted_execution=False,tokenizer_execution=False,contains_tokens_logits_or_failure_text=False,
            phase_counts=dict(native=1040,exact=0,candidate=0),all_length_invariance=False,complete_measured_context_coverage=False,
            model_asset_postchecks_completed=True,model_cleanup_completed=True,native_capture_cleanup_completed=True,
            by_kind={kind:dict(comparison_invalid=count)for kind,count in [('prefill',1024),('teacher',8),('free',8)]})
    monkeypatch.setitem(sys.modules,'heldout_runtime',SimpleNamespace(execute_heldout=execute))
    assert p.worker(a,{},data(),{},tmp_path/'source')==1
    row=reports[-1];assert 'error_type'not in row and row['cleanup_completed']and row['signal_restoration_completed']
    assert row['passed']is False and row['revision_eligible_ledger']is False and row['validation_read_status']=='confirmed'
    assert p.accept_worker(row,1,{},a,b)is row


def test_declared_private_predecessor_is_rejected_lexically_before_resolution(tmp_path,monkeypatch):
    b=data();names=p.parse(b['heldout_protected_paths.json'])['paths'];original=Path.resolve
    def resolve(value,*a,**k):
        assert not any(str(value)==n or str(value).startswith(n+'/')for n in names),'private predecessor resolution attempted'
        return original(value,*a,**k)
    monkeypatch.setattr(Path,'resolve',resolve)
    for name in names:
        a=args(tmp_path);a.output=name+'/should-not-stat'
        with pytest.raises(ValueError):p.validate_paths(a,b,tmp_path/'source')
    hooks=[];monkeypatch.setattr(p.sys,'addaudithook',hooks.append);p.install_audit(b,tmp_path/'source')
    for name in names:
        with pytest.raises(PermissionError):hooks[0]('open',(name+'/report.json','r',0))
