"""Public tokenizer/freeze binding and borrowed validation-only reader.

Inspection and construction open no external path. Body access is inherited
unchanged from input_gate.Reader and requires the caller's separate actual grant.
The returned descriptor is metadata, never an execution authorization.
"""
from pathlib import Path
import input_gate
from freeze_admission import require_frozen, parse


def _integer(value,expected):
    if type(value)is not int or value!=expected:
        raise ValueError('Exact validation producer count required')


def inspect_validation(blobs,frozen):
    """Authenticate already source-bound PUBLIC bytes, without stat/read."""
    external=input_gate.inspect(blobs)
    admitted=require_frozen(frozen)
    receipt=parse(admitted.receipt_bytes)
    producer=external['producer']
    if (receipt['tokenizer_report_sha256']!=producer['tokenizer_report_sha256'] or
        receipt['tokenizer_review_sha256']!=producer['tokenizer_root_review_sha256'] or
        admitted.model_pins_sha256!=input_gate.sha(blobs['public/model_pins.json'])):
        raise ValueError('Freeze and tokenizer/model public bindings differ')
    worker=parse(blobs['public/tokenizer_worker_report.json'])
    review=parse(blobs['public/tokenizer_root_review.json'])
    grant=parse(blobs['public/tokenizer_grant.json'])
    value=worker.get('private_outputs',{}).get('validation')
    if type(value)is not dict or set(value)!={'bytes','identity','mode','sha256'}:
        raise ValueError('Exact public validation descriptor required')
    if (not input_gate.is_digest(value['sha256']) or value['sha256']!=admitted.validation_input_sha256 or
        type(value['bytes'])is not int or not 0<value['bytes']<=4<<20 or value['mode']!='0600'):
        raise ValueError('Frozen validation digest/size/permissions differ')
    owner=value['identity'];parent=review.get('private_root_identity')
    for identity in (owner,parent):
        if type(identity)is not list or len(identity)!=2 or any(type(n)is not int or n<0 for n in identity):
            raise ValueError('Typed validation file/directory identity required')
    cal=external['calibration'];root=Path(cal['path']).parent
    if (not input_gate.typed_equal(review.get('private_outputs',{}).get('validation'),value) or
        not input_gate.typed_equal(parent,cal['parent_identity']) or
        input_gate.typed_equal(owner,cal['identity']) or grant.get('private_output')!=str(root)):
        raise ValueError('Independent validation output/root binding differs')
    if (review.get('all_five_original_inputs_and_four_tokenizer_assets_reauthenticated')is not True or
        review.get('generated_decode_contexts')is not False or worker.get('generated_decode_contexts')is not False):
        raise ValueError('Completed tokenizer-only mapping review required')
    for name,expected in (('validation_prefills',1024),('validation_decode_seeds',8),
                          ('append_only_decode_family_prefix_intersections',0),('known_token_context_intersections',0)):
        _integer(review.get(name),expected)
    counts=review.get('counts_by_length')
    if type(counts)is not dict or not input_gate.typed_equal(counts,worker.get('overlap')):
        raise ValueError('Tokenizer/independent mapping counts differ')
    if counts.get('passed')is not True or counts.get('row0_token0_excluded')is not True or counts.get('future_decode_tokens_generated')is not False:
        raise ValueError('Validation prefix mapping prerequisites differ')
    _integer(counts.get('validation_workload_entries'),1088)
    _integer(counts.get('frozen_validation_seed_entries'),8)
    rows=counts.get('validation_prefills')
    if type(rows)is not dict or set(rows)!=set(map(str,range(1,33))):
        raise ValueError('All32 validation prefix lengths required')
    for row in rows.values():
        if type(row)is not dict or set(row)!={'entries','unique'}:
            raise ValueError('Exact validation length summary required')
        _integer(row['entries'],32)
        if type(row['unique'])is not int or not 1<=row['unique']<=32:
            raise ValueError('Typed bounded unique prefix count required')
    return dict(path=str(root/'validation_inputs.json'),sha256=value['sha256'],bytes=value['bytes'],
                identity=list(owner),parent_identity=list(parent),mode='0600',parent_mode='0700')


class ValidationReader(input_gate.Reader):
    """Same descriptor ownership/read/recheck implementation, validation scope."""
    def __init__(self,blobs,frozen):
        self.description=inspect_validation(blobs,frozen)
        self.loaded=False
        self.start=None
