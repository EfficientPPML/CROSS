"""Actual execution function with synthetic model/asset boundaries only."""
from types import SimpleNamespace
import sys,json,os
import pytest
import checker_runtime as old
import heldout_runtime as r
from strict_metrics import StructuralFailure
from test_checker_runtime import execute_fixture as original_fixture,manifest
from test_heldout_dispatch import inputs
from test_freeze_admission import receipt,admit


def fixture(monkeypatch,mode='heldout',*,body_error=None,asset_error=None,gc_error=None,cleanup=True,call_count=None):
    _,_,sink,progress,events=original_fixture(monkeypatch,body_error=body_error,asset_error=asset_error,gc_error=gc_error,cleanup=cleanup)
    raw=r.canonical(inputs());fr=receipt(validation_sha=r.sha(raw));m=r.canonical(manifest())
    fr['manifest_sha256']=fr['attempts'][0]['manifest_sha256']=r.sha(m);frozen=admit(fr)
    descriptor=dict(path='/synthetic/validation_inputs.json',sha256=r.sha(raw),bytes=len(raw))
    binding=SimpleNamespace(frozen=frozen,mode=mode,manifest_bytes=m,manifest_sha256=r.sha(m),runtime_policy=r.runtime_policy(),validation_descriptor=descriptor)
    blobs={'heldout_runtime_policy.json':r.canonical(r.runtime_policy()),'dependencies.json':b'{}'}
    def auth(value,blobs):
        events.append('authorization');assert value is binding;return value
    monkeypatch.setitem(sys.modules,'heldout_authorization',SimpleNamespace(require_authorized=auth))
    import heldout_input_gate
    monkeypatch.setattr(heldout_input_gate,'inspect_validation',lambda b,f:descriptor)
    monkeypatch.setattr(os,'sched_getaffinity',lambda pid:{108,109,110,111})
    monkeypatch.setattr(r,'NativeCaptureWithInputs',old.NativeCaptureWithInputs)
    expected=1088 if mode=='heldout'else 1;calls=(1120 if mode=='heldout'else 2)if call_count is None else call_count
    class Adapter:
        def __init__(self,**kwargs):
            self.native=kwargs['native_forward'];assert kwargs['frozen']is frozen and kwargs['mode']==mode
        def run(self,body):
            events.append('dispatch');assert body==(raw if mode=='heldout'else None)
            if body_error is not None:raise body_error
            for _ in range(calls):assert self.native((0,)).shape==(1,151936)
            return dict(passed=True,revision_eligible_ledger=False,phase_counts=dict(native=expected,exact=expected,candidate=expected),native_invariance_by_length={str(i):True for i in(range(1,33)if mode=='heldout'else(1,))})
    monkeypatch.setattr(r,'HeldoutAdapters',Adapter)
    def reader(path,pin,*,limit):events.append('validation_read');assert (path,pin,limit)==(descriptor['path'],descriptor['sha256'],descriptor['bytes']);return raw
    return blobs,binding,(reader if mode=='heldout'else None),sink,progress,events


@pytest.mark.parametrize('mode,count',[('heldout',1120),('row0',2)])
def test_actual_lifecycle_order_counter_asset_postchecks_and_cleanup(monkeypatch,mode,count):
    b,a,reader,sink,p,e=fixture(monkeypatch,mode)
    result=r.execute_heldout(b,a,reader,sink,p.append)
    assert e.index('authorization')<e.index('environment')<e.index('backend_before')<e.index('assets_enter')<e.index('construct')
    if mode=='heldout':assert e.index('backend_before')<e.index('validation_read')<e.index('assets_enter')
    else:assert 'validation_read'not in e
    assert e[-4:]==['config_post','generation_post','checkpoint_post','gc']
    assert result['native_forward_accounting']==dict(expected=count,started=count,completed=count,passed=True)
    assert result['model_cleanup_completed']and result['model_asset_postchecks_completed']and result['native_capture_cleanup_completed']
    assert result['selection_permanently_closed']and result['revision_eligible_ledger']is False
    assert p[-1]==dict(stage='native_forward_completed',native_forward_completed=count)


def test_no_authorization_precedes_every_body_or_backend_action(monkeypatch):
    calls=[]
    def deny(*args):calls.append('auth');raise PermissionError('no independent freeze/grant')
    monkeypatch.setitem(sys.modules,'heldout_authorization',SimpleNamespace(require_authorized=deny))
    def forbidden(*a,**k):pytest.fail('body touched')
    with pytest.raises(PermissionError):r.execute_heldout({},None,forbidden,SimpleNamespace(json=forbidden),forbidden)
    assert calls==['auth']


@pytest.mark.parametrize('key,value',[('schema','bad'),('cores',[108,109,110,True]),('torch_threads',True),('torch_interop_threads',1.),('heldout_entries',1087),('heldout_native_forwards',1119),('row0_entries',2),('row0_native_forwards',1),('coefficient_selection',True),('candidate_revision',True)])
def test_policy_invalid_before_body(monkeypatch,key,value):
    b,a,reader,sink,p,e=fixture(monkeypatch);v=json.loads(b['heldout_runtime_policy.json']);v[key]=value;b['heldout_runtime_policy.json']=r.canonical(v)
    with pytest.raises(StructuralFailure):r.execute_heldout(b,a,reader,sink,p.append)
    assert 'validation_read'not in e and 'construct'not in e


def test_row0_rejects_validation_reader_before_body(monkeypatch):
    b,a,_,sink,p,e=fixture(monkeypatch,'row0')
    with pytest.raises(StructuralFailure):r.execute_heldout(b,a,lambda *a:pytest.fail('read'),sink,p.append)
    assert 'construct'not in e


@pytest.mark.parametrize('failure',[ValueError('body'),KeyboardInterrupt('body'),SystemExit(7)])
def test_real_body_identity_survives_asset_and_gc_cleanup(monkeypatch,failure):
    b,a,reader,sink,p,e=fixture(monkeypatch,'row0',body_error=failure,asset_error=OSError('post'),gc_error=KeyboardInterrupt('gc'))
    with pytest.raises(type(failure))as got:r.execute_heldout(b,a,reader,sink,p.append)
    assert got.value is failure and e[-4:]==['config_post','generation_post','checkpoint_post','gc']and 'capture_exit'in e


def test_cleanup_cancellation_wins_ordinary_cleanup(monkeypatch):
    cancel=KeyboardInterrupt('gc');b,a,reader,sink,p,e=fixture(monkeypatch,'row0',asset_error=OSError('post'),gc_error=cancel)
    with pytest.raises(KeyboardInterrupt)as got:r.execute_heldout(b,a,reader,sink,p.append)
    assert got.value is cancel and e[-1]=='gc'


@pytest.mark.parametrize('fault',['native_count','capture_cleanup'])
def test_bad_accounting_or_hook_retirement_rejects(monkeypatch,fault):
    b,a,reader,sink,p,e=fixture(monkeypatch,'row0',call_count=1 if fault=='native_count'else 2,cleanup=fault!='capture_cleanup')
    with pytest.raises(StructuralFailure):r.execute_heldout(b,a,reader,sink,p.append)
    assert e[-4:]==['config_post','generation_post','checkpoint_post','gc']


@pytest.mark.parametrize('problem',['bare_nonfinite','captured_hook_nonfinite'])
def test_full_heldout_known_native_invalid_retains_scientific_failure_and_actual_counts(monkeypatch,problem):
    import numpy as np
    from test_checker_runtime import Capture
    from heldout_adapters import HeldoutAdapters
    from native_capture import NativeNonfiniteOutput
    b,a,reader,sink,progress,events=fixture(monkeypatch,'heldout')
    owners=[]
    class CaptureOwner(Capture):
        def __init__(self,model):self.active=False;self.cleanup_completed=False;owners.append(self)
        def __enter__(self):return self
        def __exit__(self,*args):self.cleanup_completed=True
    monkeypatch.setattr(r,'NativeCaptureWithInputs',CaptureOwner);monkeypatch.setattr(r,'HeldoutAdapters',HeldoutAdapters)
    loader=sys.modules['transformers'].Qwen3ForCausalLM;original=loader.from_pretrained
    class Tensor:
        def __getitem__(self,key):return self
        def detach(self):return self
        def numpy(self):return self
        def astype(self,dtype):return np.broadcast_to(np.float64(np.nan if problem=='bare_nonfinite'else 1.),(1,151936))
    def load(*args,**kwargs):
        model,info=original(*args,**kwargs)
        def forward(self,**kwargs):
            if problem=='captured_hook_nonfinite'and owners[0].active:raise NativeNonfiniteOutput('synthetic hook nonfinite')
            return SimpleNamespace(logits=Tensor())
        monkeypatch.setattr(type(model),'__call__',forward)
        return model,info
    monkeypatch.setattr(loader,'from_pretrained',load)
    report=r.execute_heldout(b,a,reader,sink,progress.append)
    assert report['complete']and report['ledger_complete']and report['retained_entries']==1088
    assert report['passed']is False and report['revision_eligible_ledger']is False
    assert report['by_kind']['prefill']['comparison_invalid']==1024
    assert report['by_kind']['teacher']['comparison_invalid']==report['by_kind']['free']['comparison_invalid']==8
    assert report['by_kind']['teacher']['unmeasured']==report['by_kind']['free']['unmeasured']==24
    expected=(1040,1040)if problem=='bare_nonfinite'else(1072,32)
    assert (report['native_forward_started'],report['native_forward_completed'])==expected
    assert report['native_forward_accounting']==dict(expected=1072,started=expected[0],completed=expected[1],passed=False)
    assert report['model_asset_postchecks_completed']and report['native_capture_cleanup_completed']and report['model_cleanup_completed']
    assert len(sink.rows['ledger.json']['records'])==1088
    assert sum(row['stage']=='native_forward_started'for row in progress)==expected[0]
    assert sum(row['stage']=='native_forward_completed'for row in progress)==expected[1]
