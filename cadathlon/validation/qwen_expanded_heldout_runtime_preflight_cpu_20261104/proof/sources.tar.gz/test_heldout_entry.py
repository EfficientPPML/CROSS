"""Fresh real bootstrap with explicitly inert helpers; no actual data/backend."""
from pathlib import Path
import ast,hashlib,json,os,subprocess,sys
import pytest

ENTRY=Path(__file__).parent/'heldout_entry.py'


def required():
    tree=ast.parse(ENTRY.read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='authenticate')
    node=next(n for n in fn.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='required'for t in n.targets))
    return ast.literal_eval(node.value)


def prepared(tmp_path,mode='test-worker'):
    root=tmp_path/'source';root.mkdir();marker=tmp_path/'after-auth-marker'
    for name in required():
        path=root/name;path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text('{}'if path.suffix=='.json'else'# explicit inert helper\n')
    (root/'heldout_entry.py').write_bytes(ENTRY.read_bytes())
    (root/'heldout_process.py').write_text('from pathlib import Path\nPath('+repr(str(marker))+').write_text("source_authenticated")\ndef dispatch(*args):return 0\n')
    manifest=tmp_path/'manifest.json';manifest.write_text(json.dumps({p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in root.rglob('*')if p.is_file()},sort_keys=True))
    args=[str(root/'heldout_entry.py'),'--manifest',str(manifest),'--manifest-sha256',hashlib.sha256(manifest.read_bytes()).hexdigest(),'--mode',mode,'--output',str(tmp_path/'out')]
    return root,marker,manifest,args


def launch(args,wrapper=None):
    cmd=[sys.executable,'-I','-B',*(['-c',wrapper]if wrapper else args)]
    child=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    stdout,stderr=child.communicate()
    with pytest.raises(ProcessLookupError):os.killpg(child.pid,0)
    return child.returncode,stdout,stderr


@pytest.mark.parametrize('mode',['collect-heldout','heldout-worker','collect-row0','row0-worker','collect-preflight','test-worker','collect-import-smoke','import-smoke-worker'])
def test_all_cli_modes_authenticate_before_explicit_inert_helper(tmp_path,mode):
    root,marker,manifest,args=prepared(tmp_path,mode);code,_,error=launch(args)
    assert code==0 and marker.read_text()=='source_authenticated',error


@pytest.mark.parametrize('mode',['collect-heldout','heldout-worker','collect-row0','row0-worker'])
@pytest.mark.parametrize('origin',['file','spec','external_file_local_spec','local_file_external_spec'])
@pytest.mark.parametrize('link',[False,True])
def test_actual_cli_file_spec_unknown_alias_matrix(tmp_path,mode,origin,link):
    root,marker,manifest,args=prepared(tmp_path,mode);target=root/'heldout_authorization.py'
    if link:
        alias=tmp_path/'external-link';alias.symlink_to(target);target=alias
    assignments={'file':'module.__file__=value','spec':'module.__spec__=types.SimpleNamespace(origin=value)',
        'external_file_local_spec':'module.__file__="/outside/inert.py";module.__spec__=types.SimpleNamespace(origin=value)',
        'local_file_external_spec':'module.__file__=value;module.__spec__=types.SimpleNamespace(origin="/outside/inert.py")'}
    wrapper='import pathlib,types,sys,runpy\nmodule=types.ModuleType("unknown")\nvalue=pathlib.Path('+repr(str(target))+')\n'+assignments[origin]+'\nsys.modules["unknown"]=module\nsys.argv='+repr(args)+'\nrunpy.run_path('+repr(args[0])+',run_name="__main__")\n'
    code,_,error=launch(args,wrapper);assert code!=0 and not marker.exists(),error


@pytest.mark.parametrize('fault',['changed','missing','extra_py','pyc','so','symlink','digest'])
def test_source_mutations_reject_before_helper(tmp_path,fault):
    root,marker,manifest,args=prepared(tmp_path)
    if fault=='changed':(root/'heldout_authorization.py').write_text('raise RuntimeError("MUST_NOT_IMPORT")')
    elif fault=='missing':(root/'heldout_authorization.py').unlink()
    elif fault=='extra_py':(root/'platform.py').write_text('raise RuntimeError("MUST_NOT_IMPORT")')
    elif fault=='pyc':(root/'extra.pyc').write_bytes(b'no')
    elif fault=='so':(root/'extra.so').write_bytes(b'no')
    elif fault=='symlink':(root/'alias.py').symlink_to(root/'heldout_authorization.py')
    else:args[4]='0'*64
    code,_,_=launch(args);assert code!=0 and not marker.exists()


def test_source_bootstrap_body_identical_to_reviewed139_except_new_names():
    old=ast.parse((ENTRY.parent/'entry.py').read_text());new=ast.parse(ENTRY.read_text())
    olddefs={n.name:n for n in old.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    newdefs={n.name:n for n in new.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    for name in('bounded','parse','digest','source_limit','check_source_sizes','FrozenLoader','FrozenImports'):
        assert ast.dump(olddefs[name],include_attributes=False)==ast.dump(newdefs[name],include_attributes=False)
