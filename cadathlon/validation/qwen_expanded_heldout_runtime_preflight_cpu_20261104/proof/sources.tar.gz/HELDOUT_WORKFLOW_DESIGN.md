# Held-out1088 and separate row0 after the first complete calibration pass

This is a pure, synthetic-only preparation component. It opens no files and
imports no model, tokenizer, backend, checkpoint or evaluation framework. The
private `validation_inputs.json` has not been opened. The copied frozen23 public
protocol, tokenizer source schema, measured candidate dispatcher and numerical
six files are preserved as predecessor evidence. The numerical six are not yet
connected to a validation worker.

The public protocol gates remain exact:1024 prefills require922 top1 matches;
32 teacher decisions require29;8 full free sequences require6 complete matches.
Free-step agreement is reported only diagnostically. There is no additional
29/32 free-step gate or per-length hard gate. Every context must also complete
all421 operator,28 block and151936-logit checks, all113 normalization input
observations and the full frozen reciprocal/SiLU domain schedule. The unchanged
numeric limits are.05 operator/block nRMSE,.10 full-logit nRMSE,.01 denominator
floor, and exact/native.001 maxabs plus1e-5 nRMSE and identical top1.

`freeze_admission.authenticate(receipt_bytes, externally_pinned_sha256)` is a
proposed independent public freeze-attestation contract. It checks a complete
ordered history of at most3 distinct candidates: every earlier attempt must be
an independently verified complete scientific failure, the last must be the
first complete calibration PASS, and selection closes permanently. A failed
attempt can contain only causal unmeasured free suffixes; measured native/exact/
candidate counts agree, comparison failures are absent, all32 hook-invariance
checks pass, and native calls equal measured contexts+32. A passing attempt
requires all3200 measurements and3232 native calls. Source/assets, both process
exits/reaps/groups, cleanup, signal restoration, ordered ledger, and complete
metric/domain verification are explicit independent-attestation fields. The
receipt binds protocol, arithmetic/reference, model pins, tokenizer proof,
validation input hash, exact selected manifest and ordinal.

This attestation does not independently reconstruct the producer's source
archive or private metric journals. The future root verifier must do that and
pin the receipt digest externally. A Python `FrozenCandidate` object or caller-
supplied digest is not an authorization capability. The component deliberately
sets both execution-authorized fields false. No populated real freeze receipt,
actual calibration/selector result, or new candidate coefficients are used here.
Security's current candidate checker implements ordinal1 only; any actual
ordinal2/3 history needs its separate reviewed revision/budget successor before
it could appear in an authenticated freeze receipt.

`heldout_dispatch.run_validation(raw_validation_bytes, frozen=..., native=...,
exact=..., candidate=...)` verifies the exact frozen bytes before any callback.
It checks the tokenizer's1024 append-only prefixes in prompt-major S1..32 order,
32 natural token lengths, and8 S16 seeds from fixed prompt ordinals0,4,...,28.
Every predeclared entry remains, even where short prefixes repeat. The order is
1024 prefills,32 native-teacher decisions, then32 own-candidate-free decisions.
All three adapters receive the same actual prefix. Each candidate context must
independently look up original embeddings in the future runtime; native or exact
intermediates must never replace candidate values.

The dispatcher reuses the exact measured `Candidate`/`Record` types and checked
421/28/151936 coverage contract. Finite numerical failure still appends the
candidate's actual argmax for free continuation. A candidate-only domain stop
makes that free suffix unmeasured; native-valid teacher continuation still
appends the native argmax. Native/exact comparison failure stops only its
dependent chain. Schema/I/O/infrastructure errors escape. Manually constructed
ledgers are checked for typed evidence, exact order, fixed seed mapping and
actual preceding-token continuation. None of these outcomes permits feedback,
refitting, another candidate or an automatic retry.

`run_row0(frozen=..., native=..., exact=..., candidate=...)` is a separate fixed
token0/S1/original-position0 regression after freeze. It never uses generic S8
provenance, never contributes to1088 coverage or selection extrema, and keeps
the historical row0 failure untouched. Numeric/semantic/domain gates apply;
approximate top1 is recorded diagnostically without inventing a new per-context
acceptance threshold. Row0 can still be evaluated if held-out validation fails;
both results remain final evidence with no tuning feedback.

`FrozenWorkflow` provides one-shot in-process state for each evaluation and a
construction-bound frozen identity. An infrastructure error consumes that local
attempt rather than silently retrying. It is not persistent process admission:
the future actual workflow needs external grants, immutable manifests and
receipts, read-state reporting, fresh owned outputs, exact private input/model
authentication, source closure, attempt-all cleanup, and independently observed
terminal process evidence.

The future numerical adapter must be a separate successor to the copied six
files because their current `WORKLOAD` binding and coverage counters are fixed
to calibration3200. Reuse the unchanged metric/domain arithmetic, parameterize
only the reviewed workload/entry identities and aggregate gates, and retain all
same-prefix checks. Proposed successful heldout native count is1120=1088+32
bare/captured invariance controls; separate row0 uses its own2 native controls.
This plan has no model run, validation-body read, original-outcome comparison,
actual calibration PASS claim, HE claim or full source-bound proof yet.
