"""Distinct synthetic producer/reconstruction terminal evidence; no actual reports."""
import copy
import pytest
import freeze_admission as f
from test_freeze_admission import receipt


def fixture(ordinal=1):
    row=receipt(ordinal);producers=[];reconstructions=[];scripts=[]
    for attempt in row['attempts']:
        code=0 if attempt['outcome']=='complete_pass'else 1
        outer=dict(schema='qwen-candidate3200-producer-terminal-v1',
            report_sha256=attempt['parent_report_sha256'],worker_report_sha256=attempt['worker_report_sha256'],
            source_manifest_sha256=attempt['source_manifest_sha256'],source_archive_sha256=attempt['source_archive_sha256'],
            candidate_manifest_sha256=attempt['manifest_sha256'],grant_sha256=attempt['grant_sha256'],
            exit_code=code,reaped=True,process_group_absent=True,worker_exit_code=code,worker_reaped=True,worker_group_absent=True)
        raw=f.canonical(outer);attempt['producer_outer_receipt_sha256']=f.sha(raw);producers.append(raw)
        root=dict(schema='qwen-candidate-reconstruction-outer-v2',review_sha256=attempt['independent_review_sha256'],
            script_sha256=attempt['reconstruction_script_sha256'],producer_source_manifest_sha256=attempt['source_manifest_sha256'],
            **{k:attempt[k]for k in ('reconstruction_source_manifest_sha256','reconstruction_source_archive_sha256','reconstruction_grant_sha256')},
            candidate_manifest_sha256=attempt['manifest_sha256'],producer_outer_receipt_sha256=attempt['producer_outer_receipt_sha256'],
            returncode=0,direct_child_reaped=True,owned_group_absent=True,publication_completed=True)
        raw=f.canonical(root);attempt['reconstruction_outer_receipt_sha256']=f.sha(raw);reconstructions.append(raw);scripts.append(attempt['reconstruction_script_sha256'])
    return row,tuple(producers),tuple(reconstructions),tuple(scripts)


def admit(row,p,r,s):
    raw=f.canonical(row)
    return f.authenticate_complete_freeze(raw,f.sha(raw),producer_outers=p,reconstruction_outers=r,reviewed_script_sha256=s,reviewed_reconstruction_pins=tuple({k:a[k]for k in ('reconstruction_source_manifest_sha256','reconstruction_source_archive_sha256','reconstruction_grant_sha256')}for a in row['attempts']))


@pytest.mark.parametrize('ordinal',[1,2,3])
def test_unique_first_pass_requires_two_separate_outer_receipts_per_attempt(ordinal):
    row,p,r,s=fixture(ordinal);v=admit(row,p,r,s)
    assert v.ordinal==ordinal and v.execution_authorized is False


@pytest.mark.parametrize('key,value',[('returncode',1),('direct_child_reaped',False),('owned_group_absent',False),
    ('publication_completed',False),('review_sha256','0'*64),('script_sha256','0'*64),
    ('candidate_manifest_sha256','0'*64),('producer_source_manifest_sha256','0'*64),
    ('reconstruction_source_manifest_sha256','0'*64),('reconstruction_source_archive_sha256','0'*64),('reconstruction_grant_sha256','0'*64),('producer_outer_receipt_sha256','0'*64)])
def test_rehashed_root_outer_fault_still_rejects(key,value):
    row,p,r,s=fixture();root=f.parse(r[0]);root[key]=value;r=(f.canonical(root),)
    row['attempts'][0]['reconstruction_outer_receipt_sha256']=f.sha(r[0])
    with pytest.raises(ValueError):admit(row,p,r,s)


@pytest.mark.parametrize('key,value',[('exit_code',1),('worker_exit_code',1),('reaped',False),('worker_reaped',False),
    ('process_group_absent',False),('worker_group_absent',False),('report_sha256','0'*64),('grant_sha256','0'*64)])
def test_rehashed_producer_outer_fault_still_rejects(key,value):
    row,p,r,s=fixture();outer=f.parse(p[0]);outer[key]=value;p=(f.canonical(outer),)
    row['attempts'][0]['producer_outer_receipt_sha256']=f.sha(p[0])
    # Rebind the root's producer reference too, so denial is semantic, not just a stale hash.
    root=f.parse(r[0]);root['producer_outer_receipt_sha256']=f.sha(p[0]);r=(f.canonical(root),)
    row['attempts'][0]['reconstruction_outer_receipt_sha256']=f.sha(r[0])
    with pytest.raises(ValueError):admit(row,p,r,s)


def test_reviewed_script_pin_is_independent_from_self_consistent_receipts():
    row,p,r,s=fixture();s=('0'*64,)
    with pytest.raises(ValueError):admit(row,p,r,s)


@pytest.mark.parametrize('which',['producer','reconstruction','script'])
def test_missing_earlier_attempt_cannot_be_replaced_by_latest_pass(which):
    row,p,r,s=fixture(2)
    if which=='producer':p=p[-1:]
    elif which=='reconstruction':r=r[-1:]
    else:s=s[-1:]
    with pytest.raises(ValueError):admit(row,p,r,s)


def test_prior_pass_then_later_pass_cannot_freeze_latest():
    row,p,r,s=fixture(2);row['attempts'][0]['outcome']='complete_pass'
    with pytest.raises(ValueError):admit(row,p,r,s)


def test_original_ambiguous_outer_field_rejected_in_successor():
    row,p,r,s=fixture();row['attempts'][0]['outer_receipt_sha256']=row['attempts'][0].pop('producer_outer_receipt_sha256')
    with pytest.raises(ValueError):admit(row,p,r,s)


@pytest.mark.parametrize('name',['reconstruction_source_manifest_sha256','reconstruction_source_archive_sha256','reconstruction_grant_sha256'])
def test_reconstruction_closure_pins_are_independent_of_attestations(name):
    row,p,r,s=fixture();pins={k:row['attempts'][0][k]for k in ('reconstruction_source_manifest_sha256','reconstruction_source_archive_sha256','reconstruction_grant_sha256')};pins[name]='0'*64
    raw=f.canonical(row)
    with pytest.raises(ValueError,match='Independently reviewed'):
        f.authenticate_complete_freeze(raw,f.sha(raw),producer_outers=p,reconstruction_outers=r,reviewed_script_sha256=s,reviewed_reconstruction_pins=(pins,))
