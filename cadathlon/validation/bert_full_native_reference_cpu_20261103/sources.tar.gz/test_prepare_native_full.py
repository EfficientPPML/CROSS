"""Native-reference boundary/cleanup tests; no HE or later-state substitution."""
import numpy as np
import pytest
from prepare_native_full import capture_pooler,parity,valid_positions,hidden_array
class Tensor:
    def __init__(self,a):self.a=a
    def detach(self):return self
    def cpu(self):return self
    def numpy(self):return self.a
class Pooler:
    def __init__(self,close_error=None):self.hook=None;self.removed=False;self.close_error=close_error
    def register_forward_hook(self,hook):
        self.hook=hook;owner=self
        class Handle:
            def remove(self):
                owner.removed=True;owner.hook=None
                if owner.close_error:raise owner.close_error
        return Handle()
    def call(self,value):self.hook(self,(),Tensor(value));return 'full-output'

def test_actual_pooler_capture():
    m=Pooler();value=np.arange(768,dtype=np.float64)[None]
    result,a=capture_pooler(m,lambda:m.call(value))
    assert result=='full-output' and m.removed and m.hook is None
    np.testing.assert_array_equal(a,value[0]);value[:]=3;assert a[10]==10
@pytest.mark.parametrize('error',(ValueError('ordinary'),KeyboardInterrupt('cancel')))
def test_hook_removed_on_failure(error):
    m=Pooler()
    def failure():raise error
    with pytest.raises(type(error)) as caught:capture_pooler(m,failure)
    assert caught.value is error and m.removed

def test_primary_cancellation_preserved_over_hook_removal_failure():
    m=Pooler(ValueError('close'));error=KeyboardInterrupt('primary')
    def failure():raise error
    with pytest.raises(KeyboardInterrupt) as caught:capture_pooler(m,failure)
    assert caught.value is error and m.removed and any('close' in note for note in error.__notes__)

@pytest.mark.parametrize('count',(0,2))
def test_missing_or_repeated_native_pooler_fails_closed(count):
    m=Pooler()
    def forward():
        for _ in range(count):m.call(np.zeros((1,768)))
    with pytest.raises(ValueError):capture_pooler(m,forward)
    assert m.removed

@pytest.mark.parametrize('kind',('shape','float32','nan'))
def test_native_pooler_rejects_boundary(kind):
    value=np.zeros((1,768))
    if kind=='shape':value=value[:,:767]
    elif kind=='float32':value=value.astype(np.float32)
    else:value[0,0]=np.nan
    m=Pooler()
    with pytest.raises(ValueError):capture_pooler(m,lambda:m.call(value))
    assert m.removed

def test_positions_and_hidden_boundary():
    mask=np.zeros(128,dtype=int);mask[[0,2,127]]=1
    np.testing.assert_array_equal(valid_positions(mask,3),[0,2,127])
    with pytest.raises(ValueError):valid_positions(mask,2)
    mask[0]=0
    with pytest.raises(ValueError):valid_positions(mask,2)
    with pytest.raises(ValueError):hidden_array(Tensor(np.zeros((1,3,767))),3)
    with pytest.raises(ValueError):hidden_array(Tensor(np.zeros((1,3,768),dtype=np.float32)),3)

@pytest.mark.parametrize('kind',('shape','dtype','nan','overflow','error'))
def test_parity_nonfinite_and_wrong_boundary(kind):
    a=np.zeros(2);b=np.zeros(2)
    if kind=='shape':b=b[:1]
    elif kind=='dtype':b=b.astype(np.float32)
    elif kind=='nan':b[0]=np.nan
    elif kind=='overflow':a[0]=np.finfo(float).max;b[0]=-a[0]
    else:b[0]=2e-12
    with pytest.raises(ValueError):parity(a,b)
