"""Freeze exact preparation sources/assets, run tests, then native references only."""
from pathlib import Path
import argparse,ast,hashlib,importlib.metadata,io,json,os,signal,subprocess,sys,tarfile,time
import numpy as np
from prepare_native_full import prepare,ASSETS,SNAPSHOT,PRIOR,PRIOR_SHA,sha
HERE=Path(__file__).resolve().parent
PRIOR_SOURCE=Path('/tmp/bert-first-attention-owner-20261103/prepare_public_fixtures.py')

def sources():
    result={n:(HERE/n).read_bytes() for n in ('prepare_native_full.py','test_prepare_native_full.py','collect_native_full.py')}
    result['prior_prepare_public_fixtures.py']=PRIOR_SOURCE.read_bytes();return result
def hashes(raw):return {k:hashlib.sha256(v).hexdigest() for k,v in raw.items()}
def write(path,value):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');temp.replace(path)
def archive(path,raw):
    with tarfile.open(path,'w:gz') as stream:
        for n,b in raw.items():item=tarfile.TarInfo(n);item.size=len(b);stream.addfile(item,io.BytesIO(b))
def verify_archive(path,expected):
    with tarfile.open(path) as stream:
        rows=stream.getmembers()
        return (len(rows)==len(expected)==len({r.name for r in rows}) and all(r.isfile() for r in rows)
                and {r.name:hashlib.sha256(stream.extractfile(r).read()).hexdigest() for r in rows}==expected)
def pair_ast(raw):
    return next(n.value for n in ast.parse(raw).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PAIRS' for t in n.targets))
def stop(child):
    if child is None:return
    if child.poll() is None:
        os.killpg(child.pid,signal.SIGTERM)
        try:child.wait(timeout=30)
        except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    else:child.wait()
def run(output):
    output.mkdir(exist_ok=False);start=time.monotonic();primary=None;cancel=None;child=None;before={};assets={};cleanup=[]
    report=dict(passed=False,scope='Independent client-only full native BERT reference for fixed K15/K128; no encryption or joined encrypted-model result.',
        cpu_affinity=sorted(os.sched_getaffinity(0)),raw_arrays_archived=False,labels_loaded=False,
        reference_arrays_must_not_replace_joined_intermediates=True,native_dtype='float64',attention_implementation='eager',threads=4)
    def attempt(label,fn):
        nonlocal cancel
        try:return fn()
        except BaseException as error:
            cleanup.append(dict(operation=label,type=type(error).__name__,message=str(error)))
            if primary is not None:primary.add_note(label+': '+repr(error))
            elif not isinstance(error,Exception) and cancel is None:cancel=error
            return None
    try:
        write(output/'report.json',report);raw=sources();before=hashes(raw);archive(output/'sources.tar.gz',raw)
        if not verify_archive(output/'sources.tar.gz',before):raise ValueError('startup source archive differs')
        if ast.dump(pair_ast(raw['prepare_native_full.py']))!=ast.dump(pair_ast(raw['prior_prepare_public_fixtures.py'])):raise ValueError('fixed pair source differs')
        assets={n:sha(SNAPSHOT/n) for n in ASSETS};assets['prior_client_fixtures.npz']=sha(PRIOR)
        if assets!={**ASSETS,'prior_client_fixtures.npz':PRIOR_SHA}:raise ValueError('pinned native assets differ')
        report.update(source_hashes_before=before,source_archive_sha256=sha(output/'sources.tar.gz'),asset_hashes_before=assets,
            versions={n:importlib.metadata.version(n) for n in ('numpy','torch','transformers','tokenizers','safetensors','pytest')},
            environment={n:os.environ.get(n) for n in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')})
        command=[sys.executable,'-m','pytest','-q',str(HERE/'test_prepare_native_full.py'),'--junitxml='+str(output/'tests.xml')]
        with (output/'tests.log').open('wb') as log:
            child=subprocess.Popen(command,cwd=HERE,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            if child.wait()!=0:raise ValueError('preparation boundary tests failed')
        import xml.etree.ElementTree as ET
        tree=ET.parse(output/'tests.xml').getroot();report['tests']={n:sum(int(s.attrib.get(n,0)) for s in tree) for n in ('tests','failures','errors','skipped')}
        if any(report['tests'][n] for n in ('failures','errors','skipped')):raise ValueError('incomplete preparation tests')
        write(output/'report.json',report)
        native_start=time.monotonic();arrays,native=prepare();report['native_elapsed_s']=time.monotonic()-native_start
        path=HERE/'client_native_full.npz'
        with path.open('xb') as stream:np.savez(stream,**arrays)
        report.update(native,fixture_path=str(path),fixture_npz_sha256=sha(path),passed=True)
    except BaseException as error:
        primary=error;report.update(passed=False,error=dict(type=type(error).__name__,message=str(error)))
    finally:
        attempt('reap preparation tests',lambda:stop(child))
        after=attempt('source readback',lambda:hashes(sources()))
        final_assets=attempt('asset readback',lambda:{**{n:sha(SNAPSHOT/n) for n in ASSETS},'prior_client_fixtures.npz':sha(PRIOR)})
        verified=attempt('archive member readback',lambda:verify_archive(output/'sources.tar.gz',before)) if before else False
        report.update(source_hashes_after=after,source_files_unchanged=bool(before) and before==after,
            asset_hashes_after=final_assets,asset_files_unchanged=bool(assets) and assets==final_assets,
            source_archive_verified=verified is True,cleanup_errors=cleanup,elapsed_s=time.monotonic()-start,
            test_child_reaped=child is None or child.poll() is not None)
        report['passed']=bool(report.get('passed') and report['source_files_unchanged'] and report['asset_files_unchanged'] and verified and not cleanup)
        try:write(output/'report.json',report)
        except BaseException as error:
            preserved=primary if primary is not None else cancel
            if preserved is None:raise
            preserved.add_note('final report publication: '+repr(error))
        if primary is not None:raise primary
        if cancel is not None:raise cancel
    print(json.dumps({n:report[n] for n in ('passed','tests','native_elapsed_s','elapsed_s','fixture_npz_sha256','source_archive_sha256')}))
    return 0 if report['passed'] else 1
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();raise SystemExit(run(a.output))
