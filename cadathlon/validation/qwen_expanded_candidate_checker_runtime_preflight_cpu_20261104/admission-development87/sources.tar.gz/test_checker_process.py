from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
import ast
import copy
import json
import sys
import pytest
import checker_process as p
import checker_admission as a
from freeze_io import json_bytes
from test_input_gate import blobs as producer_blobs

HERE=Path(__file__).parent


def blobs():
    data=producer_blobs()
    for name in ('candidate_binding.json','execution_authorization.json','checker_runtime_policy.json','checker_protected_paths.json'):
        data[name]=(HERE/name).read_bytes()
    return data


def arguments(tmp_path,mode='collect-candidate'):
    return SimpleNamespace(mode=mode,output=str(tmp_path/'out'),private_output=str(tmp_path/'private'),
        manifest=str(tmp_path/'sources.json'),manifest_sha256='a'*64,grant=None,grant_sha256=None)


def binding():
    return a.CandidateBinding(b'{}','1'*64,1,'2'*64,'3'*64,a.PROTOCOL,'4'*64,'5'*64,'6'*64,'7'*64,'8'*64)


def grant(args,data,b):
    e=p.input_gate.inspect(data)
    return dict(schema='qwen-expanded-candidate-checker-grant-v1',execute=True,
        scope='one-frozen-candidate-own3200-calibration-only',candidate_ordinal=1,
        candidate_manifest_sha256=b.manifest_sha256,candidate_binding_sha256=b.binding_sha256,
        initial_report_sha256=b.initial_report_sha256,initial_proof_sha256=b.initial_proof_sha256,
        selection_report_sha256=b.selection_proof_sha256,selector_outer_sha256=b.selector_outer_sha256,
        source_manifest_sha256=args.manifest_sha256,protocol_sha256=b.protocol_sha256,
        calibration=e['calibration'],model_pins_sha256=a.sha(data['public/model_pins.json']),
        runtime_policy=p.policy(data),backend_environment=dict(p.backend_environment.REQUIRED),
        evidence_output=args.output,private_output=args.private_output,model_forward=True,
        tokenizer_execution=False,coefficient_selection=False,validation_read=False,encrypted_execution=False,
        candidate_budget=3,preflight_report_sha256='9'*64,independent_review_sha256='b'*64)


def install_grant(args,value,tmp_path):
    path=tmp_path/'grant.json';path.write_bytes(json_bytes(value));args.grant=str(path);args.grant_sha256=a.sha(path.read_bytes())


def test_pending_admission_precedes_grant_io_or_output(tmp_path,monkeypatch):
    data=blobs();args=arguments(tmp_path)
    monkeypatch.setattr(p,'read',lambda *args,**kwargs:pytest.fail('grant read before candidate admitted'))
    with pytest.raises(PermissionError):p.worker(args,{},data,{},tmp_path/'source')
    assert not Path(args.output).exists() and not Path(args.private_output).exists()


def test_exact_grant_synthetic_public_only(tmp_path,monkeypatch):
    data=blobs();args=arguments(tmp_path);b=binding();value=grant(args,data,b)
    monkeypatch.setattr(p.checker_admission,'require_candidate',lambda data:b)
    monkeypatch.setattr(p.os,'sched_getaffinity',lambda pid:set(p.policy(data)['cores']))
    install_grant(args,value,tmp_path)
    assert p.grant_check(args,data)==(b,value)
    args.mode='candidate-worker';args.output=str(Path(args.output)/'worker')
    assert p.grant_check(args,data)==(b,value)


@pytest.mark.parametrize('field,value',[('execute',1),('candidate_ordinal',2),('candidate_budget',4),
    ('candidate_manifest_sha256','c'*64),('initial_report_sha256','d'*64),('selector_outer_sha256','d'*64),
    ('validation_read',True),('coefficient_selection',True),('model_forward',False),
    ('private_output','/tmp/other'),('runtime_policy',{}),('backend_environment',{}),
    ('preflight_report_sha256',None)])
def test_bad_grant_before_any_output(tmp_path,monkeypatch,field,value):
    data=blobs();args=arguments(tmp_path);b=binding();g=grant(args,data,b);g[field]=value
    monkeypatch.setattr(p.checker_admission,'require_candidate',lambda data:b)
    monkeypatch.setattr(p.os,'sched_getaffinity',lambda pid:set(p.policy(data)['cores']))
    install_grant(args,g,tmp_path)
    with pytest.raises(ValueError):p.worker(args,{},data,{},tmp_path/'source')
    assert not Path(args.output).exists()


@pytest.mark.parametrize('target',range(5))
def test_initial_observer_trees_cannot_be_output_or_read(tmp_path,monkeypatch,target):
    data=blobs();args=arguments(tmp_path);path=p.checker_paths(data)[target]
    args.output=path+'/checker-evidence'
    with pytest.raises(ValueError):p.validate_paths(args,data,tmp_path/'source')
    hooks=[];monkeypatch.setattr(p.sys,'addaudithook',hooks.append)
    p.install_audit(data,True)
    with pytest.raises(PermissionError):hooks[0]('open',(path+'/ranges.json','rb',0))


def terminal(b,args,expected):
    return dict(passed=True,complete=True,cleanup_completed=True,signal_restoration_completed=True,
        source_files_unchanged=True,terminal_after_body_cleanup_and_signal_restoration_attempts=True,
        acceptance_requires_independent_exit0_reap_and_exact_report_hash=True,
        calibration_reauthenticated=True,private_directory_handle_closed=True,private_outputs_retained=True,
        external_inputs_never_removed=True,model_asset_postchecks_completed=True,model_cleanup_completed=True,
        native_capture_cleanup_completed=True,ledger_complete=True,audit_denials=[],
        source_manifest_sha256=args.manifest_sha256,source_hashes_start=expected,source_hashes_end=expected,
        manifest_sha256=b.manifest_sha256,grant_sha256=args.grant_sha256,
        initial_report_sha256=b.initial_report_sha256,selection_proof_sha256=b.selection_proof_sha256,
        retained_entries=3200,expected_entries=3200,candidate_ordinal=1,
        coefficient_selection_performed=False,encrypted_execution=False,validation_inputs_read=False,
        tokenizer_execution=False,contains_tokens_logits_or_failure_text=False,model_loaded=True,
        candidate_validation_admissible=True,complete_measured_context_coverage=True,trajectories_complete=True,
        all_length_invariance=True,native_forward_started=3232,native_forward_completed=3232,
        phase_counts=dict(native=3200,exact=3200,candidate=3200))


@pytest.mark.parametrize('field,value',[('native_forward_completed',3231),('native_forward_started',True),
    ('complete',False),('model_loaded',False),('ledger_complete',False),('cleanup_completed',False),
    ('signal_restoration_completed',False),('private_directory_handle_closed',False),
    ('phase_counts',dict(native=3200,exact=3200,candidate=3199)),('audit_denials',['private']),
    ('source_hashes_end',{}),('candidate_validation_admissible',False),('validation_inputs_read',True),
    ('retained_entries',3199)])
def test_terminal_rejects_missing_counters_or_cleanup(tmp_path,monkeypatch,field,value):
    data=blobs();args=arguments(tmp_path);b=binding();expected={'source':'e'*64}
    monkeypatch.setattr(p.checker_admission,'require_candidate',lambda data:b)
    report=terminal(b,args,expected);report[field]=value
    with pytest.raises(ValueError):p.accept_candidate_worker(report,0,expected,args,data)


def test_success_and_scientific_failure_are_distinct(tmp_path,monkeypatch):
    data=blobs();args=arguments(tmp_path);b=binding();expected={'source':'e'*64}
    monkeypatch.setattr(p.checker_admission,'require_candidate',lambda data:b)
    report=terminal(b,args,expected)
    assert p.accept_candidate_worker(report,0,expected,args,data) is report
    report.update(passed=False,candidate_validation_admissible=False,trajectories_complete=False,
        native_forward_started=3229,native_forward_completed=3229)
    assert p.accept_candidate_worker(report,1,expected,args,data) is report
    with pytest.raises(ValueError):p.accept_candidate_worker(report,0,expected,args,data)


def test_reviewed_lifecycle_helper_bodies_exact():
    names=('signals','accumulate','source_end','dependencies','enable_model_imports','group_absent','retire','child_environment')
    def bodies(name):
        return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse((HERE/name).read_text()).body
                if isinstance(n,ast.FunctionDef) and n.name in names}
    assert bodies('checker_process.py')==bodies('observer_process.py')


def test_supervise_source_failure_clears_candidate_and_revision_flags(tmp_path,monkeypatch):
    @contextmanager
    def signals(state=None,shield=False):
        if state is not None:state['restored']=True
        yield
    monkeypatch.setattr(p,'signals',signals)
    monkeypatch.setattr(p,'source_end',lambda *args:(_ for _ in ()).throw(ValueError('drift')))
    output=p.Output(tmp_path/'out');report=dict(passed=True,complete=True,
        candidate_validation_admissible=True,failed_attempt_terminal_candidate=True)
    with pytest.raises(ValueError):p.supervise(output,report,lambda:None,[],tmp_path,{})
    assert report['candidate_validation_admissible'] is False
    assert report['failed_attempt_terminal_candidate'] is False
    assert report['cleanup_completed'] is False


@pytest.mark.parametrize('body_cls',[ValueError,OSError,KeyboardInterrupt,SystemExit])
def test_cleanup_shield_setup_failure_still_retires_all(tmp_path,monkeypatch,body_cls):
    calls=[];body=body_cls('body')
    @contextmanager
    def signals(state=None,shield=False):
        if shield:raise OSError('shield installation')
        if state is not None:state['restored']=True
        yield
    monkeypatch.setattr(p,'signals',signals)
    monkeypatch.setattr(p,'source_end',lambda *args:calls.append('source') or {})
    output=p.Output(tmp_path/'out');report=dict(passed=False,complete=False)
    def action():raise body
    with pytest.raises(body_cls) as caught:
        p.supervise(output,report,action,[lambda:calls.append('input'),lambda:calls.append('process')],tmp_path,{})
    assert caught.value is body and calls==['input','process','source'] and output.fd is None
    assert report['cleanup_completed'] is False and report['candidate_validation_admissible'] is False


def worker_fixture(tmp_path,monkeypatch,execute):
    @contextmanager
    def signals(state=None,shield=False):
        if state is not None:state['restored']=True
        yield
    data=blobs();args=arguments(tmp_path,'candidate-worker');b=binding()
    monkeypatch.setattr(p,'signals',signals);monkeypatch.setattr(p,'source_end',lambda *args:{})
    monkeypatch.setattr(p,'grant_check',lambda *args:(b,{}))
    monkeypatch.setattr(p,'install_audit',lambda *args:[])
    monkeypatch.setattr(p,'dependencies',lambda *args:{})
    monkeypatch.setattr(p,'enable_model_imports',lambda:None)
    class Reader:
        loaded=True
        def __init__(self,blobs):pass
        def recheck(self):pass
    monkeypatch.setattr(p.input_gate,'Reader',Reader)
    monkeypatch.setitem(sys.modules,'checker_runtime',SimpleNamespace(execute_candidate=execute))
    return args,data,b


@pytest.mark.parametrize('event',[dict(stage='native_forward_started',native_forward_started=1),
    dict(stage='model_loaded',model_loaded=1),dict(stage='native',index=True),
    dict(stage='private token text'),dict(stage='native',token_ids=[1,2]),
    dict(stage='native',sequence_length=33),dict(stage='native',kind='validation')])
def test_worker_progress_rejects_private_or_false_counter_events(tmp_path,monkeypatch,event):
    def execute(blobs,reader,output,progress):progress(event);pytest.fail('bad event accepted')
    args,data,b=worker_fixture(tmp_path,monkeypatch,execute)
    with pytest.raises(ValueError):p.worker(args,{},data,{},tmp_path/'source')
    report=json.loads((Path(args.output)/'report.json').read_bytes())
    assert report['passed'] is False and report['private_directory_handle_closed'] is True
    assert report['candidate_validation_admissible'] is False


@pytest.mark.parametrize('fault',['counter_skip','counter_overwrite','authority_overwrite','false_pass'])
def test_worker_never_admits_false_runtime_completion(tmp_path,monkeypatch,fault):
    b=binding()
    def execute(blobs,reader,output,progress):
        progress(dict(stage='model_loaded',model_loaded=True))
        if fault=='counter_skip':progress(dict(stage='native_forward_started',native_forward_started=3232))
        report=dict(model_loaded=True,native_forward_started=0,native_forward_completed=0,
            passed=False,manifest_sha256=b.manifest_sha256,ledger_complete=True,revision_eligible_ledger=False)
        if fault=='counter_overwrite':report['native_forward_completed']=3232
        if fault=='authority_overwrite':report['cleanup_completed']=True
        if fault=='false_pass':report['passed']=True
        return report
    args,data,b=worker_fixture(tmp_path,monkeypatch,execute)
    with pytest.raises(ValueError):p.worker(args,{},data,{},tmp_path/'source')
    report=json.loads((Path(args.output)/'report.json').read_bytes())
    assert report['passed'] is False and report['candidate_validation_admissible'] is False
    assert report['private_directory_handle_closed'] is True
