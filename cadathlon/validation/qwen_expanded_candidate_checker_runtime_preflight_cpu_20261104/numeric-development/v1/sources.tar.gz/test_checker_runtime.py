"""Synthetic full-shape adapters; no model/parameter/token body access."""
import copy,json,sys
from types import SimpleNamespace
import numpy as np
import pytest
import checker_runtime as r
import candidate_dispatch as d
import arithmetic
from ranges import RangeBook,NORM_LABELS
from strict_metrics import StructuralFailure,operator_shapes
from test_candidate_domains import manifest
from test_dispatch import calibration

def full(shape,value=1.):return np.broadcast_to(np.float64(value),shape)
def observations(S,origin,callback=None):
    book=RangeBook().begin(S);observe=book.observe if callback is None else callback
    for i in range(28):
        for part,shape in [('input',(1,S,1)),('q',(1,16,S,1)),('k',(1,8,S,1)),('post',(1,S,1))]:
            label=f'{i}.{part}.inverse_sqrt';observe(label,full(shape))
            if origin=='exact':observe(label+'.exact_output',full((1,S,1024)))
        if origin=='exact':
            for name in('q','k'):observe(f'{i}.{name}_rope.exact_output',full((1,1)))
        observe(f'{i}.silu',full((1,S,3072),0.))
        for k in range(1,S+1):
            observe(f'{i}.softmax.raw_valid',full((1,16,k),0.));observe(f'{i}.softmax.centered',full((1,16,k),0.))
    observe('final.inverse_sqrt',full((1,1)))
    if origin=='exact':observe('final.inverse_sqrt.exact_output',full((1,1024)))
    if callback is None:return book.end()

class Sink:
    def __init__(self):self.rows={}
    def json(self,name,value):
        assert name not in self.rows;self.rows[name]=json.loads(json.dumps(value,allow_nan=False))

class Capture:
    active=False
    def begin(self,S):assert not self.active;self.active=True;self.S=S
    def end(self):
        self.active=False
        return dict(operators={n:full(s)for n,s in operator_shapes(self.S).items()},blocks=[full((1,self.S,1024))for _ in range(28)],inputs=observations(self.S,'native'))
    def abort(self):self.active=False;return dict(complete=False,invalid=True)

def setup(*,candidate_problem=None,exact_problem=None,native_problem=None):
    logits=np.ones((1,151936));logits[0,7]=2.;native_calls=[];inputs=[];capture=Capture();sink=Sink();progress=[]
    def native(prefix):
        native_calls.append(tuple(prefix))
        if native_problem=='nonfinite':return np.full((1,151936),np.nan)
        if native_problem=='shape':return np.zeros((1,2))
        return logits.copy()
    def exact(c,w,x,*,observe):
        inputs.append(('exact',x));observations(x.shape[1],'exact',observe)
        if exact_problem=='nonfinite':return np.full((1,151936),np.inf)
        y=logits.copy()
        if exact_problem=='numeric':y[0,0]=1.1
        return y
    def plain(c,w,x):
        inputs.append(('plain',x));y=logits.copy()
        if exact_problem=='numeric':y[0,0]=1.1
        return y
    def candidate(c,w,x,m,*,engine):
        inputs.append(('candidate',x))
        for event in engine.expected_events:
            values=full(event.shape,sum(event.domain)/2)
            if candidate_problem=='domain':values=full(event.shape,event.domain[1]+1)
            engine.observe(event.label,values,list(event.domain))
        for label,shape in operator_shapes(x.shape[1]).items():
            if candidate_problem=='missing_operator'and label=='final.inverse_sqrt':continue
            engine.operators[label]=full(shape,2. if candidate_problem=='operator_numeric'and label=='0.q_linear'else 1.)
        for _ in range(28):engine.blocks.append(full((1,x.shape[1],1024)))
        result=logits.copy()
        if candidate_problem=='logit_numeric':result[:]=2.;result[0,11]=3.
        if candidate_problem=='nonfinite':result[0,0]=np.nan
        if candidate_problem=='shape':result=np.zeros((1,2))
        return arithmetic.Value(result,42),engine,engine.blocks,engine.operators
    config=dict(r.ARCHITECTURE,rms_norm_eps=1e-6,rope_theta=1000000.)
    weights={'model.embed_tokens.weight':full((151936,1024),.25)}
    adapter=r.ContextAdapters(native_forward=native,capture_owner=capture,config=config,weights=weights,manifest=manifest(),manifest_sha256='a'*64,private_output=sink,progress=progress.append,exact_forward=exact,plain_forward=plain,candidate_forward=candidate)
    return adapter,sink,inputs,native_calls,progress

def context(adapter,S=1):
    entry=r.WORKLOAD[S-1];prefix=tuple(range(S));n=adapter.native(prefix,entry);e=adapter.exact(prefix,entry,n)
    return entry,prefix,n,e

@pytest.mark.parametrize('S',[1,8,32])
def test_same_prefix_independent_original_embeddings_all_metrics_and_private_stats(S):
    a,sink,inputs,calls,progress=setup();entry,prefix,n,e=context(a,S);result=a.candidate(prefix,entry)
    assert result==d.Candidate(7,True,True,True,421,28,151936)and e.semantic_pass
    assert calls==[prefix,prefix]and len(inputs)==3 and all(x.shape==(1,S,1024)for _,x in inputs)
    assert all(inputs[i][1]is not inputs[j][1]for i in range(3)for j in range(i))
    assert all(np.array_equal(inputs[0][1],x)for _,x in inputs)
    row=sink.rows[f'{entry.index:04d}-candidate.json'];assert len(row['operator_metrics'])==421 and len(row['block_metrics'])==28 and row['full_logit_metric']['count']==151936
    assert len(row['observations']['normalization_variance'])==113
    assert row['observations_sha256']==r.sha(r.canonical(row['observations']))
    native=sink.rows[f'{entry.index:04d}-native.json'];assert native['observations_sha256']==r.sha(r.canonical(native['observations']))
    assert a.pending is None and set(progress[0])=={'index','kind','sequence_length','stage'}

@pytest.mark.parametrize('problem',['operator_numeric','logit_numeric'])
def test_finite_metric_failure_retains_complete_actual_argmax(problem):
    a,sink,*_=setup(candidate_problem=problem);entry,prefix,*_=context(a);c=a.candidate(prefix,entry)
    assert c.complete and c.domain_pass and not c.numeric_pass and c.token==(11 if problem=='logit_numeric'else 7)
    assert sink.rows['0000-candidate.json']['status']=='complete'and a.pending is None

@pytest.mark.parametrize('problem',['domain','nonfinite'])
def test_candidate_invalid_stop_has_no_argmax_and_preserves_partial_evidence(problem):
    a,sink,*_=setup(candidate_problem=problem);entry,prefix,*_=context(a);c=a.candidate(prefix,entry)
    assert not c.complete and c.token is None and c.logits==0 and not c.numeric_pass
    row=sink.rows['0000-candidate.json'];assert row['failure']is not None and a.pending is None
    if problem=='domain':
        first=row['observations']['domains']['0.input.inverse_sqrt'];assert first['above']==1 and first['maximum']==11.

@pytest.mark.parametrize('problem',['shape','missing_operator'])
def test_candidate_structural_failure_is_not_revision_evidence(problem):
    a,sink,*_=setup(candidate_problem=problem);entry,prefix,*_=context(a)
    with pytest.raises(StructuralFailure):a.candidate(prefix,entry)
    assert '0000-candidate.json'not in sink.rows and a.pending is None

@pytest.mark.parametrize('phase',['native','exact'])
def test_known_nonfinite_comparison_maps_to_dispatch_stop(phase):
    a,sink,*_=setup(**{phase+'_problem':'nonfinite'});entry=r.WORKLOAD[0];prefix=(0,)
    with pytest.raises(d.InvalidObservation):
        native=a.native(prefix,entry)
        a.exact(prefix,entry,native)
    assert sink.rows['0000-'+phase+'.json']['status']=='comparison_invalid'and a.pending is None

def test_exact_semantic_failure_cannot_enter_candidate():
    a,sink,*_=setup(exact_problem='numeric');entry,prefix,n,e=context(a)
    assert not e.semantic_pass and a.pending is None
    with pytest.raises(StructuralFailure):a.candidate(prefix,entry)

@pytest.mark.parametrize('fault',['prefix','entry','argmax','phase'])
def test_phase_binding_rejects_wrong_context_or_replayed_phase(fault):
    a,sink,*_=setup();entry=r.WORKLOAD[0];prefix=(0,);native=a.native(prefix,entry)
    if fault=='prefix':prefix=(1,)
    if fault=='entry':entry=r.WORKLOAD[1];prefix=(0,1)
    if fault=='argmax':native=d.Native(8)
    if fault=='phase':a.pending['phase']='exact'
    with pytest.raises(StructuralFailure):a.exact(prefix,entry,native)

@pytest.mark.parametrize('fault',['variance_count','weighted_namespace','score_count','k1','ignored'])
def test_input_statistics_cannot_claim_wrong_namespace_or_counts(fault):
    observed=observations(3,'native')
    if fault=='variance_count':observed['ranges']['0.q.inverse_sqrt']['count']=3
    if fault=='weighted_namespace':observed['ranges']['0.input.inverse_sqrt']['count']=3*1024
    if fault=='score_count':observed['score_rows']['0']['2']['centered']['count']=2
    if fault=='k1':observed['score_rows']['0']['1']['k1_bypass']=1
    if fault=='ignored':observed['ignored_exact_output_callbacks']=True
    with pytest.raises(StructuralFailure):r.input_inventory(observed,3,'native')

def test_complete_dispatcher_uses_candidate_own_tokens_and_full_denominators(monkeypatch):
    a,sink,*_=setup();seen=[]
    def native(prefix,entry):seen.append((entry,prefix));a.native_invariance[len(prefix)]=True;return d.Native(7)
    def exact(prefix,entry,n):a.exact_invariance[len(prefix)]=True;return d.Exact(7,True)
    def candidate(prefix,entry):
        if entry.kind=='free'and entry.seed_ordinal==0 and entry.step==1:raise d.CandidateStop('synthetic domain')
        return d.Candidate(11,True,False,True,421,28,151936)
    a.native=native;a.exact=exact;a.candidate=candidate
    report=a.run(calibration())
    assert report['retained_entries']==3200 and report['by_kind']['free']['unmeasured']==2 and not report['passed']
    assert seen[-1][1][-3:]==(11,11,11)and len(sink.rows['ledger.json']['records'])==3200
    assert not report['revision_eligible_ledger']and not report['complete_measured_context_coverage']
    assert not report['revision_comparison_coverage'] # Fake dispatcher-only counts are not measured evidence.

def test_admission_precedes_any_body_environment_backend_or_sink(monkeypatch):
    calls=[]
    def deny(blobs):calls.append('admission');raise ValueError('pending frozen candidate')
    monkeypatch.setitem(sys.modules,'checker_admission',SimpleNamespace(require_candidate=deny))
    def forbidden(*a,**k):pytest.fail('body/sink/progress before admission')
    with pytest.raises(ValueError,match='pending'):r.execute_candidate({},forbidden,SimpleNamespace(json=forbidden),forbidden)
    assert calls==['admission']
