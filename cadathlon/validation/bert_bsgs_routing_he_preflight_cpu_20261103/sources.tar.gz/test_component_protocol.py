"""Synthetic terminal/source gates. No private key or ciphertext reads."""
from pathlib import Path
import copy
import hashlib
import io
import json
import os
import stat
import tarfile
import pytest
import component_protocol as p
import component_contract as c
from test_component_contract import contract


def manifest(role='request'):
    return dict(schema=p.MANIFEST_SCHEMA,contract=contract(),role=role,input_digest='ab'*32,
        tiles=[dict(index=i,manifest_sha256='cd'*32) for i in range(2 if role=='request' else 18)])


def terminal(tmp_path,stage='fixture'):
    workspace=tmp_path/'io';workspace.mkdir(mode=0o700);out=tmp_path/'evidence';out.mkdir();(out/'worker').mkdir()
    sources={'code.py':p.sha(b'pass\n')}
    with tarfile.open(out/'sources.tar.gz','w:gz') as z:
        m=tarfile.TarInfo('code.py');m.size=5;z.addfile(m,io.BytesIO(b'pass\n'))
    v=manifest('request' if stage=='fixture' else 'response')
    readback=dict(manifest=v,manifest_sha256=p.sha(c.canonical(v)),tile_count=len(v['tiles']),input_digest=v['input_digest'])
    common=dict(passed=True,stage=stage,source_files_unchanged=True,terminal_scope_completed=True,
        workspace_identity=p.identity(workspace),source_hashes_start=sources,source_hashes_end=sources,
        request_contract=contract(),readback=readback)
    w=dict(common,phase_complete=True,loader_cleanup_completed=True,forbidden_attempts=[])
    r=dict(common,schema=p.TERMINAL_SCHEMA,execute=True,worker_reaped=True,worker_exit_code=0,
        source_archive_verified=True,workspace=str(workspace),source_archive_sha256=p.sha((out/'sources.tar.gz').read_bytes()))
    args=dict(stage=stage,expected_sources=sources,workspace=workspace,workspace_identity=p.identity(workspace),request=contract())
    return out,r,w,args


def publish(out,r,w):
    p.write(out/'worker/worker_report.json',w)
    r['worker_report_sha256']=p.sha((out/'worker/worker_report.json').read_bytes())
    p.write(out/'report.json',r)
    return p.sha((out/'report.json').read_bytes())


@pytest.mark.parametrize('stage',['fixture','server'])
def test_complete_prior_parent_receipt(stage,tmp_path):
    out,r,w,args=terminal(tmp_path,stage)
    digest=publish(out,r,w)
    assert p.terminal_gate(out,digest,**args)==r


@pytest.mark.parametrize('field',['passed','execute','worker_reaped','source_files_unchanged','source_archive_verified','terminal_scope_completed'])
def test_parent_incomplete_boolean_never_authorizes(field,tmp_path):
    out,r,w,args=terminal(tmp_path);r[field]=1
    digest=publish(out,r,w)
    with pytest.raises(ValueError):p.terminal_gate(out,digest,**args)


@pytest.mark.parametrize('field',['passed','phase_complete','loader_cleanup_completed','source_files_unchanged','terminal_scope_completed'])
def test_worker_incomplete_boolean_never_authorizes(field,tmp_path):
    out,r,w,args=terminal(tmp_path);w[field]=False
    digest=publish(out,r,w)
    with pytest.raises(ValueError):p.terminal_gate(out,digest,**args)


@pytest.mark.parametrize('mutation',['wrong_stage','worker_exit_bool','worker_exit_nonzero','parent_error','worker_error',
    'cleanup_error','denial','source_start','source_end','worker_sources','contract_nonce','workspace','workspace_identity',
    'worker_contract','worker_readback','worker_manifest','worker_incomplete18','worker_body_digest','archive_digest','archive_bytes'])
def test_coherent_or_broken_terminal_tampering_rejected(mutation,tmp_path):
    out,r,w,args=terminal(tmp_path,'server')
    if mutation=='wrong_stage':r['stage']='fixture'
    elif mutation=='worker_exit_bool':r['worker_exit_code']=False
    elif mutation=='worker_exit_nonzero':r['worker_exit_code']=1
    elif mutation=='parent_error':r['error']={'message':'failed'}
    elif mutation=='worker_error':w['error']={'message':'failed'}
    elif mutation=='cleanup_error':r['cleanup_errors']=['failed']
    elif mutation=='denial':w['forbidden_attempts']=['secret']
    elif mutation in ('source_start','source_end'):r['source_hashes_'+mutation.split('_')[1]]={}
    elif mutation=='worker_sources':w['source_hashes_end']={}
    elif mutation=='contract_nonce':r['request_contract']=c.make_contract(c.CONTEXT_ID,'02'*16)
    elif mutation=='workspace':r['workspace']+='-replacement'
    elif mutation=='workspace_identity':r['workspace_identity']=[0,0]
    elif mutation=='worker_contract':w['request_contract']=c.make_contract(c.CONTEXT_ID,'02'*16)
    elif mutation=='worker_readback':w['readback']={}
    elif mutation=='worker_manifest':
        w['readback']=copy.deepcopy(w['readback']);w['readback']['manifest']['tiles'].reverse();r['readback']=w['readback']
        w['readback']['manifest_sha256']=p.sha(c.canonical(w['readback']['manifest']))
    elif mutation=='worker_incomplete18':
        w['readback']=copy.deepcopy(w['readback']);w['readback']['tile_count']=17;r['readback']=w['readback']
    elif mutation=='archive_digest':r['source_archive_sha256']='00'*32
    elif mutation=='archive_bytes':
        with tarfile.open(out/'sources.tar.gz','w:gz') as z:
            m=tarfile.TarInfo('code.py');m.size=4;z.addfile(m,io.BytesIO(b'evil'))
        r['source_archive_sha256']=p.sha((out/'sources.tar.gz').read_bytes())
    digest=publish(out,r,w)
    if mutation=='worker_body_digest':(out/'worker/worker_report.json').write_bytes(b'{}')
    with pytest.raises(ValueError):p.terminal_gate(out,digest,**args)


def test_external_report_hash_fails_before_workspace_or_later_evidence(tmp_path,monkeypatch):
    out,r,w,args=terminal(tmp_path);publish(out,r,w);reads=[];read=p.key_gate.read
    def limited(path,*a,**k):reads.append(Path(path).name);return read(path,*a,**k)
    monkeypatch.setattr(p.key_gate,'read',limited)
    def forbidden(*a,**k):raise AssertionError('workspace identity not authorized yet')
    monkeypatch.setattr(p,'check_identity',forbidden)
    with pytest.raises(ValueError,match='externally pinned'):p.terminal_gate(out,'00'*32,**args)
    assert reads==['report.json']


@pytest.mark.parametrize('edit',['reordered','duplicate','short','extra','bool_index','bad_digest','wrong_input','extra_field'])
def test_artifact_manifest_needs_all18_ordered_bindings(edit):
    value=manifest('response')
    if edit=='reordered':value['tiles'].reverse()
    elif edit=='duplicate':value['tiles'][17]=value['tiles'][0]
    elif edit=='short':value['tiles'].pop()
    elif edit=='extra':value['tiles'].append(value['tiles'][0])
    elif edit=='bool_index':value['tiles'][0]['index']=False
    elif edit=='bad_digest':value['tiles'][17]['manifest_sha256']='bad'
    elif edit=='wrong_input':value['input_digest']='01'*32
    else:value['extra']=1
    with pytest.raises(ValueError):p.validate_artifact_manifest(value,request=contract(),role='response',input_digest='ab'*32)


@pytest.mark.parametrize('name',['/etc/passwd','../code.py','a/../../code.py','./code.py','a//code.py','',None,True])
def test_relative_source_names_are_canonical(name):
    with pytest.raises(ValueError):p.relative(name)


def test_public_writer_closes_handoff_fd_and_keeps_partial_file(tmp_path,monkeypatch):
    original=p.os.fdopen;seen=[];primary=KeyboardInterrupt('cancel before stream ownership')
    def fail(fd,*a,**k):seen.append(fd);raise primary
    monkeypatch.setattr(p.os,'fdopen',fail)
    with pytest.raises(KeyboardInterrupt) as e:p.write(tmp_path/'report.json',{'passed':True})
    assert e.value is primary and len(seen)==1
    with pytest.raises(OSError):os.fstat(seen[0])
    assert (tmp_path/'report.json.tmp').exists() and not (tmp_path/'report.json').exists()


def test_closed_or_replaced_io_directory_rejected(tmp_path):
    path=tmp_path/'io';path.mkdir(mode=0o700);owner=p.identity(path)
    path.rename(tmp_path/'moved');path.mkdir(mode=0o700)
    with pytest.raises(ValueError):p.check_identity(path,owner)
    assert (tmp_path/'moved').exists() and path.exists()


@pytest.mark.parametrize('cancellation',[KeyboardInterrupt,SystemExit])
@pytest.mark.parametrize('operation',['write','readback'])
def test_nested_cleanup_only_cancellation_outranks_earlier_close_error(tmp_path,monkeypatch,cancellation,operation):
    ordinary=OSError('first close-only error');cancel=cancellation('later close cancellation');closed=[]
    original=os.close
    if operation=='readback':
        folder=tmp_path/'inputs';folder.mkdir()
        for i in range(2):(folder/f'tile{i}').mkdir()
        (folder/'manifest.json').write_bytes(c.canonical(manifest()))
    def closing(fd):
        info=os.fstat(fd);original(fd);closed.append(fd)
        if stat.S_ISREG(info.st_mode):raise ordinary
        raise cancel
    monkeypatch.setattr(os,'close',closing)
    with pytest.raises(cancellation) as caught:
        if operation=='write':p.write(tmp_path/'report.json',{'passed':True})
        else:p.readback(tmp_path,contract(),role='request')
    assert caught.value is cancel and len(closed)==len(set(closed))==2
    assert any('first close-only error' in n for n in cancel.__notes__)


@pytest.mark.parametrize('cancellation',[KeyboardInterrupt,SystemExit])
def test_real_write_body_primary_survives_two_cleanup_failures(tmp_path,monkeypatch,cancellation):
    primary=ValueError('original body failure');ordinary=OSError('file cleanup');cancel=cancellation('directory cleanup')
    original=os.close;closed=[]
    def closing(fd):
        info=os.fstat(fd);original(fd);closed.append(fd)
        raise ordinary if stat.S_ISREG(info.st_mode) else cancel
    def fail_sync(fd):raise primary
    monkeypatch.setattr(os,'fsync',fail_sync);monkeypatch.setattr(os,'close',closing)
    with pytest.raises(ValueError) as caught:p.write(tmp_path/'report.json',{'passed':True})
    assert caught.value is primary and len(closed)==len(set(closed))==2
    assert any('file cleanup' in n for n in primary.__notes__) and any('directory cleanup' in n for n in primary.__notes__)


@pytest.mark.parametrize('body_error',[False,True])
@pytest.mark.parametrize('cancellation',[KeyboardInterrupt,SystemExit])
def test_key_gate_stream_close_preserves_body_or_cleanup_cancellation(tmp_path,monkeypatch,body_error,cancellation):
    import component_key_gate as gate
    path=tmp_path/'evidence.json';path.write_bytes(b'{}')
    primary=ValueError('key gate read body');stream_error=OSError('stream close');cancel=cancellation('descriptor close')
    real_close=os.close;closed=[]
    class Stream:
        def read(self,size):
            if body_error:raise primary
            return b'{}'
        def close(self):raise stream_error
    def fdopen(fd,mode,*,closefd):assert closefd is False;return Stream()
    def close(fd):real_close(fd);closed.append(fd);raise cancel
    monkeypatch.setattr(os,'fdopen',fdopen);monkeypatch.setattr(os,'close',close)
    with pytest.raises(ValueError if body_error else cancellation) as caught:gate.read(path)
    assert caught.value is (primary if body_error else cancel) and len(closed)==1
