This isolated BSGS harness is preparation only until an explicitly reviewed
source-bound ready successor is frozen. It cannot launch while
execution_authorization.json has ready=false. The copied103 original runtime
sources and four owner/input artifacts remain unchanged.

A fixed source_inventory.json includes every copied runtime, new worker/gate,
public oracle, test and control file. The collector snapshots and verifies that
closure, authenticates the external completed key report with no key payload
reads, and runs synthetic tests and installed entrypoint probes in separate
fresh children. Installed probes import the actual copied core and initialize
the CPU backend; they instantiate no CKKSContext/Polynomial, generate no keys,
read no private/key/ciphertext/model payload, and perform no HE.

Actual execution has three individually invoked parent/worker phases. Each
parent reaps its worker and freezes a terminal receipt. The next phase requires
an externally supplied SHA256 of that completed parent receipt and the same
source inventory, request nonce, context and owned IO identity. Before private
validation, every one of18 output ciphertexts is authenticated against the
completed keyless server receipt. Original external keys, pretrained inputs,
clear references and request/receipt ledgers are never written or removed.

The fixture role encrypts only the two fixed public arrays. The server performs
three real level reductions and one ciphertext product, then six literal BSGS
maps using the frozen ordinary arithmetic owner. It streams18 checkpoints to
bounded metadata/payload files. The validator uses the independent full-slot
coordinate oracle and the unchanged absolute1e-6 gate; no clipping or relaxed
numeric tolerance is permitted. Whole-run timings are diagnostic, exclude the
existing keys' original setup cost, and cannot establish a calibrated speedup.

The new transport preserves genuine body failures and gives cleanup-only
cancellation precedence over earlier close-only errors. It owns each descriptor
through stream handoff and never retries uncertain descriptor numbers. Failed
writes retain partial tiles for parent-owned quarantine; no recursive deletion
occurs in transport. The arithmetic helper quarantines helpers/provider on any
entered-body failure, including pre-return primitive failures whose output is
not observable. The outer key loader must quarantine backing and the process
must exit. These are dedicated-process guards, not a same-user OS sandbox.

Actual encrypted artifacts remain private to the owned0700 IO directory.
Collectors retain this directory on success or failure for independent review;
retirement is a later explicit identity-checked operation after complete public
evidence preservation. No cleanup approval follows from a partial stage. Raw
stored payload is348MiB; headers, write overlap and a1GiB reserve are checked
separately. Child maxRSS is recorded but is not aggregate memory evidence.

Known development defects are preserved in child evidence directories: three
transport lifecycle failures, the key-gate descriptor handoff leak, cleanup-only
cancellation priority, the importlib.util first-entry dependency, and the
pre-return arithmetic-readiness gap. All are isolated from live full-model and
component jobs. This proof never implies full BERT or ranked accuracy.
