"""Snapshot/terminal/reaping controls using explicit child-process doubles."""
from pathlib import Path
import json
import os
import pytest
import collect_component as collector
import component_protocol as p
import component_contract as c


def setup(monkeypatch,*,failure=None):
    events=[];raw={'stub.py':b'pass\n'};expected=p.hashes(raw)
    monkeypatch.setenv('JAX_PLATFORMS','cpu')
    monkeypatch.setattr(p,'sources',lambda:raw)
    monkeypatch.setattr(p,'check_sources',lambda expected:(b'profile',b'plan'))
    def public(*a,**k):events.append('public_gate');return dict(context_id=c.CONTEXT_ID,key_report_sha256=p.KEY_REPORT,key_source_archive_sha256='01'*32)
    monkeypatch.setattr(p,'authenticate_keys',public)
    read=collector.key_gate.read
    settings=dict(mock_test_files=['test_mock.py'],mock_tests=1,installed_test_file='test_installed.py',installed_tests=1)
    def read_control(path,*a,**k):
        if Path(path)==collector.HERE/'preflight_expectations.json':return c.canonical(settings)
        return read(path,*a,**k)
    monkeypatch.setattr(collector.key_gate,'read',read_control)
    class Child:
        def __init__(self,command,**kwargs):
            self.pid=987654321;self.returncode=None;self.command=command;self.wait_calls=0
            assert kwargs['start_new_session'] and kwargs['umask']==0o077
            assert (kwargs['cwd']/'stub.py').read_bytes()==b'pass\n'
            self.xml=Path(next(x.split('=',1)[1] for x in command if x.startswith('--junitxml=')))
            events.append(('launch',self.xml.name))
        def wait(self,timeout=None):
            events.append(('wait',timeout));self.wait_calls+=1
            if failure=='cancel' and self.wait_calls==1:raise KeyboardInterrupt('parent wait cancellation')
            self.returncode=1 if failure=='child_nonzero' else -15 if failure=='cancel' else 0
            body='<failure message="failed"/>' if failure=='xml_failure' else ''
            self.xml.write_text('<testsuites><testsuite><testcase name="synthetic">'+body+'</testcase></testsuite></testsuites>')
            return self.returncode
        def poll(self):return self.returncode
    monkeypatch.setattr(collector.subprocess,'Popen',Child)
    monkeypatch.setattr(collector.os,'killpg',lambda pid,sig:events.append(('kill',pid,int(sig))))
    return events,expected


def test_parent_snapshot_two_independent_children_and_terminal(tmp_path,monkeypatch):
    events,expected=setup(monkeypatch);out=tmp_path/'proof'
    assert collector.collect(output=out,key_evidence=tmp_path/'key_evidence',key_workspace=tmp_path/'keys')==0
    report=json.loads((out/'report.json').read_bytes())
    assert report['passed'] and report['terminal_scope_completed'] and report['all_processes_reaped']
    assert report['source_hashes_start']==report['source_hashes_end']==expected
    assert report['source_archive_verified'] and report['no_encrypted_execution']
    assert len(report['children'])==2 and all(x['exit_code']==0 and x['reaped'] for x in report['children'])
    assert events[0]=='public_gate' and all(x[1] is None for x in events if isinstance(x,tuple) and x[0]=='wait')
    assert not any(x[0]=='kill' for x in events if isinstance(x,tuple))


@pytest.mark.parametrize('failure',['child_nonzero','xml_failure','cancel'])
def test_parent_failed_child_or_cancellation_never_publishes_success(tmp_path,monkeypatch,failure):
    events,expected=setup(monkeypatch,failure=failure);out=tmp_path/'proof'
    with pytest.raises(KeyboardInterrupt if failure=='cancel' else ValueError):
        collector.collect(output=out,key_evidence=tmp_path/'key_evidence',key_workspace=tmp_path/'keys')
    report=json.loads((out/'report.json').read_bytes())
    assert report['passed'] is False and report['terminal_scope_completed'] is False
    assert len(report['children'])==1 and report['children'][0]['reaped']
    if failure=='cancel':assert any(x[0]=='kill' for x in events if isinstance(x,tuple))
    else:assert not any(x[0]=='kill' for x in events if isinstance(x,tuple))


def test_public_gate_failure_never_spawns_child(tmp_path,monkeypatch):
    events,expected=setup(monkeypatch);out=tmp_path/'proof'
    def fail(*a,**k):raise ValueError('external key report not completed')
    monkeypatch.setattr(p,'authenticate_keys',fail)
    with pytest.raises(ValueError,match='key report'):collector.collect(output=out,key_evidence=tmp_path/'proof',key_workspace=tmp_path/'keys')
    report=json.loads((out/'report.json').read_bytes());assert report['passed'] is False and not report['children']
    assert not any(x[0]=='launch' for x in events if isinstance(x,tuple))


def test_source_snapshot_rejects_traversal(tmp_path):
    with pytest.raises(ValueError):collector.source_snapshot(tmp_path,{'../foreign.py':b'pass'})
    assert not (tmp_path/'foreign.py').exists()
