from pathlib import Path
import ast,os,sys,stat
import pytest
import component_contract as contract

def methods():
    tree=ast.parse(Path(__file__).with_name('component_protocol.py').read_text())
    nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('close','write')]
    ns=dict(Path=Path,os=os,sys=sys,stat=stat,contract=contract)
    exec(compile(ast.Module(body=nodes,type_ignores=[]),'unchanged_protocol_methods','exec'),ns)
    return ns

@pytest.mark.parametrize('cancellation',[KeyboardInterrupt,SystemExit])
def test_later_cleanup_only_cancellation_has_precedence(tmp_path,monkeypatch,cancellation):
    write=methods()['write'];original=os.close;regular=OSError('first close-only error');cancel=cancellation('later directory close cancellation');closed=[]
    def close(fd):
        info=os.fstat(fd);original(fd);closed.append(fd)
        if stat.S_ISREG(info.st_mode):raise regular
        raise cancel
    monkeypatch.setattr(os,'close',close)
    with pytest.raises(cancellation) as caught:write(tmp_path/'report.json',{'passed':True})
    assert caught.value is cancel and len(closed)==2 and len(set(closed))==2
