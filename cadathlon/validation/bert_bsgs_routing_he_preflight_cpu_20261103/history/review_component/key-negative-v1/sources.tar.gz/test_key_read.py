from pathlib import Path
import os
import pytest
import component_key_gate as gate

def test_fdopen_failure_has_no_lost_descriptor(tmp_path,monkeypatch):
    p=tmp_path/'public.json';p.write_bytes(b'{}')
    real_open=os.open;real_dup=os.dup;opened=[]
    def opening(*a,**k):
        fd=real_open(*a,**k);opened.append(fd);return fd
    def duplicate(*a,**k):
        fd=real_dup(*a,**k);opened.append(fd);return fd
    def failing(*a,**k):raise RuntimeError('failed fdopen handoff')
    with monkeypatch.context() as m:
        m.setattr(os,'open',opening);m.setattr(os,'dup',duplicate);m.setattr(os,'fdopen',failing)
        with pytest.raises(RuntimeError,match='failed fdopen'):gate.read(p)
    leaked=[]
    for fd in opened:
        try:os.fstat(fd)
        except OSError:continue
        leaked.append(fd);os.close(fd)
    assert not leaked,'lost descriptors: '+repr(leaked)

