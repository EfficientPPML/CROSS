"""Three synthetic lifecycle negatives of exact reviewed draft; no HE."""
from pathlib import Path
from contextlib import contextmanager
from types import SimpleNamespace
import os
import sys
import numpy as np
import pytest
import component_transport as transport


@pytest.fixture
def tiny(monkeypatch):
    binding=dict(context_id='a'*64,request_id='b'*32,role='request',tile_index=0,
        shape=(1,2,1,2,2),moduli=[17,19],layout=[1,2],scale=10.)
    class Polynomial:
        shape=binding['shape'];degree_layout=(1,2);precision=32;_ckks_nsd=1;_ckks_scale=10.
        def validate(self):pass
        def get_moduli(self):return binding['moduli']
    def writer(ct,directory):
        (directory/'bundle.json').write_bytes(transport._canonical({'shape':{'__ct__':0},'count':1}))
        np.savez(directory/'ct_0.npz',payload=np.ones(binding['shape'],dtype=np.uint32),
            moduli=np.array([17,19],dtype=np.int64),degree_layout=np.array([1,2],dtype=np.int64),
            precision=np.array(32,dtype=np.int64),nsd=np.array(1,dtype=np.int64),scale=np.array(10.,dtype=np.float64))
    monkeypatch.setattr(transport,'ciphertext_contract',lambda *a,**k:dict(binding))
    monkeypatch.setitem(sys.modules,'jaxite_word',SimpleNamespace(Polynomial=Polynomial))
    monkeypatch.setitem(sys.modules,'bundle_io',SimpleNamespace(save_bundle=writer))
    return Polynomial()


def test_read_primary_cancellation_survives_descriptor_close_error(tmp_path,monkeypatch):
    path=tmp_path/'value';path.write_bytes(b'value');real_close=os.close
    @contextmanager
    def read_failure(*args,**kwargs):
        raise KeyboardInterrupt('primary read interruption')
        yield
    def close_failure(fd):
        real_close(fd);raise OSError('later descriptor close failure')
    with monkeypatch.context() as m:
        m.setattr(os,'fdopen',read_failure);m.setattr(os,'close',close_failure)
        with pytest.raises(KeyboardInterrupt,match='primary read'):
            transport._read_regular(path,64)


def test_writer_fdopen_handoff_failure_does_not_leak_fd(tmp_path,monkeypatch,tiny):
    original_open=os.open;original_fdopen=os.fdopen;owned=[]
    def opened(path,*args,**kwargs):
        fd=original_open(path,*args,**kwargs)
        if path=='.transport.tmp':owned.append(fd)
        return fd
    def fail_handoff(fd,*args,**kwargs):
        if args and args[0]=='wb':raise RuntimeError('fdopen before ownership transfer')
        return original_fdopen(fd,*args,**kwargs)
    with monkeypatch.context() as m:
        m.setattr(os,'open',opened);m.setattr(os,'fdopen',fail_handoff)
        with pytest.raises(RuntimeError,match='fdopen before'):
            transport.save_ciphertext(tiny,tmp_path/'tile',contract={},role='request',tile_index=0)
    assert len(owned)==1
    try:
        try:os.fstat(owned[0]);leaked=True
        except OSError:leaked=False
        assert not leaked,'temporary descriptor remained open after failed handoff'
    finally:
        if leaked:os.close(owned[0])


def test_failed_writer_retains_partial_tile_without_recursive_removal(tmp_path,monkeypatch,tiny):
    import shutil
    target=tmp_path/'tile'
    def writer_failure(ct,path):
        (path/'partial').write_bytes(b'owned partial');raise RuntimeError('primary writer failure')
    def forbidden(*a,**k):raise AssertionError('recursive cleanup must never run')
    monkeypatch.setitem(sys.modules,'bundle_io',SimpleNamespace(save_bundle=writer_failure))
    monkeypatch.setattr(shutil,'rmtree',forbidden)
    with pytest.raises(RuntimeError,match='primary writer') as found:
        transport.save_ciphertext(tiny,target,contract={},role='request',tile_index=0)
    assert (target/'partial').read_bytes()==b'owned partial'
    assert any('quarantine' in n for n in found.value.__notes__)


def test_writer_failure_replacement_keeps_original_and_foreign(tmp_path,monkeypatch,tiny):
    target=tmp_path/'tile';moved=tmp_path/'original'
    def writer_failure(ct,path):
        (path/'partial').write_bytes(b'owned partial');path.rename(moved)
        path.mkdir();(path/'foreign').write_bytes(b'foreign replacement')
        raise RuntimeError('primary writer replacement')
    monkeypatch.setitem(sys.modules,'bundle_io',SimpleNamespace(save_bundle=writer_failure))
    with pytest.raises(RuntimeError,match='primary writer replacement') as found:
        transport.save_ciphertext(tiny,target,contract={},role='request',tile_index=0)
    assert (moved/'partial').read_bytes()==b'owned partial'
    assert (target/'foreign').read_bytes()==b'foreign replacement'
    assert any('quarantine' in n for n in found.value.__notes__)
