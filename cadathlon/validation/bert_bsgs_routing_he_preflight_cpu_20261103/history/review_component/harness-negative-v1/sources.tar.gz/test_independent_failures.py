import os,sys,json,signal,ctypes,subprocess
from pathlib import Path
from types import ModuleType
import numpy as np
import pytest
import component_worker as w
import component_contract as c
import collect_component as collector
from test_component_worker import orchestration,Value
from test_collect_component import setup


def test_finite_extreme_decode_retains_serializable_failure(tmp_path,monkeypatch):
    cfg,keys,events,stored=orchestration(monkeypatch,tmp_path);fixture={}
    w.fixture(cfg,keys,b'profile',b'plan',fixture,lambda:None)
    oracle=w.public_oracle();x,_=oracle.fixture_arrays();proof=c.numerical_plan()
    def exercise(ctx,source,ones,*,checkpoint):
        i=0
        for case in proof['cases']:
            forward=oracle.oracle(x,gain=case['gain'])
            answers={'forward':forward,'roundtrip_inverse':oracle.oracle(forward['key placement'],inverse=True),'hostile_inverse':oracle.oracle(x,inverse=True)}
            for row in case['checkpoints']:
                slots=answers[row['direction']][row['label']].copy()
                if i==0:slots[:]=np.finfo(np.float64).max
                checkpoint(i,Value(slots,events),{n:row[n] for n in ('direction','label','level','scale','counts')}|dict(case=case['name']));i+=1
        return {}
    fake=ModuleType('component_arithmetic');fake.exercise=exercise;monkeypatch.setitem(sys.modules,'component_arithmetic',fake)
    server={};w.server(cfg,keys,b'profile',b'plan',server,lambda:None,{'fixture':fixture})
    report={}
    with np.errstate(over='ignore',invalid='ignore'):
        with pytest.raises(ValueError):w.validate(cfg,keys,b'profile',b'plan',report,lambda:c.canonical(report),{'fixture':fixture,'server':server})
    assert report['numeric_checkpoints'][0]['passed'] is False
    c.canonical(report)


def test_exited_leader_cannot_leave_live_descendants_and_report_success(tmp_path,monkeypatch):
    real_popen=subprocess.Popen;leaders=[]
    libc=ctypes.CDLL(None,use_errno=True);previous=ctypes.c_int()
    assert libc.prctl(37,ctypes.byref(previous),0,0,0)==0
    assert libc.prctl(36,1,0,0,0)==0
    setup(monkeypatch)
    def spawn(command,**kwargs):
        xml=next(x.split('=',1)[1] for x in command if x.startswith('--junitxml='))
        pidfile=tmp_path/('descendant'+str(len(leaders)))
        script="import subprocess,sys;from pathlib import Path;child=subprocess.Popen([sys.executable,'-c','import time;time.sleep(60)']);Path(sys.argv[1]).write_text(str(child.pid));Path(sys.argv[2]).write_text('<testsuites><testsuite><testcase name=\"owned\"/></testsuite></testsuites>')"
        p=real_popen([sys.executable,'-c',script,str(pidfile),xml],**kwargs);leaders.append((p,pidfile));return p
    monkeypatch.setattr(collector.subprocess,'Popen',spawn)
    try:
        out=tmp_path/'report';collector.collect(output=out,key_evidence=tmp_path/'public',key_workspace=tmp_path/'keys')
        r=json.loads((out/'report.json').read_bytes())
        for _,pidfile in leaders:os.kill(int(pidfile.read_text()),0)
        assert not r['passed'],'leader-only completion falsely reports all_processes_reaped=True with live owned descendants'
    finally:
        for p,pidfile in leaders:
            if pidfile.exists():
                pid=int(pidfile.read_text())
                try:os.kill(pid,signal.SIGKILL)
                except ProcessLookupError:pass
                try:os.waitpid(pid,0)
                except ChildProcessError:pass
            if p.poll() is None:p.kill()
            p.wait()
        assert libc.prctl(36,previous.value,0,0,0)==0
