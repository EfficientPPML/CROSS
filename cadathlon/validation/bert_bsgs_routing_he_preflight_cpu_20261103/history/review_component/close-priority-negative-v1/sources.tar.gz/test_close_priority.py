"""Three synthetic lifecycle negatives of exact reviewed draft; no HE."""
from pathlib import Path
from contextlib import contextmanager
from types import SimpleNamespace
import os
import sys
import numpy as np
import pytest
import component_transport as transport


@pytest.fixture
def tiny(monkeypatch):
    binding=dict(context_id='a'*64,request_id='b'*32,role='request',tile_index=0,
        shape=(1,2,1,2,2),moduli=[17,19],layout=[1,2],scale=10.)
    class Polynomial:
        shape=binding['shape'];degree_layout=(1,2);precision=32;_ckks_nsd=1;_ckks_scale=10.
        def validate(self):pass
        def get_moduli(self):return binding['moduli']
    def writer(ct,directory):
        (directory/'bundle.json').write_bytes(transport._canonical({'shape':{'__ct__':0},'count':1}))
        np.savez(directory/'ct_0.npz',payload=np.ones(binding['shape'],dtype=np.uint32),
            moduli=np.array([17,19],dtype=np.int64),degree_layout=np.array([1,2],dtype=np.int64),
            precision=np.array(32,dtype=np.int64),nsd=np.array(1,dtype=np.int64),scale=np.array(10.,dtype=np.float64))
    monkeypatch.setattr(transport,'ciphertext_contract',lambda *a,**k:dict(binding))
    monkeypatch.setitem(sys.modules,'jaxite_word',SimpleNamespace(Polynomial=Polynomial))
    monkeypatch.setitem(sys.modules,'bundle_io',SimpleNamespace(save_bundle=writer))
    return Polynomial()


@pytest.mark.parametrize('cancel',[KeyboardInterrupt,SystemExit])
@pytest.mark.parametrize('site',['read','write'])
def test_cleanup_only_cancellation_supersedes_prior_close(tmp_path,monkeypatch,tiny,cancel,site):
    target=tmp_path/'tile';real_close=os.close;real_fdopen=os.fdopen;opened_write=[];active=[]
    def fdopen(fd,*a,**kw):
        if a and a[0]=='wb':opened_write.append(fd)
        return real_fdopen(fd,*a,**kw)
    def close(fd):
        real_close(fd)
        if site=='write' and not opened_write:return
        active.append(fd)
        if len(active)==1:raise OSError('first cleanup failure')
        raise cancel('later cleanup cancellation')
    with monkeypatch.context() as m:
        m.setattr(os,'fdopen',fdopen);m.setattr(os,'close',close)
        with pytest.raises(cancel,match='later cleanup'):
            transport.save_ciphertext(tiny,target,contract={},role='request',tile_index=0)
    assert len(active)==2 and target.is_dir()
