import hashlib,json,os,time
from pathlib import Path
import pytest
lab=Path(__file__).resolve().parent;root=Path('/home/jianming_gatech/CROSS')
paths=list((root/'jaxite_word').glob('*.py'))+list((root/'cadathlon/common').glob('*.py'))+list(lab.glob('*.py'))
def hashes():return {str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
before=hashes();start=time.perf_counter()
code=pytest.main(['-q','-s',str(lab/'test_tensor_only.py')])
import test_tensor_only
report=dict(passed=code==0,scope='isolated CPU secure raw tensor and actual Bootstrap multiply-dispatch parity; no complete bootstrap/TPU or model speed claim',
    elapsed_s=time.perf_counter()-start,records=test_tensor_only.RECORDS,source_sha256=before,source_unchanged=before==hashes(),jax_platforms=os.environ['JAX_PLATFORMS'])
(lab/'report.json').write_text(json.dumps(report,indent=2)+'\n')
raise SystemExit(code)
