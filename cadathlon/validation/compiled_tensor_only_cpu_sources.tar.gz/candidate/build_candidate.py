from pathlib import Path
root=Path('/home/jianming_gatech/CROSS/cadathlon/common')
lab=Path(__file__).resolve().parent
primitive=root.joinpath('encrypted_primitives.py').read_text()
primitive+='''

class CompiledTensorOnly:
    """Exact three-component tensor product, without key switching or rescale.

    Public finite-field controls are taken from the initialized parameter cache;
    no multiplication facade or evaluation-key controls are constructed here.
    The canonical core tensor kernel remains the arithmetic implementation.
    """
    def __init__(self, context):
        EncryptedPolynomialEvaluator(context)
        self.ctx = context
        self.compiler = ExplicitArrayCompiler()
        self.binding = None

    def clear(self, *, executables=False):
        self.binding = None
        if executables:
            self.compiler.clear_executables()

    def multiply(self, left, right):
        import jax
        import jax.numpy as jnp
        import finite_field
        from polynomial import Polynomial
        from types import SimpleNamespace
        from support import require_secure_execution

        require_secure_execution(self, (left, right))
        cache = self.ctx._param_cache
        level = cache.level_for_num_q(left.num_moduli)
        if level < 1:
            raise ValueError('tensor-only product requires at least level one')
        for value in (left, right):
            finite_field.check_ct_operand(cache.ff_context_cls, cache.num_q_at_level(level), value,
                'compiled tensor-only product', batch=cache.batch, num_elements=2,
                degree_layout=cache.degree_layout, moduli=cache.q_moduli_at_level(level))
        scales = [getattr(value, '_ckks_scale', None) for value in (left, right)]
        if any(scale is not None and (not math.isfinite(scale) or scale <= 0) for scale in scales):
            raise ValueError('tensor-only product requires finite positive tracked scales')
        scale = None if None in scales else scales[0] * scales[1]
        if scale is not None and (not math.isfinite(scale) or scale <= 0):
            raise ValueError('tensor-only product scale is outside floating-point range')
        nsds = [getattr(value, '_ckks_nsd', 1) for value in (left, right)]
        if any(type(nsd) is not int or nsd < 1 for nsd in nsds):
            raise ValueError('tensor-only product requires positive integer noise-scale degrees')
        devices = left.polynomial.devices()
        if len(devices) != 1 or devices != right.polynomial.devices():
            raise ValueError('tensor-only operands must share one physical device')
        device = next(iter(devices))
        signature = ('tensor-only', level, tuple(left.shape), device)
        if self.binding is None or self.binding[0] != signature:
            field = cache.get_sliced_ff_q(level)
            def tensor(a, b):
                shell = SimpleNamespace(polynomial=jnp.concatenate((a, b), axis=1),
                    ntt_ctx=SimpleNamespace(ff_ctx=field), modulus_dtype=jnp.uint32)
                first, last = Polynomial._polynomial_mult_array(shell)
                return jnp.concatenate((first, last), axis=1).astype(jnp.uint32)
            binding = self.compiler.bind(tensor, (left.polynomial, right.polynomial),
                                         signature=signature, device=device)
            self.binding = (signature, binding)
        result = left._clone_with_payload(self.binding[1](left.polynomial, right.polynomial),
                                          num_elements=3)
        result.__dict__.pop('_ckks_scale', None)
        if scale is not None:
            result._ckks_scale = scale
        result._ckks_nsd = sum(nsds)
        jax.block_until_ready(result.polynomial)
        return result
'''
lab.joinpath('encrypted_primitives.py').write_text(primitive)
refresh=root.joinpath('encrypted_refresh.py').read_text()
start=refresh.index('class _Operation:')
end=refresh.index('\n\nclass BoundedSecureRefresh',start)
refresh=refresh[:start]+'''class _Operation:
    """Delegate only unmodified attributes to the original eager facade."""
    def __init__(self, original, **overrides):
        self.original, self.overrides = original, overrides

    def __getattr__(self, name):
        if name in self.overrides:
            return self.overrides[name]
        return getattr(self.original(), name)


class _Accessor:
    def __init__(self, original, bind):
        self.original, self.bind = original, bind

    def __getitem__(self, key):
        return self.bind(key, lambda: self.original[key])

    def __getattr__(self, name):
        return getattr(self.original, name)


def _install_compiled_primitives(engine, context):
    """Bind compiled operations only on this engine's private context view."""
    from encrypted_primitives import (CompiledRelinearization, CompiledRescale,
                                     CompiledPlaintextMultiply, CompiledTensorOnly)
    from encrypted_rotation import CompiledRotation
    rotations = CompiledRotation(context)
    relinearization = CompiledRelinearization(context)
    rescale = CompiledRescale(context)
    plaintext = CompiledPlaintextMultiply(context)
    tensor = CompiledTensorOnly(context)

    def bind_rotation(key, original):
        level, index = key
        def rotate(value):
            if context._param_cache.level_for_num_q(value.num_moduli) != level:
                raise ValueError('rotation level differs from bound accessor')
            return rotations.rotate(value, index)
        return _Operation(original, rotate=rotate)

    def bind_multiply(level, original):
        cache = context._param_cache
        if type(level) is not int or not 0 <= level < cache.max_level:
            raise ValueError('compiled multiply output level must be below the maximum level')
        def relinearize(value):
            if cache.level_for_num_q(value.num_moduli) != level + 1:
                raise ValueError('relinearization level differs from bound accessor')
            return relinearization.relinearize(value)
        def multiply(left, right):
            if cache.level_for_num_q(left.num_moduli) != level + 1:
                raise ValueError('tensor-product level differs from bound accessor')
            return tensor.multiply(left, right)
        return _Operation(original, relinearize=relinearize, hemul_no_relin=multiply,
                          input_num_moduli=cache.num_q_at_level(level + 1))

    engine.ctx._he_rot = _Accessor(context.he_rot, bind_rotation)
    engine.ctx._he_mul = _Accessor(context.he_mul, bind_multiply)
    engine.ctx._he_rescale = _Accessor(context.he_rescale,
        lambda key, original: _Operation(original, rescale=lambda value: rescale.rescale(value, *key)))
    engine.ctx._ptct_mul = _Accessor(context.ptct_mul,
        lambda level, original: _Operation(original, _mul_encoded=
            lambda value, encoded: plaintext.multiply_encoded(value, encoded, level)))
    return rotations, relinearization, rescale, plaintext, tensor
'''+refresh[end:]
lab.joinpath('encrypted_refresh.py').write_text(refresh)
