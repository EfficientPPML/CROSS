"""Stdlib-only fresh-process source closure gate; no local runtime imports."""
from pathlib import Path
import hashlib,json,os,stat,sys
EXPECTED_NAMES=('READERS.md', 'README_CLIENT.md', 'baseline/client_keys.py', 'baseline/file_stage_io.py', 'baseline/file_stages.py', 'baseline/input_gate.py', 'baseline/key_contexts.py', 'baseline/key_gate.py', 'baseline/request_lifecycle.py', 'baseline/transport.py', 'boundaries.py', 'cleanup.py', 'client_89_report.json', 'client_89_sources.json', 'client_bootstrap.py', 'client_installed_probe.py', 'client_io.py', 'client_metrics.py', 'client_preflight.py', 'client_processes.py', 'client_readback.py', 'client_source_guard.py', 'collect.py', 'dependencies.json', 'dependencies.py', 'input_gate.py', 'installed_guard_probe.py', 'key_gate.py', 'key_source_manifest.json', 'model_gate.py', 'original_client_collect.py', 'original_client_readback.py', 'original_client_worker.py', 'original_public_readback.py', 'preflight.py', 'reference_gate.py', 'runtime/check_transformer_suite.py', 'runtime/cleanup.py', 'runtime/collect.py', 'runtime/jaxite_word/__init__.py', 'runtime/jaxite_word/bconv.py', 'runtime/jaxite_word/bootstrapping.py', 'runtime/jaxite_word/bootstrapping_openfhe_crosscheck.py', 'runtime/jaxite_word/bsgs.py', 'runtime/jaxite_word/ckks_ctx.py', 'runtime/jaxite_word/composite_prime_gen.py', 'runtime/jaxite_word/finite_field.py', 'runtime/jaxite_word/he_ops.py', 'runtime/jaxite_word/he_params.py', 'runtime/jaxite_word/headd.py', 'runtime/jaxite_word/hemul.py', 'runtime/jaxite_word/herot.py', 'runtime/jaxite_word/hesub.py', 'runtime/jaxite_word/key_gen.py', 'runtime/jaxite_word/mapping.py', 'runtime/jaxite_word/nn.py', 'runtime/jaxite_word/ntt_mm.py', 'runtime/jaxite_word/ntt_sm.py', 'runtime/jaxite_word/packing.py', 'runtime/jaxite_word/pedagagy/bat.py', 'runtime/jaxite_word/pedagagy/modular_reduction.py', 'runtime/jaxite_word/pedagagy/ntt.py', 'runtime/jaxite_word/pedagagy/util.py', 'runtime/jaxite_word/polynomial.py', 'runtime/jaxite_word/profiler.py', 'runtime/jaxite_word/ptct_mul.py', 'runtime/jaxite_word/rescale.py', 'runtime/jaxite_word/rns.py', 'runtime/jaxite_word/tabIX.py', 'runtime/jaxite_word/tabV.py', 'runtime/jaxite_word/tabVI.py', 'runtime/jaxite_word/tabVII.py', 'runtime/jaxite_word/util.py', 'runtime/preflight.py', 'runtime/stage/bundle_io.py', 'runtime/stage/client_inputs.py', 'runtime/stage/client_keys.py', 'runtime/stage/file_stage_contract.py', 'runtime/stage/file_stage_io.py', 'runtime/stage/file_stages.py', 'runtime/stage/full_model_engine.py', 'runtime/stage/key_contexts.py', 'runtime/stage/p60_profile_and_refresh.json', 'runtime/stage/request_lifecycle.py', 'runtime/stage/response_scale.py', 'runtime/stage/server_inputs/candidate_manifest.json', 'runtime/stage/server_inputs/p60_profile_and_refresh.json', 'runtime/stage/server_inputs/twelve_layer_plan.json', 'runtime/stage/server_public_model.py', 'runtime/stage/server_tensor_pins.json', 'runtime/stage/support.py', 'runtime/stage/transport.py', 'runtime/stage/transport_contract.py', 'runtime/test_collector.py', 'runtime/worker.py', 'source_origin.json', 'stage3_gate.py', 'stage3_source_manifest.json', 'stage4_gate.py', 'stage4_source_manifest.json', 'terminal.py', 'test_boundaries.py', 'test_client_bootstrap.py', 'test_client_descriptor_io.py', 'test_client_io.py', 'test_client_metrics.py', 'test_client_source_guard.py', 'test_collector.py', 'test_original_client_collect.py', 'test_original_client_readback.py', 'test_original_client_worker.py', 'test_original_default.py', 'test_original_transport_io.py', 'test_prerequisite_readers.py', 'test_readback.py', 'test_receipt_io.py', 'test_reference_gate.py', 'test_stage3_gate.py', 'test_stage4_gate.py', 'test_terminal_main.py', 'test_worker.py', 'worker.py')

def read(path,maximum):
 path=Path(path);fd=None;primary=None
 try:
  before=path.lstat()
  if not stat.S_ISREG(before.st_mode)or not 0<before.st_size<=maximum:raise ValueError('bounded source file required')
  fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK);opened=os.fstat(fd)
  state=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
  if state(before)!=state(opened):raise ValueError('source replaced before open')
  chunks=[];left=maximum+1
  while left:
   block=os.read(fd,min(left,1<<20))
   if not block:break
   chunks.append(block);left-=len(block)
  raw=b''.join(chunks)
  if len(raw)!=before.st_size or len(raw)>maximum or state(os.fstat(fd))!=state(before)or state(path.lstat())!=state(before):raise ValueError('source changed during read')
  return raw
 except BaseException as error:primary=error;raise
 finally:
  if fd is not None:
   try:os.close(fd)
   except BaseException as error:
    if primary is None:raise
    if error is not primary:primary.add_note('bootstrap descriptor close: '+repr(error))

def verify(root,expected,*,fresh=True):
 root=Path(root).resolve()
 if type(expected)is not dict or set(expected)!=set(EXPECTED_NAMES):raise ValueError('exact explicit successor source inventory required')
 # Undeclared modules can shadow otherwise external imports after sys.path is
 #installed. Reject source, bytecode and native-extension shadows first.
 for path in root.rglob('*'):
  if path.is_symlink():raise ValueError('source tree symlink rejected')
  if path.is_file()and path.suffix in ('.py','.pyc','.pyo','.so','.pyd')and path.relative_to(root).as_posix()not in expected:
   raise ValueError('unexpected importable source/cache file: '+path.relative_to(root).as_posix())
 local_names=set()
 for name,sha in expected.items():
  p=Path(name)
  if p.is_absolute()or '..'in p.parts or p.as_posix()!=name:raise ValueError('relative source required')
  path=root/p
  for parent in (path,*path.parents):
   if parent==root:break
   if parent.is_symlink():raise ValueError('source symlink rejected')
  raw=read(path,16<<20)
  if type(sha)is not str or hashlib.sha256(raw).hexdigest()!=sha:raise ValueError('externally bound source differs: '+name)
  if p.suffix=='.py'and (len(p.parts)==1 or p.parent in (Path('runtime/stage'),Path('runtime/jaxite_word'),Path('runtime'))):
   local_names.add(p.stem)
   if p.parent==Path('runtime/jaxite_word'):local_names.add('jaxite_word'if p.stem=='__init__'else'jaxite_word.'+p.stem)
 if fresh:
  for name,module in tuple(sys.modules.items()):
   if name in local_names and name!='client_bootstrap':raise ValueError('local helper already loaded before fresh source gate: '+name)
   for origin in (getattr(module,'__file__',None),getattr(getattr(module,'__spec__',None),'origin',None)):
    if not origin or origin in ('built-in','frozen'):continue
    path=Path(origin).resolve()
    if path.is_relative_to(root):
     if name=='client_bootstrap'and path==root/'client_bootstrap.py':continue
     if name=='__main__'and path in (root/'original_client_worker.py',root/'original_client_collect.py'):continue
     raise ValueError('local origin already loaded under alias before fresh source gate: '+name)
 return dict(passed=True,fresh=fresh,source_count=len(expected),source_hashes=expected,local_runtime_imported=False)
