"""Actual gate read AST on synthetic owned files; never real prerequisites."""
from pathlib import Path
from types import SimpleNamespace
import ast,hashlib,os,stat,sys,pytest
HERE=Path(__file__).resolve().parent

def namespace():
 fake=SimpleNamespace(**{n:getattr(os,n)for n in dir(os)})
 ns=dict(os=fake,stat=stat,sys=sys,Path=Path,MAXIMUM=8<<20,_READ_FAILURES=[])
 tree=ast.parse((HERE/'key_gate.py').read_bytes())
 selected=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in ('read','_read_descriptor')]
 exec(compile(ast.Module(body=selected,type_ignores=[]),'<actual prerequisite reader>','exec'),ns)
 return ns,fake

def private_block(ns):
 tree=ast.parse((HERE/'input_gate.py').read_bytes());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='authenticate')
 start=next(i for i,n in enumerate(fn.body)if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id in ('fd','input_bytes')for t in n.targets))
 body=fn.body[start:-1]+[ast.Return(ast.Name('input_bytes',ast.Load()))]
 func=ast.parse('def private(input_path,files):\n pass\n').body[0];func.body=body
 ns.update(key_gate=SimpleNamespace(digest=lambda raw:hashlib.sha256(raw).hexdigest(),_read_descriptor=ns.get('_read_descriptor')),INPUT='synthetic')
 exec(compile(ast.fix_missing_locations(ast.Module(body=[func],type_ignores=[])),'<actual private gate suffix>','exec'),ns)
 return ns['private']

@pytest.mark.parametrize('branch',['public','private'])
def test_actual_readers_need_no_fdopen_handoff(tmp_path,branch):
 ns,fake=namespace();p=tmp_path/'metadata';raw=b'{"synthetic":true}\n';p.write_bytes(raw);p.chmod(0o600);duplicates=[]
 def dup(fd):new=os.dup(fd);duplicates.append(new);return new
 def forbidden(*a,**k):raise RuntimeError('fdopen handoff injection')
 fake.dup=dup;fake.fdopen=forbidden
 try:
  value=ns['read'](p)if branch=='public'else private_block(ns)(p,{'synthetic':hashlib.sha256(raw).hexdigest()})
  assert value==raw and not duplicates
 finally:
  for fd in duplicates:
   try:os.close(fd)
   except OSError:pass

@pytest.mark.parametrize('branch',['public','private'])
@pytest.mark.parametrize('kind',[ValueError,KeyboardInterrupt,SystemExit])
def test_fstat_primary_is_not_masked_by_close(tmp_path,branch,kind):
 ns,fake=namespace();p=tmp_path/'metadata';p.write_bytes(b'{}');p.chmod(0o600);primary=kind('fstat body');closed=[]
 def fstat(fd):raise primary
 def close(fd):os.close(fd);closed.append(fd);raise OSError('close after primary')
 fake.fstat=fstat;fake.close=close
 with pytest.raises(kind)as got:
  ns['read'](p)if branch=='public'else private_block(ns)(p,{'synthetic':hashlib.sha256(b'{}').hexdigest()})
 assert got.value is primary and len(closed)==1
