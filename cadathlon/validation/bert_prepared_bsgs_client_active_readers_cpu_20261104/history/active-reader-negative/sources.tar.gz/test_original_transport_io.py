"""Actual selected transport reader bodies on synthetic descriptors only."""
from pathlib import Path
from types import SimpleNamespace
import ast,os,stat,sys,hashlib,pytest
HERE=Path(__file__).resolve().parent

def env():
 fake=SimpleNamespace(**{n:getattr(os,n)for n in dir(os)})
 ns=dict(os=fake,sys=sys,stat=stat,Path=Path,_IO_FAILURE_QUARANTINE=[])
 tree=ast.parse((HERE/'runtime/stage/client_keys.py').read_bytes())
 exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.ClassDef)and n.name=='_CloseState'],type_ignores=[]),'<actual close state>','exec'),ns)
 tree=ast.parse((HERE/'runtime/stage/transport.py').read_bytes());names={'_read_regular','_open_directory','_close','validate_ciphertext'}
 exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in names],type_ignores=[]),'<actual transport readers>','exec'),ns)
 return ns,fake

@pytest.mark.parametrize('kind',[ValueError,KeyboardInterrupt,SystemExit])
def test_reader_body_survives_final_close(tmp_path,kind):
 ns,fake=env();p=tmp_path/'public';p.write_bytes(b'{}');primary=kind('stat body');closed=[]
 def fail(fd):raise primary
 def close(fd):os.close(fd);closed.append(fd);raise OSError('close')
 fake.fstat=fail;fake.close=close
 with pytest.raises(kind)as got:ns['_read_regular'](p,1024)
 assert got.value is primary and len(closed)==1

@pytest.mark.parametrize('kind',[KeyboardInterrupt,SystemExit])
def test_validate_cleanup_only_cancel_crosses_inner_reader(tmp_path,kind):
 ns,fake=env();d=tmp_path/'public';d.mkdir();(d/'transport.json').write_bytes(b'{}');cancel=kind('outer directory close');seen=[]
 ns.update(ciphertext_contract=lambda *a:{},FILES={'transport.json'},MAX_JSON_BYTES=1024)
 def close(fd):
  is_dir=stat.S_ISDIR(os.fstat(fd).st_mode);os.close(fd);seen.append(is_dir)
  if is_dir:raise cancel
  raise OSError('inner file close')
 fake.close=close
 with pytest.raises(kind)as got:ns['validate_ciphertext'](d,contract={},role='response',tile_index=0)
 assert got.value is cancel and seen==[False,True]
