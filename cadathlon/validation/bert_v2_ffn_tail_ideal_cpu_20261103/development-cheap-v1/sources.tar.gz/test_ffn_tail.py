"""Full-width actual-loop ideal FFN composition; no encrypted execution."""
from collections import Counter
from pathlib import Path
import ast,json,math,sys,time
from types import SimpleNamespace
from typing import Sequence,Tuple
import numpy as np
import pytest
from scipy.special import erf
from test_initial_ideal import ideal_primitives
from test_softmax_tile import refresh_and_tracked,IdentityRefresh as BaseRefresh
from ideal_primitives import Arithmetic,Value,IdealLinear,install_matrix_class,DELTA
from encrypted_bert_v2_ffn import BertV2FFNTile,TENSORS
from encrypted_bert_v2_row_norm import V2RowLayerNorm
from ffn_public_fixtures import load
HERE=Path(__file__).resolve().parent;RAW=(HERE/'candidate_manifest.json').read_bytes();MANIFEST=json.loads(RAW)

class IdentityRefresh(BaseRefresh):
    public_bound=128.
    def __init__(self,arithmetic):
        super().__init__(arithmetic)
        from encrypted_refresh import refresh_plan
        self.plan=refresh_plan(131072,65536,(4,4),max_level=49)
        def forbidden(*args,**kwargs):raise AssertionError('compiled crypto helper invoked in identity-refresh ideal test')
        self.compiled_primitives=tuple(SimpleNamespace(ctx=arithmetic.ctx,**{name:forbidden})
            for name in ('rotate','relinearize','rescale','multiply_encoded','multiply'))
    def refresh(self,value,*,public_bound):
        assert public_bound in (128.,16.) and value.level>=2
        self.calls.append((value.level,value._ckks_scale,public_bound))
        result=Value(value.data,self.output_level,math.nextafter(DELTA,math.inf if len(self.calls)%2 else -math.inf))
        if self.inject is not None:self.inject(value,result)
        return result

@pytest.fixture(autouse=True)
def primitives(refresh_and_tracked,monkeypatch):
    install_matrix_class(monkeypatch)
    # Evaluate the unchanged backend-free public rotation/depth methods, rather
    # than accepting a self-reported fake plan or importing the HE backend.
    tree=ast.parse((HERE/'checkout/jaxite_word/bootstrapping.py').read_text())
    names={'_select_layers','_reduce_rotation','_collapsed_hoisted_plan','_bootstrap_rotation_indices'}
    nodes=[node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in names]
    original=next(node for node in tree.body if isinstance(node,ast.ClassDef) and node.name=='Bootstrap')
    methods=[node for node in original.body if isinstance(node,ast.FunctionDef) and node.name in ('compute_bootstrap_nq','required_rotation_indices')]
    namespace=dict(math=math,Sequence=Sequence,Tuple=Tuple)
    stub=ast.ClassDef(name='Bootstrap',bases=[],keywords=[],body=methods,decorator_list=[],type_params=[])
    exec(compile(ast.fix_missing_locations(ast.Module(body=nodes+[stub],type_ignores=[])),'exact_public_bootstrap_plan','exec'),namespace)
    monkeypatch.setitem(sys.modules,'jaxite_word.bootstrapping',SimpleNamespace(Bootstrap=namespace['Bootstrap']))

def test_actual_public_refresh_plan_matches_archived_profile():
    from encrypted_refresh import refresh_plan
    expected=json.loads((HERE/'p60_profile_and_refresh.json').read_text())['refresh_plan']
    actual=refresh_plan(131072,65536,(4,4),max_level=49)
    assert json.loads(json.dumps(actual))==expected
    assert type(actual['level_budget'])is tuple and type(actual['rotations'])is tuple

@pytest.fixture(scope='module')
def arrays():
    result,report=load();(HERE/'fixture_pins.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');return result

def setup(arrays,positions,progress=None):
    arithmetic=Arithmetic();linear=IdealLinear(arithmetic);refresh=IdentityRefresh(arithmetic)
    model={n:arrays[n] for n in TENSORS}
    keys=set(V2RowLayerNorm.required_rotation_indices())
    for name in ('intermediate','output'):keys.update(linear.required_rotation_indices(model[name+'.weight'],linear.layout))
    cache=arithmetic.ctx._param_cache
    for key in keys:cache.raw_rotation_keys[key]={'a':object(),'b':object()};cache.coef_maps[key]=object()
    owner=BertV2FFNTile(arithmetic,linear,refresh,model,RAW,arrays['gamma'],arrays['beta'],original_positions=positions,progress=progress)
    return owner,arithmetic,refresh

def independent(x,arrays,*,approximate):
    middle=x@arrays['intermediate.weight'].T+arrays['intermediate.bias']
    gelu=MANIFEST['gelu']['0']['polynomial'];lo,hi=gelu['domain']
    assert np.all((middle>=lo)&(middle<=hi))
    if approximate:activated=np.polynomial.chebyshev.chebval((2/(hi-lo))*middle-(hi+lo)/(hi-lo),gelu['coefficients'])
    else:activated=.5*middle*(1+erf(middle/np.sqrt(2.)))
    dense=activated@arrays['output.weight'].T+arrays['output.bias'];residual=dense+x
    centered=residual-residual.mean(axis=-1,keepdims=True);variance=np.mean(centered*centered,axis=-1,keepdims=True)+1e-12
    rule=MANIFEST['norms']['0.mlp']['polynomial'];lo,hi=rule['domain']
    assert np.all((variance>=lo)&(variance<=hi))
    inverse=np.polynomial.chebyshev.chebval((2/(hi-lo))*variance-(hi+lo)/(hi-lo),rule['coefficients']) if approximate else 1/np.sqrt(variance)
    return dict(middle=middle,activated=activated,dense=dense,residual=residual,variance=variance,
                output=centered*inverse*arrays['gamma']+arrays['beta'])

@pytest.mark.parametrize('K',(15,128))
def test_full_pinned_ffn_all_tiles_against_independent_dense_polynomial(arrays,K):
    started=time.monotonic();x=arrays[f'K{K}_native'];positions=tuple(map(int,arrays[f'K{K}_original_positions']))
    expected=independent(x,arrays,approximate=True);native=independent(x,arrays,approximate=False)
    polynomial=MANIFEST['gelu']['0']['polynomial'];lo,hi=polynomial['domain']
    padding=float(np.polynomial.chebyshev.chebval(-(hi+lo)/(hi-lo),polynomial['coefficients']))
    worst={name:0. for name in ('middle','activated','dense','residual','output')};metadata=[];calls=Counter();pt_products=0;refreshes=0
    for start in range(0,K,16):
        valid=min(16,K-start);rows=positions[start:start+valid]
        rng=np.random.default_rng(2026110308+K+start);packed=rng.choice([-100.,100.],(16,4096));packed[:valid,:768]=x[start:start+valid]
        source=Value(packed.reshape(-1),9,math.nextafter(DELTA,math.inf));before=source.data.copy();captured={}
        def progress(label,value,counts):
            mapping={'FFN intermediate dense':'middle','FFN GELU64':'activated','FFN output dense':'dense','FFN residual':'residual'}
            if label in mapping:captured[mapping[label]]=value.data.copy()
        owner,ops,refresh=setup(arrays,rows,progress);result=owner.evaluate_tile(source)
        for name,width in (('middle',3072),('activated',3072),('dense',768),('residual',768),('output',768)):
            oracle=np.full((16,4096),padding if name=='activated' else 0.)
            if name=='residual':oracle=packed.copy()
            oracle[:valid,:width]=expected[name][start:start+valid]
            actual=result.output.data if name=='output' else captured[name]
            error=float(np.max(np.abs(actual-oracle.reshape(-1))));worst[name]=max(worst[name],error)
            assert np.isfinite(actual).all() and error<1e-8,(K,start,name,error)
        output=result.output.data.reshape(16,4096)
        assert np.all(output[:valid,768:]==0) and np.all(output[valid:]==0)
        assert result.output.level==13 and type(result.output._ckks_nsd)is int and result.output._ckks_nsd==1
        assert result.original_positions==rows
        assert not any(name.startswith('_public_') for name in vars(result.output))
        assert [row['level'] for row in owner.last_run['actual_metadata']]==[25,24,10,25,24,24,13]
        assert [item[2] for item in refresh.calls]==[128.,16.]
        np.testing.assert_array_equal(source.data,before)
        assert not owner._active and owner._source is None and not owner._retained
        metadata.append(owner.last_run);calls.update(ops.calls);pt_products+=ops.public_multiplies;refreshes+=len(refresh.calls)
    observations=dict(gelu_input_min=float(expected['middle'].min()),gelu_input_max=float(expected['middle'].max()),
        mlp_variance_min=float(expected['variance'].min()),mlp_variance_max=float(expected['variance'].max()),
        input_max_abs=float(np.abs(x).max()),gelu_max_abs=float(np.abs(expected['activated']).max()))
    report=dict(passed=True,scope=__doc__,K=K,tiles=math.ceil(K/16),physical_slots_checked=65536*math.ceil(K/16),
        actual_loop_vs_independent_polynomial_gate=1e-8,max_abs_errors=worst,
        polynomial_vs_native_function_max_abs=float(np.abs(expected['output']-native['output']).max()),
        native_function_oracle='Independent dense matmul/exact-erf GELU/exact LayerNorm; no new native-framework model run.',
        domain_observations=observations,gelu_padding_polynomial_at_zero=padding,original_positions=list(positions),
        identity_refresh_calls=refreshes,actual_primitive_counts=dict(calls),public_plaintext_products=pt_products,
        metadata=metadata,elapsed_s=time.monotonic()-started,encrypted_or_refresh_error_claim=False)
    (HERE/f'development-FFN-K{K}.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')

@pytest.mark.parametrize('mutation',('arithmetic','linear_arithmetic','norm','refresher','model','positions','context_secret','scale'))
def test_before_entry_changes_reject_without_primitive(arrays,mutation):
    owner,ops,refresh=setup(arrays,(0,1))
    if mutation=='arithmetic':owner.arithmetic=Arithmetic()
    elif mutation=='linear_arithmetic':owner.linear.arithmetic=Arithmetic()
    elif mutation=='norm':owner.normalizer=object()
    elif mutation=='refresher':owner.refresher=object()
    elif mutation=='model':owner.model=dict(owner.model)
    elif mutation=='positions':owner.original_positions=(1,0)
    elif mutation=='context_secret':ops.ctx.secret_key=object()
    else:ops.scale*=2
    with pytest.raises((ValueError,TypeError,AttributeError)):owner.evaluate_tile(Value(np.zeros(65536),9))
    assert not ops.calls and not refresh.calls

def test_callback_cancellation_preserves_borrowed_owners(arrays):
    error=KeyboardInterrupt('stop after initial refresh')
    def progress(*args):raise error
    owner,ops,refresh=setup(arrays,(0,1),progress)
    with pytest.raises(KeyboardInterrupt) as caught:owner.evaluate_tile(Value(np.zeros(65536),9))
    assert caught.value is error and owner.arithmetic is ops and owner.linear.ctx is ops.ctx
    assert not owner._active and owner._source is None and not owner._retained and owner.last_run is None
    assert not ops.calls and len(refresh.calls)==1
