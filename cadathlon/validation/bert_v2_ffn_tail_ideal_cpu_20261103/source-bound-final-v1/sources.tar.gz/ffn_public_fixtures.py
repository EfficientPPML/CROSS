"""Pinned public weights and trusted native-attention fixtures; no model loader.

The returned arrays stay in memory. Source-bound archives include their hashes,
not checkpoint tensors or native attention-output arrays.
"""
from pathlib import Path
import hashlib,json
import numpy as np
HERE=Path(__file__).resolve().parent
MODEL=Path('/home/jianming_gatech/cross_validation_assets/bert/f150c1d609d1e50dd5e2e5408661cfac8339277c/model.safetensors')
MODEL_SHA='e1f8085ef673c9eb8a1a93a84270742e8aa0ccbceadef01eef15e26c44b46034'
FIXTURE=Path('/tmp/bert-first-attention-owner-20261103/client_fixtures.npz')
FIXTURE_SHA='184397324e50f8c33cd6ea62f47457b3b0992da85814c001927b412ca6d06ce7'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def load():
    if sha(MODEL)!=MODEL_SHA or sha(FIXTURE)!=FIXTURE_SHA:raise ValueError('pinned checkpoint/native attention fixture changed')
    from encrypted_bert_v2_ffn import TENSORS
    from encrypted_bert_v2_row_norm import AFFINE_SHA256
    prefix='bert.encoder.layer.0.'
    names={name:prefix+('intermediate.dense.' if name.startswith('intermediate.') else 'output.dense.')+name.split('.')[1] for name in TENSORS}
    names.update(gamma=prefix+'output.LayerNorm.weight',beta=prefix+'output.LayerNorm.bias')
    arrays={};records={}
    with MODEL.open('rb') as stream:
        length=int.from_bytes(stream.read(8),'little');header=json.loads(stream.read(length));base=8+length
        for name,source in names.items():
            desc=header[source];shape=TENSORS[name][0] if name in TENSORS else (768,)
            expected=TENSORS[name][1] if name in TENSORS else AFFINE_SHA256['0.mlp'][0 if name=='gamma' else 1]
            if desc['dtype']!='F32' or desc['shape']!=list(shape):raise ValueError('pinned tensor shape/dtype changed')
            start,end=desc['data_offsets'];stream.seek(base+start);raw=stream.read(end-start)
            if len(raw)!=int(np.prod(shape))*4 or hashlib.sha256(raw).hexdigest()!=expected:raise ValueError('pinned tensor bytes changed')
            arrays[name]=np.frombuffer(raw,dtype='<f4').reshape(shape).astype(np.float64)
            records[name]=dict(source=source,shape=list(shape),source_f32_sha256=expected,exact_f64_lift=True)
    with np.load(FIXTURE,allow_pickle=False) as source:
        for K in (15,128):
            for suffix in ('native','original_positions'):
                name=f'K{K}_{suffix}';arrays[name]=source[name].copy()
                shape=(K,768) if suffix=='native' else (K,)
                if arrays[name].shape!=shape or not np.isfinite(arrays[name]).all():raise ValueError('native fixture shape/finiteness')
                records[name]=dict(shape=list(shape),dtype=arrays[name].dtype.str,sha256=hashlib.sha256(arrays[name].tobytes()).hexdigest())
    return arrays,dict(passed=True,checkpoint_sha256=MODEL_SHA,native_fixture_sha256=FIXTURE_SHA,
        arrays=records,scope='Direct pinned public weight bytes and previously fixed trusted native attention outputs; no new model inference; arrays excluded from archive.')
