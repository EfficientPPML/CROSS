"""Regressions for independently reproduced owner/refresh boundary defects.

Only ideal slots and exact public metadata are used; no HE or model evaluation.
"""
import copy
import math
from types import SimpleNamespace
import numpy as np
import pytest
from test_ffn_tail import (ideal_primitives,refresh_and_tracked,primitives,arrays,
                          setup,IdentityRefresh,RAW)
from ideal_primitives import Arithmetic,Value,DELTA
from encrypted_fullslot_refresh_binding import FullSlotRefreshBinding
from encrypted_bert_v2_gelu import BertV2Gelu,Gelu64Contract


def binding():
    ops=Arithmetic();refresh=IdentityRefresh(ops)
    return ops,refresh


def mutate(ops,refresh,kind):
    cache=ops.ctx._param_cache
    if kind=='empty_plan':
        refresh.plan['rotations']=();cache.raw_rotation_keys.clear();cache.coef_maps.clear()
    elif kind=='missing_rotation':refresh.plan['rotations']=refresh.plan['rotations'][1:]
    elif kind=='list_rotations':refresh.plan['rotations']=list(refresh.plan['rotations'])
    elif kind=='wrong_depth':refresh.plan['boot_depth']+=1
    elif kind=='wrong_slots':refresh.plan['bootstrap_slots']=32768
    elif kind=='mode_int':cache.per_level_rotation_keys=0
    elif kind=='mode_float':cache.per_level_rotation_keys=0.
    elif kind=='mode_none':cache.per_level_rotation_keys=None
    elif kind=='missing_keys':cache.raw_rotation_keys.pop(refresh.plan['rotations'][0])
    elif kind=='missing_map':cache.coef_maps.pop(refresh.plan['rotations'][0])
    elif kind=='missing_a':cache.raw_rotation_keys[refresh.plan['rotations'][0]]['a']=None
    elif kind=='no_helpers':refresh.compiled_primitives=()
    elif kind=='helper_list':refresh.compiled_primitives=list(refresh.compiled_primitives)
    elif kind=='helper_context':refresh.compiled_primitives[0].ctx=copy.copy(ops.ctx)
    elif kind=='helper_method':refresh.compiled_primitives[0].rotate=None
    elif kind=='evaluator_refresh':refresh.evaluator.refresher=object()
    elif kind=='evaluator_bound':refresh.evaluator.declare_bound=lambda *args:None
    elif kind=='depth_type':ops.ctx.max_level=49.
    elif kind=='view_secret':refresh.engine.ctx.secret_key=object()
    elif kind=='view_parameter_secret':refresh.engine.ctx.parameters=dict(secret_key=object())
    elif kind=='view_layout':refresh.engine.ctx.degree_layout=(512,256)
    else:raise AssertionError(kind)


@pytest.mark.parametrize('kind',('empty_plan','missing_rotation','list_rotations','wrong_depth','wrong_slots',
 'mode_int','mode_float','mode_none','missing_keys','missing_map','missing_a','no_helpers','helper_list',
 'helper_context','helper_method','evaluator_refresh','evaluator_bound','depth_type','view_secret',
 'view_parameter_secret','view_layout'))
@pytest.mark.parametrize('when',('constructor','entry'))
def test_refresh_contract_rejects_before_any_work(kind,when):
    ops,refresh=binding()
    owner=FullSlotRefreshBinding(ops,refresh) if when=='entry' else None
    mutate(ops,refresh,kind)
    with pytest.raises((ValueError,TypeError,AttributeError)):
        if owner is None:FullSlotRefreshBinding(ops,refresh)
        else:owner.refresh(Value(np.zeros(65536),2),public_bound=16.)
    assert not ops.calls and not refresh.calls
    if owner is not None:assert not owner._active


@pytest.mark.parametrize('kind',('keys','maps','helper_tuple','evaluator_progress','engine_context'))
def test_refresh_identity_replacements_fail_before_work(kind):
    ops,refresh=binding();owner=FullSlotRefreshBinding(ops,refresh);cache=ops.ctx._param_cache
    if kind=='keys':cache.raw_rotation_keys=dict(cache.raw_rotation_keys)
    elif kind=='maps':cache.coef_maps=dict(cache.coef_maps)
    elif kind=='helper_tuple':refresh.compiled_primitives=tuple(list(refresh.compiled_primitives))
    elif kind=='evaluator_progress':refresh.evaluator.progress=lambda *a:None
    else:refresh.engine.ctx=copy.copy(refresh.engine.ctx)
    with pytest.raises(ValueError):owner.refresh(Value(np.zeros(65536),2),public_bound=128.)
    assert not refresh.calls and not ops.calls and not owner._active


@pytest.mark.parametrize('kind',('source_scale','source_payload','result_nsd','result_level','result_scale','result_layout','ctx_secret'))
def test_refresh_return_checks_and_borrowed_cleanup(kind):
    ops,refresh=binding();owner=FullSlotRefreshBinding(ops,refresh);source=Value(np.zeros(65536),2)
    def inject(original,result):
        if kind=='source_scale':original._ckks_scale=math.nextafter(DELTA,math.inf)
        elif kind=='source_payload':original.polynomial=copy.copy(original.polynomial)
        elif kind=='result_nsd':result._ckks_nsd=True
        elif kind=='result_level':result.level=24
        elif kind=='result_scale':result._ckks_scale=DELTA*1.01
        elif kind=='result_layout':result.degree_layout=(512,256)
        else:ops.ctx.secret_key=object()
    refresh.inject=inject
    with pytest.raises((ValueError,TypeError)):owner.refresh(source,public_bound=16.)
    assert len(refresh.calls)==1 and not owner._active and owner.arithmetic is ops


@pytest.mark.parametrize('bound',(16.,128.))
def test_refresh_valid_identity_double_preserves_source_and_clears_output_tags(bound):
    ops,refresh=binding();owner=FullSlotRefreshBinding(ops,refresh);source=Value(np.linspace(-1,1,65536),2)
    source._public_original='preserved'
    result=owner.refresh(source,public_bound=bound)
    np.testing.assert_array_equal(result.data,source.data)
    assert source._public_original=='preserved' and not any(n.startswith('_public_') for n in vars(result))
    assert result.level==25 and result._ckks_scale==math.nextafter(DELTA,math.inf)
    assert not owner._active


@pytest.mark.parametrize('error_type',(KeyboardInterrupt,SystemExit))
def test_refresh_cancellation_and_reentry(error_type):
    ops,refresh=binding();owner=FullSlotRefreshBinding(ops,refresh);source=Value(np.zeros(65536),2)
    error=error_type('retain primary')
    def inject(*args):
        with pytest.raises(ValueError,match='reentered'):owner.refresh(source,public_bound=16.)
        raise error
    refresh.inject=inject
    with pytest.raises(error_type) as exc:owner.refresh(source,public_bound=128.)
    assert exc.value is error and not owner._active and len(refresh.calls)==1


def test_gelu_strips_callback_annotations_from_current_and_retained_branches():
    ops=Arithmetic();source=Value(np.zeros(65536),24);source._public_original='keep';seen=[]
    def progress(label,result,counts):
        seen.append(result)
        for v in seen:v._public_abs_bound=0.
    owner=BertV2Gelu(ops,Gelu64Contract(RAW),progress=progress)
    output=owner.evaluate_tile(source)
    assert all(not any(n.startswith('_public_') for n in vars(v)) for v in seen)
    assert not any(n.startswith('_public_') for n in vars(output))
    assert source._public_original=='keep' and not owner._active


@pytest.mark.parametrize('layout',((512,256),[256,512],(256.,512)))
def test_entry_layout_rejected_before_gelu_or_refresh(layout):
    ops,refresh=binding();source=Value(np.zeros(65536),24);source.degree_layout=layout
    gelu=BertV2Gelu(ops,Gelu64Contract(RAW));owner=FullSlotRefreshBinding(ops,refresh)
    with pytest.raises(ValueError):gelu.evaluate_tile(source)
    with pytest.raises(ValueError):owner.refresh(source,public_bound=16.)
    assert not ops.calls and not refresh.calls


def test_gelu_rejects_primitive_result_layout_before_callback_or_next_operation(monkeypatch):
    ops=Arithmetic();original=ops.weighted_sum;callbacks=[]
    def corrupt(*args,**kwargs):
        result=original(*args,**kwargs);result.degree_layout=(512,256);return result
    monkeypatch.setattr(ops,'weighted_sum',corrupt)
    owner=BertV2Gelu(ops,Gelu64Contract(RAW),progress=lambda *args:callbacks.append(args))
    with pytest.raises(ValueError):owner.evaluate_tile(Value(np.zeros(65536),24))
    assert ops.calls==['weighted_sum'] and not callbacks and not owner._active


@pytest.mark.parametrize('mutation',('bound_linear','entry_layout'))
def test_ffn_rejects_before_refresh_or_dense(arrays,mutation):
    owner,ops,refresh=setup(arrays,(0,1));source=Value(np.zeros(65536),9)
    if mutation=='bound_linear':owner.linear.arithmetic.declare_bound=lambda *args:None
    else:source.degree_layout=(512,256)
    with pytest.raises((ValueError,TypeError)):owner.evaluate_tile(source)
    assert not ops.calls and not refresh.calls and not owner._active


def test_ffn_callback_clears_current_and_retained_annotations(arrays):
    refs=[]
    def progress(label,result,counts):
        refs.append(result)
        for v in refs:v._public_abs_bound=0.
    owner,ops,refresh=setup(arrays,(0,1),progress)
    retained=Value(np.zeros(65536),25);current=Value(np.ones(65536),24)
    refs.append(retained);owner._retained.append((retained,owner._fingerprint(retained)))
    # Real callback boundary in isolation; full dense/normalization arithmetic
    # is independently covered by test_ffn_tail's all-slot composition.
    owner._callback('boundary',current,{})
    assert not hasattr(retained,'_public_abs_bound') and not hasattr(current,'_public_abs_bound')
    assert not ops.calls and not refresh.calls


def test_ffn_note_rejects_result_layout_before_callback(arrays):
    callbacks=[];owner,ops,refresh=setup(arrays,(0,1),lambda *args:callbacks.append(args))
    result=Value(np.zeros(65536),24);result.degree_layout=(512,256)
    with pytest.raises(ValueError):owner._note('bad layout',result,[])
    assert not callbacks and not ops.calls and not refresh.calls
