"""Entrypoint/private-path boundary tests with fake modules only."""
from types import ModuleType
from pathlib import Path
import importlib,sys,builtins
import pytest
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
# Install the intended complete import prefix before loading this local module.
sys.path[:0]=[str(HERE),str(HERE/'runtime/stage'),str(HERE/'runtime')]
import boundaries as b

@pytest.fixture
def fake(monkeypatch):
    def allowed(*a,**kw):return 'allowed'
    class CKKS:pass
    for n in b.CODECS:setattr(CKKS,n,allowed)
    pkg=ModuleType('jaxite_word');pkg.CKKSContext=CKKS;monkeypatch.setitem(sys.modules,'jaxite_word',pkg)
    defs={'key_gen':b.KEY_METHODS,'jaxite_word.key_gen':b.KEY_METHODS,'client_keys':('generate',),
        'client_inputs':('ClientEmbeddings',),'key_contexts':('load_client','_read_private'),
        'file_stages':('client_key_generation','client_encode_encrypt_input','client_decrypt_decode','server_preprocess_model','_records','_snapshot')}
    modules={}
    for name,names in defs.items():
        mod=ModuleType(name)
        for n in names:setattr(mod,n,allowed)
        modules[name]=mod;monkeypatch.setitem(sys.modules,name,mod)
    return CKKS,modules,allowed

def test_every_forbidden_entrypoint_denied_then_restored(fake):
    cls,mods,allowed=fake;calls=[];entries=[(cls,n) for n in b.CODECS]+[(m,n) for m in mods.values() for n in vars(m) if not n.startswith('__')]
    assert len(entries)==25
    with b.server_only(calls):
        for owner,name in entries:
            with pytest.raises(RuntimeError,match='forbidden'):getattr(owner,name)()
    assert len(calls)==25 and all(getattr(o,n)is allowed for o,n in entries)

def test_private_path_and_symlink_alias_open_denied(fake,tmp_path):
    private=tmp_path/'private';private.mkdir();secret=private/'secret';secret.write_bytes(b'fixture')
    alias=tmp_path/'alias';alias.symlink_to(private,target_is_directory=True);public=tmp_path/'public';public.write_bytes(b'public')
    calls=[]
    with b.server_only(calls,private_paths=(private,)):
        assert public.read_bytes()==b'public'
        for p in (secret,alias/'secret'):
            with pytest.raises(RuntimeError,match='private file'):p.read_bytes()
    assert secret.read_bytes()==b'fixture' and calls==['private file access']*2

def test_native_import_audit_denied(fake):
    calls=[]
    with b.server_only(calls):
        with pytest.raises(RuntimeError,match='native model import'):sys.audit('import','transformers.foo',None,None,None,None)
    assert calls==['native model import']

def test_preloaded_native_module_rejected_before_patches(fake,monkeypatch):
    monkeypatch.setitem(sys.modules,'torch',ModuleType('torch'))
    with pytest.raises(ValueError,match='preload'):
        with b.server_only([]):pass
    assert fake[0].encrypt is fake[2]

def test_primary_cancellation_preserved_after_attempt_all_restore(fake,monkeypatch):
    cls,mods,allowed=fake;original=builtins.setattr;restores=[];primary=KeyboardInterrupt('primary')
    def replace(owner,name,value):
        if value is allowed:
            restores.append((owner,name))
            original(owner,name,value)
            if len(restores)==1:raise OSError('restore failure')
        else:original(owner,name,value)
    monkeypatch.setattr(b,'setattr',replace,raising=False)
    with pytest.raises(KeyboardInterrupt) as caught:
        with b.server_only([]):raise primary
    assert caught.value is primary and len(restores)==25 and any('restore failure' in n for n in primary.__notes__)

def test_cleanup_only_cancellation_supersedes_ordinary_restore(fake,monkeypatch):
    allowed=fake[2];restores=[];primary=SystemExit(143)
    def replace(owner,name,value):
        builtins.setattr(owner,name,value)
        if value is allowed:
            restores.append(name)
            if len(restores)==1:raise OSError('ordinary')
            if len(restores)==2:raise primary
    monkeypatch.setattr(b,'setattr',replace,raising=False)
    with pytest.raises(SystemExit) as caught:
        with b.server_only([]):pass
    assert caught.value is primary and len(restores)==25 and any('earlier' in n for n in primary.__notes__)
