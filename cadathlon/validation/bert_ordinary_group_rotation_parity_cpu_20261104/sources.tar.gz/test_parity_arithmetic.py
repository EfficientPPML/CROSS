"""Small independent representation fixtures; no context, key or HE execution."""
from pathlib import Path
from types import SimpleNamespace as NS
from collections import Counter
import sys
sys.path.insert(0,str(Path(__file__).parent))
import numpy as np
import pytest
import parity_arithmetic as a

class Value:
    def __init__(self,data,q=None,scale=1024.,nsd=1):
        self.polynomial=np.asarray(data,dtype=np.uint32);self.moduli=list(range(100,200)) if q is None else q
        self.degree_layout=(2,4);self.precision=32;self._ckks_scale=scale;self._ckks_nsd=nsd

class Reduction:
    def __getitem__(self,pair):
        assert pair==(49,25)
        return NS(level_reduce=lambda v:Value(v.polynomial[...,:52],v.moduli[:52],v._ckks_scale,v._ckks_nsd))

class Owner:
    def __init__(self,prepared=False):
        self.prepared=prepared;self.level=None;self.indices=set();self.calls=[]
        self.rotation=NS(stats=Counter(),retained_entries=0,retained_bytes=0,clear=lambda **kw:None)
    def rotate(self,value,index):
        self.calls.append(index);level=(len(value.moduli)//2)-1
        if self.prepared:
            if self.level!=level:self.indices=set();self.level=level
            self.rotation.stats['hits' if index in self.indices else 'published']+=1
            self.indices.add(index);self.rotation.retained_entries=len(self.indices);self.rotation.retained_bytes=1024*len(self.indices)
        return Value(np.roll(value.polynomial,-index,axis=3),value.moduli.copy(),value._ckks_scale,value._ckks_nsd)
    def _clear_working_caches(self):pass

def fixture():
    ctx=NS(degree_layout=(2,4),_param_cache=NS(q_moduli_at_level=lambda level:list(range(100,100+2*(level+1)))),he_level_reduce=Reduction())
    return ctx,Value(np.arange(1600,dtype=np.uint32).reshape(1,2,2,4,100))

def test_fixed24_calls_fullword_parity_and_true_prefix():
    ctx,value=fixture();left=Owner();right=Owner(True);rows=[];original=value.polynomial.copy()
    result=a.exercise(ctx,value,left,right,progress=rows.append,security=lambda *x:None)
    assert result['passed'] and result['actual_rotation_calls']==24 and len(rows)==12
    assert left.calls==right.calls==[1,1,64,64,1,64]*2
    assert sum(r['compared_words'] for r in rows)==6*(1600+832)
    assert result['level_reduction']['payload_prefix_equal'] and np.array_equal(original,value.polynomial)

@pytest.mark.parametrize('mutation',['last_word','scale','nsd','moduli','precision','shape'])
def test_independent_payload_metadata_failure(mutation):
    ctx,v=fixture();other=Value(v.polynomial.copy())
    if mutation=='last_word':other.polynomial.flat[-1]^=1
    if mutation=='scale':other._ckks_scale=np.nextafter(1024.,np.inf)
    if mutation=='nsd':other._ckks_nsd=True
    if mutation=='moduli':other.moduli[0]+=1
    if mutation=='precision':other.precision=64
    if mutation=='shape':other.polynomial=other.polynomial.reshape(1,2,4,2,100)
    try:result=a.compare(v,other,v,ctx,49)
    except ValueError:return
    assert result['passed'] is False

@pytest.mark.parametrize('mutation',['payload','scale','nsd','moduli'])
def test_reduction_rejects_relabel_or_bad_prefix(mutation):
    ctx,v=fixture();low=ctx.he_level_reduce[49,25].level_reduce(v)
    low.polynomial=low.polynomial.copy()
    if mutation=='payload':low.polynomial.flat[-1]^=1
    if mutation=='scale':low._ckks_scale*=2
    if mutation=='nsd':low._ckks_nsd=2
    if mutation=='moduli':low.moduli.reverse()
    with pytest.raises(ValueError):a.verify_reduction(v,low,ctx)

def test_cleanup_attemptall_preserves_primary_identity():
    calls=[];error=KeyboardInterrupt('primary')
    def bad():calls.append('bad');raise OSError('cleanup')
    left=NS(_clear_working_caches=bad,rotation=NS(clear=lambda **kw:calls.append('left-clear')))
    right=NS(_clear_working_caches=lambda:calls.append('right'),rotation=NS(clear=lambda **kw:calls.append('right-clear')))
    a.close_owners(left,right,error)
    assert calls==['bad','left-clear','right','right-clear'] and 'cleanup' in error.__notes__[0]

def test_cleanup_only_cancellation_priority():
    calls=[];error=KeyboardInterrupt('cancel')
    def fail(e):
        def f(**kw):calls.append(e);raise e
        return f
    owner=NS(_clear_working_caches=fail(OSError('ordinary')),rotation=NS(clear=fail(error)))
    with pytest.raises(KeyboardInterrupt) as got:a.close_owners(owner,None)
    assert got.value is error and len(calls)==2

@pytest.mark.parametrize('changed',['rotation','clear','missing'])
def test_captured_original_cleanup_cannot_be_hidden(changed):
    calls=[];original=NS(clear=lambda **kw:calls.append('original rotation'))
    first=NS(rotation=original,_clear_working_caches=lambda:calls.append('first'))
    second=NS(rotation=NS(clear=lambda **kw:calls.append('second rotation')),_clear_working_caches=lambda:calls.append('second'))
    cleanup=a.OwnerCleanup();cleanup.register(first);cleanup.register(second)
    if changed=='rotation':first.rotation=NS(clear=lambda **kw:calls.append('wrong'))
    if changed=='clear':first._clear_working_caches=lambda:calls.append('wrong')
    if changed=='missing':del first.rotation
    with pytest.raises((ValueError,AttributeError)):cleanup.close()
    assert calls==['original rotation','second','second rotation'] and not cleanup.completed
