"""Public-only transport checks; never constructs or decodes ciphertexts.

These functions read ciphertext bytes only in an explicitly authorized worker.
Preparation tests use synthetic/mocked transport objects, not retained uploads.
"""
from pathlib import Path
import math

def _inventory(directory, expected):
    import stat
    path=Path(directory)
    if not stat.S_ISDIR(path.lstat().st_mode) or {p.name for p in path.iterdir()}!=set(expected):
        raise ValueError('exact ordinary public transport directory required')

def requests(paths, *, keys, model, stage3):
    import file_stages,file_stage_contract as batches
    from file_stage_io import read_manifest
    from transport import validate_ciphertext,request_digest,manifest_digest
    from transport_contract import digest
    model_manifest=read_manifest(Path(model['server_data'])/keys['context_id']/'model_manifest.json')
    if digest(model_manifest)!=model['model_manifest_sha256']:
        raise ValueError('authenticated public model metadata changed')
    public=file_stages._public(keys['public_manifest'],model_manifest)
    batch=batches.validate_public_batch(read_manifest(Path(paths['upload'])/'batch.json'),public=public,count=1)
    if digest(batch)!=stage3['public_batch_sha256']:
        raise ValueError('completed stage3 public batch differs')
    request=batch['requests'][0];nonce=request['contract']['request_id'];sample=Path(paths['upload'])/nonce
    _inventory(paths['upload'],(nonce,'batch.json'));_inventory(sample,(f'tile{i}' for i in range(8)))
    manifests=[];rows=[]
    for i in range(8):
        payload,scale,binding,manifest=validate_ciphertext(sample/f'tile{i}',contract=request['contract'],role='request',tile_index=i)
        rows.append(dict(tile=i,payload_bytes=payload.nbytes,shape=list(payload.shape),scale=scale,manifest_sha256=manifest_digest(manifest)))
        manifests.append(manifest);del payload
    actual=request_digest(manifests,request['contract'])
    if actual!=request['input_digest'] or actual!=stage3['input_digest']:
        raise ValueError('completed ordered eight-input binding differs')
    if rows!=stage3['tiles']:
        raise ValueError('completed stage3 ordered input metadata differs')
    return dict(sample_count=1,tile_count=8,public_batch_sha256=digest(batch),input_digest=actual,
        ciphertext_payload_bytes=sum(row['payload_bytes'] for row in rows),tiles=rows,batch=batch)

def responses(paths, *, request):
    import file_stages,file_stage_contract as batches
    from file_stage_io import read_manifest
    from transport import validate_ciphertext,manifest_digest
    from transport_contract import digest
    inputs,candidate=file_stages._inputs()
    response=batches.validate_response_batch(read_manifest(Path(paths['download'])/'batch.json'),request['batch'],
        check_scale=file_stages._scale_checker(inputs,candidate))
    row=response['responses'][0];nonce=row['request_id'];original=request['batch']['requests'][0]
    _inventory(paths['download'],(nonce,'batch.json'))
    payload,scale,binding,manifest=validate_ciphertext(Path(paths['download'])/nonce,
        contract=original['contract'],role='response',tile_index=0,expected_scale=row['scale'],input_digest=original['input_digest'])
    if manifest_digest(manifest)!=row['response_manifest_sha256']:
        raise ValueError('response ciphertext differs from published digest')
    timing=read_manifest(paths['server_report']);seconds=timing.get('full_model_compute_and_transport_seconds')
    if (set(timing)!={'full_model_compute_and_transport_seconds'} or type(seconds)not in (float,int)
            or not math.isfinite(seconds) or seconds<0):raise ValueError('finite nonnegative server timing required')
    result=dict(sample_count=1,response_count=1,input_digest=original['input_digest'],public_batch_sha256=request['public_batch_sha256'],
        response_batch_sha256=digest(response),response_manifest_sha256=manifest_digest(manifest),
        payload_bytes=payload.nbytes,shape=list(payload.shape),scale=scale,level=binding['level'],
        full_model_compute_and_transport_seconds=seconds)
    del payload
    return result
