"""Public transport schema/order tests; synthetic payload descriptors only."""
from pathlib import Path
from types import SimpleNamespace as NS
import copy,sys
import pytest
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import server_readback as r

@pytest.fixture
def fixture(tmp_path,monkeypatch):
    upload=tmp_path/'upload';upload.mkdir();nonce='nonce';sample=upload/nonce;sample.mkdir()
    for i in range(8):(sample/f'tile{i}').mkdir()
    (upload/'batch.json').write_text('{}')
    download=tmp_path/'download';download.mkdir();(download/nonce).mkdir();(download/'batch.json').write_text('{}')
    report=tmp_path/'server_report';report.write_text('{}')
    batch={'requests':[{'contract':{'request_id':nonce},'input_digest':'input'}]}
    response={'responses':[{'request_id':nonce,'scale':123.,'response_manifest_sha256':'manifest-response'}]}
    model={'model_manifest':True};timing={'full_model_compute_and_transport_seconds':3.};calls=[];changes={}
    def digest(x):return 'model' if x==model else 'batch' if x==batch else 'response'
    def read(path):
        path=Path(path)
        if path.name=='model_manifest.json':return model
        if path==upload/'batch.json':return batch
        if path==download/'batch.json':return response
        if path==report:return timing
        raise AssertionError(path)
    def validate(directory,*,contract,role,tile_index,**kwargs):
        calls.append((role,tile_index))
        if changes.get('fail')==tile_index and role=='request':raise ValueError('invalid payload')
        if role=='request':return NS(nbytes=100,shape=(1,2,256,512,100)),123.,{},dict(tile=tile_index)
        assert kwargs=={'expected_scale':123.,'input_digest':'input'}
        return NS(nbytes=6,shape=(1,2,256,512,6)),123.,{'level':2},{'response':True}
    def md(m):return 'manifest-response' if m.get('response') else 'manifest-'+str(m['tile'])
    monkeypatch.setitem(sys.modules,'file_stages',NS(_public=lambda k,m:{},_inputs=lambda:({},b'candidate'),_scale_checker=lambda i,c:lambda s:s==123.))
    monkeypatch.setitem(sys.modules,'file_stage_io',NS(read_manifest=read))
    monkeypatch.setitem(sys.modules,'file_stage_contract',NS(validate_public_batch=lambda b,**kw:b,validate_response_batch=lambda b,*a,**kw:b))
    monkeypatch.setitem(sys.modules,'transport_contract',NS(digest=digest))
    monkeypatch.setitem(sys.modules,'transport',NS(validate_ciphertext=validate,request_digest=lambda ms,c:'input' if [m['tile'] for m in ms]==list(range(8)) else 'bad',manifest_digest=md))
    rows=[dict(tile=i,payload_bytes=100,shape=[1,2,256,512,100],scale=123.,manifest_sha256='manifest-'+str(i)) for i in range(8)]
    args=dict(paths=dict(upload=upload,download=download,server_report=report),keys={'context_id':'context','public_manifest':{}},
        model={'server_data':tmp_path,'model_manifest_sha256':'model'},stage3={'public_batch_sha256':'batch','input_digest':'input','tiles':rows})
    return NS(args=args,calls=calls,changes=changes,rows=rows,batch=batch,response=response,timing=timing,upload=upload,sample=sample)

def test_all_eight_in_order_and_response_binding(fixture):
    request=r.requests(**fixture.args);response=r.responses(fixture.args['paths'],request=request)
    assert fixture.calls==[('request',i) for i in range(8)]+[('response',0)]
    assert request['ciphertext_payload_bytes']==800 and response['level']==2 and response['input_digest']=='input'

@pytest.mark.parametrize('field',['public_batch_sha256','input_digest'])
def test_wrong_completed_binding_rejected(fixture,field):
    fixture.args['stage3'][field]='wrong'
    with pytest.raises(ValueError):r.requests(**fixture.args)

def test_ordered_stage3_metadata_not_set_comparison(fixture):
    fixture.args['stage3']['tiles']=list(reversed(fixture.rows))
    with pytest.raises(ValueError,match='ordered input'):r.requests(**fixture.args)

def test_eighth_payload_is_checked(fixture):
    fixture.changes['fail']=7
    with pytest.raises(ValueError,match='invalid payload'):r.requests(**fixture.args)
    assert fixture.calls==[('request',i) for i in range(8)]

def test_extra_input_file_rejected_before_payload(fixture):
    (fixture.sample/'extra').write_text('bad')
    with pytest.raises(ValueError,match='exact ordinary'):r.requests(**fixture.args)
    assert not fixture.calls

def test_symlink_sample_rejected_before_payload(fixture,tmp_path):
    fixture.sample.rename(tmp_path/'actual');fixture.sample.symlink_to(tmp_path/'actual',target_is_directory=True)
    with pytest.raises(ValueError,match='exact ordinary'):r.requests(**fixture.args)
    assert not fixture.calls

def test_model_manifest_binding_precedes_ct(fixture):
    fixture.args['model']['model_manifest_sha256']='wrong'
    with pytest.raises(ValueError,match='model metadata'):r.requests(**fixture.args)
    assert not fixture.calls

@pytest.mark.parametrize('seconds',[float('nan'),float('inf'),-1.,True,'1'])
def test_nonfinite_or_nonnumber_server_report_rejected(fixture,seconds):
    request=r.requests(**fixture.args);fixture.timing['full_model_compute_and_transport_seconds']=seconds
    with pytest.raises(ValueError,match='timing'):r.responses(fixture.args['paths'],request=request)

def test_response_manifest_digest_rejected(fixture):
    request=r.requests(**fixture.args);fixture.response['responses'][0]['response_manifest_sha256']='wrong'
    with pytest.raises(ValueError,match='published digest'):r.responses(fixture.args['paths'],request=request)
