"""Fail closed until reviewed cleanup overlays and stage3 evidence are pinned."""
from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent

def check():
    record=json.loads((HERE/'dependencies.json').read_text())
    if record.get('ready') is not True:
        raise RuntimeError('stage4 execution dependencies are pending review')
    for field,name in (('key_contexts_successor_sha256','runtime/stage/key_contexts.py'),
                       ('cleanup_successor_sha256','cleanup.py'),
                       ('terminal_successor_sha256','terminal.py'),
                       ('engine_successor_sha256','runtime/stage/full_model_engine.py'),
                       ('stage3_source_inventory_sha256','stage3_source_manifest.json')):
        value=record.get(field)
        if type(value)is not str or len(value)!=64 or hashlib.sha256((HERE/name).read_bytes()).hexdigest()!=value:
            raise ValueError('reviewed stage4 dependency differs: '+field)
    if not record.get('stage3_source_inventory_sha256'):
        raise ValueError('completed stage3 source inventory remains pending')
    return record
