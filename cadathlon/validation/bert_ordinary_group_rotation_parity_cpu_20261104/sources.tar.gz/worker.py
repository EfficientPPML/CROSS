"""Genuine server-only size0 handler scaffold; execution dependencies pending."""
from pathlib import Path
from contextlib import redirect_stdout
import argparse,hashlib,json,os,stat,sys,time
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE/'runtime/stage'),str(HERE/'joined'),
              str(HERE/'joined/checkout/cadathlon/common'),str(HERE/'runtime')]
from cleanup import cleanup_signals,termination_signals
from terminal import terminal_scope
import key_gate,model_gate,stage3_gate,dependencies,boundaries,server_readback

def write(path,value):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');temp.replace(path)

def hashes(expected):
    result={}
    for name in expected:
        p=Path(name)
        if p.is_absolute() or '..' in p.parts:raise ValueError('relative source member required')
        result[name]=hashlib.sha256((HERE/p).read_bytes()).hexdigest()
    return result

def local_modules(expected):
    result={}
    for name,module in tuple(sys.modules.items()):
        file=getattr(module,'__file__',None)
        if not file:continue
        path=Path(file).resolve()
        if HERE in path.parents and path.suffix=='.py':
            relative=path.relative_to(HERE).as_posix()
            if relative not in expected or hashlib.sha256(path.read_bytes()).hexdigest()!=expected[relative]:
                raise ValueError('loaded local module is outside exact source closure: '+name)
            result[name]=relative
    for name in ('file_stages','key_contexts','full_model_engine'):
        module=sys.modules.get(name)
        if module is not None and Path(module.__file__).resolve()!=HERE/'runtime/stage'/f'{name}.py':
            raise ValueError('mixed stage runtime module: '+name)
    return result

def authenticate(*,key_evidence,key_report_sha256,key_workspace,model_evidence,model_report_sha256,model_workspace,
                 stage3_evidence,stage3_report_sha256,io_workspace,profile_bytes,plan_bytes):
    keys=key_gate.authenticate(key_evidence,key_report_sha256,key_workspace,profile_bytes=profile_bytes,plan_bytes=plan_bytes)
    model=model_gate.authenticate(model_evidence,model_report_sha256,model_workspace,keys=keys)
    inputs=stage3_gate.authenticate(stage3_evidence,stage3_report_sha256,io_workspace,keys=keys,model=model)
    return keys,model,inputs

def prerequisite_summary(keys,model,inputs):
    return {n:keys[n] for n in ('context_id','key_report_sha256','key_source_archive_sha256')}|{
        n:model[n] for n in ('model_id','model_report_sha256','model_manifest_sha256')}|{
        n:inputs[n] for n in ('stage3_report_sha256','public_batch_sha256','input_digest')}

def make_paths(keys,model,inputs,io_workspace):
    import file_stages
    root=Path(io_workspace)
    if Path(inputs['upload'])!=root/'upload':raise ValueError('authenticated upload path differs')
    return dict(size=0,batch_size=1,model_id=file_stages.MODEL_ID,model_revision=file_stages.REVISION,
        public_keys=keys['public_keys'],server_data=model['server_data'],upload=root/'upload',
        download=root/'download',server_report=root/'server_report')

def fresh_paths(paths):
    for name in ('download','server_report'):
        path=Path(paths[name])
        if path.exists() or path.is_symlink():raise FileExistsError('fresh server response paths required')

def remaining(paths):
    result={}
    for name in ('upload','download','server_report'):
        try:info=Path(paths[name]).lstat()
        except FileNotFoundError:result[name]={'present':False};continue
        result[name]=dict(present=True,device=info.st_dev,inode=info.st_ino,size=info.st_size,
            kind='directory' if stat.S_ISDIR(info.st_mode) else 'regular' if stat.S_ISREG(info.st_mode) else 'other')
    return result

def run(*,key_evidence,key_report_sha256,key_workspace,model_evidence,model_report_sha256,model_workspace,
        stage3_evidence,stage3_report_sha256,io_workspace,output,source_manifest):
    start=time.monotonic();primary=None;expected={};calls=[];paths=None
    report=dict(passed=False,actual_server_compute_started=False,actual_server_compute_completed=False,
        request_readback_complete=False,response_readback_complete=False,source_files_unchanged=False,
        scope='Actual size0 encrypted twelve-layer server handler and public transport readback only; no client decode, accuracy or full-workload readiness claim.',
        pid=os.getpid(),cpu_affinity=sorted(os.sched_getaffinity(0)))
    gate_args=dict(key_evidence=key_evidence,key_report_sha256=key_report_sha256,key_workspace=key_workspace,
        model_evidence=model_evidence,model_report_sha256=model_report_sha256,model_workspace=model_workspace,
        stage3_evidence=stage3_evidence,stage3_report_sha256=stage3_report_sha256,io_workspace=io_workspace)
    try:
        write(output,report)
        if os.environ.get('JAX_PLATFORMS')!='cpu':raise ValueError('explicit CPU server process required')
        expected=key_gate.parse(key_gate.read(source_manifest));report['source_hashes_start']=hashes(expected)
        if report['source_hashes_start']!=expected:raise ValueError('server startup source differs')
        report['reviewed_dependencies']=dependencies.check()
        profile=(HERE/'runtime/stage/server_inputs/p60_profile_and_refresh.json').read_bytes()
        plan=(HERE/'runtime/stage/server_inputs/twelve_layer_plan.json').read_bytes()
        keys,model,inputs=authenticate(**gate_args,profile_bytes=profile,plan_bytes=plan)
        report['prerequisite']=prerequisite_summary(keys,model,inputs)
        paths=make_paths(keys,model,inputs,io_workspace);fresh_paths(paths)
        import file_stages,key_contexts,full_model_engine
        report['loaded_local_modules_start']=local_modules(expected)
        # No client-private/preprocessed path is supplied to the handler. The
        #guard remains active for request validation, computation and readback.
        with boundaries.server_only(calls,private_paths=(Path(key_workspace)/'client_private',)),redirect_stdout(sys.stderr):
            request=server_readback.requests(paths,keys=keys,model=model,stage3=inputs)
            report['request_readback_complete']=True
            report['request_readback']={n:v for n,v in request.items() if n!='batch'}
            report['actual_server_compute_started']=True;write(output,report)
            result=file_stages.server_encrypted_compute(paths)
            report['actual_server_compute_completed']=True
            response=server_readback.responses(paths,request=request)
            if (type(result)is not dict or type(result.get('sample_count'))is not int or result['sample_count']!=1
                    or result.get('public_batch_sha256')!=inputs['public_batch_sha256']
                    or response['sample_count']!=1 or response['response_count']!=1 or response['level']!=2):
                raise ValueError('actual size0 server response contract differs')
            # Revalidate all original public ciphertexts; no source input may
            #be changed by the server graph or its callbacks.
            if server_readback.requests(paths,keys=keys,model=model,stage3=inputs)!=request:
                raise ValueError('original upload changed during server compute')
        if calls:raise ValueError('server attempted forbidden action')
        after=authenticate(**gate_args,profile_bytes=profile,plan_bytes=plan)
        if prerequisite_summary(*after)!=report['prerequisite']:raise ValueError('server prerequisite identity changed')
        report.update(passed=True,response_readback_complete=True,response_readback=response,
            keygen_codecs_native_private_forbidden=True,context_id=keys['context_id'],model_id=model['model_id'])
    except BaseException as error:primary=error;report.update(passed=False,error=dict(type=type(error).__name__,message=str(error)))
    finally:
        with terminal_scope(report,output,write,cleanup_signals,lambda:(primary,None)):
            try:
                after=hashes(expected) if expected else {}
                report.update(source_hashes_end=after,source_files_unchanged=bool(expected) and after==expected,
                    forbidden_attempts=calls,elapsed_s=time.monotonic()-start)
                if expected:report['loaded_local_modules_end']=local_modules(expected)
                if paths is not None:report['remaining_artifacts']=remaining(paths)
                report['passed']=bool(report['passed'] and report['source_files_unchanged']);write(output,report)
            except BaseException as error:
                if primary is None:raise
                primary.add_note('stage4 final source/publication: '+repr(error))
            if primary is not None:raise primary
    print(json.dumps(dict(passed=report['passed'],context_id=report['context_id'],model_id=report['model_id'],
        public_batch_sha256=report['prerequisite']['public_batch_sha256'],
        worker_report_sha256=hashlib.sha256(output.read_bytes()).hexdigest(),elapsed_s=report['elapsed_s'])))
    return 0 if report['passed'] else 1

if __name__=='__main__':
    p=argparse.ArgumentParser()
    for name in ('key-evidence','key-workspace','model-evidence','model-workspace','stage3-evidence','io-workspace','output','source-manifest'):
        p.add_argument('--'+name,type=Path,required=True)
    for name in ('key-report-sha256','model-report-sha256','stage3-report-sha256'):p.add_argument('--'+name,required=True)
    with termination_signals():exit_code=run(**vars(p.parse_args()))
    raise SystemExit(exit_code)
