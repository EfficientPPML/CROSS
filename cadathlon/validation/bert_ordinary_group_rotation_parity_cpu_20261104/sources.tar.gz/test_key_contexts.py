"""Tiny mocked keys/contexts only: no real keygen, initialization or HE."""
from pathlib import Path
from types import SimpleNamespace
import json,os,stat,subprocess,sys
import numpy as np
import pytest
import key_contexts as loaders
import client_keys as keys
from test_client_keys import mocked,generate,PROFILE,RAW_PLAN

@pytest.fixture
def case(mocked,monkeypatch):
    m=mocked;generated=generate(m);events=[];contexts=[];converted=[]
    quarantine=[];monkeypatch.setattr(loaders,'_FAILURE_QUARANTINE',quarantine)
    def original(*a,**kw):return 'original'
    modules={name:SimpleNamespace(__name__=name,**{n:original for n in loaders.KEYGEN_METHODS}) for name in ('key_gen','jaxite_word.key_gen')}
    class Context:
        def __init__(self,parameters,**kw):
            events.append('construct');contexts.append(self)
            for module in modules.values():
                for name in loaders.KEYGEN_METHODS:
                    with pytest.raises(RuntimeError):getattr(module,name)()
            self.parameters=parameters;self.secret_key=parameters.get('secret_key');self.public_key=parameters.get('public_key');self.evaluation_key=parameters.get('evaluation_key')
            self.q_towers=parameters['q_towers'];self.p_towers=parameters['p_towers'];self.degree_layout=parameters['degree_layout']
        def program_initialization(self,rotations,**kw):
            events.append('initialize');assert self.secret_key is None and self.public_key is None
            for name in loaders.CODEC_METHODS:
                with pytest.raises(RuntimeError):getattr(self,name)()
            self._param_cache=SimpleNamespace(secret_key=None,per_level_rotation_keys=False,raw_rotation_keys=kw['pregenerated_rotation_keys'],coef_maps={i:object() for i in rotations})
    for name in (*loaders.CODEC_METHODS,'encode','encode_at_level'):setattr(Context,name,original)
    def asarray(a,**kw):converted.append(a);return np.array(a,copy=True,**kw)
    def evict(ctx):events.append('evict');assert ctx.__dict__;return 0
    def clear():events.append('clear')
    runtime=SimpleNamespace(Context=Context,key_modules=modules,jax=SimpleNamespace(numpy=SimpleNamespace(asarray=asarray),clear_caches=clear),ckks=SimpleNamespace(evict_context_caches=evict),polynomial=SimpleNamespace(_POLYNOMIAL_REGISTRY={}))
    def crypto():events.append('crypto');return runtime
    monkeypatch.setattr(loaders,'_crypto',crypto)
    yield SimpleNamespace(m=m,generated=generated,runtime=runtime,modules=modules,events=events,contexts=contexts,converted=converted,original=original)
    # Fake devices have no pending work; release test-only failure quarantine.
    for row in quarantine:
        for mapped in row['public_mappings']:mapped._mmap.close()
    quarantine.clear()

def client(c):return loaders.load_client(c.m.public,c.m.private,profile_bytes=PROFILE,plan_bytes=RAW_PLAN)
def server(c):return loaders.load_server(c.m.public,profile_bytes=PROFILE,plan_bytes=RAW_PLAN)

def assert_restored(c):
    assert all(getattr(m,n)is c.original for m in c.modules.values() for n in loaders.KEYGEN_METHODS)
    assert all(getattr(c.runtime.Context,n)is c.original for n in loaders.CODEC_METHODS)
    assert not loaders._ACTIVE.locked()


def test_backend_free_import():
    subprocess.run([sys.executable,'-c','import key_contexts,sys; assert not any(n in sys.modules for n in ("jax","torch","jaxite_word"))'],cwd=Path(loaders.__file__).parent,check=True)


def test_server_guards_before_setup_no_secret_mapping_and_no_store_copy(case):
    c=case
    with server(c) as h:
        ctx=h.ctx;assert not hasattr(h,'private_manifest') and ctx.secret_key is None and ctx.public_key is None
        mapped=[entry[part] for entry in ctx._param_cache.raw_rotation_keys.values() for part in ('a','b')]
        assert all(isinstance(a,np.memmap) and not a.flags.writeable for a in mapped)
        assert len(c.converted)==2 and all(a.shape==(1,3,4) for a in c.converted)
        assert ctx.encode()=='original' and ctx.encode_at_level()=='original'
        for name in loaders.CODEC_METHODS:
            with pytest.raises(RuntimeError):getattr(ctx,name)()
        assert c.events[:3]==['crypto','construct','initialize']
    assert h.ctx is None and not vars(ctx) and all(a._mmap.closed for a in mapped)
    assert c.events[-2:]==['evict','clear'];assert_restored(c)


def test_client_reopens_with_known_metadata_and_no_server_setup(case):
    c=case
    for n in loaders.PRIVATE_OPTIONAL:
        (c.m.private/n).write_text('{}');os.chmod(c.m.private/n,0o600)
    for _ in range(2):
        with client(c) as h:
            ctx=h.ctx;secret=ctx.secret_key;public=ctx.public_key
            assert isinstance(secret,np.memmap) and isinstance(public,np.memmap)
            assert not hasattr(ctx,'_param_cache') and h.private_manifest==c.generated['private_manifest']
            assert ctx.encrypt_slots()=='original' and ctx.decrypt_slots()=='original'
        assert h.ctx is None and not vars(ctx) and secret._mmap.closed and public._mmap.closed
        assert_restored(c)
    assert 'initialize' not in c.events and not c.converted

@pytest.mark.parametrize('name',('secret.npy','private_manifest.json'))
def test_server_never_opens_private_files(case,monkeypatch,name):
    original=loaders.os.open
    def guarded(path,*a,**kw):
        if str(path)==name or str(path)==str(case.m.private):raise AssertionError('private path access')
        return original(path,*a,**kw)
    monkeypatch.setattr(loaders.os,'open',guarded)
    with server(case):pass

@pytest.mark.parametrize('bad',('unknown','symlink_optional','fifo_optional','private_mode','secret_mode','manifest_mode','private_binding'))
def test_private_fail_closed_before_context(case,bad):
    c=case
    if bad=='unknown':(c.m.private/'unexpected').write_text('x')
    elif bad=='symlink_optional':(c.m.private/'requests.json').symlink_to(c.m.private/'secret.npy')
    elif bad=='fifo_optional':os.mkfifo(c.m.private/'completed.json',0o600)
    elif bad=='private_mode':os.chmod(c.m.private,0o755)
    elif bad=='secret_mode':os.chmod(c.m.private/'secret.npy',0o644)
    elif bad=='manifest_mode':os.chmod(c.m.private/'private_manifest.json',0o644)
    else:
        p=c.m.private/'private_manifest.json';m=keys._json(p.read_bytes());m['context_id']='a'*64;p.write_bytes(keys.canonical(m))
    with pytest.raises((ValueError,OSError)): 
        with client(c):pass
    assert 'crypto' not in c.events;assert_restored(c)

@pytest.mark.parametrize('bad',('security','profile','missing_key','unexpected','key_hash','key_residue','key_shape','key_fifo','key_symlink','runtime_mode'))
def test_public_fail_closed_before_context(case,monkeypatch,bad):
    c=case;p=c.m.public/'rot_2_a.npy'
    if bad=='security':
        monkeypatch.setattr(keys,'_security_check',lambda p:(_ for _ in ()).throw(ValueError('security')))
    elif bad=='profile':
        monkeypatch.setattr(keys,'public_contract',lambda p,r:(_ for _ in ()).throw(ValueError('profile')))
    elif bad=='missing_key':p.unlink()
    elif bad=='unexpected':(c.m.public/'secret.npy').write_bytes(b'no')
    elif bad=='runtime_mode':monkeypatch.setenv('CROSS_SKIP_TOPLEVEL_ROTKEYS','1')
    elif bad=='key_fifo':p.unlink();os.mkfifo(p)
    elif bad=='key_symlink':p.rename(c.m.public/'actual');p.symlink_to(c.m.public/'actual')
    else:
        array=np.zeros((1,3,4),dtype=np.uint32)
        if bad=='key_residue':array[0,0,0]=17
        if bad=='key_shape':array=array[:,:,:3]
        np.save(p,array)
        if bad!='key_hash':
            manifest=keys._json((c.m.public/'public_manifest.json').read_bytes());manifest['arrays'][p.name]['sha256']=keys.hashlib.sha256(p.read_bytes()).hexdigest();manifest['arrays'][p.name]['bytes']=p.stat().st_size
            body={k:v for k,v in manifest.items() if k!='context_id'};manifest['context_id']=keys.digest(body);(c.m.public/'public_manifest.json').write_bytes(keys.canonical(manifest))
        else:
            with p.open('r+b') as f:f.seek(-1,2);f.write(b'1')
    with pytest.raises((ValueError,OSError)):
        with server(c):pass
    assert 'crypto' not in c.events;assert_restored(c)

@pytest.mark.parametrize('error',(RuntimeError('stage failed'),KeyboardInterrupt('stage cancelled')))
def test_stage_failure_closes_maps_context_and_restores_guards(case,error):
    c=case
    with pytest.raises(type(error)) as caught:
        with server(c) as h:
            ctx=h.ctx;maps=[v for pair in ctx._param_cache.raw_rotation_keys.values() for v in pair.values()]
            raise error
    assert caught.value is error and h.ctx is None and not vars(ctx)
    assert all(not a._mmap.closed for a in maps) and len(loaders._FAILURE_QUARANTINE)==1;assert_restored(c)


def test_partial_setup_failure_restores_and_releases(case,monkeypatch):
    c=case;original=c.runtime.Context.program_initialization
    def fail(ctx,*a,**kw):original(ctx,*a,**kw);raise KeyboardInterrupt('initialization interrupted')
    monkeypatch.setattr(c.runtime.Context,'program_initialization',fail)
    with pytest.raises(KeyboardInterrupt):
        with server(c):pass
    assert len(c.contexts)==1 and not vars(c.contexts[0]);assert_restored(c)

@pytest.mark.parametrize('primary',(False,True))
def test_cleanup_attempts_everything_preserves_primary(case,monkeypatch,primary):
    c=case;error=KeyboardInterrupt('primary');closed=[];original=loaders._ReadDirectory.close
    def close(owner):original(owner);closed.append(owner.path);raise RuntimeError('close failure')
    monkeypatch.setattr(loaders._ReadDirectory,'close',close)
    c.runtime.ckks.evict_context_caches=lambda ctx:(_ for _ in ()).throw(KeyboardInterrupt('cleanup cancellation'))
    with pytest.raises(KeyboardInterrupt) as caught:
        with client(c) as h:
            ctx=h.ctx;sk=ctx.secret_key
            if primary:raise error
    assert caught.value is error if primary else str(caught.value)=='cleanup cancellation'
    assert not vars(ctx) and sk._mmap.closed and closed==[c.m.private,c.m.public]
    assert_restored(c)


def test_nested_loader_rejected_without_perturbing_outer(case):
    with server(case) as h:
        with pytest.raises(RuntimeError):
            with client(case):pass
        with pytest.raises(RuntimeError):h.ctx.decrypt_slots()
    assert_restored(case)

@pytest.mark.parametrize('kind',('file','directory','parent'))
def test_key_replacement_during_stage_rejected_and_replacement_retained(case,kind):
    c=case
    with pytest.raises((ValueError,OSError)):
        with client(c):
            if kind=='file':
                path=c.m.private/'secret.npy';path.rename(c.m.private/'old-secret.npy');path.write_bytes(b'replacement')
            elif kind=='directory':
                c.m.private.rename(c.m.private.with_name('old-private'));c.m.private.mkdir();(c.m.private/'marker').write_text('replacement')
            else:
                parent=c.m.public.parent;parent.rename(parent.with_name(parent.name+'-old'));parent.mkdir();(parent/'marker').write_text('replacement')
    if kind=='file':assert path.read_bytes()==b'replacement'
    elif kind=='directory':assert (c.m.private/'marker').read_text()=='replacement'
    else:assert (parent/'marker').read_text()=='replacement'
    assert_restored(c)


def test_missing_alias_guard_rejects_before_construct(case):
    case.runtime.key_modules.pop('key_gen')
    with pytest.raises(RuntimeError):
        with server(case):pass
    assert not case.contexts and not loaders._ACTIVE.locked()


@pytest.mark.parametrize('field',('secret_key','per_level_rotation_keys'))
def test_server_detects_secret_and_reusable_mode_mutation(case,field):
    with pytest.raises(ValueError):
        with server(case) as h:setattr(h.ctx._param_cache,field,[] if field=='secret_key' else True)
    assert_restored(case)


def test_partial_map_failure_closes_every_previous_mapping(case,monkeypatch):
    original=loaders._map_array;opened=[]
    def wrapped(owner,name,*args):
        if name=='rot_2_a.npy':raise KeyboardInterrupt('mapping interrupted')
        mapped,state=original(owner,name,*args);opened.append(mapped);return mapped,state
    monkeypatch.setattr(loaders,'_map_array',wrapped)
    with pytest.raises(KeyboardInterrupt):
        with server(case):pass
    assert opened and all(a._mmap.closed for a in opened) and not case.contexts
    assert_restored(case)


def test_successful_map_fd_close_failure_closes_created_mapping(case,monkeypatch):
    c=case;owner=loaders._ReadDirectory(c.m.public);realclose=loaders.os.close;maps=[];memmap=np.memmap
    def mapping(*a,**kw):value=memmap(*a,**kw);maps.append(value);return value
    monkeypatch.setattr(loaders.np,'memmap',mapping)
    def close(fd):realclose(fd);raise KeyboardInterrupt('fd close cancellation')
    monkeypatch.setattr(loaders.os,'close',close)
    try:
        name='relin_a.npy';spec=keys.inventory(c.m.params,c.m.rotations)[name]
        with pytest.raises(KeyboardInterrupt):loaders._map_array(owner,name,c.generated['public_manifest']['arrays'][name],*spec)
        assert len(maps)==1 and maps[0]._mmap.closed
    finally:monkeypatch.setattr(loaders.os,'close',realclose);owner.close()


def test_later_cleanup_cancellation_wins_over_ordinary_cleanup_failure(case,monkeypatch):
    c=case;c.runtime.ckks.evict_context_caches=lambda ctx:(_ for _ in ()).throw(ValueError('ordinary cleanup failure'))
    c.runtime.jax.clear_caches=lambda:(_ for _ in ()).throw(KeyboardInterrupt('later cancellation'))
    with pytest.raises(KeyboardInterrupt) as caught:
        with client(c):pass
    assert str(caught.value)=='later cancellation' and any('ordinary cleanup failure' in x for x in caught.value.__notes__)
    assert_restored(c)

@pytest.mark.parametrize('failure',('constructor','second_transfer','transpose'))
def test_pending_transfers_synchronized_before_maps_close_on_partial_setup(case,monkeypatch,failure):
    c=case;events=[];map_array=loaders._map_array
    def map_checked(*args):
        mapped,state=map_array(*args);backing=mapped._mmap
        mapped._mmap=SimpleNamespace(close=lambda:(events.append('map-close'),backing.close()))
        return mapped,state
    monkeypatch.setattr(loaders,'_map_array',map_checked)
    class Device:
        def __init__(self,index):self.index=index
        def transpose(self,*args):
            if failure=='transpose':raise KeyboardInterrupt('transpose failed')
            return self
        def block_until_ready(self):events.append(('barrier',self.index))
    created=[]
    def convert(*args,**kwargs):
        if failure=='second_transfer' and created:raise KeyboardInterrupt('conversion failed')
        value=Device(len(created));created.append(value);return value
    c.runtime.jax.numpy.asarray=convert
    old_init=c.runtime.Context.__init__
    def construct(self,*args,**kwargs):old_init(self,*args,**kwargs);raise KeyboardInterrupt('constructor failed')
    monkeypatch.setattr(c.runtime.Context,'__init__',construct)
    with pytest.raises(KeyboardInterrupt):
        with server(c):pass
    expected=2 if failure=='constructor' else 1
    assert len(created)==expected and events[:expected]==[('barrier',i) for i in range(expected)]
    assert 'map-close' in events and all(e=='map-close' for e in events[expected:]);assert_restored(c)


def test_client_early_map_close_failure_is_retried_in_finally(case,monkeypatch):
    original=loaders._map_array;calls=[];backings=[]
    def wrapped(owner,name,*args):
        mapped,state=original(owner,name,*args)
        if name=='relin_a.npy':
            backing=mapped._mmap;backings.append(backing)
            def close():
                calls.append('close')
                if len(calls)==1:raise KeyboardInterrupt('first close interrupted')
                backing.close()
            mapped._mmap=SimpleNamespace(close=close)
        return mapped,state
    monkeypatch.setattr(loaders,'_map_array',wrapped)
    with pytest.raises(KeyboardInterrupt):
        with client(case):pass
    assert calls==['close','close'] and backings[0].closed;assert_restored(case)


def test_unexpected_public_file_added_during_stage_rejected(case):
    with pytest.raises(ValueError):
        with server(case):(case.m.public/'secret.npy').write_bytes(b'extra')
    assert (case.m.public/'secret.npy').read_bytes()==b'extra';assert_restored(case)

@pytest.mark.parametrize('primary',(False,True))
def test_unresolved_readiness_quarantines_backing_and_blocks_reuse(case,monkeypatch,primary):
    c=case;quarantine=[];monkeypatch.setattr(loaders,'_FAILURE_QUARANTINE',quarantine)
    events=[]
    class Device:
        def __init__(self,index):self.index=index
        def transpose(self,*a):return self
        def block_until_ready(self):
            events.append(self.index)
            if self.index==0:raise KeyboardInterrupt('unknown transfer readiness')
    devices=[]
    def convert(*a,**kw):d=Device(len(devices));devices.append(d);return d
    c.runtime.jax.numpy.asarray=convert;error=RuntimeError('original stage error')
    try:
        with pytest.raises(RuntimeError if primary else KeyboardInterrupt) as caught:
            with server(c):
                if primary:raise error
        assert caught.value is error if primary else str(caught.value)=='unknown transfer readiness'
        assert len(quarantine)==1 and events==[0,1]
        assert all(not a._mmap.closed for a in quarantine[0]['public_mappings'])
        assert any('cleanup incomplete' in n for n in caught.value.__notes__)
        assert_restored(c)
        with pytest.raises(RuntimeError,match='must exit'):
            with client(c):pass
        assert len(c.contexts)==1
    finally:
        # Test-only fake transfers have no asynchronous work. Never expose a
        #production retry/reclaim API while readiness is unknown.
        for row in quarantine:
            for a in row['public_mappings']:a._mmap.close()
        quarantine.clear()

@pytest.mark.parametrize('primary',(False,True))
def test_repeated_cleanup_signals_deferred_until_all_resources_released(case,primary):
    import signal
    c=case;old={s:signal.getsignal(s) for s in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP)}
    def notify():
        for s in (signal.SIGINT,signal.SIGTERM,signal.SIGTERM):signal.getsignal(s)(s,None)
    c.runtime.jax.clear_caches=notify;error=ValueError('primary failure')
    with pytest.raises(ValueError if primary else KeyboardInterrupt) as caught:
        with client(c) as h:
            secret=h.ctx.secret_key
            if primary:raise error
    assert caught.value is error if primary else 'signals deferred' in str(caught.value)
    assert h.ctx is None and secret._mmap.closed and {s:signal.getsignal(s) for s in old}==old
    assert_restored(c)

@pytest.mark.parametrize('discarded',(False,True))
def test_failed_server_stage_quarantines_even_discarded_lazy_key_controls(case,discarded):
    events=[]
    class Lazy:
        def block_until_ready(self):events.append('lazy ready')
    with pytest.raises(RuntimeError,match='stage failed') as caught:
        with server(case) as h:
            cache=h.ctx._param_cache;cache._formatted_rotation_keys={1:(Lazy(),Lazy())}
            if discarded:cache._formatted_rotation_keys.clear()
            raise RuntimeError('stage failed')
    assert events==([] if discarded else ['lazy ready','lazy ready'])
    assert len(loaders._FAILURE_QUARANTINE)==1 and loaders._FAILURE_QUARANTINE[0]['reason']=='failed entered server stage'
    assert all(not a._mmap.closed for a in loaders._FAILURE_QUARANTINE[0]['public_mappings'])
    assert any('cleanup incomplete' in n for n in caught.value.__notes__)
    with pytest.raises(RuntimeError,match='must exit'):
        with server(case):pass
    assert_restored(case)


def test_normal_stage_waits_reachable_lazy_keys_before_map_close(case,monkeypatch):
    events=[];original=loaders._map_array
    def wrapped(*args):
        mapped,state=original(*args);backing=mapped._mmap;mapped._mmap=SimpleNamespace(close=lambda:(events.append('map close'),backing.close()));return mapped,state
    monkeypatch.setattr(loaders,'_map_array',wrapped)
    class Lazy:
        def block_until_ready(self):events.append('lazy ready')
    with server(case) as h:h.ctx._param_cache._formatted_rotation_keys={1:(Lazy(),Lazy())}
    assert events[:2]==['lazy ready','lazy ready'] and events[2:] and all(x=='map close' for x in events[2:])
    assert not loaders._FAILURE_QUARANTINE;assert_restored(case)
