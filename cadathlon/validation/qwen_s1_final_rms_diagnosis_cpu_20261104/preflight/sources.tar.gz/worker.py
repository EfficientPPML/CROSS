"""One fixed public embedding-row diagnostic; no framework, HE or final polynomial."""
from pathlib import Path
import argparse,hashlib,json,os,sys,time
import numpy as np
from trajectory_assets import PublicParameters,asset_gate,sha,requirement
from validation_cleanup import cleanup_signals,termination_signals
from validation_terminal import terminal_scope
from finish import finish
import prepare_metadata
from diagnosis import prefix,compare
P=Path(__file__).resolve().parent
class NoBackend:
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in ('jax','jaxlib','torch','transformers','safetensors'):raise RuntimeError('diagnosis forbids framework/backend import')
sys.meta_path.insert(0,NoBackend())
def write(path,row):
 temporary=path.with_suffix('.tmp');temporary.write_text(json.dumps(row,indent=2,allow_nan=False)+'\n');temporary.replace(path)
def sources():return {n:sha(P/n) for n in json.loads((P/'inventory.json').read_bytes())['sources']}
def gate():
 copied=json.loads((P/'copied_sources.json').read_bytes())
 if {n:sha(P/n) for n in copied['sources']}!=copied['sources']:raise ValueError('copied frozen source changed')
 return prepare_metadata.verify()
def execute(out):
 start=time.monotonic();primary=cleanup_error=None;parameters=None
 report=dict(passed=False,complete=False,cleanup_completed=False,termination_scope_completed=False,scope=__doc__,
   HE_executed=False,native_framework_executed=False,final_normalization_evaluated=False,vocabulary_evaluated=False,
   candidate_changed=False,original_S1_gate_passed=False)
 try:
  write(out/'report.json',report);report['source_hashes_before']=sources();report['provenance']=gate();req=requirement()
  report['asset_sha256_before']=asset_gate(req)
  metadata=json.loads((P/'public_metadata.json').read_bytes());parameters=PublicParameters(req)
  embeddings=parameters.matrix('model.embed_tokens.weight')[[0]].copy()
  report['fixture']=metadata['historical_S1']['fixture'];report['embedding_sha256']=hashlib.sha256(embeddings.tobytes()).hexdigest()
  if report['embedding_sha256']!=metadata['historical_S1']['embedding_sha256']:raise ValueError('original fixed row0 embedding differs')
  mb=(P/'inputs/candidate_manifest.json').read_bytes();cb=(P/'inputs/config.json').read_bytes()
  kwargs=dict(manifest_bytes=mb,config_bytes=cb,matrix=parameters.matrix,gamma=parameters.gamma)
  approximate=prefix(embeddings,(0,),**kwargs,mode='frozen_approximate')
  print(json.dumps(dict(phase='unchanged_approximate_prefix_stopped_before_final',variance=approximate.final_variance)),flush=True)
  expected=metadata['historical_S1']['failure_detail']['record']
  if approximate.final_domain!=expected:raise ValueError('historical frozen approximate final boundary was not reproduced exactly')
  exact=prefix(embeddings,(0,),**kwargs,mode='exact_function_numpy')
  print(json.dumps(dict(phase='independent_exact_function_prefix_stopped_before_final',variance=exact.final_variance)),flush=True)
  report['paired']=compare(approximate,exact)
  if not report['paired']['approximate_prior_domains_passed']:raise ValueError('approximate prefix violated an earlier domain')
  report.update(complete=True,historical_boundary_reproduced_exactly=True,parameter_records=dict(parameters.records),
    exact_function_scope='NumPy sqrt/stable sigmoid with same original weights/positions and S1 V0 bypass; not native framework/CKKS evidence',
    diagnosis_scope='Both28-block prefixes stop before final inverse polynomial and output head; exact branch domain rows are diagnostics, not frozen-candidate acceptance',
    backend_modules=[n for n in ('jax','jaxlib','torch','transformers','safetensors') if n in sys.modules])
  if report['backend_modules']:raise ValueError('forbidden backend imported')
 except BaseException as error:primary=error;report['failure_detail']=dict(type=type(error).__name__,message=str(error),notes=getattr(error,'__notes__',[]))
 finally:
  with terminal_scope(report,out/'report.json',write,cleanup_signals,lambda:(primary,cleanup_error)):
   def attempt(fn):
    nonlocal cleanup_error
    try:fn()
    except BaseException as error:
     if cleanup_error is None:cleanup_error=error
     elif isinstance(cleanup_error,Exception) and not isinstance(error,Exception):error.add_note(repr(cleanup_error));cleanup_error=error
     else:cleanup_error.add_note(repr(error))
   if parameters is not None:
    attempt(parameters.readback);attempt(parameters.close)
   attempt(lambda:report.update(provenance_after=gate()))
   if 'asset_sha256_before' in report:attempt(lambda:report.update(asset_sha256_after=asset_gate(requirement())))
   attempt(lambda:report.update(source_hashes_after=sources()))
   report['source_files_unchanged']=bool(report.get('source_hashes_before')) and report['source_hashes_before']==report.get('source_hashes_after')
   report['assets_unchanged']=bool(report.get('asset_sha256_before')) and report['asset_sha256_before']==report.get('asset_sha256_after')
   report['provenance_unchanged']=bool(report.get('provenance')) and report['provenance']==report.get('provenance_after')
   report['cleanup_completed']=cleanup_error is None
   if cleanup_error:report['cleanup_error']=dict(type=type(cleanup_error).__name__,message=str(cleanup_error))
   report['passed']=primary is None and cleanup_error is None and report['complete'] and report['source_files_unchanged'] and report['assets_unchanged'] and report['provenance_unchanged']
   report['elapsed_s']=time.monotonic()-start;write(out/'report.json',report)
 if primary is not None:
  if cleanup_error:primary.add_note(repr(cleanup_error))
  raise primary
 if cleanup_error:raise cleanup_error
 return report

def main():
 p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true',required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
 args.output.mkdir(exist_ok=False)
 report=finish(args.output/'report.json',lambda:execute(args.output),write,lambda p:p.read_bytes(),termination=termination_signals,shield=cleanup_signals)
 return 0 if report['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
