# Fixed S1 final-RMS diagnosis

This separate capsule diagnoses the preserved S1 failure. It does not change
candidate3, any domain/degree/count, the fixture, or an acceptance gate.

Both clear paths start the same authenticated checkpoint embedding row0 at
original position0. The exact copied full_reference.forward code object runs in
an isolated globals dictionary. Approximate RMS/SiLU functions stay unchanged;
all earlier approximate domain assertions remain active. The paired clear path
uses NumPy sqrt and stable sigmoid instead. S1 causal attention remains the
literal V0 bypass. Both stop before the final inverse polynomial/product/head.
No rejected approximation is evaluated and no logits are produced.

The diagnostic records 28 block differences and all113 variance inputs. The
exact-function path is a NumPy functional comparison, not a native framework,
CKKS or packed-owner measurement. Exact-path domain comparisons are diagnostic;
they do not replace the frozen approximate path's mandatory acceptance checks.

Original public ranges and protocol metadata explain the domain derivation:
calibration native/exact union, original 0.8/1.2 slack, then uniform factor4.
Calibration has sequence lengths8/16/32 and decode prefixes16–19. This documents
a coverage gap for the fixed S1 fixture independently of any trajectory drift.
The original416 input archive/token bodies, fresh and heldout inputs are never
opened by this capsule. Public report bodies are pinned and rechecked.

The collector snapshots all exact sources, independently reads every tar member,
executes from a newly verified source tree without bytecode, and requires direct
child wait plus owned-group absence. Parameters are authenticated before use and
mapped through completion/readback. Source/asset/public-metadata readback and
primary-preserving cleanup are mandatory. Reports contain aggregates and hashes,
not tensors. `passed` means the diagnosis completed under these checks; the
original S1 candidate-domain gate remains explicitly false.

A possible successor requires a separately frozen calibration protocol spanning
short sequence geometries uniformly, using only declared public/calibration
input provenance, unchanged original numeric/semantic gates, and a new untouched
validation set. The maximum3-candidate historical protocol and its completed
validation results must be preserved. This capsule selects no new domains or
coefficients and does not claim any wider domain would pass HE.
