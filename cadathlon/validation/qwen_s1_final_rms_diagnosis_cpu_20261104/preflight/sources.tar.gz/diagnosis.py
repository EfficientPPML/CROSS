"""Fixed row0 paired clear prefixes. Neither branch evaluates final RMS/logits.

The approximate branch executes the byte-identical copied dense forward with
its original norm/SiLU functions. A separate globals dictionary supplies only
an observation wrapper and a stop at the final norm boundary. The exact-function
branch changes RMS inverse sqrt and SiLU to NumPy functions; this is not a
framework/native measurement. S1 attention is explicitly the unchanged V0 bypass.
"""
from dataclasses import dataclass
import hashlib,types
import numpy as np
import full_reference as frozen

FINAL='final.inverse_sqrt'
@dataclass(frozen=True)
class Prefix:
    blocks:tuple
    variances:dict
    domains:dict
    final_input:np.ndarray
    final_variance:float
    final_domain:dict
    mode:str

class StoppedBeforeFinal(Exception):
    pass

def variance(value,epsilon):
    return frozen.finite(np.sum(value*value,axis=-1,keepdims=True)*(1./value.shape[-1])+epsilon,'diagnostic variance')

def domain_record(value,domain):
    value=frozen.finite(value,'diagnostic domain')
    return dict(domain=list(domain),count=int(value.size),minimum=float(value.min()),maximum=float(value.max()),
                below=int(np.sum(value<domain[0])),above=int(np.sum(value>domain[1])),nonfinite=0)

def exact_silu(value):
    value=frozen.finite(value,'exact-function SiLU input');sigmoid=np.empty_like(value)
    positive=value>=0;sigmoid[positive]=1./(1.+np.exp(-value[positive]))
    exponent=np.exp(value[~positive]);sigmoid[~positive]=exponent/(1.+exponent)
    return frozen.finite(value*sigmoid,'exact-function SiLU')

def prefix(embeddings,positions,*,manifest_bytes,config_bytes,matrix,gamma,mode):
    if mode not in ('frozen_approximate','exact_function_numpy'):raise ValueError('explicit fixed diagnostic mode required')
    if type(embeddings)is not np.ndarray or embeddings.shape!=(1,1024) or embeddings.dtype!=np.dtype('float64') or positions!=(0,):raise ValueError('only the fixed single original-position row is in scope')
    blocks=[];variances={};records={};last={}
    def observe_finite(value,label):
        result=frozen.finite(value,label)
        if label.endswith('.block'):
            if label!=str(len(blocks))+'.block':raise ValueError('literal block order differs')
            blocks.append(result.copy())
        return result
    def norm(value,weight,epsilon,rule,label,domains):
        v=variance(value,epsilon);variances[label]=v.copy()
        if label==FINAL:
            # Capture before any final inverse polynomial, multiply or head.
            last.update(value=value.copy(),variance=v.copy(),domain=domain_record(v,rule['domain']))
            records.update(domains)
            raise StoppedBeforeFinal()
        if mode=='frozen_approximate':return frozen.norm(value,weight,epsilon,rule,label,domains)
        domains[label]=domain_record(v,rule['domain']) # diagnostic only; not the frozen acceptance path
        return frozen.finite(value/np.sqrt(v)*weight,label+'.exact_function_normalized')
    def silu(value,rule,label,domains):
        if mode=='frozen_approximate':return frozen.silu(value,rule,label,domains)
        domains[label]=domain_record(value,rule['domain'])
        return exact_silu(value)
    def causal(query,key,value,rule,manifest,label,domains):
        if len(query)!=1 or len(key)!=1 or len(value)!=1:raise ValueError('only S1 bypass authorized')
        return frozen.causal(query,key,value,rule,manifest,label,domains)
    namespace=dict(frozen.forward.__globals__)
    namespace.update(norm=norm,silu=silu,finite=observe_finite,causal=causal)
    forward=types.FunctionType(frozen.forward.__code__,namespace,'diagnostic_forward')
    try:forward(embeddings,positions,manifest_bytes=manifest_bytes,config_bytes=config_bytes,matrix=matrix,gamma=gamma)
    except StoppedBeforeFinal:pass
    else:raise AssertionError('the final normalization boundary was not intercepted')
    if len(blocks)!=28 or len(variances)!=113 or last['variance'].shape!=(1,1):raise AssertionError('complete fixed 28-block prefix required')
    return Prefix(tuple(blocks),variances,records,last['value'],float(last['variance'][0,0]),last['domain'],mode)

def compare(approximate,exact):
    if approximate.mode!='frozen_approximate' or exact.mode!='exact_function_numpy':raise ValueError('paired modes differ')
    rows=[]
    for index,(a,b) in enumerate(zip(approximate.blocks,exact.blocks,strict=True)):
        error=frozen.finite(a-b,'paired block difference')
        rows.append(dict(layer=index,max_abs_error=float(np.max(np.abs(error))),
            rms_error=float(np.sqrt(frozen.finite(np.mean(error*error),'paired rms error'))),exact_rms=float(np.sqrt(frozen.finite(np.mean(b*b),'paired exact rms'))),
            approximate_sha256=hashlib.sha256(a.tobytes()).hexdigest(),exact_function_sha256=hashlib.sha256(b.tobytes()).hexdigest()))
    sites={name:dict(approximate_min=float(a.min()),approximate_max=float(a.max()),exact_min=float(exact.variances[name].min()),
                     exact_max=float(exact.variances[name].max()),max_abs_difference=float(np.max(np.abs(a-exact.variances[name]))))
           for name,a in approximate.variances.items()}
    return dict(blocks=rows,variance_sites=sites,final_variance_difference=approximate.final_variance-exact.final_variance,
                final_variance_relative_difference=(approximate.final_variance-exact.final_variance)/exact.final_variance,
                approximate_final=approximate.final_domain,exact_function_final=exact.final_domain,
                approximate_prefix_domain_records=len(approximate.domains),exact_function_domain_diagnostics=len(exact.domains),
                approximate_prior_domains_passed=all(not any(v[k] for k in ('below','above','nonfinite')) for v in approximate.domains.values()),
                exact_function_domain_diagnostic_failures={n:r for n,r in exact.domains.items() if any(r[k] for k in ('below','above','nonfinite'))})
