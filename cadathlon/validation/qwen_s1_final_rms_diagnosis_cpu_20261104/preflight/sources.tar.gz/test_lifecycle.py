"""Mock-only worker/collector publication and dedicated-process boundaries."""
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
import json,sys
import numpy as np
import pytest
import collect as c
import worker as w

@pytest.fixture
def fake_collection(tmp_path,monkeypatch):
    root=tmp_path/'lab';root.mkdir();(root/'source.py').write_text('public synthetic source\n')
    (root/'inventory.json').write_text(json.dumps({'sources':['source.py','inventory.json'],'tests':['fake.py'],'expected_tests':1}))
    (root/'public_metadata.json').write_text('{}')
    monkeypatch.setattr(c,'P',root)
    state=SimpleNamespace(mode='healthy',owners=[],primary=None,close_error=None,out=root/'out')
    class Child:
        def __init__(self,command,*,cwd,stdout,env):
            if state.mode=='launch':raise RuntimeError('injected launch failure')
            self.pid=765000+len(state.owners);state.owners.append(self)
            self.record=dict(pid=self.pid,process_group=self.pid,direct_child_reaped=False,direct_returncode=None,group_empty_verified=False,cleanup_completed=False)
        def wait(self):
            if state.mode in ('wait','cancel'):
                state.primary=KeyboardInterrupt('chosen cancellation') if state.mode=='cancel'else ValueError('chosen child error');raise state.primary
            self.record.update(direct_child_reaped=True,direct_returncode=0,group_empty_verified=state.mode=='healthy',cleanup_completed=state.mode=='healthy')
            if state.mode=='missing':self.record.pop('group_empty_verified')
            (state.out/'tests.xml').write_text('<testsuites><testsuite tests="1" failures="0" errors="0" skipped="0"/></testsuites>')
            (state.out/'audit.json').write_text(json.dumps(dict(passed=True,denied_attempts=[],backend_modules=[])))
            return 0
        def close(self,primary=None):
            self.record.update(direct_child_reaped=True,direct_returncode=-15,group_empty_verified=True,cleanup_completed=True)
            if state.close_error is not None:
                self.record['cleanup_completed']=False
                if primary is not None:primary.add_note('secondary cleanup '+repr(state.close_error))
                else:raise state.close_error
    monkeypatch.setattr(c,'OwnedChild',Child);monkeypatch.setattr(sys,'argv',['collect','--output',str(state.out)])
    state.report=lambda:json.loads((state.out/'report.json').read_bytes());return state

def test_collector_complete_and_group_gates(fake_collection):
    assert c.main()==0;r=fake_collection.report();assert r['passed'] and r['termination_scope_completed'] and r['terminal_scope_completed']
    assert len(r['children'])==1 and r['children'][0]['group_empty_verified']

@pytest.mark.parametrize('mode',['surviving','missing','wait','cancel','launch'])
def test_collector_child_failures_preserve_false_and_primary(fake_collection,mode):
    fake_collection.mode=mode
    expected=KeyboardInterrupt if mode=='cancel'else ValueError if mode=='wait'else RuntimeError
    with pytest.raises(expected)as found:c.main()
    if mode in('wait','cancel'):assert found.value is fake_collection.primary
    assert not fake_collection.report()['passed']

def test_cancel_survives_secondary_cleanup(fake_collection):
    fake_collection.mode='cancel';fake_collection.close_error=OSError('secondary')
    with pytest.raises(KeyboardInterrupt)as found:c.main()
    assert found.value is fake_collection.primary and found.value.__notes__
    assert not fake_collection.report()['passed']

@pytest.mark.parametrize('scope',['cleanup_signals','termination_signals'])
@pytest.mark.parametrize('kind',[OSError,KeyboardInterrupt,SystemExit])
def test_terminal_failures_republish_false(fake_collection,monkeypatch,scope,kind):
    @contextmanager
    def broken():yield;raise kind('restoration')
    monkeypatch.setattr(c,scope,broken)
    with pytest.raises(kind):c.main()
    assert not fake_collection.report()['passed'] and not fake_collection.report()['termination_scope_completed']

@pytest.mark.parametrize('module',[c,w])
def test_existing_output_evidence_never_overwritten(tmp_path,monkeypatch,module):
    out=tmp_path/'prior';out.mkdir();raw=b'{"passed":true,"prior_exact_receipt":"preserve"}\n';(out/'report.json').write_bytes(raw)
    argv=['program','--output',str(out)]
    if module is w:argv+=['--execute']
    monkeypatch.setattr(sys,'argv',argv)
    with pytest.raises(FileExistsError):module.main()
    assert (out/'report.json').read_bytes()==raw and list(out.iterdir())==[out/'report.json']

def test_collector_runs_verified_execution_tree_without_bytecode(fake_collection):
    assert c.main()==0;r=fake_collection.report()
    assert r['execution_source_hashes_before']==r['execution_source_hashes_after']==r['source_hashes_before']
    assert (fake_collection.out/'execution/source.py').read_text()=='public synthetic source\n'
    assert not list((fake_collection.out/'execution').rglob('*.pyc'))

def test_execution_copy_drift_fails_before_child(fake_collection,monkeypatch):
    original=c.execution_tree
    def corrupt(out,before):
        root=original(out,before);(root/'source.py').write_text('changed');return root
    monkeypatch.setattr(c,'execution_tree',corrupt)
    # A copy changed after verification cannot produce a passing terminal report.
    with pytest.raises(ValueError,match='before child'):c.main()
    assert not fake_collection.report()['execution_files_unchanged'] and not fake_collection.owners

@pytest.mark.parametrize('kind',[ValueError,KeyboardInterrupt,SystemExit])
def test_worker_gate_failure_before_parameters(tmp_path,monkeypatch,kind):
 out=tmp_path/'out';out.mkdir();primary=kind('first public gate')
 monkeypatch.setattr(w,'sources',lambda:{'mock':'hash'})
 def gate():raise primary
 monkeypatch.setattr(w,'gate',gate)
 monkeypatch.setattr(w,'PublicParameters',lambda *a:pytest.fail('public body opened before source/evidence gate'))
 with pytest.raises(kind)as found:w.execute(out)
 assert found.value is primary
 r=json.loads((out/'report.json').read_bytes());assert not r['passed'] and not r['complete']
 assert r['failure_detail']['message']=='first public gate'
