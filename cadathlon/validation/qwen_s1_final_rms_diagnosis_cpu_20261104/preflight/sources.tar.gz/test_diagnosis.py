import copy,hashlib,json
from pathlib import Path
import numpy as np
import pytest
import diagnosis as d
import full_reference as f
import prepare_metadata as metadata
P=Path(__file__).resolve().parent

@pytest.mark.parametrize('value',[-1000.,-10.,0.,2.,1000.])
def test_exact_silu_stable(value):
 x=np.array([value]);result=d.exact_silu(x)
 assert np.isfinite(result).all()
 assert abs(float(result[0])-.5*value*(1+np.tanh(value/2)))<1e-12

@pytest.mark.parametrize('field',['minimum','maximum'])
def test_domain_provenance_rejects_changed_original(field):
 row=json.loads((P/'public_metadata.json').read_bytes());row['original_union'][field]+=1
 with pytest.raises(ValueError):metadata.derive(row)

def test_public_original_coverage():
 row=metadata.derive(json.loads((P/'public_metadata.json').read_bytes()))
 assert row['uniform_factor4_domain']==[29.88948209636508,2923.83603515625]
 assert row['S1_calibrated']is False and row['original_final_norm_observations_per_mode']==416
 assert row['decode_sequence_lengths']==[16,17,18,19]

def test_copied_frozen_sources_exact():
 copied=json.loads((P/'copied_sources.json').read_bytes())
 for name,h in copied['sources'].items():assert hashlib.sha256((P/name).read_bytes()).hexdigest()==h

def fake_forward(embeddings,positions,*,manifest_bytes,config_bytes,matrix,gamma):
 value=finite(embeddings.copy(),'original_embeddings');records={}
 rule={'method':'polynomial','strategy':'power','evaluation_coefficients':[1.],'domain':[0.,100.]}
 for i in range(28):
  for kind in ('input','q','k','post'):
   value=norm(value,np.ones(1024),1e-6,rule,f'{i}.{kind}.inverse_sqrt',records)
  # Exercise both substituted SiLU and strict original input observation.
  silu(np.zeros_like(value),{'method':'polynomial','strategy':'power','evaluation_coefficients':[0.],'domain':[-1.,1.]},f'{i}.silu',records)
  value=finite(value,f'{i}.block')
 norm(value,np.ones(1024),1e-6,dict(rule,domain=[0.,2.]),'final.inverse_sqrt',records)
 raise AssertionError('final polynomial/head must never execute')

def run(monkeypatch,mode='frozen_approximate',value=3.):
 monkeypatch.setattr(f,'forward',fake_forward)
 return d.prefix(np.full((1,1024),value),(0,),manifest_bytes=b'',config_bytes=b'',matrix=lambda n:None,gamma=lambda n:None,mode=mode)

def test_approximate_stops_before_rejected_final_and_preserves_globals(monkeypatch):
 original=(f.norm,f.silu,f.causal,f.finite)
 result=run(monkeypatch)
 assert result.final_variance==9.000001 and result.final_domain['above']==1
 assert len(result.blocks)==28 and len(result.variances)==113 and len(result.domains)==140
 assert original==(f.norm,f.silu,f.causal,f.finite)
 assert result.mode=='frozen_approximate'

def test_exact_branch_is_separate_and_never_calls_frozen_norm(monkeypatch):
 monkeypatch.setattr(f,'norm',lambda *a,**k:pytest.fail('exact branch must not call approximate norm'))
 result=run(monkeypatch,'exact_function_numpy')
 assert result.final_variance<2 and result.final_domain['above']==0
 assert len(result.variances)==113

def test_prior_domain_violation_still_aborts_approximate(monkeypatch):
 with pytest.raises(f.DomainFailure) as caught:run(monkeypatch,value=11.)
 assert caught.value.label=='0.input.inverse_sqrt'

def test_nonfinite_is_not_hidden(monkeypatch):
 with pytest.raises(FloatingPointError):run(monkeypatch,value=float('nan'))

def test_paired_metrics_are_finite_and_do_not_relabel_domain(monkeypatch):
 a=run(monkeypatch);b=run(monkeypatch,'exact_function_numpy');row=d.compare(a,b)
 assert len(row['blocks'])==28 and len(row['variance_sites'])==113
 assert row['approximate_final']['above']==1 and row['exact_function_final']['above']==0
 assert row['approximate_prior_domains_passed']is True
 json.dumps(row,allow_nan=False)

@pytest.mark.parametrize('mode',['native','HE',None])
def test_explicit_mode_only(mode):
 with pytest.raises(ValueError):d.prefix(np.ones((1,1024)),(0,),manifest_bytes=b'',config_bytes=b'',matrix=None,gamma=None,mode=mode)

@pytest.mark.parametrize('x,positions',[(np.ones((2,1024)),(0,1)),(np.ones((1,1024),dtype=np.float32),(0,)),(np.ones((1,1024)),(1,))])
def test_fixed_fixture_shape_position_only(x,positions):
 with pytest.raises(ValueError):d.prefix(x,positions,manifest_bytes=b'',config_bytes=b'',matrix=None,gamma=None,mode='frozen_approximate')

def test_no_head_access_after_interception(monkeypatch):
 result=run(monkeypatch)
 assert result.final_input.shape==(1,1024)
 assert result.final_domain['domain']==[0.,2.]
