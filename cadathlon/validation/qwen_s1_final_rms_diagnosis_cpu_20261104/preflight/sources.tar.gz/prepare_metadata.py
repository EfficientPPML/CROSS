"""Public-report/schema projections only. Never opens calibration input archives."""
from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent
PATHS={
 'original_inputs':'/tmp/qwen-calibration-candidate1-20261103/selection_inputs.json',
 'original_origin':'/tmp/qwen-calibration-candidate1-20261103/input_origin.json',
 'original_protocol':'/tmp/qwen-calibration-candidate1-20261103/protocol.json',
 'native_exact_report':'/tmp/qwen-native-calibration-20261103/native-exact-v1/report.json',
 'candidate2':'/tmp/qwen-calibration-candidate2-20261103/candidate-v2/manifest.json',
 'candidate3':'/tmp/qwen-candidate3-calibration-20261103/candidate-v3/manifest.json',
 'candidate3_protocol':'/tmp/qwen-candidate3-calibration-20261103/selection/protocol.json',
 'completed_calibration':'/tmp/qwen-candidate3-calibration-20261103/full-v1/report.json',
 'historical_S1':'/tmp/qwen-full-model-trajectory-v2-20261104/actual-v1/S1/report.json',
}
def digest(raw):return hashlib.sha256(raw).hexdigest()
def build():
 raw={name:Path(path).read_bytes() for name,path in PATHS.items()};v={name:json.loads(b) for name,b in raw.items()}
 site='final.inverse_sqrt';proto=v['original_protocol'];native=v['native_exact_report'];cal=v['completed_calibration'];old=v['historical_S1']
 return dict(schema='qwen-fixed-row0-diagnosis-metadata-v1',sources={name:dict(path=PATHS[name],sha256=digest(b)) for name,b in raw.items()},
    original_union=v['original_inputs'][site],original_origin=v['original_origin'],
    original_native_range=native['observed_native_ranges'][site],original_exact_range=native['observed_exact_ranges'][site],
    original_domain_rule=proto['domain_rule']['positive_inverse_sqrt'],calibration_workload=proto['calibration'],
    original_acceptance_gates=proto['gates'],maximum_original_candidates=proto['maximum_calibration_candidates'],successor_policy=proto['sequence'][-1],
    candidate2_final_rule=v['candidate2']['nonlinear'][site],candidate3_final_rule=v['candidate3']['nonlinear'][site],
    candidate3_selection_protocol=v['candidate3_protocol'],completed_calibration_final=cal['propagated_domain_ranges'][site],
    completed_calibration_flags={n:cal[n] for n in ('passed','complete','all_workload_entries_accounted','candidate_manifest_sha256')},
    historical_S1={n:old[n] for n in ('passed','complete','fixture','embedding_sha256','token_vector_sha256','failure_detail','source_files_unchanged','assets_unchanged','cleanup_completed','terminal_scope_completed','termination_scope_completed')})

def derive(metadata):
 row=metadata['original_union'];original=[.8*row['minimum'],1.2*row['maximum']];widened=[max(1e-6,original[0]/4),original[1]*4]
 if original!=metadata['candidate2_final_rule']['domain'] or widened!=metadata['candidate3_final_rule']['domain']:raise ValueError('literal original and factor4 domain provenance differs')
 native=metadata['original_native_range'];exact=metadata['original_exact_range']
 if row['minimum']!=min(native['minimum'],exact['minimum']) or row['maximum']!=max(native['maximum'],exact['maximum']):raise ValueError('original union differs')
 if any(r['count']!=416 for r in (native,exact,metadata['completed_calibration_final'])):raise ValueError('original full416 count differs')
 w=metadata['calibration_workload'];prefill=w['buckets'];decode=list(range(w['decode_seed_length'],w['decode_seed_length']+w['decode_steps']))
 if prefill!=[8,16,32] or decode!=[16,17,18,19]:raise ValueError('original geometry differs')
 return dict(original_domain=original,uniform_factor4_domain=widened,prefill_sequence_lengths=prefill,decode_sequence_lengths=decode,
    S1_calibrated=False,original_final_norm_observations_per_mode=416,coverage_gap='checkpoint embedding row0 at S1 was not a sequence-length case in the original416 calibration',
    original_approximate_calibration_final_range=metadata['completed_calibration_final'],historical_S1_failure_preserved=True,
    note='Coverage gap does not by itself identify the exact-function S1 variance or the approximation contribution.')

def verify():
 recorded=json.loads((P/'public_metadata.json').read_bytes());current=build()
 if current!=recorded:raise ValueError('public diagnosis metadata/source bytes changed')
 return derive(recorded)
if __name__=='__main__':
 out=P/'public_metadata.json'
 if out.exists():raise FileExistsError(out)
 out.write_text(json.dumps(build(),indent=2,allow_nan=False)+'\n')
 print(json.dumps(derive(json.loads(out.read_bytes())),indent=2))
