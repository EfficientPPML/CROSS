import numpy as np
import pytest
from test_causal_softmax_guards import setup, pv_setup, Value


def corrupt_final(label, value, counts):
    if label == 'output':
        value.num_moduli = 1


def test_softmax_rejects_final_callback_modulus_count_mutation():
    owner, arithmetic, refresh, source = setup(corrupt_final)
    with pytest.raises(ValueError):
        owner.evaluate_tile(source, query_tile=0)


def test_direct_value_rejects_final_callback_modulus_count_mutation():
    softmax, arithmetic, refresh, unused = setup(positions=(7,))
    result = softmax.evaluate_tile(None, query_tile=0)
    pv = pv_setup(arithmetic, (7,), corrupt_final)
    with pytest.raises(ValueError):
        pv.attend_softmax(result, (Value(np.ones(65536),24),), query_tile=0)
