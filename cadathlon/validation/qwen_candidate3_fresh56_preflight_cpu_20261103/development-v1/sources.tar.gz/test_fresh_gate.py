from pathlib import Path
import copy
import hashlib
import io
import json
import tarfile
import pytest
import fresh_gate

ROOT = Path(__file__).resolve().parent


def test_real_metadata_only_gate_does_not_read_input_bodies(monkeypatch):
    req = json.loads((ROOT / 'validation_requirement.json').read_bytes())
    original = fresh_gate.sha
    read = []
    def checked(path):
        path = Path(path)
        assert path.parent == ROOT / 'fresh_freeze'
        assert path.name in ('report.json', 'protocol.json', 'input_pins.json', 'model_pins.json')
        read.append(path.name)
        return original(path)
    monkeypatch.setattr(fresh_gate, 'sha', checked)
    assert fresh_gate.verify_metadata(ROOT, req)['records'] == 56
    assert set(read) == {'report.json', 'protocol.json', 'input_pins.json', 'model_pins.json'}


@pytest.fixture
def synthetic(tmp_path, monkeypatch):
    payloads = {f'source{i}.py': ('synthetic source ' + str(i)).encode() for i in range(11)}
    archive = tmp_path / 'synthetic.tar.gz'
    def save(items):
        with tarfile.open(archive, 'w:gz') as tar:
            for name, raw in items:
                member = tarfile.TarInfo(name);member.size = len(raw)
                tar.addfile(member, io.BytesIO(raw))
    save(payloads.items())
    tokens = tmp_path / 'synthetic_tokens.json';tokens.write_bytes(b'[]')
    expected = {n: hashlib.sha256(b).hexdigest() for n, b in payloads.items()}
    req = dict(fresh_freeze=dict(report_sha256='metadata-only-test', archive_sha256=fresh_gate.sha(archive),
                                tokenized_sha256=fresh_gate.sha(tokens)))
    monkeypatch.setattr(fresh_gate, 'verify_metadata', lambda *a: dict(source_hashes_before=expected))
    return tmp_path, archive, tokens, req, payloads, save


def test_exact_synthetic_archive_and_tokens(synthetic):
    root, archive, tokens, req, _, _ = synthetic
    assert fresh_gate.verify_inputs(root, req, archive, tokens)['verified'] is True


@pytest.mark.parametrize('which', ['archive', 'tokens'])
def test_changed_external_bytes_reject(synthetic, which):
    root, archive, tokens, req, _, _ = synthetic
    req['fresh_freeze']['archive_sha256' if which == 'archive' else 'tokenized_sha256'] = '0'*64
    with pytest.raises(ValueError, match='hash'):
        fresh_gate.verify_inputs(root, req, archive, tokens)


def test_duplicate_archive_member_is_rejected(synthetic):
    root, archive, tokens, req, payloads, save = synthetic
    save([*payloads.items(), next(iter(payloads.items()))])
    req['fresh_freeze']['archive_sha256'] = fresh_gate.sha(archive)
    with pytest.raises(ValueError, match='unique archive inventory'):
        fresh_gate.verify_inputs(root, req, archive, tokens)


def test_archive_payload_substitution_is_rejected(synthetic):
    root, archive, tokens, req, payloads, save = synthetic
    payloads['source0.py'] = b'changed';save(payloads.items())
    req['fresh_freeze']['archive_sha256'] = fresh_gate.sha(archive)
    with pytest.raises(ValueError, match='every archived source byte'):
        fresh_gate.verify_inputs(root, req, archive, tokens)
