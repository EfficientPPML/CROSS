from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
import json
import sys
import pytest
import validate_heldout as v


@pytest.mark.parametrize('primary', [ValueError('primary'), KeyboardInterrupt('primary')])
@pytest.mark.parametrize('scope_error', [OSError('scope'), SystemExit('scope')])
def test_scope_failure_preserves_primary_and_publishes_false(tmp_path, monkeypatch, primary, scope_error):
    def fail(*args):
        raise primary
    @contextmanager
    def shield():
        try:
            yield
        finally:
            raise scope_error
    monkeypatch.setattr(v.validation_gate, 'verify', fail)
    monkeypatch.setattr(v, 'cleanup_signals', shield)
    with pytest.raises(type(primary)) as caught:
        v.collect(SimpleNamespace(output=tmp_path/'run', calibration_report=tmp_path/'unused', calibration_source_archive=tmp_path/'unused2'))
    assert caught.value is primary
    assert json.loads((tmp_path/'run/report.json').read_text())['passed'] is False


@pytest.mark.parametrize('restoration', [OSError('restore'), KeyboardInterrupt('restore')])
def test_main_scope_restoration_cannot_leave_success_json(tmp_path, monkeypatch, restoration):
    output = tmp_path / 'run'
    def successful(args):
        args.output.mkdir()
        v.write(args.output/'report.json', dict(passed=True, errors=[]))
        return 0
    @contextmanager
    def scope():
        try:
            yield
        finally:
            raise restoration
    monkeypatch.setattr(v, 'collect', successful)
    monkeypatch.setattr(v, 'termination_signals', scope)
    monkeypatch.setattr(sys, 'argv', ['validate_heldout.py', '--output', str(output), '--calibration-report', 'unused', '--calibration-source-archive', 'unused'])
    with pytest.raises(type(restoration)) as caught:
        v.main()
    assert caught.value is restoration
    result = json.loads((output/'report.json').read_text())
    assert result['passed'] is False and result['errors'][-1]['phase'] == 'termination_scope'
