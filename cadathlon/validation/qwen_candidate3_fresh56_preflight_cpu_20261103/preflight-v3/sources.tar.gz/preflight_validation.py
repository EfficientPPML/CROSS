"""Source-bound candidate3 fresh56 preparation; no fresh input bodies/model run."""
from pathlib import Path
import hashlib
import importlib.util
import io
import json
import os
import subprocess
import sys
import tarfile
import time
import xml.etree.ElementTree as ET
import calibration_gate
import candidate_gate
import fresh_gate
import validation_gate

ROOT = Path(__file__).resolve().parent
NEW = ('validate_heldout.py','calibration_gate.py','validation_gate.py','validation_requirement.json',
       'validation_protocol.json','test_validation_gate.py','test_fresh_gate.py','test_validation_lifecycle.py',
       'preflight_validation.py','preflight_test_entry.py','fresh_gate.py','validation_cleanup.py','validation_terminal.py',
       'fresh_freeze/report.json','fresh_freeze/protocol.json','fresh_freeze/input_pins.json','fresh_freeze/model_pins.json',
       'calibration_prerequisite/report.json','calibration_prerequisite/runtime_sources.tar.gz')


def sources(req):
    package = Path(importlib.util.find_spec('transformers').origin).parent
    paths = {n: package/n.removeprefix('software/transformers/') if n.startswith('software/') else ROOT/n
             for n in req['expected_runtime_source_hashes']}
    paths.update({n: ROOT/n for n in NEW})
    return paths


def hashes(paths):
    return {n: hashlib.sha256(p.read_bytes()).hexdigest() for n,p in paths.items()}


def main(output):
    output.mkdir(exist_ok=False)
    start = time.monotonic()
    report=dict(passed=False,fresh_input_bodies_read=False,checkpoint_model_evaluated=False,errors=[])
    (output/'report.json').write_text(json.dumps(report)+'\n')
    try:
        req = validation_gate.verify(ROOT)
        prerequisite = calibration_gate.verify(ROOT/'calibration_prerequisite/report.json',
            ROOT/'calibration_prerequisite/runtime_sources.tar.gz', ROOT, req)
        candidate_gate.verify(ROOT)
        fresh_gate.verify_metadata(ROOT, req)
        paths = sources(req);before = hashes(paths)
        with tarfile.open(output/'sources.tar.gz','w:gz') as tar:
            for name,path in paths.items():
                raw=path.read_bytes();member=tarfile.TarInfo(name);member.size=len(raw)
                tar.addfile(member,io.BytesIO(raw))
        validation_gate.verify_archive(output/'sources.tar.gz', before)
        with (output/'tests.log').open('wb') as log:
            result = subprocess.run([sys.executable, str(ROOT/'preflight_test_entry.py'), str(output)], cwd=ROOT,
                env={**os.environ, 'OPENBLAS_NUM_THREADS':'1', 'OMP_NUM_THREADS':'1'},stdout=log,stderr=subprocess.STDOUT)
        suites=ET.parse(output/'tests.xml').getroot()
        tests={n:sum(int(s.attrib.get(n,0)) for s in suites) for n in ('tests','errors','failures','skipped')}
        after=hashes(paths);validation_gate.verify_archive(output/'sources.tar.gz',before)
        guard=json.loads((output/'input_read_guard.json').read_bytes())
        report=dict(passed=result.returncode==0 and before==after and not any(tests[n] for n in ('errors','failures','skipped')),
            test_exit_code=result.returncode,tests=tests,calibration_prerequisite=prerequisite,
            source_hashes_before=before,source_hashes_after=after,source_files_unchanged=before==after,
            source_archive_verified=True,source_archive_sha256=hashlib.sha256((output/'sources.tar.gz').read_bytes()).hexdigest(),
            fresh_input_bodies_read=False,checkpoint_model_evaluated=False,read_guard=guard,
            external_input_bodies_deferred_until_authorized_runtime=req['fresh_freeze'],
            elapsed_s=time.monotonic()-start,cpu_affinity=sorted(os.sched_getaffinity(0)))
        (output/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    except BaseException as error:
        report['passed']=False
        report.setdefault('errors',[]).append(dict(type=type(error).__name__,message=str(error)))
        (output/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
        raise
    print(json.dumps({k:report[k] for k in ('passed','tests','elapsed_s','source_archive_sha256')}))
    return 0 if report['passed'] else 1


if __name__=='__main__':
    raise SystemExit(main((ROOT/sys.argv[1]).resolve()))
