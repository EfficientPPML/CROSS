"""Fresh-child installed entrypoint checks; never instantiate crypto or models.

Run separately from the synthetic module-replacement tests. The outer collector
pins this file, the boundary, cleanup helper and complete copied runtime first.
"""
from pathlib import Path
import builtins
import importlib
import os
import sys
import pytest
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE/'runtime/stage'),str(HERE/'common'),str(HERE/'runtime')]
import component_boundaries as b


@pytest.fixture(scope='module',autouse=True)
def no_payload_reads():
    active=[True];denied=[]
    def audit(event,args):
        if active[0] and event=='open' and args and isinstance(args[0],(str,bytes,os.PathLike)):
            p=Path(os.fsdecode(args[0]))
            if p.suffix in ('.npy','.npz','.safetensors') or 'client_private' in p.parts or p.name=='client_preprocessed_input':
                denied.append(str(p));raise AssertionError('installed probe may not open any payload')
    sys.addaudithook(audit)
    yield
    active[0]=False
    assert denied==[]


@pytest.mark.parametrize('role',b.ROLES)
def test_real_entrypoints_denied_restored_without_instances(role,monkeypatch):
    entries=b._entries(role)
    # Import resolution must point at the copied runtime, not the live checkout.
    module_names=('key_gen','jaxite_word.key_gen','client_keys','client_inputs','key_contexts',
        'file_stages','server_public_model','full_model_engine')
    modules=[sys.modules[name] for name in module_names]
    assert modules[0] is not modules[1]
    assert all(Path(m.__file__).resolve().is_relative_to(HERE/'runtime') for m in modules)
    from jaxite_word import CKKSContext
    def forbidden_constructor(*a,**k):raise AssertionError('probe never constructs CKKSContext')
    monkeypatch.setattr(CKKSContext,'__init__',forbidden_constructor)
    before=[getattr(owner,name) for owner,name,_ in entries]
    allowed=b.ENCRYPT if role=='fixture' else b.DECRYPT if role=='validate' else ()
    codec_before={n:getattr(CKKSContext,n) for n in allowed}
    loaders=sys.modules['key_contexts']
    permitted=loaders.load_server if role=='server' else loaders.load_client
    calls=[]
    with b.role_scope(role,calls=calls):
        assert (loaders.load_server if role=='server' else loaders.load_client) is permitted
        assert all(getattr(CKKSContext,n)is v for n,v in codec_before.items())
        for owner,name,label in entries:
            with pytest.raises(RuntimeError,match='forbidden BSGS '+role+' action'):
                getattr(owner,name)(None)
    assert calls==[label for _,_,label in entries]
    assert [getattr(owner,name) for owner,name,_ in entries]==before
    assert not any(b._native(name) for name in sys.modules)
    # This fixed assertion changes only if the reviewed entrypoint inventory does.
    assert len(entries)=={'fixture':26,'server':30,'validate':25}[role]


@pytest.mark.parametrize('role',b.ROLES)
def test_real_native_import_denial_does_not_import_native_package(role):
    calls=[]
    with b.role_scope(role,calls=calls):
        for name in sorted(b.NATIVE_ROOTS):
            with pytest.raises(RuntimeError,match='native model import'):builtins.__import__(name)
            with pytest.raises(RuntimeError,match='native model import'):importlib.import_module(name)
    assert len(calls)==12
    assert not any(b._native(name) for name in sys.modules)


@pytest.mark.parametrize('role',b.ROLES)
def test_fresh_first_entry_installs_guards_before_core_import(role,record_property):
    """Exercise the actual first-entry order in an otherwise fresh interpreter."""
    import json,subprocess,textwrap
    script=textwrap.dedent('''
        from pathlib import Path
        import json,os,sys
        root=Path(sys.argv[1]);role=sys.argv[2]
        sys.path[:0]=[str(root),str(root/'runtime/stage'),str(root/'common'),str(root/'runtime')]
        import component_boundaries as boundary
        assert 'jax' not in sys.modules and 'jaxite_word' not in sys.modules
        forbidden=[]
        def audit(event,args):
            if event=='open' and args and isinstance(args[0],(str,bytes,os.PathLike)):
                p=Path(os.fsdecode(args[0]))
                if p.suffix in ('.npy','.npz','.safetensors') or 'client_private' in p.parts or p.name=='client_preprocessed_input':
                    forbidden.append('payload');raise AssertionError('no payload read in fresh entry probe')
        def profile(frame,event,arg):
            if event!='call':return
            filename=Path(frame.f_code.co_filename).name;name=frame.f_code.co_name
            if ((filename=='key_gen.py' and name in boundary.KEY_METHODS) or
                (filename in ('ckks_ctx.py','polynomial.py') and name=='__init__')):
                forbidden.append(filename+':'+name);raise AssertionError('no crypto constructor/keygen in fresh probe')
        sys.addaudithook(audit);sys.setprofile(profile)
        calls=[]
        try:
            with boundary.role_scope(role,calls=calls):
                entries=boundary._entries(role) # now AFTER the guarded first import
                for owner,name,label in entries:
                    try:getattr(owner,name)(None)
                    except RuntimeError as e:assert str(e)=='forbidden BSGS '+role+' action: '+label
                    else:raise AssertionError('real entrypoint was not denied')
            bridge=sys.modules.get('jax._src.xla_bridge')
            backends={} if bridge is None else dict(getattr(bridge,'_backends',{}))
            result=dict(role=role,denied=len(calls),native_modules=[n for n in sys.modules if boundary._native(n)],
                jax_imported='jax' in sys.modules,backend_initialized=bool(backends),backend_names=sorted(backends),
                forbidden=forbidden,lock_released=not boundary._ACTIVE.locked())
            assert not result['native_modules'] and not forbidden and result['lock_released']
        finally:sys.setprofile(None)
        print(json.dumps(result,sort_keys=True))
    ''')
    environment=dict(os.environ,JAX_PLATFORMS='cpu',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    for name in ('TPU_VISIBLE_CHIPS','CROSS_EAGER_LEVEL_PARAMS','XLA_FLAGS'):environment.pop(name,None)
    result=subprocess.run([sys.executable,'-c',script,str(HERE),role],env=environment,text=True,capture_output=True,check=False)
    assert result.returncode==0,result.stdout+'\n'+result.stderr
    report=json.loads(result.stdout.splitlines()[-1])
    assert report['denied']=={'fixture':26,'server':30,'validate':25}[role]
    assert report['jax_imported'] and not report['forbidden'] and not report['native_modules']
    # Report actual initialization state; never call devices()/default_backend()
    #merely to measure it or infer absence from the import-only intent.
    record_property('fresh_first_entry',json.dumps(report,sort_keys=True))
