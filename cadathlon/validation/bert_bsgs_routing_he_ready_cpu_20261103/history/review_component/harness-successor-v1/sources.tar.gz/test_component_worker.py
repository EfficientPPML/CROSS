"""Worker ordering/denial and actual orchestration with explicit crypto doubles."""
from contextlib import contextmanager
from pathlib import Path
from types import ModuleType,SimpleNamespace
import copy
import json
import sys
import numpy as np
import pytest
import component_worker as w
import component_protocol as p
import component_contract as c
import component_transport as t
from test_component_contract import contract


def config(stage='fixture'):
    value=dict(stage=stage,workspace='/tmp/cross-bsgs-routing-'+contract()['nonce'],workspace_identity=[1,2],
        request_contract=contract(),key_evidence='/public/key-proof',key_workspace='/retained/keys',
        fixture_evidence=None,fixture_report_sha256=None,server_evidence=None,server_report_sha256=None)
    if stage in ('server','validate'):value.update(fixture_evidence='/public/fixture-proof',fixture_report_sha256='ab'*32)
    if stage=='validate':value.update(server_evidence='/public/server-proof',server_report_sha256='cd'*32)
    return value


@pytest.mark.parametrize('stage',p.STAGES)
def test_exact_phase_config(stage,monkeypatch):
    monkeypatch.setattr(p,'check_identity',lambda *a:None)
    assert w.validate_config(config(stage))==config(stage)


@pytest.mark.parametrize('edit',['unknown_stage','extra','missing','wrong_workspace','relative_key','missing_fixture',
    'missing_server','extra_server','extra_fixture','bad_prior_hash'])
def test_invalid_phase_config(edit,monkeypatch):
    monkeypatch.setattr(p,'check_identity',lambda *a:None);value=config('validate')
    if edit=='unknown_stage':value['stage']='other'
    elif edit=='extra':value['extra']=1
    elif edit=='missing':value.pop('key_workspace')
    elif edit=='wrong_workspace':value['workspace']=value['key_workspace']
    elif edit=='relative_key':value['key_workspace']='relative'
    elif edit=='missing_fixture':value['fixture_evidence']=None
    elif edit=='missing_server':value['server_evidence']=None
    elif edit=='extra_server':value=config('server');value.update(server_evidence='/public/server',server_report_sha256='cd'*32)
    elif edit=='extra_fixture':value=config();value.update(fixture_evidence='/public/fixture',fixture_report_sha256='cd'*32)
    else:value['fixture_report_sha256']='BAD'
    with pytest.raises(ValueError):w.validate_config(value)


def runtime(monkeypatch,stage,events,fail=None):
    expected={'stub.py':'ab'*32}
    monkeypatch.setenv('JAX_PLATFORMS','cpu')
    def check(*a):events.append('sources');return b'profile',b'plan'
    monkeypatch.setattr(p,'check_sources',check)
    monkeypatch.setattr(p,'sources',lambda:{'stub.py':b'stub'})
    monkeypatch.setattr(p,'hashes',lambda raw:expected)
    monkeypatch.setattr(p,'check_identity',lambda *a:events.append('identity'))
    monkeypatch.setattr(p,'imported_sources',lambda *a:{})
    def gates(*a):
        events.append('prior_gates')
        if fail=='gate':raise ValueError('incomplete prior terminal')
        return {}
    monkeypatch.setattr(w,'prior_gates',gates)
    def keys(*a,**k):events.append('public_keys');return dict(context_id=c.CONTEXT_ID,public_keys='/public/keys')
    monkeypatch.setattr(p,'authenticate_keys',keys)
    @contextmanager
    def boundary(*a,**k):
        events.append('boundary_enter')
        try:yield
        finally:events.append('boundary_exit')
    fake=ModuleType('component_boundaries');fake.role_scope=boundary;monkeypatch.setitem(sys.modules,'component_boundaries',fake)
    def phase(config,keys,profile,plan,report,publish,*extra):
        events.append('phase')
        if fail=='phase':raise KeyboardInterrupt('cancelled phase')
        report['loader_cleanup_completed']=True;report['readback']={'test_only':True}
    monkeypatch.setattr(w,stage,phase)
    return expected


@pytest.mark.parametrize('stage',p.STAGES)
def test_worker_completion_requires_ordered_public_gates_and_cleanup(tmp_path,monkeypatch,stage):
    events=[];expected=runtime(monkeypatch,stage,events);out=tmp_path/'report.json'
    assert w.run(config(stage),expected,out)==0
    report=json.loads(out.read_bytes())
    assert report['passed'] and report['phase_complete'] and report['terminal_scope_completed'] and report['loader_cleanup_completed']
    assert events.index('sources')<events.index('prior_gates')<events.index('public_keys')<events.index('boundary_enter')<events.index('phase')<events.index('boundary_exit')


@pytest.mark.parametrize('stage',p.STAGES)
@pytest.mark.parametrize('failure',['gate','phase'])
def test_worker_failure_cannot_authorize_next_phase(tmp_path,monkeypatch,stage,failure):
    events=[];expected=runtime(monkeypatch,stage,events,failure);out=tmp_path/'report.json'
    with pytest.raises(ValueError if failure=='gate' else KeyboardInterrupt):w.run(config(stage),expected,out)
    report=json.loads(out.read_bytes());assert report['passed'] is False and report['phase_complete'] is False
    if failure=='gate':assert 'public_keys' not in events and 'phase' not in events
    else:assert events.index('phase')<events.index('boundary_exit')


def test_validate_prior_gates_reject_different_input_digest_before_context(monkeypatch):
    def terminal(*a,**k):return {'readback':{'input_digest':('ab' if k['stage']=='fixture' else 'cd')*32}}
    monkeypatch.setattr(p,'terminal_gate',terminal)
    with pytest.raises(ValueError,match='different encrypted fixtures'):w.prior_gates(config('validate'),{})


class Payload:
    def __init__(self,slots,events):self.slots=np.asarray(slots);self.events=events
    def block_until_ready(self):self.events.append('barrier');return self


class Value:
    def __init__(self,slots,events):self.polynomial=Payload(slots,events);self._ckks_nsd=1


def orchestration(monkeypatch,tmp_path):
    """Temporary metadata files plus fake loaders/codecs/transport, no HE."""
    events=[];stored={};keys=dict(context_id=c.CONTEXT_ID,public_keys=tmp_path/'public')
    cfg=config();cfg['workspace']=str(tmp_path/'io');Path(cfg['workspace']).mkdir(mode=0o700)
    class Context:
        def encrypt_slots(self,slots):events.append('encrypt');return Value(slots,events)
        def decrypt_slots(self,value):events.append('decrypt');return value.polynomial.slots
    @contextmanager
    def load_client(*a,**k):
        events.append('client_enter')
        try:yield SimpleNamespace(ctx=Context(),public_manifest={'context_id':c.CONTEXT_ID})
        finally:events.append('client_exit')
    @contextmanager
    def load_server(*a,**k):
        events.append('server_enter')
        try:yield SimpleNamespace(ctx=Context(),public_manifest={'context_id':c.CONTEXT_ID})
        finally:events.append('server_exit')
    fake=ModuleType('key_contexts');fake.load_client=load_client;fake.load_server=load_server
    monkeypatch.setitem(sys.modules,'key_contexts',fake)
    support=ModuleType('support');support.require_secure_execution=lambda *a:events.append('security')
    monkeypatch.setitem(sys.modules,'support',support)
    def save(value,path,**k):
        binding=c.ciphertext_contract(k['contract'],k['role'],k['tile_index'],k.get('expected_scale'),k.get('input_digest'))
        m=t._manifest_fields(binding)|dict(files={'bundle.json':'01'*32,'ct_0.npz':'02'*32})
        path=Path(path);path.mkdir();stored[str(path)]=(value,m);events.append(('save',k['role'],k['tile_index']));return m
    def load(path,**k):events.append(('load',k['role'],k['tile_index']));return stored[str(path)]
    monkeypatch.setattr(t,'save_ciphertext',save);monkeypatch.setattr(t,'load_ciphertext',load)
    def readback(workspace,request,*,role,input_digest=None):
        events.append(('readback',role));folder=Path(workspace)/('inputs' if role=='request' else 'outputs')
        raw=(folder/'manifest.json').read_bytes();m=p.validate_artifact_manifest(json.loads(raw),request=request,role=role,input_digest=input_digest)
        assert all(str(folder/f'tile{i}')in stored for i in range(len(m['tiles'])))
        return dict(manifest=m,manifest_sha256=p.sha(raw),tile_count=len(m['tiles']),input_digest=m['input_digest'])
    monkeypatch.setattr(p,'readback',readback)
    return cfg,keys,events,stored


def test_fixture_orchestration_publishes_only_after_loader_retirement(tmp_path,monkeypatch):
    cfg,keys,events,stored=orchestration(monkeypatch,tmp_path);report={}
    w.fixture(cfg,keys,b'profile',b'plan',report,lambda:None)
    assert report['loader_cleanup_completed'] and report['completed_ciphertexts']==2
    assert events.count('encrypt')==2 and events.index('client_exit')<events.index(('readback','request'))
    assert len(stored)==2 and report['readback']['tile_count']==2


@pytest.mark.parametrize('bad_last',[False,True,'huge64','huge128'])
def test_all18_outputs_authenticated_before_any_private_context_or_decode(tmp_path,monkeypatch,bad_last):
    cfg,keys,events,stored=orchestration(monkeypatch,tmp_path);fixture={}
    w.fixture(cfg,keys,b'profile',b'plan',fixture,lambda:None);events.clear()
    oracle=w.public_oracle();x,_=oracle.fixture_arrays();proof=c.numerical_plan()
    def exercise(ctx,source,ones,*,checkpoint):
        index=0
        for case in proof['cases']:
            forward=oracle.oracle(x,gain=case['gain'])
            answers={'forward':forward,'roundtrip_inverse':oracle.oracle(forward['key placement'],inverse=True),'hostile_inverse':oracle.oracle(x,inverse=True)}
            for row in case['checkpoints']:
                slots=answers[row['direction']][row['label']].copy()
                if bad_last and index==17:
                    if bad_last=='huge128':slots=slots.astype(np.longdouble);slots[65535]=np.longdouble('1e400')
                    elif bad_last=='huge64':slots[65535]=np.finfo(np.float64).max
                    else:slots[65535]+=1.
                public={n:row[n] for n in ('direction','label','level','scale','counts')}|dict(case=case['name'])
                checkpoint(index,Value(slots,events),public);index+=1
        return {'synthetic_only':True}
    fake=ModuleType('component_arithmetic');fake.exercise=exercise;monkeypatch.setitem(sys.modules,'component_arithmetic',fake)
    server={};w.server(cfg,keys,b'profile',b'plan',server,lambda:None,{'fixture':fixture})
    assert server['completed_ciphertexts']==18 and server['loader_cleanup_completed'] and 'decrypt' not in events
    events.clear();result={};prior={'fixture':fixture,'server':server}
    def publish():p.write(tmp_path/'numeric_report.json',result)
    if bad_last:
        with pytest.raises(ValueError,match='all-slot numerical gate'):w.validate(cfg,keys,b'profile',b'plan',result,publish,prior)
        assert not result['numeric_checkpoints'][-1]['passed']
        if bad_last is True:assert result['numeric_checkpoints'][-1]['max_abs_error']==1.
        assert json.loads((tmp_path/'numeric_report.json').read_bytes())['numeric_checkpoints'][-1]['passed'] is False
    else:
        w.validate(cfg,keys,b'profile',b'plan',result,publish,prior)
        assert result['numeric_summary']==dict(checkpoints=18,physical_slots=1179648,maximum_absolute_error=0.,absolute_gate=1e-6,passed=True)
    assert events.index(('readback','response'))<events.index('client_enter')<events.index('decrypt')
    assert events.count('decrypt')==18 and result['loader_cleanup_completed']


def test_no_backend_imported_by_synthetic_worker_tests():
    assert not any(n in sys.modules for n in ('jax','jaxlib','torch','transformers','safetensors'))


@pytest.mark.parametrize('magnitude',[1e200,np.finfo(np.float64).max,np.longdouble('1e400'),np.finfo(np.longdouble).max])
def test_huge_finite_decode_fails_with_serializable_error_metrics(magnitude):
    actual=np.full(65536,magnitude,dtype=np.longdouble);expected=np.zeros(65536,dtype=np.float64)
    metrics=w.numeric_errors(actual,expected)
    assert metrics['passed'] is False and metrics['absolute_gate']==1e-6
    assert json.loads(c.canonical(metrics))==metrics
    assert all(v is None or np.isfinite(v) for k,v in metrics.items() if k in ('max_abs_error','nrmse'))


@pytest.mark.parametrize('error',[0.,1e-6,np.nextafter(1e-6,np.inf)])
def test_metric_overflow_repair_preserves_exact_absolute_gate(error):
    expected=np.zeros(65536);actual=expected.copy();actual[-1]=error
    metrics=w.numeric_errors(actual,expected)
    assert metrics['passed'] is bool(error<=1e-6) and metrics['max_abs_error']==error
