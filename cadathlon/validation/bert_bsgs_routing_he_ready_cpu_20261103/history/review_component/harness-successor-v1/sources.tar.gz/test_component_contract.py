"""Public schema tests only: no key, ciphertext, private data or backend access."""
import copy
import math
import sys
import numpy as np
import pytest
import component_contract as c


def contract():
    return c.make_contract(c.CONTEXT_ID, '01'*16)


@pytest.mark.parametrize('index', range(20))
def test_all_ordered_input_and_output_roles(index):
    p=c.numerical_plan();request=index<2;i=index if request else index-2
    expected=None if request else p['cases'][i//9]['checkpoints'][i%9]
    scale=None if request else expected['scale']
    b=c.ciphertext_contract(contract(),'request' if request else 'response',i,scale,None if request else 'ab'*32)
    assert b['tile_count']==(2 if request else 18)
    assert b['tile_index']==i and b['request_contract_sha256']==c.digest(contract())
    assert b['level']==(49 if request else expected['level'])
    assert b['shape']==(1,2,256,512,2*(b['level']+1))
    assert b['moduli']==p['profile']['q'][:2*(b['level']+1)]
    if request:
        assert b['label']==('x','ones')[i] and b['case'] is None and b['direction']=='fixture'
    else:
        assert (b['case'],b['direction'],b['label'])==(p['cases'][i//9]['name'],expected['direction'],expected['label'])
        assert b['scale']==expected['scale'] and b['input_digest']=='ab'*32


@pytest.mark.parametrize('nonce',[None,True,1,'','0'*31,'0'*33,'G'*32,'A'*32,'0'*32+'\n',b'0'*32])
def test_nonce_exact_type_and_format(nonce):
    with pytest.raises(ValueError):c.make_contract(c.CONTEXT_ID,nonce)


@pytest.mark.parametrize('identity',[None,True,1,'ab'*32,c.CONTEXT_ID+'\n',c.CONTEXT_ID.upper()])
def test_context_is_completed_existing_key_identity(identity):
    with pytest.raises(ValueError):c.make_contract(identity,'01'*16)


@pytest.mark.parametrize('field',list(contract()))
def test_every_contract_field_is_bound(field):
    v=contract();v[field]=None
    with pytest.raises(ValueError):c.validate_contract(v)


@pytest.mark.parametrize('edit',['extra','missing','reverse_inputs','float_count','bool_count','tuple_inputs'])
def test_contract_inventory_and_json_types(edit):
    v=contract()
    if edit=='extra':v['extra']=1
    elif edit=='missing':v.pop('absolute_gate')
    elif edit=='reverse_inputs':v['input_patterns'].reverse()
    elif edit=='float_count':v['output_count']=18.0
    elif edit=='bool_count':v['output_count']=True
    else:v['input_patterns']=tuple(v['input_patterns'])
    with pytest.raises(ValueError):c.validate_contract(v)


@pytest.mark.parametrize('value',[np.int64(1),np.float64(1),(),{1:'x'},float('nan'),float('inf')])
def test_canonical_rejects_non_json_or_nonfinite(value):
    with pytest.raises(ValueError):c.canonical(value)


@pytest.mark.parametrize('role,index,scale,digest',[
    ('request',True,None,None),('response',False,1.,'ab'*32),
    ('request',2,None,None),('request',-1,None,None),('response',18,1.,'ab'*32),
    ('response',1.0,1.,'ab'*32),('other',0,None,None),(None,0,None,None),
    ('request',0,1.,None),('request',0,None,'ab'*32),
    ('response',0,None,'ab'*32),('response',0,float('nan'),'ab'*32),
    ('response',0,1.,None),('response',0,1.,'AB'*32)])
def test_roles_cannot_be_coerced(role,index,scale,digest):
    with pytest.raises(ValueError):c.ciphertext_contract(contract(),role,index,scale,digest)


def test_hostile_noncanonical_first_rotation_preserves_actual_product_scale():
    p=c.numerical_plan();scale=p['cases'][1]['checkpoints'][6]['scale']
    assert scale==1.3872675178787955e18 and scale!=p['profile']['canonical_scale']
    assert c.ciphertext_contract(contract(),'response',15,scale,'ab'*32)['scale']==scale
    with pytest.raises(ValueError):c.ciphertext_contract(contract(),'response',15,p['profile']['canonical_scale'],'ab'*32)


def test_source_plan_is_authenticated_before_contract(monkeypatch,tmp_path):
    p=tmp_path/'proof_plan.json';p.write_text('{}')
    monkeypatch.setattr(c,'ROOT',tmp_path)
    with pytest.raises(ValueError,match='reviewed public numerical plan'):contract()


def test_no_backend_imports():
    assert not any(n in sys.modules for n in ('jax','jaxlib','torch','transformers','safetensors'))
