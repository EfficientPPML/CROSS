This isolated successor will test the frozen BSGS owner with genuine CPU CKKS.
No encryption, key loading, server arithmetic or decoding has launched here.
The preceding ideal proof has606 checks/28 sources, owner SHA
f7d9492c5ca959bb09c7c7dfe2b4062ce33b2c64678558df261b1ed92ddd8fde.
Its archive is96bd71a9de4adfba25d017e5fdcb1b67b8052eda476ed18c47adfb659b8b3919.
No main runtime, live worker, prepared/group parity or full-model source changes.

Reuse the authenticated existing full BERT p60 keys. The external stage1 report
is022cbdf687273e765668184f32cb7cd501d371c4220916e1c8f02574cf3a7f08,
with contextba28d6a81704eba60c51ad59fbfee3901516b783a1144d973e8199a014d87fb9.
The full existing130 rotation inventory contains all36 BSGS keys. The loader
must remain the ordinary authenticated loader; do not silently use prepared
or grouped rotations. No new keys, model load, pretrained input reads or TPU.
Profile/plan byte pins and actual Q/P security checks precede key/private reads.

Use three sequential processes with separately gated file artifacts:
1. Client fixture producer: authenticate the completed key evidence and exact
   profile/plan, load the retained client context, then encrypt two deterministic
   public full-slot fixtures: the predecessor dense hostile-padding x pattern
   and ones. Preserve the original pattern's generator/body and digest. Publish
   exact ciphertext metadata/payload hashes in a fresh owned workspace, validate
   readback, and completely retire client context/codec owners before server.
   This is a new explicitly identified public-pattern fixture, not existing
   pretrained stage3 input or a full-model result.
2. Keyless server: authenticate fixture evidence and every ciphertext body,
   load only supplied public/evaluation keys, install fail-closed codec/private/
   generation guards and unchanged low-memory CompiledArithmetic. Legitimately
   level-reduce x toL5 for canonical input. Independently reduce x and ones toL6
   and perform an actual ciphertext product/rescale to produce the original
   noncanonical L5 scale. No manual scale assignment or metadata-only lowering.
   Apply layout(7,15) to exactly two pairs: canonical with gain1.0 and
   noncanonical with gain.125, not their Cartesian product.
   For each case, run forward, inverse of that forward, and an independent
   inverse directly on the hostile original route input. Keep all18 actual
   checkpoint outputs completed and authenticated before client validation.
3. Client validator: only a terminal-passed server report authorizes opening
   the retained private key directory. Reauthenticate exact sources, profile,
   context, original fixture and all18 ciphertext files. Decode and compare
   every physical slot to an independent coordinate gather/scatter of the
   original public x pattern. Keep the existing strict maxabs1e-6 gate for every
   checkpoint, without clipping, scaling away error or altering coefficients.
   Record aggregate errors only; do not archive keys or ciphertext payloads.

Each case's checkpoint labels/levels are:
forward: head compaction4, local key placement3, key placement3;
inverse(forward): key tile extraction3, key extraction2, head expansion1;
inverse(hostile input): key tile extraction5, key extraction4, head expansion3.
The inverse-hostile oracle is separate from forward masks/owner helpers. Its
first checkpoint compares every slot of the full dense R_tile(x), including
hostile padding. The later two checkpoints gather selected raw global-key
entries; the sparse roundtrip oracle cannot substitute for this path.
All actual binary64 scales must follow the independently checked production
recurrence. Eighteen checkpoints cover1,179,648 slots. Expected route totals:
72 rotations including outer tiles,168 public products,156 ciphertext adds,
42 composite rescales,12 critical public-multiplication levels across six maps.
The one noncanonical input product/rescale is recorded separately. The matching
four-map subset is48 rotations; extra independent-inverse validation means a
whole-run duration cannot be directly compared to the predecessor108-rotation
four-map run. No controlled speedup is presumed.

Raw stored ciphertext sizes are200MiB for two L49 inputs and148MiB for all18
checkpoint outputs; headers/temporary writes need explicit additional margin.
This is IO arithmetic, not process memory. Existing key mappings, NTT controls,
compiler caches and transient arrays require separate host-RSS observation.
Use a fresh owned IO root, preserve all external key/model/ranked workspaces,
and retire only this proof's owned ciphertext workspace after complete client
validation or audited failure. Retain public hash/provenance evidence.

Reuse the reviewed borrowed-directory/terminal/compiled-owner lifecycle helpers
without changing their measured bytes. Preserve primary exceptions, process
reaping, original arrays through callbacks and cleanup, and unresolved owners
in quarantine; no retry of uncertain closed FD numbers. CPU124–127 is available
for a later actual proof, with4 threads and explicit JAX_PLATFORMS=cpu, pending
fresh resource checks. No healthy-work timeout. One parent owns/reaps all stages.

Before execution, build a source-bound preparation suite: synthetic success and
failure/cancellation/cleanup matrices, all actual public prerequisite gates,
installed entrypoint denial/restoration probes, no private/key/payload reads in
preflight, source/archive/current equality and terminal observation. Root reviews
that exact candidate and independently pins the final reports before each actual
phase. A partial or failed stage cannot authorize client decoding or claim the
numerical/performance gate. This design does not validate full BERT or rank cases.
