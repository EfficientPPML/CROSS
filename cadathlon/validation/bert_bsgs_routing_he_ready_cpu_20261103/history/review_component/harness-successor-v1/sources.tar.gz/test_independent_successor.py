import os,sys,json,signal,ctypes,subprocess
from pathlib import Path
from types import ModuleType
import numpy as np
import pytest
import component_worker as w
import component_contract as c
import collect_component as collector
from test_component_worker import orchestration,Value
from test_collect_component import setup


def test_finite_extreme_decode_retains_serializable_failure(tmp_path,monkeypatch):
    cfg,keys,events,stored=orchestration(monkeypatch,tmp_path);fixture={}
    w.fixture(cfg,keys,b'profile',b'plan',fixture,lambda:None)
    oracle=w.public_oracle();x,_=oracle.fixture_arrays();proof=c.numerical_plan()
    def exercise(ctx,source,ones,*,checkpoint):
        i=0
        for case in proof['cases']:
            forward=oracle.oracle(x,gain=case['gain'])
            answers={'forward':forward,'roundtrip_inverse':oracle.oracle(forward['key placement'],inverse=True),'hostile_inverse':oracle.oracle(x,inverse=True)}
            for row in case['checkpoints']:
                slots=answers[row['direction']][row['label']].copy()
                if i==0:slots[:]=np.finfo(np.float64).max
                checkpoint(i,Value(slots,events),{n:row[n] for n in ('direction','label','level','scale','counts')}|dict(case=case['name']));i+=1
        return {}
    fake=ModuleType('component_arithmetic');fake.exercise=exercise;monkeypatch.setitem(sys.modules,'component_arithmetic',fake)
    server={};w.server(cfg,keys,b'profile',b'plan',server,lambda:None,{'fixture':fixture})
    report={}
    with np.errstate(over='ignore',invalid='ignore'):
        with pytest.raises(ValueError):w.validate(cfg,keys,b'profile',b'plan',report,lambda:c.canonical(report),{'fixture':fixture,'server':server})
    assert report['numeric_checkpoints'][0]['passed'] is False
    c.canonical(report)



def test_terminal_orphan_cannot_pass_or_launch_next_stage(tmp_path,monkeypatch):
    events,_=setup(monkeypatch,failure='orphan')
    output=tmp_path/'proof'
    with pytest.raises(RuntimeError,match='surviving owned process group'):
        collector.collect(output=output,key_evidence=tmp_path/'public',key_workspace=tmp_path/'keys')
    report=json.loads((output/'report.json').read_bytes())
    assert report['passed'] is False and report['terminal_scope_completed'] is False
    assert len(report['children'])==1
    row=report['children'][0]
    assert row['direct_child_reaped'] is True and row['direct_returncode']==0
    assert row['group_empty_verified'] is True and row['cleanup_completed'] is True
    assert report['all_owned_groups_empty'] is True
    assert 'no descendant-reap claim' in row['scope']
    assert any(e[0]=='kill' for e in events if isinstance(e,tuple))
