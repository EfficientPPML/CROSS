"""Independent codec/edge comparison for the isolated scalar candidate."""
import sys, time, math, json, hashlib, warnings
from pathlib import Path
sys.path[:0] = ['/tmp/refresh-scalar-lab-v2', '/home/jianming_gatech/CROSS', '/home/jianming_gatech/CROSS/cadathlon/common']
import numpy as np
from jaxite_word import ckks_ctx
from encrypted_refresh import RefreshProfile
from uniform_scalar_codec import encode_array, try_uniform_array
LAB = Path('/tmp/refresh-scalar-lab-v2'); ROOT = Path('/home/jianming_gatech/CROSS')
files = [Path(__file__), LAB/'uniform_scalar_codec.py', *sorted((ROOT/'jaxite_word').rglob('*.py'))]
hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
Q = RefreshProfile(131072,49,56,61,4).parameters()['q_towers'][:2]
base = dict(slots=[.75]*16, cycl_order=64, q_towers=Q, p_towers=[], scale=2.**56)
started = time.perf_counter(); records = []; rng = np.random.default_rng(20261102)

def outcome(fn, kwargs):
    with warnings.catch_warnings(record=True) as seen:
        warnings.simplefilter('always')
        try:
            value = fn(**kwargs); error = None
        except Exception as exc:
            value = None; error = (type(exc).__name__, str(exc))
    return value, error, [(w.category.__name__,str(w.message)) for w in seen]

def check(label, kwargs, *, independent=False, expected_route=None, mode=None):
    actual, error, warns = outcome(encode_array, kwargs)
    baseline, expected_error, expected_warns = outcome(ckks_ctx._ckks_encode_array, kwargs)
    assert error == expected_error, (label, kwargs, error, expected_error)
    assert warns == expected_warns, (label, kwargs, warns, expected_warns)
    route = 'fallback' if try_uniform_array(**kwargs) is None else 'uniform'
    if expected_route: assert route == expected_route, (label, route)
    if error is None:
        np.testing.assert_array_equal(actual, baseline)
        assert actual.flags.c_contiguous and actual.flags.writeable and actual.dtype == np.uint64
    oracle_checked = False
    if independent and route == 'uniform':
        # Keep the identical FFT slot count: a larger reference FFT could
        # overflow on a valid sparse extreme. The constant NTT image itself
        # is degree independent; compare its per-modulus row after checking
        # every reference row agrees.
        oracle_args = dict(kwargs, cycl_order=4*len(kwargs['slots']),
                           slots=[complex(value) for value in kwargs['slots']])
        oracle, oracle_error, _ = outcome(ckks_ctx._ckks_encode_fall_back, oracle_args)
        assert oracle_error == error, (label, oracle_error, error)
        if error is None:
            oracle = np.asarray(oracle, dtype=np.uint64)
            np.testing.assert_array_equal(oracle, np.broadcast_to(oracle[0],oracle.shape))
            np.testing.assert_array_equal(actual, np.broadcast_to(oracle[0],actual.shape))
        oracle_checked = True
    records.append(dict(label=label, route=route, error=error, warnings=warns, mode=mode, independent=oracle_checked))

# Random binary64 exponents/mantissas exercise log_approx, restoration, zero
# underflow, overflow, and exceptions; both NSD1/2 and every supported word.
for i in range(2000):
    scalar = math.ldexp(float(rng.uniform(-1.,1.)), int(rng.integers(-1074,1024)))
    scale = math.ldexp(float(rng.uniform(.5,1.)), int(rng.integers(-1073,1024)))
    if scale == 0.: scale = float(np.nextafter(0.,1.))
    kwargs = dict(base, slots=[scalar]*int(rng.choice([1,2,4,8,16])), scale=scale,
                  noise_scale_degree=int(rng.choice([1,2])), max_bits_in_word=int(rng.integers(1,62)))
    check('seeded_binary64', kwargs, independent=True)

# Quantization tie points on both sides of every supported word boundary.
for word in range(1,62):
    for target in (2.**word, 2.**word-.5, np.nextafter(2.**word,0.), np.nextafter(2.**word,math.inf)):
        for sign in (-1.,1.):
            check('every_word_boundary', dict(base, slots=[float(sign*target/2.**56)]*16,
                  max_bits_in_word=word, noise_scale_degree=2), independent=True)

for dtype in (np.bool_,np.int8,np.int64,np.uint64,np.float16,np.float32,np.float64,np.longdouble,np.complex64,np.complex128,np.clongdouble):
    choices = [0,1] if np.dtype(dtype).kind=='b' else [0,1,3]
    for value in choices:
        for container in (np.array([value]*16,dtype=dtype), np.array([value]*16,dtype=dtype).tolist()):
            check('numeric_dtype',dict(base, slots=container),independent=True)
for integer in (2**53-1,2**53+1,2**63-1,2**63+1,2**64-1):
    check('uint64_rounding_conversion',dict(base,slots=np.full(16,integer,dtype=np.uint64)),independent=True)
for value in (np.longdouble('1.0000000000000000001'),np.finfo(np.longdouble).max):
    for dtype in (np.longdouble,np.clongdouble):
        check('extended_precision_conversion',dict(base,slots=np.full(16,value,dtype=dtype)),independent=False)
for modulus in (193*257,193*449,257*449,257*577):
    check('custom_composite_modulus',dict(base,q_towers=[modulus]),independent=True)
for scalar in (-0.,0.,float(np.nextafter(0.,1.)),sys.float_info.min,sys.float_info.max/16,np.nextafter(sys.float_info.max/16,math.inf)):
    check('signed_subnormal_fft_boundary',dict(base,slots=[scalar]*16,scale=2.**-1000),independent=False)

# Nondefault NumPy floating error handling delegates unmodified, including
# warning multiplicity, raised FloatingPointError, and exceptional zeros.
min_subnormal=float(np.nextafter(0.,1.))
for policy in ('warn','raise','ignore','print','log'):
    if policy in ('print','log'): continue  # Output/callback modes covered below with safe normal values.
    for scalar,scale in [(min_subnormal,np.float64(min_subnormal)),(sys.float_info.max,np.float64(2.)),(sys.float_info.max,1.),(.75,2.**56)]:
        with np.errstate(all=policy):
            check('numpy_error_policy',dict(base,slots=[scalar]*16,scale=scale),expected_route='fallback',mode=policy)
for policy in ('print','log','call'):
    with np.errstate(all=policy):
        check('numpy_error_policy_normal',base,expected_route='fallback',mode=policy)

for kwargs in [dict(base,max_bits_in_word=np.int64(61)),dict(base,max_bits_value=np.int64((1<<63)-(1<<9)-1)),
               dict(base,noise_scale_degree=np.int64(2)),dict(base,scale=np.float32(2.**20)),
               dict(base,q_towers=np.asarray(Q)),dict(base,q_towers=[np.int64(q) for q in Q]),
               dict(base,q_towers=[]),dict(base,q_towers=[17]),dict(base,slots=['.75']*16),
               dict(base,slots=[2**2000]*16),dict(base,slots=[None]*16),dict(base,cycl_order=np.int64(64))]:
    check('unusual_types_and_ring',kwargs,expected_route='fallback')
# The unused P argument remains unused, including nonstandard values.
for unused in (None,[object()],np.array([1,2])):
    check('unused_p_compatibility',dict(base,p_towers=unused),independent=True,expected_route='uniform')
# Cache reuse updates exactly the ordinary codec's public parameters.
ctx=ckks_ctx._get_or_make_encode_ctx(Q,32,1.,1,127)
encode_array(**base)
assert ctx.scaling_factor==base['scale'] and ctx.parameters['max_bits_in_word']==61 and ctx.parameters['max_bits_value']==(1<<63)-(1<<9)-1
report=dict(passed=True,scope='Isolated codec-only edge and independent-reference checks; no encrypted evaluation or accelerator performance claim',
            seed=20261102,cases=len(records),uniform_cases=sum(r['route']=='uniform' for r in records),
            fallback_cases=sum(r['route']=='fallback' for r in records),independent_cases=sum(r['independent'] for r in records),
            exception_cases=sum(r['error'] is not None for r in records),warning_cases=sum(bool(r['warnings']) for r in records),
            source_hashes=hashes,source_hashes_unchanged=hashes=={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
            total_seconds=time.perf_counter()-started,records=records)
assert report['source_hashes_unchanged']
(LAB/'edge_report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('records','source_hashes')}))
