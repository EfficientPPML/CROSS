import sys,time,math,json,hashlib,warnings,gc
from pathlib import Path
sys.path[:0]=['/tmp/refresh-scalar-lab-v2','/home/jianming_gatech/CROSS','/home/jianming_gatech/CROSS/cadathlon/common']
import numpy as np
from jaxite_word import ckks_ctx
from encrypted_refresh import RefreshProfile
from uniform_scalar_codec import encode_array,try_uniform_array,DEFAULT_BOUND
ROOT=Path('/home/jianming_gatech/CROSS'); LAB=Path('/tmp/refresh-scalar-lab-v2')
files=[Path(__file__),LAB/'uniform_scalar_codec.py',*sorted((ROOT/'jaxite_word').rglob('*.py')),ROOT/'cadathlon/common/encrypted_refresh.py']
hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
started=time.perf_counter();params=RefreshProfile(131072,49,56,61,4).parameters();Q=params['q_towers'];N=131072;S=params['scaling_factor'];records=[]

def outcome(fn,kwargs):
 with warnings.catch_warnings(record=True) as seen:
  warnings.simplefilter('always')
  try:
   value=fn(**kwargs);error=None
  except Exception as exc:
   value=None;error=(type(exc).__name__,str(exc))
 return value,error,[(w.category.__name__,str(w.message)) for w in seen]

def check(label,kwargs,*,independent=True,expected_route=None):
 baseline,error,warn=outcome(ckks_ctx._ckks_encode_array,kwargs)
 actual,actual_error,actual_warn=outcome(encode_array,kwargs)
 assert error==actual_error,(label,error,actual_error)
 assert warn==actual_warn,(label,warn,actual_warn)
 with warnings.catch_warnings():
  warnings.simplefilter('ignore'); probe=try_uniform_array(**kwargs)
 route='fallback' if probe is None else 'uniform'
 if expected_route:assert route==expected_route,(label,route,expected_route)
 if error is None:
  np.testing.assert_array_equal(actual,baseline)
  assert actual.dtype==np.uint64 and actual.flags.c_contiguous and actual.flags.writeable
  if independent:
   # Constants have a degree-independent NTT image. The independent scalar
   # encoder uses the same production Q prefix/scale in a small full ring;
   # selected cases below additionally run its actual131072-degree NTT.
   scalar=complex(kwargs['slots'][0]);refkwargs=dict(kwargs)
   refkwargs['slots']=[scalar]*16;refkwargs['cycl_order']=64
   oracle=np.asarray(ckks_ctx._ckks_encode_fall_back(**refkwargs),dtype=np.uint64)
   np.testing.assert_array_equal(oracle,np.broadcast_to(oracle[0],oracle.shape))
   np.testing.assert_array_equal(actual,np.broadcast_to(oracle[0],actual.shape))
 records.append(dict(label=label,degree=kwargs['cycl_order']//2,num_q=len(kwargs['q_towers']),slots=len(kwargs['slots']),scale=repr(kwargs['scale']),noise_scale_degree=repr(kwargs.get('noise_scale_degree',1)),word=repr(kwargs.get('max_bits_in_word',61)),bound=repr(kwargs.get('max_bits_value',DEFAULT_BOUND)),route=route,error=error,warnings=warn,independent_constant_oracle=bool(independent and error is None)))
 if len(records)%24==0:print(f'[{time.perf_counter()-started:.1f}s] {len(records)} cases passed',flush=True)

for level in (0,1,4,12,25,49):
 q=Q[:2*(level+1)]
 for slots in (128,N//2):
  for scale in (S,S*S):
   for nsd in (1,2):
    for scalar in (-14.2,-.000003,0.,.75):
     check('production_matrix',dict(slots=[complex(scalar)]*slots,cycl_order=2*N,q_towers=q,p_towers=[],scale=scale,noise_scale_degree=nsd),expected_route='uniform')

# Half-integer and mantissa/word boundaries against actual production rings.
boundaries=[0.,np.nextafter(0.,1.),np.nextafter(.5,0.),.5,np.nextafter(.5,1.),np.nextafter(1.5,0.),1.5,np.nextafter(1.5,2.),2.**52-.5,2.**52,2.**52+1.,np.nextafter(2.**61,0.),2.**61,np.nextafter(2.**61,math.inf)]
for target in boundaries:
 for sign in (-1.,1.):
  scalar=float(sign*target/2.**56)
  check('rounding_boundary',dict(slots=[complex(scalar)]*128,cycl_order=2*N,q_towers=Q[:4],p_towers=[],scale=2.**56),expected_route='fallback' if 0<abs(scalar*2.**56)<=.5 else 'uniform')
for word in (1,31,53,61):
 for scalar in (-1.25,.75):
  check('large_log_approx',dict(slots=[complex(scalar)]*128,cycl_order=2*N,q_towers=Q[:10],p_towers=[],scale=2.**200,noise_scale_degree=2,max_bits_in_word=word),expected_route='uniform')

# The fallback owns behavior outside the supported envelope, including its
# existing accepted-but-unusual settings and exact exception/warning behavior.
base=dict(slots=[complex(-.3125)]*16,cycl_order=64,q_towers=Q[:2],p_towers=[],scale=2.**20)
for word in (0,-1,62,64,61.5,'61'):
 check('unusual_word',dict(base,max_bits_in_word=word),independent=False,expected_route='fallback')
for bound in (127,(1<<61)-1,1<<63,1<<64,0,-1,float(DEFAULT_BOUND)):
 check('unusual_bound',dict(base,max_bits_value=bound),independent=False,expected_route='fallback')
for nsd in (0,-1,3,True,1.5):
 check('unusual_nsd',dict(base,noise_scale_degree=nsd),independent=False,expected_route='fallback')
for scale in (0.,-1.,True,1<<20,float('inf'),float('nan')):
 check('unusual_scale',dict(base,scale=scale),independent=False,expected_route='fallback')
for values in ([1.,2.]*8,[1j]*16,[float('nan')]*16,[float('inf')]*16,[1.]*3,[],[[1.]*4]*4):
 check('guarded_vector',dict(base,slots=values),independent=False,expected_route='fallback')
for scalar,scale,slots in [(sys.float_info.max,1.,128),(sys.float_info.max,2.**-1000,128),(sys.float_info.max/128,2.**-1000,128),(sys.float_info.max,2.,1),(np.nextafter(0.,1.),np.nextafter(0.,1.),128)]:
 check('extreme_float',dict(slots=[complex(scalar)]*slots,cycl_order=2*N,q_towers=Q[:2],p_towers=[],scale=scale),independent=False)

full_oracles=[]
for level,scalar,scale,nsd,word in [(0,-.3125,S,1,61),(49,-.3125,S,2,61),(25,-.03125,2.**120,2,31)]:
 kwargs=dict(slots=[complex(scalar)]*(N//2),cycl_order=2*N,q_towers=Q[:2*(level+1)],p_towers=[],scale=scale,noise_scale_degree=nsd,max_bits_in_word=word)
 begin=time.perf_counter();oracle=np.asarray(ckks_ctx._ckks_encode_fall_back(**kwargs),dtype=np.uint64);seconds=time.perf_counter()-begin
 actual=encode_array(**kwargs);np.testing.assert_array_equal(actual,oracle)
 full_oracles.append(dict(level=level,num_q=len(kwargs['q_towers']),noise_scale_degree=nsd,scale=repr(scale),word=word,bit_exact=True,reference_seconds=seconds))
 print(f'[{time.perf_counter()-started:.1f}s] full independent scalar reference level{level} passed ({seconds:.2f}s)',flush=True)
 del oracle,actual;gc.collect()

# Encoding-only observations with prebuilt ordinary-encoder NTT tables.
# Both outputs are fully materialized, writable contiguous uint64 arrays.
benchmark=dict(slots=[complex(-.3125)]*128,cycl_order=2*N,q_towers=Q,p_towers=[],scale=S*S)
baseline=ckks_ctx._ckks_encode_array(**benchmark);candidate=encode_array(**benchmark)
np.testing.assert_array_equal(candidate,baseline)
encoding={'ordinary_array_codec':[],'guarded_uniform_codec':[]}
for name,fn in [('ordinary_array_codec',ckks_ctx._ckks_encode_array),('guarded_uniform_codec',encode_array)]:
 for _ in range(3):
  begin=time.perf_counter();value=fn(**benchmark);encoding[name].append(time.perf_counter()-begin)
  np.testing.assert_array_equal(value,baseline);del value
import jax
jax.config.update('jax_enable_x64',True);assert jax.default_backend()=='cpu'
transfers={'ordinary_array':[],'candidate_array':[]}
for label,array in [('ordinary_array',baseline),('candidate_array',candidate)]:
 device=jax.numpy.asarray(array,dtype=jax.numpy.uint64);device.block_until_ready()
 for _ in range(3):
  begin=time.perf_counter();device=jax.numpy.asarray(array,dtype=jax.numpy.uint64);device.block_until_ready();transfers[label].append(time.perf_counter()-begin)
assert hashes=={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
report=dict(passed=True,scope='Isolated real-uniform standard-residue codec candidate with guarded fallback; no encrypted bootstrap/full-model/TPU timing claim',backend='cpu',production_profile=dict(degree=N,num_q=len(Q),num_p=len(params['p_towers']),depth=49),cases=len(records),full_independent_reference_cases=full_oracles,encoding_only_seconds=encoding,encoding_timing_scope='Warm public NTT tables; fully materialized host arrays; excludes transfer and client encryption',separate_cpu_array_conversion_seconds=transfers,cpu_conversion_scope='Warm CPU JAX ndarray conversion; may share host buffers, not a TPU transfer measurement',source_hashes_unchanged=True,source_hashes=hashes,total_seconds=time.perf_counter()-started,records=records)
(LAB/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('records','source_hashes')}),flush=True)
