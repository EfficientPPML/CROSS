"""Isolated guarded real-uniform encoder; not installed in CROSS.

The result is a writable, contiguous standard-residue NTT array. Supported
uniform real vectors have only coefficient zero after the special inverse FFT.
Power-of-two butterfly sums are exact while their intermediates stay finite.
All original quantization and noise-scale multiplication are retained.
Unknown settings and exceptional inputs delegate to the unchanged array codec.
"""
from functools import lru_cache
import math
import sys
import numpy as np
from jaxite_word import ckks_ctx

DEFAULT_BOUND = (1 << 63) - (1 << 9) - 1


@lru_cache(maxsize=256)
def _supported_roots(degree, moduli):
    # Do not accept a ring that the ordinary encoder would reject while
    # constructing its public NTT tables. No full tables are needed here.
    for modulus in moduli:
        ckks_ctx.util.root_of_unity(2*degree, modulus)
    return True


def try_uniform_array(slots, cycl_order, q_towers, p_towers, scale,
                      noise_scale_degree=1, max_bits_in_word=61,
                      max_bits_value=DEFAULT_BOUND):
    del p_towers  # The existing encoder also ignores this compatibility arg.
    # Preserve caller-selected floating-point warning/error semantics exactly.
    # The original FFT contains many array operations; only its default mode
    # is covered by the finite-intermediate argument used here.
    if np.geterr() != dict(divide="warn", over="warn", under="ignore", invalid="warn"):
        return None
    if (type(slots) not in (list, tuple, np.ndarray)
            or type(q_towers) not in (list, tuple)
            or type(cycl_order) is not int or cycl_order < 4
            or cycl_order & (cycl_order-1)
            or type(noise_scale_degree) is not int or noise_scale_degree not in (1, 2)
            or type(max_bits_in_word) is not int or not 1 <= max_bits_in_word <= 61
            or type(max_bits_value) is not int or max_bits_value != DEFAULT_BOUND
            or type(scale) not in (float, np.float64) or not math.isfinite(scale) or scale <= 0):
        return None
    degree = cycl_order//2
    try:
        values = np.asarray(slots)
        if (values.ndim != 1 or values.dtype.kind not in 'biufc'
                or values.size < 1 or values.size & (values.size-1)
                or values.size > degree//2 or degree//2 % values.size
                or not np.isfinite(values).all()):
            return None
        if np.any(np.imag(values) != 0) or not np.all(values == values[0]):
            return None
        scalar = float(np.real(values[0]))
        # Constant FFT butterfly intermediates can overflow even when the
        # later scaled constant would be finite. Preserve ordinary fallback.
        if abs(scalar) > sys.float_info.max/len(values):
            return None
        moduli = tuple(q_towers)
        if not moduli or any(type(q) is not int or not 0 < q < (1 << 31) for q in moduli):
            return None
        with np.errstate(all='ignore'):
            scaled = scalar*scale
        if not math.isfinite(scaled):
            return None
        # A nonzero sub-half coefficient raises ScalingFactorTooSmall in
        # the original codec. Let it retain that exact error behavior.
        logc = int(math.ceil(math.log2(abs(scaled)))) if scaled else 0
        if logc < 0:
            return None
        _supported_roots(degree, moduli)
    except (TypeError, ValueError, OverflowError):
        return None
    # Preserve the original context-cache parameter updates as well as its
    # exact log_approx quantization; no NTT tables or private keys are needed.
    ckks_ctx._get_or_make_encode_ctx(moduli, degree, scale, max_bits_in_word, max_bits_value)
    shift = max(0, logc-max_bits_in_word)
    coefficient = ckks_ctx.nearest_int(scaled/(2.**shift))
    # The guarded bound/word pair keeps signed coefficients inside the
    # unambiguous centered interval used by FitToNativeVector.
    if abs(coefficient) > max_bits_value//2:
        return None
    multiplier = 1 << shift
    if noise_scale_degree > 1:
        multiplier *= pow(int(round(scale)), noise_scale_degree-1)
    integer = coefficient*multiplier
    residues = np.asarray([integer % q for q in moduli], dtype=np.uint64)
    return np.broadcast_to(residues, (degree,len(moduli))).copy(order='C')


def encode_array(*args, **kwargs):
    result = try_uniform_array(*args, **kwargs)
    return ckks_ctx._ckks_encode_array(*args, **kwargs) if result is None else result
