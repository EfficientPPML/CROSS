from pathlib import Path
import hashlib,json,shutil,tarfile
ROOT=Path('/home/jianming_gatech/CROSS'); LAB=Path('/tmp/refresh-scalar-lab-v2'); DEST=ROOT/'cadathlon/validation'
production=json.loads((LAB/'report.json').read_text());edges=json.loads((LAB/'edge_report.json').read_text())
assert production['passed'] and edges['passed'] and production['source_hashes_unchanged'] and edges['source_hashes_unchanged']
for report in (production,edges):
 for source,digest in report['source_hashes'].items():assert hashlib.sha256(Path(source).read_bytes()).hexdigest()==digest,source
names={'report.json':'scalar_uniform_codec_production_cpu.json','edge_report.json':'scalar_uniform_codec_edges_cpu.json','run.log':'scalar_uniform_codec_production_cpu.log','edge.log':'scalar_uniform_codec_edges_cpu.log'}
for source,target in names.items():shutil.copy2(LAB/source,DEST/target)
sources={**production['source_hashes'],**edges['source_hashes']};archive=DEST/'scalar_uniform_codec_cpu_sources.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for source in sorted(sources):
  path=Path(source)
  name='isolated/'+path.name if path.is_relative_to(LAB) else 'measured_source/'+str(path.relative_to(ROOT))
  tar.add(path,arcname=name)
 for name in ('edge_initial_oracle_mismatch.log','edge_initial_type_mismatch.log'):
  tar.add(LAB/name,arcname='development/'+name)
 tar.add(Path(__file__),arcname='isolated/archive_evidence.py')
report=dict(passed=True,scope='Validation-only isolated real-uniform public CKKS codec candidate; no production integration, encrypted bootstrap timing, accelerator transfer timing, or model-performance claim',
 production_matrix_cases=production['cases'],full_ring_independent_reference_cases=len(production['full_independent_reference_cases']),
 additional_edge_cases=edges['cases'],additional_independent_reference_checks=edges['independent_cases'],
 source_hashes_unchanged=True,observed_process_exit_codes={'production_matrix':0,'edge_suite':0},
 candidate_source_sha256=sources[str(LAB/'uniform_scalar_codec.py')],
 guarded_envelope=['One-dimensional real-uniform finite numeric vector; power-of-two slot count dividing N/2',
 'Power-of-two cyclotomic order; compatible positive uint31 moduli with accepted roots',
 'Finite positive binary64 scale, default NumPy floating error configuration, NSD exactly integer1 or2',
 'Default signed bound and integer word bits1 through61; rounded coefficient within centered half interval',
 'Finite FFT intermediates: abs(constant)<=maxfloat/slot_count; finite scaled coefficient',
 'Nonzero scaled magnitudes requiring logc<0 delegate to preserve ScalingFactorTooSmall; exact underflow to zero retains ordinary zero encoding'],
 fallback='All unsupported vector/parameter/error-policy settings delegate to unchanged _ckks_encode_array; warning and exception parity checked. Python input iterators and unusual scalar/container types are not consumed by the fast path.',
 mathematical_basis='For a real uniform vector, each FFT difference is exactly zero and each nonzero sum is a power-of-two scaling; guarded intermediates stay finite. Division by the power-of-two slot count returns the same binary64 constant. Only coefficient0 is nonzero, so its standard-residue NTT image is uniform in each modulus. The candidate uses the same log2/ceil, nearest_int, log_approx restoration and integer noise-scale multiplier as the ordinary codec.',
 timing={'encoding_only_seconds':production['encoding_only_seconds'],'scope':production['encoding_timing_scope'],
         'separate_cpu_array_conversion_seconds':production['separate_cpu_array_conversion_seconds'],'conversion_scope':production['cpu_conversion_scope']},
 development_notes=['Initial independent-oracle harness used full16 slots for sparse extreme values, which could overflow a reference FFT that the sparse candidate did not use; corrected to preserve slot count.',
 'The independent scalar reference expects normalized complex values; boolean/raw NumPy inputs were normalized as in the production codec before comparison.',
 'Candidate conservatively delegates every nondefault NumPy floating error mode to preserve caller-selected warnings and exceptions.',
 'Earlier48-case scalar experiment and already-landed ndarray/list conversion patch are separate evidence; these timings do not include those historical runs.'],
 reproduction=['Extract measured_source under a checkout root and isolated files to /tmp/refresh-scalar-lab-v2 (scripts record the original /home/jianming_gatech/CROSS path).',
 'Set JAX_PLATFORMS=cpu, OMP_NUM_THREADS=4, OPENBLAS_NUM_THREADS=4; run check_uniform_scalar.py and check_scalar_edges.py with the recorded JAX environment. Original affinity: CPU152–155.'],
 artifacts={name:hashlib.sha256((DEST/name).read_bytes()).hexdigest() for name in (*names.values(),archive.name)})
(DEST/'scalar_uniform_codec_cpu_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'passed':True,'production_cases':production['cases'],'edge_cases':edges['cases'],'archive_bytes':archive.stat().st_size,'candidate_sha256':report['candidate_source_sha256']}))
