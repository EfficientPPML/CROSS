from types import SimpleNamespace
import json
import numpy as np
import pytest
import prepare_all_attention_fixtures as prep

class Tensor:
    def __init__(self,data):self.data=data
    def detach(self):return self
    def cpu(self):return self
    def numpy(self):return self.data
class Module:
    def __init__(self,events):self.hooks=[];self.events=events;self.cleanup_error=None
    def register_forward_hook(self,hook):
        self.hooks.append(hook)
        def remove():
            self.events.append('removed');self.hooks.remove(hook)
            if self.cleanup_error:raise self.cleanup_error
        return SimpleNamespace(remove=remove)
    def emit(self,value):
        for hook in self.hooks:hook(self,(),(Tensor(value),))
def fake_model(sequence=3):
    events=[];layers=[]
    for _ in range(12):
        layer=Module(events);layer.attention=Module(events);layers.append(layer)
    model=SimpleNamespace(bert=SimpleNamespace(encoder=SimpleNamespace(layer=layers)))
    def forward(skip=None):
        for i,layer in enumerate(layers):
            if i!=skip:layer.attention.emit(np.full((1,sequence,768),i+.25))
            layer.emit(np.full((1,sequence,768),i+.5))
    return model,forward,events

def test_every_native_label_and_all_hooks_removed():
    model,forward,events=fake_model();out=prep.capture_native(model,forward,3)
    assert len(out)==24 and len(events)==24
    for i in range(12):
        assert np.all(out[('attention',i)]==i+.25) and np.all(out[('block',i)]==i+.5)
        assert not model.bert.encoder.layer[i].hooks and not model.bert.encoder.layer[i].attention.hooks

def test_missing_label_fails_closed_and_removes_all_hooks():
    model,forward,events=fake_model()
    with pytest.raises(ValueError,match='incomplete'):prep.capture_native(model,lambda:forward(skip=4),3)
    assert len(events)==24

@pytest.mark.parametrize('primary_present',[False,True])
def test_native_capture_cleanup_cancellation_preserves_primary(primary_present):
    model,forward,events=fake_model();cleanup=KeyboardInterrupt('remove');primary=ValueError('forward')
    model.bert.encoder.layer[0].attention.cleanup_error=cleanup
    def run():
        if primary_present:raise primary
        forward()
    with pytest.raises(ValueError if primary_present else KeyboardInterrupt) as caught:prep.capture_native(model,run,3)
    assert caught.value is (primary if primary_present else cleanup) and len(events)==24

@pytest.mark.parametrize('invalid',['shape','float32','nan','duplicate'])
def test_native_capture_rejects_wrong_output(invalid):
    model,forward,events=fake_model()
    def run():
        a=np.zeros((1,3,768))
        if invalid=='shape':a=a[:,:,:2]
        elif invalid=='float32':a=a.astype(np.float32)
        elif invalid=='nan':a[0,0,0]=np.nan
        model.bert.encoder.layer[0].attention.emit(a)
        if invalid=='duplicate':model.bert.encoder.layer[0].attention.emit(a)
    with pytest.raises(ValueError):prep.capture_native(model,run,3)
    assert len(events)==24

def test_positions_keep_original_indices_and_reject_nonbinary():
    mask=np.zeros(128,dtype=np.int64);mask[[0,2,7]]=1
    np.testing.assert_array_equal(prep.positions_from_mask(mask,3),[0,2,7])
    mask[3]=2
    with pytest.raises(ValueError):prep.positions_from_mask(mask,3)

def test_fixed_key_count_cannot_be_selected_from_domain_success():
    mask=np.ones(128,dtype=np.int64)
    with pytest.raises(ValueError):prep.positions_from_mask(mask,15)

def test_parity_gate_and_array_record_are_fixed():
    a=np.zeros((3,768));assert prep.parity(a,a)==0
    b=a.copy();b[0,0]=1.01e-12
    with pytest.raises(ValueError,match='gate'):prep.parity(a,b)
    report=prep.array_record(a);json.dumps(report,allow_nan=False)
    assert report['dtype']=='<f8' and report['shape']==[3,768]

def test_failure_report_before_assets_or_native_import(tmp_path,monkeypatch):
    primary=KeyboardInterrupt('source failure')
    monkeypatch.setattr(prep,'sources',lambda:(_ for _ in ()).throw(primary))
    with pytest.raises(KeyboardInterrupt) as caught:prep.run(tmp_path/'snapshot',tmp_path/'failed')
    assert caught.value is primary
    r=json.loads((tmp_path/'failed/fixture_preparation.json').read_text());assert not r['passed'] and r['error']['type']=='KeyboardInterrupt'
