from pathlib import Path
import hashlib,json,math
lab=Path('/tmp/bert-layer-attention-20261103')
base=(lab/'first_attention_contract.py').read_text()
model=Path('/home/jianming_gatech/cross_validation_assets/bert/f150c1d609d1e50dd5e2e5408661cfac8339277c/model.safetensors')
expected='e1f8085ef673c9eb8a1a93a84270742e8aa0ccbceadef01eef15e26c44b46034'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert sha(model)==expected
prefix={'query':'attention.self.query','key':'attention.self.key','value':'attention.self.value','output':'attention.output.dense'}
pins={}
with model.open('rb') as f:
    n=int.from_bytes(f.read(8),'little');h=json.loads(f.read(n));offset=8+n
    for layer in range(12):
        pins[layer]={}
        for role,p in prefix.items():
            pins[layer][role]={}
            for kind in ('weight','bias'):
                name=f'bert.encoder.layer.{layer}.{p}.{kind}';d=h[name]
                shape=[768,768] if kind=='weight' else [768]
                assert d['dtype']=='F32' and d['shape']==shape
                a,b=d['data_offsets'];assert b-a==4*math.prod(shape)
                f.seek(offset+a);raw=f.read(b-a);assert len(raw)==b-a
                pins[layer][role][kind]=hashlib.sha256(raw).hexdigest()
assert sha(model)==expected
start=base.index('TENSOR_SHA256 = ');end=base.index('PREFIX = ',start)
import pprint
base=base[:start]+'# All96 raw F32 tensor pins were extracted from the checkpoint SHA\n# '+expected+'.\nTENSOR_SHA256 = '+pprint.pformat(pins,width=112,sort_dicts=False)+'\n'+base[end:]
base=base.replace('Pinned public first-attention schema','Pinned public layer-attention schema')
base=base.replace('def canonical(value):\n    return json.dumps(value, sort_keys=True, separators=(\',\', \':\'), allow_nan=False).encode()', '''def canonical(value):
    """Canonical exact JSON types; numeric aliases cannot change typed contracts."""
    def check(x):
        if x is None or type(x) in (str, bool, int, float):
            return
        if type(x) is list:
            for v in x: check(v)
            return
        if type(x) is dict and all(type(k) is str for k in x):
            for v in x.values(): check(v)
            return
        raise ValueError('contract requires exact JSON scalar/container types')
    check(value)
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()''')
base=base.replace('def make_contract(original_positions, context_id, request_id):','''def _layer(layer):
    if type(layer) is not int or not 0 <= layer < 12:
        raise ValueError('layer must be an exact Python integer in 0..11')
    return layer


def make_contract(original_positions, context_id, request_id, *, layer):
    layer = _layer(layer)''')
base=base.replace("schema='bert-first-attention-contract-v1', context_id=context_id,", "schema='bert-layer-attention-contract-v1', layer=layer, context_id=context_id,")
base=base.replace('input_tile_count=8, input_level=49, output_level=9,','''input_tile_count=8 if layer == 0 else t,
                input_level=49 if layer == 0 else None, input_level_range=[49, 49] if layer == 0 else [2, 49],
                output_level=9 if layer < 6 else 8,''')
base=base.replace("name='bert.encoder.layer.0.' + PREFIX[role] + '.' + kind", "name=f'bert.encoder.layer.{layer}.' + PREFIX[role] + '.' + kind")
base=base.replace('for role, pins in TENSOR_SHA256.items()}),','for role, pins in TENSOR_SHA256[layer].items()}),')
base=base.replace("tail_rows='zero-pad-compacted-input-to-128-rows',", "tail_rows='zero-pad-compacted-input-to-128-rows' if layer == 0 else 'refresh-T-tiles-then-subtract-zero-to-eight',")
base=base.replace("value.get('request_id'))", "value.get('request_id'), layer=value.get('layer'))")
base=base.replace('def validate_projection_arrays(model):','def validate_projection_arrays(model, layer):')
base=base.replace("    if type(model) is not dict or set(model) != set(TENSOR_SHA256):", "    pins_by_role = TENSOR_SHA256[_layer(layer)]\n    if type(model) is not dict or set(model) != set(pins_by_role):")
base=base.replace('for role, pins in TENSOR_SHA256.items():','for role, pins in pins_by_role.items():')
base=base[:base.index('def make_descriptor(')] + '''def _level(value):
    if type(value) is not int or not 0 <= value <= 49:
        raise ValueError('level must be an exact Python integer in 0..49')
    return value


def make_descriptor(contract, *, role, tile_index, payload_sha256, level=None, scale=None, input_digest=None):
    """Metadata only; the caller must authenticate actual serialized payload bytes."""
    c = validate_contract(contract); p = c['profile']
    if type(role) is not str or role not in ('attention_input', 'attention_output'):
        raise ValueError('unknown role')
    count = c['input_tile_count'] if role == 'attention_input' else c['query_tiles']
    if type(tile_index) is not int or not 0 <= tile_index < count:
        raise ValueError('tile index out of range')
    _hex(payload_sha256, 64, 'payload_sha256')
    if role == 'attention_input':
        if input_digest is not None:
            raise ValueError('input descriptors cannot carry a response binding')
        if c['layer'] == 0:
            if level is not None and _level(level) != 49:
                raise ValueError('fresh layer0 input must be level49')
            if scale is not None and _scale(scale) != p['scaling_factor']:
                raise ValueError('fresh layer0 input must have canonical scale')
            level = 49; scale = p['scaling_factor']
        else:
            if _level(level) < 2:
                raise ValueError('later inputs require at least level2 for refresh')
            _scale(scale)
    else:
        if level is not None and _level(level) != c['output_level']:
            raise ValueError('output level differs from selected layer schedule')
        level = c['output_level']; _scale(scale); _hex(input_digest, 64, 'input_digest')
    return dict(schema='bert-layer-attention-descriptor-v1', layer=c['layer'], context_id=c['context_id'],
                request_id=c['request_id'], contract_sha256=digest(c), role=role,
                tile_index=tile_index, tile_count=count,
                valid_rows=max(0, min(16, c['key_count'] - 16*tile_index)),
                level=level, moduli=p['q_towers'][:2*(level+1)], scale=scale, nsd=1,
                degree=p['degree'], degree_layout=p['degree_layout'], precision=p['precision'],
                batch=p['batch'], ciphertext_components=2, payload_sha256=payload_sha256,
                input_digest=input_digest)


def validate_descriptors(values, contract, *, role, expected_levels, expected_scales, input_digest=None):
    """Check every descriptor against a separately supplied actual metadata plan."""
    c = validate_contract(contract)
    count = c['input_tile_count'] if role == 'attention_input' else c['query_tiles'] if role == 'attention_output' else 0
    if not count or type(values) is not list or len(values) != count:
        raise ValueError('missing, duplicate or extra descriptor inventory')
    for plan in (expected_levels, expected_scales):
        if type(plan) not in (list, tuple) or len(plan) != count:
            raise ValueError('both inventories require actual public level and scale plans')
    for level in expected_levels: _level(level)
    for scale in expected_scales: _scale(scale)
    if role == 'attention_input' and input_digest is not None:
        raise ValueError('request inventory has response-only binding')
    result = []
    for i, value in enumerate(values):
        if type(value) is not dict:
            raise ValueError('descriptor must be a mapping')
        expected = make_descriptor(c, role=role, tile_index=i, payload_sha256=value.get('payload_sha256'),
                                   level=expected_levels[i], scale=expected_scales[i], input_digest=input_digest)
        if canonical(value) != canonical(expected):
            raise ValueError('descriptor metadata, order or request binding mismatch')
        result.append(expected)
    return result


def request_digest(values, contract, *, expected_levels, expected_scales):
    """Bind all required inputs, order, layer, context, nonce and actual metadata."""
    return digest(validate_descriptors(values, contract, role='attention_input',
                                     expected_levels=expected_levels, expected_scales=expected_scales))
'''
(lab/'layer_attention_contract.py').write_text(base)
print('96 exact public tensor pins verified; contract source written')
