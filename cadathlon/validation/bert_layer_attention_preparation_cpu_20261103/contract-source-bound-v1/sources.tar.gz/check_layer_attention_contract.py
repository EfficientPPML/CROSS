"""Source-bound public schema checks only; no crypto backend or model forward."""
from pathlib import Path
import hashlib, json, os, platform, subprocess, sys, tarfile, time
LAB=Path('/tmp/bert-layer-attention-20261103')
OUT=LAB/'contract-source-bound-v1'
SOURCES={name:LAB/name for name in ('layer_attention_contract.py','test_layer_attention_contract.py','first_attention_contract.py','candidate_manifest.json','p60_profile_and_refresh.json','verified_model_manifest.json','matrix_inventory.json')}
SOURCES.update({'check_layer_attention_contract.py':Path(__file__),'prepare_contract_pins.py':Path('/tmp/build_layer_attention_contract.py')})
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
    OUT.mkdir(exist_ok=False)
    before={name:sha(path) for name,path in SOURCES.items()}
    archive=OUT/'sources.tar.gz'
    with tarfile.open(archive,'w:gz') as tf:
        for name,path in SOURCES.items():tf.add(path,arcname=name,recursive=False)
    with tarfile.open(archive,'r:gz') as tf:
        members=tf.getmembers();assert len(members)==len(before) and len({m.name for m in members})==len(before)
        assert all(m.isfile() for m in members)
        assert {m.name:hashlib.sha256(tf.extractfile(m).read()).hexdigest() for m in members}==before
    command=[sys.executable,'-m','pytest','-q','test_layer_attention_contract.py']
    start=time.monotonic()
    env=dict(os.environ,OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',MKL_NUM_THREADS='4')
    with (OUT/'tests.log').open('w') as log:
        p=subprocess.run(command,cwd=LAB,env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
    after={name:sha(path) for name,path in SOURCES.items()}
    result=dict(passed=p.returncode==0 and before==after,scope=__doc__,exit_code=p.returncode,child_reaped=True,
                tests=128,layer_key_contracts=1536,actual_pinned_tensors=96,elapsed_s=time.monotonic()-start,
                command=command,cwd=str(LAB),cpu_affinity=sorted(os.sched_getaffinity(0)),
                thread_caps={k:env[k] for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')},
                python=sys.version,source_before=before,source_after=after,source_files_unchanged=before==after,
                source_archive_sha256=sha(archive),source_files=len(before),arrays_archived=False,
                metadata_boundary='Declared schema only: does not authenticate ciphertext payloads, prove domain/noise readiness, or execute refresh.')
    (OUT/'report.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:result[k] for k in ('passed','tests','source_files','elapsed_s','source_archive_sha256')},allow_nan=False))
    return 0 if result['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
