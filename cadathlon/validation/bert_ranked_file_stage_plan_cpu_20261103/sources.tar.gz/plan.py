"""Public shape/accounting design only. No private files, keys or HE imports."""
from pathlib import Path
import copy, hashlib, json, math, statistics, sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'sources/stage'))
import transport_contract as tc
import file_stage_contract as batches

GIB = 1 << 30
SCHEDULE = tuple((size, count, seed) for size, count in ((1, 100), (2, 200), (3, 408)) for seed in (42, 43, 44))
STEPS = ('Input preprocessing', 'Input encryption', 'Encrypted computation', 'Result decryption', 'Result postprocessing')


def storage(count):
    if type(count) is not int or count not in (100, 200, 408):
        raise ValueError('one ranked public count required')
    p = tc.parameters()
    input_bytes = 2 * p['degree'] * len(p['q_towers']) * 4
    output_bytes = 2 * p['degree'] * (2 * (2 + 1)) * 4
    upload = count * 8 * input_bytes
    download = count * output_bytes
    return dict(count=count, request_ciphertexts=8*count, response_ciphertexts=count,
        request_payload_bytes_each=input_bytes, response_payload_bytes_each=output_bytes,
        upload_payload_bytes=upload, download_payload_bytes=download,
        combined_payload_bytes=upload+download, upload_gib=upload/GIB,
        download_gib=download/GIB, combined_gib=(upload+download)/GIB,
        encode_capacity_check_bytes=count*8*(input_bytes+65536)+GIB,
        server_capacity_check_additional_bytes=count*(output_bytes+65536)+GIB,
        combined_planned_payload_header_reserve_bytes=upload+download+count*9*65536+2*GIB,
        serialized_ciphertext_file_count=27*count,
        note='Payload lower bounds; current handler estimates reserve64KiB per container and1GiB per stage. Not runtime RSS or a reservation.')


def synthetic_batch(count):
    public=tc.public_identity(dict(context_id='a'*64,model_id='b'*64,
        parameters=tc.parameters(),checkpoint_sha256=tc.CHECKPOINT_SHA256,
        config_sha256=tc.CONFIG_SHA256,candidate_sha256=tc.CANDIDATE_SHA256,
        profile_sha256=tc.PROFILE_SHA256))
    requests=[]
    for i in range(count):
        # Maximal public-position metadata. IDs are synthetic and never loaded.
        positions=list(range(128)); k=len(positions)
        metadata=dict(schema='bert-client-row-packing-v1',input_tile_count=8,
            original_positions=positions,original_attention_mask=[1]*128,
            compact_key_mask=[1]*128,key_count=k,query_tiles=8,valid_rows=[16]*8,
            packing=dict(slots=65536,row_pitch=4096,rows_per_tile=16,active_features=768,
                row_order='increasing original positions',positions_applied='before compaction',
                feature_padding='zero',unused_rows='zero',input_dtype='float64'))
        c=tc.make_contract(public,f'{i:032x}',metadata)
        requests.append(dict(contract=c,input_digest=hashlib.sha256(str(i).encode()).hexdigest()))
    batch=batches.public_batch(public,requests,count=count)
    responses=[dict(request_id=r['contract']['request_id'],input_digest=r['input_digest'],
        scale=tc.parameters()['scaling_factor'],response_manifest_sha256=hashlib.sha256(('response'+str(i)).encode()).hexdigest())
        for i,r in enumerate(requests)]
    response=batches.response_batch(batch,responses)
    private=batches.private_requests(batch,list(range(count)),'c'*64)
    return batch,response,private


def ranked_accuracy(count, correct, native_correct):
    if any(type(x) is not int for x in (count,correct,native_correct)) or count not in (100,200,408):
        raise ValueError('exact ranked counts required')
    if not 0 <= correct <= count or not 0 <= native_correct <= count:
        raise ValueError('complete bounded counts required')
    return 4*correct>=3*count and 100*(native_correct-correct)<=2*count


def median_online(measurements):
    """Design metric: three explicit one-run results; steps5–9 are not run counts."""
    if type(measurements) is not list or len(measurements)!=3:
        raise ValueError('three completed fresh one-run records required')
    sizes=[r.get('size') for r in measurements]
    seeds=[r.get('seed') for r in measurements]
    if (any(type(s)is not int or s not in (1,2,3) for s in sizes) or len(set(sizes))!=1
            or any(type(s)is not int for s in seeds) or sorted(seeds)!=[42,43,44]):
        raise ValueError('one size and exact three predeclared seeds required')
    sums=[]
    for record in measurements:
        if record.get('passed') is not True or record.get('num_runs')!=1 or type(record.get('num_runs'))is not int:
            raise ValueError('failed or differently repeated record cannot enter median')
        values=[]
        for step in STEPS:
            text=record['Timing'][step]
            if type(text)is not str or not text.endswith('s'):
                raise ValueError('original harness seconds string required')
            value=float(text[:-1])
            if not math.isfinite(value) or value<0:
                raise ValueError('finite nonnegative stage time required')
            values.append(value)
        sums.append(sum(values))
    return dict(stage_numbers=[5,6,7,8,9],invocations=3,per_invocation_s=sums,median_online_s=statistics.median(sums))


def build():
    fixture_raw=(HERE/'sources/evidence/fixture_report.json').read_bytes()
    reference_raw=(HERE/'sources/evidence/reference_report.json').read_bytes()
    assert hashlib.sha256(fixture_raw).hexdigest()=='ad1458f5183c6ccf2631c2a8771d0da92196f5f9c690016e2a0b12fa7b88f4d7'
    assert hashlib.sha256(reference_raw).hexdigest()=='77f93c90e03609bdaf12441cc8a8d07e08b5e1a475c1480f283b4f592668ae74'
    fixtures=json.loads(fixture_raw);reference=json.loads(reference_raw)
    assert all(reference.get(n)is True for n in reference['reference_acceptance_requires'])
    assert [(c['size'],c['count'],c['base_seed']) for c in fixtures['cases']]==list(SCHEDULE)
    assert [(c['size'],c['count'],c['seed']) for c in reference['cases']]==list(SCHEDULE)
    rows=[]
    for (size,count,seed),case,ref in zip(SCHEDULE,fixtures['cases'],reference['cases']):
        assert ref['input_sha256']==case['input_file_sha256'][f"io/{('single','small','medium','large')[size]}/intermediate/client_preprocessed_input"]
        assert ref['private_target_order_sha256']==case['private_target_order_sha256']
        min_correct=max((3*count+3)//4,(100*ref['official_correct']-2*count+99)//100)
        rows.append(dict(size=size,count=count,seed=seed,input_sha256=ref['input_sha256'],
            private_target_order_sha256=ref['private_target_order_sha256'],
            official_correct=ref['official_correct'],required_minimum_correct=min_correct,
            valid_token_count_histogram=case['valid_token_count_histogram']))
    metadata=[]
    for count in (100,200,408):
        b,r,p=synthetic_batch(count)
        batches.validate_public_batch(b,public=b['public'],count=count)
        batches.validate_response_batch(r,b,check_scale=lambda s:s==tc.parameters()['scaling_factor'])
        batches.validate_private_requests(p,b,list(range(count)),'c'*64)
        sizes={n:len(tc.canonical(v)) for n,v in [('upload_batch',b),('response_batch',r),('private_requests',p)]}
        assert all(size<16<<20 for size in sizes.values())
        metadata.append(dict(count=count,synthetic_maximal_position_metadata_bytes=sizes,
            actual_payloads_created=False,receipt_file_bound_not_measured=True))
    return dict(scope='public-only ranked file-stage orchestration plan; no private input/reference/key/ciphertext reads, model or HE execution',
        fixture_report_sha256=hashlib.sha256(fixture_raw).hexdigest(),reference_report_sha256=hashlib.sha256(reference_raw).hexdigest(),
        candidate_sha256=reference['candidate_sha256'],cases=rows,selected_records=2124,
        storage=[storage(c) for c in (100,200,408)],metadata=metadata,
        all_nine_upload_payload_bytes=sum(storage(n)['upload_payload_bytes'] for _,n,_ in SCHEDULE),
        all_nine_response_payload_bytes=sum(storage(n)['download_payload_bytes'] for _,n,_ in SCHEDULE),
        timing=dict(original_harness_default_num_runs=1,ranked_invocations_per_size=3,
            ranked_seeds=[42,43,44],each_invocation_num_runs=1,online_stage_names=list(STEPS),
            formula='median over seeds of SUM of steps5–9 per invocation; throughput=count/median',
            server_reported_timing_accepted_as_substitute=False),
        ranked_acceptance=dict(accuracy_floor='4*HE_correct >= 3*N',accuracy_drop='100*(official_correct-HE_correct) <= 2*N',
            tie='class0 iff logit0>logit1, else class1',prediction_agreement='diagnostic',
            finite_logits_complete_ordered_output_required=True,per_logit_tolerance='separate component/reference diagnostic'),
        original_fixtures=54,original_reference_files=11,existing_key_store_retained=True,
        actual_handler_batch_execution=False,ranked_accuracy_or_timing_claim=False)


if __name__=='__main__':
    print(json.dumps(build(),indent=2,sort_keys=True,allow_nan=False))
