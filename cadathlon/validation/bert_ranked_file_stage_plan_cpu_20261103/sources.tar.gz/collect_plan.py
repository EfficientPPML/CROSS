"""Source-bound public-only tests and resource arithmetic; no model/HE work."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET

HERE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True,allow_nan=False)+'\n')


def main():
    started=time.perf_counter();out=HERE/'source-bound-v1';out.mkdir(exist_ok=False)
    sources=[p for p in (HERE/'sources').rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    sources += [HERE/n for n in ('source_origins.json','plan.py','test_plan.py','DESIGN.md','collect_plan.py')]
    before={str(p.relative_to(HERE)):sha(p) for p in sorted(sources)}
    origins=json.loads((HERE/'source_origins.json').read_text())
    assert all(sha(Path(v['path']))==v['sha256']==sha(HERE/'sources'/n) for n,v in origins.items())
    with tarfile.open(out/'sources.tar.gz','w:gz') as tar:
        for name in before:tar.add(HERE/name,arcname=name,recursive=False)
    report=dict(passed=False,scope='public source/schema/resource planning only; no private reads or crypto/model work',
        started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),
        cpu_affinity=sorted(os.sched_getaffinity(0)),source_hashes_before=before,
        source_archive_sha256=sha(out/'sources.tar.gz'),private_bodies_read=False,
        model_or_he_execution=False)
    write(out/'report.json',report)
    try:
        with (out/'tests.log').open('wb') as log:
            test=subprocess.run([sys.executable,'-m','pytest','-q','test_plan.py','--junitxml='+str(out/'tests.xml')],cwd=HERE,stdout=log,stderr=subprocess.STDOUT)
        report['test_returncode']=test.returncode
        xml=ET.parse(out/'tests.xml').getroot();suites=[xml] if xml.tag=='testsuite' else list(xml)
        counts={key:sum(int(s.attrib.get(key,0)) for s in suites) for key in ('tests','errors','failures','skipped')}
        report['test_counts']=counts
        import plan
        planned=plan.build();write(out/'plan.json',planned)
        report['plan_sha256']=sha(out/'plan.json')
        report['forbidden_backends_absent']=not any(n in sys.modules for n in ('jax','torch','transformers'))
        report['source_hashes_after']={n:sha(HERE/n) for n in before}
        report['original_public_sources_unchanged']=all(sha(Path(v['path']))==v['sha256'] for v in origins.values())
        report['source_files_unchanged']=report['source_hashes_after']==before
        with tarfile.open(out/'sources.tar.gz') as tar:
            members=tar.getmembers()
            report['source_archive_verified']=(len(members)==len(before)==len({m.name for m in members})
                and all(m.isfile() for m in members)
                and {m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in members}==before)
        report['passed']=(test.returncode==0 and counts==dict(tests=38,errors=0,failures=0,skipped=0)
            and report['source_files_unchanged'] and report['source_archive_verified']
            and report['original_public_sources_unchanged'] and report['forbidden_backends_absent'])
    except BaseException as error:
        report['error_type']=type(error).__name__;raise
    finally:
        report['elapsed_s']=time.perf_counter()-started
        write(out/'report.json',report)
    print(json.dumps({k:report[k] for k in ('passed','test_counts','elapsed_s','source_archive_sha256')}))
    return 0 if report['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
