"""Public synthetic order/count and accounting regressions; no encrypted execution."""
import copy
import pytest
import plan


@pytest.mark.parametrize('count',[100,200,408])
def test_actual_contract_accepts_complete_ordered_batch(count):
    batch,response,private=plan.synthetic_batch(count)
    assert plan.batches.validate_public_batch(batch,public=batch['public'],count=count)==batch
    assert plan.batches.validate_private_requests(private,batch,list(range(count)),'c'*64)==private
    assert plan.batches.validate_response_batch(response,batch,check_scale=lambda s:s==plan.tc.parameters()['scaling_factor'])==response
    assert 'target_idx' not in plan.tc.canonical(batch).decode()
    assert 'input_ids' not in plan.tc.canonical(batch).decode()


@pytest.mark.parametrize('count',[100,200,408])
@pytest.mark.parametrize('fault',['swap','missing','extra','duplicate','last_digest','last_scale'])
def test_last_or_ordered_response_failure_is_not_hidden(count,fault):
    batch,response,_=plan.synthetic_batch(count)
    rows=response['responses']
    if fault=='swap':rows[0],rows[-1]=rows[-1],rows[0]
    elif fault=='missing':rows.pop()
    elif fault=='extra':rows.append(copy.deepcopy(rows[-1]))
    elif fault=='duplicate':rows[-1]=copy.deepcopy(rows[0])
    elif fault=='last_digest':rows[-1]['input_digest']='f'*64
    else:rows[-1]['scale']=1.
    with pytest.raises(ValueError):
        plan.batches.validate_response_batch(response,batch,check_scale=lambda s:s==plan.tc.parameters()['scaling_factor'])


@pytest.mark.parametrize('count',[100,200,408])
def test_client_retained_order_rejects_reordered_requests(count):
    batch,_,private=plan.synthetic_batch(count)
    batch['requests'].reverse()
    # Public syntax alone has no private target order; the client binding supplies it.
    plan.batches.validate_public_batch(batch,public=batch['public'],count=count)
    with pytest.raises(ValueError):
        plan.batches.validate_private_requests(private,batch,list(range(count)),'c'*64)


@pytest.mark.parametrize('n,native,minimum',[(100,82,80),(100,79,77),(100,84,82),(200,162,158),(200,172,168),(200,166,162),(408,345,337)])
def test_exact_integer_gate_boundaries(n,native,minimum):
    assert plan.ranked_accuracy(n,minimum,native)
    assert not plan.ranked_accuracy(n,minimum-1,native)


def test_storage_complete_batch_and_median_of_sums():
    assert plan.storage(408)['upload_payload_bytes']==318.75*plan.GIB
    assert plan.storage(408)['download_payload_bytes']==2.390625*plan.GIB
    records=[]
    # Median of sums=111, while sum of per-stage medians=12.
    for seed,values in zip((42,43,44),((100,1,10,0,0),(1,100,10,0,0),(1,1,1,0,0))):
        records.append(dict(size=1,seed=seed,passed=True,num_runs=1,Timing=dict(zip(plan.STEPS,[f'{v}s' for v in values]))))
    assert plan.median_online(records)['median_online_s']==111
    records[-1]['passed']=False
    with pytest.raises(ValueError):plan.median_online(records)


@pytest.mark.parametrize('field,value',[('seed',42),('seed',True),('size',2),('num_runs',True),('num_runs',5)])
def test_median_does_not_mix_cases_or_repeat_modes(field,value):
    rows=[dict(size=1,seed=seed,num_runs=1,passed=True,Timing={s:'1s' for s in plan.STEPS}) for seed in (42,43,44)]
    rows[-1][field]=value
    with pytest.raises(ValueError):plan.median_online(rows)


def test_public_reports_and_size_bounds_only():
    report=plan.build()
    assert len(report['cases'])==9 and report['selected_records']==2124
    assert report['all_nine_upload_payload_bytes']==1659.375*plan.GIB
    assert report['all_nine_response_payload_bytes']==12.4453125*plan.GIB
    assert not any(name in __import__('sys').modules for name in ('jax','torch','transformers'))
