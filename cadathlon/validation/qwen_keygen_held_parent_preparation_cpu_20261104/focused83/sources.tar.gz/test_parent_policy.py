"""UID seams are disclosed; directory modes and all files are real and owned."""
import os
import sys
import pytest
from parent_test_helpers import parent_fixture,fake_parent_uid,open_tiny,complete_tiny

@pytest.mark.parametrize('case',['current_owner','root_owner','untrusted_owner','shared_without_sticky','shared_with_sticky'])
def test_uid_and_sticky_policy_before_creation(tmp_path,monkeypatch,case):
    mode=0o777 if case=='shared_without_sticky'else(0o1777 if case=='shared_with_sticky'else 0o700)
    parent,raw=parent_fixture(tmp_path,mode)
    uid=0 if case=='root_owner'else(max(os.geteuid(),0)+100000 if case=='untrusted_owner'else os.geteuid())
    fake_parent_uid(monkeypatch,parent,uid)
    if case in('untrusted_owner','shared_without_sticky'):
        with pytest.raises(ValueError,match='UID/sticky'):open_tiny(parent,raw)
        assert not(parent/'keys').exists()
    else:
        owner,spec=open_tiny(parent,raw)
        try:
            complete_tiny(owner,spec)
            assert owner.parent_uid==uid
            owner.check()
        finally:owner.close(primary=sys.exception())
        assert owner.closed and owner.parent.fd is None and owner.directory.fd is None
