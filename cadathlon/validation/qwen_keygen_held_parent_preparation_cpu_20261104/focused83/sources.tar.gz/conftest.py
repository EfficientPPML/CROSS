"""Focused tiny owned-file tests only; no cryptographic/backend execution."""
import importlib.abc
from pathlib import Path
import sys
import pytest

HERE=Path(__file__).resolve().parent
RUNTIME=HERE/'runtime'
FORBIDDEN={'jax','jaxlib','jaxite_word','torch','torch_xla','tensorflow','flax','transformers','safetensors','libtpu','tokenizers'}

class DenyBackend(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0]in FORBIDDEN:raise RuntimeError('owned parent tests forbid backend discovery: '+fullname)

if any(n.split('.')[0]in FORBIDDEN for n in sys.modules):raise RuntimeError('backend preloaded')
sys.meta_path.insert(0,DenyBackend())
sys.path.insert(0,str(HERE));sys.path.insert(0,str(RUNTIME))

@pytest.fixture(autouse=True)
def selected_source_and_no_backend():
    import qwen_key_store
    assert Path(qwen_key_store.__file__).resolve()==RUNTIME/'qwen_key_store.py'
    assert not any(n.split('.')[0]in FORBIDDEN for n in sys.modules)
    yield
    assert not any(n.split('.')[0]in FORBIDDEN for n in sys.modules)
