"""Tiny real files and original descriptor retirement; no actual key role."""
from contextlib import nullcontext
import errno
import hashlib
import io
import os
import stat
import sys
import numpy as np
import pytest
import qwen_key_store as store
from parent_test_helpers import parent_fixture,specification,open_tiny,complete_tiny,replace_os,fake_parent_uid

@pytest.mark.parametrize('private',[False,True])
def test_tiny_numpy_manifest_success_preserves_original_owners(tmp_path,private):
    parent,raw=parent_fixture(tmp_path);owner,spec=open_tiny(parent,raw,private)
    parent_fd=owner.parent.fd
    try:
        value,record=complete_tiny(owner,spec)
        control=io.BytesIO();np.save(control,value,allow_pickle=False)
        body=(owner.root/spec.name).read_bytes()
        assert body==control.getvalue()and record['sha256']==hashlib.sha256(body).hexdigest()
        assert owner.expected_parent is raw and owner.verify()=={spec.name:record}
        assert owner.parent.fd==parent_fd and os.fstat(parent_fd).st_ino==parent.stat().st_ino
        assert set(p.name for p in owner.root.iterdir())=={spec.name,owner.manifest_name}
        assert stat.S_IMODE(owner.root.stat().st_mode)==0o700
        assert all(stat.S_IMODE(p.stat().st_mode)==0o600 for p in owner.root.iterdir())
    finally:owner.close(primary=sys.exception())
    assert owner.closed and owner.parent.fd is None and owner.directory.fd is None

@pytest.mark.parametrize('field',['expected_parent','parent_expectation','effective_uid','parent_uid'])
def test_captured_parent_binding_rejects_mirror_replacement(tmp_path,field):
    parent,raw=parent_fixture(tmp_path);owner,spec=open_tiny(parent,raw)
    try:
        complete_tiny(owner,spec);original=getattr(owner,field)
        replacement=b'{}\n'if field=='expected_parent'else(tuple(list(original)[:-1]+[0])if field=='parent_expectation'else original+1)
        setattr(owner,field,replacement)
        try:
            with pytest.raises(ValueError,match='binding changed'):owner.check()
        finally:setattr(owner,field,original)
        owner.check()
    finally:owner.close(primary=sys.exception())

def test_later_parent_mode_change_fails_but_all_original_descriptors_retire(tmp_path):
    parent,raw=parent_fixture(tmp_path);owner,spec=open_tiny(parent,raw)
    try:
        complete_tiny(owner,spec);fds=[owner.parent.fd,owner.directory.fd]+[f.fd for f in owner.files]
        parent.chmod(0o750)
        with pytest.raises(ValueError,match='external key parent identity')as caught:owner.close()
        assert owner.failed is caught.value and owner.closed
        assert owner.parent.fd is None and owner.directory.fd is None and all(f.fd is None for f in owner.files)
        for fd in fds:
            with pytest.raises(OSError)as closed:os.fstat(fd)
            assert closed.value.errno==errno.EBADF
        assert (owner.root/spec.name).exists()and(owner.root/owner.manifest_name).exists()
    finally:
        parent.chmod(0o700)
        if not owner.closed:owner.close(primary=sys.exception())

def test_later_uid_change_rejects_even_an_individually_trusted_uid(tmp_path,monkeypatch):
    parent,raw=parent_fixture(tmp_path)
    # Both UID1001/current and UID0/root are individually trusted. Only the
    # explicit metadata seams change; no chown or real privilege change occurs.
    fake_parent_uid(monkeypatch,parent,1001,effective_uid=1001)
    owner,spec=open_tiny(parent,raw)
    try:
        complete_tiny(owner,spec)
        fake_parent_uid(monkeypatch,parent,0,effective_uid=1001)
        with pytest.raises(ValueError,match='original key parent UID changed'):owner.check()
    finally:
        fake_parent_uid(monkeypatch,parent,1001,effective_uid=1001)
        owner.close(primary=sys.exception())

@pytest.mark.parametrize('stage',['fstat','mkdir','mkdir_close'])
def test_construction_failure_preserves_primary_and_retires_original_parent(tmp_path,monkeypatch,stage):
    parent,raw=parent_fixture(tmp_path);opened=[];closed=[];mkdirs=[]
    primary=KeyboardInterrupt('controlled mkdir body')if stage=='mkdir'else OSError('controlled constructor body')
    later=SystemExit('controlled uncertain close');real_open=os.open;real_close=os.close;real_fstat=os.fstat
    def open_fd(*args,**kwargs):fd=real_open(*args,**kwargs);opened.append(fd);return fd
    def fstat(fd):
        if stage=='fstat'and fd in opened:raise primary
        return real_fstat(fd)
    def mkdir(*args,**kwargs):mkdirs.append(args);raise primary
    def close_fd(fd):
        closed.append(fd);real_close(fd)
        if stage=='mkdir_close':raise later
    replace_os(monkeypatch,open=open_fd,fstat=fstat,mkdir=mkdir,close=close_fd)
    with pytest.raises(type(primary))as caught:
        store.KeyStore(parent/'keys',(specification(),),expected_parent=raw,shield=nullcontext)
    assert caught.value is primary and len(opened)==1 and closed==opened
    assert len(mkdirs)==(0 if stage=='fstat'else 1)and not(parent/'keys').exists()
    with pytest.raises(OSError)as gone:real_fstat(opened[0])
    assert gone.value.errno==errno.EBADF
    failed=[row[0]for row in store._QUARANTINE if isinstance(row[0],store.KeyStore)and row[0].failed is primary]
    assert len(failed)==1 and failed[0].parent.fd is None and failed[0].closed
    count=len(closed)
    with pytest.raises(type(primary))as repeated:failed[0].close()
    assert repeated.value is primary and len(closed)==count
