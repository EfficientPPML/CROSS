"""Own tiny directories only; metadata seams are explicitly test-local."""
from contextlib import nullcontext
from pathlib import Path
from types import SimpleNamespace as NS
import os
import stat
import numpy as np
import qwen_key_store as store
from qwen_key_contract import ArraySpec,canonical

def parent_fixture(tmp_path,mode=0o700):
    parent=tmp_path/'parent';parent.mkdir(mode=mode);parent.chmod(mode)
    return parent,expectation(parent)

def expectation(parent):
    info=parent.lstat()
    return canonical(dict(path=str(parent),device=info.st_dev,inode=info.st_ino,mode=stat.S_IMODE(info.st_mode)))

def specification(private=False):
    return ArraySpec('secret.npy'if private else'public_key.npy',(1,8)if private else(2,1,8),(97,))

def replace_os(monkeypatch,**overrides):
    values=dict(vars(os));values.update(overrides);monkeypatch.setattr(store,'os',NS(**values))

def open_tiny(parent,raw,private=False):
    spec=specification(private)
    return store.KeyStore(parent/'keys',(spec,),expected_parent=raw,private=private,shield=nullcontext),spec

def complete_tiny(owner,spec):
    count=1
    for dimension in spec.shape:count*=dimension
    value=np.arange(count,dtype=np.uint32).reshape(spec.shape)
    record=owner.write_array(spec.name,value)
    assert owner.write_manifest(b'{}\n')==b'{}\n'
    return value,record

def stat_with_uid(info,uid):
    return NS(**{name:(uid if name=='st_uid'else getattr(info,name))for name in dir(info)if name.startswith('st_')})

def fake_parent_uid(monkeypatch,parent,uid,*,effective_uid=None):
    # This is a metadata-only seam: no chown or borrowed parent is used.
    real_fstat=os.fstat;real_lstat=Path.lstat;identity=(parent.stat().st_dev,parent.stat().st_ino)
    def fstat(fd):
        info=real_fstat(fd)
        return stat_with_uid(info,uid)if(info.st_dev,info.st_ino)==identity else info
    def lstat(path,*args,**kwargs):
        info=real_lstat(path,*args,**kwargs)
        return stat_with_uid(info,uid)if path==parent else info
    overrides=dict(fstat=fstat)
    if effective_uid is not None:overrides['geteuid']=lambda:effective_uid
    replace_os(monkeypatch,**overrides)
    monkeypatch.setattr(Path,'lstat',lstat)
