"""Required external metadata and held/named admission before creation."""
from contextlib import nullcontext
from pathlib import Path
import errno
import json
import os
import pytest
import qwen_key_store as store
from qwen_key_contract import canonical
from parent_test_helpers import parent_fixture,specification,replace_os

@pytest.mark.parametrize('case',['missing','none','mutable','duplicate','noncanonical','unknown','boolean_device','boolean_inode','boolean_mode','zero_inode','relative_path','wrong_path','oversized'])
def test_parent_bytes_reject_before_any_open(tmp_path,monkeypatch,case):
    parent,raw=parent_fixture(tmp_path);value=json.loads(raw);calls=[]
    if case=='none':raw=None
    elif case=='mutable':raw=bytearray(raw)
    elif case=='duplicate':raw=b'{"path":"duplicate",'+raw[1:]
    elif case=='noncanonical':raw=(json.dumps(value,sort_keys=True,indent=2)+'\n').encode()
    elif case=='unknown':raw=canonical(value|{'extra':True})
    elif case.startswith('boolean_'):raw=canonical(value|{case[8:]:True})
    elif case=='zero_inode':raw=canonical(value|{'inode':0})
    elif case=='relative_path':raw=canonical(value|{'path':'relative'})
    elif case=='wrong_path':raw=canonical(value|{'path':str(tmp_path/'other')})
    elif case=='oversized':raw=b' '*8193
    def forbidden(*args,**kwargs):calls.append((args,kwargs));raise AssertionError('metadata rejection reached os.open')
    replace_os(monkeypatch,open=forbidden)
    kwargs=dict(private=False,shield=nullcontext)
    if case!='missing':kwargs['expected_parent']=raw
    with pytest.raises((ValueError,TypeError)):
        store.KeyStore(parent/'keys',(specification(),),**kwargs)
    assert calls==[] and not(parent/'keys').exists()

@pytest.mark.parametrize('field',['device','inode','mode'])
def test_wrong_granted_identity_opens_then_retires_parent_before_mkdir(tmp_path,monkeypatch,field):
    parent,raw=parent_fixture(tmp_path);value=json.loads(raw)
    value[field]=value[field]+1 if field!='mode'else value[field]^0o040
    opened=[];closed=[];mkdirs=[];real_open=os.open;real_close=os.close
    def open_fd(*args,**kwargs):fd=real_open(*args,**kwargs);opened.append(fd);return fd
    def close_fd(fd):closed.append(fd);real_close(fd)
    def mkdir(*args,**kwargs):mkdirs.append(args);raise AssertionError('identity mismatch reached mkdir')
    replace_os(monkeypatch,open=open_fd,close=close_fd,mkdir=mkdir)
    with pytest.raises(ValueError,match='external key parent identity'):
        store.KeyStore(parent/'keys',(specification(),),expected_parent=canonical(value),shield=nullcontext)
    assert len(opened)==1 and closed==opened and mkdirs==[]
    with pytest.raises(OSError)as caught:os.fstat(opened[0])
    assert caught.value.errno==errno.EBADF and not(parent/'keys').exists()

@pytest.mark.parametrize('when',['before_open','after_open'])
def test_real_owned_parent_replacement_cannot_redefine_external_identity(tmp_path,monkeypatch,when):
    parent,raw=parent_fixture(tmp_path);retained=tmp_path/'original-parent'
    opened=[];closed=[];mkdirs=[];real_open=os.open;real_close=os.close
    def replace():parent.rename(retained);parent.mkdir(mode=0o700)
    def open_fd(path,*args,**kwargs):
        assert Path(path)==parent and opened==[]
        if when=='before_open':replace()
        fd=real_open(path,*args,**kwargs);opened.append(fd)
        if when=='after_open':replace()
        return fd
    def close_fd(fd):closed.append(fd);real_close(fd)
    def mkdir(*args,**kwargs):mkdirs.append(args);raise AssertionError('replacement reached child creation')
    replace_os(monkeypatch,open=open_fd,close=close_fd,mkdir=mkdir)
    with pytest.raises(ValueError,match='external key parent identity'):
        store.KeyStore(parent/'keys',(specification(),),expected_parent=raw,shield=nullcontext)
    assert len(opened)==1 and closed==opened and mkdirs==[]
    assert parent.stat().st_ino!=retained.stat().st_ino
    assert not(parent/'keys').exists()and not(retained/'keys').exists()
    with pytest.raises(OSError)as caught:os.fstat(opened[0])
    assert caught.value.errno==errno.EBADF
