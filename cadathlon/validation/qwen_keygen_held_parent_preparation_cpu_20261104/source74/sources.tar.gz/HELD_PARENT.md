# Held-parent writer successor — source only

This isolated tree copies admitted71 exactly, then overlays only `qwen_key_store.py` and adds this document, `parent71_sources.json` and `held_parent_provenance.json`. The original71, pure28/39 authority sources and all completed proofs remain unchanged. Root source-authoring authorization335a51f2 permits this narrow implementation; it does not authorize candidate imports, collection, tests, capacity/current-store inventory, bodies, RNG, actual key generation or an actual role.

The required constructor is now:

`KeyStore(root, specs, *, expected_parent, private=False, shield=cleanup_signals)`

`expected_parent` must be immutable bytes, at most8192B, canonical compact JSON plus newline with exactly the existing grant fields `path`, `device`, `inode`, `mode`. The selected existing bounded parser rejects duplicate/nonfinite metadata. Path is an exact canonical absolute non-root string up to4096 characters and must equal the requested leaf's parent. Device/inode/mode require exact integers (bool rejected), with device>=0, inode>0 and mode0..4095. There is no None/default or observe-current fallback.

Before any descriptor acquisition, the writer captures those bytes and the parsed immutable tuple; after opening the original parent FD, but before mkdir, it compares both held and named parent to the external tuple. Both must be directories with the same UID, owned by root or the captured effective UID. A group/other-writable parent requires sticky mode. Existing trusted parents such as `/tmp` may contain protected siblings; the later actual caller still owns fresh-leaf canonicality/disjointness and all grant/model/source checks.

The original admitted UID is retained separately from the four-field external expectation. The store construction binding includes the expectation bytes/tuple, effective UID and admitted parent UID. Every subsequent directory check rechecks the original held/named tuple, canonical parent, UID and sticky policy. Constructor mismatches close the original acquired parent through unchanged shared4543 cleanup; no child is created before the parent gate. Later failures preserve existing attempt-all cleanup and partial evidence; no deletion or uncertain-close retry is added.

`_NpySink`, array conversion, all NPY/manifest formats, readback, serialization and close method bodies are unchanged. All34 core files, producerf85277dc, key_gen742e6 and key schemas remain exact. The actual store/producer entries still deny. This component does not authenticate a grant itself; an actual process must supply expectations from an independently authenticated launch before calling it, and must preserve original callbacks/owners through final retirement.

The copied71 tests and historical READY/provenance documents describe their original checkpoint. They have not been collected or run here and are not a successor test selection. Tests or recording adapters which construct KeyStore must later supply explicit synthetic expected-parent bytes for their own files; the original recording producer is not silently activated or edited. Focused test-source planning/review is a separate next step.

The new writer hash requires a separately reviewed future `REQUIRED_ACTUAL_SOURCES['qwen_key_store.py']` update and new actual generation source map/archive/launch/ModelAdmission consumer-map binding. The old pure28/39 literal2e609 prerequisite remains untouched and correctly rejects this writer. No actual map/grant/readiness claim follows from this source checkpoint. Content model_id, core keygen identity and Qwen166/335 schemas remain unchanged.
