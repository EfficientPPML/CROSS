"""Optional HEMul control reuse: exact public tables and secure helper parity."""
from pathlib import Path
import gc
import sys
import weakref
import pytest
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/'cadathlon/common')]
import jax
from jaxite_word import he_params,ckks_ctx
import hemul,polynomial,ntt_mm
from encrypted_ntt import FIELDS,ScopedNTTSubsets,enable_scoped_ntt_subsets
from encrypted_primitives import CompiledTensorOnly,CompiledRelinearization
from encrypted_compilation import CompiledTensorProduct
from test_scoped_ntt import make_owner
from test_encrypted_tensor_only import ring,server_for,bootstrap_shell,assert_same
from encrypted_refresh import _install_compiled_primitives
from encrypted_polynomial import EncryptedPolynomialEvaluator
jax.config.update('jax_enable_x64',True)
RECORDS=[]


def polynomials(kernel):
    names=('ct_obj','ct_single','ct_no_relin_out','ct_extend','ks_ct_drop_last_extend')
    return [(name,getattr(kernel,name)) for name in names]+[(f'ks_ct_parts[{i}]',x) for i,x in enumerate(kernel.ks_ct_parts)]


def tables_equal(actual,expected):
    checks=0
    for (name,a),(other,b) in zip(polynomials(actual),polynomials(expected)):
        assert name==other and a.moduli==b.moduli
        if name=='ct_no_relin_out':
            # This deliberately supplied finite-field context must not become
            # an NTT wrapper, even with the optional factory installed.
            assert type(a.ntt_ctx) is type(b.ntt_ctx) is expected.ff_context_cls
            continue
        for field in FIELDS:
            np.testing.assert_array_equal(getattr(a.ntt_ctx,field),getattr(b.ntt_ctx,field))
            checks+=1
    return checks


@pytest.mark.parametrize('cd',[1,2])
@pytest.mark.parametrize('skip',[False,True])
def test_every_hemul_ntt_table_is_exact(cd,skip):
    owner=make_owner();provider=ScopedNTTSubsets(owner)
    args=dict(batch=2,r=16,c=16,dnum=2,num_eval_mult=1,original_moduli=owner.q_towers,
              extend_moduli=owner.p_towers,composite_degree=cd)
    expected=hemul._HEMulKernel(**args)
    actual=hemul._HEMulKernel(**args,polynomial_factory=provider.polynomial_factory)
    for kernel in (expected,actual):kernel.control_gen(degree_layout=(16,16),keygen_sizeQ=4,skip_rescale=skip)
    assert expected._polynomial_factory is hemul.Polynomial
    checks=tables_equal(actual,expected)
    assert checks>=30 and provider.stats['builds']>0
    RECORDS.append(dict(kind='six_field_table_parity',composite_degree=cd,skip_rescale=skip,field_checks=checks,stats=dict(provider.stats)))
    provider.close()
    # Retained kernel-owned arrays remain valid after provider retirement.
    assert tables_equal(actual,expected)==checks


def test_close_resets_only_factories_owned_by_this_provider():
    owner=make_owner();provider=ScopedNTTSubsets(owner)
    owner.rotation_polynomial_factory=provider.polynomial_factory
    owner.multiplication_polynomial_factory=provider.polynomial_factory
    provider.close();provider.close()
    assert owner.rotation_polynomial_factory is None and owner.multiplication_polynomial_factory is None
    provider=ScopedNTTSubsets(owner);replacement=lambda *args:None
    owner.rotation_polynomial_factory=replacement
    owner.multiplication_polynomial_factory=provider.polynomial_factory
    provider.close()
    assert owner.rotation_polynomial_factory is replacement and owner.multiplication_polynomial_factory is None


@pytest.mark.parametrize('cd',[1,2])
def test_both_facade_kernels_receive_owner_factory(cd):
    # Arithmetic-only small ring: test constructor routing, not security.
    from types import SimpleNamespace
    import he_ops
    owner=make_owner();provider=ScopedNTTSubsets(owner)
    cache=SimpleNamespace(max_level=(len(owner.q_towers)-1)//cd,composite_degree=cd,
        batch=1,r=16,c=16,dnum=2,q_towers=owner.q_towers,p_towers=owner.p_towers,
        degree_layout=(16,16),perf_test=False,ff_context_cls=he_params.BarrettContext,
        multiplication_polynomial_factory=provider.polynomial_factory,
        rescale_polynomial_factory=provider.polynomial_factory,
        num_q_at_level=lambda level:(level+1)*cd)
    # Key controls only: zero evaluation arrays do not claim encryption.
    cache.get_eval_key=lambda level:tuple(jax.numpy.zeros((2,256,(level+1)*cd+2),dtype='uint32') for _ in range(2))
    operation=he_ops._HEMulAtLevel(cache,0)
    assert operation._hemul._polynomial_factory.__self__ is provider
    assert operation._no_relin_operator._polynomial_factory.__self__ is provider
    assert (operation._hemul is operation._no_relin_operator)==(cd==2)
    provider.close()


def test_secure_helpers_use_scoped_controls_and_release_owners(ring):
    client=ring[0]
    def execute():
        ordinary=server_for(ring,2);server=server_for(ring,2)
        assert server.secret_key is None and server._param_cache.secret_key is None
        assert server._param_cache.multiplication_polynomial_factory is None
        occupied=lambda *args:None
        server._param_cache.multiplication_polynomial_factory=occupied
        with pytest.raises(ValueError,match='already owns'):enable_scoped_ntt_subsets(server)
        assert server._param_cache.rotation_polynomial_factory is None
        assert server._param_cache.multiplication_polynomial_factory is occupied
        server._param_cache.multiplication_polynomial_factory=None
        provider=enable_scoped_ntt_subsets(server,max_entries=16)
        assert server._param_cache.multiplication_polynomial_factory.__self__ is provider
        with pytest.raises(ValueError,match='already owns'):enable_scoped_ntt_subsets(server)
        evaluator=EncryptedPolynomialEvaluator(server)
        tensor=CompiledTensorOnly(server);relin=CompiledRelinearization(server)
        combined=CompiledTensorProduct(server)
        eager=bootstrap_shell(ordinary);compiled=bootstrap_shell(server)
        helpers=_install_compiled_primitives(compiled,server)
        values=np.stack([np.linspace(-.3,.3,client.num_slots),.2*np.sin(np.arange(client.num_slots)/17)])
        left=client.encrypt_slots_batch(values,scale=float(1<<40))
        right=client.encrypt_slots_batch(-.7*values,scale=float(1<<39))
        pt=server.encode_at_level(np.full(client.num_slots,.5),2,scale=float(1<<40))
        left2=server.ptct_mul[2].mul(left,pt)
        right2=server.ptct_mul[2].mul(right,pt)
        for level in (2,1):
            a=left if level==2 else evaluator._lower(left,1)
            b=right if level==2 else evaluator._lower(right,1)
            expected_op=ordinary.he_mul[level-1]
            actual_op=server.he_mul[level-1]
            assert actual_op._hemul._polynomial_factory.__self__ is provider
            fields=tables_equal(actual_op._hemul,expected_op._hemul)
            expected_tensor=expected_op.hemul_no_relin(a,b)
            actual_tensor=actual_op.hemul_no_relin(a,b)
            assert_same(actual_tensor,expected_tensor)
            expected_relin=expected_op.relinearize(expected_tensor)
            assert_same(actual_op.relinearize(actual_tensor),expected_relin)
            expected_mul=expected_op.mul(a,b);actual_mul=actual_op.mul(a,b)
            np.testing.assert_array_equal(actual_mul.polynomial,expected_mul.polynomial)
            assert actual_mul._ckks_scale==expected_mul._ckks_scale
            assert getattr(actual_mul,'_ckks_nsd',None)==getattr(expected_mul,'_ckks_nsd',None)
            err=float(np.max(np.abs(client.decrypt_slots_batch(actual_mul)-values*(-.7*values))))
            assert err<2e-6,err
            # Actual compiled tensor-only helper must build no HEMul controls.
            server.he_mul._instances.clear();before=dict(provider.stats)
            assert_same(tensor.multiply(a,b),expected_tensor)
            assert not server.he_mul._instances and dict(provider.stats)==before
            assert_same(relin.relinearize(expected_tensor),expected_relin)
            assert not server.he_mul._instances
            assert_same(combined.multiply(a,b),expected_relin)
            assert not server.he_mul._instances
            count=relin.compiler.compile_count
            relin.clear();provider.clear();jax.clear_caches()
            assert_same(relin.relinearize(expected_tensor),expected_relin)
            assert relin.compiler.compile_count==count
            RECORDS.append(dict(kind='secure_core_and_compiled_helpers',batch=2,level=level,
                six_field_checks=fields,payload_metadata_exact=True,max_abs_error=err,
                tensor_helper_constructed_no_hemul=True,relinearization_executable_reused=True))
        for level,a,b,truth in [(2,left,right,values*(-.7*values)),
             (1,left2,right,(.5*values)*(-.7*values)),
             (1,left2,right2,(.5*values)*(-.35*values))]:
            expected=eager._he_op_mul(level,a,b)
            actual=compiled._he_op_mul(level,a,b)
            assert_same(actual,expected)
            assert actual._ckks_nsd==2
            err=float(np.max(np.abs(client.decrypt_slots_batch(actual)-truth)))
            assert err<2e-6,err
            RECORDS.append(dict(kind='actual_bootstrap_mul_dispatch',batch=2,level=level,
                input_nsds=[getattr(x,'_ckks_nsd',1) for x in (a,b)],
                payload_metadata_exact=True,max_abs_error=err))
        stats=dict(provider.stats);assert stats['builds']>0
        compiler=relin.compiler
        control_refs=[weakref.ref(x) for x in relin.binding[1].controls]
        refs=[weakref.ref(server),weakref.ref(server._param_cache)]
        for helper in (*helpers,tensor,relin):helper.clear()
        combined.clear()
        provider.close()
        assert server._param_cache.multiplication_polynomial_factory is None
        assert server._param_cache.rotation_polynomial_factory is None
        server.he_mul._instances.clear()
        assert server.he_mul[0]._hemul._polynomial_factory is hemul.Polynomial
        ckks_ctx.evict_context_caches(server);ckks_ctx.evict_context_caches(ordinary)
        return refs,control_refs,compiler,provider,stats
    refs,control_refs,compiler,provider,stats=execute()
    jax.clear_caches();polynomial._POLYNOMIAL_REGISTRY.clear();ntt_mm._barrett_ntt_context_cache.clear();gc.collect()
    assert compiler._executables
    assert all(ref() is None for ref in refs)
    assert all(ref() is None for ref in control_refs)
    RECORDS.append(dict(kind='retirement',owners_and_controls_collected=True,
                        executable_retained=True,stats=stats))


def test_montgomery_hemul_keeps_ordinary_backend():
    from finite_field import MontgomeryContext
    owner=make_owner();provider=ScopedNTTSubsets(owner)
    args=dict(batch=1,r=16,c=16,dnum=2,num_eval_mult=1,original_moduli=owner.q_towers,
              extend_moduli=owner.p_towers,composite_degree=2,finite_field_context=MontgomeryContext)
    expected=hemul._HEMulKernel(**args)
    actual=hemul._HEMulKernel(**args,polynomial_factory=provider.polynomial_factory)
    for kernel in (expected,actual):kernel.control_gen(degree_layout=(16,16),keygen_sizeQ=4,skip_rescale=True)
    assert tables_equal(actual,expected)==36
    assert provider.stats['builds']==0
    for _,value in polynomials(actual):
        assert type(value.ntt_ctx.ff_ctx) is MontgomeryContext
        assert not value.ntt_ctx.ff_ctx.computation_format_is_standard
    provider.close()


@pytest.mark.parametrize('precision,layout',[(64,(16,16)),(32,(8,32))])
def test_factory_unsupported_precision_or_layout_keeps_ordinary_constructor(precision,layout):
    owner=make_owner();provider=ScopedNTTSubsets(owner)
    shapes=dict(batch=1,num_elements=2,degree=256,num_moduli=2,precision=precision,degree_layout=layout)
    parameters=dict(moduli=owner.q_towers[:2],finite_field_context=owner.ff_context_cls)
    expected=polynomial.Polynomial(shapes,parameters)
    actual=provider.polynomial_factory(shapes,parameters)
    assert actual.precision==expected.precision and actual.degree_layout==expected.degree_layout
    for field in FIELDS:np.testing.assert_array_equal(getattr(actual.ntt_ctx,field),getattr(expected.ntt_ctx,field))
    assert provider.stats['builds']==0 and provider.stats['fallback']==1
    provider.close()


def test_installed_factories_do_not_retain_owner_without_close():
    owner=make_owner();provider=ScopedNTTSubsets(owner)
    owner.rotation_polynomial_factory=provider.polynomial_factory
    owner.multiplication_polynomial_factory=provider.polynomial_factory
    ref=weakref.ref(owner)
    del owner
    gc.collect()
    assert ref() is None
    provider.close();provider.close()
