"""Optional rescale-facade NTT reuse: exact controls, arithmetic and ownership."""
from pathlib import Path
import gc,sys,weakref
import numpy as np
import pytest
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/'cadathlon/common')]
import jax
from jaxite_word import he_params,ckks_ctx
import finite_field,polynomial,rescale
from encrypted_ntt import FIELDS,ScopedNTTSubsets,enable_scoped_ntt_subsets
from encrypted_primitives import CompiledRescale
from encrypted_polynomial import EncryptedPolynomialEvaluator
from encrypted_refresh import _install_compiled_primitives
from test_scoped_ntt import make_owner
from test_encrypted_tensor_only import ring,server_for,bootstrap_shell,assert_same
jax.config.update('jax_enable_x64',True)
RECORDS=[]

def controls_equal(actual,expected):
 assert actual.moduli==expected.moduli and actual.output_moduli==expected.output_moduli
 assert actual.composite_degree==expected.composite_degree
 assert actual._lift_reduction_modes==expected._lift_reduction_modes
 for name in ('moduli_threshold_all','gammas_stacked','betas_stacked','lift_add_stacked'):
  np.testing.assert_array_equal(getattr(actual,name),getattr(expected,name))
 count=0
 for a,b in zip(actual.ct_last_list+actual.ct_work_list,expected.ct_last_list+expected.ct_work_list):
  assert a.moduli==b.moduli and a.shape==b.shape
  for name in FIELDS:
   np.testing.assert_array_equal(getattr(a.ntt_ctx,name),getattr(b.ntt_ctx,name));count+=1
 return count

@pytest.mark.parametrize('drop',[1,2,3])
@pytest.mark.parametrize('elements',[2,3])
def test_all_rescale_prefix_and_singleton_tables_exact(drop,elements):
 owner=make_owner();provider=ScopedNTTSubsets(owner)
 args=dict(batch=2,num_elements=elements,moduli=owner.q_towers,r=16,c=16,degree_layout=(16,16))
 expected=rescale._HERescaleKernel(**args);actual=rescale._HERescaleKernel(**args,polynomial_factory=provider.polynomial_factory)
 for kernel in (expected,actual):kernel.control_gen(composite_degree=drop)
 checks=controls_equal(actual,expected);assert checks==12*drop
 shape=dict(batch=2,num_elements=elements,degree=256,precision=32,num_moduli=4,degree_layout=(16,16))
 data=np.random.default_rng(1500+drop+elements).integers(0,2**31,size=(2,elements,16,16,4),dtype='uint32')
 data=data%np.asarray(owner.q_towers,dtype='uint32')
 value=polynomial.Polynomial(shape,{'moduli':owner.q_towers},payload=jax.numpy.asarray(data))
 value._ckks_scale=2.**80;value._ckks_nsd=3
 assert_same(actual.rescale(value),expected.rescale(value))
 provider.close();assert controls_equal(actual,expected)==checks
 RECORDS.append(dict(kind='public_controls_and_raw_arithmetic',drop=drop,elements=elements,six_field_checks=checks,stats=dict(provider.stats)))


def test_nonstandard_reduction_keeps_original_constructor():
 owner=make_owner();provider=ScopedNTTSubsets(owner)
 args=dict(batch=1,num_elements=2,moduli=owner.q_towers,r=16,c=16,finite_field_context=finite_field.MontgomeryContext)
 expected=rescale._HERescaleKernel(**args);actual=rescale._HERescaleKernel(**args,polynomial_factory=provider.polynomial_factory)
 for kernel in (expected,actual):kernel.control_gen(composite_degree=2)
 assert controls_equal(actual,expected)==24
 assert provider.stats['builds']==0
 for value in actual.ct_last_list+actual.ct_work_list:assert value.ntt_ctx.ff_ctx.computation_format_is_standard is False


def test_rescale_owner_slot_is_atomic_and_close_preserves_replacement(ring):
 server=server_for(ring,1);cache=server._param_cache;occupied=lambda *a:None
 cache.rescale_polynomial_factory=occupied
 with pytest.raises(ValueError,match='already owns'):enable_scoped_ntt_subsets(server)
 assert cache.rotation_polynomial_factory is None and cache.multiplication_polynomial_factory is None
 cache.rescale_polynomial_factory=None;provider=enable_scoped_ntt_subsets(server)
 assert cache.rescale_polynomial_factory.__self__ is provider
 cache.rescale_polynomial_factory=occupied;provider.close();provider.close()
 assert cache.rescale_polynomial_factory is occupied
 assert cache.rotation_polynomial_factory is None and cache.multiplication_polynomial_factory is None
 cache.rescale_polynomial_factory=None;ckks_ctx.evict_context_caches(server)


def test_secure_facade_compiled_bootstrap_dispatch_and_lifetime(ring):
 client=ring[0]
 def execute():
  ordinary=server_for(ring,2);server=server_for(ring,2)
  assert server.secret_key is None and server._param_cache.secret_key is None and server.parameters.get('secret_key') is None
  def forbidden(*a,**kw):raise AssertionError('no server encryption/decryption')
  for name in ('encrypt','decrypt','encrypt_slots','decrypt_slots','encrypt_slots_batch','decrypt_slots_batch'):setattr(server,name,forbidden)
  provider=enable_scoped_ntt_subsets(server)
  helper=CompiledRescale(server);evaluator=EncryptedPolynomialEvaluator(server)
  values=np.stack([np.linspace(-.3,.3,client.num_slots),.2*np.sin(np.arange(client.num_slots)/17)])
  fresh=client.encrypt_slots_batch(values,scale=float(1<<40))
  pt=server.encode_at_level(np.full(client.num_slots,.5),2,scale=float(1<<40))
  twice=server.ptct_mul[2].mul(fresh,pt)
  thrice=server.ptct_mul[2].mul(twice,pt)
  snapshots=[(v,v.polynomial,v._ckks_scale,getattr(v,"_ckks_nsd",None),v.moduli[:]) for v in (fresh,twice,thrice)]
  eager=bootstrap_shell(ordinary);compiled=bootstrap_shell(server);helpers=_install_compiled_primitives(compiled,server)
  for source,target,value,truth in [(2,1,twice,.5*values),(1,0,server.he_level_reduce[2,1].level_reduce(twice),.5*values),(2,0,thrice,.25*values)]:
   expected_op=ordinary.he_rescale[source,target];actual_op=server.he_rescale[source,target]
   assert expected_op._he_rescale._polynomial_factory is rescale.Polynomial
   assert actual_op._he_rescale._polynomial_factory.__self__ is provider
   checks=controls_equal(actual_op._he_rescale,expected_op._he_rescale)
   expected=expected_op.rescale(value);actual=actual_op.rescale(value);assert_same(actual,expected)
   error=float(np.max(np.abs(client.decrypt_slots_batch(actual)-truth)));assert error<5e-6,error
   assert_same(helper.rescale(value,source,target),expected)
   count=helper.compiler.compile_count
   helper.clear();server.he_rescale._instances.clear();provider.clear();jax.clear_caches()
   assert_same(helper.rescale(value,source,target),expected);assert helper.compiler.compile_count==count
   for decrement in (False,True):
    assert_same(compiled._he_op_rescale(source,target,value,decrement_nsd=decrement),
                eager._he_op_rescale(source,target,value,decrement_nsd=decrement))
   RECORDS.append(dict(kind='secure_rescale_paths',source=source,target=target,input_nsd=value._ckks_nsd,six_field_checks=checks,max_abs_error=error,raw_payload_and_metadata_exact=True,executable_reused=True))
  for v,payload,scale,nsd,moduli in snapshots:
   assert v.polynomial is payload and v._ckks_scale==scale and getattr(v,"_ckks_nsd",None)==nsd and v.moduli==moduli
  compiler=helper.compiler;control_refs=[weakref.ref(x) for x in helper.binding[1].controls]
  owner_refs=[weakref.ref(server),weakref.ref(server._param_cache)]
  for h in helpers:h.clear()
  helper.clear();provider.close();server.he_rescale._instances.clear()
  assert server._param_cache.rescale_polynomial_factory is None
  assert server.he_rescale[1,0]._he_rescale._polynomial_factory is rescale.Polynomial
  ckks_ctx.evict_context_caches(server);ckks_ctx.evict_context_caches(ordinary)
  return compiler,control_refs,owner_refs,provider
 compiler,controls,owners,provider=execute()
 jax.clear_caches();polynomial._POLYNOMIAL_REGISTRY.clear();he_params.ntt_mm._barrett_ntt_context_cache.clear();gc.collect()
 assert all(r() is None for r in controls)
 assert all(r() is None for r in owners)
 assert compiler._executables and provider.live_entries==0
 RECORDS.append(dict(kind='lifetime',retired_controls_collected=True,retired_owners_collected=True,executable_cache_retained=True))
