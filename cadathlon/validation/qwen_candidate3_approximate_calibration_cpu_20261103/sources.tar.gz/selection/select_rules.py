"""Uniform public candidate3 selection; no tokenizer, model, JAX or HE use."""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal
from collections import Counter
import copy,hashlib,io,json,math,os,sys,tarfile,time
import numpy as np
import certificate,numeric
from old_selection import depths
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
canonical=lambda x:hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def rule(domain,degree):
    c=numeric.coefficients('inverse_sqrt',domain,degree).tolist()
    result=dict(kind='inverse_sqrt',method='polynomial',domain=list(domain),degree=degree,strategy='chebyshev',chebyshev_coefficients=c,evaluation_coefficients=list(c))
    result['depth']=numeric.polynomial_depth(result);return result


def grid_check(candidate):
    a,b=candidate['domain'];x=np.unique(np.concatenate((np.linspace(a,b,2049),np.geomspace(a,b,2049))))
    with np.errstate(all='ignore'):
        value=numeric.polynomial(x,candidate);truth=1/np.sqrt(x);ratio=value/truth-1
        t=x*(2/(b-a))-(b+a)/(b-a);independent=np.polynomial.chebyshev.chebval(t,candidate['chebyshev_coefficients'])
        finite=bool(np.isfinite(value).all() and np.isfinite(ratio).all() and np.isfinite(independent).all())
        error=float(np.max(abs(ratio))) if finite else None
        agreement=float(np.max(abs(value-independent))) if finite else None
    return dict(points=len(x),finite=finite,max_relative_error=error,clenshaw_max_abs_difference=agreement,passed=finite and error<=1e-6)


def select_one(domain,fallback,ladder):
    attempts=[]
    for degree in ladder:
        started=time.monotonic();candidate=rule(domain,degree);cert=certificate.certify(candidate);grid=grid_check(candidate)
        selected=cert['certified'] and grid['passed']
        attempts.append(dict(degree=degree,depth=candidate['depth'],coefficients=candidate['evaluation_coefficients'],
            uniform_certificate={k:v for k,v in cert.items() if k not in ('delta','relative','extent','H_L1','chebyshev_extent_envelope')},
            binary64_diagnostic=grid,selected=selected,elapsed_s=time.monotonic()-started))
        if selected:return candidate,cert,grid,attempts
    if not fallback['binary64_diagnostic']['passed'] or not fallback['certificate']['verified']:raise ValueError('certified fallback absent')
    return dict(kind='inverse_sqrt',method='newton',**fallback['rule']),dict(kind='rounded_first_affine_newton',**fallback['certificate'],relative=fallback['rule']['final_relative_error_bound']),fallback['binary64_diagnostic'],attempts


def quantities(candidate):
    if candidate['method']=='newton':
        n=candidate['iterations'];return dict(inverse_depth=4*n-3,complete_rms_depth=4*n+1,ciphertext_products_inverse=3*(n-1),weighted_affines_inverse=n,from_capacity25_final_level=25-(4*n+1),two_level_reserve_from25=False)
    d=candidate['degree'];N=131072;variance_level=23
    term_levels=[variance_level-1-2*(n-1).bit_length() for n in range(1,d+1)]
    return dict(inverse_depth=candidate['depth'],complete_rms_depth=candidate['depth']+4,ciphertext_products_inverse=d-1,weighted_affines_inverse=d+1,
        from_capacity25_final_level=25-candidate['depth']-4,two_level_reserve_from25=25-candidate['depth']-4>=2,
        retained_term_payload_bytes_at_variance23=sum(2*(2*(level+1))*N*4 for level in term_levels),
        retained_term_payload_scope='Sum of all actual cached balanced basis payloads atCD2/N131072/varianceL23, excluding keys, controls, temporaries and result; not peak/device memory proof.')


def collect_sources():
    return [ROOT/n for n in ('protocol.json','select_rules.py','run_public.py','certificate.py','test_certificate.py','test_selection.py','numeric.py','old_selection.py')]+sorted((ROOT/'inputs').glob('*'))


def main(output):
    output=Path(output);output.mkdir(exist_ok=False);start=time.monotonic();primary=None
    paths=collect_sources();before={str(p.relative_to(ROOT)):sha(p) for p in paths}
    report=dict(passed=False,complete=False,model_evaluated=False,HE_executed=False,heldout_or_fresh56_read=False,source_hashes_before=before)
    (output/'report.json').write_text(json.dumps(report)+'\n')
    with tarfile.open(output/'sources.tar.gz','w:gz') as tar:
        for p in paths:raw=p.read_bytes();i=tarfile.TarInfo(str(p.relative_to(ROOT)));i.size=len(raw);tar.addfile(i,io.BytesIO(raw))
    assessments={};manifest=None
    try:
        protocol=json.loads((ROOT/'protocol.json').read_text())
        for n,h in protocol['inputs'].items():
            if sha(ROOT/n)!=h:raise ValueError('protocol input identity differs')
        base=json.loads((ROOT/'inputs/candidate2_manifest.json').read_text());fallback=json.loads((ROOT/'inputs/factor4_fallback_report.json').read_text())
        multipliers=json.loads((ROOT/'inputs/norm_multipliers.json').read_text());manifest=copy.deepcopy(base)
        names=sorted(k for k in base['nonlinear'] if k.endswith('.inverse_sqrt'));assert len(names)==113
        for name in names:
            chosen,cert,grid,attempts=select_one(fallback['sites'][name]['expanded_domain'],fallback['sites'][name],protocol['degree_ladder'])
            manifest['nonlinear'][name]=chosen
            assessments[name]=dict(domain=chosen['domain'],selected_method=chosen['method'],selected_degree=chosen.get('degree'),selected_iterations=chosen.get('iterations'),
                certificate=cert,binary64_diagnostic=grid,attempts=attempts,counts=quantities(chosen))
            print(json.dumps(dict(site=name,method=chosen['method'],degree=chosen.get('degree'),iterations=chosen.get('iterations'),depth=chosen['depth'])),flush=True)
        protected=lambda m:({k:v for k,v in m['nonlinear'].items() if not k.endswith('.inverse_sqrt')},{k:m[k] for k in ('softmax','exp','initial_reciprocal','reciprocal_by_keys')})
        assert protected(manifest)==protected(base)
        silu={}
        for i in range(28):
            name=f'{i}.post.inverse_sqrt';cert=assessments[name]['certificate']
            delta=certificate.unpack(cert['relative']) if assessments[name]['selected_method']=='polynomial' else F(Decimal(cert['relative']))
            bound=F(9,8)*(1+delta)*F(multipliers[str(i)]['native_gate_upper']);radius=-(-bound.numerator//bound.denominator);domain=base['nonlinear'][f'{i}.silu']['domain']
            silu[str(i)]=dict(required_conditional_radius=radius,unchanged_domain=domain,covered=domain[0]<=-radius and domain[1]>=radius)
        complete=all(x['covered'] for x in silu.values())
        manifest.update(schema='qwen-uniform-normalization-candidate-v3',candidate_index=3,parent_manifest_sha256=sha(ROOT/'inputs/candidate2_manifest.json'),
            source_input_sha256=before,selection_protocol_sha256=sha(ROOT/'protocol.json'),all_norm_sites_supported=complete,
            selection='Uniform factor4 normalization domains; first balanced degree16/32/64/128/256/512 passing exact map/coefficient1e-6 certificate plus fixed binary64 grids, else fixed certified staticNewton fallback. All28SiLU/softmaxrules unchanged; no heldout/fresh56/model input reads.',
            error_scope='Ideal-real uniform normalization certificates including public coefficient/map rounding. Subsequent binary64, CKKS and refresh error excluded; domains remain conditional.',
            depth_by_sequence={str(S):depths(manifest,S) for S in (8,16,19,32)})
        for name,value in [('manifest.json',manifest),('assessments.json',assessments)]: (output/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
        report.update(passed=complete,complete=True,normalization_count=113,protected_other_rules_unchanged=True,
            selected_counts=dict(Counter('balanced'+str(x['selected_degree']) if x['selected_method']=='polynomial' else 'newton' for x in assessments.values())),
            complete_rms_depth_range=[min(x['counts']['complete_rms_depth'] for x in assessments.values()),max(x['counts']['complete_rms_depth'] for x in assessments.values())],
            sites_without_two_level_reserve_from25=[name for name,x in assessments.items() if not x['counts']['two_level_reserve_from25']],
            largest_binary64_grid_relative_error=max(x['binary64_diagnostic']['max_relative_error'] for x in assessments.values()),
            abstract_depths={s:x['final_depth'] for s,x in manifest['depth_by_sequence'].items()},silu_radius_recheck=silu,
            manifest_sha256=sha(output/'manifest.json'),assessments_sha256=sha(output/'assessments.json'),
            original_candidate2_nine_stops_remain_failures=True,calibration_or_validation_not_executed=True)
    except BaseException as error:
        primary=error;report['error']=dict(type=type(error).__name__,message=str(error))
        (output/'partial_assessments.json').write_text(json.dumps(assessments,indent=2,allow_nan=False)+'\n')
    finally:
        after={str(p.relative_to(ROOT)):sha(p) for p in paths}
        with tarfile.open(output/'sources.tar.gz') as tar:
            ms=tar.getmembers();verified=len(ms)==len(before)==len({m.name for m in ms}) and {m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in ms}==before
        report.update(source_hashes_after=after,source_files_unchanged=before==after,source_archive_verified=verified,source_archive_sha256=sha(output/'sources.tar.gz'),
            elapsed_s=time.monotonic()-start,cpu_affinity=sorted(os.sched_getaffinity(0)),numpy_version=np.__version__,python=sys.version)
        report['passed']=report['passed'] and before==after and verified
        (output/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    if primary is not None:raise primary
    print(json.dumps({k:report[k] for k in ('passed','selected_counts','complete_rms_depth_range','abstract_depths','elapsed_s','manifest_sha256')}));return 0 if report['passed'] else 1

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);raise SystemExit(main(p.parse_args().output))
