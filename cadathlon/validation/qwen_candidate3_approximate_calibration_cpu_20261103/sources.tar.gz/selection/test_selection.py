from fractions import Fraction as F
from types import SimpleNamespace
import json
import numpy as np
import pytest
import select_rules as s


def test_first_uniform_degree_with_both_gates_is_selected(monkeypatch):
    seen=[]
    monkeypatch.setattr(s,'rule',lambda domain,d:dict(degree=d,depth=d,evaluation_coefficients=[1.]))
    def certify(rule):seen.append(rule['degree']);return {'certified':rule['degree']>=32}
    monkeypatch.setattr(s.certificate,'certify',certify)
    monkeypatch.setattr(s,'grid_check',lambda rule:dict(passed=rule['degree']>=64))
    chosen,_,_,attempts=s.select_one([1.,2.],{},[16,32,64,128])
    assert seen==[16,32,64] and chosen['degree']==64 and [a['selected'] for a in attempts]==[False,False,True]


def test_fixed_certified_fallback_after_all_unsuccessful_degrees(monkeypatch):
    monkeypatch.setattr(s,'rule',lambda domain,d:dict(degree=d,depth=d,evaluation_coefficients=[1.]))
    monkeypatch.setattr(s.certificate,'certify',lambda rule:dict(certified=False))
    monkeypatch.setattr(s,'grid_check',lambda rule:dict(passed=True))
    f={'binary64_diagnostic':{'passed':True},'certificate':{'verified':True},'rule':{'domain':[1.,2.],'iterations':9,'final_relative_error_bound':'1e-7'}}
    chosen,_,_,a=s.select_one([1.,2.],f,[16,32]);assert chosen['method']=='newton' and chosen['iterations']==9 and len(a)==2

@pytest.mark.parametrize('d,depth,final',((16,10,11),(32,12,9),(64,14,7),(128,16,5),(256,18,3),(512,20,1)))
def test_polynomial_depth_retention_and_two_level_reserve(d,depth,final):
    rule=s.rule([.5,1.5],d);q=s.quantities(rule)
    assert rule['depth']==depth and q['from_capacity25_final_level']==final and q['two_level_reserve_from25']==(final>=2)
    assert q['ciphertext_products_inverse']==d-1 and q['weighted_affines_inverse']==d+1
    assert q['retained_term_payload_bytes_at_variance23']>0


def test_policy_same_all_sites_and_no_hidden_input_sources():
    p=json.loads((s.ROOT/'protocol.json').read_text());assert p['degree_ladder']==[16,32,64,128,256,512]
    assert p['uniform_relative_target']==1e-6 and all('fresh' not in n and 'validation' not in n for n in p['inputs'])
    assert set(p['inputs'])=={'inputs/candidate2_manifest.json','inputs/qwen_config.json','inputs/norm_multipliers.json','inputs/factor4_fallback_report.json','numeric.py','old_selection.py'}
