"""Source-bound tests plus public uniform selection; no model or HE worker."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys,tarfile,time
import select_rules
ROOT=Path(__file__).resolve().parent

def main(output):
    output=Path(output);output.mkdir(exist_ok=False);start=time.monotonic();paths=select_rules.collect_sources()
    before={str(p.relative_to(ROOT)):select_rules.sha(p) for p in paths};report=dict(passed=False,model_evaluated=False,HE_executed=False,source_hashes_before=before);primary=None
    (output/'report.json').write_text(json.dumps(report)+'\n')
    with tarfile.open(output/'sources.tar.gz','w:gz') as tar:
        for p in paths:tar.add(p,arcname=str(p.relative_to(ROOT)),recursive=False)
    try:
        for name,command in [('tests',[sys.executable,'-m','pytest','-q','test_certificate.py','test_selection.py','--junitxml='+str(output/'tests.xml')]),
                ('selection',[sys.executable,str(ROOT/'select_rules.py'),'--output',str(output/'candidate-v3')])]:
            with (output/(name+'.log')).open('wb') as log:r=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
            if r.returncode:raise ValueError(name+' failed')
        import xml.etree.ElementTree as ET
        selection=json.loads((output/'candidate-v3/report.json').read_text())
        if not selection['passed'] or selection['source_hashes_before']!=before or selection['source_hashes_after']!=before:raise ValueError('selected source closure differs')
        report.update(passed=True,tests={k:sum(int(x.attrib.get(k,0)) for x in ET.parse(output/'tests.xml').getroot()) for k in ('tests','failures','errors','skipped')},selection_report_sha256=select_rules.sha(output/'candidate-v3/report.json'),manifest_sha256=selection['manifest_sha256'])
    except BaseException as error:primary=error;report['error']=dict(type=type(error).__name__,message=str(error))
    finally:
        after={str(p.relative_to(ROOT)):select_rules.sha(p) for p in paths}
        with tarfile.open(output/'sources.tar.gz') as tar:
            ms=tar.getmembers();verified=len(ms)==len(before)==len({m.name for m in ms}) and {m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in ms}==before
        report.update(source_hashes_after=after,source_files_unchanged=before==after,source_archive_verified=verified,source_archive_sha256=select_rules.sha(output/'sources.tar.gz'),elapsed_s=time.monotonic()-start,cpu_affinity=sorted(os.sched_getaffinity(0)))
        report['passed']=report['passed'] and verified and before==after
        (output/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    if primary is not None:raise primary
    print(json.dumps(report));return 0 if report['passed'] else 1

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);raise SystemExit(main(p.parse_args().output.absolute()))
