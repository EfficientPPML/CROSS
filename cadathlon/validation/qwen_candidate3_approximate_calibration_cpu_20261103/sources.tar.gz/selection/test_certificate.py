from fractions import Fraction as F
import numpy as np
import pytest
import certificate,numeric

def clenshaw(c,x):
    b1=b2=F(0)
    for a in reversed(c[1:]):b1,b2=a+2*x*b1-b2,b1
    return c[0]+x*b1-b2

@pytest.mark.parametrize('c',([.25,-.5,.125],[1.1,.3,0.,-.7,.02],[.01]*9))
def test_exact_product_against_independent_clenshaw(c):
    c=list(map(F,c));A=F(2/3.1);B=F(-4.3/3.1);h=certificate.residual(c,A,B)
    for x in map(F,(-1.,-.6,0.,.125,.9,1.)):
        assert clenshaw(h,x)==((x-B)/A)*clenshaw(c,x)**2-1

@pytest.mark.parametrize('n',(0,1,2,16,128))
def test_exact_extent_encloses_each_lower_degree(n):
    x=F(1)+F(1,2**50);bound=certificate.T(n,x)
    assert all(abs(certificate.T(i,x))<=bound for i in range(n+1))

def test_squared_residual_cannot_certify_negative_polynomial():
    r={'domain':[.9,1.1],'strategy':'chebyshev','evaluation_coefficients':[-1.]}
    out=certificate.certify(r,F(1));assert not out['certified'] and not out['positive_at_mapped_zero']

@pytest.mark.parametrize('d',(16,32,64,128,256,512))
def test_analytic_synthetic_certificate_and_circuit(d):
    domain=[.5,1.5];c=numeric.coefficients('inverse_sqrt',domain,d);r={'domain':domain,'strategy':'chebyshev','evaluation_coefficients':c.tolist()}
    result=certificate.certify(r);assert result['certified']
    x=np.linspace(*domain,2049);assert np.max(abs(numeric.polynomial(x,r)*np.sqrt(x)-1))<1e-6
    assert certificate.unpack(result['relative'])<=F(1,10**6)

def test_rounded_map_extension_is_recorded_and_included():
    for domain in ([.1,2.7],[.03,3.14],[.011,1.97],[1e-4,3.]):
        c=numeric.coefficients('inverse_sqrt',domain,16);r={'domain':domain,'strategy':'chebyshev','evaluation_coefficients':c.tolist()}
        result=certificate.certify(r)
        if result['endpoint_extension']:
            assert certificate.unpack(result['chebyshev_extent_envelope'])>1
            assert certificate.unpack(result['delta'])>=certificate.unpack(result['H_L1']);return
    raise AssertionError('explicit binary64 extension fixture missing')

@pytest.mark.parametrize('x',(F(7,6),F(1)+F(1,2**50),F(11,8)))
def test_common_denominator_T_matches_independent_fraction_recurrence(x):
    before,current=F(1),x
    assert certificate.T(0,x)==before and certificate.T(1,x)==current
    for n in range(2,65):
        before,current=current,2*x*current-before
        assert certificate.T(n,x)==current
