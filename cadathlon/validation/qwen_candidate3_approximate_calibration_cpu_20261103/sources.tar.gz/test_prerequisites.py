from pathlib import Path
import hashlib,io,json,os,tarfile
import pytest
import candidate_gate as gate
P=Path(__file__).resolve().parent;REQ=json.loads((P/'collector_requirement.json').read_text())

@pytest.fixture
def copied(tmp_path):
    names={'collector_requirement.json','candidate-v3/manifest.json'}
    for group in ('selection_artifact_sha256','calibration_input_sha256','runtime_dependency_sha256'):names.update(REQ[group])
    names.update('selection/'+n for n in REQ['selection_input_sha256'])
    for name in names:
        target=tmp_path/name;target.parent.mkdir(parents=True,exist_ok=True);os.link(P/name,target)
    return tmp_path

def replace(path,data):path.unlink();path.write_bytes(data)

def rebind(root,monkeypatch,fn):
    r=json.loads((root/'collector_requirement.json').read_text());fn(r);replace(root/'collector_requirement.json',json.dumps(r).encode());monkeypatch.setattr(gate,'EXPECTED_REQUIREMENT',gate.sha(root/'collector_requirement.json'))

def test_exact_public_selection_and_original_calibration_only():
    r=gate.verify(P);assert r['passed'] and r['selection_archive_members']==12 and r['runtime']['cores']==[124,125,126,127]
    assert len(r['verified']['calibration_input_sha256'])==5
    assert all('fresh' not in n and 'heldout' not in n for group in r['verified'].values() for n in group)

@pytest.mark.parametrize('name',[*('selection/'+n for n in REQ['selection_input_sha256']),*REQ['calibration_input_sha256'],*REQ['runtime_dependency_sha256']])
def test_each_public_selection_calibration_or_runtime_input_is_bound(copied,name):
    replace(copied/name,(copied/name).read_bytes()+b'\n')
    with pytest.raises(ValueError,match='Frozen .* mismatch'):gate.verify(copied)

@pytest.mark.parametrize('field',('passed','complete','protected_other_rules_unchanged','source_files_unchanged','source_archive_verified','calibration_or_validation_not_executed'))
def test_failed_selection_remains_rejected_if_report_digest_rebound(copied,monkeypatch,field):
    f=copied/'candidate-v3/report.json';r=json.loads(f.read_text());r[field]=False;replace(f,json.dumps(r).encode())
    rebind(copied,monkeypatch,lambda q:q['selection_artifact_sha256'].update({'candidate-v3/report.json':gate.sha(f)}))
    with pytest.raises(ValueError,match='incomplete'):gate.verify(copied)

def test_requirement_cannot_self_authorize_new_inputs(copied):
    f=copied/'collector_requirement.json';r=json.loads(f.read_text());r['runtime']['cores']=[140,141,142,143];replace(f,json.dumps(r).encode())
    with pytest.raises(ValueError,match='requirement mismatch'):gate.verify(copied)

@pytest.mark.parametrize('kind',('duplicate','missing','extra','nonregular','changed'))
def test_unique_exact_archive_members(tmp_path,kind):
    p=tmp_path/'archive.tar.gz';items=[('a',b'a'),('b',b'b')]
    if kind=='duplicate':items.append(('a',b'a'))
    if kind=='missing':items.pop()
    if kind=='extra':items.append(('c',b'c'))
    if kind=='changed':items[0]=('a',b'wrong')
    with tarfile.open(p,'w:gz') as t:
        for name,data in items:
            m=tarfile.TarInfo(name);m.size=len(data)
            if kind=='nonregular' and name=='a':m.type=tarfile.SYMTYPE;m.linkname='b';m.size=0
            t.addfile(m,io.BytesIO(data))
    with pytest.raises(ValueError):gate.verify_archive(p,{n:hashlib.sha256(b).hexdigest() for n,b in [('a',b'a'),('b',b'b')]})
