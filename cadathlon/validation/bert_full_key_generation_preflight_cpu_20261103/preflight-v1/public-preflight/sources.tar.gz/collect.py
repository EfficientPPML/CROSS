"""Prepare or explicitly execute one complete130-key first-handler proof.

Default is public preflight only. Real key generation requires --execute and a
separate root launch decision. Healthy work has no timeout. No key payload is
copied into evidence; successful keys remain in the explicit owned workspace.
"""
from pathlib import Path
import argparse,hashlib,importlib.util,io,json,os,shutil,sys,tarfile,time,uuid
HERE=Path(__file__).resolve().parent
STAGE=Path('/tmp/bert-full-model-file-stages-20261103')
TRANSPORT=Path('/tmp/bert-full-model-transport-20261103')
REPO=Path('/home/jianming_gatech/CROSS')
sys.path.insert(0,str(REPO/'cadathlon/validation'))
import check_transformer_suite as process
LOCAL=('client_keys.py','client_inputs.py','file_stages.py','file_stage_contract.py','file_stage_io.py','request_lifecycle.py',
       'key_contexts.py','response_scale.py','server_public_model.py','full_model_engine.py','server_tensor_pins.json',
       'server_inputs/p60_profile_and_refresh.json','server_inputs/candidate_manifest.json','server_inputs/twelve_layer_plan.json')

def sources():
    paths={n:HERE/n for n in ('worker.py','collect.py','test_collector.py','preflight.py')}
    paths.update({'stage/'+n:STAGE/n for n in LOCAL})
    paths.update({'stage/'+n:TRANSPORT/n for n in ('transport.py','transport_contract.py','bundle_io.py','p60_profile_and_refresh.json')})
    paths['check_transformer_suite.py']=Path(process.__file__)
    for p in sorted((REPO/'jaxite_word').rglob('*.py')):
        if not p.name.endswith('_test.py') and not p.name.startswith('test_'):paths[str(p.relative_to(REPO))]=p
    return {n:p.read_bytes() for n,p in paths.items()}
def hashes(raw):return {n:hashlib.sha256(b).hexdigest() for n,b in raw.items()}
def write(path,value):process.write_json(path,value)
def archive(path,raw):
    with tarfile.open(path,'w:gz') as tar:
        for name,data in raw.items():info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data))
def check_archive(path,expected):
    with tarfile.open(path) as tar:
        rows=tar.getmembers();return len(rows)==len(expected)==len({m.name for m in rows}) and all(m.isfile() for m in rows) and {m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in rows}==expected

def choose_parent(candidates,required):
    observations=[];selected=None
    for candidate in candidates:
        path=Path(candidate)
        try:
            status=path.lstat()
            import stat
            if not stat.S_ISDIR(status.st_mode):raise ValueError('real workspace parent directory required')
            usage=shutil.disk_usage(path);row=dict(path=str(path),device=status.st_dev,total_bytes=usage.total,free_bytes=usage.free)
            if selected is None and usage.free>=required:selected=path
        except (OSError,ValueError) as e:row=dict(path=str(path),error=repr(e))
        observations.append(row)
    if selected is None:raise OSError('no measured filesystem has enough free space for the complete key store: '+repr(observations))
    return selected,observations

def load_keys(source):
    spec=importlib.util.spec_from_file_location('collected_client_keys',source);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def run(output,*,execute=False,workspace_parents=('/dev/shm','/tmp')):
    output=Path(output);output.mkdir(parents=True,exist_ok=False);started=time.monotonic();primary=None;cleanup_error=None;owner=None;active=False;record=None;before={};raw={}
    report=dict(passed=False,execute=execute,scope='First handler only: complete130-key fixed commonp60 store; no encryption/model/server inference.',
                actual_key_generation=False,workspace_retained=False,all_processes_reaped=True,wrapper_pid=os.getpid(),cpu_affinity=sorted(os.sched_getaffinity(0)))
    def attempt(label,fn):
        nonlocal cleanup_error
        try:return fn()
        except BaseException as e:
            report.setdefault('cleanup_errors',[]).append(dict(operation=label,type=type(e).__name__,message=str(e)))
            if primary is not None:primary.add_note(label+': '+repr(e))
            elif cleanup_error is None:cleanup_error=e
            elif not isinstance(e,Exception) and isinstance(cleanup_error,Exception):e.add_note('earlier cleanup '+repr(cleanup_error));cleanup_error=e
            else:cleanup_error.add_note(label+': '+repr(e))
    try:
        write(output/'report.json',report)
        if type(execute)is not bool:raise TypeError('explicit execute bool required')
        if os.environ.get('JAX_PLATFORMS')!='cpu':raise ValueError('explicit CPU preflight/execution required')
        raw=sources();before=hashes(raw);archive(output/'sources.tar.gz',raw)
        if not check_archive(output/'sources.tar.gz',before):raise ValueError('startup archive readback differs')
        execution=output/'execution_source';execution.mkdir()
        for name,data in raw.items():path=execution/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
        execution_hashes={name:hashlib.sha256((execution/name).read_bytes()).hexdigest() for name in before}
        if execution_hashes!=before:raise ValueError('isolated execution source readback differs')
        write(output/'source_manifest.json',before)
        report['isolated_execution_source_hashes']=execution_hashes
        keys=load_keys(execution/'stage/client_keys.py')
        profile=raw['stage/server_inputs/p60_profile_and_refresh.json'];plan=raw['stage/server_inputs/twelve_layer_plan.json']
        p,rotations=keys.public_contract(profile,plan);security=keys._security_check(p);resource=keys.resources(p,rotations)
        parent,observations=choose_parent(workspace_parents,resource['public_required_bytes']+resource['private_required_bytes'])
        owner=keys._OwnedDirectory(parent/('cross-full-bert-keys-'+uuid.uuid4().hex))
        _,_,preflight=keys.preflight(owner.path/'public_keys',owner.path/'client_private',profile_bytes=profile,plan_bytes=plan)
        report.update(source_hashes_start=before,source_archive_sha256=process.sha256(output/'sources.tar.gz'),security=security,resource=resource,
            workspace_parent_observations=observations,workspace=str(owner.path),workspace_identity=list(owner.identity),preflight=preflight,
            software=process.software_versions(),environment={k:os.environ.get(k) for k in ('JAX_PLATFORMS','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')})
        write(output/'report.json',report)
        if execute:
            directory=output/'worker';directory.mkdir();active=True
            command=[sys.executable,str(execution/'worker.py'),'--workspace',str(owner.path),'--output',str(directory/'worker_report.json'),
                     '--source-manifest',str(output/'source_manifest.json')]
            previous=process.child_environment_overrides
            process.child_environment_overrides=lambda:{'JAX_PLATFORMS':'cpu','PYTHONUNBUFFERED':'1'}
            try:record=process.run_case(command,directory,timeout=None,cleanup_grace_s=120.)
            finally:process.child_environment_overrides=previous
            active=False;report['worker_process']=record
            if (not isinstance(record,dict) or record.get('returncode')!=0 or record.get('error') or record.get('process_reaped')is not True
                    or record.get('public_key_store_removed')is not True or record.get('owned_directory_handle_closed')is not True):raise ValueError('key-generation worker/process cleanup failed')
            worker=json.loads((directory/'worker_report.json').read_text());result=record.get('result',{})
            if (type(worker)is not dict or worker.get('passed')is not True or worker.get('source_hashes_start')!=before or worker.get('source_hashes_end')!=before
                    or worker.get('source_files_unchanged')is not True or worker.get('actual_key_generation_completed')is not True
                    or result.get('passed')is not True or result.get('worker_report_sha256')!=process.sha256(directory/'worker_report.json')):raise ValueError('strict worker source/result binding differs')
            public=worker['public_manifest'];private=worker['private_manifest']
            if public['context_id']!=private['context_id'] or public['rotations']!=list(rotations):raise ValueError('worker key inventory identity differs')
            for name,value in (('public_manifest.json',public),('private_manifest.json',private)):write(output/name,value)
            report.update(actual_key_generation=True,worker_elapsed_s=worker['elapsed_s'],context_id=public['context_id'])
        report['operation_complete']=True
    except BaseException as e:primary=e;report.update(error=dict(type=type(e).__name__,message=str(e)))
    finally:
        if active:
            try:
                record=json.loads((output/'worker/process.json').read_text())
                if type(record)is not dict or record.get('process_reaped')is not True:raise ValueError('active worker cleanup unknown')
                report['worker_process']=record
            except BaseException as e:
                report['worker_process']=dict(process_reaped=False,error='active worker evidence missing/corrupt',evidence_error=repr(e))
                if primary is None:primary=e
                else:primary.add_note('active worker evidence: '+repr(e))
        report['all_processes_reaped']=not active if record is None else type(record)is dict and record.get('process_reaped')is True
        after=attempt('source readback',lambda:hashes(sources()));verified=attempt('archive readback',lambda:check_archive(output/'sources.tar.gz',before)) if before else False
        report.update(source_hashes_end=after,source_files_unchanged=bool(before) and before==after,source_archive_verified=verified is True)
        retain=bool(execute and report.get('operation_complete') and primary is None and cleanup_error is None and before==after and verified and report['all_processes_reaped'])
        if owner is not None:
            if retain:
                if attempt('retained workspace identity',owner.check) is None and cleanup_error is None and primary is None:report['workspace_retained']=True
            elif report['all_processes_reaped']:attempt('owned workspace removal',owner.remove)
            else:report['workspace_retained']=True;report['workspace_retention_reason']='owned process cleanup unknown; files retained fail-closed'
            attempt('owned workspace handle close',owner.close)
        report['cleanup_completed']=not report.get('cleanup_errors') and report['all_processes_reaped']
        report['passed']=bool(report.get('operation_complete') and primary is None and cleanup_error is None and report['source_files_unchanged'] and verified and report['cleanup_completed'] and (not execute or report['workspace_retained']))
        report['elapsed_s']=time.monotonic()-started
        try:write(output/'report.json',report)
        except BaseException as e:
            keep=primary if primary is not None else cleanup_error
            if keep is None:raise
            keep.add_note('terminal publication: '+repr(e))
        if primary is not None:raise primary
        if cleanup_error is not None:raise cleanup_error
    print(json.dumps({k:report[k] for k in ('passed','execute','actual_key_generation','workspace_retained','elapsed_s')}));return report
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--execute',action='store_true');parser.add_argument('--workspace-parent',type=Path,action='append');args=parser.parse_args()
    with process.termination_signals():
        result=run(args.output,execute=args.execute,workspace_parents=args.workspace_parent or ('/dev/shm','/tmp'));raise SystemExit(0 if result['passed'] else 1)
