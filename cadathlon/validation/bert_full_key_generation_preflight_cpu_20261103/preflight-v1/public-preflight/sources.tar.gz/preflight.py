"""Source-bound collector tests plus public resource gate; never execute keys."""
from pathlib import Path
import argparse,json,os,subprocess,sys,time
import collect

def run(output):
    output.mkdir(exist_ok=False);started=time.monotonic();primary=None;before={};report=dict(passed=False,actual_key_generation=False)
    try:
        collect.write(output/'report.json',report);raw=collect.sources();before=collect.hashes(raw);collect.archive(output/'sources.tar.gz',raw)
        if not collect.check_archive(output/'sources.tar.gz',before):raise ValueError('preflight source archive differs')
        with (output/'tests.log').open('wb') as log:
            result=subprocess.run([sys.executable,'-m','pytest','-q',str(collect.HERE/'test_collector.py'),'--junitxml='+str(output/'tests.xml')],stdout=log,stderr=subprocess.STDOUT,cwd=collect.HERE)
        if result.returncode:raise ValueError('collector tests failed')
        public=collect.run(output/'public-preflight',execute=False)
        if public.get('actual_key_generation')is not False or not public['passed']:raise ValueError('public preflight failed')
        import xml.etree.ElementTree as ET
        report.update(tests={k:sum(int(x.attrib.get(k,0)) for x in ET.parse(output/'tests.xml').getroot()) for k in ('tests','failures','errors','skipped')},
                      public_preflight_sha256=collect.process.sha256(output/'public-preflight/report.json'),passed=True)
    except BaseException as e:primary=e;report.update(passed=False,error=dict(type=type(e).__name__,message=str(e)))
    finally:
        try:
            after=collect.hashes(collect.sources());verified=bool(before) and collect.check_archive(output/'sources.tar.gz',before)
            report.update(source_hashes_before=before,source_hashes_after=after,source_archive_sha256=collect.process.sha256(output/'sources.tar.gz') if before else None,
                          source_files_unchanged=bool(before) and before==after,source_archive_verified=verified,elapsed_s=time.monotonic()-started,cpu_affinity=sorted(os.sched_getaffinity(0)))
            report['passed']=bool(report['passed'] and verified and before==after);collect.write(output/'report.json',report)
        except BaseException as e:
            if primary is None:raise
            primary.add_note('preflight final publication: '+repr(e))
        if primary is not None:raise primary
    print(json.dumps({k:report[k] for k in ('passed','tests','elapsed_s','source_archive_sha256')}));return 0 if report['passed'] else 1
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    with collect.process.termination_signals():raise SystemExit(run(a.output))
