"""Mocked subprocess/retention transactions, no encrypted work."""
from pathlib import Path
from types import SimpleNamespace as NS
import importlib.util,json,sys
import pytest
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
spec=importlib.util.spec_from_file_location('stage4_test_collect',HERE/'collect.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)

@pytest.fixture
def case(tmp_path,monkeypatch):
    monkeypatch.setenv('JAX_PLATFORMS','cpu');events=[];fail={};owners=[]
    dirs={n:tmp_path/n for n in ('keys','model','io','ke','me','se')}
    for p in dirs.values():p.mkdir()
    (dirs['io']/'upload').mkdir();(dirs['keys']/'private-sentinel').write_bytes(b'untouched')
    inputs=dict(upload=dirs['io']/'upload',stage3_report_sha256='5'*64,public_batch_sha256='b'*64,input_digest='d'*64,tiles=[dict(tile=i) for i in range(8)])
    auth=(dict(context_id='c'*64,public_keys=dirs['keys']/'public_keys',key_report_sha256='1'*64,key_source_archive_sha256='2'*64),
        dict(model_id='m'*64,model_report_sha256='3'*64,model_manifest_sha256='4'*64,server_data=dirs['model']),inputs)
    raw={'worker.py':b'# mock\n','marker.py':b'# unchanged\n','runtime/stage/server_inputs/p60_profile_and_refresh.json':b'{}',
         'runtime/stage/server_inputs/twelve_layer_plan.json':b'{}'}
    monkeypatch.setattr(c,'sources',lambda:dict(raw));monkeypatch.setattr(c.dependencies,'check',lambda:{'ready':True})
    monkeypatch.setattr(c.process,'software_versions',lambda:{'mock':True})
    monkeypatch.setattr(c.shutil,'disk_usage',lambda p:NS(free=20<<30))
    def authenticate(**kw):
        events.append('gates')
        if fail.get('gate'):raise fail['gate']
        return auth
    monkeypatch.setattr(c.worker,'authenticate',authenticate)
    monkeypatch.setitem(sys.modules,'file_stages',NS(MODEL_ID='fixed',REVISION='pinned'))
    original=c.BorrowedDirectory
    class Borrowed(original):
        def __init__(self,path):super().__init__(path);owners.append(self)
        def check(self):
            super().check()
            if fail.get('check'):raise fail['check']
        def close(self):
            events.append('close');super().close()
            if fail.get('close'):raise fail['close']
    monkeypatch.setattr(c,'BorrowedDirectory',Borrowed)
    request=dict(sample_count=1,tile_count=8,tiles=inputs['tiles'],public_batch_sha256='b'*64,input_digest='d'*64)
    response=dict(sample_count=1,response_count=1,level=2,public_batch_sha256='b'*64,input_digest='d'*64)
    def launch(command,directory,*,timeout,cleanup_grace_s):
        events.append('launch');assert timeout is None and cleanup_grace_s>=30
        assert Path(command[1]).parent.name=='execution_source'
        assert not any('private' in x or 'snapshot' in x for x in command[2::2])
        (dirs['io']/'download').mkdir();(dirs['io']/'server_report').write_text('{}')
        if fail.get('launch'):raise fail['launch']
        before=c.hashes(raw)
        proof=dict(passed=True,actual_server_compute_started=True,actual_server_compute_completed=True,
            request_readback_complete=True,response_readback_complete=True,source_files_unchanged=True,
            keygen_codecs_native_private_forbidden=True,forbidden_attempts=[],source_hashes_start=before,source_hashes_end=before,
            prerequisite=c.worker.prerequisite_summary(*auth),reviewed_dependencies={'ready':True},
            request_readback=request,response_readback=response,elapsed_s=1.)
        proof.update(fail.get('proof',{}));c.write(directory/'worker_report.json',proof)
        record=dict(returncode=0,process_reaped=True,public_key_store_removed=True,owned_directory_handle_closed=True,
            result=dict(passed=True,context_id='c'*64,model_id='m'*64,public_batch_sha256='b'*64,
                worker_report_sha256=c.process.sha256(directory/'worker_report.json')))
        record.update(fail.get('process',{}));c.write(directory/'process.json',record)
        if fail.get('source'):raw['marker.py']=b'# changed\n'
        if fail.get('late_check'):fail['check']=fail['late_check']
        return record
    monkeypatch.setattr(c.process,'run_case',launch)
    args=dict(output=tmp_path/'evidence',key_evidence=dirs['ke'],key_report_sha256='1'*64,key_workspace=dirs['keys'],
        model_evidence=dirs['me'],model_report_sha256='3'*64,model_workspace=dirs['model'],stage3_evidence=dirs['se'],
        stage3_report_sha256='5'*64,io_workspace=dirs['io'],execute=True)
    return NS(args=args,dirs=dirs,events=events,fail=fail,owners=owners,raw=raw,request=request,response=response)

def report(case):return json.loads((case.args['output']/'report.json').read_text())

def test_success_retains_all_external_artifacts(case):
    r=c.run(**case.args)
    assert r['passed'] and r['actual_server_compute'] and r['all_processes_reaped'] and r['source_archive_verified']
    assert case.events==['gates','launch','gates','close'] and case.owners[0].fd is None
    assert (case.dirs['io']/'download').is_dir() and (case.dirs['keys']/'private-sentinel').read_bytes()==b'untouched'

def test_noexecute_never_launches_or_removes_external_upload(case):
    case.args['execute']=False;r=c.run(**case.args)
    assert r['passed'] and not r['actual_server_compute'] and not r['actual_execution_attempted']
    assert 'launch' not in case.events and case.owners[0].fd is None and (case.dirs['io']/'upload').is_dir()

@pytest.mark.parametrize('which',['keys','model','io','ke','me','se'])
@pytest.mark.parametrize('alias',[False,True])
def test_output_containment_before_mkdir(case,tmp_path,which,alias):
    base=case.dirs[which]
    if alias:
        target=tmp_path/'alias';target.symlink_to(base,target_is_directory=True);base=target
    case.args['output']=base/'must-not-exist'
    with pytest.raises(ValueError,match='outside'):c.run(**case.args)
    assert not case.args['output'].exists() and not case.events

def test_pending_dependencies_precede_gates(case,monkeypatch):
    monkeypatch.setattr(c.dependencies,'check',lambda:(_ for _ in ()).throw(RuntimeError('pending cleanup')))
    with pytest.raises(RuntimeError,match='pending'):c.run(**case.args)
    assert not case.events and not case.owners and not report(case)['passed']

def test_failed_gate_precedes_borrowing_or_launch(case):
    case.fail['gate']=ValueError('stage3 pending')
    with pytest.raises(ValueError,match='pending'):c.run(**case.args)
    assert case.events==['gates'] and not case.owners and not report(case)['actual_execution_attempted']

@pytest.mark.parametrize('flag',['process_reaped','public_key_store_removed','owned_directory_handle_closed'])
def test_process_cleanup_failclosed_but_retains_outputs(case,flag):
    case.fail['process']={flag:False}
    with pytest.raises(ValueError,match='worker failed'):c.run(**case.args)
    r=report(case);assert not r['passed'] and not r['all_processes_reaped'] and r['io_workspace_retained']
    assert (case.dirs['io']/'download').is_dir() and case.owners[0].fd is None

def test_unknown_child_cancellation_primary_retained(case):
    error=KeyboardInterrupt('cancel');case.fail['launch']=error
    with pytest.raises(KeyboardInterrupt) as caught:c.run(**case.args)
    assert caught.value is error and any('active process evidence' in n for n in error.__notes__)
    r=report(case);assert not r['all_processes_reaped'] and r['io_workspace_retained'] and not r['passed']
    assert (case.dirs['io']/'download').is_dir() and case.owners[0].fd is None

def test_worker_source_binding_failure(case):
    case.fail['proof']={'source_hashes_end':{}}
    with pytest.raises(ValueError,match='worker/source'):c.run(**case.args)
    assert not report(case)['passed'] and case.owners[0].fd is None

def test_wrong_response_level_rejected(case):
    case.response['level']=3
    with pytest.raises(ValueError,match='response binding'):c.run(**case.args)
    assert not report(case)['passed']

def test_source_mutation_cannot_publish_pass(case):
    case.fail['source']=True;r=c.run(**case.args)
    assert not r['passed'] and not r['source_files_unchanged'] and r['io_workspace_retained']

def test_initial_publication_failure_recovers_failed_report(case,monkeypatch):
    original=c.write;calls=[]
    def write(path,value):
        calls.append(1)
        if len(calls)==1:raise OSError('initial publication')
        original(path,value)
    monkeypatch.setattr(c,'write',write)
    with pytest.raises(OSError,match='initial publication'):c.run(**case.args)
    assert not report(case)['passed'] and not case.events and not case.owners

def test_final_publication_preserves_cancellation(case,monkeypatch):
    original=c.write;error=KeyboardInterrupt('primary');case.fail['launch']=error
    def write(path,value):
        if path.name=='report.json' and 'source_hashes_end' in value:raise OSError('publication')
        original(path,value)
    monkeypatch.setattr(c,'write',write)
    with pytest.raises(KeyboardInterrupt) as caught:c.run(**case.args)
    assert caught.value is error and any('terminal publication' in n for n in error.__notes__) and case.owners[0].fd is None

def test_cleanup_cancellation_does_not_skip_close(case):
    case.fail['late_check']=ValueError('replaced');error=KeyboardInterrupt('close cancel');case.fail['close']=error
    with pytest.raises(ValueError,match='replaced') as caught:c.run(**case.args)
    assert case.owners[0].fd is None and any('close cancel' in n for n in caught.value.__notes__)

def test_metadata_failure_closes_borrowed_dir_retains_external(case,monkeypatch):
    monkeypatch.setattr(c.process,'software_versions',lambda:(_ for _ in ()).throw(ValueError('metadata')))
    with pytest.raises(ValueError,match='metadata'):c.run(**case.args)
    assert case.owners[0].fd is None and (case.dirs['io']/'upload').is_dir() and not report(case)['passed']

def test_real_pending_gate_and_source_closure():
    import dependencies,stage3_gate
    with pytest.raises(RuntimeError,match='pending'):dependencies.check()
    with pytest.raises(RuntimeError,match='pending'):stage3_gate.authenticate(None,None,None,keys=None,model=None)
    sources=c.sources()
    assert sources['runtime/stage/full_model_engine.py']==Path('/tmp/bert-stage4-engine-cleanup-20261103/candidate-v2/full_model_engine.py').read_bytes()
    assert 'joined/encrypted_bert_full_model.py' in sources and 'dependencies.json' in sources
    assert all(not x.endswith('.npz') for x in sources)
