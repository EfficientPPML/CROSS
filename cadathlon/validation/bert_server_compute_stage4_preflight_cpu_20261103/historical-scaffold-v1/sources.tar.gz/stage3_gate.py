"""Pending public-only completion gate. Never accepts an unfinished stage3."""
def authenticate(evidence, report_sha256, io_workspace, *, keys, model):
    raise RuntimeError('completed stage3 public evidence gate is pending root review')
