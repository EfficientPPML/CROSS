from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys,time
ROOT=Path('/tmp/bert-server-compute-stage4-successor-20261103')
sys.path.insert(0,str(ROOT))
spec=importlib.util.spec_from_file_location('scaffold_collector',ROOT/'collect.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
OUT=ROOT/'scaffold-preflight-v1';OUT.mkdir(exist_ok=False)
raw=c.sources();raw['external_preflight_driver.py']=Path(__file__).read_bytes();before=c.hashes(raw)
c.archive(OUT/'sources.tar.gz',raw)
command=[sys.executable,'-m','pytest','-q',*[str(ROOT/n) for n in ('test_worker.py','test_collector.py','test_boundaries.py','test_server_readback.py')],f'--junitxml={OUT}/tests.xml']
start=time.monotonic()
with (OUT/'tests.log').open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
after=c.hashes(c.sources()|{'external_preflight_driver.py':Path(__file__).read_bytes()})
origin=json.loads((ROOT/'source_origin.json').read_text());assembly={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in origin['assembly_source_hashes']}
report=dict(passed=result.returncode==0 and before==after and c.check_archive(OUT/'sources.tar.gz',before) and assembly==origin['assembly_source_hashes'],returncode=result.returncode,scope='Mocked stage4 worker/collector/transport and entrypoint guards only; no retained payload reads, CKKS context or handler execution.',command=command,cpu_affinity=sorted(os.sched_getaffinity(0)),elapsed_s=time.monotonic()-start,source_hashes_before=before,source_hashes_after=after,source_files_unchanged=before==after,source_count=len(before),source_archive_sha256=hashlib.sha256((OUT/'sources.tar.gz').read_bytes()).hexdigest(),source_archive_verified=c.check_archive(OUT/'sources.tar.gz',before),original_198_unchanged=assembly==origin['assembly_source_hashes'],actual_execution_dependency_ready=False)
(OUT/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in report.items() if not isinstance(v,(dict,list))},indent=2));raise SystemExit(0 if report['passed'] else 1)
