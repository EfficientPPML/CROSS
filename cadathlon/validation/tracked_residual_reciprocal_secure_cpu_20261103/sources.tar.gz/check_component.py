"""Secure CPU tracked-residual reciprocal components for130 frozen public rules.

No refresh, composed softmax, model, TPU or general-domain readiness claim.
All outputs are computed before any client decoding, including diagnostic e13.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import gc
import hashlib
import importlib.metadata
import io
import json
import math
import os
import resource
import signal
import sys
import tarfile
import time

if os.environ.get('JAX_PLATFORMS') != 'cpu':
    raise RuntimeError('explicit CPU backend required')
HERE=Path(__file__).resolve().parent
ROOT=HERE/'checkout'
sys.path[:0]=[str(ROOT),str(ROOT/'cadathlon/common')]
import jax
import numpy as np
from jaxite_word import CKKSContext,ckks_ctx,he_params,key_gen,util
from jaxite_word.composite_prime_gen import composite_prime_gen
from encrypted_ntt import enable_scoped_ntt_subsets
from encrypted_packed_qwen import CompiledArithmetic
from support import require_secure_execution
from lifecycle import CleanupTracker
from tracked_reciprocal import tracked_scale_plan,tracked_reciprocal_updates
jax.config.update('jax_enable_x64',True)
SLOTS=32768
UPDATES=13
GATE=1e-6
MANIFEST_SHA256='4e2277beea7189aa1d77b168c500c8a175f6c630afa520fcc6b38cb5a179cff9'


def sha(data):return hashlib.sha256(data).hexdigest()


def sources():
    paths=set(HERE.glob('*.py'))|{HERE/'candidate_manifest.json',HERE/'source_origin.json'}
    paths.update(ROOT.rglob('*.py'))
    return {str(p.relative_to(HERE)):p.read_bytes() for p in sorted(paths)}


def write(path,value):
    temporary=path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
    temporary.replace(path)


def load_rules(path=HERE/'candidate_manifest.json'):
    raw=path.read_bytes()
    if sha(raw)!=MANIFEST_SHA256:raise ValueError('frozen public reciprocal manifest differs')
    manifest=json.loads(raw)
    entries=[('initial',manifest['initial_reciprocal']),('tanh',manifest['tanh_reciprocal'])]
    rules=manifest['normalization_reciprocal_by_public_K']
    if set(rules)!={str(k) for k in range(1,129)}:raise ValueError('all128 public K rules required')
    entries.extend((f'K{k}',rules[str(k)]) for k in range(1,129))
    result=[]
    for name,rule in entries:
        low,high=rule['domain'];seed=rule['seed'];count=rule['iterations']
        if (not all(math.isfinite(x) for x in (low,high,seed)) or not 0<low<high or seed<=0
                or type(count)is not int or not 1<=count<=UPDATES):
            raise ValueError('invalid fixed reciprocal rule')
        result.append(dict(name=name,domain=[low,high],seed=seed,iterations=count,
                           first_weight=-seed*seed,first_bias=2*seed))
    return result


def make_probes(rules):
    if len(rules)!=130:raise ValueError('exact130 rules required')
    x=np.empty(SLOTS,np.float64);weight=np.empty_like(x);bias=np.empty_like(x);segments=[]
    for rule,indices in zip(rules,np.array_split(np.arange(SLOTS),130)):
        low,high=rule['domain'];count=len(indices)
        fixed=np.array([low,high,np.nextafter(low,high),np.nextafter(high,low),
                        low+(high-low)/2,math.sqrt(low)*math.sqrt(high)])
        remaining=count-len(fixed);n=remaining//3
        # Grid endpoints are assigned explicitly to avoid a libm rounding outside the domain.
        linear=np.linspace(low,high,n);geometric=np.geomspace(low,high,n)
        interior=low+(high-low)*(np.arange(remaining-2*n)+.5)/(remaining-2*n)
        values=np.concatenate([fixed,linear,geometric,interior])
        if values.shape!=(count,) or not np.isfinite(values).all() or np.any(values<low) or np.any(values>high):
            raise ValueError('public probes outside declared domain')
        x[indices]=values;weight[indices]=rule['first_weight'];bias[indices]=rule['first_bias']
        segments.append(dict(rule,slot_start=int(indices[0]),slot_stop=int(indices[-1]+1),
            slots=count,input_sha256=sha(values.tobytes()),minimum=float(values.min()),maximum=float(values.max())))
    metadata=dict(manifest_sha256=MANIFEST_SHA256,slots=SLOTS,rule_count=130,segments=segments,
        input_sha256=sha(x.tobytes()),weight_sha256=sha(weight.tobytes()),bias_sha256=sha(bias.tobytes()),
        probe_selection='Fixed endpoints, adjacent interior floats, arithmetic/geometric midpoints, linear/geometric grids and deterministic interior grid; no ciphertext/logit/label tuning.',
        fillers='None: all32768 physical slots belong to exactly one declared rule.')
    return x,weight,bias,metadata


def client_oracles(x,weight,bias):
    # Independent original Newton float circuit, not the proposed two-branch recurrence.
    y=weight*x+bias;ys=[y.copy()]
    for _ in range(1,UPDATES):
        y=y*(2-x*y);ys.append(y.copy())
    # Direct powers of the actual rounded-affine residual in wider arithmetic.
    # This oracle does not read either encrypted branch or derive e from decoded y.
    xx=x.astype(np.longdouble);ww=weight.astype(np.longdouble);bb=bias.astype(np.longdouble)
    e1=1-xx*(ww*xx+bb)
    es=[np.asarray(np.power(e1,2**i),np.float64) for i in range(UPDATES)]
    if not all(np.isfinite(z).all() for z in ys+es):raise ValueError('nonfinite fixed public oracle')
    return ys,es


def _error_max(values):
    """Keep numerical failures JSON-safe, including overflow from finite operands."""
    result=float(np.max(np.abs(values)))
    return result if math.isfinite(result) else None


def validate_decoded(decoded_y,decoded_e,x,oracle_y,oracle_e,fixture,metadata):
    if set(decoded_y)!=set(range(1,14)) or set(decoded_e)!=set(range(1,14)):
        raise ValueError('all13 estimate and actual residual checkpoints required')
    all_checks=[];declared=[]
    for update in range(1,14):
        y,e=np.asarray(decoded_y[update]),np.asarray(decoded_e[update])
        finite=y.shape==e.shape==(SLOTS,) and np.isfinite(y).all() and np.isfinite(e).all()
        values=dict.fromkeys(('y_original_newton_max_abs_error','e_independent_power_max_abs_error','invariant_defect_max_abs'))
        if finite:
            with np.errstate(over='ignore',invalid='ignore'):
                values=dict(y_original_newton_max_abs_error=_error_max(y-oracle_y[update-1]),
                    e_independent_power_max_abs_error=_error_max(e-oracle_e[update-1]),
                    invariant_defect_max_abs=_error_max(e-(1-x*y)))
        summaries_finite=all(v is not None for v in values.values())
        valid=bool(finite and summaries_finite and all(v<=GATE for v in values.values()) and metadata[update]['passed'])
        all_checks.append(dict(update=update,passed=valid,slots_checked=SLOTS,finite_and_shape=bool(finite),
            error_summaries_finite=summaries_finite,final_residual_is_separate_diagnostic_multiply=update==13,
            metadata=metadata[update],**values))
    for rule in fixture['segments']:
        index=rule['iterations'];s=slice(rule['slot_start'],rule['slot_stop'])
        whole_y,whole_e=np.asarray(decoded_y[index]),np.asarray(decoded_e[index])
        shape_ok=whole_y.shape==whole_e.shape==(SLOTS,)
        values=dict.fromkeys(('y_original_newton_max_abs_error','true_inverse_max_abs_error',
            'true_relative_residual_max_abs','tracked_residual_max_abs','invariant_defect_max_abs'))
        finite=False
        if shape_ok:
            y,e,xx=whole_y[s],whole_e[s],x[s]
            finite=bool(np.isfinite(y).all() and np.isfinite(e).all())
            if finite:
                with np.errstate(over='ignore',invalid='ignore'):
                    values=dict(y_original_newton_max_abs_error=_error_max(y-oracle_y[index-1][s]),
                        true_inverse_max_abs_error=_error_max(y-1/xx),
                        true_relative_residual_max_abs=_error_max(1-xx*y),
                        tracked_residual_max_abs=_error_max(e),
                        invariant_defect_max_abs=_error_max(e-(1-xx*y)))
        summaries_finite=all(v is not None for v in values.values())
        declared.append(dict(name=rule['name'],declared_update=index,slots_checked=rule['slots'],
            finite_and_shape=bool(shape_ok and finite),error_summaries_finite=summaries_finite,
            passed=bool(finite and summaries_finite and all(v<=GATE for v in values.values())),**values))
    return dict(passed=all(c['passed'] for c in all_checks+declared),checkpoints=all_checks,declared_rules=declared,
        convergence_gate_scope='Only each rule original declared count; earlier unconverged iterations have numerical oracle and invariant gates.',
        oracle_residual_method='Direct longdouble power of1-x*(rounded_weight*x+rounded_bias), independent of decoded branches.',
        oracle_longdouble_mantissa_bits=int(np.finfo(np.longdouble).nmant))


def parameters():
    degree,depth,dnum=65536,15,4
    q=composite_prime_gen(2,2*(depth+1),61,60,2*degree,31)
    p=util.generate_p_towers(q,dnum,degree,aux_bits=30)
    if not he_params.qp_is_secure(q,p,degree,he_params.SecurityTarget(128,'classical')):
        raise ValueError('insecure actual Q/P ring')
    he_params.assert_p_coverage(q,p,dnum)
    alpha=math.ceil(len(q)/dnum);parts=math.ceil(len(q)/alpha);shape=(parts,len(q)+len(p),degree)
    scale=float(q[-2])*q[-1]
    plan=tracked_scale_plan(q,input_scale=scale,input_level=depth,updates=UPDATES,final_scale=scale)
    e12=plan['rows'][-2]
    diagnostic=dict(update=13,level=e12['residual_level']-1,
        scale=e12['residual_scale']*e12['residual_scale']/math.prod(q[2*e12['residual_level']:2*e12['residual_level']+2]),nsd=1)
    retained_towers=sum(2*(r['level']+1)+ (2*(r['residual_level']+1) if 'residual_level'in r else 0) for r in plan['rows'])+2*(diagnostic['level']+1)
    return dict(degree=degree,depth=depth,dnum=dnum,q_towers=q,p_towers=p,degree_layout=[256,256],slots=SLOTS,
        actual_log2_qp=sum(map(math.log2,q+p)),security_bits=128,scale=scale,precision_bits=60,
        rotation_indices=[],actual_switch_partitions=parts,key_pair_shape=shape,
        raw_relinearization_key_bytes=2*math.prod(shape)*4,raw_public_key_bytes=2*len(q)*degree*4,
        raw_input_ciphertext_bytes=2*len(q)*degree*4,raw_retained_checkpoint_bytes=2*retained_towers*degree*4,
        disk_key_bytes=0,key_storage='In-memory public evaluation key only; no public rotation keys.',
        static_capacity=True,implicit_refresh=False,scoped_ntt_subsets=True,preserve_dispatch_cache=True,
        scale_plan=plan,diagnostic_residual=diagnostic,
        production_counts=dict(ciphertext_multiplications=24,initial_public_affines=1,composite_rescales=25),
        diagnostic_counts=dict(ciphertext_multiplications=1,composite_rescales=1))


def verify_archive(path,before):
    with tarfile.open(path) as archive:
        members=archive.getmembers()
        if len(members)!=len(before) or {m.name for m in members}!=set(before):raise ValueError('source inventory differs')
        for member in members:
            if not member.isfile() or sha(archive.extractfile(member).read())!=before[member.name]:raise ValueError('source archive bytes differ')
    return True


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--preflight',action='store_true');args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=False)
    started=time.monotonic();before={}
    report=dict(scope=__doc__,passed=False,source_hashes_before=before,phases=[],checks={},started_utc=datetime.now(timezone.utc).isoformat(),
        fixed_absolute_error_gate=GATE,process_pid=os.getpid(),cpu_affinity=sorted(os.sched_getaffinity(0)),
        environment={n:os.environ.get(n) for n in ('JAX_PLATFORMS','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')},
        key_generation_started=False,encryption_started=False,
        limitations=['130 fixed-domain reciprocal components only; no correlated softmax mass/error or model proof.',
            'Same process, separate client and keyless server objects; guards are regression boundaries, not an OS sandbox.',
            'Direct powers and original Newton float arrays are client-only numerical oracles and never enter server arithmetic.',
            'No implicit refresh; tracked residual can drift from true residual under CKKS, so both are independently gated.'])
    client=server=ops=provider=encrypted=keys=evaluation=original_multiply=None
    y=e=diagnostic=generator=value=None
    retained_y={};retained_e={};patched=[];codec_patches=[];old_handlers={}
    decoded_y={};decoded_e={};metadata={}
    counts=dict(production_ciphertext_multiplications=0,diagnostic_ciphertext_multiplications=0)
    def phase(label,value=None):
        if value is not None:value.polynomial.block_until_ready()
        row=dict(label=label,elapsed_s=time.monotonic()-started,peak_host_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        if value is not None:row.update(level=ops._level(value),scale=value._ckks_scale,nsd=value._ckks_nsd)
        report['phases'].append(row);write(args.output/'report.json',report);print(json.dumps(row),flush=True)
    def interrupted(signum,frame):
        for number in old_handlers:signal.signal(number,signal.SIG_IGN)
        raise KeyboardInterrupt(f'interrupted by signal {signum}')
    def forbidden(*args,**kwargs):raise AssertionError('client codec or secret-key generation during server computation')
    try:
        write(args.output/'report.json',report)
        raw=sources();before={name:sha(data) for name,data in raw.items()}
        with tarfile.open(args.output/'sources.tar.gz','w:gz') as archive:
            for name,data in raw.items():
                item=tarfile.TarInfo(name);item.size=len(data);archive.addfile(item,io.BytesIO(data))
        report.update(source_hashes_before=before,source_archive_sha256=sha((args.output/'sources.tar.gz').read_bytes()))
        report['source_archive_members_verified_before_work']=verify_archive(args.output/'sources.tar.gz',before)
        report['versions']={name:importlib.metadata.version(name) for name in ('jax','jaxlib','numpy')}
        for number in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):old_handlers[number]=signal.signal(number,interrupted)
        rules=load_rules();x,weight,bias,fixture=make_probes(rules);oracle_y,oracle_e=client_oracles(x,weight,bias)
        report['fixture']=fixture
        # Confirm the unchanged public probes and chosen rules satisfy their ideal gates before any keys.
        idealmeta={i:dict(passed=True) for i in range(1,14)}
        report['ideal_probe_checks']=validate_decoded(dict(enumerate(oracle_y,1)),dict(enumerate(oracle_e,1)),x,oracle_y,oracle_e,fixture,idealmeta)
        if not report['ideal_probe_checks']['passed']:raise ValueError('fixed public ideal domain/iteration gates fail')
        ring=parameters();report['ring']=ring
        if jax.default_backend()!='cpu' or any(d.platform!='cpu' for d in jax.devices()):raise ValueError('CPU backend not honored')
        phase('actual ring/P coverage and all130 fixed public rule probes passed')
        if args.preflight:report.update(passed=True,preflight_only=True)
        else:
            q,p,N,dnum=ring['q_towers'],ring['p_towers'],ring['degree'],ring['dnum'];scale=ring['scale']
            report['key_generation_started']=True;phase('fresh client key generation starting')
            keys=key_gen.gen_pke_pair(q,[],N)
            evaluation=key_gen.gen_evaluation_key(keys['secret_key'],q=q,P=p,dnum=dnum)
            params=dict(degree=N,num_slots=SLOTS,scaling_factor=scale,output_scale=scale,q_towers=q,p_towers=p,
                composite_degree=2,degree_layout=(256,256),p=60,CKKS_M_FACTOR=1,max_bits_in_word=61,noise_scale_degree=1)
            client=CKKSContext(dict(params,**keys))
            server=CKKSContext(dict(params,evaluation_key=[jax.numpy.asarray(evaluation[name],dtype='uint32').transpose(0,2,1) for name in ('a','b')]))
            for module in {key_gen,sys.modules.get('key_gen')}-{None}:
                for name in ('gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen'):
                    patched.append((module,name,getattr(module,name)));setattr(module,name,forbidden)
            report['key_generation_guards']=sorted({module.__name__ for module,_,_ in patched})
            if set(report['key_generation_guards'])!={'jaxite_word.key_gen','key_gen'}:raise RuntimeError('both key-generation aliases must be guarded')
            server.program_initialization([],dnum=dnum,r=256,c=256,batch=1,pregenerated_rotation_keys={})
            if any(v is not None for v in (server.secret_key,server._param_cache.secret_key,server.parameters.get('secret_key'))):raise RuntimeError('server has secret key')
            report['keyless_server']=True;client._polynomial_ntt_ctx=server._param_cache.ntt_q_max
            provider=enable_scoped_ntt_subsets(server);ops=CompiledArithmetic(server,low_memory=True,preserve_dispatch_cache=True)
            keys=evaluation=None;report['encryption_started']=True
            encrypted=client.encrypt_slots(x);encrypted._ckks_nsd=1
            report['execution_rings']=require_secure_execution(server,encrypted)
            fingerprint=(sha(np.asarray(encrypted.polynomial).tobytes()),encrypted._ckks_scale,encrypted._ckks_nsd,ops._level(encrypted))
            if fingerprint[1:]!=(scale,1,15):raise ValueError('fresh input metadata differs')
            for name in ('encrypt','decrypt','encrypt_slots','decrypt_slots','encrypt_slots_batch','decrypt_slots_batch','decode'):
                codec_patches.append((CKKSContext,name,getattr(CKKSContext,name)));setattr(CKKSContext,name,forbidden)
            report['class_codec_guards']=[name for _,name,_ in codec_patches]
            original_multiply=ops.multiply
            def production_multiply(left,right):
                counts['production_ciphertext_multiplications']+=1
                return original_multiply(left,right)
            ops.multiply=production_multiply
            phase('full-slot denominator encrypted; all client codecs guarded')
            generator=tracked_reciprocal_updates(ops,encrypted,normalization_factor=1,first_weight=weight,first_bias=bias,updates=13,
                first_output_scale=ring['scale_plan']['first_output_scale'])
            for update,y,e in generator:
                retained_y[update]=y
                if e is not None:retained_e[update]=e
                phase(f'production update{update} estimate complete',y)
                if e is not None:phase(f'production update{update} residual complete',e)
            generator=None
            if counts['production_ciphertext_multiplications']!=24:raise ValueError('production CT count differs')
            ops.multiply=original_multiply
            # Genuine final branch checkpoint, deliberately outside the production helper.
            counts['diagnostic_ciphertext_multiplications']+=1
            diagnostic=ops.multiply(retained_e[12],retained_e[12]);retained_e[13]=diagnostic
            phase('separate diagnostic e13 square complete',diagnostic)
            report['operation_counts']=dict(counts,production_initial_public_affines=1,production_composite_rescales=25,diagnostic_composite_rescales=1)
            for update in range(1,14):
                y,e=retained_y[update],retained_e[update];row=ring['scale_plan']['rows'][update-1]
                eres=ring['diagnostic_residual'] if update==13 else dict(level=row['residual_level'],scale=row['residual_scale'])
                ok=(ops._level(y)==row['level'] and y._ckks_scale==row['scale'] and type(y._ckks_nsd)is int and y._ckks_nsd==1
                    and ops._level(e)==eres['level'] and e._ckks_scale==eres['scale'] and type(e._ckks_nsd)is int and e._ckks_nsd==1)
                metadata[update]=dict(passed=ok,y_level=ops._level(y),y_scale=y._ckks_scale,y_nsd=y._ckks_nsd,
                    e_level=ops._level(e),e_scale=e._ckks_scale,e_nsd=e._ckks_nsd,
                    y_execution_rings=require_secure_execution(server,y),e_execution_rings=require_secure_execution(server,e))
                if not ok:raise ValueError('actual checkpoint metadata differs from scale plan')
            report['server_complete_before_client_validation']=True
            phase('all13 estimates and13 actual residuals complete; enabling client validation')
            for module,name,original in codec_patches:setattr(module,name,original)
            codec_patches.clear()
            for update in range(1,14):
                decoded_y[update]=np.asarray(client.decrypt_slots(retained_y[update]));decoded_e[update]=np.asarray(client.decrypt_slots(retained_e[update]))
            report['checks']=validate_decoded(decoded_y,decoded_e,x,oracle_y,oracle_e,fixture,metadata)
            report['input_payload_and_metadata_unchanged']=fingerprint==(sha(np.asarray(encrypted.polynomial).tobytes()),encrypted._ckks_scale,encrypted._ckks_nsd,ops._level(encrypted))
            report['provider_stats']=dict(provider.stats)
            report['passed']=bool(report['checks']['passed'] and report['input_payload_and_metadata_unchanged'])
            phase('all-slot client checkpoint and original-rule convergence gates complete')
    except BaseException as error:
        report.update(passed=False,error=f'{type(error).__name__}: {error}');raise
    finally:
        primary=sys.exception();tracker=CleanupTracker(primary);attempt=tracker.attempt
        for module,name,original in codec_patches:attempt('restore codec guard',lambda:setattr(module,name,original))
        if generator is not None:attempt('close generator',generator.close)
        if provider is not None:attempt('provider.close',provider.close)
        if ops is not None:
            if original_multiply is not None:attempt('restore multiply observer',lambda:setattr(ops,'multiply',original_multiply))
            attempt('rotation.clear',lambda:ops.rotation.clear(executables=True))
            for helper in (ops._plaintext_multiply,ops._rescale):attempt('compiled primitive clear',lambda:helper.clear(executables=True))
            attempt('multiplication compiler clear',ops._multiplication_compiler.clear_executables)
        for context in (server,client):
            if context is not None:attempt('evict context caches',lambda:ckks_ctx.evict_context_caches(context))
        context=keys=evaluation=encrypted=ops=server=client=value=provider=helper=y=e=diagnostic=generator=original_multiply=None
        retained_y.clear();retained_e.clear();decoded_y.clear();decoded_e.clear()
        attempt('jax.clear_caches',jax.clear_caches);attempt('gc.collect',gc.collect)
        for module,name,original in patched:attempt('restore key generation guard',lambda:setattr(module,name,original))
        for number,handler in old_handlers.items():attempt('restore signal handler',lambda:signal.signal(number,handler))
        data=attempt('source verification',sources);after={name:sha(content) for name,content in data.items()} if data is not None else {}
        verified=attempt('source archive verification',lambda:verify_archive(args.output/'sources.tar.gz',before))
        report.update(source_hashes_after=after,source_files_unchanged=bool(before) and before==after,
            source_archive_members_verified=verified is True,cleanup_errors=tracker.errors,
            cleanup_completed=not tracker.errors,no_key_files_written=True,
            elapsed_s=time.monotonic()-started,peak_host_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            finished_utc=datetime.now(timezone.utc).isoformat())
        report['passed']=bool(report['passed'] and before==after and verified and not tracker.errors)
        try:write(args.output/'report.json',report)
        except BaseException as publication_error:
            preserved=primary if primary is not None else tracker.cancellation
            if preserved is None:raise
            preserved.add_note(f'Final report publication failed: {publication_error}')
        tracker.finish()
    return 0 if report['passed'] else 1

if __name__=='__main__':raise SystemExit(main())
