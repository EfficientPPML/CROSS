"""Trusted native fixtures for two isolated LayerNorms, not a full P2 client."""
from pathlib import Path
import argparse
import hashlib
import importlib.metadata
import json
import math
import os
import struct
import sys
import time
import numpy as np

ROOT = Path(os.environ['CROSS_ROOT']).resolve()
sys.path[:0] = [str(ROOT), str(ROOT/'cadathlon/common')]
from spec import ASSETS, REVISION, EXAMPLE, KINDS, CHECKPOINTS, RULES, NORM_TENSOR_SHA256
from contracts import sha, write, digest, tensor_name, load_model
from transport import _json, _read_regular

SCHEMA = 'bert-row-norm-preprocessing-v1'
SCOPE = ('Actual native attention and MLP pre-LayerNorm rows0/1 of the fixed128-token pair; '
         'trusted isolated component fixtures beyond the embedding-only P2 client boundary. '
         'No encrypted/full-model accuracy or performance claim.')
FIELDS = frozenset(('schema','scope','passed','rows','shape','full_native_shape','public_pair',
    'public_pair_sha256','tokenization_sha256','asset_sha256','model_revision',
    'model_manifest_sha256','rules','source_module_tensor_sha256','input_sha256',
    'private_reference_sha256','records','versions','elapsed_s'))
# Fixed native-preflight v1 bytes, selected from the predeclared pair/rows,
# never chosen from encrypted results. This prototype deliberately pins its
# exact input artifacts as well as the model/tokenizer revision.
FIXED_TOKENIZATION_SHA256 = '03e5df9ab51acca03e137e974d7d591bbad970fe1142983b2b76af918d6f1ab5'
FIXED_INPUT_SHA256 = {'attention_input.npy':'0ddb34b51073d9d44295464b2fd12771fa7a42c837cdeea174397e5ab70283af',
                     'mlp_input.npy':'80ee63136c7bdbd72f447a198c036dc2e9cd46a171d21841ce241542fbb0dedb'}
INPUTS = {phase+'_input.npy' for phase in KINDS}
REFERENCES = {phase+'_'+role+'_expected.npy' for phase in KINDS for role in CHECKPOINTS}


def tensor_bytes(snapshot, name):
    with (snapshot/'model.safetensors').open('rb') as stream:
        size = struct.unpack('<Q', stream.read(8))[0]
        header = json.loads(stream.read(size))
        entry = header[name]
        start, stop = entry['data_offsets']
        stream.seek(8+size+start)
        raw = stream.read(stop-start)
    if entry['dtype'] != 'F32':
        raise ValueError('expected pinned F32 tensor')
    return np.frombuffer(raw, dtype='<f4').reshape(entry['shape']).copy()


def polynomial_values(values, rule):
    lo, hi = rule['domain']
    if not np.isfinite(values).all() or np.any(values < lo) or np.any(values > hi):
        raise ValueError('fixed inverse domain violated; domain is not widened')
    return np.polynomial.chebyshev.chebval((2*values-lo-hi)/(hi-lo), rule['coefficients'])


def numpy_references(tile, gamma, beta, rule):
    """Independent moments and Clenshaw oracle; never executes the encrypted helper."""
    tile = np.asarray(tile)
    gamma, beta = np.asarray(gamma), np.asarray(beta)
    if tile.dtype != np.float64 or tile.shape != (16384,) or not np.isfinite(tile).all():
        raise ValueError('finite float64[16384] input required')
    if any(x.shape != (768,) or not np.isfinite(x).all() for x in (gamma, beta)):
        raise ValueError('finite full-width affine vectors required')
    rows = tile.reshape(4,4096)[:2,:768]
    mean = rows.mean(axis=1, keepdims=True)
    centered = rows-mean
    variance = (centered*centered).mean(axis=1, keepdims=True)+rule['epsilon']
    mean_slots = np.zeros((4,4096), dtype=np.float64)
    mean_slots[:2,:768] = mean
    variance_slots = np.full((4,4096), sum(rule['domain'])/2, dtype=np.float64)
    variance_slots[:2,:] = variance
    inverse_slots = polynomial_values(variance_slots, rule)
    output_slots = np.zeros((4,4096), dtype=np.float64)
    output_slots[:2,:768] = centered*inverse_slots[:2,:768]*gamma+beta
    return {name: value.ravel() for name,value in zip(CHECKPOINTS,
        (mean_slots,variance_slots,inverse_slots,output_slots))}


def validate_private(private, model):
    """Client-only strict fixed-fixture/schema/hash validation; no native model load."""
    private, model = Path(private), Path(model)
    if private.is_symlink() or not private.is_dir():
        raise ValueError('private directory must be a real directory')
    report = _json(_read_regular(private/'preprocessing.json', 131072))
    if not isinstance(report,dict) or set(report) != FIELDS:
        raise ValueError('unexpected preprocessing schema')
    if (report['schema'] != SCHEMA or report['scope'] != SCOPE or report['passed'] is not True
            or report['rows'] != [0,1] or report['shape'] != [16384]
            or report['full_native_shape'] != [1,128,768]
            or report['public_pair'] != list(EXAMPLE)
            or report['public_pair_sha256'] != digest(list(EXAMPLE))
            or report['asset_sha256'] != ASSETS or report['model_revision'] != REVISION
            or report['rules'] != RULES
            or any(type(v) is not int for key in ('rows','shape','full_native_shape') for v in report[key])):
        raise ValueError('fixed native fixture identity differs')
    _, affine = load_model(model)
    if report['model_manifest_sha256'] != sha(model/'model_manifest.json',65536):
        raise ValueError('native model binding differs')
    if (report['tokenization_sha256'] != FIXED_TOKENIZATION_SHA256
            or report['tokenization_sha256'] != sha(private/'tokens.json',65536)):
        raise ValueError('native tokenization differs')
    tokens = _json(_read_regular(private/'tokens.json',65536))
    if not isinstance(tokens,dict) or set(tokens) != {'input_ids','token_type_ids','attention_mask'}:
        raise ValueError('unexpected native token fields')
    for name,value in tokens.items():
        if (not isinstance(value,list) or len(value)!=1 or not isinstance(value[0],list)
                or len(value[0])!=128 or any(type(x) is not int for x in value[0])):
            raise ValueError('native token shape/type differs')
        if name != 'input_ids' and any(x not in (0,1) for x in value[0]):
            raise ValueError('native token mask/type value differs')
    if tokens['attention_mask'][0][:2] != [1,1]:
        raise ValueError('fixed rows must be valid')
    if report['input_sha256'] != FIXED_INPUT_SHA256:
        raise ValueError('fixed native input artifact identity differs')
    loaded = {}
    for field,names in (('input_sha256',INPUTS),('private_reference_sha256',REFERENCES)):
        hashes=report[field]
        if not isinstance(hashes,dict) or set(hashes)!=names:
            raise ValueError('private reference inventory differs')
        for name,expected_digest in hashes.items():
            path=private/name
            if sha(path,16384*8+65536)!=expected_digest:
                raise ValueError('private array hash differs')
            value=np.load(path,allow_pickle=False)
            if value.dtype!=np.float64 or value.shape!=(16384,) or not np.isfinite(value).all():
                raise ValueError('private array layout differs')
            loaded[name] = value
    for phase in KINDS:
        recomputed = numpy_references(loaded[phase+'_input.npy'], *affine[phase], RULES[phase])
        for role, reference in recomputed.items():
            if not np.array_equal(loaded[phase+'_'+role+'_expected.npy'], reference):
                raise ValueError('private oracle differs from independent fixed circuit')
    sources=report['source_module_tensor_sha256']
    if not isinstance(sources,dict) or not sources or any(not isinstance(k,str) or not isinstance(v,str) or len(v)!=64 for k,v in sources.items()):
        raise ValueError('native module provenance differs')
    for phase in KINDS:
        for suffix in ('gamma','beta'):
            if sources.get(tensor_name(phase,suffix)) != NORM_TENSOR_SHA256[phase][suffix]:
                raise ValueError('native normalization tensor differs')
    records=report['records']
    if not isinstance(records,dict) or set(records)!=set(KINDS):
        raise ValueError('native diagnostic inventory differs')
    for phase,record in records.items():
        keys={'variance_range','domain_violations','exact_numpy_vs_native_max_abs',
              'polynomial_vs_native_max_abs','polynomial_vs_native_nrmse','padding_seed'}
        if not isinstance(record,dict) or set(record)!=keys:
            raise ValueError('native diagnostic schema differs')
        bounds=record['variance_range'];lo,hi=RULES[phase]['domain']
        if (not isinstance(bounds,list) or len(bounds)!=2
                or any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for v in bounds)
                or not lo<=bounds[0]<=bounds[1]<=hi or type(record['domain_violations']) is not int
                or record['domain_violations']!=0
                or type(record['padding_seed']) is not int
                or record['padding_seed']!=20261103+RULES[phase]['degree']*100+2):
            raise ValueError('fixed variance domain/padding differs')
        for key in ('exact_numpy_vs_native_max_abs','polynomial_vs_native_max_abs','polynomial_vs_native_nrmse'):
            v=record[key]
            if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<0:
                raise ValueError('invalid native numerical diagnostic')
        if record['exact_numpy_vs_native_max_abs']>1e-12:
            raise ValueError('independent exact native normalization disagrees')
    if not isinstance(report['versions'],dict) or set(report['versions'])!={'numpy','torch','transformers','tokenizers','safetensors'} or any(not isinstance(v,str) or not v for v in report['versions'].values()):
        raise ValueError('native software provenance differs')
    elapsed=report['elapsed_s']
    if isinstance(elapsed,bool) or not isinstance(elapsed,(int,float)) or not math.isfinite(elapsed) or elapsed<0:
        raise ValueError('invalid preprocessing duration')
    return report


def prepare(snapshot, private, model):
    started=time.perf_counter()
    snapshot,private,model=Path(snapshot),Path(private),Path(model)
    hashes={name:sha(snapshot/name) for name in ASSETS}
    if hashes!=ASSETS or snapshot.name!=REVISION:
        raise ValueError('pinned BERT asset mismatch')
    import torch
    from transformers import AutoTokenizer,BertForSequenceClassification
    torch.set_num_threads(1)
    network,loading=BertForSequenceClassification.from_pretrained(snapshot,local_files_only=True,
        use_safetensors=True,torch_dtype=torch.float64,attn_implementation='eager',output_loading_info=True)
    if loading['missing_keys'] or loading.get('mismatched_keys') or loading.get('error_msgs') or set(loading['unexpected_keys'])-{'bert.embeddings.position_ids'}:
        raise ValueError('incomplete pinned model')
    network.eval()
    tokenizer=AutoTokenizer.from_pretrained(snapshot,local_files_only=True)
    tokens=tokenizer(*EXAMPLE,max_length=128,padding='max_length',truncation=True,return_tensors='pt')
    layer=network.bert.encoder.layer[0]
    with torch.no_grad():
        embedding=network.bert.embeddings(input_ids=tokens['input_ids'],token_type_ids=tokens['token_type_ids'])
        mask=tokens['attention_mask'].bool()
        additive=torch.zeros(mask[:,None,None,:].shape,dtype=torch.float64).masked_fill(~mask[:,None,None,:],torch.finfo(torch.float64).min)
        context=layer.attention.self(embedding,attention_mask=additive)[0]
        attention_input=layer.attention.output.dense(context)+embedding
        attention_output=layer.attention.output.LayerNorm(attention_input)
        if not torch.equal(attention_output,layer.attention(embedding,attention_mask=additive)[0]):
            raise ValueError('native attention decomposition disagrees')
        mlp_input=layer.output.dense(layer.intermediate(attention_output))+attention_output
        mlp_output=layer.output.LayerNorm(mlp_input)
    if not bool(mask[0,:2].all()):
        raise ValueError('fixed rows must be valid')
    private.mkdir(mode=0o700);model.mkdir()
    write(private/'tokens.json',{name:value.tolist() for name,value in tokens.items()})
    state=network.state_dict();source_hashes={}
    for name,value in state.items():
        if name.startswith(('bert.embeddings.','bert.encoder.layer.0.')):
            raw=tensor_bytes(snapshot,name)
            if not np.array_equal(raw.astype(np.float64),value.numpy()):
                raise ValueError('native source tensor differs from pinned F32 bytes')
            source_hashes[name]=hashlib.sha256(raw.tobytes()).hexdigest()
    manifest={'schema':'pinned-bert-layer0-row-norm-v1','model_id':'google-bert/bert-base-cased-finetuned-mrpc',
        'revision':REVISION,'asset_sha256':hashes,'tensors':{}}
    affine={}
    for phase in KINDS:
        pair=[]
        for suffix in ('gamma','beta'):
            name=tensor_name(phase,suffix);raw=tensor_bytes(snapshot,name)
            tensor_hash=hashlib.sha256(raw.tobytes()).hexdigest()
            if raw.shape!=(768,) or tensor_hash!=NORM_TENSOR_SHA256[phase][suffix]:
                raise ValueError('fixed normalization tensor differs')
            filename=phase+'_'+suffix+'.npy';np.save(model/filename,raw,allow_pickle=False)
            manifest['tensors'][filename]={'name':name,'shape':[768],'dtype':raw.dtype.str,
                'file_sha256':sha(model/filename),'tensor_sha256':tensor_hash}
            pair.append(raw.astype(np.float64))
        affine[phase]=pair
    write(model/'model_manifest.json',manifest)
    report={'schema':SCHEMA,'scope':SCOPE,'passed':False,'rows':[0,1],'shape':[16384],
        'full_native_shape':[1,128,768],'public_pair':list(EXAMPLE),'public_pair_sha256':digest(list(EXAMPLE)),
        'tokenization_sha256':sha(private/'tokens.json'),'asset_sha256':hashes,'model_revision':REVISION,
        'model_manifest_sha256':sha(model/'model_manifest.json'),'rules':RULES,
        'source_module_tensor_sha256':source_hashes,'input_sha256':{},'private_reference_sha256':{},
        'records':{},'versions':{name:importlib.metadata.version(name) for name in ('numpy','torch','transformers','tokenizers','safetensors')},'elapsed_s':0.}
    try:
        for phase,raw_input,native_output,module in (
                ('attention',attention_input,attention_output,layer.attention.output.LayerNorm),
                ('mlp',mlp_input,mlp_output,layer.output.LayerNorm)):
            rows=raw_input[0,:2].numpy().copy();native=native_output[0,:2].numpy().copy()
            if rows.shape!=(2,768) or not np.isfinite(rows).all() or np.array_equal(rows[0],rows[1]):
                raise ValueError('fixed rows must remain distinct and finite')
            rule=RULES[phase]
            if module.eps!=rule['epsilon']:
                raise ValueError('fixed native epsilon differs')
            seed=20261103+rule['degree']*100+2
            tile=np.random.default_rng(seed).uniform(-100.,100.,(4,4096))
            tile[:2,:768]=rows;filename=phase+'_input.npy'
            np.save(private/filename,tile.ravel(),allow_pickle=False);report['input_sha256'][filename]=sha(private/filename)
            mean=rows.mean(axis=1,keepdims=True);centered=rows-mean
            variance=(centered*centered).mean(axis=1,keepdims=True)+rule['epsilon']
            lo,hi=rule['domain'];violations=int(np.count_nonzero((variance<lo)|(variance>hi)|~np.isfinite(variance)))
            record={'variance_range':[float(variance.min()),float(variance.max())],'domain_violations':violations,
                'padding_seed':seed,'exact_numpy_vs_native_max_abs':0.,'polynomial_vs_native_max_abs':0.,'polynomial_vs_native_nrmse':0.}
            report['records'][phase]=record
            if violations:
                raise ValueError('fixed inverse domain violated; domain is not widened')
            gamma,beta=affine[phase]
            exact=centered/np.sqrt(variance)*gamma+beta
            references=numpy_references(tile.ravel(),gamma,beta,rule)
            approx=references['output'].reshape(4,4096)[:2,:768]
            record.update(exact_numpy_vs_native_max_abs=float(np.max(np.abs(exact-native))),
                polynomial_vs_native_max_abs=float(np.max(np.abs(approx-native))),
                polynomial_vs_native_nrmse=float(np.sqrt(np.mean((approx-native)**2))/max(.01,np.sqrt(np.mean(native**2)))))
            if record['exact_numpy_vs_native_max_abs']>1e-12:
                raise ValueError('independent exact native normalization disagrees')
            for role,array in references.items():
                filename=phase+'_'+role+'_expected.npy';np.save(private/filename,array,allow_pickle=False)
                report['private_reference_sha256'][filename]=sha(private/filename)
        report.update(passed=True,elapsed_s=time.perf_counter()-started)
        write(private/'preprocessing.json',report)
        validate_private(private,model)
    except BaseException as error:
        report.update(passed=False,elapsed_s=time.perf_counter()-started,error=type(error).__name__+': '+str(error))
        write(private/'preprocessing.json',report)
        raise
    finally:
        for path in private.iterdir():
            os.chmod(path,0o600)
    print(json.dumps(report,allow_nan=False))
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('snapshot','private','model'):
        parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();prepare(args.snapshot,args.private,args.model)
