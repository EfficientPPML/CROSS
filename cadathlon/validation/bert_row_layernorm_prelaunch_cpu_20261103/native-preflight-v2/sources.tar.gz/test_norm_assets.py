"""Independent fixture/metadata tests; no keygen, encryption or native model load."""
from pathlib import Path
import copy
import importlib.util
import os
import sys
import numpy as np
import pytest

HERE=Path(__file__).resolve().parent
os.environ['CROSS_ROOT']=str(HERE.parent/'checkout')
sys.path.insert(0,str(HERE))
import assets


def make_tile(phase):
    rule=assets.RULES[phase]
    rng=np.random.default_rng(20261103+rule['degree']*100+2)
    tile=rng.uniform(-100.,100.,(4,4096))
    rows=rng.normal(size=(2,768))
    rows-=rows.mean(axis=1,keepdims=True)
    rows/=np.sqrt((rows*rows).mean(axis=1,keepdims=True))
    rows*=np.sqrt(sum(rule['domain'])/2-rule['epsilon'])
    rows+=np.array([[1.2],[-.7]])
    tile[:2,:768]=rows
    return tile.ravel(),rng.normal(size=768),rng.normal(size=768)


@pytest.mark.parametrize('phase',assets.KINDS)
def test_independent_full_slot_references_ignore_hostile_padding(phase):
    tile,gamma,beta=make_tile(phase);saved=tile.copy();rule=assets.RULES[phase]
    result=assets.numpy_references(tile,gamma,beta,rule)
    assert set(result)==set(assets.CHECKPOINTS)
    for row in range(2):
        x=tile.reshape(4,4096)[row,:768]
        mean=sum(x)/768
        centered=x-mean
        variance=sum(centered*centered)/768+rule['epsilon']
        inverse=np.polynomial.Chebyshev(rule['coefficients'],domain=rule['domain'])(variance)
        np.testing.assert_allclose(result['mean'].reshape(4,4096)[row,:768],mean,atol=1e-14,rtol=0)
        np.testing.assert_allclose(result['variance'].reshape(4,4096)[row],variance,atol=1e-14,rtol=0)
        np.testing.assert_allclose(result['output'].reshape(4,4096)[row,:768],centered*inverse*gamma+beta,atol=2e-14,rtol=0)
    mask=np.ones((4,4096),bool);mask[:2,:768]=False
    assert np.all(result['mean'].reshape(4,4096)[mask]==0)
    assert np.all(result['output'].reshape(4,4096)[mask]==0)
    midpoint=sum(rule['domain'])/2
    assert np.all(result['variance'].reshape(4,4096)[2:]==midpoint)
    np.testing.assert_allclose(result['inverse'],assets.polynomial_values(result['variance'],rule),atol=0,rtol=0)
    changed=tile.copy().reshape(4,4096);changed[mask]*=-99
    again=assets.numpy_references(changed.ravel(),gamma,beta,rule)
    for key in result:np.testing.assert_array_equal(again[key],result[key])
    np.testing.assert_array_equal(tile,saved)


@pytest.mark.parametrize('phase',assets.KINDS)
def test_out_of_domain_and_malformed_inputs_fail(phase):
    tile,gamma,beta=make_tile(phase)
    for invalid in (tile.astype(np.float32),tile[:-1],np.full(16384,np.nan)):
        with pytest.raises(ValueError):assets.numpy_references(invalid,gamma,beta,assets.RULES[phase])
    constant=np.zeros(16384,dtype=np.float64)
    with pytest.raises(ValueError,match='domain violated'):
        assets.numpy_references(constant,gamma,beta,assets.RULES[phase])


@pytest.fixture
def private_case(tmp_path,monkeypatch):
    private=tmp_path/'client';model=tmp_path/'model';private.mkdir();model.mkdir()
    # This test isolates private-schema validation; real pinned public tensors
    # are checked by the separate native preflight and contracts.load_model.
    affine={}
    monkeypatch.setattr(assets,'load_model',lambda path: ({},affine))
    assets.write(model/'model_manifest.json',{'fixture':'private-validator-unit'})
    assets.write(private/'tokens.json',{'input_ids':[[1]*128],'token_type_ids':[[0]*128],'attention_mask':[[1]*128]})
    report={'schema':assets.SCHEMA,'scope':assets.SCOPE,'passed':True,'rows':[0,1],
        'shape':[16384],'full_native_shape':[1,128,768],'public_pair':list(assets.EXAMPLE),
        'public_pair_sha256':assets.digest(list(assets.EXAMPLE)),'tokenization_sha256':assets.sha(private/'tokens.json'),
        'asset_sha256':assets.ASSETS,'model_revision':assets.REVISION,'model_manifest_sha256':assets.sha(model/'model_manifest.json'),
        'rules':assets.RULES,'source_module_tensor_sha256':{},'input_sha256':{},'private_reference_sha256':{},
        'records':{},'versions':{k:'fixture' for k in ('numpy','torch','transformers','tokenizers','safetensors')},'elapsed_s':.1}
    for phase in assets.KINDS:
        tile,gamma,beta=make_tile(phase);affine[phase]=(gamma,beta);name=phase+'_input.npy';np.save(private/name,tile,allow_pickle=False)
        report['input_sha256'][name]=assets.sha(private/name)
        result=assets.numpy_references(tile,gamma,beta,assets.RULES[phase])
        for role,value in result.items():
            name=phase+'_'+role+'_expected.npy';np.save(private/name,value,allow_pickle=False)
            report['private_reference_sha256'][name]=assets.sha(private/name)
        for suffix in ('gamma','beta'):
            report['source_module_tensor_sha256'][assets.tensor_name(phase,suffix)]=assets.NORM_TENSOR_SHA256[phase][suffix]
        variance=result['variance'].reshape(4,4096)[:2,0]
        report['records'][phase]={'variance_range':[float(variance.min()),float(variance.max())],'domain_violations':0,
            'exact_numpy_vs_native_max_abs':0.,'polynomial_vs_native_max_abs':1e-7,'polynomial_vs_native_nrmse':1e-7,
            'padding_seed':20261103+assets.RULES[phase]['degree']*100+2}
    monkeypatch.setattr(assets,'FIXED_TOKENIZATION_SHA256',report['tokenization_sha256'])
    monkeypatch.setattr(assets,'FIXED_INPUT_SHA256',copy.deepcopy(report['input_sha256']))
    assets.write(private/'preprocessing.json',report)
    return private,model,report


def test_valid_private_fixture(private_case):
    private,model,report=private_case
    assert assets.validate_private(private,model)==report


@pytest.mark.parametrize('field,value',[
    ('schema','other'),('passed',1),('rows',[False,True]),('full_native_shape',[True,128,768]),
    ('shape',[8192]),('public_pair',['wrong','pair']),('rules',{}),('model_revision','wrong'),
    ('model_manifest_sha256','0'*64),('tokenization_sha256','0'*64),('input_sha256',{}),
    ('private_reference_sha256',{}),('source_module_tensor_sha256',{}),('versions',{}),('elapsed_s',-1),
])
def test_private_schema_mutation_rejected(private_case,field,value):
    private,model,report=private_case;report=copy.deepcopy(report);report[field]=value
    assets.write(private/'preprocessing.json',report)
    with pytest.raises((ValueError,TypeError)):assets.validate_private(private,model)


@pytest.mark.parametrize('name',sorted(assets.INPUTS|assets.REFERENCES))
def test_every_private_array_hash_bound(private_case,name):
    private,model,_=private_case
    with (private/name).open('ab') as stream:stream.write(b'changed')
    with pytest.raises(ValueError,match='hash differs|artifact identity differs'):assets.validate_private(private,model)


@pytest.mark.parametrize('kind',('nan','dtype','shape','symlink','fifo'))
def test_invalid_private_array_even_with_updated_hash(private_case,kind):
    private,model,report=private_case;path=private/'attention_input.npy'
    if kind=='nan':np.save(path,np.full(16384,np.nan))
    elif kind=='dtype':np.save(path,np.zeros(16384,dtype=np.float32))
    elif kind=='shape':np.save(path,np.zeros(8192,dtype=np.float64))
    elif kind=='symlink':
        target=private/'saved.npy';path.rename(target);path.symlink_to(target)
    else:path.unlink();os.mkfifo(path)
    if kind not in ('symlink','fifo'):
        report['input_sha256'][path.name]=assets.sha(path);assets.write(private/'preprocessing.json',report)
    with pytest.raises((ValueError,OSError)):assets.validate_private(private,model)


def test_updated_token_and_self_declared_hash_still_rejected(private_case):
    private,model,report=private_case
    tokens=assets._json((private/'tokens.json').read_bytes());tokens['input_ids'][0][0]=12345
    assets.write(private/'tokens.json',tokens);report['tokenization_sha256']=assets.sha(private/'tokens.json')
    assets.write(private/'preprocessing.json',report)
    with pytest.raises(ValueError,match='tokenization'):assets.validate_private(private,model)


@pytest.mark.parametrize('name',sorted(assets.REFERENCES))
def test_updated_oracle_and_self_declared_hash_still_rejected(private_case,name):
    private,model,report=private_case
    np.save(private/name,np.full(16384,123.,dtype=np.float64))
    report['private_reference_sha256'][name]=assets.sha(private/name)
    assets.write(private/'preprocessing.json',report)
    with pytest.raises(ValueError,match='independent fixed circuit'):assets.validate_private(private,model)


def test_updated_input_and_self_declared_hash_still_rejected(private_case):
    private,model,report=private_case
    np.save(private/'attention_input.npy',np.full(16384,123.,dtype=np.float64))
    report['input_sha256']['attention_input.npy']=assets.sha(private/'attention_input.npy')
    assets.write(private/'preprocessing.json',report)
    with pytest.raises(ValueError,match='artifact identity'):assets.validate_private(private,model)
