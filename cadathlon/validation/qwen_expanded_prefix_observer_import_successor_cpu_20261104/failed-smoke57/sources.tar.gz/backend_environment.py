"""Explicit CPU PyTorch backend selection, checked before backend import."""
import os

REQUIRED = {
    'USE_TF': '0', 'USE_FLAX': '0', 'USE_TORCH': '1',
    'USE_TORCH_XLA': '0', 'FORCE_TF_AVAILABLE': '0',
}

def check():
    actual = {name: os.environ.get(name) for name in REQUIRED}
    if actual != REQUIRED:
        raise ValueError('Explicit PyTorch-only backend environment required')
    return actual
