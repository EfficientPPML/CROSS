"""Authenticated backend class import, with no inputs, assets or model work."""
from contextlib import contextmanager
import os
from pathlib import Path
import sys
import backend_environment
from cleanup_origin import cleanup_origin, protect_body, choose


@contextmanager
def no_model_construction(torch, calls):
    original = torch.nn.Module.__init__
    previous_profile = sys.getprofile()
    primary = body = None
    def denied(*args, **kwargs):
        calls.append('torch.nn.Module.__init__')
        raise PermissionError('Model construction forbidden in import smoke')
    def profile(frame, event, arg):
        if event == 'call':
            name = frame.f_code.co_name
            module = frame.f_globals.get('__name__', '')
            if module.startswith(('transformers', 'tokenizers')) and name in ('from_pretrained', 'from_file', 'from_str'):
                calls.append(module + '.' + name)
                raise PermissionError('Pretrained/tokenizer loading forbidden in import smoke')
        elif event == 'c_call' and getattr(arg, '__module__', '') == 'tokenizers' and getattr(arg, '__name__', '') in ('from_file', 'from_str'):
            calls.append('tokenizers.' + arg.__name__)
            raise PermissionError('Tokenizer construction forbidden in import smoke')
    try:
        torch.nn.Module.__init__ = denied
        sys.setprofile(profile)
        yield
    except BaseException as error:
        primary = error
        body = None if cleanup_origin(error) else protect_body(error)
        raise
    finally:
        selected = primary
        for name, action in (
            ('restore profiler', lambda: sys.setprofile(previous_profile)),
            ('restore module constructor', lambda: setattr(torch.nn.Module, '__init__', original)),
        ):
            try: action()
            except BaseException as error: selected = choose(selected,error,name,body_primary=body)
        if selected is not None and selected is not primary: raise selected


def run(blobs):
    backend_environment.check()
    from freeze_io import read, parse
    from model_runtime import backend_check
    before = backend_check(blobs, read)
    import torch
    calls = []
    with no_model_construction(torch, calls):
        from transformers import Qwen3ForCausalLM
        from transformers.utils import import_utils
        if any((import_utils.is_tf_available(), import_utils.is_flax_available(), import_utils.is_torch_xla_available())):
            raise ValueError('Disabled optional backend reported available')
        if not issubclass(Qwen3ForCausalLM, torch.nn.Module):
            raise ValueError('Expected actual Qwen torch class')
        after = backend_check(blobs, read, loaded=True)
        pin = parse(blobs['backend_sources.json'])['models/qwen3/modeling_qwen3.py']
        module = sys.modules[Qwen3ForCausalLM.__module__]
        if Path(module.__file__).resolve() != Path(pin['path']).resolve():
            raise ValueError('Qwen class source differs')
    if before != after or calls:
        raise ValueError('Import-only source or constructor invariant differs')
    forbidden = sorted(n for n in sys.modules if n.split('.')[0] in ('jax','jaxlib','jaxite_word','tensorflow','flax','torch_xla'))
    if forbidden:
        raise ValueError('Forbidden backend imported')
    return dict(import_smoke_completed=True, model_class_imported=True,
        model_class_module=Qwen3ForCausalLM.__module__,model_class_name=Qwen3ForCausalLM.__name__,
        model_constructed=False,model_forward=False,tokenizer_execution=False,
        constructor_attempts=calls,forbidden_backends_loaded=forbidden,
        backend_sources_before=before,backend_sources_after=after,
        tokenizers_module_imported=any(n=='tokenizers' or n.startswith('tokenizers.') for n in sys.modules),
        torch_cuda_initialized=torch.cuda.is_initialized(),
        native_threads=len(os.listdir('/proc/self/task')),
        scope='Actual Qwen class import only; no model constructor, weights, tokens, tokenizer or forward')
