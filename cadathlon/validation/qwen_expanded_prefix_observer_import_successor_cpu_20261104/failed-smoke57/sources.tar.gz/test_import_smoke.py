"""Synthetic environment, import-only boundaries and truthful phase reporting."""
import ast
from pathlib import Path
import sys
from types import SimpleNamespace
import pytest
import backend_environment as env
import import_smoke as smoke
import observer_process as process
from test_grants import blobs,args
from freeze_io import parse

@pytest.mark.parametrize('name',tuple(env.REQUIRED))
@pytest.mark.parametrize('value',[None,'AUTO','bad',True])
def test_explicit_environment_rejects_inherited_optional_backend(monkeypatch,name,value):
    for key,val in env.REQUIRED.items():monkeypatch.setenv(key,val)
    if value is None:monkeypatch.delenv(name)
    else:monkeypatch.setenv(name,str(value))
    with pytest.raises(ValueError):env.check()


def test_child_environment_overrides_all_optional_backends(monkeypatch):
    for key in env.REQUIRED:monkeypatch.setenv(key,'AUTO')
    actual=process.child_environment()
    assert {key:actual[key] for key in env.REQUIRED}==env.REQUIRED
    for key,val in env.REQUIRED.items():monkeypatch.setenv(key,val)
    assert env.check()==env.REQUIRED


def test_constructor_guard_rejects_and_restores():
    class Module:
        def __init__(self):pass
    original=Module.__init__;calls=[];torch=SimpleNamespace(nn=SimpleNamespace(Module=Module))
    with smoke.no_model_construction(torch,calls):
        with pytest.raises(PermissionError):Module()
    assert Module.__init__ is original and calls==['torch.nn.Module.__init__']


@pytest.mark.parametrize('kind',[ValueError,KeyboardInterrupt,SystemExit])
def test_constructor_guard_preserves_body_and_restores(kind):
    class Module:
        def __init__(self):pass
    original=Module.__init__;primary=kind('body');torch=SimpleNamespace(nn=SimpleNamespace(Module=Module))
    with pytest.raises(kind) as got:
        with smoke.no_model_construction(torch,[]):raise primary
    assert got.value is primary and Module.__init__ is original


def test_import_smoke_has_no_actual_runtime_or_asset_reader_calls():
    tree=ast.parse(Path(smoke.__file__).read_text())
    called={n.func.attr if isinstance(n.func,ast.Attribute) else n.func.id if isinstance(n.func,ast.Name) else ''
            for n in ast.walk(tree) if isinstance(n,ast.Call)}
    assert not called.intersection({'execute','model_assets','from_pretrained','forward','Tokenizer','Reader'})
    assert {'backend_check','check','no_model_construction'}<=called


def test_import_mode_rejects_private_or_actual_grant_before_output(tmp_path,monkeypatch):
    a=args(tmp_path);a.mode='import-smoke-worker'
    monkeypatch.setattr(process,'Output',lambda *a:pytest.fail('output created'))
    with pytest.raises(ValueError):process.import_worker(a,{},blobs(),{},tmp_path/'source')


def test_import_mode_audits_all_bodies_false(tmp_path,monkeypatch):
    a=args(tmp_path);a.mode='import-smoke-worker';a.private_output=None
    audit=[]
    monkeypatch.setattr(process,'validate_paths',lambda *a:None)
    monkeypatch.setattr(process,'install_audit',lambda b,allow,diagnostics=None:audit.append(allow) or [])
    monkeypatch.setattr(process,'dependencies',lambda b:{})
    monkeypatch.setattr(process,'source_end',lambda *a:{})
    monkeypatch.setattr(process,'enable_model_imports',lambda:None)
    monkeypatch.setattr(env,'check',lambda:dict(env.REQUIRED))
    monkeypatch.setattr(smoke,'run',lambda b:{'import_smoke_completed':True,'model_class_imported':True})
    assert process.import_worker(a,{},blobs(),{},tmp_path/'source')==0
    report=parse((Path(a.output)/'report.json').read_bytes())
    assert audit==[False] and report['passed']is True and report['model_forward']is False


@pytest.mark.parametrize('event_count',[0,1])
def test_worker_reports_real_forward_events_on_failure(tmp_path,monkeypatch,event_count):
    a=args(tmp_path)
    monkeypatch.setattr(process,'validate_paths',lambda *a:None)
    monkeypatch.setattr(process,'grant_check',lambda *a:None)
    monkeypatch.setattr(process,'install_audit',lambda *a:[])
    monkeypatch.setattr(process,'dependencies',lambda b:{})
    monkeypatch.setattr(process,'source_end',lambda *a:{})
    monkeypatch.setattr(process,'enable_model_imports',lambda:None)
    class Reader:
        loaded=False
        def __init__(self,*args):pass
        def recheck(self):pass
    monkeypatch.setattr(process.input_gate,'Reader',Reader)
    def execute(b,reader,private,progress):
        if event_count:
            progress({'stage':'model_loaded','model_loaded':True})
            progress({'stage':'native_forward_started','native_forward_started':1})
        raise ValueError('failure before materialized forward')
    monkeypatch.setitem(sys.modules,'model_runtime',SimpleNamespace(execute=execute))
    with pytest.raises(ValueError):process.worker(a,{},blobs(),{},tmp_path/'source')
    r=parse((Path(a.output)/'report.json').read_bytes())
    assert r['passed']is False and r['native_forward_completed']==0
    assert r['native_forward_started']==event_count and r['model_forward']is bool(event_count)
    assert r['model_loaded']is bool(event_count)


def test_smoke_audit_records_stack_only_and_still_denies(monkeypatch):
    hooks=[];monkeypatch.setattr(process.sys,'addaudithook',hooks.append)
    details=[];denied=process.install_audit(blobs(),False,diagnostics=details)
    with pytest.raises(PermissionError):hooks[0]('socket.getaddrinfo',('sensitive-host',1234))
    assert denied==['network'] and details[0]['event']=='socket.getaddrinfo'
    assert details[0]['stack'] and 'sensitive-host' not in repr(details)
