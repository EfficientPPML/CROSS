"""Isolated combined candidate regression; no live repository imports."""
from pathlib import Path
import hashlib,importlib.metadata,io,json,os,subprocess,sys,tarfile,time
HERE=Path(__file__).resolve().parent;ROOT=HERE/'checkout';OUT=HERE/'evidence'
assert os.environ.get('JAX_PLATFORMS')=='cpu'
def snapshot():
 paths=[Path(__file__),HERE/'test_scoped_ntt.py',HERE/'check_integrated.py',*OUT.glob('*.py')]
 for folder in ('jaxite_word','cadathlon/common','cadathlon/tests'):
  paths.extend((ROOT/folder).rglob('*.py'))
 for folder in ('cadathlon/agent_pset/p2_bert/test','cadathlon/agent_pset/p4_qwen/test'):
  paths.extend(p for p in (ROOT/folder).rglob('*') if p.is_file())
 return {str(p.relative_to(HERE)):p.read_bytes() for p in sorted(set(paths))}
data=snapshot();before={p:hashlib.sha256(b).hexdigest() for p,b in data.items()}
with tarfile.open(OUT/'tested_sources.tar.gz','w:gz') as tar:
 for name,content in data.items():
  info=tarfile.TarInfo(name);info.size=len(content);tar.addfile(info,io.BytesIO(content))
paths=[str(OUT/'test_direct_linear.py'),str(HERE/'test_scoped_ntt.py'),str(OUT/'test_secure_direct_linear.py')]
paths += [str(ROOT/'cadathlon/tests'/f'test_{name}.py') for name in ('packed_transformer','bounded_transformer_plan','bounded_shared_preparation','bounded_contracts','bounded_reference_preflight','encrypted_bounded_metadata','encrypted_reference_lifecycle','encrypted_rotation','encrypted_primitives','encrypted_compilation','encrypted_polynomial','encrypted_refresh','package','bert_staging')]
paths += [str(ROOT/'jaxite_word'/f'{name}_test.py') for name in ('key_gen','herot','ckks_ctx','ckks_level_ops','ntt_mm')]
command=[sys.executable,'-m','pytest','-q','--tb=short',f'--junitxml={OUT/"tests.xml"}',*paths]
env=dict(os.environ,PYTHONPATH=str(ROOT)+':'+str(ROOT/'jaxite_word')+':'+str(ROOT/'cadathlon/common'),CROSS_ROOT=str(ROOT),CROSS_TEST_CHUNKED_SECURE='1')
started=time.monotonic()
with (OUT/'tests.log').open('w') as log:result=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
after={p:hashlib.sha256(b).hexdigest() for p,b in snapshot().items()}
report={'scope':'Isolated giant scheduling + native keygen arrays + opt-in owner-scoped NTT reuse. Includes actual secure shallow component parity and all twelve ideal packed graph contracts; no full encrypted graph or accelerator timing.',
 'passed':result.returncode==0 and before==after,'returncode':result.returncode,'source_files_unchanged':before==after,'source_hashes_before':before,'source_hashes_after':after,
 'command':command,'environment':{k:env.get(k) for k in ('JAX_PLATFORMS','CROSS_ROOT','PYTHONPATH','CROSS_TEST_CHUNKED_SECURE','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')},
 'affinity':sorted(os.sched_getaffinity(0)),'seconds':time.monotonic()-started,'versions':{k:importlib.metadata.version(k) for k in ('jax','jaxlib','numpy','pytest')}}
(OUT/'combined_tests.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if not k.startswith('source_hashes')},indent=2),flush=True)
raise SystemExit(0 if report['passed'] else 1)
