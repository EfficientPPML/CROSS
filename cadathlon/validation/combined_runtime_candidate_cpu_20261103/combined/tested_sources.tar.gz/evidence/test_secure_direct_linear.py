"""Actual secure component parity; not a full transformer/runtime claim."""
import json
import math
import os
from pathlib import Path
import sys
import time
import weakref

LAB = Path(__file__).resolve().parent
ROOT = LAB.parent/'checkout'
sys.path[:0] = [str(LAB), str(ROOT), str(ROOT/'cadathlon/common')]
import numpy as np
import pytest
from encrypted_packed_transformer import (PackedTransformer as ChunkedPackedTransformer,
    PackedPairLayout, output_payload_bytes, pending_limit)
from encrypted_bounded_transformer import BoundedPackedTransformer as ChunkedBoundedPackedTransformer
from baseline_linear import (BaselinePackedTransformer as PackedTransformer,
    BaselineBoundedPackedTransformer as BoundedPackedTransformer)
from encrypted_packed_qwen import MatrixDiagonals


@pytest.mark.skipif(os.environ.get('CROSS_TEST_CHUNKED_SECURE') != '1', reason='explicit secure CPU component run')
def test_actual_secure_chunked_linear_exact_residues_contracts_and_control_lifetimes():
    import jax
    from jaxite_word import CKKSContext, key_gen, util, he_params, ckks_ctx
    from jaxite_word.composite_prime_gen import composite_prime_gen
    from encrypted_refresh import ClientRotationKeyStore
    from encrypted_ntt import enable_scoped_ntt_subsets
    assert os.environ.get('JAX_PLATFORMS') == 'cpu'
    jax.config.update('jax_enable_x64', True)
    degree, depth, dnum = 8192, 1, 2
    q = composite_prime_gen(2, 2*(depth+1), 61, 56, 2*degree, 31)
    p = util.generate_p_towers(q, dnum, degree, aux_bits=30)
    assert he_params.qp_is_secure(q, p, degree, he_params.SecurityTarget(128, 'classical'))
    he_params.assert_p_coverage(q, p, dnum)
    layout = PackedPairLayout(1, 2, 8, degree//2)
    rng = np.random.default_rng(20261102)
    cases = [(rng.uniform(-.08, .08, (8, 7)), rng.uniform(-.01, .01, 8), True, 1.),
             (rng.uniform(-.08, .08, (5, 8)), rng.uniform(-.01, .01, 5), False, 1.125)]
    rotations = sorted(set().union(*(MatrixDiagonals(w, layout.slots, layout.features).rotations for w, _, _, _ in cases)))
    keys = key_gen.gen_pke_pair(q, [], degree)
    evaluation = key_gen.gen_evaluation_key(keys['secret_key'], q=q, P=p, dnum=dnum)
    store = ClientRotationKeyStore.generate(keys['secret_key'], q, p, degree=degree, dnum=dnum, rotations=rotations)
    scale = float(q[-2])*q[-1]
    params = dict(degree=degree, num_slots=degree//2, scaling_factor=scale, output_scale=scale,
        q_towers=q, p_towers=p, composite_degree=2, degree_layout=(64, 128), p=56,
        CKKS_M_FACTOR=1, max_bits_in_word=61, noise_scale_degree=1)
    client = CKKSContext(dict(params, **keys))
    server = CKKSContext(dict(params, evaluation_key=[jax.numpy.asarray(evaluation[name], dtype='uint32').transpose(0, 2, 1) for name in ('a', 'b')]))
    server.program_initialization(rotations, dnum=dnum, r=64, c=128, batch=1, pregenerated_rotation_keys=store.keys)
    provider = enable_scoped_ntt_subsets(server)
    assert server._param_cache.rotation_polynomial_factory.__self__ is provider
    client._polynomial_ntt_ctx = server._param_cache.ntt_q_max
    assert server.secret_key is None and server._param_cache.secret_key is None and server.parameters.get('secret_key') is None
    def forbidden(*args, **kwargs): raise AssertionError('server encrypt/decrypt forbidden')
    server.encrypt = server.decrypt = server.encrypt_slots = server.decrypt_slots = forbidden
    report = dict(scope='Secure shallow packed-linear component parity only; no refresh/full graph/TPU claim',
        ring=dict(degree=degree, depth=depth, dnum=dnum, q_count=len(q), p_count=len(p), actual_log2_qp=sum(map(math.log2, q+p)), security_bits=128), cases=[])
    try:
        slots = np.tile(rng.uniform(-.12, .12, layout.period), layout.slots//layout.period)
        mask = np.tile(rng.uniform(-1., 1., layout.period), layout.slots//layout.period)
        for number, (weight, bias, masked, scale_factor) in enumerate(cases):
            encrypted = client.encrypt_slots(slots, scale=scale*scale_factor)
            mask_arg = mask if masked else None
            source = MatrixDiagonals(weight, layout.slots, layout.features)
            groups = len({d//source.n1*source.n1 for d in source.active})
            assert groups >= 2
            for bounded in (False, True):
                outputs, details = [], []
                for candidate in (False, True):
                    cls = ((ChunkedBoundedPackedTransformer if candidate else BoundedPackedTransformer)
                           if bounded else (ChunkedPackedTransformer if candidate else PackedTransformer))
                    graph = cls(server, layout, None, low_memory=True) if bounded else cls(server, layout, low_memory=True)
                    graph.linear_max_pending = 3
                    graph.linear_extra_payload_bytes = 2*output_payload_bytes(graph, encrypted)
                    count = dict(clears=0)
                    original_clear = graph.arithmetic._clear_working_caches
                    def counted_clear():
                        count['clears'] += 1
                        return original_clear()
                    graph.arithmetic._clear_working_caches = counted_clear
                    queued_contexts = []
                    original_sum = graph.arithmetic.weighted_sum
                    def observed_sum(*args, **kwargs):
                        result = original_sum(*args, **kwargs)
                        # If prior queued results still exist, completed outputs
                        # must share their public NTT context, not duplicate it.
                        live = [ref() for ref in queued_contexts if ref() is not None]
                        assert all(item.ntt_ctx is result.ntt_ctx for item in live)
                        queued_contexts.append(weakref.ref(result))
                        return result
                    graph.arithmetic.weighted_sum = observed_sum
                    if bounded:
                        graph.arithmetic.declare_bound(encrypted, .12)
                        encrypted._public_row_l2_bound = .4
                        encrypted._public_normalization_affine = ((1.,)*weight.shape[1], (0.,)*weight.shape[1], .4)
                        graph._head_contract = (2, 4) if weight.shape[0] == 8 else None
                    original_relations = {k:v for k,v in encrypted.__dict__.items() if k.startswith('_public_')}
                    started = time.monotonic()
                    result = graph.linear(encrypted, weight, bias, input_mask=mask_arg)
                    result.polynomial.block_until_ready()
                    observed = client.decrypt_slots(result)
                    expected = np.zeros((layout.slots//layout.features, layout.features))
                    x = slots.reshape(-1, layout.features)
                    masked_x = x if mask_arg is None else x*mask_arg.reshape(-1, layout.features)
                    expected[:, :weight.shape[0]] = masked_x[:, :weight.shape[1]] @ weight.T + bias
                    error = float(np.max(np.abs(observed-expected.reshape(-1))))
                    assert error < 2e-7
                    outputs.append(dict(payload=np.asarray(result.polynomial).copy(), scale=result._ckks_scale,
                        nsd=result._ckks_nsd, moduli=tuple(result.moduli), public={k:v for k,v in result.__dict__.items() if k.startswith('_public_')}))
                    assert {k:v for k,v in encrypted.__dict__.items() if k.startswith('_public_')} == original_relations
                    assert graph.arithmetic._level(result) == 0 and result._ckks_nsd == 1
                    if bounded:
                        assert not graph.arithmetic.refresh_events
                        assert hasattr(result, '_public_row_l2_bound')
                        assert not hasattr(result, '_public_normalization_affine')
                        if graph._head_contract is not None:
                            assert len(result._public_head_l2_bounds) == 2
                    details.append(dict(candidate=candidate, seconds=time.monotonic()-started, max_abs_error=error,
                        cache_clears=count['clears'], groups=groups,
                        output_payload_bytes=output_payload_bytes(graph, encrypted),
                        pending_limit=pending_limit(output_payload_bytes(graph, encrypted), groups,
                            extra_payload_bytes=graph.linear_extra_payload_bytes, max_pending=graph.linear_max_pending) if candidate else 1))
                    graph.arithmetic.checkpoint(result, 'isolated linear completed')
                    del result, graph
                np.testing.assert_array_equal(outputs[0].pop('payload'), outputs[1].pop('payload'))
                assert outputs[0] == outputs[1]
                assert details[1]['cache_clears'] <= details[0]['cache_clears']
                if groups >= 3:
                    assert details[1]['cache_clears'] < details[0]['cache_clears']
                report['cases'].append(dict(number=number, bounded=bounded, variants=details, exact_payload_and_metadata=True))
        assert provider.stats['builds'] > 0
        report['ntt_subsets_enabled'] = True
        report['ntt_provider_stats'] = dict(provider.stats)
        report['passed'] = True
    finally:
        provider.close()
        ckks_ctx.evict_context_caches(client)
        ckks_ctx.evict_context_caches(server)
        store.close()
    (LAB/'secure_result.json').write_text(json.dumps(report, indent=2)+'\n')
