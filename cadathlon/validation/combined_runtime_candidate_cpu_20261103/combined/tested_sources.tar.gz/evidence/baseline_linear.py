"""Test-only exact original linear method; no runtime fallback."""
import numpy as np
from encrypted_packed_qwen import MatrixDiagonals
from encrypted_packed_transformer import PackedTransformer
from encrypted_bounded_transformer import BoundedPackedTransformer

def baseline_linear(self, value, weight, bias=None, *, input_mask=None):
    """One-level sparse BSGS with one active rotation key at a time."""
    source = MatrixDiagonals(weight, self.layout.slots, self.features)
    if bias is not None and np.shape(bias) != (source.weight.shape[0],):
        raise ValueError('packed linear bias differs from output rows')
    if input_mask is not None:
        input_mask = np.asarray(input_mask, dtype=np.float64)
        if input_mask.shape != (self.layout.slots,) or not np.isfinite(input_mask).all():
            raise ValueError('packed linear mask must be a finite full slot vector')
    bias_slots = 0. if bias is None else self.layout.feature(bias)
    if not source.active:
        return self.arithmetic.weighted_sum([value], [0.], bias=bias_slots)
    (value,) = self.arithmetic._ensure_capacity((value,), 1)
    babies = {0: value}
    for index in sorted({d % source.n1 for d in source.active} - {0}):
        babies[index] = self.arithmetic.rotate(value, index)
    groups = {}
    for diagonal in source.active:
        giant = diagonal // source.n1 * source.n1
        groups.setdefault(giant, []).append(diagonal)
    result = None
    for giant, indices in groups.items():
        diagonals = source.materialize_diagonals(indices)
        values, weights = [], []
        for index in indices:
            diagonal = diagonals[index]
            if input_mask is not None:
                # The mask belongs to the source coordinate of each
                # diagonal, including masks that vary within a block.
                diagonal = diagonal * np.roll(input_mask, -index)
            values.append(babies[index % source.n1])
            weights.append(np.roll(diagonal, giant))
        inner = self.arithmetic.weighted_sum(values, weights)
        contribution = self.arithmetic.rotate(inner, giant)
        result = contribution if result is None else self.arithmetic.add(result, contribution)
    if bias is not None:
        level = self.arithmetic._level(result)
        self.arithmetic._prepare(level)
        constant = self.arithmetic._encode_public(bias_slots, level, result._ckks_scale)
        result = self.ctx.he_add[level].add_plain(result, constant)
    return self.arithmetic._finish(result)

class BaselinePackedTransformer(PackedTransformer):
    linear = baseline_linear

class BaselineBoundedPackedTransformer(BoundedPackedTransformer, BaselinePackedTransformer):
    pass
