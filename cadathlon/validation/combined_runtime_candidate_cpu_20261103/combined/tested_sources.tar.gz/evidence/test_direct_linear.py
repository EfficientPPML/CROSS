"""Isolated scheduling contracts; execute only after CPU calibration release."""
from pathlib import Path
from types import SimpleNamespace
import gc
import sys
import weakref

LAB = Path(__file__).resolve().parent
ROOT = LAB.parent/'checkout'
sys.path[:0] = [str(LAB), str(ROOT), str(ROOT/'cadathlon/common')]
import numpy as np
import pytest
from encrypted_packed_transformer import (pending_limit, output_payload_bytes, giant_chunks,
    PackedTransformer as ChunkedPackedTransformer, PackedPairLayout)
from encrypted_bounded_transformer import BoundedPackedTransformer as ChunkedBoundedPackedTransformer
from baseline_linear import (BaselinePackedTransformer as PackedTransformer,
    BaselineBoundedPackedTransformer as BoundedPackedTransformer)


@pytest.mark.parametrize('size,groups,budget,maximum,expected', [
    (512*1024**2, 16, 256*1024**2, 8, 1),
    (256*1024**2, 16, 256*1024**2, 8, 2),
    (85*1024**2, 16, 256*1024**2, 8, 4),
    (16*1024**2, 16, 256*1024**2, 8, 8),
    (16*1024**2, 3, 256*1024**2, 8, 3),
    (16, 3, 0, 8, 1), (16, 3, 500, 1, 1), (None, 3, 500, 8, 1),
])
def test_payload_cap(size, groups, budget, maximum, expected):
    count = pending_limit(size, groups, extra_payload_bytes=budget, max_pending=maximum)
    assert count == expected
    if size is not None:
        assert (count-1)*size <= budget


@pytest.mark.parametrize('size,groups,budget,maximum', [
    (0, 3, 5, 2), (True, 3, 5, 2), (1, 0, 5, 2), (1, True, 5, 2),
    (1, 3, -1, 2), (1, 3, True, 2), (1, 3, 5, 0), (1, 3, 5, True),
])
def test_invalid_payload_caps(size, groups, budget, maximum):
    with pytest.raises(ValueError):
        pending_limit(size, groups, extra_payload_bytes=budget, max_pending=maximum)


@pytest.mark.parametrize('batch,level', [(1, 1), (2, 25), (1, 49)])
def test_output_bytes_include_batch_components_degree_remaining_limbs_and_dtype(batch, level):
    value = SimpleNamespace(polynomial=SimpleNamespace(shape=(batch, 2, 256, 512, 2*(level+1)), dtype='uint32'))
    graph = SimpleNamespace(ctx=SimpleNamespace(_param_cache=SimpleNamespace(num_q_at_level=lambda n: 2*(n+1))),
                            arithmetic=SimpleNamespace(_level=lambda _: level))
    assert output_payload_bytes(graph, value) == batch*2*131072*(2*level)*4


@pytest.mark.parametrize('limit', [1, 2, 3, 8])
def test_queue_peak_and_consumed_reference_retirement(limit):
    alive = weakref.WeakSet()
    made, consumed, peak = [], [], 0
    class Token: pass
    def make(giant, indices):
        nonlocal peak
        token = Token()
        token._public_absolute_bound = giant + 1
        alive.add(token)
        peak = max(peak, len(alive))
        made.append(giant)
        return token
    for giant, token in giant_chunks([(n, [n]) for n in range(19)], make, limit):
        assert token._public_absolute_bound == giant + 1
        consumed.append(giant)
        del token
    assert made == consumed == list(range(19))
    assert peak <= limit
    assert not alive


def test_queue_releases_unconsumed_items_on_failure_and_generator_close():
    alive = weakref.WeakSet()
    class Token: pass
    def make(giant, indices):
        if giant == 2:
            raise RuntimeError('inner failure')
        item = Token(); alive.add(item); return item
    with pytest.raises(RuntimeError, match='inner failure'):
        next(giant_chunks([(n, [n]) for n in range(4)], make, 4))
    gc.collect()
    assert not alive
    iterator = giant_chunks([(0, []), (1, [])], make, 2)
    giant, token = next(iterator)
    del token
    iterator.close()
    gc.collect()
    assert not alive


class Value:
    def __init__(self, slots, level):
        self.slots, self.level, self._ckks_scale = np.asarray(slots), level, 1.
        self.polynomial = SimpleNamespace(shape=(1, 2, 8, 8, 2*(level+1)), dtype='uint32')


class PlanningArithmetic:
    def __init__(self, slots):
        self.events, self.transitions, self.active_level = [], [], None
        self.ctx = SimpleNamespace(num_slots=slots,
            _param_cache=SimpleNamespace(num_q_at_level=lambda level: 2*(level+1)))
        self.ctx.he_add = AddAccessor(self)
    def _level(self, value): return value.level
    def _ensure_capacity(self, values, required): return tuple(values)
    def _finish(self, value): return value
    def _prepare(self, level):
        if self.active_level != level:
            self.transitions.append(level); self.active_level = level
    def weighted_sum(self, values, weights, bias=0.):
        values, weights = tuple(values), tuple(weights)
        level = min(x.level for x in values); self._prepare(level)
        out = sum(value.slots*weight for value, weight in zip(values, weights)) + bias
        self.events.append(('weighted', out.tobytes()))
        return Value(out, level-1)
    def rotate(self, value, shift):
        if shift % self.ctx.num_slots:
            self._prepare(value.level)
        out = np.roll(value.slots, -shift)
        self.events.append(('rotate', shift, out.tobytes()))
        return Value(out, value.level)
    def add(self, left, right):
        self._prepare(min(left.level, right.level))
        out = left.slots+right.slots
        self.events.append(('add', out.tobytes()))
        return Value(out, min(left.level, right.level))
    def _encode_public(self, slots, level, scale): return Value(slots, level)


class AddAccessor:
    def __init__(self, arithmetic): self.arithmetic = arithmetic
    def __getitem__(self, level): return SimpleNamespace(add_plain=self.arithmetic.add)


def graph_of(cls, layout):
    graph = object.__new__(cls)
    graph.layout, graph.features = layout, layout.features
    graph.arithmetic = PlanningArithmetic(layout.slots)
    graph.ctx = graph.arithmetic.ctx
    return graph


@pytest.mark.parametrize('shape', [(8, 7), (5, 8)])
@pytest.mark.parametrize('with_mask', [False, True])
@pytest.mark.parametrize('limit', [1, 2, 8])
def test_linear_exact_float_order_masks_and_bias(shape, with_mask, limit):
    rng = np.random.default_rng(31)
    layout = PackedPairLayout(1, 2, 8, 64)
    value = Value(rng.normal(size=layout.slots), 4)
    weight, bias = rng.normal(size=shape), rng.normal(size=shape[0])
    mask = rng.uniform(-1., 1., layout.slots) if with_mask else None
    before = graph_of(PackedTransformer, layout)
    after = graph_of(ChunkedPackedTransformer, layout)
    after.linear_max_pending = limit
    expected = before.linear(value, weight, bias, input_mask=mask)
    actual = after.linear(value, weight, bias, input_mask=mask)
    np.testing.assert_array_equal(actual.slots, expected.slots)
    assert actual.level == expected.level
    for kind in ('weighted', 'rotate', 'add'):
        assert [e for e in before.arithmetic.events if e[0] == kind] == [e for e in after.arithmetic.events if e[0] == kind]
    assert len(after.arithmetic.transitions) <= len(before.arithmetic.transitions)
    if limit == 1:
        assert after.arithmetic.events == before.arithmetic.events


def test_zero_matrix_fast_path_and_symbolic_fallback():
    layout = PackedPairLayout(1, 2, 8, 64)
    before, after = graph_of(PackedTransformer, layout), graph_of(ChunkedPackedTransformer, layout)
    value = Value(np.ones(layout.slots), 4)
    expected = before.linear(value, np.zeros((5, 8)), np.arange(5)*.01)
    actual = after.linear(value, np.zeros((5, 8)), np.arange(5)*.01)
    np.testing.assert_array_equal(actual.slots, expected.slots)
    assert after.arithmetic.events == before.arithmetic.events
    assert output_payload_bytes(after, SimpleNamespace(level=4)) is None


def test_direct_runtime_classes_keep_the_bounded_semantic_wrapper():
    from encrypted_packed_transformer import PackedTransformer as DirectPacked
    from encrypted_bounded_transformer import BoundedPackedTransformer as DirectBounded
    assert ChunkedPackedTransformer is DirectPacked
    assert ChunkedBoundedPackedTransformer is DirectBounded
    assert DirectBounded.__mro__[1] is DirectPacked
    assert DirectBounded.linear is BoundedPackedTransformer.linear
