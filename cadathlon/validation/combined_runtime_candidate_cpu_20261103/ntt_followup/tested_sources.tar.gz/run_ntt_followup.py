"""Fresh-process second-device guard and secure scoped-NTT component followup."""
from pathlib import Path
import hashlib,io,json,os,subprocess,sys,tarfile,time
HERE=Path(__file__).resolve().parent;ROOT=HERE/'checkout';OUT=HERE/'ntt_followup';OUT.mkdir(exist_ok=False)
paths=[Path(__file__),HERE/'check_integrated.py',ROOT/'cadathlon/tests/test_scoped_ntt.py']
for folder in ('jaxite_word','cadathlon/common'):paths.extend((ROOT/folder).glob('*.py'))
data={str(p.relative_to(HERE)):p.read_bytes() for p in sorted(set(paths))};before={n:hashlib.sha256(b).hexdigest() for n,b in data.items()}
with tarfile.open(OUT/'tested_sources.tar.gz','w:gz') as archive:
 for name,content in data.items():
  info=tarfile.TarInfo(name);info.size=len(content);archive.addfile(info,io.BytesIO(content))
env=dict(os.environ,JAX_PLATFORMS='cpu',XLA_FLAGS='--xla_force_host_platform_device_count=2',
 PYTHONPATH=str(ROOT)+':'+str(ROOT/'jaxite_word')+':'+str(ROOT/'cadathlon/common'),CROSS_ROOT=str(ROOT))
commands=[('second_device',[sys.executable,'-m','pytest','-q',str(ROOT/'cadathlon/tests/test_scoped_ntt.py')+'::test_guards_fall_back[other_device]']),
          ('secure_batch_level',[sys.executable,str(HERE/'check_integrated.py')])]
results=[];start=time.monotonic()
for name,command in commands:
 t=time.monotonic()
 with (OUT/(name+'.log')).open('w') as log:completed=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':command,'returncode':completed.returncode,'seconds':time.monotonic()-t})
 if completed.returncode:break
after={str(p.relative_to(HERE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths))}
raw=HERE/'integrated.json'
if raw.exists():(OUT/'integrated.json').write_bytes(raw.read_bytes())
report={'scope':__doc__,'passed':len(results)==2 and all(r['returncode']==0 for r in results) and before==after,
 'results':results,'seconds':time.monotonic()-start,'source_files_unchanged':before==after,'source_hashes_before':before,'source_hashes_after':after,
 'affinity':sorted(os.sched_getaffinity(0)),'environment':{k:env.get(k) for k in ('JAX_PLATFORMS','XLA_FLAGS','PYTHONPATH','CROSS_ROOT','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')}}
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if not k.startswith('source_hashes')},indent=2),flush=True)
raise SystemExit(0 if report['passed'] else 1)
