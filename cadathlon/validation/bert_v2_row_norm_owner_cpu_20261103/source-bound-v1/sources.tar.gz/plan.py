"""Public frozen-v2 row-norm depth/scale/resource planning; no backend or HE."""
from pathlib import Path
import argparse,hashlib,json,math,sys
import numpy as np
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'checkout/cadathlon/common'))
from encrypted_bert_v2_row_norm import V2RowNormContract,V2RowLayerNorm,row_norm_scale_plan,AFFINE_SHA256,COEFFICIENT_SHA256

def run():
    profile_raw=(HERE/'actual_profile_audit.json').read_bytes()
    if hashlib.sha256(profile_raw).hexdigest()!='2b2457e50da73b9ccf87984c089afcb99586fde863a48e98b89a1b7ccf872a17':raise ValueError('actual prime audit changed')
    p=next(x for x in json.loads(profile_raw)['profiles'] if x['name']=='depth49_p60_d8')
    raw=(HERE/'candidate_manifest.json').read_bytes();delta=p['canonical_scale'];rows={}
    for site in ('0.attention','0.mlp'):
        c=V2RowNormContract(raw,site);entries=[]
        for level in range(12,50):
            for scale in (math.nextafter(delta,-math.inf),delta,math.nextafter(delta,math.inf)):
                entries.append(row_norm_scale_plan(p['q'][:2*(level+1)],input_level=level,input_scale=scale,canonical_scale=delta,contract=c))
        intended=20 if site=='0.attention' else 24
        rows[site]=dict(domain=c.domain,degree=c.degree,method=c.method,epsilon=c.epsilon,
            coefficients_sha256=COEFFICIENT_SHA256[site],affine_raw_f32_sha256=AFFINE_SHA256[site],
            power_coefficient_l1=float(np.abs(np.polynomial.chebyshev.cheb2poly(c.coefficients)).sum()),
            intended_join=row_norm_scale_plan(p['q'][:2*(intended+1)],input_level=intended,input_scale=math.nextafter(delta,math.inf),canonical_scale=delta,contract=c),
            schedules=entries)
    rotations=V2RowLayerNorm.required_rotation_indices()
    result=dict(passed=True,scope=__doc__,encrypted_execution=False,backend_initialized=False,
        manifest_sha256=hashlib.sha256(raw).hexdigest(),actual_profile_audit_sha256=hashlib.sha256(profile_raw).hexdigest(),
        profile={k:p[k] for k in ('name','degree','slots','depth','dnum','Q_count','P_count','log2_QP','security_ceiling','actual_128_bit_QP_secure','P_covers_each_partition','canonical_scale')},
        row_layout=dict(slots=65536,feature_pitch=4096,active_features=768,rows=16,original_positions='strictly increasing valid-token indices0..127; caller establishes compaction'),
        sites=rows,rotation_indices=rotations,rotation_key_count=len(rotations),logical_rotations_per_tile=42,
        raw_rotation_pair_bytes=p['rotation_pair_bytes'],raw_22_rotation_pairs_bytes=len(rotations)*p['rotation_pair_bytes'],
        raw_key_storage_scope='Public raw keys only; excludes relinearization/public key, headers, formatted controls and runtime ciphertext memory.',
        limitations=['No v2 encrypted row-norm, full attention, FFN or full-model result.',
            'Historical measured RowLayerNorm used different inverse coefficients; this wrapper fixes the frozen v2 manifest.',
            'Each valid variance must lie within its declared site interval; no ciphertext range inspection or clipping.',
            'Actual binary64 metadata prediction excludes CKKS encoding, rescale, key-switch and propagated error.',
            'No implicit refresh or codec; caller owns context, input compaction and final model/file-stage contract.',
            'Input scale must be within existing1e-12 HEAdd compatibility of canonical scale; metadata is never reassigned.'])
    if any(n.split('.')[0] in ('jax','jaxlib','jaxite_word','torch','transformers') for n in sys.modules):raise ValueError('backend unexpectedly imported')
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();args.output.write_text(json.dumps(run(),indent=2,allow_nan=False)+'\n')
