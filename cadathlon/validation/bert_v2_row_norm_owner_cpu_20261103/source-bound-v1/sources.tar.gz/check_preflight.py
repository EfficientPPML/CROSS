"""Source-bound pure planning/layout/API tests for the v2 norm wrapper."""
from pathlib import Path
import argparse,hashlib,io,json,os,subprocess,sys,tarfile,time
HERE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inventory():
    files=list((HERE/'checkout').rglob('*.py'))
    files += [HERE/n for n in ('plan.py','check_preflight.py','test_v2_row_norm.py','test_v2_row_norm_contracts.py','candidate_manifest.json','actual_profile_audit.json','source_origin.json','gamma.npy','beta.npy','mlp_gamma.npy','mlp_beta.npy')]
    return {str(p.relative_to(HERE)):p for p in sorted(files)}
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def main(output):
    output.mkdir(parents=True,exist_ok=False);start=time.monotonic();paths=inventory();before={n:sha(p) for n,p in paths.items()}
    report=dict(passed=False,scope=__doc__,encrypted_execution=False,source_hashes_before=before,cpu_affinity=sorted(os.sched_getaffinity(0)));primary=None
    try:
        save(output/'report.json',report)
        with tarfile.open(output/'sources.tar.gz','w:gz') as archive:
            for n,p in paths.items():raw=p.read_bytes();member=tarfile.TarInfo(n);member.size=len(raw);archive.addfile(member,io.BytesIO(raw))
        with tarfile.open(output/'sources.tar.gz') as archive:
            members=archive.getmembers()
            if len(members)!=len(before) or len({m.name for m in members})!=len(before) or any(not m.isfile() for m in members):raise ValueError('archive inventory differs')
            if {m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in members}!=before:raise ValueError('archive bytes differ')
        report['source_archive_sha256']=sha(output/'sources.tar.gz');report['source_archive_verified']=True
        commands=[('public_plan',[sys.executable,str(HERE/'plan.py'),'--output',str(output/'public_plan.json')]),
            ('tests',[sys.executable,'-m','pytest','-q',str(HERE/'test_v2_row_norm.py'),str(HERE/'test_v2_row_norm_contracts.py')])]
        report['commands']=[]
        for name,command in commands:
            t=time.monotonic()
            with (output/(name+'.log')).open('w') as log:run=subprocess.run(command,cwd=HERE,stdout=log,stderr=subprocess.STDOUT)
            report['commands'].append(dict(name=name,returncode=run.returncode,elapsed_s=time.monotonic()-t))
            if run.returncode:raise RuntimeError(name+' failed')
        report['passed']=True
    except BaseException as error:primary=error;report['error']=dict(type=type(error).__name__,message=str(error))
    finally:
        try:
            after={n:sha(p) for n,p in paths.items()};report.update(source_hashes_after=after,source_files_unchanged=after==before)
            report['passed']=report['passed'] and after==before
        except BaseException as error:
            report['passed']=False
            if primary is None:primary=error
            else:primary.add_note('Final provenance: '+repr(error))
        report['elapsed_s']=time.monotonic()-start
        try:save(output/'report.json',report)
        except BaseException as error:
            if primary is None:raise
            primary.add_note('Final publication: '+repr(error))
    if primary is not None:raise primary
    return 0 if report['passed'] else 1
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    raise SystemExit(main(parser.parse_args().output))
