"""Pinned contracts and callback boundaries; no ciphertext execution."""
import copy
import math
from types import SimpleNamespace
import numpy as np
import pytest
from test_v2_row_norm import (norm, Arithmetic, Value, RAW, Q, DELTA, weights,
    setup, fixture, backend_free)


@pytest.mark.parametrize('site',('0.attention','0.mlp'))
@pytest.mark.parametrize('level',(12,20,24,49))
@pytest.mark.parametrize('scale',(math.nextafter(DELTA,-math.inf),DELTA,math.nextafter(DELTA,math.inf)))
def test_plan_matches_executed_primitive_metadata(site,level,scale):
    ops,owner=setup(site)
    result=owner.normalize_tile(Value(fixture(owner.contract,2),level,scale),
        valid_rows=2,original_positions=(0,127),capture_checkpoints=True)
    assert result.output.level==level-11
    assert len(result.plan['weighted_sum_stages'])==5
    assert result.plan['polynomial_depth']==6
    assert result.plan['range_verified'] is False
    assert result.plan['logical_rotations']==ops.calls.count('rotate')==42


def _replace(owner,name):
    if name=='arithmetic':owner.arithmetic=Arithmetic()
    elif name=='context':owner.ctx=copy.copy(owner.ctx)
    elif name=='cache':owner.ctx._param_cache=copy.copy(owner.ctx._param_cache)
    elif name=='layout':owner.layout=copy.copy(owner.layout)
    elif name=='contract':owner.contract=copy.copy(owner.contract)
    elif name=='approximation':owner.approximation=copy.copy(owner.approximation)
    elif name=='core':owner._core=copy.copy(owner._core)
    elif name=='gamma':owner.gamma=owner.gamma.copy()
    elif name=='beta':owner.beta=owner.beta.copy()
    elif name=='progress':owner.progress=lambda *args:None
    elif name=='core_context':owner._core.ctx=copy.copy(owner.ctx)
    elif name=='core_arithmetic':owner._core.arithmetic=Arithmetic()
    elif name=='core_layout':owner._core.layout=copy.copy(owner.layout)
    elif name=='rotation_mapping':owner.ctx._param_cache.raw_rotation_keys=dict(owner.ctx._param_cache.raw_rotation_keys)
    else:raise AssertionError(name)


@pytest.mark.parametrize('name',('arithmetic','context','cache','layout','contract','approximation','core','gamma','beta','progress','core_context','core_arithmetic','core_layout','rotation_mapping'))
@pytest.mark.parametrize('when',('before','mean','output'))
def test_owner_substitution_stops_before_next_primitive(name,when):
    at=[]
    def callback(label,value,metadata):
        if label.endswith(' '+when):
            at.append(len(ops.calls));_replace(owner,name)
    ops,owner=setup(progress=callback)
    source=Value(fixture(owner.contract,2))
    if when=='before':at.append(0);_replace(owner,name)
    with pytest.raises((ValueError,TypeError)):
        owner.normalize_tile(source,valid_rows=2,original_positions=(0,1))
    assert len(ops.calls)==at[0] and owner.last_run is None and not owner._active


MUTATIONS=(('epsilon',True),('epsilon',np.float64(1e-12)),('epsilon',1e-11),
    ('degree',True),('degree',12.0),('degree',16),('site','0.mlp'),
    ('method','chebyshev'),('domain',[0.2669251572966357,1.4255030943618103]),
    ('coefficients',None),('manifest_bytes',bytearray(RAW)))


@pytest.mark.parametrize('field,value',MUTATIONS)
@pytest.mark.parametrize('when',('before','mean','output'))
@pytest.mark.parametrize('mutator',('dict','object'))
def test_every_frozen_contract_field_typed_and_bound(field,value,when,mutator):
    at=[]
    def mutate():
        replacement=list(owner.contract.coefficients) if value is None else value
        if mutator=='dict':owner.contract.__dict__[field]=replacement
        else:object.__setattr__(owner.contract,field,replacement)
    def callback(label,*args):
        if label.endswith(' '+when):at.append(len(ops.calls));mutate()
    ops,owner=setup(progress=callback);source=Value(fixture(owner.contract,2))
    if when=='before':at.append(0);mutate()
    with pytest.raises((ValueError,TypeError)):
        owner.normalize_tile(source,valid_rows=2,original_positions=(0,1))
    assert len(ops.calls)==at[0] and owner.last_run is None and not owner._active


def _context_mutate(owner,kind):
    c=owner.ctx;k=c._param_cache
    if kind=='ctx_secret':c.secret_key=object()
    elif kind=='cache_secret':k.secret_key=object()
    elif kind=='parameter_secret':c.parameters['secret_key']=object()
    elif kind=='ctx_layout':c.degree_layout=(512,256)
    elif kind=='cache_layout':k.degree_layout=(512,256)
    elif kind=='cache_degree':k.degree=131072.
    elif kind=='ctx_cd':c.composite_degree=2.
    elif kind=='cache_cd':k.composite_degree=True
    elif kind=='batch':k.batch=True
    elif kind=='dnum':k.dnum=4
    elif kind=='q':k.q_towers[2]=k.q_towers[3]
    elif kind=='p':k.p_towers[0]=k.p_towers[1]
    elif kind=='scale':owner.arithmetic.scale=math.nextafter(DELTA,math.inf)
    elif kind=='strategy':owner.arithmetic.strategy='chebyshev'
    elif kind=='refresher':owner.arithmetic.refresher=object()
    elif kind=='key':k.raw_rotation_keys.pop(next(iter(k.raw_rotation_keys)))
    elif kind=='arithmetic_progress':owner.arithmetic.progress=lambda *args:None
    else:raise AssertionError(kind)


@pytest.mark.parametrize('kind',('ctx_secret','cache_secret','parameter_secret','ctx_layout','cache_layout','cache_degree','ctx_cd','cache_cd','batch','dnum','q','p','scale','strategy','refresher','key','arithmetic_progress'))
@pytest.mark.parametrize('when',('before','variance','output'))
def test_context_is_fixed_keyless_and_keys_present(kind,when):
    at=[]
    def callback(label,*args):
        if label.endswith(' '+when):at.append(len(ops.calls));_context_mutate(owner,kind)
    ops,owner=setup(progress=callback);source=Value(fixture(owner.contract,2))
    if when=='before':at.append(0);_context_mutate(owner,kind)
    with pytest.raises((ValueError,TypeError)):
        owner.normalize_tile(source,valid_rows=2,original_positions=(0,1))
    assert len(ops.calls)==at[0] and owner.last_run is None and not owner._active


@pytest.mark.parametrize('target',('input','result','centered'))
@pytest.mark.parametrize('change',('nsd_bool','nsd_float','scale','payload','layout','moduli'))
@pytest.mark.parametrize('when',('variance','output'))
def test_callback_input_retained_and_result_metadata(target,change,when):
    at=[];values={}
    def callback(label,result,*args):
        if label.endswith(' centered'):values['centered']=result
        if label.endswith(' '+when):
            # Centered has deliberately been released before the terminal
            # affine; no contract promises detection for dead intermediates.
            if target=='centered' and when=='output':return
            victim={'input':source,'result':result,'centered':values.get('centered')}[target]
            if change=='nsd_bool':victim._ckks_nsd=True
            elif change=='nsd_float':victim._ckks_nsd=1.
            elif change=='scale':victim._ckks_scale=math.nextafter(victim._ckks_scale,math.inf)
            elif change=='payload':victim.polynomial=victim.polynomial.copy()
            elif change=='layout':victim.degree_layout=(512,256)
            elif change=='moduli':victim.moduli=list(victim.moduli)
            at.append(len(ops.calls))
    if target=='centered' and when=='output':pytest.skip('dead intermediate is intentionally released')
    ops,owner=setup(progress=callback);source=Value(fixture(owner.contract,2))
    with pytest.raises((ValueError,TypeError)):
        owner.normalize_tile(source,valid_rows=2,original_positions=(0,1))
    assert len(ops.calls)==at[0] and owner.last_run is None and not owner._active


@pytest.mark.parametrize('positions',([0,1],(0,0),(1,0),(-1,1),(0,128),(False,1),(0.,1),(0,),()))
def test_original_positions_fail_before_arithmetic(positions):
    ops,owner=setup()
    with pytest.raises((ValueError,TypeError)):
        owner.normalize_tile(Value(fixture(owner.contract,2)),valid_rows=2,original_positions=positions)
    assert not ops.calls


@pytest.mark.parametrize('valid',(True,2.,0,17,-1))
def test_valid_rows_fail_before_arithmetic(valid):
    ops,owner=setup()
    with pytest.raises((ValueError,TypeError)):
        owner.normalize_tile(Value(np.zeros(65536)),valid_rows=valid,original_positions=(0,1))
    assert not ops.calls


@pytest.mark.parametrize('field,value',(('_ckks_nsd',True),('_ckks_nsd',1.),('_ckks_nsd',2),('_ckks_scale',math.nan),('_ckks_scale',math.inf),('_ckks_scale',DELTA*1.01),('batch',2),('batch',True),('batch',1.),('num_elements',3),('num_elements',2.),('degree',65536),('degree',131072.),('degree_layout',(512,256)),('degree_layout',[256,512])))
def test_input_rejection_before_primitive(field,value):
    ops,owner=setup();source=Value(fixture(owner.contract,2));setattr(source,field,value)
    with pytest.raises((ValueError,TypeError)):
        owner.normalize_tile(source,valid_rows=2,original_positions=(0,1))
    assert not ops.calls


def test_missing_keys_and_mutable_affine_rejected_at_construction():
    ops=Arithmetic();ops.ctx._param_cache.raw_rotation_keys.pop(1)
    with pytest.raises(ValueError,match='rotation keys'):norm.V2RowLayerNorm(ops,RAW,*weights('0.attention'))
    gamma,beta=weights('0.attention');gamma=gamma.astype(np.float64);gamma[0]+=1e-12
    with pytest.raises(ValueError,match='affine vector'):norm.V2RowLayerNorm(Arithmetic(),RAW,gamma,beta)
    _,owner=setup()
    with pytest.raises(ValueError):owner.gamma.flags.writeable=True
    assert owner.gamma.base is not None and isinstance(owner.gamma.base,bytes)


@pytest.mark.parametrize('exception',(KeyboardInterrupt,SystemExit))
def test_cancellation_reentry_and_borrowed_lifetime(exception):
    def callback(label,result,*args):
        with pytest.raises(ValueError,match='reentered'):
            owner.normalize_tile(source,valid_rows=2,original_positions=(0,1))
        raise exception('preserve cancellation')
    ops,owner=setup(progress=callback);source=Value(fixture(owner.contract,2));original_ctx=ops.ctx
    with pytest.raises(exception,match='preserve cancellation'):
        owner.normalize_tile(source,valid_rows=2,original_positions=(0,1))
    assert not owner._active and owner.last_run is None and owner.ctx is original_ctx


def test_contract_reconstruction_rejects_typed_alias_before_public_plan():
    contract=norm.V2RowNormContract(RAW);object.__setattr__(contract,'degree',12.)
    with pytest.raises(ValueError,match='fields changed'):
        norm.row_norm_scale_plan(Q[:42],input_level=20,input_scale=DELTA,canonical_scale=DELTA,contract=contract)


@pytest.mark.parametrize('kind',('missing_a','missing_b','nonmapping_pair','missing_map','none_map','nonmapping_maps','per_level','per_level_int','per_level_float'))
@pytest.mark.parametrize('when',('constructor','before','mean','output'))
def test_actual_key_pair_map_and_reusable_mode_required(kind,when):
    at=[]
    def corrupt(cache):
        if kind=='missing_a':cache.raw_rotation_keys[1].pop('a')
        elif kind=='missing_b':cache.raw_rotation_keys[1]['b']=None
        elif kind=='nonmapping_pair':cache.raw_rotation_keys[1]=object()
        elif kind=='missing_map':cache.coef_maps.pop(1)
        elif kind=='none_map':cache.coef_maps[1]=None
        elif kind=='nonmapping_maps':cache.coef_maps=[]
        elif kind=='per_level':cache.per_level_rotation_keys=True
        elif kind=='per_level_int':cache.per_level_rotation_keys=0
        elif kind=='per_level_float':cache.per_level_rotation_keys=0.
    if when=='constructor':
        ops=Arithmetic();corrupt(ops.ctx._param_cache)
        with pytest.raises(ValueError):norm.V2RowLayerNorm(ops,RAW,*weights('0.attention'))
        assert not ops.calls
        return
    def callback(label,*args):
        if label.endswith(' '+when):at.append(len(ops.calls));corrupt(ops.ctx._param_cache)
    ops,owner=setup(progress=callback);source=Value(fixture(owner.contract,2))
    if when=='before':at.append(0);corrupt(ops.ctx._param_cache)
    with pytest.raises(ValueError):owner.normalize_tile(source,valid_rows=2,original_positions=(0,1))
    assert len(ops.calls)==at[0] and owner.last_run is None and not owner._active


def test_planning_and_execution_have_no_codec_or_refresh_dependency():
    ops,owner=setup();source=Value(fixture(owner.contract,1))
    result=owner.normalize_tile(source,valid_rows=1,original_positions=(127,))
    assert result.checkpoints=={} and result.original_positions==(127,)
    assert owner.ctx is ops.ctx and ops.refresher is None
