"""Regression closure for the independent frozen-v1 API reproductions."""
import pytest
from test_v2_row_norm import backend_free,setup,fixture,Value,norm,Arithmetic,weights,RAW


@pytest.mark.parametrize('checkpoint',('mean','variance','inverse'))
@pytest.mark.parametrize('field,value',(('_ckks_nsd',True),('_ckks_nsd',1.),('_ckks_scale',1.),('degree_layout',(512,256)),('polynomial',None)))
def test_later_callback_cannot_corrupt_returned_checkpoint(checkpoint,field,value):
    seen={};at=[]
    def callback(label,result,metadata):
        name=label.rsplit(' ',1)[1];seen[name]=result
        if name=='output':
            setattr(seen[checkpoint],field,value);at.append(len(ops.calls))
    ops,owner=setup(progress=callback)
    with pytest.raises(ValueError,match='captured ciphertext'):
        owner.normalize_tile(Value(fixture(owner.contract,2)),valid_rows=2,original_positions=(0,1),capture_checkpoints=True)
    assert len(ops.calls)==at[0] and not owner._active and owner.last_run is None


def test_callback_annotations_are_stripped_from_current_and_prior_returns():
    seen=[]
    def callback(label,value,metadata):
        for previous in seen:previous._public_row_l2_bound=0.
        value._public_abs_bound=0.;seen.append(value)
    ops,owner=setup(progress=callback);source=Value(fixture(owner.contract,2));old_bound=source._public_row_l2_bound
    result=owner.normalize_tile(source,valid_rows=2,original_positions=(0,1),capture_checkpoints=True)
    assert all(not any(n.startswith('_public_') for n in vars(v)) for v in [result.output,*result.checkpoints.values()])
    assert source._public_row_l2_bound==old_bound


def test_bound_aware_arithmetic_rejected_at_construction():
    class BoundAware(Arithmetic):
        def declare_bound(self,value,bound):value._public_abs_bound=bound;return value
    ops=BoundAware()
    with pytest.raises(ValueError):norm.V2RowLayerNorm(ops,RAW,*weights('0.attention'))
    assert not ops.calls


@pytest.mark.parametrize('when',('before','mean','output'))
def test_inserted_bound_aware_capability_rejected_before_continuation(when):
    at=[]
    def change():ops.declare_bound=lambda value,bound:value
    def callback(label,*args):
        if label.endswith(' '+when):at.append(len(ops.calls));change()
    ops,owner=setup(progress=callback);source=Value(fixture(owner.contract,2))
    if when=='before':at.append(0);change()
    with pytest.raises(ValueError):owner.normalize_tile(source,valid_rows=2,original_positions=(0,1))
    assert len(ops.calls)==at[0] and not owner._active and owner.last_run is None
