"""Synthetic data mapping and overlap regressions; no old input/model reads."""
import copy
import pytest
import input_plan as p


def fixtures():
    prompts = [dict(id=f'C{i}', text=f'calibration fixture {i}') for i in range(96)]
    corpus = dict(calibration_prompts=prompts, decode_prompt_ids=[x['id'] for x in prompts[:16]])
    rows = [dict(id=x['id'], sequence_length=n, raw_token_count=40,
                 token_ids=[1000+i]+list(range(1,n)))
            for i,x in enumerate(prompts) for n in (8,16,32)]
    design = dict(prefix_lengths=list(range(1,33)), prompts=[dict(ordinal=i,text=f'new fixture {i}') for i in range(32)],
                  decode_seed_prompt_ordinals=list(range(0,32,4)), decode_seed_length=16,steps=4,
                  prefill_count=1024,teacher=32,free=32,total=1088)
    old = []
    for group in range(3):
        records = []
        for i in range(56):
            n = (8,16,32)[i//16] if i<48 else 16
            records.append(dict(kind='prefill' if i<48 else'decode',sequence_length=n,
                                token_ids=[3000+group*100+i]+list(range(1,n))))
        old.append(records)
    encode = lambda text: [2000+int(text.split()[-1])]+list(range(1,40))
    return corpus,rows,design,old,encode


def built():
    corpus,rows,design,old,encode=fixtures()
    return p.calibration(corpus,rows),p.validation(design,encode),old


def test_complete_mapping_and_future_decode_scope():
    cal,new,old=built();r=p.disjointness(cal,new,old)
    assert r['passed'] and r['future_decode_tokens_generated']is False
    assert r['calibration_workload_entries']==3200 and r['validation_workload_entries']==1088
    assert sum(x['original_prefill_member'] for x in cal['prefills'])==288
    assert [x['id']for x in cal['decode_seeds']]==[f'C{i}'for i in range(16)]
    assert all(x['entries']==96 for x in r['calibration_prefills'].values())
    assert all(x['entries']==32 for x in r['validation_prefills'].values())


@pytest.mark.parametrize('bad',[[True],[1.0],[-1],[151936],[],(1,2),None])
def test_token_contract_rejects_coercions(bad):
    with pytest.raises(ValueError):p.tokens(bad)


@pytest.mark.parametrize('length',[True,0,-1,1.,2])
def test_declared_length_is_exact(length):
    with pytest.raises(ValueError):p.tokens([1],length)


@pytest.mark.parametrize('change',['order','prefix','raw_length','alias_length','missing','seed','duplicate_id'])
def test_original_mapping_is_never_repaired_silently(change):
    corpus,rows,*_=fixtures()
    if change=='order':rows[0],rows[1]=rows[1],rows[0]
    elif change=='prefix':rows[1]['token_ids'][2]=9999
    elif change=='raw_length':rows[0]['raw_token_count']=31
    elif change=='alias_length':rows[0]['sequence_length']=8.
    elif change=='missing':rows.pop()
    elif change=='seed':corpus['decode_prompt_ids'][0]='absent'
    elif change=='duplicate_id':corpus['calibration_prompts'][1]['id']='C0'
    with pytest.raises(ValueError):p.calibration(corpus,rows)


@pytest.mark.parametrize('change',['ordinal','text_duplicate','seed','length_alias','prefix_alias','schedule','short'])
def test_new_design_failure_keeps_every_entry(change):
    _,_,design,_,encode=fixtures()
    if change=='ordinal':design['prompts'][0]['ordinal']=False
    elif change=='text_duplicate':design['prompts'][1]['text']=design['prompts'][0]['text']
    elif change=='seed':design['decode_seed_prompt_ordinals'][0]=True
    elif change=='length_alias':design['decode_seed_length']=16.
    elif change=='prefix_alias':design['prefix_lengths'][0]=True
    elif change=='schedule':design['steps']=3
    elif change=='short':encode=lambda text:[7]*31
    with pytest.raises(ValueError):p.validation(design,encode)


def test_short_prefix_overlap_rejects_without_dropping_duplicates():
    corpus,rows,design,old,_=fixtures()
    cal=p.calibration(corpus,rows)
    new=p.validation(design,lambda text:[1000]+list(range(1,40)))
    r=p.disjointness(cal,new,old)
    assert not r['passed'] and r['known_full_context_intersections']['1']['unique']==1
    assert r['validation_prefills']['1']==dict(entries=32,unique=1)
    assert r['validation_workload_entries']==1088


def test_row0_is_a_separate_excluded_input():
    corpus,rows,design,old,_=fixtures()
    new=p.validation(design,lambda text:[0]+list(range(1,40)))
    r=p.disjointness(p.calibration(corpus,rows),new,old)
    assert not r['passed'] and r['known_full_context_intersections']['1']['entries']==1


def test_unknown_future_extension_rejected_by_seed_prefix():
    cal,new,old=built();seed=list(new['decode_seeds'][0]['token_ids'])
    # An old32 input shares only the16-token seed; no new known full context is equal.
    old[0][32]['token_ids']=seed+[9999]*16
    r=p.disjointness(cal,new,old)
    assert not r['passed'] and r['known_full_context_intersections']=={}
    assert r['new_decode_seed_vs_excluded_context_prefixes']==1


def test_append_only_prefix_proof_for_arbitrary_suffixes():
    cal,new,old=built();assert p.disjointness(cal,new,old)['passed']
    prior=[tuple(x['token_ids'])for x in cal['decode_seeds']]
    for rows in old:prior += [tuple(x['token_ids'])for x in rows if x['kind']=='decode']
    for seed in new['decode_seeds']:
        for suffix in ((),(0,),(17,19),(151935,0,19),(1,2,3,4)):
            result=tuple(seed['token_ids'])+suffix
            assert all(result[:16]!=original for original in prior)


@pytest.mark.parametrize('change',['missing','wrong_kind','wrong_length','token_bool'])
def test_old_exclusion_inventory_must_be_complete(change):
    *_,old,encode=fixtures();rows=old[0]
    if change=='missing':rows.pop()
    elif change=='wrong_kind':rows[0]['kind']='teacher'
    elif change=='wrong_length':rows[48]['sequence_length']=32
    elif change=='token_bool':rows[0]['token_ids'][0]=True
    with pytest.raises(ValueError):p.old_inputs(rows)


def test_inputs_are_not_mutated():
    corpus,rows,design,old,encode=fixtures();before=copy.deepcopy((corpus,rows,design,old))
    p.disjointness(p.calibration(corpus,rows),p.validation(design,encode),old)
    assert (corpus,rows,design,old)==before
