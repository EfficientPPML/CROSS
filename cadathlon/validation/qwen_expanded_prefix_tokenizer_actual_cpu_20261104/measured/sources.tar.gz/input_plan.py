"""Pure input mapping and append-only disjointness; no filesystem/model access."""
from collections import Counter

VOCABULARY = 151936


def tokens(value, length=None):
    if length is not None and (type(length) is not int or length <= 0):
        raise ValueError('exact positive declared token length required')
    if type(value) is not list or not value or any(
        type(x) is not int or not 0 <= x < VOCABULARY for x in value
    ):
        raise ValueError('exact nonempty vocabulary token list required')
    if length is not None and len(value) != length:
        raise ValueError('declared token length differs')
    return tuple(value)


def calibration(corpus, rows):
    if type(corpus) is not dict or type(rows) is not list or len(rows) != 288:
        raise ValueError('original calibration input inventory required')
    prompts = corpus.get('calibration_prompts')
    seed_ids = corpus.get('decode_prompt_ids')
    if type(prompts) is not list or len(prompts) != 96:
        raise ValueError('exact original96 prompts required')
    ids = []
    for item in prompts:
        if type(item) is not dict or type(item.get('id')) is not str or not item['id']:
            raise ValueError('original prompt ID required')
        if type(item.get('text')) is not str or not item['text'].strip():
            raise ValueError('original prompt text required')
        ids.append(item['id'])
    if len(set(ids)) != 96 or type(seed_ids) is not list or len(seed_ids) != 16:
        raise ValueError('original prompt/seed inventory differs')
    if any(type(x) is not str for x in seed_ids) or len(set(seed_ids)) != 16 or not set(seed_ids) <= set(ids):
        raise ValueError('original seed ID mapping differs')
    index = {}
    for ordinal, row in enumerate(rows):
        if type(row) is not dict or set(row) != {'id', 'sequence_length', 'raw_token_count', 'token_ids'}:
            raise ValueError('original calibration row schema differs')
        length = row['sequence_length']
        if type(length) is not int or length != (8, 16, 32)[ordinal % 3] or row['id'] != ids[ordinal // 3]:
            raise ValueError('original calibration row order differs')
        if type(row['raw_token_count']) is not int or row['raw_token_count'] < 32:
            raise ValueError('original natural token length differs')
        index[(row['id'], length)] = (tokens(row['token_ids'], length), row['raw_token_count'])
    prefills = []
    for ordinal, name in enumerate(ids):
        full, natural = index[(name, 32)]
        if any(index[(name, n)] != (full[:n], natural) for n in (8, 16)):
            raise ValueError('original8/16/32 token prefixes differ')
        for length in range(1, 33):
            prefills.append(dict(prompt_ordinal=ordinal, id=name, sequence_length=length,
                                 token_ids=list(full[:length]), original_prefill_member=length in (8, 16, 32)))
    seeds = [dict(seed_ordinal=i, prompt_ordinal=ids.index(name), id=name,
                  token_ids=list(index[(name, 16)][0])) for i, name in enumerate(seed_ids)]
    return dict(prefills=prefills, decode_seeds=seeds)


def old_inputs(rows):
    if type(rows) is not list or len(rows) != 56:
        raise ValueError('complete old56 input set required')
    counts = Counter()
    contexts, seeds = [], []
    for row in rows:
        if type(row) is not dict or row.get('kind') not in ('prefill', 'decode'):
            raise ValueError('old input kind differs')
        length = row.get('sequence_length')
        if type(length) is not int:
            raise ValueError('exact old input length required')
        value = tokens(row.get('token_ids'), length)
        counts[(row['kind'], length)] += 1
        contexts.append(value)
        if row['kind'] == 'decode':
            seeds.append(value)
    if counts != {('prefill', 8): 16, ('prefill', 16): 16, ('prefill', 32): 16, ('decode', 16): 8}:
        raise ValueError('original old prefill/decode inventory differs')
    return contexts, seeds


def validation(design, encode):
    if (type(design) is not dict or type(design.get('prefix_lengths')) is not list or
        any(type(n) is not int for n in design['prefix_lengths']) or design['prefix_lengths'] != list(range(1, 33))):
        raise ValueError('fixed prefix design required')
    prompts = design.get('prompts')
    seed_ordinals = design.get('decode_seed_prompt_ordinals')
    if type(prompts) is not list or len(prompts) != 32:
        raise ValueError('exact32 authored validation prompts required')
    if (type(seed_ordinals) is not list or len(seed_ordinals) != 8 or
        any(type(n) is not int or not 0 <= n < 32 for n in seed_ordinals) or len(set(seed_ordinals)) != 8):
        raise ValueError('exact eight validation seed ordinals required')
    expected = dict(decode_seed_length=16, steps=4, prefill_count=1024, teacher=32, free=32, total=1088)
    if any(type(design.get(k)) is not int or design[k] != v for k, v in expected.items()):
        raise ValueError('fixed validation decode schedule differs')
    prefills, seed_tokens, natural_lengths = [], {}, []
    texts = set()
    for ordinal, item in enumerate(prompts):
        if type(item) is not dict or set(item) != {'ordinal', 'text'} or type(item['ordinal']) is not int or item['ordinal'] != ordinal:
            raise ValueError('authored validation order differs')
        text = item['text']
        if type(text) is not str or not text.strip() or text in texts:
            raise ValueError('distinct authored validation texts required')
        texts.add(text)
        full = tokens(encode(text))
        if len(full) < 32:
            raise ValueError('natural validation token length below32')
        natural_lengths.append(len(full))
        seed_tokens[ordinal] = full[:16]
        for length in range(1, 33):
            prefills.append(dict(prompt_ordinal=ordinal, sequence_length=length, token_ids=list(full[:length])))
    seeds = [dict(seed_ordinal=i, prompt_ordinal=n, token_ids=list(seed_tokens[n])) for i, n in enumerate(seed_ordinals)]
    return dict(prefills=prefills, decode_seeds=seeds, natural_token_lengths=natural_lengths)


def counts_by_length(contexts):
    return {str(n): dict(entries=sum(len(x) == n for x in contexts),
                        unique=len({x for x in contexts if len(x) == n}))
            for n in sorted({len(x) for x in contexts})}


def disjointness(calibration_inputs, validation_inputs, previous_sets):
    cal = [tokens(x['token_ids'], x['sequence_length']) for x in calibration_inputs['prefills']]
    cal_seeds = [tokens(x['token_ids'], 16) for x in calibration_inputs['decode_seeds']]
    new = [tokens(x['token_ids'], x['sequence_length']) for x in validation_inputs['prefills']]
    new_seeds = [tokens(x['token_ids'], 16) for x in validation_inputs['decode_seeds']]
    if (len(cal), len(cal_seeds), len(new), len(new_seeds), len(previous_sets)) != (3072, 16, 1024, 8, 3):
        raise ValueError('complete planned input sets required')
    excluded = set(cal) | set(cal_seeds) | {(0,)}
    old_seed_set = set(cal_seeds)
    for rows in previous_sets:
        contexts, seeds = old_inputs(rows)
        excluded.update(contexts)
        old_seed_set.update(seeds)
    overlap = (set(new) | set(new_seeds)) & excluded
    current_family_overlap = {x[:16] for x in new if len(x) >= 16} & old_seed_set
    seed_overlap = set(new_seeds) & {x[:16] for x in excluded if len(x) >= 16}
    family_overlap = set(new_seeds) & old_seed_set
    return dict(passed=not (overlap or current_family_overlap or seed_overlap or family_overlap),
                known_full_context_intersections=counts_by_length(list(overlap)),
                known_new_context_vs_old_decode_family_prefixes=len(current_family_overlap),
                new_decode_seed_vs_excluded_context_prefixes=len(seed_overlap),
                new_vs_old_decode_family_prefixes=len(family_overlap),
                calibration_prefills=counts_by_length(cal), validation_prefills=counts_by_length(new),
                frozen_calibration_seed_entries=len(cal_seeds), frozen_validation_seed_entries=len(new_seeds),
                calibration_workload_entries=3200, validation_workload_entries=1088,
                frozen_prefill_entries=dict(calibration=len(cal), validation=len(new)),
                future_decode_tokens_generated=False,
                future_decode_disjointness_assumption='Every later decode only appends to its authenticated original16-token seed.',
                excluded_input_set_count=3, row0_token0_excluded=True,
                limits='Token equality and prefix separation only; no semantic independence or model/generalization claim.')
