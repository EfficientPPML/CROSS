"""Tokenizer-only preparation; outputs contain inputs, never model observations."""
import hashlib
import input_plan
from freeze_io import parse

ASSETS = ('tokenizer.json', 'tokenizer_config.json', 'vocab.json', 'merges.txt')
ASSET_ROOT = '/home/jianming_gatech/cross_validation_assets/qwen/c1899de289a04d12100db370d81485cdf75e47ca'
INPUTS = ('calibration_corpus', 'calibration_tokens', 'published_tokens',
          'candidate2_fresh_tokens', 'candidate3_fresh_tokens')


def execute(blobs, reader, tokenizer_factory, output):
    """All reads have fixed pins; injection exists only for public synthetic tests."""
    external = parse(blobs['external_inputs.json'])
    model = parse(blobs['public/model_pins.json'])
    if type(external) is not dict or set(external) != set(INPUTS):
        raise ValueError('exact five original input pins required')
    inputs = {}
    for name in INPUTS:
        pin = external[name]
        if type(pin) is not dict or set(pin) != {'path', 'sha256'}:
            raise ValueError('exact input pin schema required')
        data = reader(pin['path'], pin['sha256'])
        if hashlib.sha256(data).hexdigest() != pin['sha256']:
            raise ValueError('original input digest differs')
        inputs[name] = parse(data)
    assets = {}
    for name in ASSETS:
        expected = model['asset_sha256'][name]
        data = reader(ASSET_ROOT + '/' + name, expected)
        if hashlib.sha256(data).hexdigest() != expected:
            raise ValueError('tokenizer asset digest differs')
        assets[name] = data
    cal = input_plan.calibration(inputs['calibration_corpus'], inputs['calibration_tokens'])
    old = [inputs[name] for name in INPUTS[2:]]
    for rows in old:
        input_plan.old_inputs(rows)
    # from_str consumes the authenticated bytes, avoiding a second unbound path read.
    tokenizer = tokenizer_factory(assets['tokenizer.json'].decode('utf-8'))
    def encode(text):
        return tokenizer.encode(text, add_special_tokens=False).ids
    # Verification only: calibration remains derived from the original frozen S32.
    rows = inputs['calibration_tokens']
    for ordinal, prompt in enumerate(inputs['calibration_corpus']['calibration_prompts']):
        actual = input_plan.tokens(encode(prompt['text']))
        for index, length in enumerate((8, 16, 32)):
            row = rows[ordinal * 3 + index]
            if list(actual[:length]) != row['token_ids'] or len(actual) != row['raw_token_count']:
                raise ValueError('pinned tokenizer differs from original calibration record')
    new = input_plan.validation(parse(blobs['public/validation_design.json']), encode)
    overlap = input_plan.disjointness(cal, new, old)
    report = dict(scope='Tokenizer-only expanded-prefix input preparation; no model or coefficient evaluation.',
                  input_sha256={name: external[name]['sha256'] for name in INPUTS},
                  tokenizer_asset_sha256={name: model['asset_sha256'][name] for name in ASSETS},
                  protocol_sha256=hashlib.sha256(blobs['public/protocol.json']).hexdigest(),
                  validation_design_sha256=hashlib.sha256(blobs['public/validation_design.json']).hexdigest(),
                  overlap=overlap, original_calibration_records_verified=288,
                  new_natural_token_min=min(new['natural_token_lengths']),
                  new_natural_token_max=max(new['natural_token_lengths']),
                  model_forward=False, coefficient_selection=False, generated_decode_contexts=False,
                  private_outputs={}, passed=False, complete=False)
    # Keep the complete fixed input set on an overlap failure; never silently replace it.
    report['private_outputs']['calibration'] = output.json('calibration_inputs.json', cal)
    report['private_outputs']['validation'] = output.json('validation_inputs.json', new)
    report.update(complete=True, passed=overlap['passed'])
    return report
