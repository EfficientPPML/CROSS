"""Exercise the complete input workflow with synthetic bodies and tokenizer."""
import hashlib
from types import SimpleNamespace
import pytest
import freeze_logic as f
from freeze_io import json_bytes,parse
from test_input_plan import fixtures


def workflow():
    corpus,rows,design,old,encode=fixtures()
    data={name:json_bytes(value) for name,value in zip(f.INPUTS,[corpus,rows,*old])}
    pins={name:dict(path='/synthetic/'+name,sha256=hashlib.sha256(value).hexdigest())for name,value in data.items()}
    assets={name:json_bytes({'synthetic_asset':name}) for name in f.ASSETS}
    blobs={'external_inputs.json':json_bytes(pins),
           'public/model_pins.json':json_bytes({'asset_sha256':{name:hashlib.sha256(value).hexdigest()for name,value in assets.items()}}),
           'public/validation_design.json':json_bytes(design),'public/protocol.json':b'{"synthetic":true}'}
    bodies={pins[name]['path']:value for name,value in data.items()}
    bodies.update({f.ASSET_ROOT+'/'+name:value for name,value in assets.items()})
    reads=[];encodes=[];writes={}
    def reader(path,expected):
        reads.append(path)
        value=bodies[path]
        assert hashlib.sha256(value).hexdigest()==expected
        return value
    class Tokenizer:
        def encode(self,text,add_special_tokens):
            assert add_special_tokens is False
            encodes.append(text)
            if text.startswith('calibration'):
                i=int(text.split()[-1]);value=[1000+i]+list(range(1,40))
            else:value=encode(text)
            return SimpleNamespace(ids=value)
    def factory(text):
        assert text==assets['tokenizer.json'].decode()
        return Tokenizer()
    class Output:
        def json(self,name,value):
            assert name not in writes
            writes[name]=value
            return {'sha256':hashlib.sha256(json_bytes(value)).hexdigest()}
    return blobs,bodies,reader,factory,Output(),reads,encodes,writes


def test_complete_workflow_reads_only_five_inputs_four_tokenizer_assets():
    blobs,bodies,reader,factory,output,reads,encodes,writes=workflow()
    report=f.execute(blobs,reader,factory,output)
    assert report['passed'] and report['complete']
    assert len(reads)==9 and set(reads)==set(bodies)
    assert len(encodes)==128
    assert len(writes['calibration_inputs.json']['prefills'])==3072
    assert len(writes['validation_inputs.json']['prefills'])==1024
    public=json_bytes(report)
    assert b'token_ids' not in public and b'new fixture' not in public and b'calibration fixture' not in public
    assert report['model_forward']is False and report['generated_decode_contexts']is False


@pytest.mark.parametrize('what',['input_hash','asset_hash','short_validation','calibration_mismatch'])
def test_failure_prevents_any_input_publication(what):
    blobs,bodies,reader,factory,output,reads,encodes,writes=workflow()
    if what=='input_hash':
        reader=lambda path,expected:b'[]'
    elif what=='asset_hash':
        orig=reader
        reader=lambda path,expected:b'{}'if path.endswith('tokenizer.json')else orig(path,expected)
    else:
        orig=factory
        def factory(text):
            tokenizer=orig(text);original=tokenizer.encode
            def encode(prompt,add_special_tokens):
                result=original(prompt,add_special_tokens)
                if (what=='short_validation'and prompt.startswith('new'))or(what=='calibration_mismatch'and prompt.startswith('calibration')):
                    result.ids=[7]*2
                return result
            tokenizer.encode=encode
            return tokenizer
    with pytest.raises(ValueError):f.execute(blobs,reader,factory,output)
    assert not writes


def test_overlap_keeps_full_fixed_inputs_and_reports_failure():
    blobs,bodies,reader,factory,output,reads,encodes,writes=workflow();orig=factory
    def factory(text):
        tokenizer=orig(text);original=tokenizer.encode
        def encode(prompt,add_special_tokens):
            result=original(prompt,add_special_tokens)
            if prompt.startswith('new'):result.ids[0]=1000
            return result
        tokenizer.encode=encode
        return tokenizer
    report=f.execute(blobs,reader,factory,output)
    assert report['complete'] and not report['passed']
    assert len(writes['validation_inputs.json']['prefills'])==1024
    assert report['overlap']['validation_workload_entries']==1088
