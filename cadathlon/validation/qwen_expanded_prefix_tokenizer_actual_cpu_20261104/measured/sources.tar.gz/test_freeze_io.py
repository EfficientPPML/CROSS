"""Failure-path ownership tests for authenticated readers and retained outputs."""
import os
import stat
import pytest
import freeze_io as f


def test_reader_bound_digest_regular_and_replacement(tmp_path):
    path=tmp_path/'input';path.write_bytes(b'input')
    assert f.read(path)==b'input'
    with pytest.raises(ValueError):f.read(path, limit=4)
    with pytest.raises(ValueError):f.read(path, expected='0'*64)
    link=tmp_path/'link';link.symlink_to(path)
    with pytest.raises(OSError):f.read(link)
    fifo=tmp_path/'fifo';os.mkfifo(fifo)
    with pytest.raises(ValueError):f.read(fifo)


@pytest.mark.parametrize('failure',['fstat','read','stat'])
def test_reader_closes_on_early_failures(tmp_path,monkeypatch,failure):
    path=tmp_path/'input';path.write_bytes(b'input');closed=[]
    original_close=os.close
    def close(fd):closed.append(fd);original_close(fd)
    def bad(*a,**k):raise RuntimeError('primary')
    with monkeypatch.context() as patch:
        patch.setattr(f.os,'close',close);patch.setattr(f.os,failure,bad)
        with pytest.raises(RuntimeError,match='primary'):f.read(path)
    assert len(closed)==1
    with pytest.raises(OSError):os.fstat(closed[0])


def test_reader_retains_primary_when_close_also_fails(tmp_path,monkeypatch):
    path=tmp_path/'input';path.write_bytes(b'input');original_close=os.close
    def bad(*a):raise RuntimeError('primary')
    def close(fd):original_close(fd);raise OSError('secondary')
    with monkeypatch.context() as patch:
        patch.setattr(f.os,'read',bad);patch.setattr(f.os,'close',close)
        with pytest.raises(RuntimeError,match='primary') as result:f.read(path)
    assert result.value.__notes__==['cleanup failure: OSError']


def test_close_cancellation_preserves_genuine_body_primary(tmp_path,monkeypatch):
    path=tmp_path/'input';path.write_bytes(b'input');original_close=os.close
    def bad(*a):raise RuntimeError('primary')
    def close(fd):original_close(fd);raise KeyboardInterrupt('cancel')
    with monkeypatch.context() as patch:
        patch.setattr(f.os,'read',bad);patch.setattr(f.os,'close',close)
        with pytest.raises(RuntimeError,match='primary') as result:f.read(path)
    assert result.value.__notes__==['cleanup failure: KeyboardInterrupt']


def test_reader_detects_named_inode_replacement(tmp_path,monkeypatch):
    path=tmp_path/'input';path.write_bytes(b'input');original_read=os.read;first=True
    def changed(fd,n):
        nonlocal first
        if first:
            first=False;path.rename(tmp_path/'retained');path.write_bytes(b'input')
        return original_read(fd,n)
    with monkeypatch.context() as patch:
        patch.setattr(f.os,'read',changed)
        with pytest.raises(ValueError,match='changed'):f.read(path)


def test_output_is_fresh_private_and_retained(tmp_path):
    path=tmp_path/'owned';owner=f.Output(path)
    record=owner.json('tokens.json', {'synthetic':[1,2]})
    assert stat.S_IMODE(path.stat().st_mode)==0o700
    assert stat.S_IMODE((path/'tokens.json').stat().st_mode)==0o600
    assert record['sha256'] and record['bytes']>0
    with pytest.raises(FileExistsError):owner.json('tokens.json', {})
    with pytest.raises(ValueError):owner.json('../escape', {})
    owner.close();owner.close()
    assert path.exists() and (path/'tokens.json').exists()
    with pytest.raises(FileExistsError):f.Output(path)


def test_constructor_fstat_failure_releases_fd(tmp_path,monkeypatch):
    closed=[];original_close=os.close
    def close(fd):closed.append(fd);original_close(fd)
    def bad(fd):raise RuntimeError('constructor')
    with monkeypatch.context() as patch:
        patch.setattr(f.os,'fstat',bad);patch.setattr(f.os,'close',close)
        with pytest.raises(RuntimeError,match='constructor'):f.Output(tmp_path/'owned')
    assert len(closed)==1 and (tmp_path/'owned').exists()
    with pytest.raises(OSError):os.fstat(closed[0])


def test_output_replaced_directory_is_rejected(tmp_path):
    path=tmp_path/'owned';owner=f.Output(path)
    path.rename(tmp_path/'retained');path.mkdir(mode=0o700)
    try:
        with pytest.raises(ValueError,match='identity'):owner.json('report.json',{})
        assert not list(path.iterdir())
    finally:owner.close()


def test_partial_write_is_retained_and_closed(tmp_path,monkeypatch):
    owner=f.Output(tmp_path/'owned');original_write=os.write;calls=0;closed=[];original_close=os.close
    def write(fd,data):
        nonlocal calls
        calls+=1
        if calls==1:return original_write(fd,data[:2])
        raise OSError('write failed')
    def close(fd):closed.append(fd);original_close(fd)
    try:
        with monkeypatch.context() as patch:
            patch.setattr(f.os,'write',write);patch.setattr(f.os,'close',close)
            with pytest.raises(OSError,match='write failed'):owner.write('partial',b'12345')
        assert (tmp_path/'owned/partial').read_bytes()==b'12' and len(closed)==1
        with pytest.raises(OSError):os.fstat(closed[0])
    finally:owner.close()


def test_duplicate_and_nonfinite_json_rejected():
    for raw in (b'{"a":1,"a":2}',b'{"a":NaN}',b'{"a":Infinity}'):
        with pytest.raises(ValueError):f.parse(raw)
