The next isolated owner will implement the public proposal proven in
`/tmp/bert-bsgs-score-routing-plan-20261103/source-bound-v1`: report SHA256
e81ef215087e6cd010bc5360a312d04cf452598f944746ec42d60826518dedc2,
ten-source archive6db86228c46611578ae20dff305473545fbd8d058964fd890cdd28542b31800e.
No owner implementation or encrypted execution is present yet.

Keep the existing FactoredScoreLayout and outer tile rotations. Replace each
head/key weighted stage with four baby inputs and three/four giant groups.
Masks are rotated in the opposite giant direction before multiplication.
Each giant group performs a real weighted sum and rescale, followed by its
giant rotation; explicit ciphertext additions merge the groups. No scale is
assigned manually. Head/key input/output levels remain L/L-1 per stage.

Bind the actual borrowed CompiledArithmetic/context/layout/helper identities
and the common p60 ordered Q/P contract. Require serial, low-memory arithmetic
whose ordinary primitive calls synchronize their arrays; do not own or close
its context. Use the copied scale planner to predict each group's actual
binary64 output from the input scale and the dropped Q pair. Validate every
rotation, weighted result and addition independently, including exact NSD,
precision, layout and Q prefix. Canonical and noncanonical positive inputs
must both work. Equal group scales must be established before their additions.

Retain the original input, baby and partial-result arrays separately from
mutable ciphertext wrappers through callback checks and any cleanup. Bind
accessors before work, reject reentry and callback mutations, preserve caller
tags on zero aliases, and clear only tags owned by new outputs. Do not add a
global ciphertext or mask cache. Private data, encoding, decoding, refresh and
new key generation are outside this owner.

Ideal tests must exercise the actual owner loops with explicit primitive and
security doubles, all128 mappings/directions/gains, hostile padding, exact
operation counts and the36-key inventory. Add scale/level mutations, original
payload retention and helper/callback replacement tests. Reuse reviewed
production metadata ASTs if needed to distinguish binary64 recurrence checks
from a test double merely copying the plan. Preserve any failing revision.

Only after a frozen ideal/source proof and independent review should a separate
actual harness use the retained authenticated public context. The existing
factored-route numerical gate remains1e-6 on every physical slot. Different
key-switch, summation and rescale order prevents a bitwise-equivalence claim.
All new encrypted outputs must finish before client decoding. Measure actual
memory and time separately from logical counts; no speedup is presumed.

The full BERT server, prepared-key parity run, ordinary-group harness and all
other frozen jobs remain unchanged. This directory is root-owned.
