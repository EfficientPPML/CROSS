"""Execute frozen production metadata ASTs on virtual payloads, never HE.

The actual weighted/PTCT/rescale/add/level-reduce/clone/validation method bodies
are unchanged. Only finite-field payload math, encoding, synchronization and
security are inert doubles. Virtual shapes carry the full ring; data samples
are public float64 values, not residues or ciphertext arrays.
"""
from pathlib import Path
from contextlib import contextmanager
from types import ModuleType,SimpleNamespace as NS,MethodType
import ast,hashlib,json,math,sys
import typing
import numpy as np
HERE=Path(__file__).resolve().parent
INPUTS=HERE/'input_sources'
PROFILE=json.loads((INPUTS/'p60_profile_and_refresh.json').read_bytes())['profile']
Q=tuple(PROFILE['q']);P=tuple(PROFILE['p']);DELTA=PROFILE['canonical_scale'];LAYOUT=(256,512)
EXTRACTED={}

def extract(filename,owner,name,namespace):
    raw=(INPUTS/filename).read_bytes();tree=ast.parse(raw)
    container=tree if owner is None else next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name==owner)
    function=next(x for x in container.body if isinstance(x,ast.FunctionDef) and x.name==name)
    if function.decorator_list:raise ValueError('method extraction does not transform decorators')
    key=filename+':'+(owner+'.' if owner else '')+name
    EXTRACTED[key]=dict(source_sha256=hashlib.sha256(raw).hexdigest(),ast_sha256=hashlib.sha256(ast.dump(function,include_attributes=False).encode()).hexdigest())
    env=dict(np=np,jnp=np,math=math,Optional=typing.Optional,List=typing.List,Polynomial=Value if 'Value' in globals() else None)
    env.update(namespace)
    exec(compile(ast.Module(body=[function],type_ignores=[]),str(INPUTS/filename),'exec'),env)
    return env[name]

class Field:
    def __init__(self,moduli):self.moduli=list(moduli)

def ntt(moduli):return NS(moduli=list(moduli),ff_ctx=Field(moduli))

class Payload:
    dtype=np.dtype('uint32')
    def __init__(self,data,shape):self.data=np.asarray(data,dtype=np.float64);self.shape=tuple(shape);self.ndim=len(shape)
    def devices(self):return frozenset({'metadata-cpu'})
    def astype(self,dtype):
        if np.dtype(dtype)!=self.dtype:raise ValueError('metadata stub only supports canonical uint32')
        return self
    def __getitem__(self,index):
        if type(index)is not tuple or index[:-1]!=(Ellipsis,) or not isinstance(index[-1],slice) or index[-1].start is not None or index[-1].step is not None:
            raise ValueError('metadata payload supports only exact Q-prefix slicing')
        return Payload(self.data,(*self.shape[:-1],index[-1].stop))

class Value:
    modulus_dtype=np.uint32
    def __init__(self,scale,level,*,data=1.,elements=2,nsd=1):
        self.batch=1;self.num_elements=elements;self.r,self.c=LAYOUT;self.degree_layout=LAYOUT;self.degree=131072
        self.precision=32;self.moduli=list(Q[:2*(level+1)]);self.num_moduli=len(self.moduli)
        self.moduli_array=np.asarray(self.moduli,dtype=np.uint32);self.ntt_ctx=ntt(self.moduli)
        self._ckks_scale=scale;self._ckks_nsd=nsd;self.polynomial=Payload(data,self._payload_shape)
    @property
    def _payload_shape(self):return (self.batch,self.num_elements,self.r,self.c,self.num_moduli)
    @property
    def shape(self):return self.polynomial.shape
    @property
    def level(self):return self.num_moduli//2-1
    @property
    def polynomial(self):return self._polynomial
    @polynomial.setter
    def polynomial(self,value):self._validate_payload(value);self._polynomial=value

for method in ('_validate_payload','validate','_clone_with_payload'):
    setattr(Value,method,extract('polynomial.py','Polynomial',method,{}))

FINITE=ModuleType('finite_field');ns=dict(jnp=np)
for name in ('check_reduction_match','check_rank5_array','check_ct_operand','check_binary_ct_operands'):
    fn=extract('finite_field.py',None,name,ns);setattr(FINITE,name,fn);ns[name]=fn
G=dict(finite_field=FINITE)
META=extract('he_ops.py',None,'_validate_additive_metadata',G);G['_validate_additive_metadata']=META
KERNEL_ADD=extract('headd.py','_HEAddKernel','add',G)
FACADE_ADD=extract('he_ops.py','_HEAddAtLevel','add',G)
ADD_PLAIN=extract('he_ops.py','_HEAddAtLevel','add_plain',G)
REDUCE=extract('he_ops.py','_HELevelReduceAtLevels','level_reduce',G)
PTCT=extract('encrypted_primitives.py','CompiledPlaintextMultiply','multiply',G)
RESCALE=extract('encrypted_primitives.py','CompiledRescale','rescale',G)
WEIGHTED=extract('encrypted_polynomial.py','EncryptedPolynomialEvaluator','weighted_sum',G)
ADD=extract('encrypted_polynomial.py','EncryptedPolynomialEvaluator','add',G)
ROTATE=extract('encrypted_packed_qwen.py','CompiledArithmetic','rotate',G)
LEVEL=extract('encrypted_polynomial.py','EncryptedPolynomialEvaluator','_level',G)
LOWER=extract('encrypted_polynomial.py','EncryptedPolynomialEvaluator','_lower',G)
CAPACITY=extract('encrypted_polynomial.py','EncryptedPolynomialEvaluator','_ensure_capacity',G)
SLOTS=extract('encrypted_polynomial.py','EncryptedPolynomialEvaluator','_public_slots',G)

@contextmanager
def no_backend():
    replacements={'finite_field':FINITE,'polynomial':NS(Polynomial=Value),'support':NS(require_secure_execution=lambda *args:None),
                  'jax':NS(block_until_ready=lambda value:value)}
    prior={n:sys.modules.get(n) for n in replacements}
    try:
        sys.modules.update(replacements);yield
    finally:
        for n,old in prior.items():
            if old is None:sys.modules.pop(n,None)
            else:sys.modules[n]=old

class AddTable:
    def __init__(self,cache):self.cache=cache
    def __getitem__(self,level):
        q=self.cache.q_moduli_at_level(level)
        kernel=NS(ff_context_cls=Field,num_moduli=len(q),moduli=q,
            _add_unchecked=lambda x,y:Payload(x.data+y.data,x.shape))
        kernel.add=MethodType(KERNEL_ADD,kernel)
        op=NS(_kernel=kernel,cache=self.cache,level=level,
            _add_plain_array=lambda x,y:Payload(x.data+y.data,x.shape))
        op.add=MethodType(FACADE_ADD,op);op.add_plain=MethodType(ADD_PLAIN,op);return op
class ReduceTable:
    def __init__(self,cache):self.cache=cache
    def __getitem__(self,pair):
        source,target=pair
        if not 0<=target<source<=49:raise ValueError('strict level reduction required')
        op=NS(cache=self.cache,src_level=source,dst_level=target,_target_num_q=2*(target+1))
        op.level_reduce=MethodType(REDUCE,op);return op

class ProductionMetadata:
    """Independent metadata engine; no input-scale formula copied from planner."""
    _level=LEVEL;_lower=LOWER;_ensure_capacity=CAPACITY;_public_slots=SLOTS
    def __init__(self):
        self.scale=DELTA;self.refresher=None;self.events=[]
        cache=NS(batch=1,degree_layout=LAYOUT,ff_context_cls=Field,q_towers=list(Q),p_towers=list(P),
            q_moduli_at_level=lambda level:list(Q[:2*(level+1)]),num_q_at_level=lambda level:2*(level+1),
            level_for_num_q=lambda count:count//2-1,get_sliced_ntt_q=lambda level:ntt(Q[:2*(level+1)]),
            _prepare_plaintext_payload=lambda payload,level:payload)
        self.ctx=NS(_param_cache=cache,num_slots=65536,degree_layout=LAYOUT)
        self.ctx.he_add=AddTable(cache);self.ctx.he_level_reduce=ReduceTable(cache)
        pt=NS(ctx=self.ctx);pt.multiply_encoded=lambda value,plain,level:value._clone_with_payload(Payload(value.polynomial.data*plain.data,value.shape))
        pt.multiply=MethodType(PTCT,pt);self._plaintext_multiply=pt
        rs=NS(ctx=self.ctx,binding=None)
        def rescale(value,source,target):
            signature=('rescale',source,target,tuple(value.shape),'metadata-cpu')
            rs.binding=(signature,lambda payload:Payload(payload.data,(*payload.shape[:-1],2*(target+1))))
            return RESCALE(rs,value,source,target)
        rs.rescale=rescale;self._rescale=rs
        self.rotation=NS(rotate=lambda value,index:value._clone_with_payload(Payload(value.polynomial.data,value.shape)))
    def _prepare(self,level):self.events.append(('prepare',level))
    def _finish(self,value):self.events.append(('finish',value.level));return value
    def _encode_public(self,weight,level,scale):return Value(scale,level,data=weight,elements=1)
    def weighted_sum(self,values,weights,*,bias=0.):
        with no_backend():return WEIGHTED(self,values,weights,bias=bias)
    def add(self,left,right):
        with no_backend():return ADD(self,left,right)
    def rotate(self,value,index):
        with no_backend():return ROTATE(self,value,index)
    def raw_add(self,left,right,level):
        with no_backend():return self.ctx.he_add[level].add(left,right)
    def rescale_only(self,value,source,target):
        with no_backend():return self._rescale.rescale(value,source,target)

def metadata(value):
    return dict(level=value.level,scale=value._ckks_scale,scale_hex=float(value._ckks_scale).hex(),nsd=value._ckks_nsd,
        moduli=list(value.moduli),shape=list(value.shape),precision=value.precision)
