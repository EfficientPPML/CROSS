"""Independent production-AST metadata checks for the future BSGS owner."""
from pathlib import Path
import importlib.util,math,sys
import numpy as np
import pytest
from production_metadata import ProductionMetadata,Value,Payload,Q,DELTA,metadata,EXTRACTED,INPUTS,no_backend
spec=importlib.util.spec_from_file_location('copied_scale_plan',INPUTS/'encrypted_scale_planning.py')
planner=importlib.util.module_from_spec(spec);spec.loader.exec_module(planner)
SCALES=(DELTA,math.nextafter(DELTA,0.),math.nextafter(DELTA,math.inf),DELTA*.73,DELTA*1.17,
        (DELTA*DELTA)/math.prod(Q[12:14]),1e-12,1e28)

@pytest.mark.parametrize('level',(49,25))
@pytest.mark.parametrize('scale',SCALES)
@pytest.mark.parametrize('groups',(3,4))
def test_independent_production_ast_group_addition_metadata(level,scale,groups):
    oracle=ProductionMetadata();source=Value(scale,level)
    babies=[oracle.rotate(source,i) for i in (0,63,126,189)]
    assert babies[0] is source and all(metadata(v)==metadata(source) for v in babies)
    expected=planner.weighted_sum_scale([scale]*4,DELTA,planner.drop_divisor(Q,level))['output_scale']
    outputs=[]
    for group in range(groups):
        weights=[0.,(-1.)**group,.125,1.]
        out=oracle.weighted_sum(babies,weights,bias=.25)
        assert type(out._ckks_nsd)is int and out._ckks_nsd==1
        assert out._ckks_scale==expected and out.level==level-1 and out.moduli==list(Q[:2*level])
        assert out.shape==(1,2,256,512,2*level) and out.precision==32
        outputs.append(oracle.rotate(out,252*group))
    combined=outputs[0]
    for other in outputs[1:]:
        assert combined._ckks_scale==other._ckks_scale
        previous=metadata(combined);combined=oracle.add(combined,other)
        assert metadata(combined)==previous
    assert metadata(source)['scale']==scale and source.moduli==list(Q[:2*(level+1)])

@pytest.mark.parametrize('level',(49,25))
def test_nearby_unequal_scales_are_accepted_but_left_owned(level):
    oracle=ProductionMetadata();left=Value(DELTA,level);right=Value(math.nextafter(DELTA,math.inf),level)
    result=oracle.add(left,right)
    assert result._ckks_scale==left._ckks_scale!=right._ckks_scale
    assert metadata(result)==metadata(left)
    # Reversing the input order reverses retained metadata, not a scale average.
    assert oracle.add(right,left)._ckks_scale==right._ckks_scale

@pytest.mark.parametrize('level',(49,25))
def test_actual_rescale_preserves_nsd_until_weighted_sum_resets(level):
    oracle=ProductionMetadata();v=Value(DELTA,level,nsd=2)
    out=oracle.rescale_only(v,level,level-1)
    assert out._ckks_nsd==2 and out.moduli==list(Q[:2*level])
    assert out._ckks_scale==DELTA/math.prod(Q[2*level:2*level+2])

@pytest.mark.parametrize('level',(49,25))
def test_addition_exact_q_order_and_level_contract(level):
    oracle=ProductionMetadata();left=Value(DELTA,level);right=Value(DELTA,level)
    # Same-size different ordered prefix passes a length-only check but not the actual facade.
    right.moduli=list(reversed(right.moduli));right.moduli_array=np.asarray(right.moduli,dtype=np.uint32)
    from production_metadata import ntt
    right.ntt_ctx=ntt(right.moduli)
    with pytest.raises(ValueError,match='moduli'):oracle.raw_add(left,right,level)
    right=Value(DELTA,level-1)
    with pytest.raises(ValueError):oracle.raw_add(left,right,level)
    # Actual evaluator.add performs actual level-reduce before its facade.
    out=oracle.add(left,right)
    assert out.level==level-1 and out._ckks_scale==DELTA and out._ckks_nsd==1
    assert out.moduli==right.moduli and left.level==level

@pytest.mark.parametrize('kind',('scale','nsd','precision','dtype'))
def test_real_additive_and_representation_rejections(kind):
    oracle=ProductionMetadata();left=Value(DELTA,25);right=Value(DELTA,25)
    if kind=='scale':right._ckks_scale*=1.001
    elif kind=='nsd':right._ckks_nsd=2
    elif kind=='precision':right.precision=64
    else:right.polynomial.dtype=np.dtype('uint64')
    with pytest.raises(ValueError):oracle.add(left,right)

def test_legacy_nsd_equality_is_not_an_exact_type_guard():
    oracle=ProductionMetadata();left=Value(DELTA,25);right=Value(DELTA,25,nsd=True)
    assert oracle.add(left,right)._ckks_nsd==1
    assert oracle.add(right,left)._ckks_nsd is True
    # The new owner must independently require exact int NSD1 before primitives.

def test_weighted_first_zero_term_still_owns_actual_scale():
    oracle=ProductionMetadata();scales=[DELTA*(1+i/64) for i in range(65)]
    for level in (49,25):
        outputs=[oracle.weighted_sum([Value(s,level)],[1.])._ckks_scale for s in scales]
        pair=next(((a,b) for a in range(len(scales)) for b in range(a+1,len(scales)) if outputs[a]!=outputs[b]),None)
        assert pair is not None
        a,b=pair
        result=oracle.weighted_sum([Value(scales[a],level),Value(scales[b],level)],[0.,1.])
        reverse=oracle.weighted_sum([Value(scales[b],level),Value(scales[a],level)],[1.,0.])
        assert result._ckks_scale==outputs[a] and reverse._ckks_scale==outputs[b]

def test_public_alignment_resolution_is_additional_positive_scale_condition():
    oracle=ProductionMetadata()
    with pytest.raises(ValueError,match='round away'):
        oracle.weighted_sum([Value(1e100,49)],[.125])
    with pytest.raises(ValueError,match='finite and positive'):
        oracle.weighted_sum([Value(5e-324,49)],[1.])

def test_no_backend_modules_or_transformed_metadata_methods():
    assert not any(n=='jax' or n.startswith('jaxite_word') for n in sys.modules)
    assert len(EXTRACTED)==21
    assert all(len(x['source_sha256'])==len(x['ast_sha256'])==64 for x in EXTRACTED.values())
    original=sys.modules.get('jax')
    with no_backend():assert callable(sys.modules['jax'].block_until_ready)
    assert sys.modules.get('jax')is original
