"""Actual BSGS loops with independently extracted production metadata ASTs.

Only payload math/encoding/security are ideal doubles. Full-slot scatter is an
independent coordinate oracle; no finite-field arithmetic or HE is performed.
"""
from pathlib import Path
from types import SimpleNamespace
import math
import sys
import numpy as np
import pytest
sys.path.insert(0, str(Path(__file__).parent/'metadata_tests'))
from production_metadata import ProductionMetadata, Value, Payload, Field, Q, P, DELTA
from test_bsgs import add_key_inventory
from encrypted_bsgs_score_routing import BSGSScoreRouting
from encrypted_factored_score_routing import FactoredScoreLayout, SLOTS


@pytest.fixture
def production(monkeypatch):
    a = ProductionMetadata()
    monkeypatch.setattr(Field, 'computation_format_is_standard', True, raising=False)
    values = dict(degree=131072, num_slots=SLOTS, composite_degree=2, dnum=8,
                  max_level=49, scaling_factor=DELTA, degree_layout=(256, 512),
                  q_towers=list(Q), p_towers=list(P), secret_key=None, batch=1)
    for owner in (a.ctx, a.ctx._param_cache):
        for name, value in values.items():setattr(owner, name, value)
    a.ctx.parameters = {}
    add_key_inventory(a, Field)
    a.low_memory = True
    a.progress = None
    a._clear_working_caches = lambda: None
    for helper in (a.rotation, a._plaintext_multiply, a._rescale):
        helper.ctx = a.ctx
        helper.clear = lambda: None
    a.rotation.rotate = lambda value, shift: value._clone_with_payload(
        Payload(np.roll(value.polynomial.data, -shift), value.shape))
    monkeypatch.setitem(sys.modules, 'encrypted_packed_qwen', SimpleNamespace(CompiledArithmetic=ProductionMetadata))
    monkeypatch.setitem(sys.modules, 'jaxite_word', SimpleNamespace(Polynomial=Value))
    monkeypatch.setitem(sys.modules, 'support', SimpleNamespace(require_secure_execution=lambda *args: None))
    monkeypatch.setitem(sys.modules, 'jax', SimpleNamespace(block_until_ready=lambda arrays: arrays))
    monkeypatch.setitem(sys.modules, 'finite_field', SimpleNamespace(BarrettContext=Field))
    return a


@pytest.mark.parametrize('level', [49, 25])
@pytest.mark.parametrize('scale', [DELTA, math.nextafter(DELTA, 0.), math.nextafter(DELTA, math.inf), DELTA*.73, DELTA*1.17, (DELTA*DELTA)/math.prod(Q[12:14]), 1e-12, 1e28])
@pytest.mark.parametrize('tile,offset', [(0, 0), (7, 15)])
@pytest.mark.parametrize('inverse,gain', [(False, 1.), (False, .125), (True, 1.)])
def test_owner_matches_scatter_with_production_metadata(production, level, scale, tile, offset, inverse, gain):
    data = np.random.default_rng(19008).uniform(-100, 100, SLOTS)
    source = Value(scale, level, data=data)
    r = BSGSScoreRouting(production, FactoredScoreLayout(tile, offset))
    out = r.inverse(source) if inverse else r.forward(source, gain=gain)
    expected = np.zeros(SLOTS)
    for row in range(16):
        for head in range(12):
            i = row*4096+head*64
            j = row*4096+(tile*16+(row+offset)%16)*16+head
            expected[i if inverse else j] = data[j if inverse else i]*(1. if inverse else gain)
    np.testing.assert_array_equal(out.polynomial.data, expected)
    np.testing.assert_array_equal(source.polynomial.data, data)
    assert source._ckks_scale == scale and source.level == level
    assert out.level == level-2 and type(out._ckks_nsd) is int and out._ckks_nsd == 1
    assert out.moduli == list(Q[:2*(level-1)]) and out.shape == (1, 2, 256, 512, 2*(level-1))
    assert r.last_run['counts'] == dict(rotations=11+bool(tile), public_multiplications=28,
        ciphertext_additions=26, actual_composite_rescales=7, public_multiplication_levels=2)


@pytest.mark.parametrize('scale', [5e-324, 1e100])
def test_extreme_positive_scale_is_not_an_alignment_guarantee(production, scale):
    r = BSGSScoreRouting(production, FactoredScoreLayout(0, 0))
    with pytest.raises(ValueError):r.forward(Value(scale, 49, data=np.ones(SLOTS)), gain=.125)
