Experimental BSGS score-routing owner, isolated from all live jobs.

The actual routing loops use four baby inputs and three/four real weighted
sums, giant rotations and ciphertext additions. Both stages retain their
original depth; seven rescales replace two, while internal rotations decrease
from26 to11. The common p60 full-ring profile and36 required existing key pairs
are bound explicitly. No context/key ownership, client decoding or refresh is
introduced. No new encrypted or performance claim is supported by this lab.

Tests execute actual owner loops with ideal primitives/security and independently
extracted production metadata method bodies. Full-slot comparisons cover all128
mappings, both directions/gains, hostile padding, canonical and admissible
noncanonical scales. Positive scale alone does not guarantee representable
alignment or sufficient plaintext resolution. Actual encrypted error remains
subject to the unchanged1e-6 all-slot gate in a separate future proof.

Required key/map identities, shapes and dtypes are retained. Their content
authentication and exclusion of external writes to file-backed key memory remain
the authenticated loader's responsibility. Identity/read-only flags are not a
proof of external immutability. Ordinary serial low-memory arithmetic owns its
internal pending kernels; this owner retains original input/returned arrays
through callbacks and failures and quarantines unresolved barriers.

Source-bound execution is not yet run. Development logs and exact archive-time
source snapshots preserve intermediate results and failures. The independent
metadata oracle has its own14-source/46-test proof under metadata_tests; its
payloads/encoding/security are explicit doubles and its21 production method
bodies are unmodified. The root collector snapshots its complete source closure
before tests and compares current, snapshot and archived bytes afterward.
