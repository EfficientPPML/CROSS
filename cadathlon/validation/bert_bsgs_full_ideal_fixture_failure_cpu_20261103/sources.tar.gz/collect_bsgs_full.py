"""Pinned full BERT ideal BSGS collection. No HE or ranked evidence."""
from pathlib import Path
import argparse,io,json,math,os,sys,tarfile,time,xml.etree.ElementTree as ET
import export_decoder as public_io
from component_processes import OwnedChild
from cleanup import cleanup_signals
from terminal import terminal_scope
from finish import finish
HERE=Path(__file__).resolve().parent
MANIFEST_SHA='02d03a1a098daa69c3c955664e1c6c7f4bad3d32364af0151c0349205d4d25eb'
ORIGINAL_TESTS=33
# Updated only after focused collection; full execution requires this exact count.
COLLECTOR_TESTS=47
EXPECTED_COUNTS={15:dict(rotate=81845,multiply=7008,pt_products=517267,rescales=37398),
                 128:dict(rotate=538189,multiply=59236,pt_products=2058877,rescales=269701)}
EXPECTED_DOMAINS={15:302,128:2346}
EXPECTED_REFRESH={15:136,128:1067}

def parse(raw):return json.loads(raw,object_pairs_hook=public_io.unique,parse_constant=lambda x:(_ for _ in ()).throw(ValueError('nonfinite JSON')))
def digest(raw):return public_io.digest(raw)
def write(path,value):return public_io.write_json(path,value)
def hashes(raw):return {n:digest(b) for n,b in raw.items()}
def source_bytes(root=HERE):
    root=Path(root);raw=(root/'source_inventory.json').read_bytes();names=parse(raw)
    if type(names)is not list or len(names)!=len(set(names)) or names!=sorted(names):raise ValueError('unique sorted source inventory required')
    if 'source_inventory.json' not in names:raise ValueError('source inventory must bind itself')
    for name in names:
        if type(name)is not str or Path(name).is_absolute() or '..'in Path(name).parts:raise ValueError('relative source member required')
    return {n:(root/n).read_bytes() for n in names}

def archive(path,raw):
    with tarfile.open(path,'w:gz')as t:
        for name,b in sorted(raw.items()):
            m=tarfile.TarInfo(name);m.size=len(b);t.addfile(m,io.BytesIO(b))

def archive_readback(path,expected):
    with tarfile.open(path)as t:
        rows=t.getmembers()
        if (len(rows)!=len(expected) or len({m.name for m in rows})!=len(rows)
            or any(not m.isfile() or m.size>8<<20 for m in rows) or sum(m.size for m in rows)>32<<20):raise ValueError('bounded unique regular source archive required')
        actual={m.name:digest(t.extractfile(m).read())for m in rows}
    if actual!=expected:raise ValueError('source archive bytes differ')
    return True

def predecessor(row,*,baseline):
    raw=public_io.public_report(row['report_path'])
    if digest(raw)!=row['report_sha256']:raise ValueError('pinned predecessor report differs')
    report=parse(raw)
    flags=('passed','complete','source_files_unchanged','source_archive_verified','asset_files_unchanged') if baseline else ('passed','sources_unchanged','source_archive_verified','all_processes_reaped_and_owned_group_empty','terminal_scope_completed','termination_scope_completed')
    if any(report.get(n)is not True for n in flags) or report.get('error') or report.get('cleanup_errors'):raise ValueError('successful predecessor required')
    before=report.get('source_hashes_before');after=report.get('source_hashes_after')
    if type(before)is not dict or len(before)!=row['source_count'] or before!=after:raise ValueError('predecessor exact source inventory differs')
    if baseline:
        process=report.get('process_cleanup',{})
        if process.get('exit_code')!=0 or type(process.get('exit_code'))is not int or any(process.get(n)is not True for n in ('reaped','group_gone')):raise ValueError('baseline direct process completion required')
        if report.get('tests')!={'tests':46,'errors':0,'failures':0,'skipped':0}:raise ValueError('complete baseline46 tests required')
    else:
        if report.get('tests')!={'tests':22,'errors':0,'failures':0,'skipped':0}:raise ValueError('complete BSGS join22 tests required')
    if report.get('source_archive_sha256')!=row['archive_sha256'] or public_io.file_sha(row['archive_path'])!=row['archive_sha256']:raise ValueError('pinned predecessor archive differs')
    archive_readback(row['archive_path'],before)
    return before

def prerequisite_gate(data):
    raw=data['collector_overlay_manifest.json']
    if digest(raw)!=MANIFEST_SHA:raise ValueError('reviewed overlay manifest differs')
    m=parse(raw);base_raw=data['baseline_source_manifest.json']
    if digest(base_raw)!=m['baseline_source_manifest_sha256']:raise ValueError('baseline source map differs')
    base=parse(base_raw)
    if len(base)!=137 or set(m['overlays'])!={'encrypted_bert_full_model.py','encrypted_bert_layer_attention.py','test_full_model_owner.py','ideal_primitives.py'}:raise ValueError('exact137 baseline/four overlays required')
    desired=dict(base);desired.update(m['overlays']);desired.update(m['new_runtime']);desired.update(m['helpers'])
    for name,h in desired.items():
        if name not in data or digest(data[name])!=h:raise ValueError('fixed source differs: '+name)
    # All local contracts are checked before reading external public archives,
    # and every public predecessor is authenticated before fixture bodies.
    if predecessor(m['baseline'],baseline=True)!=base:raise ValueError('baseline source origin differs')
    joined=predecessor(m['bsgs_join'],baseline=False)
    for name,h in (m['new_runtime']|m['helpers']).items():
        if joined.get(name)!=h:raise ValueError('unchanged BSGS/helper origin differs')
    return m

def asset_hashes(m):return {n:public_io.file_sha(row['path'])for n,row in m['assets'].items()}
def finite_number(value):return type(value)in(int,float) and math.isfinite(value)

def verify_case(row,K):
    T=(K+15)//16
    if (type(row)is not dict or type(row.get('K'))is not int or row['K']!=K or row.get('passed')is not True
        or row.get('all_connections_are_actual_output_objects')is not True or row.get('native_prediction_agrees')is not True
        or row.get('ideal_gate')!=1e-7 or type(row.get('output_level'))is not int or row['output_level']!=2
        or row.get('native_logit_gate')!='abs(error)<=0.02+0.01*abs(native)'
        or row.get('physical_stage_slots_checked')!=(24*T+2)*65536):raise ValueError('complete fixed case/connection/level/gate required')
    errors=row.get('stage_errors')
    if type(errors)is not list or len(errors)!=24 or {(r.get('layer'),r.get('phase'))for r in errors}!={(l,p)for l in range(12)for p in ('attention','block')}:raise ValueError('all24 stage records required')
    for r in errors:
        if type(r.get('layer'))is not int or r.get('physical_slots')!=T*65536 or not finite_number(r.get('max_abs')) or not 0<=r['max_abs']<=1e-7:raise ValueError('fixed full-slot stage gate failed')
    for name in ('pooler_all_slot_max_abs','logits_all_slot_max_abs'):
        if not finite_number(row.get(name)) or not 0<=row[name]<=1e-7:raise ValueError('fixed head gate failed')
    if not finite_number(row.get('native_logit_max_abs'))or row['native_logit_max_abs']<0:raise ValueError('finite native diagnostic required')
    counts=row.get('primitive_counts')
    if type(counts)is not dict or counts!=EXPECTED_COUNTS[K] or any(type(n)is not int for n in counts.values()):raise ValueError('independent operation counts differ')
    plan=row.get('public_operation_plan',{})
    if plan.get('counts')!=counts or plan.get('identity_refreshes')!=EXPECTED_REFRESH[K] or row.get('identity_refresh_calls')!=EXPECTED_REFRESH[K]:raise ValueError('unchanged refresh/public plan differs')
    if type(row['identity_refresh_calls'])is not int:raise ValueError('exact refresh count required')
    for name,count in (('actual_domain_observations',EXPECTED_DOMAINS[K]),('independent_domain_observations',156)):
        rows=row.get(name)
        if type(rows)is not list or len(rows)!=count:raise ValueError('complete domain observation inventory required')
        for d in rows:
            if type(d)is not dict or type(d.get('count'))is not int or d['count']<=0 or type(d.get('domain'))is not list or len(d['domain'])!=2:raise ValueError('typed domain observation required')
            a,b=d['domain'];lo,hi=d.get('minimum'),d.get('maximum')
            if not all(finite_number(x)for x in (a,b,lo,hi)) or not a<=lo<=hi<=b:raise ValueError('actual nonlinear domain failure')
            if name=='actual_domain_observations':
                if d.get('passed')is not True:raise ValueError('actual domain failed')
            elif any(type(d.get(n))is not int or d[n]!=0 for n in ('below','above','nonfinite')):raise ValueError('independent domain failed')
    metadata=row.get('actual_metadata',{})
    if metadata.get('explicit_direct_ciphertext_connections')is not True or metadata.get('output_level')!=2 or metadata.get('original_positions')!=list(range(K)):raise ValueError('final full graph metadata differs')
    return dict(K=K,stage_records=24,physical_slots=row['physical_stage_slots_checked'],maximum_stage_absolute_error=max(r['max_abs']for r in errors),pooler_absolute_error=row['pooler_all_slot_max_abs'],logit_absolute_error=row['logits_all_slot_max_abs'],native_logit_max_abs=row['native_logit_max_abs'],native_prediction_agrees=True,native_P2_predicate_enforced_by_pinned_test=True,primitive_counts=counts,identity_refresh_calls=EXPECTED_REFRESH[K],actual_domains=EXPECTED_DOMAINS[K],independent_domains=156)

def read_cases(snapshot,output,report):
    rows=[];errors=[]
    for K in (15,128):
        path=snapshot/f'joined-K{K}.json'
        try:
            if path.exists():
                raw=public_io.public_report(path);(output/path.name).write_bytes(raw)
                report.setdefault('case_file_sha256',{})[str(K)]=digest(raw)
                rows.append(verify_case(parse(raw),K))
        except BaseException as error:errors.append(error)
        try:
            progress=snapshot/f'joined-progress-K{K}.jsonl'
            if progress.exists():
                raw=public_io.public_report(progress);(output/progress.name).write_bytes(raw)
        except BaseException as error:errors.append(error)
    report['cases']=rows
    if errors:
        chosen=next((e for e in errors if not isinstance(e,Exception)),errors[0])
        for error in errors:
            if error is not chosen:chosen.add_note('other retained case evidence: '+type(error).__name__)
        raise chosen
    return len(rows)==2

def run(output):
    output=Path(output).absolute();output.mkdir(mode=0o700,parents=False,exist_ok=False);start=time.monotonic()
    report=dict(passed=False,complete=False,encrypted_execution=False,model_forward=False,requested_cases=[15,128],cases=[],wrapper_pid=os.getpid(),cpu_affinity=sorted(os.sched_getaffinity(0)),source_files_unchanged=False,asset_files_unchanged=False,cleanup_completed=False,termination_scope_completed=False,raw_arrays_archived=False,only_initial_embeddings_supplied=True,scope='Full12 BERT BSGS graph with ideal slot/metadata primitives and identity refresh; no HE, five-handler, ranked or performance claim.')
    primary=None;cleanup_error=None;child=None;expected={};m=None;assets={};snapshot=output/'snapshot'
    try:
        write(output/'report.json',report)
        raw=source_bytes();expected=hashes(raw);m=prerequisite_gate(raw)
        archive(output/'sources.tar.gz',raw);archive_readback(output/'sources.tar.gz',expected)
        snapshot.mkdir()
        for name,b in raw.items():
            p=snapshot/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
        if hashes(source_bytes(snapshot))!=expected:raise ValueError('execution snapshot differs')
        assets=asset_hashes(m)
        if assets!={n:r['sha256']for n,r in m['assets'].items()}:raise ValueError('fixed assets differ')
        env=dict(os.environ,BERT_FULL_NATIVE_FIXTURE=m['assets']['private_original_native_fixture']['path'],JAX_PLATFORMS='cpu',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',MKL_NUM_THREADS='4',PYTHONHASHSEED='0')
        env.pop('PYTHONPATH',None)
        command=[sys.executable,'-m','pytest','-q','--tb=short','test_full_model_owner.py','test_bsgs_full_collector.py','-k','not test_collector_','--junitxml='+str(output/'tests.xml')]
        report.update(source_count=len(expected),source_hashes_before=expected,source_archive_sha256=public_io.file_sha(output/'sources.tar.gz'),asset_hashes_before=assets,command=command,original_tests_selected=ORIGINAL_TESTS,legacy_collector_tests_excluded=13,new_collector_tests_expected=COLLECTOR_TESTS)
        write(output/'report.json',report)
        with public_io.owned_stream(output/'tests.log',write=True)as log:
            child=OwnedChild(command,cwd=snapshot,stdout=log,env=env)
            report['process']=child.record;write(output/'report.json',report);code=child.wait()
        suites=list(ET.parse(output/'tests.xml').getroot().iter('testsuite'))
        counts={n:sum(int(s.attrib.get(n,0))for s in suites)for n in ('tests','errors','failures','skipped')};report['tests']=counts
        complete=read_cases(snapshot,output,report)
        if code!=0 or counts!={'tests':ORIGINAL_TESTS+COLLECTOR_TESTS,'errors':0,'failures':0,'skipped':0}:raise ValueError('complete fixed test inventory required')
        if not complete:raise ValueError('both complete K15/K128 cases required')
        report.update(complete=True,passed=True)
    except BaseException as error:
        primary=error;report.update(passed=False,error=dict(type=type(error).__name__,message=str(error)))
    finally:
        with terminal_scope(report,output/'report.json',write,cleanup_signals,lambda:(primary,cleanup_error)):
            errors=[]
            def attempt(label,fn):
                nonlocal cleanup_error
                try:return fn()
                except BaseException as error:
                    errors.append((label,error))
                    if cleanup_error is None or not isinstance(error,Exception)and isinstance(cleanup_error,Exception):cleanup_error=error
            if child is not None:attempt('owned child retirement',lambda:child.close(primary=primary))
            if snapshot.exists():attempt('retained case/progress evidence',lambda:read_cases(snapshot,output,report))
            after=attempt('current source readback',lambda:hashes(source_bytes()))
            copied=attempt('execution source readback',lambda:hashes(source_bytes(snapshot)))if snapshot.exists()else{}
            archived=attempt('source archive readback',lambda:archive_readback(output/'sources.tar.gz',expected))if expected and (output/'sources.tar.gz').exists()else False
            after_assets=attempt('fixed asset readback',lambda:asset_hashes(m))if assets else{}
            if m is not None:attempt('public prerequisite readback',lambda:prerequisite_gate(source_bytes()))
            process_ok=child is not None and all(child.record.get(n)is True for n in ('direct_child_reaped','group_empty_verified','cleanup_completed'))
            report.update(source_hashes_after=after,snapshot_source_hashes_after=copied,source_files_unchanged=bool(expected)and expected==after==copied,source_archive_verified=archived is True,asset_hashes_after=after_assets,asset_files_unchanged=bool(assets)and assets==after_assets,all_direct_children_reaped=bool(child and child.record.get('direct_child_reaped')is True),all_owned_groups_empty=bool(child and child.record.get('group_empty_verified')is True),cleanup_completed=not errors and (child is None or process_ok),cleanup_errors=[dict(operation=n,type=type(e).__name__)for n,e in errors],elapsed_s=time.monotonic()-start)
            report['passed']=bool(report['passed']and report['complete']and process_ok and report['source_files_unchanged']and report['source_archive_verified']and report['asset_files_unchanged']and not errors)
            attempt('final report',lambda:write(output/'report.json',report))
            if primary is not None:
                for label,error in errors:primary.add_note(label+': '+type(error).__name__)
                raise primary
            if cleanup_error is not None:raise cleanup_error
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    result=finish(args.output/'report.json',lambda:run(args.output),write,public_io.public_report)
    print(json.dumps({n:result[n]for n in ('passed','complete','tests','elapsed_s')},allow_nan=False))
    raise SystemExit(0 if result['passed']else 1)
