from pathlib import Path
import json,math
import numpy as np
import pytest
import public_contract
from test_routing import backend_free
from fixtures import *
from encrypted_bert_all_gelu import BertGeluContract

def contract():return BertGeluContract((Path(__file__).parent/'candidate_manifest.json').read_bytes(),0)
def test_fixed_full_range_distinct_rows_and_padding():
    x=make_values();rows=x.reshape(16,4096)
    assert x.shape==(65536,) and x.dtype==np.float64 and x.min()==-21 and x.max()==14
    assert np.all(rows[:,3072:]==0) and len({row.tobytes() for row in rows})==16
    refs=client_oracles(x,contract());assert tuple(refs)==CHECKPOINTS
    for n in [2,4,8,16,32,64]:
        t=refs['domain map'];expected=np.cos(n*np.arccos(np.clip(t,-1,1)))
        np.testing.assert_allclose(refs[f'T{n}'],expected,atol=3e-13,rtol=0)
    p0=np.polynomial.chebyshev.chebval(7/35,contract().coefficients)
    assert np.all(refs['output'][padding_mask()]==p0)
    assert all(checkpoint_error(v,v)['passed'] for v in refs.values())

def test_actual_public_profile_noncanonical_scale_and_complete_schedule():
    r=public_contract.preflight(actual_security=False);q=r['q_towers'];s=r['scale']
    assert r['rotation_indices']==[] and r['raw_rotation_key_bytes']==0
    assert r['prestage_scale']==float(s)*float(s)/math.prod(q[50:52])==1.506919487555368e18
    assert r['prestage_scale']!=s and r['plan']['output_level']==10
    assert r['plan']['ciphertext_products']==63 and r['plan']['weighted_operations']==65 and r['plan']['actual_composite_rescales']==128
    assert r['checkpoints']['prestage']['level']==24 and len(r['checkpoints'])==9
    # Independent public binary64 weighted-sum order for the first affine.
    D=math.prod(q[48:50]);encoded=(s*D)/r['prestage_scale']
    assert r['checkpoints']['domain map']['scale']==float(r['prestage_scale'])*float(encoded)/D
    json.dumps(r,allow_nan=False)

@pytest.mark.parametrize('kind',['nan','inf','shape','complex','bool','overflow'])
def test_metrics_fail_closed_and_json_safe(kind):
    a=np.zeros(SLOTS);b=np.zeros(SLOTS)
    if kind=='nan':a[0]=np.nan
    elif kind=='inf':a[0]=np.inf
    elif kind=='shape':a=a[:-1]
    elif kind=='complex':a=a.astype(complex)
    elif kind=='bool':a=a.astype(bool)
    else:a.fill(np.finfo(float).max);b.fill(-np.finfo(float).max)
    result=checkpoint_error(a,b);assert not result['passed'];json.dumps(result,allow_nan=False)
    diagnostic=native_diagnostic(a,b);json.dumps(diagnostic,allow_nan=False)

@pytest.mark.parametrize('bad',[-21.0001,14.0001,float('nan')])
def test_oracle_domain_rejection(bad):
    x=make_values();x[0]=bad
    with pytest.raises(ValueError):client_oracles(x,contract())

def test_actual_noncanoical_prestage_matches_generic_payload_and_scale_double(backend_free):
    from test_gelu64 import Arithmetic,value
    from encrypted_bert_all_gelu import BertGelu
    r=public_contract.preflight(actual_security=False);ops=Arithmetic();x=make_values()
    prestage=ops.multiply(value(x,25,r['scale']),value(np.ones(SLOTS),25,r['scale']))
    assert prestage._ckks_scale==r['prestage_scale'] and prestage.level==24
    retained={}
    owner=BertGelu(ops,contract(),progress=lambda n,v,c:retained.setdefault(n,v))
    output=owner.evaluate_tile(prestage)
    assert owner.last_plan==r['plan'] and output.level==10
    references=client_oracles(x,contract())
    for name in CHECKPOINTS:
        v=prestage if name=='prestage' else retained[name]
        assert v.level==r['checkpoints'][name]['level'] and v._ckks_scale==r['checkpoints'][name]['scale']
        assert checkpoint_error(v.data,references[name])['passed']
    assert sum(c[0]=='multiply' for c in ops.calls)==64
    assert sum(c[0]=='weighted_sum' for c in ops.calls)==65


def test_exact_generic_owner_and_manifest_are_pinned():
    import hashlib
    p=Path(__file__).parent
    origin=json.loads((p/'source_origin.json').read_text())
    assert hashlib.sha256((p/'checkout/cadathlon/common/encrypted_bert_all_gelu.py').read_bytes()).hexdigest()==origin['generic_owner_sha256']=='fdedce34acda01b1da9f093ca37eeae2b4911ba0b4ec1c9a921b637b278e837c'
    assert hashlib.sha256((p/'candidate_manifest.json').read_bytes()).hexdigest()==origin['manifest_sha256']
