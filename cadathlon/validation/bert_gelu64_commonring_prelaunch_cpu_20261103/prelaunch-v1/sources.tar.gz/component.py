"""Genuine fixed full-ring GELU64 component; client decode after all server outputs."""
from pathlib import Path
import gc,hashlib,sys,time
import numpy as np
from lifecycle import CleanupTracker
from fixtures import make_values,client_oracles,checkpoint_error,native_diagnostic,CHECKPOINTS
from public_contract import HERE,ROOT,preflight
sys.path[:0]=[str(ROOT),str(ROOT/'cadathlon/common')]

def digest(value):return hashlib.sha256(np.asarray(value).tobytes()).hexdigest()
def keyless(ctx):
    if ctx.secret_key is not None or ctx._param_cache.secret_key is not None or ctx.parameters.get('secret_key') is not None:raise ValueError('server secret material present')
def fingerprint(value,ops):
    return digest(value.polynomial),tuple((n,type(getattr(value,n,None)).__name__,getattr(value,n,None)) for n in
        ('_ckks_scale','_ckks_nsd','batch','num_elements','degree','degree_layout','moduli')),ops._level(value)

def run(report,phase,verify_sources):
    import os
    if os.environ.get('JAX_PLATFORMS')!='cpu':raise ValueError('explicit CPU backend required')
    import jax
    from jaxite_word import CKKSContext,ckks_ctx,key_gen
    from encrypted_ntt import enable_scoped_ntt_subsets
    from encrypted_packed_qwen import CompiledArithmetic
    from encrypted_bert_all_gelu import BertGelu,BertGeluContract
    from support import require_secure_execution
    jax.config.update('jax_enable_x64',True)
    if jax.default_backend()!='cpu' or any(d.platform!='cpu' for d in jax.devices()):raise ValueError('CPU backend not honored')
    ring=preflight(actual_security=True);report['ring']=ring
    contract=BertGeluContract((HERE/'candidate_manifest.json').read_bytes(),0)
    refs=client_oracles(make_values(),contract)
    client=server=ops=provider=keys=evaluation=graph=value=output=prestage=None
    inputs={};fingerprints={};retained={};patches=[];codec_patches=[]
    def forbidden(*args,**kwargs):raise AssertionError('client codec/runtime key generation during keyless server arithmetic')
    try:
        q,p,N,dnum=ring['q_towers'],ring['p_towers'],ring['degree'],ring['dnum'];scale=ring['scale']
        phase('actual secure profile and independent client fixture preflight complete')
        report['key_generation_started']=True
        keys=key_gen.gen_pke_pair(q,[],N)
        evaluation=key_gen.gen_evaluation_key(keys['secret_key'],q=q,P=p,dnum=dnum)
        params=dict(degree=N,num_slots=65536,scaling_factor=scale,output_scale=scale,q_towers=q,p_towers=p,
            composite_degree=2,degree_layout=(256,512),p=60,CKKS_M_FACTOR=1,max_bits_in_word=61,noise_scale_degree=1)
        client=CKKSContext(dict(params,**keys))
        server=CKKSContext(dict(params,evaluation_key=[jax.numpy.asarray(evaluation[n],dtype='uint32').transpose(0,2,1) for n in ('a','b')]))
        modules={key_gen,sys.modules.get('key_gen')}-{None}
        if {m.__name__ for m in modules}!={'jaxite_word.key_gen','key_gen'}:raise RuntimeError('both keygen aliases required')
        for module in modules:
            for name in ('gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen'):
                patches.append((module,name,getattr(module,name)));setattr(module,name,forbidden)
        report['key_generation_guards']={m.__name__:['gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen'] for m in modules}
        server.program_initialization([],dnum=dnum,r=256,c=512,batch=1,pregenerated_rotation_keys={})
        keyless(server);report['keyless_server_initialized']=True
        client._polynomial_ntt_ctx=server._param_cache.ntt_q_max
        provider=enable_scoped_ntt_subsets(server)
        ops=CompiledArithmetic(server,low_memory=True,preserve_dispatch_cache=True)
        keys=evaluation=None
        report['encryption_started']=True
        for name,array in [('values',make_values()),('ones',np.ones(65536))]:
            value=client.encrypt_slots(array)
            value=server.he_level_reduce[49,25].level_reduce(value)
            if type(value._ckks_nsd)is not int or value._ckks_nsd!=1 or value._ckks_scale!=scale:raise RuntimeError('fresh input metadata differs')
            require_secure_execution(server,value);inputs[name]=value;fingerprints[name]=fingerprint(value,ops)
        value=array=None
        for name in ('encrypt','decrypt','encrypt_slots','decrypt_slots','encrypt_slots_batch','decrypt_slots_batch','decode'):
            codec_patches.append((CKKSContext,name,getattr(CKKSContext,name)));setattr(CKKSContext,name,forbidden)
        report['codec_guards']=[name for _,name,_ in codec_patches]
        phase('values and ones encrypted at level25; all seven codecs guarded')
        prestage=ops.multiply(inputs['values'],inputs['ones']);prestage.polynomial.block_until_ready()
        if ops._level(prestage)!=24 or prestage._ckks_scale!=ring['prestage_scale'] or type(prestage._ckks_nsd)is not int or prestage._ckks_nsd!=1:raise RuntimeError('real multiplication prestage metadata differs')
        retained['prestage']=prestage
        phase('genuine noncanonical input created',dict(level=24,scale=prestage._ckks_scale,nsd=prestage._ckks_nsd))
        before=fingerprint(prestage,ops)
        def progress(label,current,counts):
            keyless(server);current.polynomial.block_until_ready()
            if label in CHECKPOINTS:
                if label in retained:raise RuntimeError('duplicate retained checkpoint')
                retained[label]=current
            phase(label,dict(level=ops._level(current),scale=current._ckks_scale,nsd=current._ckks_nsd,counts=counts))
        graph=BertGelu(ops,contract,progress=progress)
        output=graph.evaluate_tile(prestage)
        output.polynomial.block_until_ready()
        if set(retained)!=set(CHECKPOINTS) or graph.last_plan!=ring['plan']:raise RuntimeError('fixed checkpoint/actual metadata plan differs')
        report['gelu_plan']=graph.last_plan
        keyless(server)
        report['input_payload_and_metadata_unchanged']=(fingerprint(prestage,ops)==before and all(fingerprint(v,ops)==fingerprints[n] for n,v in inputs.items()))
        if not report['input_payload_and_metadata_unchanged']:raise RuntimeError('server changed input ciphertext')
        if verify_sources() is not True:raise RuntimeError('source closure changed before client decode')
        report['source_closure_verified_before_decode']=True
        report['server_complete_before_any_decode']=True
        phase('all nine ciphertext checkpoints complete and source closure verified; client validation begins')
        for module,name,original in codec_patches:setattr(module,name,original)
        codec_patches.clear()
        report['checks']={}
        for name in CHECKPOINTS:
            value=retained[name];decoded=np.asarray(client.decrypt_slots(value));expected=refs[name]
            result=checkpoint_error(decoded,expected);planned=ring['checkpoints'][name]
            metadata=(ops._level(value)==planned['level'] and type(value._ckks_nsd)is int and value._ckks_nsd==1 and type(value._ckks_scale)is float and value._ckks_scale==planned['scale'])
            result.update(passed=bool(result['passed'] and metadata),metadata_ok=metadata,slots_checked=65536,
                level=ops._level(value),scale=value._ckks_scale,nsd=value._ckks_nsd,expected_metadata=planned,execution_rings=require_secure_execution(server,value))
            if name=='prestage':
                result['domain_diagnostic']=dict(domain=list(contract.domain),decoded_all_slots_inside=bool(result['shape_and_finite'] and np.all((decoded>=contract.domain[0])&(decoded<=contract.domain[1]))),scope='Diagnostic only: endpoint encryption noise is judged by the fixed independent polynomial checkpoint gates.')
            report['checks'][name]=result
            if name=='output':report['native_gelu_diagnostic']=native_diagnostic(decoded,make_values())
        report['provider_stats']=dict(provider.stats)
        report['passed']=len(report['checks'])==9 and all(v['passed'] for v in report['checks'].values())
        phase('all-slot client validation complete')
    finally:
        tracker=CleanupTracker(sys.exception());attempt=tracker.attempt
        for module,name,original in codec_patches:attempt('restore codec',lambda:setattr(module,name,original))
        if provider is not None:attempt('provider.close',provider.close)
        if ops is not None:
            attempt('rotation.clear',lambda:ops.rotation.clear(executables=True))
            for helper in (ops._plaintext_multiply,ops._rescale):attempt('primitive.clear',lambda:helper.clear(executables=True))
            attempt('multiply compiler.clear',ops._multiplication_compiler.clear_executables)
        for context in (server,client):
            if context is not None:attempt('evict context',lambda:ckks_ctx.evict_context_caches(context))
        graph=value=output=prestage=keys=evaluation=ops=server=client=None
        retained.clear();inputs.clear();fingerprints.clear();refs.clear()
        attempt('jax.clear_caches',jax.clear_caches);attempt('gc.collect',gc.collect)
        for module,name,original in patches:attempt('restore keygen',lambda:setattr(module,name,original))
        report['cleanup_errors']=tracker.errors;report['cleanup_completed']=not tracker.errors
        report['passed']=bool(report.get('passed') and not tracker.errors)
        tracker.finish()
