"""Fixed synthetic full-ring probes and independent client-only references."""
import hashlib,math
import numpy as np
SLOTS=65536;GATE=1e-6
CHECKPOINTS=('prestage','domain map','T2','T4','T8','T16','T32','T64','output')
def make_values():
    rng=np.random.default_rng(20261103)
    rows=np.zeros((16,4096),dtype=np.float64)
    # Each physical row is distinct; all active positions cover the entire
    # unchanged domain, while the final1024 feature slots are exact padding.
    for row in range(16):
        values=rng.uniform(-21.,14.,3072)
        values[:1024]=np.linspace(-21.,14.,1024)
        values=np.roll(values,row*137)
        values[:7]=(-21.,14.,0.,np.nextafter(-21.,14.),np.nextafter(14.,-21.),-1e-8,1e-8)
        rows[row,:3072]=values
    return rows.reshape(-1)
def padding_mask():
    result=np.zeros((16,4096),dtype=bool);result[:,3072:]=True;return result.reshape(-1)
def client_oracles(values,contract):
    x=np.asarray(values)
    if x.shape!=(SLOTS,) or x.dtype!=np.float64 or not np.isfinite(x).all():raise ValueError('fixed real float64 slots required')
    lo,hi=contract.domain
    if np.any((x<lo)|(x>hi)):raise ValueError('input exceeds frozen GELU domain')
    t=x*(2/(hi-lo))-(hi+lo)/(hi-lo)
    out={'prestage':x.copy(),'domain map':t}
    for degree in (2,4,8,16,32,64):
        c=np.zeros(degree+1);c[-1]=1.;out[f'T{degree}']=np.polynomial.chebyshev.chebval(t,c)
    out['output']=np.polynomial.chebyshev.chebval(t,contract.coefficients)
    assert tuple(out)==CHECKPOINTS
    return out

def _real_slots(value):
    a=np.asarray(value)
    return a.shape==(SLOTS,) and a.dtype.kind in 'fiu' and np.isfinite(a).all()
def checkpoint_error(decoded,expected):
    good=_real_slots(decoded) and _real_slots(expected)
    result=dict(passed=False,shape_and_finite=bool(good),max_abs_error=None,padding_max_abs_error=None,gate=GATE)
    if good:
        with np.errstate(over='ignore',invalid='ignore'):
            difference=np.abs(np.asarray(decoded,dtype=np.float64)-np.asarray(expected,dtype=np.float64))
            maximum=float(np.max(difference));padding=float(np.max(difference[padding_mask()]))
        result.update(max_abs_error=maximum if math.isfinite(maximum) else None,
                      padding_max_abs_error=padding if math.isfinite(padding) else None,
                      passed=bool(math.isfinite(maximum) and maximum<=GATE))
    return result

def native_diagnostic(decoded,values):
    if not _real_slots(decoded) or not _real_slots(values):return dict(finite=False,max_abs_error=None,nrmse=None)
    x=np.asarray(values,dtype=np.float64)
    native=.5*x*(1+np.fromiter((math.erf(float(v)/math.sqrt(2)) for v in x),dtype=np.float64,count=SLOTS))
    with np.errstate(over='ignore',invalid='ignore',divide='ignore'):
        delta=np.asarray(decoded,dtype=np.float64)-native
        maximum=float(np.max(np.abs(delta)));nrmse=float(np.sqrt(np.mean(delta*delta))/max(float(np.sqrt(np.mean(native*native))),1e-12))
    return dict(finite=bool(math.isfinite(maximum) and math.isfinite(nrmse)),max_abs_error=maximum if math.isfinite(maximum) else None,nrmse=nrmse if math.isfinite(nrmse) else None,
                scope='GELU polynomial plus HE versus exact erf diagnostic, not a full-model gate')
