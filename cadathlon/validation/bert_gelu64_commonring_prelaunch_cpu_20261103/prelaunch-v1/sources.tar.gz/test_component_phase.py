"""Phase/security/cleanup doubles, not numerical evidence."""
from types import ModuleType,SimpleNamespace
import sys
import numpy as np
import pytest
import component,public_contract
from fixtures import client_oracles,CHECKPOINTS
from encrypted_bert_all_gelu import BertGeluContract

@pytest.fixture
def fake_crypto(monkeypatch):
    monkeypatch.setenv('JAX_PLATFORMS','cpu');ring=public_contract.preflight(actual_security=False)
    events=[];cleanup_error=[None];finished=[False];source_ok=[True];keyless_violation=[False]
    def preflight(**kwargs):events.append('security');return ring
    monkeypatch.setattr(component,'preflight',preflight)
    class Payload:
        def __init__(self,data):self.data=np.asarray(data)
        def __array__(self,dtype=None,copy=None):return np.asarray(self.data,dtype=dtype)
        def block_until_ready(self):events.append('sync')
    class CT:
        batch=1;num_elements=2;degree=131072;degree_layout=(256,512)
        def __init__(self,data,level=49,scale=None):
            self.polynomial=Payload(data);self.level=level;self._ckks_scale=float(ring['scale'] if scale is None else scale)
            self._ckks_nsd=1;self.moduli=tuple(ring['q_towers'][:2*(level+1)])
    class Lower:
        def __getitem__(self,pair):return SimpleNamespace(level_reduce=lambda v:CT(np.asarray(v.polynomial),pair[1],v._ckks_scale))
    class Context:
        def __init__(self,params):self.parameters=params;self.secret_key=params.get('secret_key');self._param_cache=None;self.he_level_reduce=Lower()
        def program_initialization(self,rotations,**kwargs):
            assert rotations==[] and kwargs['pregenerated_rotation_keys']=={}
            events.append('initialize')
            for m in (packaged,flat):
                for n in ('gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen'):
                    with pytest.raises(AssertionError):getattr(m,n)()
            self._param_cache=SimpleNamespace(secret_key=None,ntt_q_max=object())
            if keyless_violation[0]:self.parameters['secret_key']=object()
        def encrypt_slots(self,x):events.append('encrypt');return CT(x)
        def decrypt_slots(self,v):
            assert finished[0] and 'source verify' in events and source_ok[0]
            events.append('decode');return np.asarray(v.polynomial)
        def encrypt(self,*a):raise AssertionError('unexpected')
        def decrypt(self,*a):raise AssertionError('unexpected')
        def encrypt_slots_batch(self,*a):raise AssertionError('unexpected')
        def decrypt_slots_batch(self,*a):raise AssertionError('unexpected')
        def decode(self,*a):raise AssertionError('unexpected')
    codecs={n:getattr(Context,n) for n in ('encrypt','decrypt','encrypt_slots','decrypt_slots','encrypt_slots_batch','decrypt_slots_batch','decode')}
    def pke(*a,**k):events.append('keygen');return dict(secret_key=object(),public_key=object())
    def relin(*a,**k):events.append('relin');return dict(a=np.zeros((1,1,1),np.uint32),b=np.zeros((1,1,1),np.uint32))
    packaged=ModuleType('jaxite_word.key_gen');flat=ModuleType('key_gen')
    for m in (packaged,flat):
        m.gen_pke_pair=pke;m.gen_evaluation_key=relin;m.gen_rotation_key=pke;m.key_switch_gen=pke
    originals={m:{n:getattr(m,n) for n in ('gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen')} for m in (packaged,flat)}
    def evict(c):
        events.append('evict')
        if cleanup_error[0]:raise cleanup_error[0]
    package=ModuleType('jaxite_word');package.CKKSContext=Context;package.key_gen=packaged;package.ckks_ctx=SimpleNamespace(evict_context_caches=evict)
    monkeypatch.setitem(sys.modules,'jaxite_word',package);monkeypatch.setitem(sys.modules,'jaxite_word.key_gen',packaged);monkeypatch.setitem(sys.modules,'key_gen',flat)
    monkeypatch.setitem(sys.modules,'jax',SimpleNamespace(config=SimpleNamespace(update=lambda *a:None),numpy=np,default_backend=lambda:'cpu',devices=lambda:[SimpleNamespace(platform='cpu')],clear_caches=lambda:events.append('jax clear')))
    monkeypatch.setitem(sys.modules,'encrypted_ntt',SimpleNamespace(enable_scoped_ntt_subsets=lambda ctx:SimpleNamespace(stats={},close=lambda:events.append('provider close'))))
    class Ops:
        def __init__(self,ctx,**kwargs):
            self.ctx=ctx;self.rotation=SimpleNamespace(clear=lambda **k:events.append('rotation clear'))
            self._plaintext_multiply=self._rescale=SimpleNamespace(clear=lambda **k:events.append('primitive clear'))
            self._multiplication_compiler=SimpleNamespace(clear_executables=lambda:events.append('compiler clear'))
        def _level(self,v):return v.level
        def multiply(self,a,b):
            for n in codecs:
                with pytest.raises(AssertionError):getattr(Context,n)(None,None)
            events.append('multiply');return CT(np.asarray(a.polynomial)*np.asarray(b.polynomial),24,ring['prestage_scale'])
    monkeypatch.setitem(sys.modules,'encrypted_packed_qwen',SimpleNamespace(CompiledArithmetic=Ops))
    class Graph:
        def __init__(self,ops,contract,progress):self.contract=contract;self.progress=progress;self.last_plan=None
        def evaluate_tile(self,v):
            for n in codecs:
                with pytest.raises(AssertionError):getattr(Context,n)(None,None)
            refs=client_oracles(np.asarray(v.polynomial),self.contract)
            for n in CHECKPOINTS[1:]:
                p=ring['checkpoints'][n];out=CT(refs[n],p['level'],p['scale']);self.progress(n,out,{})
            self.last_plan=ring['plan'];finished[0]=True;return out
    monkeypatch.setitem(sys.modules,'encrypted_bert_all_gelu',SimpleNamespace(BertGelu=Graph,BertGeluContract=BertGeluContract))
    monkeypatch.setitem(sys.modules,'support',SimpleNamespace(require_secure_execution=lambda *a:dict(test_double=True)))
    def verify():events.append('source verify');return source_ok[0]
    def restored():
        assert all(getattr(Context,n)is v for n,v in codecs.items())
        assert all(getattr(m,n)is v for m,values in originals.items() for n,v in values.items())
    return SimpleNamespace(ring=ring,events=events,cleanup_error=cleanup_error,source_ok=source_ok,keyless_violation=keyless_violation,verify=verify,restored=restored)

def test_all_server_outputs_and_sources_precede_decode(fake_crypto):
    f=fake_crypto;r={};component.run(r,lambda *a:None,f.verify)
    assert r['passed'] and len(r['checks'])==9 and r['cleanup_completed'] and r['input_payload_and_metadata_unchanged']
    assert f.events.index('security')<f.events.index('keygen')<f.events.index('initialize')<f.events.index('encrypt')<f.events.index('multiply')<f.events.index('source verify')<f.events.index('decode')
    assert f.events.count('decode')==9;f.restored()

def test_source_failure_prevents_all_client_decode(fake_crypto):
    f=fake_crypto;f.source_ok[0]=False;r={}
    with pytest.raises(RuntimeError,match='source closure'):component.run(r,lambda *a:None,f.verify)
    assert 'decode' not in f.events and r['cleanup_completed'];f.restored()

@pytest.mark.parametrize('primary',[False,True])
def test_cleanup_cancellation_attempts_all_and_preserves_primary(fake_crypto,primary):
    f=fake_crypto;interrupt=KeyboardInterrupt('cleanup');failure=ValueError('primary');f.cleanup_error[0]=interrupt;r={}
    def phase(label,*args):
        if primary and label=='T4':raise failure
    with pytest.raises(ValueError if primary else KeyboardInterrupt) as e:component.run(r,phase,f.verify)
    assert e.value is (failure if primary else interrupt) and not r['cleanup_completed'] and not r['passed']
    assert f.events.count('evict')==2 and 'jax clear' in f.events;f.restored()

def test_context_parameter_secret_is_rejected_before_encryption(fake_crypto):
    f=fake_crypto;f.keyless_violation[0]=True;r={}
    with pytest.raises(ValueError,match='secret'):component.run(r,lambda *a:None,f.verify)
    assert 'encrypt' not in f.events and 'decode' not in f.events;f.restored()

def test_wrong_metadata_fails_unchanged_numeric_gate(fake_crypto,monkeypatch):
    f=fake_crypto;Graph=sys.modules['encrypted_bert_all_gelu'].BertGelu;original=Graph.evaluate_tile
    def wrong(self,*args):
        output=original(self,*args);output._ckks_scale=float(np.nextafter(output._ckks_scale,np.inf));return output
    monkeypatch.setattr(Graph,'evaluate_tile',wrong);r={};component.run(r,lambda *a:None,f.verify)
    assert not r['passed'] and r['checks']['output']['max_abs_error']==0 and not r['checks']['output']['metadata_ok'];f.restored()
