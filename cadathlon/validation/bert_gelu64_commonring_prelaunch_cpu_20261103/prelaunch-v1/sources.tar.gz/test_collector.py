from pathlib import Path
from types import SimpleNamespace
import hashlib,io,json,sys,tarfile
import pytest
import collect,public_contract

@pytest.fixture
def collector(tmp_path,monkeypatch):
    monkeypatch.setenv('JAX_PLATFORMS','cpu')
    monkeypatch.setattr(collect,'sources',lambda:{'a.py':b'fixed'})
    monkeypatch.setattr(collect.importlib.metadata,'version',lambda n:'test')
    monkeypatch.setattr(public_contract,'preflight',lambda **kw:dict(current_key_storage_free_bytes=100,raw_all_owned_public_key_bytes=1,additional_storage_margin_bytes=1))
    return SimpleNamespace(output=tmp_path/'attempt',preflight=True)

def test_collector_preflight_archives_every_source_and_never_encrypts(collector):
    assert collect.collect(collector)==0
    r=json.loads((collector.output/'report.json').read_text())
    assert r['passed'] and r['complete'] and r['source_archive_verified'] and r['source_files_unchanged']
    assert not r['key_generation_started'] and not r['encryption_started']

@pytest.mark.parametrize('where',('initial_publication','initial_sources','public_preflight','component','final_sources'))
def test_failure_keeps_terminal_evidence_and_primary_cancellation(collector,monkeypatch,where):
    failure=KeyboardInterrupt(where);real_write=collect.write
    if where=='initial_publication':
        calls=[]
        def writer(path,data):
            calls.append(1)
            if len(calls)==1:raise failure
            real_write(path,data)
        monkeypatch.setattr(collect,'write',writer)
    elif where in ('initial_sources','final_sources'):
        calls=[]
        def sources():
            calls.append(1)
            if where=='initial_sources' and len(calls)==1 or where=='final_sources' and len(calls)==2:raise failure
            return {'a.py':b'fixed'}
        monkeypatch.setattr(collect,'sources',sources)
    elif where=='public_preflight':monkeypatch.setattr(public_contract,'preflight',lambda **k:(_ for _ in ()).throw(failure))
    else:
        collector.preflight=False;monkeypatch.setitem(sys.modules,'component',SimpleNamespace(run=lambda *a:(_ for _ in ()).throw(failure)))
    with pytest.raises(KeyboardInterrupt) as caught:collect.collect(collector)
    assert caught.value is failure
    r=json.loads((collector.output/'report.json').read_text());assert not r['passed']
    assert r['errors'] or r['collector_cleanup_errors']

def test_primary_failure_survives_final_publication_error(collector,monkeypatch):
    primary=KeyboardInterrupt('primary');real_write=collect.write;calls=[]
    monkeypatch.setattr(public_contract,'preflight',lambda **k:(_ for _ in ()).throw(primary))
    def write(path,data):
        calls.append(1)
        if len(calls)>1:raise OSError('publication')
        return real_write(path,data)
    monkeypatch.setattr(collect,'write',write)
    with pytest.raises(KeyboardInterrupt) as caught:collect.collect(collector)
    assert caught.value is primary and any('publication' in note for note in primary.__notes__)

@pytest.mark.parametrize('kind',('duplicate','different','symlink'))
def test_source_archive_exact_member_readback(tmp_path,kind):
    path=tmp_path/'source.tar.gz';raw=b'one';expected={'a':hashlib.sha256(raw).hexdigest()}
    with tarfile.open(path,'w:gz') as t:
        member=tarfile.TarInfo('a');member.size=3
        if kind=='symlink':member.type=tarfile.SYMTYPE;member.linkname='else';member.size=0;t.addfile(member)
        else:
            t.addfile(member,io.BytesIO(b'two' if kind=='different' else raw))
            if kind=='duplicate':t.addfile(member,io.BytesIO(raw))
    with pytest.raises(ValueError):collect.verify_archive(path,expected)

