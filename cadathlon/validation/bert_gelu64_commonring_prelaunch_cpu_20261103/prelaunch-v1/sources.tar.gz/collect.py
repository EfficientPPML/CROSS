"""Source-bound CPU whole-domain GELU64 component collector; no implicit healthy timeout."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,importlib.metadata,io,json,os,resource,signal,sys,tarfile,time
from lifecycle import CleanupTracker
HERE=Path(__file__).resolve().parent

def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(path,record):
    temporary=path.with_suffix('.tmp');temporary.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');temporary.replace(path)
def sources():
    files=set(HERE.glob('*.py'))|{HERE/n for n in ('candidate_manifest.json','actual_profile_audit.json','source_origin.json','p60_profile_and_refresh.json')}
    files.update((HERE/'checkout').rglob('*.py'))
    return {str(p.relative_to(HERE)):p.read_bytes() for p in sorted(files)}
def verify_archive(path,expected):
    with tarfile.open(path) as t:
        members=t.getmembers()
        if len(members)!=len(expected) or len({m.name for m in members})!=len(members) or not all(m.isfile() for m in members):raise ValueError('source archive inventory differs')
        if {m.name:sha(t.extractfile(m).read()) for m in members}!=expected:raise ValueError('source archive bytes differ')
    return True

def collect(args):
    args.output.mkdir(parents=True,exist_ok=False)
    report=dict(scope=__doc__,passed=False,complete=False,preflight_only=args.preflight,
        started_utc=datetime.now(timezone.utc).isoformat(),cpu_affinity=sorted(os.sched_getaffinity(0)),process_pid=os.getpid(),
        phases=[],errors=[],checks={},fixed_absolute_error_gate=1e-6,key_generation_started=False,encryption_started=False,
        full_attention_evaluated=False,full_block_evaluated=False,full_model_evaluated=False,refresh_performed=False,
        calibrated_timing=False,limitations=['One fixed synthetic full-slot GELU fixture with endpoint/interior probes and zero padding; no native FFN or complete block.',
            'Client and keyless server are separate objects in one dedicated process; not a three-process file boundary or OS sandbox.',
            'All seven client codec APIs are blocked through the genuine noncanonical prestage and all nine checkpoints; no early decode.',
            'The exact layer0 v2 degree64 balanced GELU is used; no refresh or rotation keys are required.',
            'T64 boundary amplification is covered only if the unchanged1e-6 all-slot gate passes.',
            'Raw key payload and phase RSS observations are not a peak device memory or scoring calibration claim.'])
    start=time.monotonic();primary=None;before={};handlers={}
    def interrupted(number,frame):
        for signum in handlers:signal.signal(signum,signal.SIG_IGN)
        raise KeyboardInterrupt('interrupted by signal '+str(number))
    def phase(label,extra=None):
        report['phases'].append(dict(label=label,elapsed_s=time.monotonic()-start,peak_host_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,**(extra or {})))
        write(args.output/'report.json',report);print(json.dumps(report['phases'][-1]),flush=True)
    try:
        write(args.output/'report.json',report)
        for number in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):handlers[number]=signal.signal(number,interrupted)
        raw=sources();before={name:sha(data) for name,data in raw.items()}
        with tarfile.open(args.output/'sources.tar.gz','w:gz') as t:
            for name,data in raw.items():info=tarfile.TarInfo(name);info.size=len(data);t.addfile(info,io.BytesIO(data))
        report.update(source_hashes_before=before,source_archive_sha256=sha((args.output/'sources.tar.gz').read_bytes()),
            source_archive_verified=verify_archive(args.output/'sources.tar.gz',before),
            versions={n:importlib.metadata.version(n) for n in ('jax','jaxlib','numpy')},
            environment={n:os.environ.get(n) for n in ('JAX_PLATFORMS','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')})
        if os.environ.get('JAX_PLATFORMS')!='cpu':raise ValueError('explicit JAX_PLATFORMS=cpu required')
        from public_contract import preflight
        report['ring']=preflight(actual_security=True)
        phase('fixed public profile, P coverage, slots and oracle preflight passed')
        if args.preflight:report['passed']=True
        else:
            import component
            def verify_sources_before_decode():
                return {n:sha(v) for n,v in sources().items()}==before and verify_archive(args.output/'sources.tar.gz',before)
            component.run(report,phase,verify_sources_before_decode)
        report['complete']=True
    except BaseException as error:
        primary=error;report['passed']=False;report['errors'].append(dict(type=type(error).__name__,message=str(error)))
    finally:
        tracker=CleanupTracker(primary)
        for number,handler in handlers.items():tracker.attempt('restore signal',lambda:signal.signal(number,handler))
        after_raw=tracker.attempt('read final sources',sources)
        after={name:sha(data) for name,data in after_raw.items()} if after_raw is not None else {}
        verified=tracker.attempt('verify final archive',lambda:verify_archive(args.output/'sources.tar.gz',before))
        report.update(source_hashes_after=after,source_files_unchanged=bool(before) and before==after,
            source_archive_verified=verified is True,collector_cleanup_errors=tracker.errors,
            elapsed_s=time.monotonic()-start,peak_host_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            finished_utc=datetime.now(timezone.utc).isoformat())
        report['passed']=bool(report['passed'] and before and before==after and verified and not tracker.errors)
        try:write(args.output/'report.json',report)
        except BaseException as error:
            preserved=primary if primary is not None else tracker.cancellation
            if preserved is None:raise
            preserved.add_note('Final publication failed: '+repr(error))
        tracker.finish()
    if primary is not None:raise primary
    return 0 if report['passed'] else 1

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);p.add_argument('--preflight',action='store_true');args=p.parse_args()
    return collect(args)
if __name__=='__main__':raise SystemExit(main())
