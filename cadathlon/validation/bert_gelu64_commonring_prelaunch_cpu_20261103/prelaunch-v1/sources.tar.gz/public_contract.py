"""Actual pinned profile and metadata plan; no keys or ciphertexts."""
from pathlib import Path
import hashlib,json,math,sys
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=HERE/'checkout'
sys.path[:0]=[str(ROOT),str(ROOT/'cadathlon/common')]
from encrypted_bert_all_gelu import BertGeluContract,gelu_plan
from fixtures import make_values,client_oracles,CHECKPOINTS,padding_mask
AUDIT_SHA256='2b2457e50da73b9ccf87984c089afcb99586fde863a48e98b89a1b7ccf872a17'
INPUT_LEVEL=24;PRESTAGE_LEVEL=25

def preflight(*,actual_security=True):
    raw=(HERE/'actual_profile_audit.json').read_bytes()
    if hashlib.sha256(raw).hexdigest()!=AUDIT_SHA256:raise ValueError('actual public profile audit differs')
    record=next(x for x in json.loads(raw)['profiles'] if x['name']=='depth49_p60_d8')
    q,p=record['q'],record['p'];degree=record['degree'];dnum=record['dnum'];scale=record['canonical_scale']
    if (degree,record['depth'],record['scale_bits'],dnum,len(q),len(p))!=(131072,49,60,8,100,14):raise ValueError('fixed common-ring profile differs')
    if any(type(x)is not int or x<=1 or x%(2*degree)!=1 for x in q+p) or len(set(q+p))!=114:raise ValueError('invalid actual ordered prime inventory')
    if math.prod(q+p).bit_length()>3523:raise ValueError('actual QP security bound exceeded')
    alpha=math.ceil(len(q)/dnum);parts=math.ceil(len(q)/alpha)
    if any(math.prod(q[i:i+alpha])>math.prod(p) for i in range(0,len(q),alpha)):raise ValueError('actual P coverage failed')
    if actual_security:
        from jaxite_word import he_params
        if not he_params.qp_is_secure(q,p,degree,he_params.SecurityTarget(128,'classical')):raise ValueError('actual qp_is_secure failed before keygen')
        he_params.assert_p_coverage(q,p,dnum)
    contract=BertGeluContract((HERE/'candidate_manifest.json').read_bytes(),0)
    divisor=math.prod(q[2*PRESTAGE_LEVEL:2*(PRESTAGE_LEVEL+1)])
    input_scale=float(scale)*float(scale)/divisor
    assert input_scale==1.506919487555368e18 and input_scale!=scale
    plan=gelu_plan(q[:2*(INPUT_LEVEL+1)],degree=64,input_level=INPUT_LEVEL,canonical_scale=scale,input_scale=input_scale)
    refs=client_oracles(make_values(),contract)
    checkpoints={'prestage':dict(level=INPUT_LEVEL,scale=input_scale)}
    checkpoints.update({row['name']:dict(level=row['level'],scale=row['scale']) for row in plan['stages'] if row['name'] in CHECKPOINTS})
    assert set(checkpoints)==set(CHECKPOINTS) and plan['output_level']==10
    pair=2*parts*(len(q)+len(p))*degree*4
    return dict(degree=degree,slots=65536,depth=49,scale_bits=60,dnum=dnum,q_towers=q,p_towers=p,scale=scale,
        actual_log2_QP=sum(map(math.log2,q+p)),actual_QP_bit_length=math.prod(q+p).bit_length(),actual_qp_is_secure_checked=actual_security,P_coverage_passed=True,
        degree_layout=[256,512],actual_switch_partitions=parts,raw_relinearization_pair_bytes=pair,raw_public_key_bytes=2*len(q)*degree*4,
        rotation_indices=[],raw_rotation_key_bytes=0,input_level=24,prestage_level=25,prestage_divisor=divisor,prestage_scale=input_scale,
        plan=plan,checkpoints=checkpoints,input_sha256=hashlib.sha256(make_values().astype('<f8').tobytes()).hexdigest(),
        reference_sha256={n:hashlib.sha256(v.astype('<f8').tobytes()).hexdigest() for n,v in refs.items()},
        padding_slots=int(padding_mask().sum()),domain=list(contract.domain),coefficient_sha256=hashlib.sha256(np.asarray(contract.coefficients,dtype='<f8').tobytes()).hexdigest(),
        fixed_checkpoint_absolute_gate=1e-6,expected_checkpoint_count=9,
        limitations=['No refresh or rotation keys; one supplied relinearization pair. Raw key sizes exclude tables/executables/retained ciphertexts and are not peak memory.',
                    'Synthetic whole-domain probes and P(0) padding only; no native FFN, residual, LayerNorm, complete block or full model.',
                    'T64 at interval endpoints can amplify ciphertext error; the unchanged1e-6 all-slot gate remains authoritative.'])
