"""Independent polynomial evaluation, fixed-domain and complete-reference guards."""
from pathlib import Path
import importlib.util
import numpy as np
import pytest
from full_model_reference import Arithmetic,DomainViolation,manifest,tensor_shapes,compute
RAW=Path('/tmp/bert-twelve-layer-continuation-plan-20261103/candidate_manifest.json').read_bytes()

@pytest.mark.parametrize('site',[f'{i}.{kind}' for i in range(12) for kind in ('attention','mlp')])
def test_each_selected_norm_polynomial_agrees_with_independent_direct_basis(site):
    a=Arithmetic(RAW,approximate=True);rule=a.manifest['norms'][site];p=rule['polynomial'];lo,hi=p['domain']
    x=np.linspace(lo+.01*(hi-lo),hi-.01*(hi-lo),65);t=x*(2/(hi-lo))-(hi+lo)/(hi-lo)
    y=a.polynomial(x,p,rule['method'],site)
    if rule['method']=='power':
        c=np.polynomial.chebyshev.cheb2poly(p['coefficients']);expected=sum(c[i]*np.power(t,i) for i in range(len(c)))
    else:
        # Explicit trigonometric basis is independent of Clenshaw recurrence.
        expected=sum(c*np.cos(i*np.arccos(t)) for i,c in enumerate(p['coefficients']))
    np.testing.assert_allclose(y,expected,atol=1e-7,rtol=0)

@pytest.mark.parametrize('kind',('polynomial','inverse','softmax','gelu','tanh','nan'))
def test_declared_domain_rejects_without_clipping(kind):
    a=Arithmetic(RAW,approximate=True)
    with pytest.raises(DomainViolation):
        if kind=='polynomial':a.polynomial(np.array([100.]),a.manifest['norms']['0.attention']['polynomial'],'power','norm')
        elif kind=='inverse':a.inverse(np.array([0.]),a.manifest['initial_reciprocal'],'inverse')
        elif kind=='softmax':a.softmax(np.array([[[100.,-100.]]]),0)
        elif kind=='gelu':a.gelu(np.array([1000.]),0)
        elif kind=='tanh':a.tanh(np.array([35.]))
        else:a.polynomial(np.array([np.nan]),a.manifest['base_exp'],'power','nonfinite')
    assert a.observations and any(a.observations[-1][key] for key in ('below','above','nonfinite'))

def test_exact_nonlinear_mode_is_native_function_reference():
    a=Arithmetic(RAW,approximate=False)
    np.testing.assert_allclose(a.softmax(np.array([[[1000.,1000.]]]),0),.5,atol=0,rtol=0)
    x=np.array([-2.,0.,2.]);np.testing.assert_array_equal(a.tanh(x),np.tanh(x))
    assert not a.observations

def test_manifest_and_full_tensor_inventory_strict():
    with pytest.raises(ValueError):manifest(RAW+b' ')
    with pytest.raises(ValueError):Arithmetic(RAW,approximate=1)
    shapes=tensor_shapes();assert len(shapes)==196
    assert not any('embedding' in n for n in shapes)
    assert shapes['bert.encoder.layer.11.intermediate.dense.weight']==(3072,768)
    with pytest.raises(ValueError):compute(np.zeros((15,768)),{},RAW,approximate=True)

@pytest.mark.parametrize('K',(1,15,128))
def test_rational_softmax_normalization_finite_and_domains(K):
    a=Arithmetic(RAW,approximate=True)
    scores=np.sin(np.arange(12*3*K).reshape(12,3,K)*.317)*.4
    output=a.softmax(scores,0)
    assert output.shape==scores.shape and np.isfinite(output).all() and np.all(output>0)
    np.testing.assert_allclose(output.sum(axis=-1),1.,atol=1e-12,rtol=0)
    assert len(a.observations)==3+a.manifest['softmax']['0']['squarings']
