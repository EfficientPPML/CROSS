from pathlib import Path
import ast,hashlib,json,sys,tarfile,time,argparse
from contextlib import contextmanager
from types import SimpleNamespace as NS
import pytest
HERE=Path(__file__).parent

def actual_run(tmp_path,write,guard):
 tree=ast.parse((HERE/'preflight_combined.py').read_bytes())
 fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='run')
 env=dict(Path=Path,os=__import__('os'),time=time,sys=sys,guard=guard,HERE=tmp_path,EXTRA=(),write=write,tarfile=tarfile,hashlib=hashlib)
 exec(compile(ast.Module(body=[fn],type_ignores=[]),'exact_run','exec'),env)
 return env['run']

@pytest.mark.parametrize('kind',(KeyboardInterrupt,SystemExit))
def test_body_primary_survives_final_source_and_publication_failures(tmp_path,kind):
 primary=kind('body cancellation');checks=[];writes=[]
 def check(*args,**kwargs):
  checks.append(1)
  if len(checks)==1:raise primary
  raise OSError('final source failure')
 def write(path,value):
  writes.append(1)
  if len(writes)>1:raise OSError('final publication failure')
  path.write_text(json.dumps(value))
 run=actual_run(tmp_path,write,NS(capture_sources=lambda *a,**k:{},check_sources=check))
 with pytest.raises(BaseException)as caught:run(tmp_path/'out',source_guard_tests=1)
 assert caught.value is primary

def test_outer_termination_failure_republishes_failed_record(tmp_path,monkeypatch):
 tree=ast.parse((HERE/'preflight_combined.py').read_bytes());node=next(n for n in tree.body if isinstance(n,ast.If)and isinstance(n.test,ast.Compare))
 output=tmp_path/'report.json';failure=OSError('termination handler restoration')
 @contextmanager
 def termination():
  yield
  raise failure
 def run(*args,**kwargs):
  result=dict(passed=True,complete=True,source_count=265,groups=[],elapsed_seconds=1.)
  output.write_text(json.dumps(result));return result
 monkeypatch.setattr(sys,'argv',['preflight',str(tmp_path),'--source-guard-tests','36'])
 env={'__name__':'__main__','argparse':argparse,'termination_signals':termination,'run':run,'json':json}
 with pytest.raises(OSError):exec(compile(ast.Module(body=[node],type_ignores=[]),'exact_main','exec'),env)
 assert json.loads(output.read_text())['passed']is False
