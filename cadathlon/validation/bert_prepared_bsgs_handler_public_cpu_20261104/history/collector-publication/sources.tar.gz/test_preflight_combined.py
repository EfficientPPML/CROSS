"""Collector rejection/cleanup tests with synthetic child and source records."""
from pathlib import Path
import hashlib,json
from types import SimpleNamespace as NS
import pytest
import preflight_combined as collector


@pytest.mark.parametrize('fault',('none','nonzero','count','failure','skipped','source','cancellation'))
def test_false_success_rejected_and_started_child_closed(tmp_path,monkeypatch,fault):
    source=tmp_path/'public.py';source.write_text('PUBLIC=1\n')
    children=[];primary=KeyboardInterrupt('synthetic child cancellation')
    def capture(*args,**kwargs):return {'public.py':hashlib.sha256(source.read_bytes()).hexdigest()}
    def check(expected,*args,**kwargs):
        if capture()!=expected:raise ValueError('source changed')
        return dict(passed=True)
    class Child:
        def __init__(self,command,**kwargs):
            self.command=command;self.closed=False;self.primary=None
            self.record=dict(pid=100+len(children),direct_child_reaped=False,group_empty_verified=False,cleanup_completed=False,cleanup_errors=[])
            self.xml=Path(next(x.split('=',1)[1]for x in command if x.startswith('--junitxml=')))
            children.append(self)
        def wait(self):
            if fault=='cancellation':raise primary
            node='<testcase name="synthetic">'+({'failure':'<failure/>','skipped':'<skipped/>'}.get(fault,''))+'</testcase>'
            self.xml.write_text('<testsuites><testsuite>'+node*(2 if fault=='count'else 1)+'</testsuite></testsuites>')
            self.record.update(direct_child_reaped=True,group_empty_verified=True,cleanup_completed=True)
            if fault=='source':source.write_text('PUBLIC=2\n')
            return 2 if fault=='nonzero'else 0
        def close(self,primary=None):
            self.closed=True;self.primary=primary
            self.record.update(direct_child_reaped=True,group_empty_verified=True,cleanup_completed=True)
    monkeypatch.setattr(collector,'HERE',tmp_path)
    monkeypatch.setattr(collector,'GROUPS',(('only',('synthetic.py',),1),))
    monkeypatch.setattr(collector,'OwnedChild',Child)
    monkeypatch.setattr(collector,'guard',NS(capture_sources=capture,check_sources=check))
    out=tmp_path/'evidence'
    if fault=='none':
        result=collector.run(out,source_guard_tests=1)
        assert result['passed']and result['complete']and len(children)==2
    elif fault=='cancellation':
        with pytest.raises(KeyboardInterrupt)as caught:collector.run(out,source_guard_tests=1)
        assert caught.value is primary and children[0].primary is primary
    else:
        with pytest.raises(ValueError):collector.run(out,source_guard_tests=1)
    report=json.loads((out/'report.json').read_bytes())
    assert report['passed']is (fault=='none')
    assert report['all_started_children_reaped']and all(c.closed for c in children)
    if fault in ('nonzero','count','failure','skipped','cancellation'):assert len(children)==1
    if fault=='source':assert report['source_files_unchanged']is False and 'final_evidence_failure'in report
