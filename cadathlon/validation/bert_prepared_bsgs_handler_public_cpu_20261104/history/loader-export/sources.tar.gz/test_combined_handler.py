"""Actual isolated handler function with public filesystem/protocol doubles."""
from pathlib import Path
from types import SimpleNamespace as NS,ModuleType
from contextlib import contextmanager
import ast,sys,time
import pytest
P=Path(__file__).resolve().parent

def handler(globals_,path='runtime/stage/file_stages.py'):
    tree=ast.parse((P/path).read_bytes())
    fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='server_encrypted_compute')
    env=dict(globals_);exec(compile(ast.Module(body=[fn],type_ignores=[]),str(P/path),'exec'),env)
    return env['server_encrypted_compute']

@pytest.fixture
def rig(tmp_path,monkeypatch):
    events=[];fault={};nonce='b'*32;ctx=object();handle=NS(ctx=ctx,public_manifest={'context_id':'c'*64})
    paths={n:tmp_path/n for n in ('public_keys','upload','download','server_report')}
    upload=paths['upload'];upload.mkdir();(upload/'batch.json').write_text('{}');sample=upload/nonce;sample.mkdir()
    for i in range(8):(sample/f'tile{i}').mkdir()
    contract={'request_id':nonce,'input':{'original_positions':[0]}}
    batch={'requests':[dict(contract=contract,input_digest='input-digest')]}
    @contextmanager
    def loader(kind,path,**options):
        assert path==paths['public_keys'];events.append(('loader-open',kind,options));primary=None
        try:yield handle
        except BaseException as error:primary=error;raise
        finally:events.append(('loader-close',kind,primary))
    for name,attribute,kind in (('key_contexts','load_server','ordinary'),('loader_prepared_rotation','load_server_prepared','prepared')):
        module=ModuleType(name)
        setattr(module,attribute,lambda path,_kind=kind,**kw:loader(_kind,path,**kw));monkeypatch.setitem(sys.modules,name,module)
    def evaluate(tiles,weights,**kw):
        events.append(('evaluate',len(tiles),kw));assert len(tiles)==8 and type(tiles)is tuple
        if 'evaluate'in fault:raise fault['evaluate']
        return NS(output=NS(_ckks_scale=17.))
    @contextmanager
    def engine(context,**kw):
        assert context is ctx;events.append(('engine-open',kw));primary=None
        try:yield NS(evaluate=evaluate)
        except BaseException as error:primary=error;raise
        finally:events.append(('engine-close',primary))
    module=ModuleType('full_model_engine');module.server_engine=engine;monkeypatch.setitem(sys.modules,'full_model_engine',module)
    @contextmanager
    def directory(path):
        assert path==paths['download'];events.append(('download-open',));primary=None
        try:yield NS(path=path,check=lambda:events.append(('download-check',)))
        except BaseException as error:primary=error;raise
        finally:events.append(('download-close',primary))
    @contextmanager
    def file(path,data):
        events.append(('report-open',path));yield;events.append(('report-close',))
    def load(path,**kw):
        events.append(('load-tile',kw['tile_index']))
        if kw['tile_index']==3 and 'load'in fault:raise fault['load']
        return object(),dict(index=kw['tile_index'])
    def save(value,path,**kw):
        events.append(('save',kw));assert value._ckks_scale==17. and kw['input_digest']=='input-digest'
        return {'response':'public'}
    env=dict(Path=Path,time=time,_paths=lambda paths,**kw:1,_inputs=lambda:({'profile_bytes':b'profile','plan_bytes':b'plan'},b'candidate'),
        _scale_checker=lambda *args:lambda scale:scale==17.,_capacity=lambda *args:None,
        server_public_model=NS(load=lambda *a,**kw:({'weights':'public'},{'model':'public'})),_model_dir=lambda *args:'model',
        _public=lambda keys,model:dict(context_id=keys['context_id']),
        batches=NS(validate_public_batch=lambda *a,**kw:batch,response_batch=lambda b,rows:{'responses':rows}),
        read_manifest=lambda path:{},new_directory=directory,new_file=file,load_ciphertext=load,save_ciphertext=save,
        request_digest=lambda manifests,contract:'input-digest',manifest_digest=lambda row:'response-digest',
        write_manifest=lambda *args:events.append(('response-batch',)),canonical=lambda value:b'public-json',digest=lambda value:'batch-digest')
    return NS(events=events,fault=fault,handle=handle,paths=paths,env=env)

def test_default_branch_matches_original_handler_trace(rig):
    original=handler(rig.env,'baseline/file_stages.py');candidate=handler(rig.env)
    assert original(rig.paths)==dict(sample_count=1,public_batch_sha256='batch-digest')
    before=list(rig.events);rig.events.clear()
    assert candidate(rig.paths)==dict(sample_count=1,public_batch_sha256='batch-digest')
    assert rig.events==before

@pytest.mark.parametrize('mode',(False,True))
def test_exact_loader_handle_and_engine_order(rig,mode):
    assert handler(rig.env)(rig.paths,prepared_rotation_cache=mode)['sample_count']==1
    loader=rig.events[0];assert loader[:2]==('loader-open','prepared'if mode else'ordinary')
    assert loader[2]==dict(profile_bytes=b'profile',plan_bytes=b'plan',**({'dedicated_no_write':True}if mode else{}))
    engine=next(e for e in rig.events if e[0]=='engine-open')
    assert engine[1]==dict(manifest_bytes=b'candidate',**({'prepared_handle':rig.handle}if mode else{}))
    names=[e[0]for e in rig.events];assert names.index('engine-close')<names.index('download-close')<names.index('loader-close')

@pytest.mark.parametrize('bad',(0,1,None,'true',[],object()))
def test_non_boolean_mode_fails_before_any_path_or_parameter_access(rig,bad):
    def forbidden(*args,**kwargs):raise AssertionError('path/parameter access before mode gate')
    env=dict(rig.env,_paths=forbidden,_inputs=forbidden)
    with pytest.raises(ValueError,match='exact bool'):handler(env)(rig.paths,prepared_rotation_cache=bad)
    assert not rig.events

@pytest.mark.parametrize('site',('load','evaluate'))
@pytest.mark.parametrize('kind',(ValueError,KeyboardInterrupt,SystemExit))
def test_entered_failure_propagates_through_engine_before_loader(rig,site,kind):
    primary=kind('synthetic failure');rig.fault[site]=primary
    with pytest.raises(kind)as caught:handler(rig.env)(rig.paths,prepared_rotation_cache=True)
    assert caught.value is primary
    closed=[e for e in rig.events if e[0]in('engine-close','download-close','loader-close')]
    assert [e[0]for e in closed]==['engine-close','download-close','loader-close']
    assert closed[0][1]is primary and closed[1][1]is primary and closed[2][2]is primary
    assert not any(e[0]in('save','response-batch','report-open')for e in rig.events)
