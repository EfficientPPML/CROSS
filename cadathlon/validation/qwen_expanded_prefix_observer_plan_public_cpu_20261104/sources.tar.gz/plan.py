"""Public metadata derivation only. Never opens calibration/model/output bodies."""
from pathlib import Path
import argparse
import hashlib
import io
import json
import tarfile
from workload import workload, BASELINE_MANIFEST_SHA256

P = Path(__file__).resolve().parent


def digest(raw): return hashlib.sha256(raw).hexdigest()


def archive_map(raw, expected, count):
    if type(expected) is not dict or len(expected) != count:
        raise ValueError('Exact producer inventory required')
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        members=archive.getmembers()
        if (len(members)!=count or len({m.name for m in members})!=count or
            {m.name for m in members}!=set(expected) or
            any(not m.isfile() or Path(m.name).is_absolute() or '..' in Path(m.name).parts or
                not 0 <= m.size <= 8<<20 for m in members) or
            sum(m.size for m in members)>64<<20):
            raise ValueError('Bounded regular source-only producer archive required')
        actual={m.name:digest(archive.extractfile(m).read()) for m in members}
    if actual!=expected: raise ValueError('Producer archive bytes differ')
    return actual


def validate_receipts(tokenizer, worker, review):
    for record in (tokenizer,worker):
        for name in ('passed','complete','cleanup_completed','signal_restoration_completed',
                     'terminal_after_body_cleanup_and_signal_restoration_attempts',
                     'acceptance_requires_independent_exit0_reap_and_exact_report_hash'):
            if record.get(name) is not True: raise ValueError('Tokenizer terminal flag differs: '+name)
        for name in ('model_forward','coefficient_selection'):
            if record.get(name) is not False: raise ValueError('Tokenizer scope differs')
        if record.get('audit_denials') != []: raise ValueError('Tokenizer audit differs')
    if (tokenizer.get('child_reaped') is not True or tokenizer.get('child_group_absent') is not True
        or type(tokenizer.get('child_returncode')) is not int or tokenizer['child_returncode']!=0):
        raise ValueError('Tokenizer direct-child retirement differs')
    if tokenizer.get('worker') != worker: raise ValueError('Tokenizer worker linkage differs')
    if (review.get('passed') is not True or type(review.get('sources')) is not int or review['sources'] != 33 or
        review.get('source_current_execution_start_end_archive_equal') is not True or
        review.get('original288_mapping_and16_seeds_exact') is not True or
        review.get('private_directory0700_files0600') is not True):
        raise ValueError('Independent tokenizer review differs')
    outer=review.get('outer',{})
    for name in ('outer_completed','collector_absent','child_reaped','child_group_absent'):
        if outer.get(name) is not True: raise ValueError('Authoritative outer retirement absent')
    if any(type(outer.get(n)) is not int or outer[n]!=0 for n in ('outer_returncode','child_returncode')):
        raise ValueError('Authoritative outer exit differs')


def build(root=P):
    root=Path(root)
    pins=json.loads((root/'producer_pins.json').read_bytes())
    origins=json.loads((root/'source_origins.json').read_bytes())
    blobs={}
    for name,expected in pins.items():
        if not name.startswith('references/') or Path(name).is_absolute() or '..' in Path(name).parts:
            raise ValueError('Fixed local public reference required')
        raw=(root/name).read_bytes()
        if digest(raw)!=expected or origins[name]['sha256']!=expected:
            raise ValueError('Public reference digest differs: '+name)
        blobs[name.removeprefix('references/')]=raw
    doc=lambda name:json.loads(blobs[name])
    protocol=doc('protocol_plan.json');parent=doc('protocol_report.json')
    if (parent.get('passed') is not True or parent.get('complete') is not True or
        parent['source_hashes_before']!=parent['source_hashes_after'] or
        parent.get('source_archive_sha256')!=digest(blobs['protocol_sources.tar.gz'])):
        raise ValueError('Frozen23 protocol source proof differs')
    archive_map(blobs['protocol_sources.tar.gz'],parent['source_hashes_before'],23)
    tokenizer,worker,review=(doc(n) for n in ('tokenizer_report.json','tokenizer_worker_report.json','tokenizer_root_review.json'))
    validate_receipts(tokenizer,worker,review)
    report_hash=digest(blobs['tokenizer_report.json']);archive_hash=digest(blobs['tokenizer_sources.tar.gz'])
    if (tokenizer['worker_report_sha256']!=digest(blobs['tokenizer_worker_report.json']) or
        review['report_sha256']!=report_hash or review['outer']['report_sha256']!=report_hash or
        review['source_archive_sha256']!=archive_hash or review['outer']['source_archive_sha256']!=archive_hash or
        tokenizer['source_archive']['sha256']!=archive_hash or
        tokenizer['source_hashes_start']!=tokenizer['source_hashes_end'] or
        worker['source_hashes_start']!=tokenizer['source_hashes_start'] or
        worker['source_hashes_end']!=tokenizer['source_hashes_start']):
        raise ValueError('Tokenizer report/archive linkage differs')
    archive_map(blobs['tokenizer_sources.tar.gz'],tokenizer['source_hashes_start'],33)
    if (digest(blobs['candidate3_manifest.json'])!=BASELINE_MANIFEST_SHA256 or
        protocol['old_candidate_manifest_sha256']!=BASELINE_MANIFEST_SHA256 or
        worker['protocol_sha256']!=digest(blobs['protocol_plan.json']) or
        worker['private_outputs']!=review['private_outputs'] or
        worker['grant_sha256']!=digest(blobs['tokenizer_grant.json']) or
        review['grant_sha256']!=digest(blobs['tokenizer_grant.json'])):
        raise ValueError('Fixed protocol/baseline/input producer linkage differs')
    grant=doc('tokenizer_grant.json')
    rows=workload()
    return dict(schema='qwen-expanded-prefix-observer-plan-v1',passed=True,
        scope='Public source/producer metadata and pure synthetic dispatcher only',
        execution_authorized=False,calibration_or_validation_bodies_read=False,
        model_or_tokenizer_executed=False,coefficient_selection_performed=False,
        protocol_sha256=digest(blobs['protocol_plan.json']),
        tokenizer_report_sha256=report_hash,tokenizer_archive_sha256=archive_hash,
        tokenizer_root_review_sha256=digest(blobs['tokenizer_root_review.json']),
        private_calibration_descriptor=dict(path=grant['private_output']+'/calibration_inputs.json',
            parent_identity=review['private_root_identity'],**worker['private_outputs']['calibration']),
        initial_generator=dict(manifest_sha256=BASELINE_MANIFEST_SHA256,
            role='frozen candidate3 actual approximate free-prefix generator',
            new_candidate_budget_consumed=0,maximum_forward_contexts=64,
            baseline_ranges_used_for_initial_domain_selection=False,
            failed_generator_suffix='unmeasured; initial selection refused'),
        workload=dict(entries=len(rows),prefills=3072,teacher=64,free=64,
            original416_members=sum(e.original416_member for e in rows),
            index_formulas=dict(prefill='32*prompt+length-1',teacher='3072+4*seed+step',free='3136+4*seed+step'),
            deduplicated=False,teacher_choice='native argmax',free_choice='pinned candidate3 argmax',
            lengths=list(range(1,33)),decode_lengths=[16,17,18,19]),
        selection=protocol['selection'],acceptance=protocol['acceptance']['calibration'],
        gates=protocol['acceptance']['unchanged_numeric_gates'],
        initial_selection_requires_complete_native_exact3200=True,
        native_exact_and_baseline_ranges_must_remain_separate=True,
        K1='explicit public bypass; no reciprocal domain observation',
        protected_internal_domains='only actual approximate propagation measures original reciprocal/tanh inputs',
        private_outputs='token contexts, generated choices and raw logits remain outside public evidence',
        referenced_source_sha256={n:r['sha256'] for n,r in origins.items() if n.endswith('.py.txt')})


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();report=build()
    with args.output.open('x') as stream:json.dump(report,stream,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps(dict(passed=True,entries=3200,execution_authorized=False)))


if __name__=='__main__': main()
