import json
from pathlib import Path
import sys
import pytest
import collect


def make_source(tmp_path):
    root=tmp_path/'source';root.mkdir()
    (root/'inventory.json').write_text(json.dumps({'sources':['one.py','inventory.json']}))
    (root/'one.py').write_text('one = 1\n')
    return root


def test_source_inventory_excludes_nested_output(tmp_path,monkeypatch):
    root=make_source(tmp_path);monkeypatch.setattr(collect,'P',root)
    before=collect.source_hashes()
    output=root/'attempt';output.mkdir();(output/'unexpected.py').write_text('different')
    assert collect.source_hashes()==before


def test_late_source_drift_does_not_match_snapshot(tmp_path,monkeypatch):
    root=make_source(tmp_path);monkeypatch.setattr(collect,'P',root)
    output=tmp_path/'out';output.mkdir();before=collect.source_hashes()
    collect.archive(output,before);collect.verify_archive(output,before)
    (root/'one.py').write_text('one = 2\n')
    assert collect.source_hashes()!=before
    with pytest.raises(ValueError,match='source changed'):collect.archive(output,before)


def test_existing_output_report_never_republished(tmp_path,monkeypatch):
    output=tmp_path/'out';output.mkdir();report=output/'report.json';report.write_bytes(b'foreign original')
    monkeypatch.setattr(sys,'argv',['collect.py','--output',str(output)])
    monkeypatch.setattr(collect,'finish',lambda *a,**k:pytest.fail('finish before fresh output ownership'))
    with pytest.raises(FileExistsError):collect.main()
    assert report.read_bytes()==b'foreign original'


def test_snapshot_current_archive_and_execution_agree(tmp_path,monkeypatch):
    root=make_source(tmp_path);monkeypatch.setattr(collect,'P',root)
    out=tmp_path/'out';out.mkdir();before=collect.source_hashes()
    collect.archive(out,before);collect.verify_archive(out,before)
    execution=collect.execution_tree(out,before)
    assert collect.source_hashes(execution)==before
