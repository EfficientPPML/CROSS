import copy
import hashlib
import io
import json
from pathlib import Path
import tarfile
import pytest
import plan


def test_public_plan_and_producer_links():
    value=plan.build()
    assert value['passed'] and value['execution_authorized'] is False
    assert value['calibration_or_validation_bodies_read'] is False
    assert value['model_or_tokenizer_executed'] is False
    assert value['workload']['entries']==3200
    assert value['initial_generator']['maximum_forward_contexts']==64
    assert value['initial_generator']['new_candidate_budget_consumed']==0
    assert value['selection']['maximum_candidates']==3
    assert value['acceptance']==dict(prefill_required_matches=2765,prefill_total=3072,
        teacher_required_matches=58,teacher_total=64,complete_free_required=12,
        complete_free_total=16,complete_contexts=3200)
    assert value['private_calibration_descriptor']['sha256']=='80eeaefad423167ee0710797d7eb76d8cf3a422e6f3b2e6069932d682835963b'
    assert value['native_exact_and_baseline_ranges_must_remain_separate'] is True


@pytest.mark.parametrize('part,field,value',[
    ('parent','passed',1),('parent','child_reaped',False),
    ('parent','child_returncode',False),('worker','model_forward',True),
    ('worker','coefficient_selection',True),('worker','complete',False),
    ('review','original288_mapping_and16_seeds_exact',False),
    ('outer','outer_returncode',False),('outer','collector_absent',False),
    ('outer','child_group_absent',False)])
def test_incomplete_producer_receipts_reject(part,field,value):
    load=lambda n:json.loads((Path(__file__).parent/'references'/n).read_bytes())
    parent,worker,review=map(load,('tokenizer_report.json','tokenizer_worker_report.json','tokenizer_root_review.json'))
    target={'parent':parent,'worker':worker,'review':review,'outer':review['outer']}[part]
    target[field]=value
    with pytest.raises(ValueError):plan.validate_receipts(parent,worker,review)


def test_bounded_archive_duplicate_missing_symlink_and_mismatch():
    def archive(names,symlink=False):
        data=io.BytesIO()
        with tarfile.open(fileobj=data,mode='w:gz') as t:
            for n in names:
                m=tarfile.TarInfo(n);m.size=1
                if symlink:m.type=tarfile.SYMTYPE;m.linkname='outside';m.size=0
                t.addfile(m,None if symlink else io.BytesIO(b'x'))
        return data.getvalue()
    expected={'one.py':hashlib.sha256(b'x').hexdigest()}
    assert plan.archive_map(archive(['one.py']),expected,1)==expected
    for raw in (archive(['one.py','one.py']),archive([]),archive(['one.py'],True),archive(['../one.py'])):
        with pytest.raises(ValueError):plan.archive_map(raw,expected,1)
    with pytest.raises(ValueError):plan.archive_map(archive(['one.py']),{'one.py':'0'*64},1)


def test_reference_copies_are_exact_and_no_input_payloads_are_archived():
    root=Path(__file__).parent
    origins=json.loads((root/'source_origins.json').read_bytes())
    pins=json.loads((root/'producer_pins.json').read_bytes())
    assert all(name.startswith('references/') for name in pins)
    for name,digest in pins.items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest==origins[name]['sha256']
        assert Path(name).suffix not in ('.npy','.npz','.safetensors','.parquet')
        assert Path(name).name not in ('calibration_inputs.json','validation_inputs.json','corpus.json')
