import sys
sys.path[:0]=['/tmp/rotation-binding-hit-lab','/home/jianming_gatech/CROSS/cadathlon/common','/home/jianming_gatech/CROSS']
import encrypted_rotation
assert encrypted_rotation.__file__.startswith('/tmp/rotation-binding-hit-lab')
import pytest
raise SystemExit(pytest.main(['-q','/tmp/rotation-binding-hit-lab/test_encrypted_rotation.py']))
