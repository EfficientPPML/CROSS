from pathlib import Path
import shutil,difflib
ROOT=Path('/home/jianming_gatech/CROSS');LAB=Path('/tmp/uniform-scalar-integration');LAB.mkdir(exist_ok=True)
shutil.copytree(ROOT/'jaxite_word',LAB/'jaxite_word',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
source=(ROOT/'jaxite_word/ckks_ctx.py').read_text()
candidate=Path('/tmp/refresh-scalar-lab-v2/uniform_scalar_codec.py').read_text()
helper=candidate[candidate.index('DEFAULT_BOUND ='):candidate.index('\n\ndef encode_array(')]
helper=helper.replace('DEFAULT_BOUND','_UNIFORM_ENCODE_BOUND').replace('_supported_roots','_uniform_encode_roots').replace('try_uniform_array','_try_uniform_real_encode')
helper=helper.replace('max_bits_value=_UNIFORM_ENCODE_BOUND):','max_bits_value=_UNIFORM_ENCODE_BOUND, *, expected_slot_count=None):')
helper=helper.replace("or values.size < 1 or values.size & (values.size-1)", "or (expected_slot_count is not None and values.size != expected_slot_count)\n                or values.size < 1 or values.size & (values.size-1)")
helper=helper.replace('ckks_ctx.util.', 'util.').replace('ckks_ctx._get_or_make_encode_ctx', '_get_or_make_encode_ctx').replace('ckks_ctx.nearest_int','nearest_int')
# Match the surrounding core's two-space indentation without changing logic.
helper='\n'.join(line[:len(line)-len(line.lstrip())].replace('    ','  ')+line.lstrip() for line in helper.splitlines())+'\n\n\n'
source=source.replace('def _ckks_encode_array(',helper+'def _ckks_encode_array(',1)
old='''  arr = _fast_encode(
      slots,
      lite,
      scale=scale,
      noise_scale_degree=noise_scale_degree,
      allow_complex=True,
      # Bootstrap's sparse transforms encode a periodic slot pattern in the
      # same full ring. Keep the cached encode context immutable: public
      # context codecs still require exactly their declared slot count.
      slot_count=len(slots),
  )  # (N, M) uint64
'''
new='''  arr = _try_uniform_real_encode(
      slots, cycl_order, q_towers, p_towers, scale, noise_scale_degree,
      max_bits_in_word, max_bits_value,
  )
  if arr is None:
    arr = _fast_encode(
        slots,
        lite,
        scale=scale,
        noise_scale_degree=noise_scale_degree,
        allow_complex=True,
        # Bootstrap's sparse transforms encode a periodic slot pattern in the
        # same full ring. Public codecs retain their own exact slot count.
        slot_count=len(slots),
    )  # (N, M) uint64
'''
assert source.count(old)==1;source=source.replace(old,new)
old='    encoded_rns = _fast_encode(slots, encode_ctx, scale=actual_scale)'
new='''    encoded_rns = _try_uniform_real_encode(
        slots, 2 * encode_ctx.degree, encode_ctx.q_towers, [], actual_scale,
        max_bits_in_word=encode_ctx.parameters['max_bits_in_word'],
        max_bits_value=encode_ctx.parameters['max_bits_value'],
        expected_slot_count=encode_ctx.num_slots,
    )
    if encoded_rns is None:
      encoded_rns = _fast_encode(slots, encode_ctx, scale=actual_scale)'''
assert source.count(old)==1;source=source.replace(old,new)
(LAB/'jaxite_word/ckks_ctx.py').write_text(source)
patch=''.join(difflib.unified_diff((ROOT/'jaxite_word/ckks_ctx.py').read_text().splitlines(keepends=True),source.splitlines(keepends=True),fromfile='a/jaxite_word/ckks_ctx.py',tofile='b/jaxite_word/ckks_ctx.py'))
(LAB/'integration.patch').write_text(patch)
print('Prepared isolated core candidate only:',LAB)
