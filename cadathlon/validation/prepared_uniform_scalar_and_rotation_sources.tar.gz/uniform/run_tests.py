import sys
sys.path[:0]=['/tmp/uniform-scalar-integration','/home/jianming_gatech/CROSS']
from jaxite_word import ckks_ctx
assert ckks_ctx.__file__.startswith('/tmp/uniform-scalar-integration')
import pytest
raise SystemExit(pytest.main(['-q','/tmp/uniform-scalar-integration/test_uniform_encoding.py','/tmp/uniform-scalar-integration/jaxite_word/codec_preparation_test.py']))
