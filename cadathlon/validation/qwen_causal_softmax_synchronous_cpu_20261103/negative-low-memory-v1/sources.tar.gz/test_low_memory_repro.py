import pytest
from test_causal_softmax_guards import RAW,CERT,CONFIG,pv_setup
from ideal_primitives import Arithmetic
from ideal_refresh import IdentityRefresh
from encrypted_qwen_causal_softmax import QwenCausalSoftmax,QwenCausalSoftmaxContract
@pytest.mark.parametrize("target",["arithmetic","refresh_evaluator","refresh_engine","PV"])
def test_reject_asynchronous_before_work(target):
    a=Arithmetic();r=IdentityRefresh(a)
    a.low_memory=True;r.evaluator.low_memory=True;r.engine._low_mem=True
    if target in ("arithmetic","PV"):a.low_memory=False
    elif target=="refresh_evaluator":r.evaluator.low_memory=False
    else:r.engine._low_mem=False
    with pytest.raises(ValueError):
        if target=="PV":pv_setup(a,(0,2))
        else:QwenCausalSoftmax(a,QwenCausalSoftmaxContract(RAW,CERT,3),CONFIG,positions=(0,2),refresher=r)
