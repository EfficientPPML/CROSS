from pathlib import Path
import hashlib,io,json,subprocess,sys,tarfile
p=Path(__file__).parent
files=sorted([x for x in p.rglob("*") if x.is_file() and x.suffix in (".py",".json") and x.name!="report.json"])
def hashes():return {str(x.relative_to(p)):hashlib.sha256(x.read_bytes()).hexdigest() for x in files}
before=hashes()
with tarfile.open(p/"sources.tar.gz","w:gz") as t:
 for x in files:
  b=x.read_bytes();i=tarfile.TarInfo(str(x.relative_to(p)));i.size=len(b);t.addfile(i,io.BytesIO(b))
with (p/"tests.log").open("w") as log:r=subprocess.run([sys.executable,"-m","pytest","test_low_memory_repro.py","-q","--junitxml=tests.xml"],cwd=p,stdout=log,stderr=subprocess.STDOUT)
after=hashes()
with tarfile.open(p/"sources.tar.gz") as t:assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers()}==before
report=dict(scope="Expected old-owner rejection failures only; no backend/model/HE",expected_negative_reproduction_passed=r.returncode==1 and before==after,pytest_exit_code=r.returncode,source_hashes_before=before,source_hashes_after=after,archive_sha256=hashlib.sha256((p/"sources.tar.gz").read_bytes()).hexdigest())
(p/"report.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(dict(expected_negative_reproduction_passed=report["expected_negative_reproduction_passed"],sources=len(before),archive=report["archive_sha256"])))
raise SystemExit(0 if report["expected_negative_reproduction_passed"] else 1)
