"""Reproduce metadata gaps in the immutable measured baseline with ideal fakes."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
from types import SimpleNamespace
import numpy as np
from test_routing import Arithmetic, Value, SLOTS

HERE = Path(__file__).resolve().parent
BASELINE = HERE / 'baseline/encrypted_shallow_score_routing.py'
assert hashlib.sha256(BASELINE.read_bytes()).hexdigest() == '0ce87c1c580e27bf793fc1d23eca63b64f6f14de63e36e1feea77d0481d83e2c'
sys.modules['jaxite_word'] = SimpleNamespace(Polynomial=Value)
sys.modules['support'] = SimpleNamespace(require_secure_execution=lambda *args: None)
sys.modules['encrypted_packed_qwen'] = SimpleNamespace(CompiledArithmetic=Arithmetic)
spec = importlib.util.spec_from_file_location('original_routing', BASELINE)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)

source = Value(np.ones(SLOTS))
source._ckks_nsd = True
module.ShallowScoreRouting(Arithmetic(), module.ShallowScoreLayout(0, 0)).forward(source)
report = {'baseline_sha256': hashlib.sha256(BASELINE.read_bytes()).hexdigest(),
          'baseline_accepts_boolean_input_nsd': True,
          'scope': 'Ideal backend reproduction; no encryption or secure-execution claim.'}

source = Value(np.ones(SLOTS))
events = []
def mutate(label, value, counts):
    source._ckks_nsd = True
    value._ckks_nsd = True
    events.append(label)
result = module.ShallowScoreRouting(Arithmetic(), module.ShallowScoreLayout(0, 0), progress=mutate).forward(source)
report.update(baseline_continues_after_input_callback_mutation=len(events) == 2,
              baseline_returns_boolean_output_nsd=type(result._ckks_nsd) is bool)
assert all(report[name] for name in report if name.startswith('baseline_') and name != 'baseline_sha256')
(HERE / 'baseline_reproduction.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
