"""Freeze public routing tests and key plans; no encrypted evaluation."""
from pathlib import Path
import argparse
import hashlib
import io
import json
import os
import subprocess
import sys
import tarfile
import time

HERE = Path(__file__).resolve().parent


def sources():
    paths = sorted(set(HERE.rglob('*.py')) | {HERE / n for n in ('source_origin.json', 'p60_profile_and_refresh.json')})
    return {str(p.relative_to(HERE)): p.read_bytes() for p in paths}


def sha(value):
    return hashlib.sha256(value).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(exist_ok=False)
    start = time.monotonic()
    raw = sources()
    before = {name: sha(value) for name, value in raw.items()}
    with tarfile.open(args.output / 'sources.tar.gz', 'w:gz') as archive:
        for name, value in raw.items():
            info = tarfile.TarInfo(name)
            info.size = len(value)
            archive.addfile(info, io.BytesIO(value))
    environment = dict(os.environ, PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
    with (args.output / 'plan.log').open('w') as output:
        plan = subprocess.run([sys.executable, 'public_plan.py'], cwd=HERE,
                              env=environment, stdout=output, stderr=subprocess.STDOUT)
    with (args.output / 'tests.log').open('w') as output:
        tests = subprocess.run([sys.executable, '-m', 'pytest', '-q', 'test_routing.py', 'test_hardening.py', 'test_factored.py'],
                               cwd=HERE, env=environment, stdout=output, stderr=subprocess.STDOUT)
    with tarfile.open(args.output / 'sources.tar.gz') as archive:
        members = archive.getmembers()
        assert len(members) == len({m.name for m in members}) == len(before)
        assert all(m.isfile() for m in members)
        archived = {m.name: sha(archive.extractfile(m).read()) for m in members}
    after = {name: sha(value) for name, value in sources().items()}
    report = dict(passed=plan.returncode == tests.returncode == 0 and before == after == archived,
                  scope=__doc__, plan_exit_code=plan.returncode, tests_exit_code=tests.returncode,
                  source_hashes_before=before, source_hashes_after=after,
                  source_archive_verified=archived == before, source_files_unchanged=before == after,
                  source_archive_sha256=sha((args.output / 'sources.tar.gz').read_bytes()),
                  public_plan_sha256=sha((HERE / 'public_plan.json').read_bytes()),
                  elapsed_s=time.monotonic() - start)
    (args.output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({key: value for key, value in report.items() if not isinstance(value, dict)}))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
