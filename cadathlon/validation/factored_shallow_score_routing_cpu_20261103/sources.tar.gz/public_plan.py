"""Actual-profile public key inventory; no context, keys, backend or HE."""
from pathlib import Path
import hashlib
import json
import math
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'checkout/cadathlon/common'))
from encrypted_shallow_score_routing import ShallowScoreLayout
from encrypted_factored_score_routing import FactoredScoreLayout


def main():
    profile_bytes = (HERE / 'p60_profile_and_refresh.json').read_bytes()
    assert hashlib.sha256(profile_bytes).hexdigest() == 'fe2408637f9d6de19ac6aef9f6f749aaef9dd56ccbb37b5334293cd223ede035'
    source = json.loads(profile_bytes)
    profile = source['profile']
    assert (profile['degree'], profile['depth'], profile['scale_bits'], profile['dnum']) == (131072, 49, 60, 8)
    q, p = profile['q'], profile['p']
    degree, dnum = 131072, 8
    assert len(q) == 100 and len(p) == 14
    assert math.prod(q+p).bit_length() <= 3523
    alpha = math.ceil(len(q)/dnum)
    parts = math.ceil(len(q)/alpha)
    assert all(math.prod(q[i:i+alpha]) <= math.prod(p) for i in range(0, len(q), alpha))
    pair_bytes = 2*parts*(len(q)+len(p))*degree*4
    direct = set()
    factored = set()
    maps = []
    for tile in range(8):
        for offset in range(16):
            before = set(ShallowScoreLayout(tile, offset).rotation_indices())
            after = set(FactoredScoreLayout(tile, offset).rotation_indices())
            direct.update(before)
            factored.update(after)
            maps.append(dict(tile=tile, offset=offset, direct_key_count=len(before),
                             factored_key_count=len(after), forward_levels=2, inverse_levels=2,
                             total_rotation_calls=54 if tile else 52,
                             total_weighted_terms=56, total_composite_rescales=4))
    assert len(direct) == 276 and len(factored) == 66
    head_ops = {sign*(1 << bit) % 65536 for bit in range(6) for sign in (-1, 1)}
    row_alignment = {4096*k for k in range(1, 16)}
    refresh = set(source['refresh_plan']['rotations'])
    assert len(refresh) == 106
    graph_only = factored | head_ops | row_alignment
    graph_and_refresh = graph_only | refresh
    groups = {'direct_routing_only': direct, 'factored_routing_only': factored,
              'prospective_qk_and_pv_routing': graph_only,
              'prospective_qk_and_pv_routing_plus_refresh': graph_and_refresh}
    report = dict(passed=True, scope=__doc__, actual_profile_source_sha256=hashlib.sha256(profile_bytes).hexdigest(),
                  profile=dict(degree=degree, dnum=dnum, q=q, p=p, actual_partitions=parts,
                               actual_log2_QP=sum(map(math.log2, q+p)), raw_rotation_pair_bytes=pair_bytes),
                  key_groups={name: dict(count=len(keys), keys=sorted(keys), raw_rotation_bytes=len(keys)*pair_bytes,
                                         raw_rotation_GiB=len(keys)*pair_bytes/2**30) for name, keys in groups.items()},
                  mappings=maps, noncanonical_input_alignment='The first real weighted_sum aligns input scale while performing its mask; each weighted output remains canonical. No added level or metadata relabel.',
                  limitations=['No cryptographic numerical proof for this factorization or full attention accumulation.',
                               'Prospective QK/PV unions include head sums/broadcasts and row alignment, not dense projections, LayerNorm or the full transformer.',
                               'Raw key bytes exclude headers, context tables, ciphertexts, compiler buffers, transient copies and peak host/device memory.',
                               'Measured source from prior routing proofs is preserved separately; its errors do not transfer automatically.',
                               'Exact actual security/P coverage is inherited from the pinned public profile and rechecked arithmetically; no new core backend call.'])
    assert 'jax' not in sys.modules
    (HERE / 'public_plan.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({name: {k: v for k, v in row.items() if k != 'keys'} for name, row in report['key_groups'].items()}))


if __name__ == '__main__':
    main()
