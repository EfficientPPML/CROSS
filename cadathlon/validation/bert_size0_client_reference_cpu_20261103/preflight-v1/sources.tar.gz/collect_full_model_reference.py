"""Source-bound independent full12 NumPy reference, native gates before approximation."""
from pathlib import Path
import argparse,hashlib,importlib.metadata,importlib.util,io,json,os,signal,subprocess,sys,tarfile,time
import numpy as np
from full_model_reference import compute,tensor_shapes
HERE=Path(__file__).resolve().parent
MODEL=Path('/home/jianming_gatech/cross_validation_assets/bert/f150c1d609d1e50dd5e2e5408661cfac8339277c/model.safetensors')
MODEL_SHA='e1f8085ef673c9eb8a1a93a84270742e8aa0ccbceadef01eef15e26c44b46034'
NATIVE_SHA='758ff5d71fa3c836f74a974dee97c4a744e17ea283047e2abe15b4675edc202a'
ATTENTION=Path('/tmp/bert-all-ffn-tile-owner-20261103/client_all_ffn_fixtures.npz')
ATTENTION_SHA='283d23fb4cc5ba89bf73e85380154389060952bc0174bb6fcedd50ae45f3be7a'
PLAN=Path('/tmp/bert-twelve-layer-continuation-plan-20261103')
PINS=Path('/tmp/bert-full-model-file-stages-20261103/server_tensor_pins.json')
PUBLIC_SHA={'candidate_manifest.json':'4e2277beea7189aa1d77b168c500c8a175f6c630afa520fcc6b38cb5a179cff9',
 'frozen_approximate.py':'81fdb3b4539a91c65adec107643a36f048fb4822327dd55c86f9055be28e95c5',
 'server_tensor_pins.json':'719d09712c2b26e80bfc36897a81dcd423cfa9ef64cb6423899ff80a0f72f575'}

def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');tmp.replace(path)
def sources():
    data={n:(HERE/n).read_bytes() for n in ('full_model_reference.py','test_full_model_reference.py','collect_full_model_reference.py')}
    data.update({n:(PINS if n=='server_tensor_pins.json' else PLAN/n).read_bytes() for n in PUBLIC_SHA})
    data['native_reference_report.json']=(HERE/'native-source-bound-v1/report.json').read_bytes()
    return data
def hashes(data):return {k:hashlib.sha256(v).hexdigest() for k,v in data.items()}
def archive(path,data):
    with tarfile.open(path,'w:gz') as t:
        for n,b in data.items():m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
def verify_archive(path,before):
    with tarfile.open(path) as t:
        rows=t.getmembers()
        return len(rows)==len(before)==len({m.name for m in rows}) and all(m.isfile() for m in rows) and {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in rows}==before

def load_weights(pins):
    if pins['checkpoint_sha256']!=MODEL_SHA or set(pins['tensors'])!=set(tensor_shapes()):raise ValueError('exact196 public tensor pin inventory required')
    arrays={}
    with MODEL.open('rb') as f:
        size=int.from_bytes(f.read(8),'little');header=json.loads(f.read(size));start=size+8
        for name,shape in tensor_shapes().items():
            entry=header[name];a,b=entry['data_offsets']
            if entry['dtype']!='F32' or entry['shape']!=list(shape) or b-a!=4*np.prod(shape):raise ValueError('public tensor storage differs')
            f.seek(start+a);raw=f.read(b-a)
            if hashlib.sha256(raw).hexdigest()!=pins['tensors'][name]:raise ValueError('public tensor bytes differ')
            arrays[name]=np.frombuffer(raw,dtype='<f4').astype(np.float64).reshape(shape)
    return arrays

def max_error(a,b,gate=None):
    a,b=np.asarray(a),np.asarray(b)
    if a.shape!=b.shape or a.dtype!=np.float64 or b.dtype!=np.float64 or not np.isfinite(a).all() or not np.isfinite(b).all():raise ValueError('finite matching float64 outputs required')
    with np.errstate(over='ignore',invalid='ignore'):error=float(np.max(np.abs(a-b)))
    if not np.isfinite(error) or (gate is not None and error>gate):raise ValueError('fixed reference comparison gate failed: '+str(error))
    return error

def stop(child):
    if child is None:return
    if child.poll() is None:
        os.killpg(child.pid,signal.SIGTERM)
        try:child.wait(timeout=30)
        except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    else:child.wait()

def run(output):
    output.mkdir(exist_ok=False);start=time.monotonic();primary=None;cancel=None;child=None;before={};asset_before={};cleanup=[]
    asset_paths={'checkpoint':MODEL,'native_reference':HERE/'client_native_full.npz','native_attention_reference':ATTENTION}
    report=dict(passed=False,scope='Independent complete12-layer NumPy reference; no encrypted execution, no native later-state substitution.',
        cpu_affinity=sorted(os.sched_getaffinity(0)),cases=[],native_exact_gate=1e-12,independent_vs_frozen_logit_gate=1e-7,
        approximate_logit_gate='abs(error) <=0.02+0.01*abs(native)',labels_loaded=False,raw_arrays_archived=False)
    def attempt(label,fn):
        nonlocal cancel
        try:return fn()
        except BaseException as e:
            cleanup.append(dict(operation=label,type=type(e).__name__,message=str(e)))
            if primary is not None:primary.add_note(label+': '+repr(e))
            elif not isinstance(e,Exception) and cancel is None:cancel=e
            return None
    try:
        write(output/'report.json',report);raw=sources();before=hashes(raw);archive(output/'sources.tar.gz',raw)
        if not verify_archive(output/'sources.tar.gz',before):raise ValueError('startup archive readback differs')
        if {n:before[n] for n in PUBLIC_SHA}!=PUBLIC_SHA:raise ValueError('frozen public inputs differ')
        native_report=json.loads(raw['native_reference_report.json'])
        if not native_report['passed'] or not native_report['source_files_unchanged'] or native_report['fixture_npz_sha256']!=NATIVE_SHA:raise ValueError('native prerequisite differs')
        asset_before={n:sha(p) for n,p in asset_paths.items()}
        if asset_before!={'checkpoint':MODEL_SHA,'native_reference':NATIVE_SHA,'native_attention_reference':ATTENTION_SHA}:raise ValueError('public/private reference asset bytes differ')
        report.update(source_hashes_before=before,source_archive_sha256=sha(output/'sources.tar.gz'),asset_hashes_before=asset_before,
            versions={n:importlib.metadata.version(n) for n in ('numpy','scipy','pytest')},environment={n:os.environ.get(n) for n in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')})
        command=[sys.executable,'-m','pytest','-q',str(HERE/'test_full_model_reference.py'),'--junitxml='+str(output/'tests.xml')]
        with (output/'tests.log').open('wb') as log:
            child=subprocess.Popen(command,cwd=HERE,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            if child.wait()!=0:raise ValueError('independent reference tests failed')
        import xml.etree.ElementTree as ET
        report['tests']={n:sum(int(s.attrib.get(n,0)) for s in ET.parse(output/'tests.xml').getroot()) for n in ('tests','errors','failures','skipped')}
        if any(report['tests'][n] for n in ('errors','failures','skipped')):raise ValueError('incomplete focused tests')
        weights=load_weights(json.loads(raw['server_tensor_pins.json']))
        spec=importlib.util.spec_from_file_location('unchanged_frozen_reference',PLAN/'frozen_approximate.py');frozen=importlib.util.module_from_spec(spec);spec.loader.exec_module(frozen)
        config=dict(num_attention_heads=12,num_hidden_layers=12,layer_norm_eps=1e-12)
        saved={};phase_start=time.monotonic()
        with np.load(asset_paths['native_reference'],allow_pickle=False) as native,np.load(ATTENTION,allow_pickle=False) as native_attention:
            for K in (15,128):
                initial=native[f'K{K}_embeddings'][:K].copy();initial_bytes=initial.tobytes()
                exact=compute(initial,weights,raw['candidate_manifest.json'],approximate=False)
                comparisons=[]
                for layer in range(12):
                    comparisons.append(dict(layer=layer,
                        attention_max_abs=max_error(exact['attention_outputs'][layer],native_attention[f'layer{layer}_K{K}_native'],1e-12),
                        block_max_abs=max_error(exact['block_outputs'][layer],native[f'layer{layer}_K{K}_native'],1e-12)))
                pooler_error=max_error(exact['pooler'],native[f'K{K}_pooler_native'],1e-12)
                logit_error=max_error(exact['logits'],native[f'K{K}_logits_native'],1e-12)
                row=dict(K=K,exact_native_layers=comparisons,exact_native_pooler_max_abs=pooler_error,exact_native_logit_max_abs=logit_error,approximate_complete=False)
                report['cases'].append(row);write(output/'report.json',report)
                approx=compute(initial,weights,raw['candidate_manifest.json'],approximate=True)
                original=frozen.Arithmetic(json.loads(raw['candidate_manifest.json'])).forward(config,weights,initial)
                frozen_error=max_error(approx['logits'],original,1e-7)
                native_logits=native[f'K{K}_logits_native'];errors=np.abs(approx['logits']-native_logits)
                if not np.all(errors<=.02+.01*np.abs(native_logits)):raise ValueError('original P2 logit tolerance failed')
                if initial.tobytes()!=initial_bytes:raise ValueError('original embedding input mutated')
                row.update(approximate_complete=True,domain_observations=approx['domain_observations'],
                    independent_vs_frozen_logit_max_abs=frozen_error,approximate_native_logit_max_abs=float(errors.max()),
                    original_P2_logit_gate_passed=True,prediction_agreement_diagnostic=bool((approx['logits'][1]>=approx['logits'][0])==(native_logits[1]>=native_logits[0])),
                    approximate_native_layer_max_abs=[dict(layer=i,attention=max_error(approx['attention_outputs'][i],native_attention[f'layer{i}_K{K}_native']),block=max_error(approx['block_outputs'][i],native[f'layer{i}_K{K}_native'])) for i in range(12)])
                for layer in range(12):
                    saved[f'layer{layer}_K{K}_attention']=approx['attention_outputs'][layer]
                    saved[f'layer{layer}_K{K}_block']=approx['block_outputs'][layer]
                saved[f'K{K}_pooler']=approx['pooler'];saved[f'K{K}_logits']=approx['logits']
                write(output/'report.json',report)
        report['computation_elapsed_s']=time.monotonic()-phase_start
        path=HERE/'client_full_model_reference.npz'
        with path.open('xb') as f:np.savez(f,**saved)
        report.update(passed=True,reference_npz_sha256=sha(path),reference_arrays={n:dict(shape=list(a.shape),dtype=a.dtype.str,sha256=hashlib.sha256(a.tobytes()).hexdigest()) for n,a in saved.items()})
    except BaseException as e:
        primary=e;report.update(passed=False,error=dict(type=type(e).__name__,message=str(e)))
        if hasattr(e,'observation'):report['domain_failure']=e.observation
    finally:
        attempt('reap focused tests',lambda:stop(child))
        after=attempt('source readback',lambda:hashes(sources()));assets_after=attempt('asset readback',lambda:{n:sha(p) for n,p in asset_paths.items()})
        verified=attempt('archive readback',lambda:verify_archive(output/'sources.tar.gz',before)) if before else False
        report.update(source_hashes_after=after,asset_hashes_after=assets_after,source_files_unchanged=bool(before) and before==after,
            asset_files_unchanged=bool(asset_before) and asset_before==assets_after,source_archive_verified=verified is True,
            cleanup_errors=cleanup,elapsed_s=time.monotonic()-start,test_child_reaped=child is None or child.poll() is not None)
        report['passed']=bool(report.get('passed') and report['source_files_unchanged'] and report['asset_files_unchanged'] and verified and not cleanup)
        try:write(output/'report.json',report)
        except BaseException as e:
            keep=primary if primary is not None else cancel
            if keep is None:raise
            keep.add_note('terminal publication: '+repr(e))
        if primary is not None:raise primary
        if cancel is not None:raise cancel
    print(json.dumps({n:report[n] for n in ('passed','tests','elapsed_s','reference_npz_sha256','source_archive_sha256')}));return 0 if report['passed'] else 1
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();raise SystemExit(run(a.output))
