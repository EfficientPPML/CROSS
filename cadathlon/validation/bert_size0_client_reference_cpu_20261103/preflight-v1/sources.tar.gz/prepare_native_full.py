"""Client-only pinned native full-BERT references for joined arithmetic checking.

Only the original compact embeddings may be used as joined-owner inputs. Every
later layer, pooler, and logit array is an independent comparison reference.
"""
from pathlib import Path
import hashlib
import sys
import numpy as np

SNAPSHOT=Path('/home/jianming_gatech/cross_validation_assets/bert/f150c1d609d1e50dd5e2e5408661cfac8339277c')
PRIOR=Path('/tmp/bert-first-attention-owner-20261103/client_fixtures.npz')
PRIOR_SHA='184397324e50f8c33cd6ea62f47457b3b0992da85814c001927b412ca6d06ce7'
ASSETS={
 'config.json':'ec2b6cd6ce741dda6c972aea96f9d1a449cbb4b5349e688c5370a9b2f6872d30',
 'model.safetensors':'e1f8085ef673c9eb8a1a93a84270742e8aa0ccbceadef01eef15e26c44b46034',
 'tokenizer.json':'5b3360be30cdf39081153cf9d30bfb0503c011462fc9f77f097127c83ef0f4d9',
 'tokenizer_config.json':'0f6d13e6f4da6f9e24f22ada6bc3be571123d858d7c0c05a8a7cd55a9c23c2e8',
 'vocab.txt':'eeaa9875b23b04b4c54ef759d03db9d1ba1554838f8fb26c5d96fa551df93d02'}
PAIRS=(
 ('The committee approved the proposal.','The committee approved the proposal.'),
 ('The committee reviews the proposal and discusses the evidence. '*20,
  'Members discuss the proposal before reaching a decision. '*20),
)
GATE=1e-12

def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def array_record(value):
    a=np.asarray(value)
    return dict(shape=list(a.shape),dtype=a.dtype.str,sha256=hashlib.sha256(a.tobytes()).hexdigest())
def parity(left,right):
    a,b=np.asarray(left),np.asarray(right)
    if a.shape!=b.shape or a.dtype!=np.float64 or b.dtype!=np.float64 or not np.isfinite(a).all() or not np.isfinite(b).all():
        raise ValueError('native comparison requires matching finite float64 shapes')
    with np.errstate(over='ignore',invalid='ignore'):error=float(np.max(np.abs(a-b)))
    if not np.isfinite(error) or error>GATE:raise ValueError('fixed native compaction gate failed')
    return error

def capture_pooler(module,forward):
    """Retain the actual pooler output and always remove its native hook."""
    values=[]
    def hook(owner,inputs,output):
        a=np.array(output.detach().cpu().numpy(),copy=True)
        if a.shape!=(1,768) or a.dtype!=np.float64 or not np.isfinite(a).all():raise ValueError('native pooler shape/dtype differs')
        values.append(a[0])
    handle=module.register_forward_hook(hook)
    try:
        result=forward()
        if len(values)!=1:raise ValueError('native pooler capture incomplete or repeated')
        return result,values[0]
    finally:
        primary=sys.exception()
        try:handle.remove()
        except BaseException as error:
            if primary is None:raise
            primary.add_note('native pooler hook removal: '+repr(error))

def valid_positions(mask,expected):
    a=np.asarray(mask)
    if a.shape!=(128,) or a.dtype.kind not in 'biu' or not np.isin(a,(0,1)).all():raise ValueError('fixed public128 mask required')
    positions=np.flatnonzero(a).astype(np.int64)
    if len(positions)!=expected or positions[0]!=0:raise ValueError('fixed key count/CLS differs')
    return positions

def hidden_array(value,sequence):
    a=np.array(value.detach().cpu().numpy(),copy=True)
    if a.shape!=(1,sequence,768) or a.dtype!=np.float64 or not np.isfinite(a).all():raise ValueError('native hidden state boundary differs')
    return a[0]

def prepare(snapshot=SNAPSHOT):
    """Run the two fixed examples; never choose rows from approximation success."""
    snapshot=Path(snapshot)
    before={name:sha(snapshot/name) for name in ASSETS}
    if before!=ASSETS or sha(PRIOR)!=PRIOR_SHA:raise ValueError('pinned native inputs/assets changed')
    import torch
    from transformers import AutoTokenizer,BertForSequenceClassification
    torch.set_num_threads(4)
    model,loading=BertForSequenceClassification.from_pretrained(snapshot,local_files_only=True,use_safetensors=True,
        torch_dtype=torch.float64,attn_implementation='eager',output_loading_info=True)
    if loading['missing_keys'] or loading.get('mismatched_keys') or loading.get('error_msgs') or not set(loading['unexpected_keys'])<={'bert.embeddings.position_ids'}:
        raise ValueError('pinned native model loading differs')
    model.eval();tokenizer=AutoTokenizer.from_pretrained(snapshot,local_files_only=True)
    if (model.config.hidden_size,model.config.num_hidden_layers,model.config.num_attention_heads,model.config.intermediate_size,model.config.layer_norm_eps)!=(768,12,12,3072,1e-12):
        raise ValueError('native architecture differs')
    arrays={};cases=[]
    with np.load(PRIOR,allow_pickle=False) as old,torch.no_grad():
        for index,pair in enumerate(PAIRS):
            K=(15,128)[index]
            tokens=tokenizer(*pair,max_length=128,truncation=True,padding='max_length',return_tensors='pt')
            positions=valid_positions(tokens['attention_mask'][0].numpy(),K)
            if not np.array_equal(positions,old[f'K{K}_original_positions']):raise ValueError('prior original positions differ')
            full,pooler=capture_pooler(model.bert.pooler,lambda:model(**tokens,output_hidden_states=True,return_dict=True))
            if len(full.hidden_states)!=13:raise ValueError('all twelve native layer outputs required')
            initial=hidden_array(full.hidden_states[0],128)
            compact=full.hidden_states[0][:,positions,:]
            padded=np.zeros((128,768));padded[:K]=initial[positions]
            initial_error=parity(padded,old[f'K{K}_embeddings'])
            if initial_error!=0.:raise ValueError('initial embedding bytes differ from prior fixed fixture')
            compact_encoder=model.bert.encoder(compact,attention_mask=torch.zeros((1,1,1,K),dtype=torch.float64),output_hidden_states=True,return_dict=True)
            if len(compact_encoder.hidden_states)!=13:raise ValueError('compact native layer outputs incomplete')
            compact_pooler=model.bert.pooler(compact_encoder.last_hidden_state)
            compact_logits=model.classifier(model.dropout(compact_pooler)).cpu().numpy()[0]
            full_logits=np.array(full.logits.cpu().numpy()[0],copy=True)
            if full_logits.shape!=(2,) or full_logits.dtype!=np.float64 or not np.isfinite(full_logits).all():raise ValueError('native logits boundary differs')
            checks=[]
            for layer in range(12):
                native=hidden_array(full.hidden_states[layer+1],128)[positions]
                compact_native=hidden_array(compact_encoder.hidden_states[layer+1],K)
                error=parity(native,compact_native)
                arrays[f'layer{layer}_K{K}_native']=native.copy()
                checks.append(dict(layer=layer,full128_vs_compact_max_abs=error))
            pooler_error=parity(pooler,compact_pooler.cpu().numpy()[0]);logit_error=parity(full_logits,compact_logits)
            arrays[f'K{K}_embeddings']=padded
            arrays[f'K{K}_positions']=positions
            arrays[f'K{K}_pooler_native']=pooler
            arrays[f'K{K}_logits_native']=full_logits
            import json
            token_sha=hashlib.sha256(json.dumps({k:v.tolist() for k,v in tokens.items()},sort_keys=True).encode()).hexdigest()
            cases.append(dict(K=K,original_positions=positions.tolist(),initial_embedding_max_abs=initial_error,
                layers=checks,pooler_compaction_max_abs=pooler_error,logit_compaction_max_abs=logit_error,
                tokenization_sha256=token_sha))
    after={name:sha(snapshot/name) for name in ASSETS}
    if after!=before or sha(PRIOR)!=PRIOR_SHA:raise ValueError('native assets changed during preparation')
    if len(arrays)!=32:raise ValueError('complete independent native reference inventory required')
    return arrays,dict(cases=cases,asset_sha256=before,asset_hashes_after=after,prior_fixture_sha256=PRIOR_SHA,
        arrays={k:array_record(v) for k,v in arrays.items()},fixed_native_compaction_gate=GATE,
        allowed_joined_inputs=['K15_embeddings','K128_embeddings'],
        later_native_arrays_are_references_only=True,labels_loaded=False,approximation_domain_selection=False)
