"""One authenticated upstream size0 input; client-only native/clear references.

No keys, ciphertext, server, labels, token selection, or coefficient selection.
Private references are retained in a new0700 directory, never in evidence.
"""
from pathlib import Path
import argparse, gc, hashlib, importlib.metadata, importlib.util, io, json, os
import signal, stat, subprocess, sys, tarfile, tempfile, time
import numpy as np
import client_inputs, input_gate, key_gate
from full_model_reference import compute, DomainViolation, MANIFEST_SHA256
from collect_full_model_reference import load_weights
from prepare_native_full import capture_pooler, hidden_array
from server_public_model import open_owned_directory, check_owned_directory

HERE=Path(__file__).resolve().parent
FIXTURE=Path('/tmp/bert-size0-input-fixture-20261103/actual-v1')
FIXTURE_SHA='2218282c9d4ef468a448d00d6e7afeebc9c3a9fa0e9f3834227afe299ea28e10'
INPUT_SHA='c30ffc79d8150cf6cf3d544bca23a07150d8a0d0f7b7924788e91df3aa55991f'
PINS_SHA='719d09712c2b26e80bfc36897a81dcd423cfa9ef64cb6423899ff80a0f72f575'
MODEL=input_gate.MODEL
PARITY_GATE=1e-12

def sha(path):
    return client_inputs.file_sha256(Path(path))

def write(path,value):
    raw=(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    temp=path.with_suffix(path.suffix+'.tmp');temp.write_bytes(raw);temp.replace(path)

def real_array(value,shape):
    a=np.asarray(value)
    if a.shape!=shape or a.dtype.kind not in 'fiu' or not np.isfinite(a).all():
        raise ValueError('finite real numeric array with exact shape required')
    with np.errstate(over='ignore',invalid='ignore'):a=a.astype(np.float64)
    if not np.isfinite(a).all():raise ValueError('finite binary64 conversion required')
    return a

def compare(left,right,*,shape,gate=None,p2=False):
    a,b=real_array(left,shape),real_array(right,shape)
    with np.errstate(over='ignore',invalid='ignore'):error=np.abs(a-b)
    if not np.isfinite(error).all():raise ValueError('finite comparison difference required')
    passed=bool(np.all(error<=(.02+.01*np.abs(b)))) if p2 else bool(gate is None or np.all(error<=gate))
    return dict(max_abs=float(error.max()),passed=passed)

def prediction_agreement(left,right):
    a,b=real_array(left,(2,)),real_array(right,(2,))
    # Exact upstream tie rule: class1 when logits are equal.
    return bool((a[1]>=a[0])==(b[1]>=b[0]))

def fixture_inventory(workspace,expected):
    files={p.relative_to(workspace).as_posix():p for p in workspace.rglob('*') if not p.is_dir()}
    if set(files)!=set(expected):raise ValueError('original six-file fixture inventory differs')
    for p in files.values():
        s=p.lstat()
        if not stat.S_ISREG(s.st_mode) or stat.S_IMODE(s.st_mode)!=0o600:
            raise ValueError('original private fixture file mode/type differs')
    result={n:sha(p) for n,p in files.items()}
    if result!=expected:raise ValueError('original six private fixture bytes differ')
    return result

def authenticate():
    value=input_gate.authenticate(FIXTURE,FIXTURE_SHA)
    if value['input_sha256']!=INPUT_SHA or value['valid_token_count']!=32:
        raise ValueError('fixed size0 input identity differs')
    report=key_gate.parse(key_gate.read(FIXTURE/'report.json'))
    fixture_inventory(value['private_workspace'],report['input_file_sha256'])
    return value,report

def source_paths():
    paths={p.name:p for p in HERE.iterdir() if p.suffix in ('.py','.json','.md') and p.is_file()}
    names=('transformers.models.bert.modeling_bert','transformers.modeling_utils',
           'transformers.configuration_utils','transformers.activations','transformers.pytorch_utils',
           'torch.nn.functional','torch.nn.modules.normalization','torch.nn.modules.linear')
    for name in names:
        spec=importlib.util.find_spec(name)
        paths['installed/'+name.replace('.','/')+'.py']=Path(spec.origin)
    return paths

def source_hashes(paths):return {n:sha(p) for n,p in paths.items()}

def archive(path,paths):
    with tarfile.open(path,'w:gz') as tar:
        for name,p in paths.items():
            raw=p.read_bytes();member=tarfile.TarInfo(name);member.size=len(raw);tar.addfile(member,io.BytesIO(raw))

def verify_archive(path,expected):
    with tarfile.open(path) as tar:
        members=tar.getmembers()
        if len(members)!=len(expected) or len({m.name for m in members})!=len(members) or any(not m.isfile() for m in members):
            raise ValueError('exact unique source archive inventory required')
        if {m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in members}!=expected:
            raise ValueError('source archive bytes differ')
    return True

def save_private(workspace,descriptor,identity,value):
    check_owned_directory(workspace,descriptor,identity)
    raw=(json.dumps(value,sort_keys=True,allow_nan=False)+'\n').encode()
    fd=os.open('references.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=descriptor)
    try:
        with os.fdopen(os.dup(fd),'wb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
    finally:os.close(fd)
    check_owned_directory(workspace,descriptor,identity)
    return hashlib.sha256(raw).hexdigest()

def native_model(dtype=None,eager=False):
    import torch
    from transformers import BertForSequenceClassification
    options=dict(local_files_only=True,use_safetensors=True,output_loading_info=True)
    if dtype is not None:options['torch_dtype']=dtype
    if eager:options['attn_implementation']='eager'
    model,loading=BertForSequenceClassification.from_pretrained(MODEL,**options)
    if (loading['missing_keys'] or loading.get('mismatched_keys') or loading.get('error_msgs')
            or not set(loading['unexpected_keys'])<={'bert.embeddings.position_ids'}):
        raise ValueError('pinned native model load differs')
    model.eval();model.requires_grad_(False)
    expected=dtype if dtype is not None else torch.float32
    if any(p.dtype!=expected or p.device.type!='cpu' for p in model.parameters()):
        raise ValueError('native dtype/device differs')
    return model

def evaluate(record,report):
    import torch
    torch.set_num_threads(4)
    tokens={n:torch.tensor([getattr(record,n)],dtype=torch.long) for n in ('input_ids','token_type_ids','attention_mask')}
    with torch.no_grad():
        official=native_model()
        native32=real_array(official(**tokens,return_dict=True).logits.cpu().numpy()[0],(2,))
        report['official_native']=dict(dtype='float32',attention_implementation=official.config._attn_implementation,
            original128_mask=True,upstream_default_dtype=True,model_revision=client_inputs.REVISION)
        del official;gc.collect()
        embedder=client_inputs.ClientEmbeddings(MODEL)
        original=embedder.original_embeddings(record)
        positions=tuple(i for i,x in enumerate(record.attention_mask) if x)
        embeddings=original[list(positions)].copy();input_bytes=embeddings.tobytes()
        native=native_model(torch.float64,True)
        attention=[];handles=[]
        def hook(module,args,value):attention.append(hidden_array(value[0],128)[list(positions)])
        try:
            for layer in native.bert.encoder.layer:handles.append(layer.attention.register_forward_hook(hook))
            full,pooler=capture_pooler(native.bert.pooler,lambda:native(**tokens,return_dict=True,output_hidden_states=True))
        finally:
            primary=sys.exception();errors=[]
            for handle in handles:
                try:handle.remove()
                except BaseException as e:errors.append(e)
            if errors:
                if primary is not None:
                    for e in errors:primary.add_note('attention hook cleanup: '+repr(e))
                else:raise next((e for e in errors if not isinstance(e,Exception)),errors[0])
        if len(attention)!=12 or len(full.hidden_states)!=13:raise ValueError('complete native capture required')
        native64=real_array(full.logits.cpu().numpy()[0],(2,))
        report['client_embedding_native_parity']=compare(original,hidden_array(full.hidden_states[0],128),shape=(128,768),gate=0.)
        weights=load_weights(json.loads((HERE/'server_tensor_pins.json').read_bytes()))
        raw=(HERE/'candidate_manifest.json').read_bytes()
        exact=compute(embeddings,weights,raw,approximate=False)
        checks=[]
        for layer in range(12):
            checks.append(dict(layer=layer,attention=compare(exact['attention_outputs'][layer],attention[layer],shape=(32,768),gate=PARITY_GATE),
                block=compare(exact['block_outputs'][layer],hidden_array(full.hidden_states[layer+1],128)[list(positions)],shape=(32,768),gate=PARITY_GATE)))
        report['exact_fp64_parity']=dict(layers=checks,pooler=compare(exact['pooler'],pooler,shape=(768,),gate=PARITY_GATE),
            logits=compare(exact['logits'],native64,shape=(2,),gate=PARITY_GATE),gate=PARITY_GATE,native_attention_implementation='eager')
        if (not report['client_embedding_native_parity']['passed'] or not all(x[k]['passed'] for x in checks for k in ('attention','block'))
                or not report['exact_fp64_parity']['pooler']['passed'] or not report['exact_fp64_parity']['logits']['passed']):
            raise ValueError('fixed exact/native parity gate failed')
        approx=compute(embeddings,weights,raw,approximate=True)
        report.update(approximate_complete=True,domain_observations=approx['domain_observations'],
            approximate_vs_official_fp32=compare(approx['logits'],native32,shape=(2,),p2=True),
            approximate_vs_native_fp64=compare(approx['logits'],native64,shape=(2,),p2=True),
            prediction_agreement_official_fp32=prediction_agreement(approx['logits'],native32),
            prediction_agreement_native_fp64=prediction_agreement(approx['logits'],native64))
        if embeddings.tobytes()!=input_bytes:raise ValueError('client embedding source mutated')
        report['client_embedding_bytes_unchanged']=True
        return dict(schema='bert-size0-private-reference-v1',target_idx=record.target_idx,input_sha256=INPUT_SHA,
            fixture_report_sha256=FIXTURE_SHA,candidate_sha256=MANIFEST_SHA256,checkpoint_sha256=client_inputs.ASSETS['model.safetensors'],
            original_positions=list(positions),native_fp32_logits=native32.tolist(),native_fp64_logits=native64.tolist(),
            independent_exact_fp64_logits=exact['logits'].tolist(),approximate_fp64_logits=approx['logits'].tolist())

def run(output,preflight):
    output.mkdir(exist_ok=False);started=time.monotonic();paths={};before={};original={};workspace=None;fd=None;identity=None
    primary=None;cleanup=[];cancellation=None;handlers={}
    report=dict(schema='bert-size0-client-reference-v1',passed=False,preflight=preflight,record_count=1,key_count=32,
        scope='Client-only one fixed size0 example; native FP32 benchmark and FP64/eager parity, unchanged independent approximate full12 reference. No HE/server/keys/labels/ranked accuracy.',
        raw_arrays_archived=False,labels_loaded=False,fixture_report_sha256=FIXTURE_SHA,input_sha256=INPUT_SHA,
        candidate_sha256=MANIFEST_SHA256,approximate_complete=False,cleanup_errors=cleanup,
        gates=dict(native_fp64_parity=PARITY_GATE,original_P2='abs(approx-native_fp32)<=0.02+0.01*abs(native_fp32)',prediction='upstream class1 on ties'),
        cpu_affinity=sorted(os.sched_getaffinity(0)),pid=os.getpid())
    def attempt(name,fn):
        nonlocal cancellation
        try:return fn()
        except BaseException as e:
            cleanup.append(dict(operation=name,type=type(e).__name__))
            if primary is not None:primary.add_note(name+': '+repr(e))
            elif not isinstance(e,Exception) and cancellation is None:cancellation=e
    try:
        write(output/'report.json',report)
        for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP):
            handlers[sig]=signal.getsignal(sig);signal.signal(sig,lambda signum,frame:(_ for _ in ()).throw(KeyboardInterrupt('signal '+str(signum))))
        paths=source_paths();before=source_hashes(paths)
        if before['candidate_manifest.json']!=MANIFEST_SHA256 or before['server_tensor_pins.json']!=PINS_SHA:
            raise ValueError('frozen candidate/tensor pins differ')
        origins=json.loads((HERE/'origins.json').read_bytes())
        if any(before.get(n)!=row['sha256'] for n,row in origins.items()):raise ValueError('copied reviewed helper bytes differ')
        archive(output/'sources.tar.gz',paths);verify_archive(output/'sources.tar.gz',before)
        report.update(source_hashes_before=before,source_archive_sha256=sha(output/'sources.tar.gz'),source_archive_verified=True,
            versions={n:importlib.metadata.version(n) for n in ('numpy','scipy','torch','transformers','safetensors','pytest')},python=sys.version,
            environment={n:os.environ.get(n) for n in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE')})
        fixture,original=authenticate();report['original_private_files_before']=fixture_inventory(fixture['private_workspace'],original['input_file_sha256'])
        report['asset_hashes_before']={n:sha(Path(n)) for n in input_gate.ASSETS}
        if report['asset_hashes_before']!=input_gate.ASSETS:raise ValueError('pinned public assets differ')
        if preflight:
            with (output/'tests.log').open('wb') as log:
                result=subprocess.run([sys.executable,'-m','pytest','-q',str(HERE/'test_reference.py'),'--tb=short','--junitxml='+str(output/'tests.xml')],stdout=log,stderr=subprocess.STDOUT)
            import xml.etree.ElementTree as ET
            report['tests']={n:sum(int(s.attrib.get(n,0)) for s in ET.parse(output/'tests.xml').getroot()) for n in ('tests','errors','failures','skipped')}
            report['test_returncode']=result.returncode
            report['passed']=result.returncode==0 and not any(report['tests'][n] for n in ('errors','failures','skipped'))
        else:
            prerequisite=json.loads((HERE/'preflight-v1/report.json').read_bytes())
            if not prerequisite['passed'] or prerequisite['source_hashes_before']!=before or prerequisite['source_hashes_after']!=before:
                raise ValueError('unchanged successful preflight prerequisite required')
            report['preflight_report_sha256']=sha(HERE/'preflight-v1/report.json')
            records=client_inputs.read_preprocessed_jsonl(fixture['preprocessed_input'])
            if len(records)!=1 or sum(records[0].attention_mask)!=32:raise ValueError('fixed size0 single record required')
            workspace=Path(tempfile.mkdtemp(prefix='bert-size0-reference-client-'));os.chmod(workspace,0o700)
            fd,identity=open_owned_directory(workspace)
            report.update(private_workspace=str(workspace),private_workspace_identity=identity)
            write(output/'report.json',report)
            private=evaluate(records[0],report)
            report['private_reference_sha256']=save_private(workspace,fd,identity,private)
            report['private_reference_path']=str(workspace/'references.json')
            report['private_reference_permissions_0600']=stat.S_IMODE((workspace/'references.json').stat().st_mode)==0o600
            report['passed']=report['approximate_vs_official_fp32']['passed'] and report['prediction_agreement_official_fp32']
    except BaseException as e:
        primary=e;report['passed']=False;report['error']={'type':type(e).__name__}
        if isinstance(e,DomainViolation):report['failed_domain']=e.observation
    finally:
        # Shield repeated cancellation while completing evidence. No child/HE owner survives.
        for sig in handlers:attempt('shield_signal',lambda sig=sig:signal.signal(sig,signal.SIG_IGN))
        attempt('garbage_collection',gc.collect)
        if original:
            after=attempt('original_fixture',lambda:fixture_inventory(Path(original['private_workspace']),original['input_file_sha256']))
            report['original_private_files_after']=after;report['original_fixture_unchanged']=after==report.get('original_private_files_before')
        report['asset_hashes_after']=attempt('asset_readback',lambda:{n:sha(Path(n)) for n in input_gate.ASSETS})
        report['assets_unchanged']=report.get('asset_hashes_before')==report['asset_hashes_after'] and bool(report.get('asset_hashes_before'))
        report['source_hashes_after']=attempt('source_readback',lambda:source_hashes(paths))
        report['source_files_unchanged']=bool(before) and report['source_hashes_after']==before
        if before:attempt('archive_readback',lambda:verify_archive(output/'sources.tar.gz',before))
        if fd is not None:
            attempt('private_identity',lambda:check_owned_directory(workspace,fd,identity));attempt('private_descriptor_close',lambda:os.close(fd))
        report['no_jax_or_he_modules_loaded']=not any(n=='jax' or n.startswith(('jax.','jaxite_word','jaxite.')) for n in sys.modules)
        report['private_workspace_retained']=workspace is not None and workspace.is_dir()
        report['passed']=bool(report['passed'] and not cleanup and report['source_files_unchanged'] and report['assets_unchanged']
            and report.get('original_fixture_unchanged') and report['no_jax_or_he_modules_loaded'])
        report['elapsed_s']=time.monotonic()-started
        attempt('final_publication',lambda:write(output/'report.json',report))
        for sig,handler in handlers.items():attempt('restore_signal',lambda sig=sig,handler=handler:signal.signal(sig,handler))
    if primary is not None and not isinstance(primary,Exception):raise primary
    if cancellation is not None and primary is None:raise cancellation
    return 0 if report['passed'] and not cleanup else 1

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--preflight',action='store_true')
    args=parser.parse_args();raise SystemExit(run(args.output,args.preflight))
