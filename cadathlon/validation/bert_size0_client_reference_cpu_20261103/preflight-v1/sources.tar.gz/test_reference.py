from pathlib import Path
import hashlib,io,json,os,stat,tarfile
import numpy as np
import pytest
import check_reference as r

@pytest.mark.parametrize('bad',[np.array([1+2j,2+0j]),np.array([1,2],dtype=object),np.array(['1','2']),np.array([True,False]),np.array([np.nan,2.]),np.array([np.inf,2.]),np.zeros(3)])
def test_metric_rejects_nonreal_nonfinite_and_shape(bad):
    with pytest.raises(ValueError):r.compare(bad,np.ones(2),shape=(2,),p2=True)
    with pytest.raises(ValueError):r.compare(np.ones(2),bad,shape=(2,),p2=True)

def test_difference_overflow_fails():
    with pytest.raises(ValueError):r.compare(np.array([1e308,0.]),np.array([-1e308,0.]),shape=(2,),p2=True)

def test_gate_uses_native_denominator_not_approximate():
    # delta .02 against native0 is the fixed boundary, not relative to estimate.
    assert r.compare([.02,2.],[0.,2.],shape=(2,),p2=True)['passed']
    assert not r.compare([.0201,2.],[0.,2.],shape=(2,),p2=True)['passed']

def test_upstream_tie_is_class_one():
    assert r.prediction_agreement([0.,0.],[-1.,1.])
    assert not r.prediction_agreement([0.,0.],[1.,-1.])

@pytest.mark.parametrize('kind',('extra','changed','symlink','mode'))
def test_original_fixture_exact_inventory(tmp_path,kind):
    p=tmp_path/'input';p.write_bytes(b'private-placeholder');p.chmod(0o600)
    expected={'input':r.sha(p)}
    assert r.fixture_inventory(tmp_path,expected)==expected
    if kind=='extra':(tmp_path/'extra').write_bytes(b'not part of fixture')
    elif kind=='changed':p.write_bytes(b'different')
    elif kind=='symlink':p.unlink();p.symlink_to('/dev/null')
    else:p.chmod(0o644)
    with pytest.raises(ValueError):r.fixture_inventory(tmp_path,expected)

def test_external_report_authentication_precedes_private_asset_reads(monkeypatch):
    monkeypatch.setattr(r.input_gate.key_gate,'read',lambda *a,**k:b'{}')
    monkeypatch.setattr(r,'fixture_inventory',lambda *a:pytest.fail('private data reached'))
    with pytest.raises(ValueError,match='external completed'):r.authenticate()

def test_private_output_mode_exclusive_and_no_public_values(tmp_path):
    tmp_path.chmod(0o700);fd,identity=r.open_owned_directory(tmp_path)
    value={'target_idx':17,'native_fp32_logits':[1.25,-2.75]}
    try:
        digest=r.save_private(tmp_path,fd,identity,value)
        assert r.sha(tmp_path/'references.json')==digest
        assert stat.S_IMODE((tmp_path/'references.json').stat().st_mode)==0o600
        assert json.loads((tmp_path/'references.json').read_bytes())==value
        with pytest.raises(FileExistsError):r.save_private(tmp_path,fd,identity,value)
    finally:os.close(fd)

def test_private_output_rejects_replacement(tmp_path):
    root=tmp_path/'owned';root.mkdir();fd,identity=r.open_owned_directory(root)
    try:
        root.rename(tmp_path/'moved');root.mkdir()
        with pytest.raises(RuntimeError):r.save_private(root,fd,identity,{'safe':True})
        assert not list(root.iterdir())
    finally:os.close(fd)

def test_archive_duplicate_rejected(tmp_path):
    p=tmp_path/'dup.tar.gz'
    with tarfile.open(p,'w:gz') as tar:
        for _ in range(2):
            member=tarfile.TarInfo('a.py');member.size=1;tar.addfile(member,io.BytesIO(b'x'))
    with pytest.raises(ValueError):r.verify_archive(p,{'a.py':hashlib.sha256(b'x').hexdigest()})

def test_exact_copied_reference_and_client_helpers_bound():
    origins=json.loads((r.HERE/'origins.json').read_bytes())
    for name,row in origins.items():assert r.sha(r.HERE/name)==row['sha256']
    assert r.sha(r.HERE/'full_model_reference.py')=='a32b51c0e0e1f436891fa087eeb2c8756c1115777a2a57d4f3605262cefc0d51'
    assert r.sha(r.HERE/'client_inputs.py')=='ea026bcadb56281762535daa0168ecaa3abf18df29f20fa81f4e7adb183b1e72'
    assert r.sha(r.HERE/'candidate_manifest.json')==r.MANIFEST_SHA256

def test_harness_predictions_and_model_default_dtype_source():
    model=(r.HERE/'upstream_model.py').read_text();predict=(r.HERE/'upstream_test.py').read_text()
    assert 'torch_dtype' not in model and 'from_pretrained(MODEL_ID)' in model
    assert '0 if logits[0].item() > logits[1].item() else 1' in predict
