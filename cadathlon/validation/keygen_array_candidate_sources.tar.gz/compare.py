"""Compare allocation-only keygen changes with identical public test entropy."""
import gc
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import sys
import time
from unittest import mock

BASE = Path(__file__).resolve().parent
CORE = BASE / 'checkout/jaxite_word'
sys.path[:0] = [str(CORE), str(CORE.parent)]
import numpy as np
import key_gen as candidate
import util
import he_params
from composite_prime_gen import composite_prime_gen

spec = importlib.util.spec_from_file_location('baseline_key_gen', BASE / 'baseline_key_gen.py')
baseline = importlib.util.module_from_spec(spec)
spec.loader.exec_module(baseline)


def hashes():
    paths = [*CORE.rglob('*.py'), BASE / 'baseline_key_gen.py', Path(__file__)]
    return {str(p.relative_to(BASE)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}


class TestEntropy:
    def __init__(self, seed):
        self.generator = np.random.default_rng(seed)
        self.calls = []

    def draw(self, kind, size):
        self.calls.append((kind, size))
        return self.generator.bytes(size)


def run(module, secret, q, p, *, dnum, rotation, seed):
    entropy = TestEntropy(seed)
    started = time.perf_counter()
    with mock.patch.object(module.secrets, 'token_bytes', side_effect=lambda n: entropy.draw('uniform', n)), \
         mock.patch.object(module.os, 'urandom', side_effect=lambda n: entropy.draw('gaussian', n)), \
         mock.patch.dict(os.environ, {'CROSS_NP_KEYGEN': '1'}):
        result = module.gen_rotation_key(secret, q, p, rotation, dnum=dnum)[rotation]
    return result, entropy.calls, time.perf_counter() - started


def compare(degree, depth, dnum, rotation, seed, *, reverse=False):
    q = composite_prime_gen(2, 2 * (depth + 1), 61, 56, 2 * degree, 31)
    p = util.generate_p_towers(q, dnum, degree, aux_bits=30)
    target = he_params.SecurityTarget(128, he_params.CostModel.CLASSICAL)
    assert he_params.qp_is_secure(q, p, degree, target)
    he_params.assert_p_coverage(q, p, dnum)
    coefficients = np.random.default_rng(seed + 1).integers(-1, 2, size=degree, dtype=np.int64)
    secret = []
    for modulus in q:
        transformed = util.ntt_negacyclic_bit_reverse(
            util.uint64_residues_np(coefficients, modulus), modulus,
            util.root_of_unity(2 * degree, modulus))
        secret.append(util.bit_reverse_array(transformed).tolist())
    outputs, calls, elapsed = {}, {}, {}
    order = ('candidate', 'baseline') if reverse else ('baseline', 'candidate')
    for name in order:
        outputs[name], calls[name], elapsed[name] = run(
            candidate if name == 'candidate' else baseline, secret, q, p,
            dnum=dnum, rotation=rotation, seed=seed)
    old, new = outputs['baseline'], outputs['candidate']
    assert old.keys() == new.keys()
    for field in old:
        if field in ('a', 'b'):
            assert old[field].dtype == new[field].dtype == np.uint32
            np.testing.assert_array_equal(old[field], new[field])
        else:
            assert old[field] == new[field]
    assert calls['baseline'] == calls['candidate']
    assert baseline.KEY_GENERATION_VERSION == candidate.KEY_GENERATION_VERSION
    record = {
        'degree': degree, 'depth': depth, 'dnum': dnum, 'rotation': rotation,
        'q_count': len(q), 'p_count': len(p), 'security_parameter_check': True,
        'order': order, 'elapsed_s': elapsed, 'array_shape': list(new['a'].shape),
        'payload_and_metadata_bit_exact': True, 'entropy_call_sequence_identical': True,
        'entropy_calls': len(calls['candidate']),
        'entropy_bytes': sum(size for _, size in calls['candidate']),
        'public_test_key_sha256': {name: hashlib.sha256(memoryview(new[name]).cast('B')).hexdigest()
                                   for name in ('a', 'b')},
        'key_generation_version': candidate.KEY_GENERATION_VERSION,
    }
    print(json.dumps(record), flush=True)
    del outputs, old, new, secret
    gc.collect()
    return record


before = hashes()
(BASE / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
started = time.perf_counter()
records = []
report = {
    'scope': 'Native allocation-only keygen candidate; deterministic public test entropy for exact parity, never production key generation.',
    'passed': False, 'sources': before,
    'module_origins': {name: module.__file__ for name, module in
                       [('candidate', candidate), ('baseline', baseline), ('util', util), ('he_params', he_params)]},
    'timing_scope': 'Development CPU observations; order alternates, not controlled accelerator/model/calibration timing.',
}
try:
    records.append(compare(8192, 1, 2, 1, 371))
    records.append(compare(8192, 1, 2, -3, 927, reverse=True))
    records.append(compare(131072, 49, 4, 1, 1639))
    records.append(compare(131072, 49, 4, -3, 2639, reverse=True))
    report['passed'] = True
finally:
    after = hashes()
    report.update(cases=records, source_files_unchanged=before == after,
                  elapsed_s=time.perf_counter() - started,
                  max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    report['passed'] = report['passed'] and report['source_files_unchanged']
    (BASE / 'comparison.json').write_text(json.dumps(report, indent=2) + '\n')
    (BASE / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
    print(json.dumps({'passed': report['passed'], 'elapsed_s': report['elapsed_s'],
                      'source_files_unchanged': report['source_files_unchanged']}), flush=True)
