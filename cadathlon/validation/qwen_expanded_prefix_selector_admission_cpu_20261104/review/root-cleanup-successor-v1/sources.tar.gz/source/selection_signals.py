"""Reviewed observer signals with explicit cleanup-shield setup provenance."""
import signal
from contextlib import contextmanager
from cleanup_origin import cleanup_origin, mark_cleanup, protect_body, choose
SIGNALS=(signal.SIGTERM,signal.SIGINT,signal.SIGHUP)

def accumulate(primary, error, phase, body_primary=None):
    if body_primary is not None:
        protect_body(body_primary)
    return choose(primary,error,phase,body_primary=body_primary)

@contextmanager
def signals(state=None, shield=False):
    """Single-fire outer cancellation; deferred cleanup cancellation.

    Main-thread masking narrows installation/restoration windows, not a
    process-wide atomicity claim with native threads. All originals are saved
    before setters, and masks are queried before mutating operations.
    """
    state = {} if state is None else state
    state['restored'] = False
    old = {}; errors = []; deferred = []; previous = None
    primary = body = None; fired = False; entered = False
    def handler(number, frame):
        nonlocal fired
        if shield:
            deferred.append(number)
        elif not fired:
            fired = True
            raise KeyboardInterrupt('termination signal')
    def attempt(label,action):
        try:return action()
        except BaseException as error:
            errors.append((label,mark_cleanup(error)));return None
    try:
        previous = signal.pthread_sigmask(signal.SIG_BLOCK, ())
        signal.pthread_sigmask(signal.SIG_BLOCK, SIGNALS)
        for number in SIGNALS:
            old[number] = signal.getsignal(number)
        for number in SIGNALS:
            signal.signal(number, handler)
        signal.pthread_sigmask(signal.SIG_SETMASK, previous)
        entered = True
        yield
    except BaseException as error:
        primary = error
        # Setup of the cleanup-only shield is itself cleanup, not a new body.
        # Existing protected body objects remain protected if rethrown here.
        if shield and not entered:mark_cleanup(error)
        body = None if cleanup_origin(error) else protect_body(error)
        raise
    finally:
        # Capture the current mask separately before a possibly mutating setter.
        restore_mask = attempt('capture restoration mask',lambda:signal.pthread_sigmask(signal.SIG_BLOCK, ()))
        attempt('block during signal restoration',lambda:signal.pthread_sigmask(signal.SIG_BLOCK, SIGNALS))
        restored = True
        for number, handler_before in old.items():
            try:signal.signal(number,handler_before)
            except BaseException as error:
                restored=False;errors.append(('restore signal',mark_cleanup(error)))
        target = previous if previous is not None else restore_mask
        if target is not None:
            try:signal.pthread_sigmask(signal.SIG_SETMASK,target)
            except BaseException as error:
                restored=False;errors.append(('restore mask',mark_cleanup(error)))
        else:restored=False
        if deferred:errors.append(('deferred cleanup cancellation',mark_cleanup(KeyboardInterrupt('signals deferred during cleanup'))))
        state['restored'] = restored and not errors
        pending=primary
        for label,error in errors:pending=accumulate(pending,error,label,body)
        if pending is not None and pending is not primary:raise pending
