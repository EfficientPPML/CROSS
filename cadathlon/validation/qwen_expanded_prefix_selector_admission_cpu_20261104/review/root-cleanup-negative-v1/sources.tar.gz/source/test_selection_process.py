from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import os
import shutil
import subprocess
import sys
import pytest
import initial_proof as p
import selection_process as process
from test_initial_proof import fixture, encode, grant

HERE=Path(__file__).resolve().parent


def arrange(tmp_path):
    source=tmp_path/'source';source.mkdir()
    files={f.relative_to(HERE).as_posix():f.read_bytes()for f in HERE.rglob('*')
           if f.is_file()and '__pycache__'not in f.parts}
    for name,raw in files.items():
        target=source/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    mapping={n:p.digest(b)for n,b in files.items()};manifest=p.canonical(mapping)
    control=tmp_path/'control';control.mkdir();manifest_path=control/'sources.json';manifest_path.write_bytes(manifest)
    evidence=tmp_path/'public';evidence.mkdir()
    data=fixture();data[1]['private_output']['path']=str(tmp_path/'unopened-producer-private')
    args,pins,snapshot,outer=encode(data)
    private=tmp_path/'snapshot';private.mkdir(mode=0o700);snapshot_path=private/'reconstructed-snapshot.json'
    snapshot_path.write_bytes(snapshot);snapshot_path.chmod(0o600)
    stat=snapshot_path.stat();parent=private.stat();review=p.parse(args[3])
    review['snapshot_descriptor']=dict(path=str(snapshot_path),sha256=p.digest(snapshot),bytes=len(snapshot),
        identity=[stat.st_dev,stat.st_ino],parent_identity=[parent.st_dev,parent.st_ino])
    root=p.canonical(review);outer_row=p.parse(outer);outer_row['review_sha256']=p.digest(root);outer=p.canonical(outer_row)
    public=dict(parent=args[0],worker=args[1],source_archive=args[2],root_review=root,
        reconstruction_script=(HERE/'inputs/reconstruction_script.py.txt').read_bytes(),root_reconstruction_outer_receipt=outer)
    descriptors={}
    for name,raw in public.items():
        path=evidence/name;path.write_bytes(raw)
        descriptors[name]=dict(path=str(path),sha256=p.digest(raw),bytes=len(raw))
    pins=p.ProofPins(p.digest(args[0]),p.digest(args[1]),p.digest(args[2]),p.digest(root),pins.source_manifest_bytes,
                     p.RECONSTRUCTION_SCRIPT_SHA256,p.digest(outer))
    binding=p.authenticate_initial(args[0],args[1],args[2],root,pins=pins,root_outer_bytes=outer)
    admitted=p.authenticate_snapshot(snapshot,binding)
    output=tmp_path/'selection'
    row=grant(admitted,p.digest(manifest),str(output));row['initial_evidence']=descriptors
    grant_path=control/'grant.json';raw=p.canonical(row);grant_path.write_bytes(raw)
    command=[sys.executable,'-I','-B',str(source/'entry.py'),'--manifest',str(manifest_path),
        '--manifest-sha256',p.digest(manifest),'--output',str(output),'--execute',
        '--grant',str(grant_path),'--grant-sha256',p.digest(raw)]
    return dict(source=source,files=files,manifest=manifest_path,grant=grant_path,command=command,
                output=output,private=private,public=evidence,snapshot=snapshot_path)


def launch(row):
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',
             OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    return subprocess.run(row['command'],capture_output=True,text=True,env=env,timeout=90)


def test_actual_entry_with_only_synthetic_reports_ranges_and_grant(tmp_path):
    row=arrange(tmp_path);before={f.name:p.digest(f.read_bytes())for f in row['public'].iterdir()}
    snapshot=p.digest(row['snapshot'].read_bytes());result=launch(row)
    assert result.returncode==0,result.stderr
    report=p.parse((row['output']/'report.json').read_bytes())
    assert report['passed']is True and report['publication_complete']is True
    assert report['signal_restoration_completed']is True and report['cleanup_completed']is True
    assert report['audit_denials']==[] and report['source_hashes_start']==report['source_hashes_end']
    assert report['acceptance_requires_independent_exit0_reap_and_exact_report_hash']is True
    candidate=p.parse((row['output']/'candidate_manifest.json').read_bytes())
    assert candidate['candidate_ordinal']==1 and candidate['synthetic_only']is False
    assert report['model_execution']is False and report['validation_body_reads']is False
    assert snapshot==p.digest(row['snapshot'].read_bytes())
    assert before=={f.name:p.digest(f.read_bytes())for f in row['public'].iterdir()}
    assert {n:p.digest((row['source']/n).read_bytes())for n in row['files']}==p.parse(row['manifest'].read_bytes())


@pytest.mark.parametrize('mutation',['missing_grant','bad_grant','changed_helper','extra_shadow','wrong_source_hash','wrong_outer'])
def test_actual_cli_fails_before_snapshot_or_output(tmp_path,mutation):
    row=arrange(tmp_path);marker=tmp_path/'marker'
    if mutation=='missing_grant':row['command']=row['command'][:-4]
    elif mutation=='bad_grant':row['command'][-1]='0'*64
    elif mutation=='changed_helper':
        helper=row['source']/'selection_process.py';helper.write_text(f"open({str(marker)!r},'w').write('bad')\n"+helper.read_text())
    elif mutation=='extra_shadow':(row['source']/'platform.py').write_text(f"open({str(marker)!r},'w').write('bad')\n")
    elif mutation=='wrong_source_hash':row['command'][row['command'].index('--manifest-sha256')+1]='0'*64
    else:
        outer=row['public']/'root_reconstruction_outer_receipt';value=p.parse(outer.read_bytes());value['exit_code']=1
        raw=p.canonical(value);outer.write_bytes(raw)
        grant_value=p.parse(row['grant'].read_bytes());desc=grant_value['initial_evidence']['root_reconstruction_outer_receipt']
        desc.update(sha256=p.digest(raw),bytes=len(raw));raw=p.canonical(grant_value);row['grant'].write_bytes(raw);row['command'][-1]=p.digest(raw)
    result=launch(row)
    assert result.returncode!=0 and not marker.exists() and not row['output'].exists()
    assert not (tmp_path/'unopened-producer-private').exists()


def test_snapshot_holds_exact_permissions_and_identity(tmp_path):
    path=tmp_path/'held';path.mkdir(mode=0o700);file=path/'snapshot';file.write_bytes(b'hello');file.chmod(0o600)
    fs=file.stat();ps=path.stat();desc=dict(path=str(file),sha256=p.digest(b'hello'),bytes=5,
        identity=[fs.st_dev,fs.st_ino],parent_identity=[ps.st_dev,ps.st_ino])
    assert process.snapshot_read(desc)==b'hello'
    file.chmod(0o644)
    with pytest.raises(ValueError,match='permissions'):process.snapshot_read(desc)


@pytest.mark.parametrize('primary_factory',[ValueError,KeyboardInterrupt,SystemExit])
def test_snapshot_body_primary_survives_both_close_errors(tmp_path,monkeypatch,primary_factory):
    path=tmp_path/'held';path.mkdir(mode=0o700);file=path/'snapshot';file.write_bytes(b'x');file.chmod(0o600)
    fs=file.stat();ps=path.stat();desc=dict(path=str(file),sha256=p.digest(b'x'),bytes=1,
        identity=[fs.st_dev,fs.st_ino],parent_identity=[ps.st_dev,ps.st_ino])
    primary=primary_factory('synthetic body');real_close=os.close;closed=[]
    def close(fd):
        real_close(fd);closed.append(fd);raise OSError('synthetic close')
    fake=SimpleNamespace(**{n:getattr(os,n)for n in ('open','fstat','stat','getuid','O_RDONLY','O_DIRECTORY','O_NOFOLLOW','O_CLOEXEC','O_NONBLOCK')},
                         read=lambda *a:(_ for _ in ()).throw(primary),close=close)
    monkeypatch.setattr(process,'os',fake)
    with pytest.raises(type(primary))as result:process.snapshot_read(desc)
    assert result.value is primary and len(closed)==2


@pytest.mark.parametrize('cancel',[KeyboardInterrupt,SystemExit])
def test_snapshot_cleanup_only_later_cancellation_wins(tmp_path,monkeypatch,cancel):
    path=tmp_path/'held';path.mkdir(mode=0o700);file=path/'snapshot';file.write_bytes(b'x');file.chmod(0o600)
    fs=file.stat();ps=path.stat();desc=dict(path=str(file),sha256=p.digest(b'x'),bytes=1,
        identity=[fs.st_dev,fs.st_ino],parent_identity=[ps.st_dev,ps.st_ino])
    real_close=os.close;closed=[];primary=OSError('file close');later=cancel('directory close')
    def close(fd):
        real_close(fd);closed.append(fd);raise primary if len(closed)==1 else later
    fake=SimpleNamespace(**{n:getattr(os,n)for n in ('open','fstat','stat','read','getuid','O_RDONLY','O_DIRECTORY','O_NOFOLLOW','O_CLOEXEC','O_NONBLOCK')},close=close)
    monkeypatch.setattr(process,'os',fake)
    with pytest.raises(cancel)as result:process.snapshot_read(desc)
    assert result.value is later and len(closed)==2
