from pathlib import Path
from fractions import Fraction as F
import ast,copy,hashlib,io,json,math,tarfile
import numpy as np
import pytest
import admission as a
import selector as s
import numeric,newton_certificate,select_rules
HERE=Path(__file__).resolve().parent

def stats(n,lo,hi):return dict(count=n,minimum=float(lo),maximum=float(hi),nonfinite=0,nonpositive=n if hi<=0 else 0 if lo>0 else n//2)

def family():
    counts=a.expected_counts();rows={n:stats(c,1.,1.01)if n in s.NORMS else stats(c,-.5,.5)for n,c in counts.items()}
    scores={}
    for layer in range(28):
        queries={}
        for k in range(1,33):
            contexts=96*(33-k)+32*sum(n>=k for n in(16,17,18,19));n=contexts*16*k
            queries[str(k)]=dict(query=k-1,key_count=k,shape=[1,16,k],contexts=contexts,k1_bypass=k==1,reciprocal_observations=0,
                raw_valid=stats(n,-.5,.5),centered=stats(n,0.,0.)if k==1 else stats(n,-.5,.5))
        rows[f'{layer}.softmax.centered']['nonpositive']=sum(q['centered']['nonpositive']for q in queries.values())
        scores[str(layer)]=queries
    return dict(contexts=3200,ranges=rows,score_rows=scores,reciprocal_inputs_observed=False,scope='synthetic source-only fixtures')

def fixture():
    sources={'observer.py':s.digest(b'# synthetic observer\n')};buf=io.BytesIO()
    with tarfile.open(fileobj=buf,mode='w:gz')as t:
        n=tarfile.TarInfo('observer.py');n.size=len(b'# synthetic observer\n');t.addfile(n,io.BytesIO(b'# synthetic observer\n'))
    manifest=s.canonical(sources);archive=buf.getvalue();native=family();exact=family()
    union=copy.deepcopy(native['ranges'])
    for row in union.values():row['count']*=2;row['nonpositive']*=2
    ranges=dict(native=native,exact=exact,native_exact_union=union,baseline_generator_separate_diagnostic={'never_selected':{'minimum':-1e200,'maximum':1e200}},initial_bounds_include_baseline=False)
    common=dict(passed=True,complete=True,cleanup_completed=True,signal_restoration_completed=True,
        terminal_after_body_cleanup_and_signal_restoration_attempts=True,acceptance_requires_independent_exit0_reap_and_exact_report_hash=True,
        source_files_unchanged=True,source_hashes_start=sources,source_hashes_end=sources,source_manifest_sha256=s.digest(manifest),audit_denials=[],coefficient_selection=False)
    worker=dict(common,initial_selection_admissible=True,model_forward=True,calibration_reauthenticated=True,private_directory_handle_closed=True,
        private_outputs_retained=True,external_inputs_never_removed=True,exact_order=True,tokenizer_execution=False,validation_inputs_read=False,
        coefficient_selection_performed=False,encrypted_execution=False,baseline_ranges_in_initial_selection=False,contains_tokens_or_logits=False,
        expected_entries=3200,retained_entries=3200,semantic_passes=3200,baseline_complete=64,original416_members=416,new_protocol_candidates_used=0,new_candidates_evaluated=0,
        schema='qwen-expanded-initial-observer-ledger-v1',baseline_manifest_sha256=s.BASELINE_SHA256,baseline_role='initial_free_trace_generator_only',
        by_kind={kind:dict(expected=n,records=n,observed=n,complete=n,invalid=0,unmeasured=0,semantic_failures=0)for kind,n in(('prefill',3072),('teacher',64),('free',64))},
        prefills_by_length={str(i):96 for i in range(1,33)},hook_invariance_by_length={str(i):True for i in range(1,33)},exact_invariance_by_length={str(i):True for i in range(1,33)},input_ranges=ranges)
    parent=dict(common,actual_observer_stage=True,child_reaped=True,child_group_absent=True,model_forward=False,child_returncode=0,
        source_archive={'sha256':s.digest(archive)})
    review=dict(schema='qwen-initial3200-root-review-contract-v1',passed=True,source_archive_sha256=s.digest(archive),source_manifest_sha256=s.digest(manifest),
        outer_exit_code=0,outer_reaped=True,outer_group_absent=True,worker_exit_code=0,worker_reaped=True,worker_group_absent=True,exact_ordered_contexts=3200,
        per_context_norm_input_sites=113,per_context_silu_sites=28,per_context_causal_score_sites=28,baseline_free_contexts=64,baseline_excluded=True,
        per_context_coverage_independently_verified=True,aggregate_ranges_independently_recomputed=True,source_inventory_independently_verified=True)
    return parent,worker,review,archive,manifest

def encode(data):
    parent,worker,review,archive,manifest=data
    wb=s.canonical(worker);parent['worker']=worker;parent['worker_report_sha256']=s.digest(wb);pb=s.canonical(parent)
    review['parent_report_sha256']=s.digest(pb);review['worker_report_sha256']=s.digest(wb);rb=s.canonical(review)
    return (pb,wb,archive,rb),a.ProofPins(s.digest(pb),s.digest(wb),s.digest(archive),s.digest(rb),manifest)

def admit(data):
    blobs,pins=encode(data);return a.authenticate_synthetic(*blobs,pins=pins)

def test_full_synthetic_initial_admission_and_baseline_exclusion():
    data=fixture();value=admit(data);union=json.loads(value.union_bytes)
    assert len(union)==197 and union['final.inverse_sqrt']['minimum']==1.
    data[1]['input_ranges']['baseline_generator_separate_diagnostic']={'arbitrary_excluded':True}
    assert admit(data).union_bytes==value.union_bytes

@pytest.mark.parametrize('field,value',[('passed',False),('complete',False),('cleanup_completed',False),('signal_restoration_completed',False),('child_returncode',1),('child_returncode',False),('child_reaped',False),('child_group_absent',False),('actual_observer_stage',False),('coefficient_selection',True)])
def test_parent_failure_rejected_even_with_rehashed_root(field,value):
    d=fixture();d[0][field]=value
    with pytest.raises(ValueError):admit(d)

@pytest.mark.parametrize('field,value',[('initial_selection_admissible',False),('retained_entries',3199),('exact_order',False),('semantic_passes',3199),('baseline_complete',63),('baseline_ranges_in_initial_selection',True),('validation_inputs_read',True),('coefficient_selection_performed',True),('new_candidates_evaluated',1),('private_directory_handle_closed',False)])
def test_incomplete_or_wrong_phase_worker_rejected(field,value):
    d=fixture();d[1][field]=value
    with pytest.raises(ValueError):admit(d)

@pytest.mark.parametrize('field,value',[('outer_exit_code',1),('outer_reaped',False),('worker_reaped',False),('outer_group_absent',False),('baseline_excluded',False),('exact_ordered_contexts',3199),('per_context_norm_input_sites',112),('aggregate_ranges_independently_recomputed',False),('passed',1)])
def test_external_root_mandatory_terminal_coverage(field,value):
    d=fixture();d[2][field]=value
    with pytest.raises(ValueError):admit(d)

@pytest.mark.parametrize('mutation', ['missing_site','bad_count','nonfinite','nonpositive','missing_K','k1_not_bypass','invented_inverse','union_baseline','partial_kind','invariance','wrong_manifest'])
def test_range_and_workload_mutations(mutation):
    d=fixture();w=d[1];r=w['input_ranges'];v=r['native']['ranges']['0.input.inverse_sqrt']
    if mutation=='missing_site':del r['native']['ranges']['0.q.inverse_sqrt']
    elif mutation=='bad_count':v['count']-=1
    elif mutation=='nonfinite':v['nonfinite']=1
    elif mutation=='nonpositive':v['minimum']=0.;v['nonpositive']=1
    elif mutation=='missing_K':del r['exact']['score_rows']['0']['32']
    elif mutation=='k1_not_bypass':r['native']['score_rows']['0']['1']['k1_bypass']=False
    elif mutation=='invented_inverse':r['native']['score_rows']['0']['1']['reciprocal_observations']=1
    elif mutation=='union_baseline':r['native_exact_union']['0.input.inverse_sqrt']['maximum']=1e200
    elif mutation=='partial_kind':w['by_kind']['free']['complete']=63
    elif mutation=='invariance':w['hook_invariance_by_length']['1']=False
    else:w['baseline_manifest_sha256']='0'*64
    with pytest.raises(ValueError):admit(d)

def test_external_digest_and_reviewed_archive_reject_substitution():
    data=fixture();blobs,pins=encode(data)
    with pytest.raises(ValueError):a.authenticate_synthetic(blobs[0]+b' ',*blobs[1:],pins=pins)
    data=list(data);data[-1]=s.canonical({'substitute.py':s.digest(b'other')})
    with pytest.raises(ValueError):admit(data)

def test_independent_integer_count_derivation():
    # Sum triangular score rows independently of admission.lengths().
    tokens=96*(32*33//2)+2*16*(16+17+18+19)
    score=16*(96*(32*33*34//6)+32*sum(n*(n+1)//2 for n in(16,17,18,19)))
    assert tokens==52928 and score==9524224
    c=a.expected_counts();assert c['0.input.inverse_sqrt']==tokens and c['0.q.inverse_sqrt']==16*tokens and c['0.k.inverse_sqrt']==8*tokens
    assert c['final.inverse_sqrt']==3200 and c['0.silu']==3072*tokens==162594816 and c['0.softmax.centered']==score

@pytest.mark.parametrize('lo,hi',[(1.,1.),(1e-6,2e-6),(1.,7.),(3.7,21.9)])
def test_binary64_domain_policy(lo,hi):
    actual=s.uniform_domain(lo,hi);base=[max(1e-6,.8*lo),1.2*hi]
    assert actual==dict(base_domain=base,domain=[max(1e-6,base[0]/4),base[1]*4])

@pytest.mark.parametrize('lo,hi',[(0.,1.),(True,1.),(1,2.),(float('nan'),1.),(1.,float('inf')),(1.,float.fromhex('0x1.fffffffffffffp+1023'))])
def test_invalid_domain_fails(lo,hi):
    with pytest.raises(ValueError):s.uniform_domain(lo,hi)

def test_real_small_interval_first_ladder_certificate():
    x=s.select_interval([1.,1.01]);assert x['rule']['degree']==16 and len(x['attempts'])==1
    assert x['certificate']['certified']and x['binary64_diagnostic']['passed']

def test_new_fallback_uses_new_domain_minimal_frozen_certificate(monkeypatch):
    monkeypatch.setattr(s.certificate,'certify',lambda c:dict(certified=False))
    x=s.select_interval([1.,64.]);y=s.newton_fallback([1.,4.])
    assert [v['degree']for v in x['attempts']]==list(s.LADDER)and not any(v['selected']for v in x['attempts'])
    assert x['rule']['iterations']>y[0]['iterations']and x['rule']['domain']==[1.,64.]
    assert x['certificate']['verified']and x['binary64_diagnostic']['passed']
    assert x['rule']==dict(kind='inverse_sqrt',method='newton',**numeric.rsqrt_contract([1.,64.],1e-6))

def test_full113_synthetic_policy_protected_bytes_and_counts():
    data=fixture();base=(HERE/'inputs/candidate3_manifest.json').read_bytes();bounds=json.loads((HERE/'inputs/norm_multipliers.json').read_bytes())
    result=s.select_synthetic_initial(base,admit(data),bounds)
    assert result['passed']and result['actual_coefficient_selection']is False and len(result['assessments'])==113
    assert s.canonical(s.protected(result['candidate']))==s.canonical(s.protected(json.loads(base)))
    assert all(v['domain']==[.2,4.848]for v in result['assessments'].values())
    candidate=result['candidate'];assert 'unchanged_norms_sha256'not in candidate and 'source_input_sha256'not in candidate and 'selection_protocol_sha256'not in candidate
    assert set(candidate['depth_by_sequence'])==set(map(str,range(1,33)))
    assert candidate['depth_by_sequence']['32']==select_rules.depths(candidate,32)

def test_protected_radius_failure_is_unsupported_no_retarget(monkeypatch):
    candidate=s.select_interval([1.,1.01]);monkeypatch.setattr(s,'select_interval',lambda d:copy.deepcopy(candidate))
    base=(HERE/'inputs/candidate3_manifest.json').read_bytes();bounds=json.loads((HERE/'inputs/norm_multipliers.json').read_bytes());bounds['0']['native_gate_upper']=1e10
    result=s.select_synthetic_initial(base,admit(fixture()),bounds)
    assert not result['passed']and not result['protected_checks']['0']['radius_covered']
    assert s.protected(result['candidate'])==s.protected(json.loads(base))

def test_copied_newton_certificate_definitions_exact():
    original=ast.parse((HERE/'origins/assess.py.txt').read_text());copied=ast.parse((HERE/'newton_certificate.py').read_text())
    for name in('outward','check_certificate'):
        get=lambda tree:ast.dump(next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name==name),include_attributes=False)
        assert get(original)==get(copied)

def test_actual_paths_disabled_and_inputs_immutable():
    assert json.loads((HERE/'execution_authorization.json').read_bytes())=={'actual_coefficient_selection':False,'actual_observer_admission':False}
    with pytest.raises(RuntimeError):s.actual_selection()
    with pytest.raises(RuntimeError):a.admit_actual()
    origins=json.loads((HERE/'source_origins.json').read_bytes())
    for n,row in origins.items():assert s.digest((HERE/n).read_bytes())==row['sha256']
    assert s.digest((HERE/'inputs/candidate3_manifest.json').read_bytes())==s.BASELINE_SHA256

@pytest.mark.parametrize('stage',['generation','certificate','newton'])
def test_unsupported_attempts_are_retained(monkeypatch,stage):
    def fail(*args,**kwargs):raise ValueError('synthetic failure')
    if stage=='generation':monkeypatch.setattr(s.select_rules,'rule',fail)
    elif stage=='certificate':monkeypatch.setattr(s.certificate,'certify',fail)
    else:
        monkeypatch.setattr(s.certificate,'certify',lambda c:dict(certified=False))
        monkeypatch.setattr(s,'newton_fallback',fail)
    with pytest.raises(s.SelectionFailure)as e:s.select_interval([1.,1.01])
    assert e.value.attempts[-1]['unsupported']is True
    assert len(e.value.attempts)==(7 if stage=='newton'else 1)


def test_per_K_flat_range_substitution_rejected():
    d=fixture();d[1]['input_ranges']['native']['score_rows']['0']['2']['centered']['maximum']=7.
    with pytest.raises(ValueError,match='per-K'):admit(d)


def test_frozen23_protocol_and_policy_match():
    proof=json.loads((HERE/'inputs/protocol_report.json').read_bytes())
    with tarfile.open(HERE/'inputs/protocol_sources.tar.gz')as t:
        members=t.getmembers();raw={m.name:t.extractfile(m).read()for m in members}
    assert len(raw)==23
    expected=proof['source_hashes_before']
    assert {n:s.digest(b)for n,b in raw.items()}==expected==proof['source_hashes_after']
    tree=ast.parse(raw['protocol.py']);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='uniform_domain')
    namespace={'math':math};exec(compile(ast.Module(body=[fn],type_ignores=[]),'frozen_protocol.py','exec'),namespace)
    for lo,hi in((1e-6,1e-6),(.01,.5),(1.,1.01),(23.25,112.25)):
        assert s.uniform_domain(lo,hi)['domain']==namespace['uniform_domain'](lo,hi,1e-6)
    plan=json.loads((HERE/'inputs/expanded_protocol.json').read_bytes())
    assert plan['selection']['degree_ladder']==list(s.LADDER)and plan['selection']['uniform_relative_target']==s.TARGET
    assert plan['calibration']['contexts']==3200 and plan['old_candidate_manifest_sha256']==s.BASELINE_SHA256


def test_newton_previous_count_does_not_meet_certificate():
    from decimal import Decimal,localcontext,ROUND_CEILING,ROUND_FLOOR
    rule,cert,grid=s.newton_fallback([1.,64.]);bound=rule['first_exact_residual_abs_bound']
    with localcontext()as ctx:
        ctx.prec=200;ctx.rounding=ROUND_CEILING
        r=Decimal(bound['numerator'])/Decimal(bound['denominator'])
        for _ in range(rule['iterations']-2):r=r*r*(3+r)/4
    with localcontext()as ctx:
        ctx.prec=200;ctx.rounding=ROUND_FLOOR;den=1+(1-r).sqrt().next_minus()
    with localcontext()as ctx:
        ctx.prec=200;ctx.rounding=ROUND_CEILING;previous=r/den
    assert rule['iterations']>1 and previous>Decimal('1e-6')


def test_late_domain_overflow_retains_prior_site_assessments(monkeypatch):
    prior=s.select_interval([1.,1.01]);monkeypatch.setattr(s,'select_interval',lambda d:copy.deepcopy(prior))
    data=fixture();label=s.NORMS[1];huge=float.fromhex('0x1.fffffffffffffp+1023')
    for family_name in('native','exact'):data[1]['input_ranges'][family_name]['ranges'][label]['maximum']=huge
    data[1]['input_ranges']['native_exact_union'][label]['maximum']=huge
    base=(HERE/'inputs/candidate3_manifest.json').read_bytes();bounds=json.loads((HERE/'inputs/norm_multipliers.json').read_bytes())
    with pytest.raises(s.SelectionFailure)as failure:s.select_synthetic_initial(base,admit(data),bounds)
    assert failure.value.stage=='domain'and failure.value.site==label
    assert list(failure.value.completed_assessments)==[s.NORMS[0]]and failure.value.attempts==()
