"""Granted initial-only selection, with public authentication before snapshot IO."""
import hashlib
import io
import os
from pathlib import Path
import stat
import sys
import tarfile
import time
from cleanup_origin import cleanup_origin, protect_body, choose
from freeze_io import Output, read, parse, finish, json_bytes
from selection_signals import signals
from initial_proof import (ProofPins, authenticate_initial, authenticate_snapshot,
                           SOURCE_MANIFEST_SHA256, digest, canonical, MAX_SNAPSHOT)
from selection_grant import authenticate_grant
from selection_contract import select_actual
from selector import SelectionFailure


def disjoint(path, protected):
    path = Path(path).resolve()
    for item in protected:
        other = Path(item).resolve()
        if path == other or path in other.parents or other in path.parents:
            raise ValueError('Owned selection output overlaps a protected source/evidence/private tree')


def source_end(root, expected):
    actual = {}
    for path in root.rglob('*'):
        if path.is_symlink():
            raise ValueError('Symlink in selector source closure')
        if path.is_file():
            name = path.relative_to(root).as_posix()
            if name not in expected:
                raise ValueError('Unexpected selector source/cache file')
            actual[name] = digest(read(path, expected[name], 16 << 20))
        elif not path.is_dir():
            raise ValueError('Nonregular selector source member')
        elif not any(n.startswith(path.relative_to(root).as_posix() + '/') for n in expected):
            raise ValueError('Unexpected selector source directory')
    if actual != expected:
        raise ValueError('Selector source inventory changed')
    return actual


def loaded_origins(root, expected):
    names = {Path(n).stem:n for n in expected if n.endswith('.py') and '/' not in n}
    result = {}
    for name,module in tuple(sys.modules.items()):
        if name.split('.')[0] in ('torch','transformers','safetensors','tokenizers','jax','jaxlib','tensorflow','flax','torch_xla'):
            raise ValueError('Forbidden model/backend module loaded')
        values = (getattr(module,'__file__',None),getattr(getattr(module,'__spec__',None),'origin',None))
        local = []
        for value in values:
            if isinstance(value,(str,os.PathLike)) and value not in ('built-in','frozen'):
                path = Path(value).resolve()
                if path == root or root in path.parents:
                    local.append(path)
        if name in names or local:
            wanted = root / ('entry.py' if name == '__main__' else names.get(name,'__unknown__'))
            if not local or any(path != wanted for path in local):
                raise ValueError('Loaded selector module origin differs')
            if name != '__main__' and (len(local) != 2 or values[0] is None or values[1] is None):
                raise ValueError('Both loaded selector origins required')
            result[name] = dict(path=wanted.relative_to(root).as_posix(),sha256=expected[wanted.relative_to(root).as_posix()])
    return result


def snapshot_read(description):
    """One held private directory and one bounded FD; no token/journal reads."""
    path = Path(description['path'])
    parent_fd = os.open(path.parent, os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
    primary = None
    try:
        parent = os.fstat(parent_fd)
        if ([parent.st_dev,parent.st_ino] != description['parent_identity'] or
                stat.S_IMODE(parent.st_mode) != 0o700 or parent.st_uid != os.getuid()):
            raise ValueError('Private reconstruction directory identity/permissions differ')
        fd = os.open(path.name, os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC, dir_fd=parent_fd)
        inner = None
        try:
            before = os.fstat(fd)
            if (not stat.S_ISREG(before.st_mode) or stat.S_IMODE(before.st_mode) != 0o600 or
                    before.st_uid != os.getuid() or [before.st_dev,before.st_ino] != description['identity'] or
                    before.st_size != description['bytes'] or not 0 < before.st_size <= MAX_SNAPSHOT):
                raise ValueError('Private snapshot identity/permissions/size differ')
            parts = []; remaining = before.st_size + 1
            while remaining:
                block = os.read(fd,min(remaining,1<<20))
                if not block:break
                parts.append(block);remaining -= len(block)
            raw = b''.join(parts)
            after = os.fstat(fd); named = os.stat(path.name,dir_fd=parent_fd,follow_symlinks=False)
            fields = lambda row:(row.st_dev,row.st_ino,row.st_size,row.st_mtime_ns,row.st_ctime_ns)
            current_parent = os.stat(path.parent,follow_symlinks=False)
            if (fields(before) != fields(after) or fields(before) != fields(named) or
                    [current_parent.st_dev,current_parent.st_ino] != description['parent_identity'] or
                    len(raw) != description['bytes'] or digest(raw) != description['sha256']):
                raise ValueError('Private snapshot changed during authenticated read')
            return raw
        except BaseException as error:
            inner = protect_body(error) if not cleanup_origin(error) else error
            raise
        finally:
            finish(inner,lambda:os.close(fd))
    except BaseException as error:
        primary = protect_body(error) if not cleanup_origin(error) else error
        raise
    finally:
        finish(primary,lambda:os.close(parent_fd))


def _archive(blobs):
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer,mode='w:gz') as archive:
        for name,raw in sorted(blobs.items()):
            member=tarfile.TarInfo(name);member.size=len(raw);member.mode=0o600
            archive.addfile(member,io.BytesIO(raw))
    return buffer.getvalue()


def run(args, manifest_bytes, expected, blobs, origins, root):
    """Called only through authenticated -I -B entry; no retained workspace writes."""
    start=time.monotonic();root=Path(root).resolve()
    if not args.execute:
        raise PermissionError('Explicit execution required')
    if digest(manifest_bytes) != args.manifest_sha256 or parse(manifest_bytes) != expected:
        raise ValueError('Entry source manifest binding differs')
    source_end(root,expected)
    grant_raw=read(args.grant,args.grant_sha256,1<<20)
    authorization=authenticate_grant(grant_raw,args.grant_sha256,
        source_manifest_sha256=args.manifest_sha256,output_directory=os.path.abspath(args.output))
    descriptors=parse(authorization.evidence_bytes)
    public={name:read(row['path'],row['sha256'],row['bytes']) for name,row in descriptors.items()}
    if any(len(public[name]) != row['bytes'] for name,row in descriptors.items()):
        raise ValueError('Public initial evidence size differs')
    pins=ProofPins(descriptors['parent']['sha256'],descriptors['worker']['sha256'],
        descriptors['source_archive']['sha256'],descriptors['root_review']['sha256'],
        blobs['inputs/observer_sources.json'],descriptors['reconstruction_script']['sha256'])
    binding=authenticate_initial(public['parent'],public['worker'],public['source_archive'],public['root_review'],pins=pins)
    snapshot_description=parse(binding.snapshot_descriptor_bytes)
    private=parse(binding.private_output_bytes)
    protected=[root,Path(args.manifest).resolve().parent,Path(args.grant).resolve().parent,
        private['path'],Path(snapshot_description['path']).parent]
    protected.extend(Path(row['path']).parent for row in descriptors.values())
    disjoint(args.output,protected)
    output=None; report=None; primary=body=None; state={}; owned_identity=None
    try:
        with signals(state):
            try:
                output=Output(args.output);owned_identity=output.owner
                report=dict(schema='qwen-expanded-initial-selection-report-v1',passed=False,complete=False,
                    pid=os.getpid(),source_hashes_start=expected,source_manifest_sha256=args.manifest_sha256,
                    grant_sha256=args.grant_sha256,initial_parent_report_sha256=binding.parent_report_sha256,
                    initial_worker_report_sha256=binding.worker_report_sha256,initial_root_review_sha256=binding.root_review_sha256,
                    reconstruction_script_sha256=binding.reconstruction_script_sha256,
                    initial_snapshot_sha256=snapshot_description['sha256'],calibration_sha256=binding.calibration_sha256,
                    model_pins_sha256=digest(binding.model_pins_bytes),protocol_sha256=binding.protocol_sha256,
                    candidate_ordinal=1,model_execution=False,token_or_calibration_body_reads=False,
                    validation_body_reads=False,encrypted_execution=False,synthetic_only=False,
                    actual_coefficient_selection=False,publication_complete=False,private_inputs_never_removed=True,
                    preflight_report_sha256=authorization.preflight_report_sha256,
                    independent_preflight_review_sha256=authorization.independent_preflight_review_sha256,
                    source_archive=output.write('sources.tar.gz',_archive(blobs)))
                output.write('source_manifest.json',manifest_bytes)
                snapshot_raw=snapshot_read(snapshot_description)
                admitted=authenticate_snapshot(snapshot_raw,binding)
                result=select_actual(blobs['inputs/candidate3_manifest.json'],admitted,
                    blobs['inputs/norm_multipliers.json'],authorization=authorization)
                report['actual_coefficient_selection']=True
                report['candidate_supported']=result['passed']
                report['input_bindings']=result['input_bindings']
                files={}
                for name,value in (('candidate_manifest.json',result['candidate']),('assessments.json',result['assessments']),
                                   ('protected_checks.json',result['protected_checks'])):
                    raw=json_bytes(value);files[name]=output.write(name,raw)
                    if read(Path(args.output)/name,files[name]['sha256'],len(raw)) != raw:
                        raise ValueError('Published selection readback differs')
                report.update(outputs=files,publication_complete=True,complete=True,passed=result['passed'],
                    all_norm_sites_supported=result['candidate']['all_norm_sites_supported'],
                    protected_rules_supported=result['candidate']['protected_rules_supported'])
                if snapshot_read(snapshot_description) != snapshot_raw:
                    raise ValueError('Initial snapshot changed after selection')
            except BaseException as error:
                primary=error;body=None if cleanup_origin(error) else protect_body(error)
                if report is not None:
                    report.update(passed=False,error_type=type(error).__name__)
                    if isinstance(error,SelectionFailure):
                        report['unsupported_stage']=error.stage
                        report['unsupported_site']=getattr(error,'site',None)
                        if output is not None:
                            try:report['failure_assessments']=output.json('failure_assessments.json',dict(
                                attempts=error.attempts,completed_assessments=getattr(error,'completed_assessments',{})))
                            except BaseException as later:primary=choose(primary,later,'failure history publication',body_primary=body)
            finally:
                with signals({},shield=True):
                    checks=[('source final check',lambda:source_end(root,expected)),
                            ('loaded source origins',lambda:loaded_origins(root,expected)),
                            ('grant recheck',lambda:read(args.grant,args.grant_sha256,1<<20))]
                    checks.extend(('public evidence recheck',lambda row=row:read(row['path'],row['sha256'],row['bytes'])) for row in descriptors.values())
                    for label,action in checks:
                        try:
                            value=action()
                            if report is not None and label=='source final check':report.update(source_hashes_end=value,source_files_unchanged=True)
                            if report is not None and label=='loaded source origins':report['loaded_local_origins']=value
                        except BaseException as error:primary=choose(primary,error,label,body_primary=body)
                    if output is not None:
                        try:output.close(primary)
                        except BaseException as error:primary=choose(primary,error,'owned output close',body_primary=body)
            if primary is not None:raise primary
    except BaseException as error:
        primary=choose(primary,error,'outer terminal scope',body_primary=body)
    if report is None:
        if primary is not None:raise primary
        raise RuntimeError('Selection body did not produce a report')
    report.update(elapsed_s=time.monotonic()-start,cleanup_completed=primary is None,
        signal_restoration_completed=state.get('restored',False),
        terminal_after_body_cleanup_and_signal_restoration_attempts=True,
        acceptance_requires_independent_exit0_reap_and_exact_report_hash=True)
    if primary is not None or state.get('restored') is not True:
        report.update(passed=False,error_type=type(primary).__name__ if primary is not None else 'SignalRestorationFailure')
    publication=None
    try:
        publication=Output.reopen(args.output,owned_identity)
        publication.json('report.json',report)
    except BaseException as error:primary=choose(primary,error,'final report publication',body_primary=body)
    finally:
        if publication is not None:
            try:publication.close(primary)
            except BaseException as error:primary=choose(primary,error,'final publication close',body_primary=body)
    if primary is not None:raise primary
    return 0 if report['passed'] else 1
