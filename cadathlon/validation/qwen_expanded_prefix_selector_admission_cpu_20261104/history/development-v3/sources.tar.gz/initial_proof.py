"""Pure terminal observer authentication. No filesystem access or launch authority.

External report/root/script hashes must come from a reviewed caller. A constructed
Pins or binding is data, never an authorization capability. Snapshot body access
and coefficient selection still require a separately reviewed, granted process.
"""
from dataclasses import dataclass
import io
import json
import re
import tarfile
from pathlib import PurePosixPath

from admission import parse, exact_int, require_flags
from initial_ranges import range_union
from selector import BASELINE_SHA256, canonical, digest

SOURCE_MANIFEST_SHA256 = '8131c5ac045f1cf274a493bbc14278e330c0a8e057079edc4f10f9a23dd9bf91'
GATE_BOUNDS_SHA256 = '761a07e232e0bba981ba014eb6d202cce96a9471616743594fecdc6a57d67840'
PROTOCOL_SHA256 = 'eea8e4b38b4c2719e63a0aa13028150564901305e9e5f1f9d0f2985c821cb70f'
RECONSTRUCTION_SCRIPT_SHA256 = '3690b5710a8f019f529062303289d415fad99d85bb579ff426e66ec9633ff2e3'
ROOT_SCHEMA = 'qwen-initial3200-root-review-contract-v2'
SNAPSHOT_SCHEMA = 'qwen-initial3200-reconstructed-snapshot-v1'
ACTUAL_ACTIVATION = False
MAX_REPORT = 32 << 20
MAX_SNAPSHOT = 32 << 20
ARCHITECTURE = dict(num_hidden_layers=28, hidden_size=1024, intermediate_size=3072,
                    num_attention_heads=16, num_key_value_heads=8, head_dim=128, vocab_size=151936)
BACKEND_ENVIRONMENT = dict(USE_TF='0', USE_FLAX='0', USE_TORCH='1',
                           USE_TORCH_XLA='0', FORCE_TF_AVAILABLE='0')


@dataclass(frozen=True, slots=True)
class ProofPins:
    parent_sha256: str
    worker_sha256: str
    archive_sha256: str
    root_sha256: str
    source_manifest_bytes: bytes
    reconstruction_script_sha256: str
    root_outer_sha256: str


@dataclass(frozen=True, slots=True)
class InitialProofBinding:
    parent_report_sha256: str
    worker_report_sha256: str
    source_archive_sha256: str
    source_manifest_sha256: str
    source_manifest_bytes: bytes
    root_review_sha256: str
    reconstruction_script_sha256: str
    root_outer_sha256: str
    calibration_sha256: str
    model_pins_bytes: bytes
    protocol_sha256: str
    baseline_manifest_sha256: str
    snapshot_descriptor_bytes: bytes
    private_inventory_sha256: str
    worker_ranges_bytes: bytes
    private_ranges_descriptor_bytes: bytes
    private_output_bytes: bytes
    protected_paths_bytes: bytes
    proof_sha256: str
    execution_authorized: bool = False


@dataclass(frozen=True, slots=True)
class InitialSnapshot:
    binding: InitialProofBinding
    snapshot_sha256: str
    union_bytes: bytes
    ledger_sha256: str
    private_inventory_sha256: str
    execution_authorized: bool = False


def hash_string(value):
    return type(value) is str and re.fullmatch('[0-9a-f]{64}', value) is not None


def same(left, right):
    return canonical(left) == canonical(right)


def inventory_bytes(value):
    """Exact producer/root JSON encoding for the inventory digest."""
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def bounded(raw, limit, expected=None):
    if type(raw) is not bytes or not 0 < len(raw) <= limit:
        raise ValueError('Bounded immutable proof bytes required')
    if expected is not None and (not hash_string(expected) or digest(raw) != expected):
        raise ValueError('External proof digest differs')
    return raw


def identity(value):
    if (type(value) is not list or len(value) != 2 or
            any(type(n) is not int or n < 0 for n in value) or value[1] == 0):
        raise ValueError('Typed device/inode identity required')


def absolute_path(value):
    if type(value) is not str or not value or '\x00' in value:
        raise ValueError('Absolute canonical descriptor path required')
    path = PurePosixPath(value)
    if not path.is_absolute() or '..' in path.parts or path.as_posix() != value:
        raise ValueError('Absolute canonical descriptor path required')
    return path


def snapshot_descriptor(row):
    if type(row) is not dict or set(row) != {'path', 'sha256', 'bytes', 'identity', 'parent_identity'}:
        raise ValueError('Exact immutable snapshot descriptor required')
    absolute_path(row['path'])
    if not hash_string(row['sha256']) or type(row['bytes']) is not int or not 0 < row['bytes'] <= MAX_SNAPSHOT:
        raise ValueError('Bounded snapshot digest required')
    identity(row['identity']); identity(row['parent_identity'])


def archive_sources(raw, manifest_bytes):
    bounded(manifest_bytes, 1 << 20, SOURCE_MANIFEST_SHA256)
    sources = parse(manifest_bytes)
    if type(sources) is not dict or len(sources) != 61:
        raise ValueError('Exact reviewed61 source inventory required')
    for name, value in sources.items():
        path = PurePosixPath(name)
        if (type(name) is not str or path.is_absolute() or '..' in path.parts or
                path.as_posix() != name or not hash_string(value)):
            raise ValueError('Invalid reviewed producer source entry')
    bounded(raw, 32 << 20)
    found = {}; total = 0
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        for member in archive:
            total += member.size
            if (member.name not in sources or member.name in found or not member.isfile() or
                    not 0 <= member.size <= 16 << 20 or total > 32 << 20):
                raise ValueError('Producer archive member differs')
            found[member.name] = archive.extractfile(member).read()
    if {name: digest(data) for name, data in found.items()} != sources:
        raise ValueError('Archive differs from independently pinned61 sources')
    return sources, found


def _completed_worker(worker):
    require_flags(worker, true=(
        'initial_selection_admissible', 'model_forward', 'model_loaded', 'model_loading_exact',
        'model_execution_requested', 'calibration_reauthenticated', 'private_directory_handle_closed',
        'private_outputs_retained', 'external_inputs_never_removed', 'exact_order'), false=(
        'tokenizer_execution', 'validation_inputs_read', 'coefficient_selection_performed',
        'encrypted_execution', 'baseline_ranges_in_initial_selection', 'contains_tokens_or_logits'))
    counts = dict(expected_entries=3200, retained_entries=3200, semantic_passes=3200,
                  baseline_complete=64, original416_members=416, new_protocol_candidates_used=0,
                  new_candidates_evaluated=0, native_forward_started=3232, native_forward_completed=3232)
    if any(not exact_int(worker.get(k), n) for k, n in counts.items()):
        raise ValueError('Complete initial3200/native3232 accounting required')
    if (worker.get('schema') != 'qwen-expanded-initial-observer-ledger-v1' or
            worker.get('baseline_manifest_sha256') != BASELINE_SHA256 or
            worker.get('baseline_role') != 'initial_free_trace_generator_only' or
            worker.get('native_dtype') != 'float32' or worker.get('exact_dtype') != 'float64'):
        raise ValueError('Frozen initial native/exact and baseline policy differs')
    by_kind = worker.get('by_kind', {})
    if type(by_kind) is not dict or set(by_kind) != {'prefill', 'teacher', 'free'}:
        raise ValueError('Exact initial workload kinds required')
    for kind, n in (('prefill', 3072), ('teacher', 64), ('free', 64)):
        wanted = dict(expected=n, records=n, observed=n, complete=n, invalid=0,
                      unmeasured=0, semantic_failures=0)
        if not same(by_kind[kind], wanted):
            raise ValueError('Partial initial workload forbidden')
    keys = set(map(str, range(1, 33)))
    for field in ('hook_invariance_by_length', 'exact_invariance_by_length'):
        rows = worker.get(field)
        if type(rows) is not dict or set(rows) != keys or any(v is not True for v in rows.values()):
            raise ValueError('All32 lengths require native/exact invariance')
    rows = worker.get('prefills_by_length')
    if type(rows) is not dict or set(rows) != keys or any(not exact_int(v, 96) for v in rows.values()):
        raise ValueError('All32 lengths require96 prefills')


def authenticate_initial(parent_bytes, worker_bytes, archive_bytes, root_bytes, *, pins, root_outer_bytes):
    """Authenticate public bytes only; never read the private snapshot or launch."""
    if type(pins) is not ProofPins or pins.reconstruction_script_sha256 != RECONSTRUCTION_SCRIPT_SHA256:
        raise ValueError('Externally reviewed immutable pin bundle required')
    for raw, pin, limit in ((parent_bytes, pins.parent_sha256, MAX_REPORT),
                            (worker_bytes, pins.worker_sha256, MAX_REPORT),
                            (archive_bytes, pins.archive_sha256, 32 << 20),
                            (root_bytes, pins.root_sha256, 2 << 20),
                            (root_outer_bytes, pins.root_outer_sha256, 1 << 20)):
        bounded(raw, limit, pin)
    sources, blobs = archive_sources(archive_bytes, pins.source_manifest_bytes)
    parent, worker, review = map(parse, (parent_bytes, worker_bytes, root_bytes))
    outer = parse(root_outer_bytes)
    outer_required = dict(schema='qwen-initial3200-root-reconstruction-terminal-v1',
        exit_code=0, reaped=True, process_group_absent=True, review_sha256=pins.root_sha256,
        script_sha256=pins.reconstruction_script_sha256)
    if not same(outer, outer_required):
        raise ValueError('Independent root reconstruction exit0/reap receipt required')
    common = ('passed', 'complete', 'cleanup_completed', 'signal_restoration_completed',
              'terminal_after_body_cleanup_and_signal_restoration_attempts',
              'acceptance_requires_independent_exit0_reap_and_exact_report_hash', 'source_files_unchanged')
    for report in (parent, worker):
        require_flags(report, true=common, false=('coefficient_selection',))
        if (not same(report.get('source_hashes_start'), sources) or
                not same(report.get('source_hashes_end'), sources) or
                report.get('source_manifest_sha256') != SOURCE_MANIFEST_SHA256 or
                report.get('audit_denials') != [] or 'error_type' in report):
            raise ValueError('Producer failure/source binding differs')
    require_flags(parent, true=('actual_observer_stage', 'child_reaped', 'child_group_absent'),
                  false=('model_forward',))
    if (not exact_int(parent.get('child_returncode'), 0) or
            parent.get('worker_report_sha256') != pins.worker_sha256 or
            not same(parent.get('worker'), worker) or
            parent.get('source_archive', {}).get('sha256') != pins.archive_sha256):
        raise ValueError('Parent/worker/archive terminal binding differs')
    _completed_worker(worker)
    external = parse(blobs['external_inputs.json'])
    calibration = external['calibration']['sha256']
    model = parse(blobs['public/model_pins.json'])
    assets = {name: model['asset_sha256'][name] for name in external['model_assets']}
    dependencies = parse(blobs['dependencies.json'])
    backend = {name: row['sha256'] for name, row in parse(blobs['backend_sources.json']).items()}
    if (worker.get('calibration_sha256') != calibration or not same(worker.get('model_asset_sha256'), assets) or
            not same(worker.get('architecture'), ARCHITECTURE) or
            not same(worker.get('backend_environment'), BACKEND_ENVIRONMENT) or
            not same(worker.get('installed_dependencies'), dependencies) or
            not same(worker.get('backend_sources_before'), backend) or
            not same(worker.get('backend_sources_after'), backend) or
            digest(blobs['public/candidate3_manifest.json']) != BASELINE_SHA256 or
            digest(blobs['public/protocol.json']) != PROTOCOL_SHA256):
        raise ValueError('Calibration/model/backend/protocol source binding differs')
    private = worker.get('private_output')
    if type(private) is not dict or set(private) != {'path', 'identity', 'mode'} or private['mode'] != '0700':
        raise ValueError('Producer private output ownership descriptor required')
    absolute_path(private['path']); identity(private['identity'])
    desc = worker.get('private_ranges_descriptor')
    if type(desc) is not dict or set(desc) != {'sha256', 'bytes', 'identity', 'mode'} or desc['mode'] != '0600':
        raise ValueError('Producer private range descriptor required')
    if not hash_string(desc['sha256']) or type(desc['bytes']) is not int or not 0 < desc['bytes'] <= MAX_REPORT:
        raise ValueError('Bounded private range descriptor required')
    identity(desc['identity'])
    range_union(worker['input_ranges'])
    required = dict(schema=ROOT_SCHEMA, passed=True, parent_report_sha256=pins.parent_sha256,
        worker_report_sha256=pins.worker_sha256, source_archive_sha256=pins.archive_sha256,
        source_manifest_sha256=SOURCE_MANIFEST_SHA256, outer_exit_code=0, outer_reaped=True,
        outer_group_absent=True, worker_exit_code=0, worker_reaped=True, worker_group_absent=True,
        exact_ordered_contexts=3200, per_context_norm_input_sites=113, per_context_silu_sites=28,
        per_context_causal_score_sites=28, baseline_free_contexts=64, baseline_excluded=True,
        per_context_coverage_independently_verified=True, aggregate_ranges_independently_recomputed=True,
        source_inventory_independently_verified=True, native_model_loaded=True,
        native_forward_started=3232, native_forward_completed=3232,
        reconstruction_script_sha256=pins.reconstruction_script_sha256, private_files=9666,
        calibration_sha256=calibration, private_journals_immutable_at_review=True)
    extra = {'snapshot_descriptor', 'private_inventory_sha256'}
    if (type(review) is not dict or set(review) != set(required) | extra or
            any(not same(review[k], v) for k, v in required.items()) or
            not hash_string(review['private_inventory_sha256'])):
        raise ValueError('Independent complete initial root/outer proof differs')
    snapshot_descriptor(review['snapshot_descriptor'])
    if review['snapshot_descriptor']['parent_identity'] == private['identity']:
        raise ValueError('Root snapshot must preserve the original journal directory inventory')
    proof = digest(canonical(dict(parent=pins.parent_sha256, worker=pins.worker_sha256,
        archive=pins.archive_sha256, root=pins.root_sha256,
        reconstruction_script=pins.reconstruction_script_sha256, root_outer=pins.root_outer_sha256)))
    return InitialProofBinding(pins.parent_sha256, pins.worker_sha256, pins.archive_sha256,
        SOURCE_MANIFEST_SHA256, pins.source_manifest_bytes, pins.root_sha256,
        pins.reconstruction_script_sha256, pins.root_outer_sha256, calibration, canonical(model), PROTOCOL_SHA256,
        BASELINE_SHA256, canonical(review['snapshot_descriptor']), review['private_inventory_sha256'],
        canonical(worker['input_ranges']), canonical(desc), canonical(private),
        canonical(sorted(set(external['protected_paths'] + [external['model_root'],
            str(PurePosixPath(external['calibration']['path']).parent)]))), proof)


def expected_private_names():
    names = {f'{n:04d}-{phase}.json' for n in range(3200) for phase in ('started', 'native', 'exact')}
    names.update(f'{n:04d}-baseline.json' for n in range(3136, 3200))
    names.update(('initial-ledger.json', 'input-ranges.json'))
    return names


def authenticate_snapshot(snapshot_bytes, binding):
    """Validate caller-held immutable snapshot bytes; never open a private path."""
    if type(binding) is not InitialProofBinding or binding.execution_authorized is not False:
        raise ValueError('Public initial proof binding required')
    descriptor = parse(binding.snapshot_descriptor_bytes)
    snapshot_descriptor(descriptor)
    bounded(snapshot_bytes, MAX_SNAPSHOT, descriptor['sha256'])
    if len(snapshot_bytes) != descriptor['bytes']:
        raise ValueError('Snapshot size differs')
    value = parse(snapshot_bytes)
    required = dict(schema=SNAPSHOT_SCHEMA, parent_report_sha256=binding.parent_report_sha256,
        worker_report_sha256=binding.worker_report_sha256, source_archive_sha256=binding.source_archive_sha256,
        source_manifest_sha256=binding.source_manifest_sha256, calibration_sha256=binding.calibration_sha256)
    if type(value) is not dict or set(value) != set(required) | {'input_ranges', 'ledger_sha256', 'inventory'}:
        raise ValueError('Exact reconstructed snapshot schema required')
    if any(not same(value[k], v) for k, v in required.items()):
        raise ValueError('Reconstructed snapshot producer binding differs')
    inventory = value['inventory']
    if type(inventory) is not dict or set(inventory) != expected_private_names():
        raise ValueError('Exact ordered phase journal inventory required')
    identities = set(); total = 0
    for name, row in inventory.items():
        if type(row) is not dict or set(row) != {'sha256', 'bytes', 'identity'}:
            raise ValueError('Exact private journal descriptor required')
        if not hash_string(row['sha256']) or type(row['bytes']) is not int or not 0 < row['bytes'] <= MAX_REPORT:
            raise ValueError('Bounded private journal digest/size required')
        identity(row['identity']); identities.add(tuple(row['identity'])); total += row['bytes']
    if len(identities) != 9666 or total > 32 << 30:
        raise ValueError('Distinct bounded private journal inventory required')
    if tuple(descriptor['identity']) in identities:
        raise ValueError('Snapshot must not alias a producer journal')
    if digest(inventory_bytes(inventory)) != binding.private_inventory_sha256:
        raise ValueError('Private inventory differs from independent root review')
    if not hash_string(value['ledger_sha256']) or value['ledger_sha256'] != inventory['initial-ledger.json']['sha256']:
        raise ValueError('Ordered private ledger digest differs')
    ranges_desc = parse(binding.private_ranges_descriptor_bytes)
    if not same(inventory['input-ranges.json'], {k: ranges_desc[k] for k in ('sha256', 'bytes', 'identity')}):
        raise ValueError('Original private aggregate descriptor differs')
    if canonical(value['input_ranges']) != binding.worker_ranges_bytes:
        raise ValueError('Reconstructed aggregate differs from producer report')
    union = range_union(value['input_ranges'])
    return InitialSnapshot(binding, digest(snapshot_bytes), canonical(union), value['ledger_sha256'],
                           binding.private_inventory_sha256)


def authenticate_gate_bounds(raw):
    bounded(raw, 4 << 20, GATE_BOUNDS_SHA256)
    return parse(raw)


def activate_actual(*args, **kwargs):
    raise RuntimeError('Actual admission/selection requires separate reviewed preflight and root grant')
