from pathlib import Path
from dataclasses import replace
import copy
import hashlib
import io
import json
import tarfile
import pytest
import initial_proof as p
import selection_grant as g
import selection_contract as c
import selector as s
from test_selector import fixture as old_fixture

HERE = Path(__file__).resolve().parent


def fixture():
    parent, worker, _, _, _ = old_fixture()
    manifest = (HERE/'inputs/observer_sources.json').read_bytes()
    archive = (HERE/'inputs/observer_source_fixture.tar.gz').read_bytes()
    sources, blobs = p.archive_sources(archive, manifest)
    external = p.parse(blobs['external_inputs.json'])
    assets = p.parse(blobs['public/model_pins.json'])['asset_sha256']
    for row in (parent, worker):
        row.update(source_hashes_start=sources, source_hashes_end=sources,
                   source_manifest_sha256=p.digest(manifest))
    worker.update(model_loaded=True, model_loading_exact=True, model_execution_requested=True,
        native_forward_started=3232, native_forward_completed=3232,
        native_dtype='float32', exact_dtype='float64', architecture=p.ARCHITECTURE,
        backend_environment=p.BACKEND_ENVIRONMENT,
        calibration_sha256=external['calibration']['sha256'],
        model_asset_sha256={n:assets[n] for n in external['model_assets']},
        installed_dependencies=p.parse(blobs['dependencies.json']),
        backend_sources_before={n:r['sha256'] for n,r in p.parse(blobs['backend_sources.json']).items()},
        backend_sources_after={n:r['sha256'] for n,r in p.parse(blobs['backend_sources.json']).items()},
        private_output=dict(path='/synthetic/producer-private', identity=[1, 2], mode='0700'))
    ranges = p.inventory_bytes(worker['input_ranges'])
    worker['private_ranges_descriptor'] = dict(sha256=p.digest(ranges), bytes=len(ranges), identity=[1,9999], mode='0600')
    parent['source_archive'] = dict(sha256=p.digest(archive))
    inventory = {name:dict(sha256=p.digest(name.encode()), bytes=len(name), identity=[1,10000+i])
                 for i,name in enumerate(sorted(p.expected_private_names()))}
    inventory['input-ranges.json'] = {k:worker['private_ranges_descriptor'][k] for k in ('sha256','bytes','identity')}
    return parent,worker,archive,manifest,inventory


def encode(data, *, review_change=None, snapshot_change=None):
    parent,worker,archive,manifest,inventory = copy.deepcopy(data)
    wb=p.canonical(worker);parent.update(worker=worker,worker_report_sha256=p.digest(wb));pb=p.canonical(parent)
    snapshot=dict(schema=p.SNAPSHOT_SCHEMA,parent_report_sha256=p.digest(pb),worker_report_sha256=p.digest(wb),
        source_archive_sha256=p.digest(archive),source_manifest_sha256=p.digest(manifest),
        calibration_sha256=worker['calibration_sha256'],input_ranges=worker['input_ranges'],
        ledger_sha256=inventory['initial-ledger.json']['sha256'],inventory=inventory)
    if snapshot_change:snapshot_change(snapshot)
    sb=p.inventory_bytes(snapshot)
    review=dict(schema=p.ROOT_SCHEMA,passed=True,parent_report_sha256=p.digest(pb),worker_report_sha256=p.digest(wb),
        source_archive_sha256=p.digest(archive),source_manifest_sha256=p.digest(manifest),
        outer_exit_code=0,outer_reaped=True,outer_group_absent=True,worker_exit_code=0,worker_reaped=True,
        worker_group_absent=True,exact_ordered_contexts=3200,per_context_norm_input_sites=113,
        per_context_silu_sites=28,per_context_causal_score_sites=28,baseline_free_contexts=64,baseline_excluded=True,
        per_context_coverage_independently_verified=True,aggregate_ranges_independently_recomputed=True,
        source_inventory_independently_verified=True,native_model_loaded=True,native_forward_started=3232,
        native_forward_completed=3232,reconstruction_script_sha256=p.RECONSTRUCTION_SCRIPT_SHA256,private_files=9666,
        calibration_sha256=worker['calibration_sha256'],private_journals_immutable_at_review=True,
        private_inventory_sha256=p.digest(p.inventory_bytes(snapshot['inventory'])),
        snapshot_descriptor=dict(path='/synthetic/reconstruction/snapshot.json',sha256=p.digest(sb),bytes=len(sb),
                                 identity=[2,3],parent_identity=[2,2]))
    if review_change:review_change(review)
    rb=p.canonical(review)
    outer=p.canonical(dict(schema='qwen-initial3200-root-reconstruction-terminal-v1',exit_code=0,reaped=True,
        process_group_absent=True,review_sha256=p.digest(rb),script_sha256=p.RECONSTRUCTION_SCRIPT_SHA256))
    pins=p.ProofPins(p.digest(pb),p.digest(wb),p.digest(archive),p.digest(rb),manifest,
                     p.RECONSTRUCTION_SCRIPT_SHA256,p.digest(outer))
    return (pb,wb,archive,rb),pins,sb,outer


def authenticate(data=None, **kwargs):
    args,pins,snapshot,outer=encode(fixture() if data is None else data,**kwargs)
    binding=p.authenticate_initial(*args,pins=pins,root_outer_bytes=outer)
    return p.authenticate_snapshot(snapshot,binding),args,pins,snapshot


def grant(snapshot, source='3'*64, output='/synthetic/selection'):
    b=snapshot.binding
    evidence={n:dict(path='/synthetic/proof/'+n,sha256=pin,bytes=1) for n,pin in
        dict(parent=b.parent_report_sha256,worker=b.worker_report_sha256,source_archive=b.source_archive_sha256,
             root_review=b.root_review_sha256,reconstruction_script=b.reconstruction_script_sha256,
             root_reconstruction_outer_receipt=b.root_outer_sha256).items()}
    return dict(schema='qwen-expanded-initial-selector-grant-v1',ready=True,execute_authorized=True,
        candidate_ordinal=1,source_manifest_sha256=source,observer_source_manifest_sha256=p.SOURCE_MANIFEST_SHA256,
        protected_manifest_sha256=p.BASELINE_SHA256,protocol_sha256=p.PROTOCOL_SHA256,gate_bounds_sha256=p.GATE_BOUNDS_SHA256,
        output_directory=output,model_execution=False,token_or_calibration_body_reads=False,
        validation_body_reads=False,encrypted_execution=False,preflight_report_sha256='4'*64,
        independent_preflight_review_sha256='5'*64,initial_evidence=evidence)


def test_complete61_public_proof_then_snapshot():
    value,args,pins,snapshot=authenticate()
    assert value.execution_authorized is False and value.binding.execution_authorized is False
    assert len(p.parse(value.union_bytes))==197 and len(p.expected_private_names())==9666
    assert value.binding.source_manifest_sha256==p.SOURCE_MANIFEST_SHA256
    assert p.digest(p.inventory_bytes(p.parse(snapshot)['inventory']))==value.private_inventory_sha256
    assert p.digest(p.canonical(p.parse(snapshot)['inventory']))!=value.private_inventory_sha256
    with pytest.raises(Exception):value.union_bytes=b'{}'


@pytest.mark.parametrize('name,value',[
    ('model_loaded',False),('model_loading_exact',False),('native_forward_started',3231),
    ('native_forward_completed',3231),('native_forward_completed',3232.0),('model_execution_requested',False),
    ('calibration_reauthenticated',False),('baseline_complete',63),('semantic_passes',3199),
    ('validation_inputs_read',True),('private_directory_handle_closed',False),('native_dtype','float64')])
def test_worker_terminal_and_actual_model_counts(name,value):
    data=fixture();data[1][name]=value
    with pytest.raises(ValueError):authenticate(data)


@pytest.mark.parametrize('name,value',[
    ('native_model_loaded',False),('native_forward_started',3231),('native_forward_completed',3231),
    ('private_files',9665),('private_journals_immutable_at_review',False),('outer_exit_code',1),
    ('outer_reaped',False),('worker_group_absent',False),('reconstruction_script_sha256','0'*64),
    ('source_inventory_independently_verified',False),('aggregate_ranges_independently_recomputed',False)])
def test_root_independent_contract(name,value):
    with pytest.raises(ValueError):authenticate(review_change=lambda row:row.__setitem__(name,value))


@pytest.mark.parametrize('field',['calibration_sha256','model_asset_sha256','backend_sources_after','installed_dependencies','architecture','backend_environment'])
def test_asset_and_backend_fields_come_from_reviewed_sources(field):
    data=fixture();data[1][field]='0'*64 if field=='calibration_sha256' else {}
    with pytest.raises(ValueError):authenticate(data)


def test_mutually_rehashed_replacement_source_map_not_allowed():
    args,pins,snapshot,outer=encode(fixture())
    mapping=p.parse(pins.source_manifest_bytes);mapping['observer_process.py']='0'*64
    with pytest.raises(ValueError,match='digest'):p.authenticate_initial(*args,pins=replace(pins,source_manifest_bytes=p.canonical(mapping)),root_outer_bytes=outer)


@pytest.mark.parametrize('mutation',['missing','extra','alias','bool_size','zero_size','bad_hash','wrong_ledger','wrong_ranges','wrong_producer'])
def test_snapshot_private_inventory_and_producer_binding(mutation):
    def change(row):
        inv=row['inventory']
        if mutation=='missing':del inv['0000-native.json']
        elif mutation=='extra':inv['private-tokens.json']=inv['0000-native.json']
        elif mutation=='alias':inv['0000-native.json']['identity']=inv['0000-exact.json']['identity']
        elif mutation=='bool_size':inv['0000-native.json']['bytes']=True
        elif mutation=='zero_size':inv['0000-native.json']['bytes']=0
        elif mutation=='bad_hash':inv['0000-native.json']['sha256']='x'*64
        elif mutation=='wrong_ledger':row['ledger_sha256']='0'*64
        elif mutation=='wrong_ranges':row['input_ranges']['native_exact_union']['0.input.inverse_sqrt']['minimum']=0.5
        else:row['worker_report_sha256']='0'*64
    with pytest.raises(ValueError):authenticate(snapshot_change=change)


def test_snapshot_not_read_by_public_authenticator():
    args,pins,snapshot,outer=encode(fixture())
    b=p.authenticate_initial(*args,pins=pins,root_outer_bytes=outer)
    with pytest.raises(ValueError,match='digest'):p.authenticate_snapshot(snapshot+b' ',b)
    with pytest.raises(ValueError,match='original journal'):authenticate(review_change=lambda row:row['snapshot_descriptor'].__setitem__('parent_identity',[1,2]))


@pytest.mark.parametrize('name,value',[('exit_code',1),('exit_code',False),('reaped',False),('process_group_absent',False),('review_sha256','0'*64),('script_sha256','0'*64)])
def test_root_publication_does_not_replace_independent_terminal_receipt(name,value):
    args,pins,_,outer=encode(fixture());row=p.parse(outer);row[name]=value;outer=p.canonical(row)
    pins=replace(pins,root_outer_sha256=p.digest(outer))
    with pytest.raises(ValueError,match='reconstruction'):p.authenticate_initial(*args,pins=pins,root_outer_bytes=outer)


def test_baseline_ranges_never_enter_norm_union():
    data=fixture();data[1]['input_ranges']['baseline_generator_separate_diagnostic']={'0.input.inverse_sqrt':{'minimum':1e-300,'maximum':1e300}}
    value,*_=authenticate(data)
    assert p.parse(value.union_bytes)['0.input.inverse_sqrt']['minimum']==1.0


def test_positive_native_epsilon_rounding_is_proof_valid_but_policy_unsupported():
    data=fixture();lo=float(__import__('numpy').float32(1e-6));ranges=data[1]['input_ranges']
    for kind in ('native','exact'):
        ranges[kind]['ranges']['0.input.inverse_sqrt']['minimum']=lo
    ranges['native_exact_union']['0.input.inverse_sqrt']['minimum']=lo
    raw=p.inventory_bytes(ranges)
    data[1]['private_ranges_descriptor'].update(sha256=p.digest(raw),bytes=len(raw))
    data[4]['input-ranges.json']={k:data[1]['private_ranges_descriptor'][k]for k in ('sha256','bytes','identity')}
    snapshot,*_=authenticate(data)
    with pytest.raises(s.SelectionFailure)as error:
        c.prepare_synthetic_selection((HERE/'inputs/candidate3_manifest.json').read_bytes(),snapshot,
            (HERE/'inputs/norm_multipliers.json').read_bytes())
    assert error.value.stage=='domain'and error.value.site=='0.input.inverse_sqrt'


@pytest.mark.parametrize('name,value',[('ready',False),('execute_authorized',False),('candidate_ordinal',2),('candidate_ordinal',True),
    ('model_execution',True),('validation_body_reads',True),('gate_bounds_sha256','0'*64),('source_manifest_sha256','0'*64)])
def test_grant_strict_phase_and_source(name,value):
    snapshot,*_=authenticate();row=grant(snapshot);row[name]=value;raw=p.canonical(row)
    with pytest.raises(ValueError):g.authenticate_grant(raw,p.digest(raw),source_manifest_sha256='3'*64,output_directory='/synthetic/selection')


def test_exact_gate_bound_bytes_and_missing_actual_grant():
    snapshot,*_=authenticate();base=(HERE/'inputs/candidate3_manifest.json').read_bytes();bounds=(HERE/'inputs/norm_multipliers.json').read_bytes()
    with pytest.raises(PermissionError):c.select_actual(base,snapshot,bounds,authorization=None)
    with pytest.raises(ValueError):c.prepare_synthetic_selection(base,snapshot,bounds+b' ')


def test_real113_core_through_synthetic_granted_fixture():
    snapshot,*_=authenticate();row=grant(snapshot);raw=p.canonical(row)
    authorization=g.authenticate_grant(raw,p.digest(raw),source_manifest_sha256='3'*64,output_directory='/synthetic/selection')
    result=c.select_actual((HERE/'inputs/candidate3_manifest.json').read_bytes(),snapshot,
        (HERE/'inputs/norm_multipliers.json').read_bytes(),authorization=authorization)
    assert result['passed'] and len(result['assessments'])==113
    candidate=result['candidate']
    assert candidate['schema']=='qwen-expanded-initial-selection-v1' and candidate['candidate_ordinal']==1
    assert candidate['synthetic_only'] is False and candidate['actual_coefficient_selection'] is True
    # This test supplies only synthetic reports/ranges/grant. No actual grant was issued.
    assert p.canonical(s.protected(candidate))==p.canonical(s.protected(p.parse((HERE/'inputs/candidate3_manifest.json').read_bytes())))
