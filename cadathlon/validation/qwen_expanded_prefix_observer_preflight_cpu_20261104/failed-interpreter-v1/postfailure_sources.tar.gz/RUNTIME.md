This is a separately gated initial observer for the frozen expanded-prefix
Qwen protocol. Preparation leaves `execution_authorization.json` false. An
external manifest digest authenticates the exact source tree before local
imports; the actual worker additionally requires a separate reviewed grant.
Preflight performs synthetic checks and installed import denials only. It
does not read calibration tokens, model tensors, validation or old outcomes.

The actual grant permits only the completed tokenizer producer's calibration
file and the three pinned checkpoint/configuration assets. No tokenizer is
constructed. Transitive tokenizers package imports are permitted in the actual
worker; tokenizer assets remain forbidden. JAX, HE, network access, validation
and row0 are outside this stage. These are Python integrity/audit boundaries,
not an OS sandbox or a complete binary reproducibility image.

The 3,200 entries retain the original order and duplicates: 96 prompt families
at lengths1–32, then16 teacher sequences of four steps, then16 free sequences
of four steps. All computations use each entry's actual full prefix, positions
0 through S-1, and no KV cache. Teacher steps append the native argmax. Free
steps append the frozen candidate3 argmax after its complete checked circuit.
Candidate3 is only an initial trace generator and consumes none of the three
new candidates permitted by the later protocol. No new coefficients are
selected or evaluated here. Invalid dependent suffixes remain unmeasured;
neither native nor exact output can substitute for a failed free generator.

Native CPU float32 eager Qwen28 and the unchanged NumPy float64 reference
compare all151936 last-token logits. Gates are maxabs0.001, nRMSE1e-5 with
floor0.01, and exact argmax. Instrumented and uninstrumented outputs must be
bitwise equal at every length1–32. Observers capture113 normalization INPUT
variances,28 SiLU gate inputs and every causal raw/centered score row by
layer/query/valid-key count. Weighted normalization outputs are not mislabeled
as input variances. K1 is explicitly recorded as a probability-one bypass;
native/exact observations do not invent reciprocal denominator evidence.

Initial bounds can use only the native/exact union. Frozen generator ranges
remain separately tagged diagnostics. The actual source, model and calibration
files are checked around the run. Selection admission additionally requires
all3,200 entries complete, all semantic gates,64 complete generator calls,
all32 shape-invariance checks, successful cleanup, and independently verified
outer/child exit and source evidence. A terminal file cannot certify the
success of its own final descriptor close.

Fresh0700/0600 private journals retain each prefix, decision, metric, logit
digest and complete per-context input sufficient statistics. These statistics
allow later independent reconstruction of the aggregate without retaining raw
activations or full logit vectors. An interrupted run has phase records but no
complete final ledger. Public progress and reports contain only permitted
metadata, aggregate ranges/counts and hashes. Source archives exclude all
generated private journals, tokens, tensors and outputs.

The observer uses four CPU threads on112–115, with inter-op threads1 and an
explicit offline environment. Healthy work has no deadline. Cleanup attempts
every owned resource, preserves genuine body exception identity, and gives
cleanup-only cancellation priority over ordinary cleanup failures. Shared
borrowed inputs are never deleted. The runtime establishes no encrypted,
ranked, accuracy, refreshed-range or calibrated performance result.
