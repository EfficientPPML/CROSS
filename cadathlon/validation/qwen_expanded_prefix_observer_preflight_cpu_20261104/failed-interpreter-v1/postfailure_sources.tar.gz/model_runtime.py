"""Initial native/exact3200 observer; frozen candidate3 generates only free traces.

Imports are intentionally backend-free until execute(), which is called only
by the separately authenticated, granted observer worker. No selector exists
in this module. Per-entry tokens, choices and comparisons stay private.
"""
from dataclasses import asdict
import copy
import hashlib
import importlib.metadata
import math
import os
from pathlib import Path
import sys


VOCABULARY = 151936
ARCHITECTURE = dict(num_hidden_layers=28, hidden_size=1024,
                    intermediate_size=3072, num_attention_heads=16,
                    num_key_value_heads=8, head_dim=128, vocab_size=VOCABULARY)


def semantic_metric(actual, expected):
    """All last-token logits, stable scaled RMS, and exact top1 agreement."""
    import numpy as np
    a, b = np.asarray(actual), np.asarray(expected)
    result = dict(passed=False, finite=False,
                  shape_matches=a.shape == b.shape == (1, VOCABULARY),
                  max_abs=None, nrmse=None, top1_agreement=False,
                  all_final_logits_checked=0)
    if not result['shape_matches'] or a.dtype.kind not in 'fiu' or b.dtype.kind not in 'fiu':
        return result
    with np.errstate(over='ignore', invalid='ignore'):
        a, b = a.astype(np.float64), b.astype(np.float64)
        difference = a - b
    if not all(np.isfinite(x).all() for x in (a, b, difference)):
        return result
    maximum = float(np.max(np.abs(difference)))
    scale = float(np.max(np.abs(b)))
    error_rms = 0. if maximum == 0 else maximum * float(np.sqrt(np.mean((difference/maximum)**2)))
    reference_rms = 0. if scale == 0 else scale * float(np.sqrt(np.mean((b/scale)**2)))
    nrmse = error_rms / max(.01, reference_rms)
    top1 = bool(np.array_equal(a.argmax(-1), b.argmax(-1)))
    finite = math.isfinite(nrmse)
    result.update(finite=finite, max_abs=maximum, nrmse=nrmse if finite else None,
                  top1_agreement=top1, all_final_logits_checked=VOCABULARY)
    result['passed'] = bool(result['finite'] and maximum <= 1e-3 and nrmse <= 1e-5 and top1)
    return result


def array_digest(value, dtype='<f8'):
    import numpy as np
    return hashlib.sha256(np.asarray(value, dtype=dtype).tobytes(order='C')).hexdigest()


def merge_statistics(destination, source):
    """Sum observations without replacing minima/maxima or dropping failures."""
    for label, row in source.items():
        if label not in destination:
            destination[label] = copy.deepcopy(row)
            continue
        old = destination[label]
        if set(old) != set(row):
            raise ValueError('Observation statistic schema changed')
        for field, value in row.items():
            if field in ('count', 'nonfinite', 'nonpositive', 'below', 'above'):
                if type(value) is not int or value < 0:
                    raise ValueError('Nonnegative exact observation count required')
                old[field] += value
            elif field == 'minimum':
                old[field] = value if old[field] is None else old[field] if value is None else min(old[field], value)
            elif field == 'maximum':
                old[field] = value if old[field] is None else old[field] if value is None else max(old[field], value)
            elif old[field] != value:
                raise ValueError('Observation invariant differs')


class Aggregate:
    def __init__(self):
        self.contexts = 0
        self.ranges = {}
        self.score_rows = {}

    def add(self, observed):
        if observed.get('complete') is not True or observed.get('invalid') is not False:
            raise ValueError('Complete valid observer result required')
        if observed.get('norm_input_sites') != 113 or observed.get('silu_gate_sites') != 28:
            raise ValueError('Full28 native/exact input sites required')
        merge_statistics(self.ranges, observed['ranges'])
        for layer, rows in observed['score_rows'].items():
            target = self.score_rows.setdefault(layer, {})
            for key, row in rows.items():
                if key not in target:
                    target[key] = copy.deepcopy(row)
                    target[key]['contexts'] = 1
                    continue
                prior = target[key]
                if any(prior[name] != row[name] for name in row if name not in ('raw_valid', 'centered')):
                    raise ValueError('Per-query score contract changed')
                temporary = {name:prior[name] for name in ('raw_valid', 'centered')}
                merge_statistics(temporary, {name:row[name] for name in temporary})
                prior['contexts'] += 1
        self.contexts += 1

    def report(self):
        return dict(contexts=self.contexts, ranges=copy.deepcopy(self.ranges),
                    score_rows=copy.deepcopy(self.score_rows),
                    reciprocal_inputs_observed=False,
                    scope='Native/exact input observations only; K1 is an explicit bypass.')


def backend_check(blobs, reader, *, loaded=False):
    """Check installed Python source pins, including actual loaded Qwen origins."""
    from freeze_io import parse
    metadata = parse(blobs['backend_sources.json'])
    actual = {}
    for name, pin in metadata.items():
        snapshot = blobs[pin['snapshot']]
        if hashlib.sha256(snapshot).hexdigest() != pin['sha256']:
            raise ValueError('Backend snapshot digest differs')
        # This reader is the public regular-file primitive, never the restricted
        # calibration reader. The source-only preflight may exercise this path.
        data = reader(pin['path'], pin['sha256'], limit=4*1024*1024)
        actual[name] = hashlib.sha256(data).hexdigest()
        module_name = 'transformers.' + name[:-3].replace('/', '.')
        module = sys.modules.get(module_name)
        if loaded and module is not None:
            expected = Path(pin['path']).resolve()
            origins = (getattr(module, '__file__', None),
                       getattr(getattr(module, '__spec__', None), 'origin', None))
            if any(not isinstance(p, (str, os.PathLike)) or Path(p).resolve() != expected for p in origins):
                raise ValueError('Loaded backend module origin differs')
    if loaded and 'transformers.models.qwen3.modeling_qwen3' not in sys.modules:
        raise ValueError('Actual pinned Qwen backend was not loaded')
    return actual


class Adapters:
    """Own transient logits and private per-phase evidence for the pure dispatcher."""
    def __init__(self, *, native_forward, capture, config, weights, manifest,
                 private, progress, exact_module, plain_module, arithmetic_module,
                 range_factory, invalid_range):
        self.forward, self.capture = native_forward, capture
        self.config, self.weights, self.manifest = config, weights, manifest
        self.private, self.progress = private, progress
        self.observed, self.plain, self.arithmetic = exact_module, plain_module, arithmetic_module
        self.range_factory, self.invalid_range = range_factory, invalid_range
        self.native_ranges, self.exact_ranges = Aggregate(), Aggregate()
        self.baseline_ranges = {}
        self.native_logits = None
        self.native_binding = None
        self.invariance = {}
        self.exact_invariance = {}
        self.semantic_passes = 0
        self.baseline_complete = 0

    def embeddings(self, prefix):
        import numpy as np
        return self.weights['model.embed_tokens.weight'][np.asarray([prefix], dtype=np.int64)]

    def journal(self, entry, stage, record):
        # Fresh, never overwritten. An interrupted run lacks its final ledger;
        # these individual phase records cannot claim a completed context/run.
        self.private.json(f'{entry.index:04d}-{stage}.json', dict(entry=asdict(entry), **record))

    def native(self, prefix, entry):
        import numpy as np
        import workload
        self.native_logits = self.native_binding = None
        self.progress(dict(index=entry.index, kind=entry.kind, sequence_length=len(prefix), stage='native'))
        self.journal(entry, 'started', dict(prefix=list(prefix), context_complete=False,
                                          status='attempt_started'))
        bare = self.forward(prefix) if len(prefix) not in self.invariance else None
        self.capture.begin(len(prefix))
        try:
            logits = self.forward(prefix)
            observed = self.capture.end()
        except self.invalid_range as error:
            partial = self.capture.abort() if self.capture.active else self.capture.book.snapshot()
            self.journal(entry, 'native-invalid', dict(status='invalid_input', reason=str(error),
                                                     partial_observations=partial))
            raise workload.InvalidObservation('Native invalid input: ' + str(error)) from error
        if bare is not None:
            same = bool(np.array_equal(bare, logits))
            self.invariance[len(prefix)] = same
            if not same:
                raise ValueError('Native observation changed final logits')
        if logits.shape != (1, VOCABULARY) or not np.isfinite(logits).all():
            self.journal(entry, 'native-invalid', dict(status='invalid_logits'))
            raise workload.InvalidObservation('Native logits invalid')
        self.native_ranges.add(observed)
        self.native_logits = logits
        self.native_binding = (entry.index, tuple(prefix))
        token = int(logits.argmax())
        self.journal(entry, 'native', dict(status='observed', token=token,
            logits_sha256=array_digest(logits), all_final_logits=VOCABULARY,
            observations=observed,
            ranges_sha256=hashlib.sha256(__import__('freeze_io').json_bytes(observed)).hexdigest()))
        return workload.Native(token)

    def exact(self, prefix, entry, native):
        import numpy as np
        import workload
        if self.native_binding != (entry.index, tuple(prefix)) or self.native_logits is None:
            raise ValueError('Exact comparison has no matching actual native prefix')
        expected = self.native_logits
        self.native_logits = self.native_binding = None
        book = self.range_factory()
        book.begin(len(prefix))
        embeddings = self.embeddings(prefix)
        try:
            logits = self.observed.forward(self.config, self.weights, embeddings, observe=book.observe)
            observed = book.end()
        except self.invalid_range as error:
            self.journal(entry, 'exact-invalid', dict(status='invalid_input', reason=str(error),
                                                    partial_observations=book.snapshot()))
            raise workload.InvalidObservation('Exact invalid input: ' + str(error)) from error
        if len(prefix) not in self.exact_invariance:
            plain = self.plain.forward(self.config, self.weights, embeddings)
            same = bool(np.array_equal(plain, logits))
            self.exact_invariance[len(prefix)] = same
            if not same:
                raise ValueError('Exact observation changed final logits')
        metric = semantic_metric(logits, expected)
        self.exact_ranges.add(observed)
        token = int(logits.argmax()) if metric['finite'] else None
        self.journal(entry, 'exact', dict(status='observed', token=token, semantic=metric,
            logits_sha256=array_digest(logits),
            observations=observed,
            ranges_sha256=hashlib.sha256(__import__('freeze_io').json_bytes(observed)).hexdigest()))
        if token is None:
            raise workload.InvalidObservation('Exact logits invalid')
        self.semantic_passes += int(metric['passed'])
        self.progress(dict(index=entry.index, kind=entry.kind, sequence_length=len(prefix),
                           stage='native_exact_complete', semantic_pass=metric['passed']))
        return workload.Exact(token, metric['passed'])

    def baseline(self, prefix, entry):
        import numpy as np
        import workload
        engine = self.arithmetic.QwenArithmetic(self.manifest)
        failure = None
        output = None
        try:
            output, returned, blocks, operators = self.arithmetic.approximate_forward(
                self.config, self.weights, self.embeddings(prefix), self.manifest, engine=engine)
            if returned is not engine or len(blocks) != 28 or len(operators) != 421:
                raise ValueError('Incomplete frozen baseline operator trajectory')
        except self.arithmetic.InvalidCircuit as error:
            failure = dict(label=error.label, record=error.record)
        merge_statistics(self.baseline_ranges, engine.domains)
        complete = (output is not None and failure is None and not engine.domain_failures()
                    and output.data.shape == (1, VOCABULARY) and np.isfinite(output.data).all())
        token = int(output.data.argmax()) if complete else None
        self.journal(entry, 'baseline', dict(status='complete' if complete else 'invalid',
            token=token, failure=failure, domain_ranges=engine.domains,
            logits_sha256=array_digest(output.data) if complete else None,
            ranges_role='separate_initial_generator_diagnostic_only'))
        if not complete:
            raise workload.InvalidObservation('Frozen baseline incomplete; dependent suffix unmeasured')
        self.baseline_complete += 1
        return workload.Baseline(token, True)

    def run(self, calibration):
        import workload
        result = workload.run_initial(calibration, native=self.native, exact=self.exact,
                                      baseline=self.baseline)
        self.native_logits = self.native_binding = None
        self.private.json('initial-ledger.json', asdict(result))
        public = result.public_report()
        union = copy.deepcopy(self.native_ranges.ranges)
        merge_statistics(union, self.exact_ranges.ranges)
        ranges = dict(native=self.native_ranges.report(), exact=self.exact_ranges.report(),
                      native_exact_union=union,
                      baseline_generator_separate_diagnostic=self.baseline_ranges,
                      initial_bounds_include_baseline=False)
        descriptor = self.private.json('input-ranges.json', ranges)
        required_shapes = set(range(1, 33))
        invariance = (set(self.invariance) == required_shapes and all(self.invariance.values())
                      and set(self.exact_invariance) == required_shapes and all(self.exact_invariance.values()))
        public.update(passed=bool(public['complete'] and invariance and
                      self.semantic_passes == 3200 and self.baseline_complete == 64),
                      hook_invariance_by_length={str(k):v for k,v in self.invariance.items()},
                      exact_invariance_by_length={str(k):v for k,v in self.exact_invariance.items()},
                      semantic_passes=self.semantic_passes, baseline_complete=self.baseline_complete,
                      input_ranges=ranges, private_ranges_descriptor=descriptor,
                      validation_inputs_read=False, coefficient_selection_performed=False,
                      new_candidates_evaluated=0, encrypted_execution=False,
                      scope='Initial native/exact3200 observations and frozen baseline64 trace generation only.')
        public['initial_selection_admissible'] = public['passed']
        return public


def execute(blobs, reader, private_output, progress):
    """Actual-worker entry only; no injected model, tokenizer, or output oracle."""
    from freeze_io import parse, read as public_read
    from input_gate import model_assets
    import workload
    external = parse(blobs['external_inputs.json'])
    cal = external['calibration']
    calibration = parse(reader(cal['path'], cal['sha256'], limit=cal['bytes']))
    workload.validate_calibration(calibration)
    manifest_bytes = blobs['public/candidate3_manifest.json']
    if hashlib.sha256(manifest_bytes).hexdigest() != workload.BASELINE_MANIFEST_SHA256:
        raise ValueError('Frozen baseline manifest differs')
    manifest = parse(manifest_bytes)
    dependencies = parse(blobs['dependencies.json'])
    installed = {name:sys.version if name == 'python' else importlib.metadata.version(name)
                 for name in dependencies}
    if installed != dependencies:
        raise ValueError('Pinned installed runtime versions differ')
    if sorted(os.sched_getaffinity(0)) != [112, 113, 114, 115]:
        raise ValueError('Observer requires declared CPU112-115 affinity')
    for name in ('HF_HUB_OFFLINE', 'TRANSFORMERS_OFFLINE', 'HF_HUB_DISABLE_TELEMETRY'):
        if os.environ.get(name) != '1':
            raise ValueError('Explicit offline model environment required')
    for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):
        if os.environ.get(name) != '4':
            raise ValueError('Declared four-thread numeric environment required')
    backend_before = backend_check(blobs, public_read)
    # Every asset remains hash/identity checked around all model work. This is
    # an in-process integrity contract, not protection from a hostile same UID.
    with model_assets(blobs) as model_root:
        import numpy as np
        import torch
        from transformers import Qwen3ForCausalLM
        from native_observer import NativeObserver
        from ranges import RangeBook, InvalidInput
        import observed_reference
        import reference
        import arithmetic
        torch.set_num_threads(4)
        torch.set_num_interop_threads(1)
        model, loading = Qwen3ForCausalLM.from_pretrained(model_root, local_files_only=True,
            use_safetensors=True, torch_dtype=torch.float32, attn_implementation='eager',
            output_loading_info=True)
        if any(loading.get(name) for name in ('missing_keys','unexpected_keys','mismatched_keys','error_msgs')):
            raise ValueError('Model loading was not exact')
        model.eval()
        config = model.config.to_dict()
        if {name:config[name] for name in ARCHITECTURE} != ARCHITECTURE:
            raise ValueError('Actual model architecture differs')
        if model.config._attn_implementation != 'eager' or model.training:
            raise ValueError('Actual model must use eager evaluation')
        if any(p.device.type != 'cpu' or p.dtype != torch.float32 for p in model.parameters()):
            raise ValueError('CPU float32 parameters required')
        if model.lm_head.weight.data_ptr() != model.model.embed_tokens.weight.data_ptr():
            raise ValueError('Actual pretrained tied embeddings required')
        weights = {name:value.detach().numpy().astype(np.float64)
                   for name,value in model.state_dict().items() if name != 'lm_head.weight'}
        backend_check(blobs, public_read, loaded=True)
        def native(prefix):
            with torch.no_grad():
                return model(input_ids=torch.tensor([prefix], dtype=torch.long),
                    attention_mask=torch.ones((1,len(prefix)), dtype=torch.long),
                    position_ids=torch.arange(len(prefix))[None,:], use_cache=False
                    ).logits[:,-1].detach().numpy().astype(np.float64)
        with NativeObserver(model) as capture:
            adapters = Adapters(native_forward=native, capture=capture, config=config,
                weights=weights, manifest=manifest, private=private_output, progress=progress,
                exact_module=observed_reference, plain_module=reference,
                arithmetic_module=arithmetic, range_factory=RangeBook, invalid_range=InvalidInput)
            report = adapters.run(calibration)
        backend_after = backend_check(blobs, public_read, loaded=True)
        if backend_after != backend_before:
            raise ValueError('Backend source changed during model work')
        report.update(architecture=ARCHITECTURE, model_loading_exact=True,
            backend_sources_before=backend_before, backend_sources_after=backend_after,
            native_dtype='float32', exact_dtype='float64', installed_dependencies=installed,
            calibration_sha256=cal['sha256'], model_asset_sha256={name:
                parse(blobs['public/model_pins.json'])['asset_sha256'][name]
                for name in external['model_assets']})
        return report
