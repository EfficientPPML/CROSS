# Isolated Qwen organizer/reference file adapter

This is new organizer/reference glue around the unchanged combined208 full28 owner, whose authoritative90010/6e7331 exit0/reaped terminal passed330 synthetic tests with zero audit denials; exact parent208 sources are copied under parent208/ without edits. The contestant `p4_qwen/src/qwen_he.py` starter is intentionally untouched. The existing runner is a toy-fixture runner; this module does not turn its toy case API into evidence for the learned full model. No actual entrypoint, grant, scientific acceptance or backend construction is enabled here.

The initial implementation closes parameter-file/header ownership and Qwen request/response lifecycle. It will use public source metadata and synthetic files only. The eventual session contract remains client `encrypt(original_embeddings)`, keyless server `evaluate(ciphertexts)`, client `decrypt(ciphertexts)`, and `close()`, with explicit original position IDs. Repeated encrypted prefill is the supported decode geometry; there is no plaintext/KV-cache shortcut.

## Exact geometry and identities

One request has batch1, 1..32 distinct logical embedding rows of width1024 and increasing original position IDs in0..40959. Packing uses16 rows per65536-slot ciphertext, row pitch4096, feature and unused-row padding zero, without replication. There are exactly ceil(S/16) input ciphertexts. The file boundary will carry freshL49 inputs at canonical scale; the server must perform a genuine public prefix level reduction49→25, preserving scale, before passing the original ciphertext objects' reduced successors to the full owner. This is an explicit proposed adapter boundary, not a claim that current208 already owns input encoding or reduction.

The owner performs the selected cohort attention path, all28 decoder layers, final last-valid-row extraction, B8192 refresh toL25, degree256 final RMS toL3 and38 head blocks toL2. Responses contain all38 ordered ciphertexts at physical row0:37 blocks of4096 logits and one of384, concatenated to151936 logits for the final supplied original position. Each response binds the exact request nonce and ordered input digest, actual finite positive scale, Q-prefix, level, NSD1, precision32, batch1/two ciphertext elements, layout256×512 and exact block start/stop. No two-class BERT response or eight-input assumption transfers.

Public source identities bind expanded candidate344954b3873a8847ececba320646f52612ca7277412c7de81a7313894e21799a, exact config/checkpoint, unchanged historical QKV/decoder export identities, their explicit candidate bridge, new normalization certificates, actual166-key union and exact p60/d8 Q100/P14 profile. Context identity comes from the authenticated public key manifest. Producer source identity and consumer source identity remain distinct. A digest binds bytes; it is not an external grant or proof of scientific acceptance. Current missing first-PASS freeze, heldout/row0 disposition and actual execution grant remain null/false.

## Parameter ownership

The public catalog consumes all84 QKV descriptors,114 decoder names/113 physical files including the exact tied embedding/head alias, and113 gamma descriptors. Historical export metadata retain their original candidate identity. Every matrix checks the pinned NPY file hash, bounded header/version, exact little-endian float64 C order/shape/byte extent, raw promoted payload hash and finite values. The loader holds the original directory/file inode and read-only backing through use, rechecks file/path identity and bytes before release, and supplies exact ndarray views to the existing immutable-copy QwenParameterSource. The gamma NPZ is authenticated as a whole, then all113 members are checked for exact inventory, bounded headers/extents, float64 shape/raw hash and finite values; no pickle, object arrays, extra members or allocation from unchecked dimensions.

Owned test files are synthetic. Actual exported matrix/gamma bodies, checkpoint/model files, token/trajectory/outcome bodies and keys/ciphertexts remain unopened in this preparation. Catalog construction from authenticated public source blobs is separate from a held body-reader object; actual role admission must precede construction of the latter.

## File lifecycle and reuse

Byte-exact reviewed BERT286/default125 source helpers will be copied only with explicit provenance. Reuse is limited to bounded descriptor I/O, ownership, payload-format validation, attempt-all cleanup and terminal process structure where compatible. Their BERT model/profile/key-count/request/response contracts are not reused. The new Qwen schemas must enumerate every field, reject unknown/type-aliased fields, and bind both producer and consumer identities.

Request uploads are borrowed read-only. Response and client completion/result roots are fresh owned disjoint roots. Each ordered artifact must authenticate before any backend wrapper is constructed; the client authenticates all38 payloads before opening its private loader. Server computation and all output readiness barriers finish before any private decode. No metadata publication can certify external wait/reap/group retirement; that requires an independent outer receipt.

Parameter mappings and key/context/compiled owners outlive all consumers and readiness barriers. An entered arithmetic or barrier failure quarantines the complete retained ownership graph until dedicated-process exit; ordinary file-reader failures attempt all safe releases and preserve the genuine body-primary object. Uncertain close resources are retained and never retried. Normal cleanup checks held identities, performs source/parameter readback, retires compiled owners before borrowed key mappings, and publishes completion only after cleanup and signal restoration. The initial component does not yet provide an executable HE process harness or assert process isolation.

## Initial public/synthetic components

1. `qwen_file_contract.py`: exact typed public identity, original-row packing, fresh input and38-output metadata/digest schemas. No backend import or body I/O.
2. `qwen_public_parameters.py`: source-bound public catalog plus held NPY/NPZ readers, immutable descriptor state, readback, close/quarantine and ndarray callback interface.
3. `qwen_file_lifecycle.py`: ordered request/response admission and held-file lifetime around separately supplied serializers/consumers. Payload semantics use the existing exact six-field RNS container format; synthetic callbacks are labeled and cannot become an actual execution grant.
4. Focused unit tests for real synthetic NPY/NPZ headers/bytes, replacement/truncation/alias failures, ordered38-output binding/all-before-private admission, cleanup failures and original primary preservation. No backend, keygen, model or learned wholegraph tests.

The next source review will decide the exact smallest backend/session adapter. No broad new collector/audit matrix, benchmark, numerical approximation change or full source-bound preparation is implied by this draft.
