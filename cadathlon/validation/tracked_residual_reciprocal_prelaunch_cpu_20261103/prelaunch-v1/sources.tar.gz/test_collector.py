"""Collector gates and failure recovery; no encrypted numerical claims."""
from pathlib import Path
import copy
import io
import json
import sys
import tarfile
import numpy as np
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parent))
import check_component as c
from lifecycle import CleanupTracker

@pytest.fixture(scope='module')
def ideal():
    rules=c.load_rules();x,w,b,fixture=c.make_probes(rules);y,e=c.client_oracles(x,w,b)
    return x,w,b,fixture,y,e

def evaluate(ideal,mutate=None):
    x,w,b,fixture,y,e=ideal
    yy={i:v.copy() for i,v in enumerate(y,1)};ee={i:v.copy() for i,v in enumerate(e,1)}
    meta={i:dict(passed=True) for i in range(1,14)}
    if mutate:mutate(yy,ee,meta)
    return c.validate_decoded(yy,ee,x,y,e,fixture,meta)

def test_exact_pinned_manifest_and_complete_physical_segments(ideal):
    x,w,b,fixture,y,e=ideal
    assert c.sha((c.HERE/'candidate_manifest.json').read_bytes())==c.MANIFEST_SHA256
    assert [r['name'] for r in fixture['segments']]==['initial','tanh']+[f'K{i}' for i in range(1,129)]
    assert fixture['segments'][0]['slot_start']==0 and fixture['segments'][-1]['slot_stop']==32768
    assert sum(r['slots'] for r in fixture['segments'])==32768
    for left,right in zip(fixture['segments'],fixture['segments'][1:]):assert left['slot_stop']==right['slot_start']
    for row in fixture['segments']:
        values=x[row['slot_start']:row['slot_stop']];low,high=row['domain']
        assert values[0]==low and values[1]==high
        assert np.all((values>=low)&(values<=high)) and np.unique(values).size>200
        assert np.all(w[row['slot_start']:row['slot_stop']]==-row['seed']*row['seed'])
        assert np.all(b[row['slot_start']:row['slot_stop']]==2*row['seed'])

def test_changed_manifest_rejected_before_probe_selection(tmp_path):
    p=tmp_path/'manifest.json';p.write_bytes((c.HERE/'candidate_manifest.json').read_bytes()+b' ')
    with pytest.raises(ValueError,match='frozen'):c.load_rules(p)

def test_ideal_gates_and_early_nonconvergence_are_distinct(ideal):
    result=evaluate(ideal)
    assert result['passed'] and len(result['checkpoints'])==13 and len(result['declared_rules'])==130
    x,w,b,fixture,y,e=ideal
    assert np.max(np.abs(1-x*y[0]))>.9
    assert max(r['true_inverse_max_abs_error'] for r in result['declared_rules'])<1e-6
    assert {r['declared_update'] for r in result['declared_rules']}=={5,6,7,8,9,10,11,12,13}

@pytest.mark.parametrize('branch',['y','e'])
@pytest.mark.parametrize('update',[1,6,13])
def test_every_actual_checkpoint_gated(ideal,branch,update):
    def mutate(y,e,metadata):(y if branch=='y' else e)[update].__setitem__(17,(y if branch=='y' else e)[update][17]+3e-6)
    assert not evaluate(ideal,mutate)['passed']

def test_true_inverse_absolute_gate_is_independent_of_relative_residual(ideal):
    # At the low K128 endpoint,2e-6 absolute inverse error has only7.8e-9 relative residual.
    x,w,b,fixture,y,e=ideal;row=fixture['segments'][-1];slot=row['slot_start'];update=row['iterations']
    def mutate(yy,ee,metadata):yy[update][slot]+=2e-6
    result=evaluate(ideal,mutate);last=result['declared_rules'][-1]
    assert last['true_relative_residual_max_abs']<c.GATE
    assert last['true_inverse_max_abs_error']>c.GATE and not last['passed']

def test_tiny_tracked_residual_cannot_mask_estimate_branch_drift(ideal):
    x,w,b,fixture,y,e=ideal;slot=fixture['segments'][-1]['slot_start']
    def mutate(yy,ee,metadata):yy[13][slot]+=1e-2;ee[13][slot]=0
    result=evaluate(ideal,mutate)
    assert not result['passed'] and result['checkpoints'][-1]['invariant_defect_max_abs']>c.GATE

def test_missing_actual_final_residual_rejected(ideal):
    x,w,b,fixture,y,e=ideal
    with pytest.raises(ValueError,match='actual residual'):
        c.validate_decoded(dict(enumerate(y,1)),dict(enumerate(e[:-1],1)),x,y,e,fixture,{})

@pytest.mark.parametrize('branch',['y','e'])
def test_nonfinite_decoded_values_fail(ideal,branch):
    def mutate(y,e,metadata):(y if branch=='y' else e)[13].__setitem__(0,np.nan)
    assert not evaluate(ideal,mutate)['passed']

def test_metadata_failure_independent_of_exact_decoded_values(ideal):
    def mutate(y,e,metadata):metadata[8]['passed']=False
    assert not evaluate(ideal,mutate)['passed']

def test_actual_profile_scale_and_retained_resource_accounting():
    r=c.parameters();q,p=r['q_towers'],r['p_towers']
    assert r['degree']==65536 and len(q)==32 and len(p)==9 and r['dnum']==4
    assert r['actual_log2_qp']<1747
    assert np.prod(np.asarray(p,dtype=object))>=max(np.prod(np.asarray(q[i:i+8],dtype=object)) for i in range(0,32,8))
    rows=r['scale_plan']['rows'];assert [x['level'] for x in rows]==[14]+list(range(12,0,-1))
    assert [x['residual_level'] for x in rows[:-1]]==list(range(13,1,-1))
    assert rows[-1].get('residual_level') is None
    assert r['diagnostic_residual']['level']==1
    assert r['diagnostic_residual']['scale']==rows[-2]['residual_scale']*rows[-2]['residual_scale']/(q[4]*q[5])
    assert r['raw_retained_checkpoint_bytes']==219152384
    assert r['production_counts']['ciphertext_multiplications']==24
    assert r['diagnostic_counts']['ciphertext_multiplications']==1

def test_archive_payload_tampering_rejected(tmp_path):
    path=tmp_path/'source.tar.gz'
    with tarfile.open(path,'w:gz') as t:
        info=tarfile.TarInfo('a.py');info.size=3;t.addfile(info,io.BytesIO(b'bad'))
    with pytest.raises(ValueError,match='bytes differ'):c.verify_archive(path,{'a.py':c.sha(b'yes')})

def fake_main(monkeypatch,tmp_path):
    output=tmp_path/'attempt'
    monkeypatch.setattr(sys,'argv',['collector','--output',str(output),'--preflight'])
    monkeypatch.setattr(c,'sources',lambda:{'exact.py':b'public source'})
    return output

def test_initial_publication_failure_keeps_failed_report(monkeypatch,tmp_path):
    output=fake_main(monkeypatch,tmp_path);write=c.write;calls=[]
    def flaky(path,value):
        calls.append(path)
        if len(calls)==1:raise OSError('initial publication failed')
        write(path,value)
    monkeypatch.setattr(c,'write',flaky)
    with pytest.raises(OSError,match='initial'):c.main()
    r=json.loads((output/'report.json').read_text());assert not r['passed'] and not r['key_generation_started']
    assert 'initial publication failed' in r['error'] and r['cleanup_completed'] is False

def test_software_metadata_failure_keeps_failed_report(monkeypatch,tmp_path):
    output=fake_main(monkeypatch,tmp_path)
    def fail(*args):raise RuntimeError('versions unavailable')
    monkeypatch.setattr(c.importlib.metadata,'version',fail)
    with pytest.raises(RuntimeError,match='versions'):c.main()
    r=json.loads((output/'report.json').read_text());assert not r['passed'] and not r['key_generation_started']
    assert r['source_archive_members_verified'] and r['source_files_unchanged']

def test_preflight_source_drift_fails(monkeypatch,tmp_path):
    output=fake_main(monkeypatch,tmp_path);calls=[]
    def source():calls.append(1);return {'exact.py':b'first' if len(calls)==1 else b'changed'}
    monkeypatch.setattr(c,'sources',source)
    assert c.main()==1
    r=json.loads((output/'report.json').read_text());assert not r['passed'] and not r['source_files_unchanged'] and not r['key_generation_started']

def test_cleanup_preserves_primary_and_attempts_every_action():
    primary=ValueError('arithmetic');tracker=CleanupTracker(primary);seen=[]
    def failure():seen.append(1);raise KeyboardInterrupt('cleanup cancellation')
    tracker.attempt('first',failure);tracker.attempt('last',lambda:seen.append(2));tracker.finish()
    assert seen==[1,2] and tracker.errors and primary.__notes__

def test_cleanup_only_cancellation_preserved_after_attempt_all():
    tracker=CleanupTracker(None);seen=[]
    def failure():raise KeyboardInterrupt('stop')
    tracker.attempt('first',failure);tracker.attempt('last',lambda:seen.append(1))
    with pytest.raises(KeyboardInterrupt,match='stop'):tracker.finish()
    assert seen==[1]
