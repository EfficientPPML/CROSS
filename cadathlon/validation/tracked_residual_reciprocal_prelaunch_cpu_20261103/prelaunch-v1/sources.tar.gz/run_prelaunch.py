"""Preserve exact source bytes for backend-free tests and public ring preflight."""
from pathlib import Path
import argparse,hashlib,io,json,os,subprocess,sys,tarfile,time
HERE=Path(__file__).resolve().parent

def sha(data):return hashlib.sha256(data).hexdigest()
def files():
    paths=set(HERE.glob('*.py'))|{HERE/'candidate_manifest.json',HERE/'source_origin.json'}
    paths.update((HERE/'checkout').rglob('*.py'))
    return {str(p.relative_to(HERE)):p.read_bytes() for p in sorted(paths)}
def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(exist_ok=False)
    started=time.monotonic();raw=files();before={n:sha(v) for n,v in raw.items()}
    with tarfile.open(a.output/'sources.tar.gz','w:gz') as t:
        for n,v in raw.items():i=tarfile.TarInfo(n);i.size=len(v);t.addfile(i,io.BytesIO(v))
    commands=[('tests',[sys.executable,'-m','pytest','-q',str(HERE/'test_collector.py'),str(HERE/'test_tracked_reciprocal.py'),'--junitxml='+str(a.output/'tests.xml')]),
              ('preflight',[sys.executable,str(HERE/'check_component.py'),'--preflight','--output',str(a.output/'preflight')])]
    rows=[]
    for name,command in commands:
        begin=time.monotonic()
        with (a.output/(name+'.log')).open('wb') as output:
            process=subprocess.run(command,cwd=HERE,stdout=output,stderr=subprocess.STDOUT,check=False)
        rows.append(dict(name=name,command=command,returncode=process.returncode,elapsed_s=time.monotonic()-begin))
    after={n:sha(v) for n,v in files().items()}
    with tarfile.open(a.output/'sources.tar.gz') as t:archived={m.name:sha(t.extractfile(m).read()) for m in t.getmembers()}
    ring=json.loads((a.output/'preflight/report.json').read_text()) if (a.output/'preflight/report.json').is_file() else {}
    passed=all(r['returncode']==0 for r in rows) and before==after==archived==ring.get('source_hashes_before')==ring.get('source_hashes_after') and ring.get('passed') is True
    report=dict(passed=passed,scope='Public preflight and CPU boundary tests only; no keys or ciphertext execution.',source_hashes_before=before,source_hashes_after=after,
        source_files_unchanged=before==after,archive_members_verified=archived==before,source_archive_sha256=sha((a.output/'sources.tar.gz').read_bytes()),
        child_preflight_source_identity=before==ring.get('source_hashes_before'),commands=rows,elapsed_s=time.monotonic()-started,
        cpu_affinity=sorted(os.sched_getaffinity(0)),pid=os.getpid())
    (a.output/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ('passed','scope','elapsed_s','child_preflight_source_identity')}))
    return 0 if passed else 1
if __name__=='__main__':raise SystemExit(main())
