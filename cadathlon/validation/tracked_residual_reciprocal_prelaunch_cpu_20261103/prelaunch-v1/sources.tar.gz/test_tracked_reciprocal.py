"""Independent rational identity, actual scale recurrence and suspension guards."""
from fractions import Fraction
from pathlib import Path
from types import SimpleNamespace
import json
import math
import sys
import numpy as np
import pytest

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE), str(HERE/'checkout/cadathlon/common')]
import tracked_reciprocal as module


class Value:
    def __init__(self, data, level, scale):
        self.data = data
        self.level = level
        self._ckks_scale = scale
        self._ckks_nsd = 1


class Arithmetic:
    def __init__(self, q, slots):
        self.q = q
        self.calls = 0
        self.refresher = None
        self.ctx = SimpleNamespace(composite_degree=2, num_slots=slots,
            secret_key=None, parameters={}, _param_cache=SimpleNamespace(secret_key=None,
            q_moduli_at_level=lambda level: tuple(q[:2*(level+1)])))

    def _level(self, value):
        return value.level

    def multiply(self, a, b):
        self.calls += 1
        level = min(a.level, b.level)
        divisor = self.q[2*level] * self.q[2*level+1]
        return Value(a.data*b.data, level-1, a._ckks_scale*b._ckks_scale/divisor)


def install_public_simulator(monkeypatch, *, rational=False):
    def convert(x):
        if rational:
            return Fraction.from_float(float(x))
        return np.asarray(x)

    def affine(arithmetic, value, weight, bias, *, output_scale):
        arithmetic.calls += 1
        divisor = arithmetic.q[2*value.level] * arithmetic.q[2*value.level+1]
        encoded_scale = output_scale*divisor/value._ckks_scale
        return Value(value.data*convert(weight)+convert(bias), value.level-1,
                     value._ckks_scale*encoded_scale/divisor)

    def integer(arithmetic, value, multiplier, *, bias=0.):
        arithmetic.calls += 1
        return Value(value.data*multiplier+convert(bias), value.level, value._ckks_scale)

    monkeypatch.setattr(module, 'affine_at_scale', affine)
    monkeypatch.setattr(module, 'integer_affine', integer)


def inputs(updates, slots=1):
    level = 2 if updates == 1 else updates+2
    q = tuple(2**30-101-2*i for i in range(2*(level+1)))
    scale = float(q[-2])*q[-1]
    arithmetic = Arithmetic(q, slots)
    plan = module.tracked_scale_plan(q, input_level=level, input_scale=scale,
                                    updates=updates, final_scale=scale)
    return arithmetic, plan, level, scale


@pytest.mark.parametrize('updates', [1, 2, 3, 4, 6])
@pytest.mark.parametrize('constant', [1, 32])
def test_exact_fraction_identity_from_rounded_first_affine(monkeypatch, updates, constant):
    install_public_simulator(monkeypatch, rational=True)
    arithmetic, plan, level, scale = inputs(updates)
    x = Fraction(7, 19)
    # Deliberately rounded coefficients: neither is represented as an ideal seed.
    weight, bias = -0.12345678901234567, 0.9876543210987654
    expected = x*Fraction.from_float(weight)+Fraction.from_float(bias)
    original = Value(x, level, scale)
    before = dict(vars(original))
    results = list(module.tracked_reciprocal_updates(arithmetic, original,
        normalization_factor=constant, first_weight=weight, first_bias=bias,
        updates=updates, first_output_scale=plan['first_output_scale']))
    for number, y, error in results:
        if number > 1:
            expected = expected*(2-constant*x*expected)
        assert y.data == expected
        if error is not None:
            assert error.data == 1-constant*x*expected
        row = plan['rows'][number-1]
        assert (y.level, y._ckks_scale) == (row['level'], row['scale'])
        if error is not None:
            assert (error.level, error._ckks_scale) == (row['residual_level'], row['residual_scale'])
    assert results[-1][2] is None
    assert level-results[-1][1].level == (1 if updates == 1 else updates+1)
    assert vars(original) == before


def test_all_130_frozen_rules_use_their_original_counts_and_coefficients(monkeypatch):
    install_public_simulator(monkeypatch)
    manifest = HERE/'candidate_manifest.json'
    import hashlib
    assert hashlib.sha256(manifest.read_bytes()).hexdigest() == '4e2277beea7189aa1d77b168c500c8a175f6c630afa520fcc6b38cb5a179cff9'
    model = json.loads(manifest.read_text())
    rules = [model['initial_reciprocal'], model['tanh_reciprocal'],
             *model['normalization_reciprocal_by_public_K'].values()]
    assert len(rules) == 130
    xs, weights, biases = [], [], []
    for rule in rules:
        low, high = rule['domain']
        xs.extend([low, np.nextafter(low, high), (low+high)/2, np.nextafter(high, low), high])
        weights.extend([-rule['seed']*rule['seed']]*5)
        biases.extend([2*rule['seed']]*5)
    x, w, b = map(np.asarray, (xs, weights, biases))
    arithmetic, plan, level, scale = inputs(13, len(x))
    results = list(module.tracked_reciprocal_updates(arithmetic, Value(x, level, scale),
        normalization_factor=1, first_weight=w, first_bias=b, updates=13,
        first_output_scale=plan['first_output_scale']))
    newton = x*w+b
    for i, y, e in results:
        if i > 1:
            newton = newton*(2-x*newton)
        np.testing.assert_allclose(y.data, newton, atol=2e-11, rtol=2e-13)
        if e is not None:
            np.testing.assert_allclose(e.data, 1-x*y.data, atol=2e-13, rtol=0)
    for index, rule in enumerate(rules):
        result = results[rule['iterations']-1][1].data[5*index:5*(index+1)]
        np.testing.assert_allclose(x[5*index:5*(index+1)]*result, 1., atol=1.1e-12, rtol=0)
    assert abs(plan['final_relative_difference']) < 1e-9


@pytest.mark.parametrize('mutation', ['ctx_secret', 'cache_secret', 'parameters_secret', 'refresh',
    'denominator_scale', 'denominator_nsd', 'returned_y_scale', 'returned_e_scale', 'context', 'cache', 'q'])
def test_suspended_iteration_rejects_contract_drift_before_next_operation(monkeypatch, mutation):
    install_public_simulator(monkeypatch)
    arithmetic, plan, level, scale = inputs(4)
    denominator = Value(np.array([.5]), level, scale)
    generator = module.tracked_reciprocal_updates(arithmetic, denominator,
        normalization_factor=1, first_weight=-1., first_bias=2., updates=4,
        first_output_scale=plan['first_output_scale'])
    _, y, e = next(generator)
    before = arithmetic.calls
    if mutation == 'ctx_secret': arithmetic.ctx.secret_key = object()
    elif mutation == 'cache_secret': arithmetic.ctx._param_cache.secret_key = object()
    elif mutation == 'parameters_secret': arithmetic.ctx.parameters['secret_key'] = object()
    elif mutation == 'refresh': arithmetic.refresher = object()
    elif mutation == 'denominator_scale': denominator._ckks_scale *= 2
    elif mutation == 'denominator_nsd': denominator._ckks_nsd = True
    elif mutation == 'returned_y_scale': y._ckks_scale *= 2
    elif mutation == 'returned_e_scale': e._ckks_scale *= 2
    elif mutation == 'context': arithmetic.ctx = Arithmetic(arithmetic.q, 1).ctx
    elif mutation == 'cache': arithmetic.ctx._param_cache = Arithmetic(arithmetic.q, 1).ctx._param_cache
    else: arithmetic.q = tuple(reversed(arithmetic.q)); arithmetic.ctx._param_cache.q_moduli_at_level = lambda level: arithmetic.q[:2*(level+1)]
    with pytest.raises(ValueError): next(generator)
    assert arithmetic.calls == before


@pytest.mark.parametrize('bad', [True, 0, -1, 1.5, 2**64])
def test_invalid_constant_fails_before_any_operation(monkeypatch, bad):
    install_public_simulator(monkeypatch)
    arithmetic, plan, level, scale = inputs(4)
    with pytest.raises(ValueError):
        list(module.tracked_reciprocal_updates(arithmetic, Value(.5, level, scale),
            normalization_factor=bad, first_weight=-1., first_bias=2., updates=4,
            first_output_scale=plan['first_output_scale']))
    assert arithmetic.calls == 0


@pytest.mark.parametrize('updates', [1, 2, 3, 4, 8, 13])
def test_scale_solution_matches_independent_log_recurrence(updates):
    arithmetic, plan, level, delta = inputs(updates)
    if updates > 1:
        q = arithmetic.q
        log_e = math.log(delta) + math.log(plan['rows'][0]['scale']) - math.log(q[2*(level-1)]*q[2*(level-1)+1])
        log_ratio = math.log(q[2*(level-1)]*q[2*(level-1)+1]) - math.log(delta)
        for step in range(updates-1):
            active = level-2-step
            log_e = 2*log_e-math.log(q[2*active]*q[2*active+1])
        assert abs(log_e+log_ratio-math.log(delta)) < 1e-9
    assert abs(plan['final_relative_difference']) < 1e-9


@pytest.mark.parametrize('change', ['bool_updates', 'float_level', 'too_shallow', 'duplicate_q',
    'invalid_q', 'scale_zero', 'scale_inf', 'scale_bool', 'scale_underflow'])
def test_invalid_scale_plan_rejected(change):
    _, _, level, scale = inputs(4)
    q = tuple(range(101, 101+2*(level+1)))
    args = dict(input_scale=scale, input_level=level, updates=4, final_scale=scale)
    if change == 'bool_updates': args['updates'] = True
    elif change == 'float_level': args['input_level'] = float(level)
    elif change == 'too_shallow': args['updates'] = level
    elif change == 'duplicate_q': q = (101,)*len(q)
    elif change == 'invalid_q': q = (1, *q[1:])
    elif change == 'scale_zero': args['input_scale'] = 0
    elif change == 'scale_inf': args['input_scale'] = float('inf')
    elif change == 'scale_bool': args['final_scale'] = True
    else: args['input_scale'] = np.longdouble('1e-4000')
    with pytest.raises(ValueError): module.tracked_scale_plan(q, **args)
