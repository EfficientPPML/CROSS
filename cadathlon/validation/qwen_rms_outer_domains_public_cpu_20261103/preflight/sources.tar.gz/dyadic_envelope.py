"""Exact nonnegative binary32/binary64 dot products with outward endpoints."""
from fractions import Fraction
import math
import numpy as np


def upper(value):
    value=Fraction(value)
    out=float(value)
    if not math.isfinite(out):raise ValueError('unrepresentable outer bound')
    while Fraction.from_float(out)<value:out=math.nextafter(out,math.inf)
    return out


def integerize(values):
    a=np.asarray(values)
    if a.dtype not in (np.dtype('float32'),np.dtype('float64')) or not a.size or not np.isfinite(a).all() or np.any(a<0):
        raise ValueError('finite nonnegative F32/F64 array required')
    if a.dtype==np.float32:
        bits=np.ascontiguousarray(a).view(np.uint32);fractionbits=23;bias=127;expmask=255
    else:
        bits=np.ascontiguousarray(a).view(np.uint64);fractionbits=52;bias=1023;expmask=2047
    exp=((bits>>fractionbits)&expmask).astype(np.int64)
    mant=(bits&((1<<fractionbits)-1)).astype(np.uint64)
    normal=exp!=0;mant[normal]|=np.uint64(1<<fractionbits)
    powers=np.where(normal,exp-bias-fractionbits,1-bias-fractionbits)
    active=mant!=0
    if not np.any(active):return np.zeros(a.shape,dtype=object),0
    minimum=int(powers[active].min());powers[~active]=minimum
    integers=np.left_shift(mant.astype(object),(powers-minimum).astype(object))
    return integers,minimum


def exact_linear(matrix,envelope):
    a=np.asarray(matrix);b=np.asarray(envelope)
    if a.ndim!=2 or b.shape!=(a.shape[1],):raise ValueError('linear shape mismatch')
    ai,ae=integerize(np.abs(a));bi,be=integerize(b)
    products=ai@bi
    power=ae+be
    result=[]
    for value in products:
        exact=Fraction(int(value)<<power) if power>=0 else Fraction(int(value),1<<-power)
        result.append(upper(exact))
    return np.asarray(result,dtype=np.float64)


def exact_product(left,right):
    a=np.asarray(left);b=np.asarray(right)
    if a.shape!=b.shape:raise ValueError('product shape mismatch')
    return np.array([upper(Fraction.from_float(float(x))*Fraction.from_float(float(y))) for x,y in zip(a,b)],dtype=np.float64)


def exact_add(left,right):
    a=np.asarray(left);b=np.asarray(right)
    if a.shape!=b.shape:raise ValueError('addition shape mismatch')
    return np.array([upper(Fraction.from_float(float(x))+Fraction.from_float(float(y))) for x,y in zip(a,b)],dtype=np.float64)
