"""Input-independent exact-real native RMS denominator envelopes; no model forward."""
from pathlib import Path
from fractions import Fraction
import argparse,hashlib,io,json,os,sys,tarfile,time
import numpy as np
from bounds import rms_variance_upper,sqrt_upper,ideal_newton_cost
from exact_dyadic import rows
from dyadic_envelope import upper,exact_linear,exact_add,exact_product
HERE=Path(__file__).resolve().parent
SNAPSHOT=Path('/home/jianming_gatech/cross_validation_assets/qwen/c1899de289a04d12100db370d81485cdf75e47ca')


def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def save(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')


def fraction(value):return [str(value.numerator),str(value.denominator)]


class Reader:
    def __init__(self,path):
        self.path=path;self.records={}
        with path.open('rb') as f:
            n=int.from_bytes(f.read(8),'little');self.header=json.loads(f.read(n));self.base=8+n
    def chunks(self,name,shape,chunk_rows=4096):
        d=self.header[name]
        if d['shape']!=list(shape) or d['dtype'] not in ('BF16','F32'):raise ValueError('tensor dtype/shape '+name)
        lo,hi=d['data_offsets'];width=int(np.prod(shape[1:]));itemsize=2 if d['dtype']=='BF16' else 4
        if hi-lo!=int(np.prod(shape))*itemsize:raise ValueError('tensor byte size')
        rawhash=hashlib.sha256();promotedhash=hashlib.sha256()
        with self.path.open('rb') as f:
            f.seek(self.base+lo)
            for start in range(0,shape[0],chunk_rows):
                nr=min(chunk_rows,shape[0]-start);raw=f.read(nr*width*itemsize)
                if len(raw)!=nr*width*itemsize:raise ValueError('truncated tensor')
                rawhash.update(raw)
                if d['dtype']=='BF16':
                    words=np.frombuffer(raw,dtype='<u2');bits=words.astype('<u4')<<16;array=bits.view('<f4')
                    if not np.array_equal(array.view('<u4')>>16,words):raise ValueError('inexact BF16 promotion')
                else:array=np.frombuffer(raw,dtype='<f4').copy()
                if not np.isfinite(array).all():raise ValueError('nonfinite public tensor')
                promotedhash.update(array.tobytes());yield array.reshape((nr,)+tuple(shape[1:]))
        self.records[name]=dict(shape=list(shape),source_dtype=d['dtype'],source_raw_bytes=hi-lo,
                               source_raw_sha256=rawhash.hexdigest(),promoted_dtype='<f4',
                               promoted_sha256=promotedhash.hexdigest(),promotion_exact=True)
    def read(self,name,shape):return np.concatenate(list(self.chunks(name,shape)),axis=0)


def run(output):
    output.mkdir(parents=True,exist_ok=False);start=time.monotonic();primary=None;paths={};before={};assets={}
    report=dict(passed=False,complete=False,scope=__doc__,model_forward=False,coefficient_selection=False,
                HE_or_backend_initialized=False,sites={},layers={},errors=[],cpu_affinity=sorted(os.sched_getaffinity(0)))
    try:
        save(output/'report.json',report)
        paths={p.name:p for p in HERE.iterdir() if p.suffix in ('.py','.json') and p.is_file()}
        before={n:sha(p) for n,p in paths.items()}
        with tarfile.open(output/'sources.tar.gz','w:gz') as t:
            for n,p in paths.items():raw=p.read_bytes();info=tarfile.TarInfo(n);info.size=len(raw);t.addfile(info,io.BytesIO(raw))
        with tarfile.open(output/'sources.tar.gz') as t:
            members=t.getmembers()
            if len(members)!=len(before) or len({m.name for m in members})!=len(before) or any(not m.isfile() for m in members):raise ValueError('source inventory')
            if {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in members}!=before:raise ValueError('source bytes')
        report.update(source_hashes_before=before,source_archive_sha256=sha(output/'sources.tar.gz'))
        pins=json.loads((HERE/'model_pins.json').read_text());assets={n:sha(SNAPSHOT/n) for n in pins['asset_sha256']}
        if assets!=pins['asset_sha256']:raise ValueError('pinned assets changed')
        report['asset_sha256_before']=assets
        config=json.loads((SNAPSHOT/'config.json').read_text())
        for name,value in dict(hidden_size=1024,intermediate_size=3072,num_attention_heads=16,num_key_value_heads=8,head_dim=128,num_hidden_layers=28,vocab_size=151936,attention_bias=False,hidden_act='silu').items():
            if type(config[name]) is not type(value) or config[name]!=value:raise ValueError('architecture mismatch '+name)
        eps=Fraction(config['rms_norm_eps'])
        if eps<=0:raise ValueError('epsilon must be positive')
        reader=Reader(SNAPSHOT/'model.safetensors');names=set(reader.header)-{'__metadata__'}
        suffixes={'input_layernorm.weight':(1024,), 'post_attention_layernorm.weight':(1024,),
                  'self_attn.q_norm.weight':(128,), 'self_attn.k_norm.weight':(128,),
                  'self_attn.q_proj.weight':(2048,1024),'self_attn.k_proj.weight':(1024,1024),
                  'self_attn.v_proj.weight':(1024,1024),'self_attn.o_proj.weight':(1024,2048),
                  'mlp.gate_proj.weight':(3072,1024),'mlp.up_proj.weight':(3072,1024),'mlp.down_proj.weight':(1024,3072)}
        expected={'model.embed_tokens.weight','model.norm.weight','lm_head.weight'}|{f'model.layers.{layer}.{name}' for layer in range(28) for name in suffixes}
        if names!=expected:raise ValueError('unexpected tensor/bias inventory')
        report['tensor_inventory']=sorted(names)
        residual=np.zeros(1024,dtype=np.float32)
        for block in reader.chunks('model.embed_tokens.weight',(151936,1024)):
            residual=np.maximum(residual,np.max(np.abs(block),axis=0))
        residual=residual.astype(np.float64)
        report['embedding_coordinate_upper']=residual.tolist()
        def site(label,hi,head_upper=None):
            value=dict(lower=float(eps),lower_fraction=fraction(eps),upper=upper(hi),upper_fraction=fraction(hi),
                       condition_ratio_upper=upper(hi/eps),positive_epsilon=True)
            if head_upper is not None:value['head_upper']=[dict(upper=upper(v),fraction=fraction(v)) for v in head_upper]
            report['sites'][label]=value
        def normalized(weight,gamma):
            values=list(rows(weight,gamma))
            return np.array([v[1] for v in values]),[v[0] for v in values]
        for layer in range(28):
            prefix=f'model.layers.{layer}.'
            public={s:reader.read(prefix+s,shape) for s,shape in suffixes.items()}
            gi=public['input_layernorm.weight'];gp=public['post_attention_layernorm.weight']
            site(f'{layer}.input.inverse_sqrt',rms_variance_upper(residual,eps))
            for role in ('q','k'):
                bound,square=normalized(public[f'self_attn.{role}_proj.weight'],gi)
                heads=[sum(square[i:i+128],Fraction())/128+eps for i in range(0,len(square),128)]
                site(f'{layer}.{role}.inverse_sqrt',max(heads),heads)
            v_bound,_=normalized(public['self_attn.v_proj.weight'],gi)
            v_gqa=np.repeat(v_bound.reshape(8,128),2,axis=0).reshape(-1)
            attention=exact_linear(public['self_attn.o_proj.weight'],v_gqa)
            post=exact_add(residual,attention)
            site(f'{layer}.post.inverse_sqrt',rms_variance_upper(post,eps))
            gate,_=normalized(public['mlp.gate_proj.weight'],gp)
            up,_=normalized(public['mlp.up_proj.weight'],gp)
            intermediate=exact_product(gate,up)
            mlp=exact_linear(public['mlp.down_proj.weight'],intermediate)
            residual=exact_add(post,mlp)
            report['layers'][str(layer)]=dict(attention_coordinate_upper=attention.tolist(),post_coordinate_upper=post.tolist(),
                gate_maximum=float(gate.max()),up_maximum=float(up.max()),mlp_coordinate_upper=mlp.tolist(),
                residual_coordinate_upper=residual.tolist(),residual_maximum=float(residual.max()),
                native_convex_attention_assumption='exact-real softmax, nonempty valid causal prefix; whole-head GQA repeat')
            print(json.dumps(dict(layer=layer,input_upper=report['sites'][f'{layer}.input.inverse_sqrt']['upper'],post_upper=report['sites'][f'{layer}.post.inverse_sqrt']['upper'],residual_maximum=float(residual.max()),elapsed_s=time.monotonic()-start)),flush=True)
        reader.read('model.norm.weight',(1024,))
        site('final.inverse_sqrt',rms_variance_upper(residual,eps))
        report.update(complete=True,tensor_records=reader.records,tensors_read=len(reader.records),sites_count=len(report['sites']),
                      exact_native_inverse_magnitude_upper=sqrt_upper(1/eps),
                      minimum_site_upper=min(v['upper'] for v in report['sites'].values()),maximum_site_upper=max(v['upper'] for v in report['sites'].values()),
                      minimum_condition_ratio=min(v['condition_ratio_upper'] for v in report['sites'].values()),maximum_condition_ratio=max(v['condition_ratio_upper'] for v in report['sites'].values()),
                      illustrative_ideal_newton_costs={label:ideal_newton_cost(Fraction(v['upper_fraction'][0])/Fraction(v['upper_fraction'][1])/eps) for label,v in report['sites'].items()},
                      no_backend_or_model_imported=not any(n.split('.')[0] in ('jax','jaxlib','jaxite_word','torch','transformers') for n in sys.modules),
                      limitations=['Exact-real native circuit only. No native float32, approximation, CKKS or refresh error bound.',
                       'Q/K bounds precede head normalization and RoPE; exact causal softmax convexity bounds values independently of Q/K magnitudes.',
                       'Lower epsilon is the exact configured binary64 number; float32 epsilon rounding is separate.',
                       'Residual, row-L2, Frobenius and L1 envelopes discard correlations and can be impractically loose.',
                       'Approximate attention needs nonnegative/row-L1 and norm-multiplier proofs before any propagation transfer.',
                       'Illustrative ideal Newton costs use an abstract exact seed, exclude actual coefficients/rounding and are not minimum depths.',
                       'No coefficients selected, prompts evaluated or validation extrema used. lm_head is outside the RMS input graph.'])
        report['passed']=report['sites_count']==113 and report['tensors_read']==310 and report['no_backend_or_model_imported']
    except BaseException as exc:
        primary=exc;report['passed']=False;report['errors'].append(dict(type=type(exc).__name__,message=str(exc)))
    finally:
        try:
            after={n:sha(p) for n,p in paths.items()};report.update(source_hashes_after=after,source_files_unchanged=bool(before) and before==after)
            report['asset_sha256_after']={n:sha(SNAPSHOT/n) for n in assets};report['assets_unchanged']=bool(assets) and assets==report['asset_sha256_after']
            report['passed']=report['passed'] and report['source_files_unchanged'] and report['assets_unchanged']
        except BaseException as exc:
            report['passed']=False;report['errors'].append(dict(phase='final_provenance',type=type(exc).__name__,message=str(exc)))
            if primary is None:primary=exc
            else:primary.add_note('Final provenance: '+repr(exc))
        report['elapsed_s']=time.monotonic()-start
        try:save(output/'report.json',report)
        except BaseException as exc:
            if primary is None:raise
            primary.add_note('Final publication: '+repr(exc))
    if primary is not None:raise primary
    return 0 if report['passed'] else 1


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
    raise SystemExit(run(p.parse_args().output))
