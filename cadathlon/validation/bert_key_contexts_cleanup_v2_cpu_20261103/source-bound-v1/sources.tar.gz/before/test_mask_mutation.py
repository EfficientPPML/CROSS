"""A sigmask setter may mutate process state before raising."""
import signal
import pytest
import key_contexts as loaders
from test_client_keys import mocked
from test_key_contexts import case,client,assert_restored
from test_key_contexts_signals import signal_state,SIGS

@pytest.mark.parametrize('phase',('installation','restoration'))
@pytest.mark.parametrize('body_primary',(False,True))
def test_postmutation_block_failure_restores_prior_mask_and_cleans(case,signal_state,monkeypatch,phase,body_primary):
    real_set,original,mask=signal_state;real_mask=signal.pthread_sigmask;blocks=[];primary=ValueError('body primary')
    selected=1 if phase=='installation' else 2
    def masking(how,values):
        values=tuple(values);result=real_mask(how,values)
        if how==signal.SIG_BLOCK and values:
            blocks.append(True)
            if len(blocks)==selected:raise OSError('SIG_BLOCK mutated the mask then failed')
        return result
    monkeypatch.setattr(signal,'pthread_sigmask',masking)
    with pytest.raises(ValueError if body_primary else OSError) as caught:
        with client(case) as h:
            secret=h.ctx.secret_key
            if body_primary:raise primary
    if body_primary:assert caught.value is primary and any('SIG_BLOCK mutated' in n for n in primary.__notes__)
    assert len(blocks)>=selected
    assert real_mask(signal.SIG_BLOCK,[])==mask
    assert all(signal.getsignal(s)is original for s in SIGS)
    assert h.ctx is None and secret._mmap.closed;assert_restored(case)
