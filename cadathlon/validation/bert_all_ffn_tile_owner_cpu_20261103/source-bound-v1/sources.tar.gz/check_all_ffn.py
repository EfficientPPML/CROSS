"""Snapshot and test all12 full-width ideal FFN composition; no HE/model-array archive."""
from pathlib import Path
import argparse,hashlib,importlib.metadata,io,json,os,shutil,signal,subprocess,sys,tarfile,time
HERE=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def inventory():
    files=list((HERE/'checkout').rglob('*.py'))+list(HERE.glob('*.py'))
    files += [HERE/n for n in ('candidate_manifest.json','actual_profile_audit.json','p60_profile_and_refresh.json','source_origin.json','ffn_tensor_pins.json','gelu_refresh_certificate.json','fixture_contract.json','verified_model_manifest.json')]
    return {str(p.relative_to(HERE)):p for p in sorted(files)}
def terminate(process):
    if process.poll() is None:
        try:os.killpg(process.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        try:process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGKILL);process.wait()

def main(output,final):
    output.mkdir(parents=True,exist_ok=False);start=time.monotonic();primary=None;process=None;paths={};before={}
    report=dict(passed=False,scope=__doc__,final_source_bound=final,encrypted_execution=False,
        actual_refresh=False,model_arrays_archived=False,cpu_affinity=sorted(os.sched_getaffinity(0)))
    try:
        save(output/'report.json',report)
        report['software']={name:importlib.metadata.version(name) for name in ('numpy','scipy','pytest')}
        report['python']=sys.version
        report['environment']={name:os.environ.get(name) for name in ('JAX_PLATFORMS','OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS')}
        paths=inventory();before={n:sha(p) for n,p in paths.items()};snapshot=output/'snapshot';snapshot.mkdir()
        for name,path in paths.items():
            target=snapshot/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
        copied={name:sha(snapshot/name) for name in paths}
        if copied!=before:raise ValueError('source changed while snapshotting')
        with tarfile.open(output/'sources.tar.gz','w:gz') as archive:
            for name in paths:
                data=(snapshot/name).read_bytes();member=tarfile.TarInfo(name);member.size=len(data);archive.addfile(member,io.BytesIO(data))
        with tarfile.open(output/'sources.tar.gz') as archive:
            members=archive.getmembers()
            if len(members)!=len({m.name for m in members}) or not all(m.isfile() for m in members):raise ValueError('invalid archive inventory')
            if {m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in members}!=before:raise ValueError('archive bytes differ')
        report.update(source_hashes_before=before,source_archive_sha256=sha(output/'sources.tar.gz'),archive_verified=True)
        tests=['test_all_ffn.py']
        report['tests']=tests;save(output/'report.json',report)
        with (output/'tests.log').open('w') as log:
            process=subprocess.Popen([sys.executable,'-m','pytest','-q',*tests],cwd=snapshot,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            report['child_pid']=process.pid;save(output/'report.json',report);status=process.wait()
        report['test_returncode']=status
        for name in ('fixture_pins.json',*(f'development-FFN-layer{layer}-K{K}.json' for layer in range(12) for K in (15,128))):
            if (snapshot/name).exists():shutil.copy2(snapshot/name,output/name)
        report['cases']={f'{layer}/K{K}':json.loads((output/f'development-FFN-layer{layer}-K{K}.json').read_text()) for layer in range(12) for K in (15,128) if (output/f'development-FFN-layer{layer}-K{K}.json').exists()}
        report['passed']=status==0 and set(report['cases'])=={f'{layer}/K{K}' for layer in range(12) for K in (15,128)} and all(case['passed'] for case in report['cases'].values())
        if not report['passed']:raise RuntimeError('complete all12-layer/two-input FFN composition failed')
    except BaseException as error:primary=error;report['error']=dict(type=type(error).__name__,message=str(error));report['passed']=False
    finally:
        try:
            if process is not None:terminate(process)
            report['child_reaped']=process is None or process.poll() is not None
        except BaseException as error:
            report['passed']=False;report['child_reaped']=False
            if primary is None:primary=error
            else:primary.add_note('Child cleanup: '+repr(error))
        try:
            after={n:sha(p) for n,p in paths.items()};same_inventory=set(inventory())==set(paths)
            report.update(original_hashes_after=after,original_sources_unchanged=bool(before) and before==after and same_inventory)
            if before:
                exact={n:sha(output/'snapshot'/n) for n in paths};report['executed_snapshot_unchanged']=exact==before
                report['passed']=report['passed'] and report['executed_snapshot_unchanged'] and (not final or report['original_sources_unchanged'])
            else:report['passed']=False
            if (output/'fixture_pins.json').exists():
                pins=json.loads((output/'fixture_pins.json').read_text())
                import all_ffn_public_fixtures as fixtures
                contract=json.loads((HERE/'fixture_contract.json').read_text())
                assets=dict(checkpoint_sha256=fixtures.sha(fixtures.MODEL),native_fixture_sha256=fixtures.sha(Path(contract['fixture_path'])),preparation_report_sha256=fixtures.sha(Path(contract['preparation_report_path'])))
                report['assets_after']=assets;report['assets_unchanged']=all(pins[name]==value for name,value in assets.items())
                report['passed']=report['passed'] and report['assets_unchanged']
        except BaseException as error:
            report['passed']=False
            if primary is None:primary=error
            else:primary.add_note('Source readback: '+repr(error))
        report['elapsed_s']=time.monotonic()-start
        try:save(output/'report.json',report)
        except BaseException as error:
            if primary is None:raise
            primary.add_note('Final publication: '+repr(error))
    if primary is not None:raise primary
    return 0 if report['passed'] else 1
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--final',action='store_true')
    args=parser.parse_args();raise SystemExit(main(args.output,args.final))
