"""Pin all48 public FFN tensors directly from the already verified checkpoint."""
from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent
MODEL=Path('/home/jianming_gatech/cross_validation_assets/bert/f150c1d609d1e50dd5e2e5408661cfac8339277c/model.safetensors')
MODEL_SHA='e1f8085ef673c9eb8a1a93a84270742e8aa0ccbceadef01eef15e26c44b46034'
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
    source=sha(Path(__file__));assert sha(MODEL)==MODEL_SHA
    shapes={'intermediate.weight':[3072,768],'intermediate.bias':[3072],'output.weight':[768,3072],'output.bias':[768]};sites={}
    with MODEL.open('rb') as f:
        length=int.from_bytes(f.read(8),'little');header=json.loads(f.read(length));base=length+8
        for layer in range(12):
            site={}
            for name,shape in shapes.items():
                side,leaf=name.split('.');full=f'bert.encoder.layer.{layer}.{side}.dense.{leaf}';desc=header[full]
                assert desc['dtype']=='F32' and desc['shape']==shape
                lo,hi=desc['data_offsets'];f.seek(base+lo);raw=f.read(hi-lo)
                import math
                assert len(raw)==4*math.prod(shape)
                site[name]=dict(source=full,shape=shape,source_f32_sha256=hashlib.sha256(raw).hexdigest())
            sites[str(layer)]=site
    assert sha(MODEL)==MODEL_SHA and sha(Path(__file__))==source
    report=dict(passed=True,checkpoint_sha256=MODEL_SHA,sites=sites,tensors=48,source_sha256=source,scope=__doc__)
    (HERE/'ffn_tensor_pins.json').write_text(json.dumps(report,indent=2)+'\n');print('48 exact public FFN pins verified')
if __name__=='__main__':main()
