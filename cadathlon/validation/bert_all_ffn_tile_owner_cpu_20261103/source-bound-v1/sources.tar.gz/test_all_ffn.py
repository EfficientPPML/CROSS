"""All12 full-width actual-loop ideal FFN composition; no encrypted execution."""
from collections import Counter
from pathlib import Path
import ast,json,math,sys,time
from types import SimpleNamespace
from typing import Sequence,Tuple
import numpy as np
import pytest
from scipy.special import erf
from test_initial_ideal import ideal_primitives
from test_softmax_tile import refresh_and_tracked,IdentityRefresh as BaseRefresh
from ideal_primitives import Arithmetic,Value,IdealLinear,install_matrix_class,DELTA
from encrypted_bert_all_ffn import BertFFNTile,TENSORS,GELU_REFRESH_BOUNDS
from encrypted_bert_all_row_norm import BertRowLayerNorm
from all_ffn_public_fixtures import load
HERE=Path(__file__).resolve().parent;RAW=(HERE/'candidate_manifest.json').read_bytes();MANIFEST=json.loads(RAW)

class IdentityRefresh(BaseRefresh):
    public_bound=128.
    def __init__(self,arithmetic):
        super().__init__(arithmetic)
        from encrypted_refresh import refresh_plan
        self.plan=refresh_plan(131072,65536,(4,4),max_level=49)
        def forbidden(*args,**kwargs):raise AssertionError('compiled crypto helper invoked in identity-refresh ideal test')
        self.compiled_primitives=tuple(SimpleNamespace(ctx=arithmetic.ctx,**{name:forbidden})
            for name in ('rotate','relinearize','rescale','multiply_encoded','multiply'))
    def refresh(self,value,*,public_bound):
        assert public_bound in (2.,128.,16.,32.,64.) and value.level>=2
        self.calls.append((value.level,value._ckks_scale,public_bound))
        result=Value(value.data,self.output_level,math.nextafter(DELTA,math.inf if len(self.calls)%2 else -math.inf))
        if self.inject is not None:self.inject(value,result)
        return result

@pytest.fixture(autouse=True)
def primitives(refresh_and_tracked,monkeypatch):
    install_matrix_class(monkeypatch)
    # Evaluate the unchanged backend-free public rotation/depth methods, rather
    # than accepting a self-reported fake plan or importing the HE backend.
    tree=ast.parse((HERE/'checkout/jaxite_word/bootstrapping.py').read_text())
    names={'_select_layers','_reduce_rotation','_collapsed_hoisted_plan','_bootstrap_rotation_indices'}
    nodes=[node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in names]
    original=next(node for node in tree.body if isinstance(node,ast.ClassDef) and node.name=='Bootstrap')
    methods=[node for node in original.body if isinstance(node,ast.FunctionDef) and node.name in ('compute_bootstrap_nq','required_rotation_indices')]
    namespace=dict(math=math,Sequence=Sequence,Tuple=Tuple)
    stub=ast.ClassDef(name='Bootstrap',bases=[],keywords=[],body=methods,decorator_list=[],type_params=[])
    exec(compile(ast.fix_missing_locations(ast.Module(body=nodes+[stub],type_ignores=[])),'exact_public_bootstrap_plan','exec'),namespace)
    monkeypatch.setitem(sys.modules,'jaxite_word.bootstrapping',SimpleNamespace(Bootstrap=namespace['Bootstrap']))

def test_actual_public_refresh_plan_matches_archived_profile():
    from encrypted_refresh import refresh_plan
    expected=json.loads((HERE/'p60_profile_and_refresh.json').read_text())['refresh_plan']
    actual=refresh_plan(131072,65536,(4,4),max_level=49)
    assert json.loads(json.dumps(actual))==expected
    assert type(actual['level_budget'])is tuple and type(actual['rotations'])is tuple

@pytest.fixture(scope='module')
def arrays():
    result,report=load();(HERE/'fixture_pins.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');return result

def setup(arrays,positions,progress=None,*,layer=0):
    arithmetic=Arithmetic();linear=IdealLinear(arithmetic);refresh=IdentityRefresh(arithmetic)
    model={n:arrays[n] for n in TENSORS[0]}
    keys=set(BertRowLayerNorm.required_rotation_indices())
    for name in ('intermediate','output'):keys.update(linear.required_rotation_indices(model[name+'.weight'],linear.layout))
    cache=arithmetic.ctx._param_cache
    for key in keys:cache.raw_rotation_keys[key]={'a':object(),'b':object()};cache.coef_maps[key]=object()
    owner=BertFFNTile(arithmetic,linear,refresh,model,RAW,arrays['gamma'],arrays['beta'],layer=layer,original_positions=positions,progress=progress)
    return owner,arithmetic,refresh

def independent(x,arrays,*,approximate,layer):
    middle=x@arrays['intermediate.weight'].T+arrays['intermediate.bias']
    gelu=MANIFEST['gelu'][str(layer)]['polynomial'];lo,hi=gelu['domain']
    assert np.all((middle>=lo)&(middle<=hi))
    if approximate:activated=np.polynomial.chebyshev.chebval((2/(hi-lo))*middle-(hi+lo)/(hi-lo),gelu['coefficients'])
    else:activated=.5*middle*(1+erf(middle/np.sqrt(2.)))
    dense=activated@arrays['output.weight'].T+arrays['output.bias'];residual=dense+x
    centered=residual-residual.mean(axis=-1,keepdims=True);variance=np.mean(centered*centered,axis=-1,keepdims=True)+1e-12
    rule=MANIFEST['norms'][f'{layer}.mlp']['polynomial'];lo,hi=rule['domain']
    assert np.all((variance>=lo)&(variance<=hi))
    inverse=np.polynomial.chebyshev.chebval((2/(hi-lo))*variance-(hi+lo)/(hi-lo),rule['coefficients']) if approximate else 1/np.sqrt(variance)
    return dict(middle=middle,activated=activated,dense=dense,residual=residual,variance=variance,
                output=centered*inverse*arrays['gamma']+arrays['beta'])

def public_operation_inventory(arrays,layer):
    from encrypted_packed_qwen import MatrixDiagonals
    from encrypted_chained_streaming_linear import linear_rotation_plan
    maps={};rotations=0;groups=0;diagonals=0
    for name in ('intermediate','output'):
        source=MatrixDiagonals(arrays[name+'.weight'],65536,4096)
        plan=linear_rotation_plan(source,strategy='chained')
        count=len({index//source.n1 for index in source.active})
        maps[name]=dict(active_diagonals=len(source.active),n1=source.n1,giant_groups=count,
            rotations=plan.nonzero_rotation_calls,required_keys=list(plan.required_keys))
        rotations+=plan.nonzero_rotation_calls;groups+=count;diagonals+=len(source.active)
    norm=MANIFEST['norms'][f'{layer}.mlp'];g=MANIFEST['gelu'][str(layer)]['degree'];d=norm['polynomial']['degree']
    if norm['method']=='power':
        coefficients=np.polynomial.chebyshev.cheb2poly(norm['polynomial']['coefficients']);indices=[i for i in range(1,len(coefficients)) if coefficients[i]!=0]
    else:indices=list(range(1,d+1))
    powers={1}
    def visit(n):
        if n not in powers:visit(n//2);visit((n+1)//2);powers.add(n)
    for n in indices:visit(n)
    corrections=0 if norm['method']=='power' else d-1
    norm_terms=4+len(indices)+(0 if norm['method']=='power' else sum(1 if n%2==0 else 2 for n in range(2,d+1)))
    gelu_terms=1+g+sum(1 if n%2==0 else 2 for n in range(2,g+1))
    expected=dict(rotate=rotations+42,weighted_sum=groups+g+1+5+corrections,
        multiply=g-1+len(powers)-1+2,add=groups+44)
    plaintext_terms=diagonals+gelu_terms+norm_terms
    return dict(matrices=maps,norm_method=norm['method'],norm_degree=d,gelu_degree=g,
        per_tile_primitive_calls=expected,per_tile_public_plaintext_terms=plaintext_terms,
        identity_refresh_calls_per_tile=2,full_refresh_cost_included=False)

@pytest.mark.parametrize('layer',range(12))
@pytest.mark.parametrize('K',(15,128))
def test_full_pinned_ffn_all_tiles_against_independent_dense_polynomial(arrays,K,layer):
    arrays=arrays[layer]
    started=time.monotonic();x=arrays[f'K{K}_native'];positions=tuple(map(int,arrays[f'K{K}_original_positions']))
    expected=independent(x,arrays,approximate=True,layer=layer);native=independent(x,arrays,approximate=False,layer=layer)
    operation_plan=public_operation_inventory(arrays,layer)
    polynomial=MANIFEST['gelu'][str(layer)]['polynomial'];lo,hi=polynomial['domain']
    padding=float(np.polynomial.chebyshev.chebval(-(hi+lo)/(hi-lo),polynomial['coefficients']))
    worst={name:0. for name in ('middle','activated','dense','residual','output')};metadata=[];calls=Counter();pt_products=0;refreshes=0
    for start in range(0,K,16):
        valid=min(16,K-start);rows=positions[start:start+valid]
        rng=np.random.default_rng(2026110308+K+start);packed=rng.choice([-100.,100.],(16,4096));packed[:valid,:768]=x[start:start+valid]
        source=Value(packed.reshape(-1),9,math.nextafter(DELTA,math.inf));before=source.data.copy();captured={}
        def progress(label,value,counts):
            mapping={'FFN intermediate dense':'middle','FFN GELU':'activated','FFN output dense':'dense','FFN residual':'residual'}
            if label in mapping:captured[mapping[label]]=value.data.copy()
        owner,ops,refresh=setup(arrays,rows,progress,layer=layer);result=owner.evaluate_tile(source)
        for name,width in (('middle',3072),('activated',3072),('dense',768),('residual',768),('output',768)):
            oracle=np.full((16,4096),padding if name=='activated' else 0.)
            if name=='residual':oracle=packed.copy()
            oracle[:valid,:width]=expected[name][start:start+valid]
            actual=result.output.data if name=='output' else captured[name]
            error=float(np.max(np.abs(actual-oracle.reshape(-1))));worst[name]=max(worst[name],error)
            assert np.isfinite(actual).all() and error<1e-8,(K,start,name,error)
        output=result.output.data.reshape(16,4096)
        assert np.all(output[:valid,768:]==0) and np.all(output[valid:]==0)
        expected_final=24-result.plan['consumed_levels']
        assert result.output.level==expected_final and type(result.output._ckks_nsd)is int and result.output._ckks_nsd==1
        assert result.original_positions==rows
        assert not any(name.startswith('_public_') for name in vars(result.output))
        assert [row['level'] for row in owner.last_run['actual_metadata']]==[25,24,24-(2*math.ceil(math.log2(polynomial['degree']))+2),25,24,24,expected_final]
        assert [item[2] for item in refresh.calls]==[128.,GELU_REFRESH_BOUNDS[layer]]
        np.testing.assert_array_equal(source.data,before)
        assert not owner._active and owner._source is None and not owner._retained
        metadata.append(owner.last_run);calls.update(ops.calls);pt_products+=ops.public_multiplies;refreshes+=len(refresh.calls)
    observations=dict(gelu_input_min=float(expected['middle'].min()),gelu_input_max=float(expected['middle'].max()),
        mlp_variance_min=float(expected['variance'].min()),mlp_variance_max=float(expected['variance'].max()),
        input_max_abs=float(np.abs(x).max()),gelu_max_abs=float(np.abs(expected['activated']).max()))
    tiles=math.ceil(K/16)
    assert dict(calls)=={name:tiles*count for name,count in operation_plan['per_tile_primitive_calls'].items()}
    assert pt_products==tiles*operation_plan['per_tile_public_plaintext_terms'] and refreshes==2*tiles
    report=dict(passed=True,scope=__doc__,layer=layer,K=K,tiles=math.ceil(K/16),physical_slots_checked=65536*math.ceil(K/16),
        actual_loop_vs_independent_polynomial_gate=1e-8,max_abs_errors=worst,
        polynomial_vs_native_function_max_abs=float(np.abs(expected['output']-native['output']).max()),
        native_function_oracle='Independent dense matmul/exact-erf GELU/exact LayerNorm; no new native-framework model run.',
        domain_observations=observations,gelu_padding_polynomial_at_zero=padding,original_positions=list(positions),
        identity_refresh_calls=refreshes,actual_primitive_counts=dict(calls),public_plaintext_products=pt_products,public_operation_plan=operation_plan,
        metadata=metadata,elapsed_s=time.monotonic()-started,encrypted_or_refresh_error_claim=False)
    (HERE/f'development-FFN-layer{layer}-K{K}.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')

@pytest.mark.parametrize('mutation',('arithmetic','linear_arithmetic','norm','refresher','model','positions','context_secret','scale'))
def test_before_entry_changes_reject_without_primitive(arrays,mutation):
    owner,ops,refresh=setup(arrays[0],(0,1))
    if mutation=='arithmetic':owner.arithmetic=Arithmetic()
    elif mutation=='linear_arithmetic':owner.linear.arithmetic=Arithmetic()
    elif mutation=='norm':owner.normalizer=object()
    elif mutation=='refresher':owner.refresher=object()
    elif mutation=='model':owner.model=dict(owner.model)
    elif mutation=='positions':owner.original_positions=(1,0)
    elif mutation=='context_secret':ops.ctx.secret_key=object()
    else:ops.scale*=2
    with pytest.raises((ValueError,TypeError,AttributeError)):owner.evaluate_tile(Value(np.zeros(65536),9))
    assert not ops.calls and not refresh.calls

def test_callback_cancellation_preserves_borrowed_owners(arrays):
    error=KeyboardInterrupt('stop after initial refresh')
    def progress(*args):raise error
    owner,ops,refresh=setup(arrays[0],(0,1),progress)
    with pytest.raises(KeyboardInterrupt) as caught:owner.evaluate_tile(Value(np.zeros(65536),9))
    assert caught.value is error and owner.arithmetic is ops and owner.linear.ctx is ops.ctx
    assert not owner._active and owner._source is None and not owner._retained and owner.last_run is None
    assert not ops.calls and len(refresh.calls)==1


def test_fixed_all_layer_public_pin_and_bound_inventory():
    import hashlib
    from encrypted_bert_all_gelu import MANIFEST_SHA256
    pin=json.loads((HERE/'ffn_tensor_pins.json').read_text());proof=json.loads((HERE/'gelu_refresh_certificate.json').read_text())
    assert pin['passed'] and pin['tensors']==48 and proof['passed'] and proof['manifest_sha256']==MANIFEST_SHA256
    assert len(TENSORS)==len(GELU_REFRESH_BOUNDS)==12
    for layer in range(12):
        assert set(TENSORS[layer])=={'intermediate.weight','intermediate.bias','output.weight','output.bias'}
        for name,(shape,digest) in TENSORS[layer].items():
            assert tuple(pin['sites'][str(layer)][name]['shape'])==shape
            assert pin['sites'][str(layer)][name]['source_f32_sha256']==digest
        c=MANIFEST['gelu'][str(layer)]['polynomial'];r=proof['sites'][str(layer)]
        assert r['refresh_bound']==GELU_REFRESH_BOUNDS[layer] and r['degree']==c['degree'] and r['domain']==c['domain']
        assert r['coefficient_sha256']==hashlib.sha256(np.asarray(c['coefficients'],dtype='<f8').tobytes()).hexdigest()

@pytest.mark.parametrize('layer',[True,False,0.,'0',-1,12,None])
def test_layer_selection_rejected_before_refresh(arrays,layer):
    with pytest.raises((ValueError,TypeError)):
        setup(arrays[0],(0,),layer=layer)

@pytest.mark.parametrize('mutation',['layer_type','layer_value','gelu_bound_type','gelu_bound_value','gelu_layer','norm_site'])
def test_layer_bound_cross_component_identity(arrays,mutation):
    owner,ops,refresh=setup(arrays[1],(0,),layer=1)
    if mutation=='layer_type':owner.layer=1.
    elif mutation=='layer_value':owner.layer=2
    elif mutation=='gelu_bound_type':owner.gelu_bound=int(owner.gelu_bound)
    elif mutation=='gelu_bound_value':owner.gelu_bound=16.
    elif mutation=='gelu_layer':object.__setattr__(owner.gelu.contract,'layer',2)
    else:object.__setattr__(owner.normalizer.contract,'site','2.mlp')
    with pytest.raises((ValueError,TypeError)):owner.evaluate_tile(Value(np.zeros(65536),2))
    assert not ops.calls and not refresh.calls

@pytest.mark.parametrize('bound',[True,16,32,64,128,8.,256.,float('nan')])
def test_new_binding_only_exact_supported_bounds(arrays,bound):
    owner,ops,refresh=setup(arrays[0],(0,))
    with pytest.raises(ValueError):owner.refresh_binding.refresh(Value(np.zeros(65536),2),public_bound=bound)
    assert not ops.calls and not refresh.calls

@pytest.mark.parametrize('name',list(TENSORS[0]))
def test_other_layer_rehashed_or_edited_weight_rejected(arrays,name):
    from encrypted_bert_all_ffn import freeze_weights
    bad={n:arrays[0][n].copy() for n in TENSORS[0]};bad[name].flat[0]=np.nextafter(bad[name].flat[0],np.inf)
    with pytest.raises(ValueError):freeze_weights(bad,0)
    with pytest.raises(ValueError):freeze_weights({n:arrays[1][n] for n in TENSORS[1]},0)


def test_callback_preserves_source_and_strips_current_retained_annotations(arrays):
    data=arrays[0]['K15_native'][:1];packed=np.full((16,4096),-100.);packed[0,:768]=data[0]
    source=Value(packed.ravel(),2);source._public_example='borrowed';retained=[]
    def progress(label,value,counts):
        retained.append(value)
        for previous in retained:previous._public_abs_bound=0.
        with pytest.raises(ValueError,match='reentered'):owner.evaluate_tile(source)
    owner,ops,refresh=setup(arrays[0],(0,),progress)
    result=owner.evaluate_tile(source)
    assert source._public_example=='borrowed'
    assert not any(n.startswith('_public_') for n in vars(result.output))
    assert not owner._active and not owner._retained and owner._source is None

@pytest.mark.parametrize('stage',['FFN input B128 refresh','FFN GELU refresh','FFN residual'])
@pytest.mark.parametrize('mutation',['source','retained','context'])
def test_callbacks_guard_live_branches_before_next_work(arrays,stage,mutation):
    data=arrays[0]['K15_native'][:1];packed=np.zeros((16,4096));packed[0,:768]=data[0]
    source=Value(packed.ravel(),2);remember=[];seen=[]
    def progress(label,value,counts):
        if label=='FFN input B128 refresh':remember.append(value)
        if label!=stage:return
        seen.append(len(ops.calls))
        if mutation=='source':source._ckks_nsd=True
        elif mutation=='retained':remember[0]._ckks_nsd=True
        else:ops.ctx._param_cache.secret_key=object()
    owner,ops,refresh=setup(arrays[0],(0,),progress)
    with pytest.raises(ValueError):owner.evaluate_tile(source)
    assert seen==[len(ops.calls)] and not owner._active and not owner._retained and owner._source is None

@pytest.mark.parametrize('layer',range(12))
@pytest.mark.parametrize('K',(15,128))
def test_fixed_component_inputs_declared_domains(arrays,layer,K):
    model=arrays[layer];x=model[f'K{K}_native'];result=independent(x,model,approximate=True,layer=layer)
    assert float(np.abs(x).max())<128.
    assert float(np.abs(result['activated']).max())<GELU_REFRESH_BOUNDS[layer]
    assert float(np.abs(result['output']).max())<128.


@pytest.mark.parametrize('bound',[2.,16.,32.,64.,128.])
def test_binding_explicit_float_allowlist(arrays,bound):
    owner,ops,refresh=setup(arrays[0],(0,))
    source=Value(np.zeros(65536),2);result=owner.refresh_binding.refresh(source,public_bound=bound)
    assert result.level==25 and refresh.calls[-1][2]==bound and source.level==2
    assert not ops.calls and not owner.refresh_binding._active
