"""Client-only pinned public weights and fixed native attention-output inputs."""
from pathlib import Path
import hashlib,json
import numpy as np
HERE=Path(__file__).resolve().parent
MODEL=Path('/home/jianming_gatech/cross_validation_assets/bert/f150c1d609d1e50dd5e2e5408661cfac8339277c/model.safetensors')
MODEL_SHA='e1f8085ef673c9eb8a1a93a84270742e8aa0ccbceadef01eef15e26c44b46034'
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load():
    from encrypted_bert_all_ffn import TENSORS
    from encrypted_bert_all_row_norm import AFFINE_SHA256
    pin=json.loads((HERE/'fixture_contract.json').read_text());fixture=Path(pin['fixture_path']);prep=Path(pin['preparation_report_path'])
    if sha(MODEL)!=MODEL_SHA or sha(fixture)!=pin['fixture_npz_sha256'] or sha(prep)!=pin['preparation_report_sha256']:raise ValueError('pinned public checkpoint/native input changed')
    report=json.loads(prep.read_text())
    if report['passed'] is not True:raise ValueError('successful trusted native preparation required')
    arrays={};records={}
    with MODEL.open('rb') as f:
        length=int.from_bytes(f.read(8),'little');header=json.loads(f.read(length));base=length+8
        for layer in range(12):
            result={};rows={}
            for name,(shape,expected) in dict(TENSORS[layer],gamma=((768,),AFFINE_SHA256[f'{layer}.mlp'][0]),beta=((768,),AFFINE_SHA256[f'{layer}.mlp'][1])).items():
                if name in ('gamma','beta'):full=f'bert.encoder.layer.{layer}.output.LayerNorm.'+('weight' if name=='gamma' else 'bias')
                else:
                    side,leaf=name.split('.');full=f'bert.encoder.layer.{layer}.{side}.dense.{leaf}'
                d=header[full]
                if d['dtype']!='F32' or d['shape']!=list(shape):raise ValueError('exact public tensor shape/dtype')
                lo,hi=d['data_offsets'];f.seek(base+lo);raw=f.read(hi-lo)
                if len(raw)!=4*int(np.prod(shape)) or hashlib.sha256(raw).hexdigest()!=expected:raise ValueError('pinned public tensor bytes')
                result[name]=np.frombuffer(raw,dtype='<f4').reshape(shape).astype('<f8')
                rows[name]=dict(source=full,shape=list(shape),source_f32_sha256=expected,exact_f64_lift=True)
            arrays[layer]=result;records[str(layer)]=rows
    names={f'layer{layer}_K{K}_native' for layer in range(12) for K in (15,128)}|{'K15_positions','K128_positions'}
    with np.load(fixture,allow_pickle=False) as archive:
        if set(archive.files)!=names:raise ValueError('exact native input inventory')
        for name in names:
            a=archive[name];record=report['arrays'][name]
            if list(a.shape)!=record['shape'] or a.dtype.str!=record['dtype'] or hashlib.sha256(a.tobytes()).hexdigest()!=record['sha256'] or not np.isfinite(a).all():raise ValueError('native array binding')
            if name.endswith('_positions'):
                K=int(name.split('_')[0][1:])
                if a.shape!=(K,) or a.dtype.kind not in 'iu' or any(type(int(x))is not int or not 0<=int(x)<128 for x in a) or list(a)!=sorted(set(a.tolist())):raise ValueError('strict original positions')
                for layer in range(12):arrays[layer][f'K{K}_original_positions']=a.copy()
            else:
                layer=int(name.split('_')[0][5:]);K=int(name.split('_')[1][1:])
                if a.dtype!=np.dtype('<f8') or a.shape!=(K,768):raise ValueError('native input shape/dtype')
                arrays[layer][f'K{K}_native']=a.copy()
    return arrays,dict(passed=True,checkpoint_sha256=MODEL_SHA,native_fixture_sha256=pin['fixture_npz_sha256'],preparation_report_sha256=pin['preparation_report_sha256'],layers=records,native_array_hashes=report['arrays'],scope='Public exact checkpoint weights and fixed client-only native component inputs; no joint approximate trajectory or HE claim.')
