"""One unchanged original stage body per process, explicit synthetic receipts."""
from pathlib import Path
import json,os,sys,time
import integration_common as common
import ranked_execution as execution
from ranked_terminal import finish
from cleanup import cleanup_signals
from terminal import terminal_scope


def _hash(path):return common.digest(Path(path).read_bytes())
def _input_hashes(name,paths):
    # Public-server stages never inspect client input/secret/reference bodies.
    fields={'client_preprocess_input':('test_input',),'client_encode_encrypt_input':('preprocessed_input',),
        'client_decrypt_decode':('preprocessed_input',),'client_postprocess':('preprocessed_input','decrypted_results')} .get(name,())
    return {n:_hash(paths[n]) for n in fields}

def _public(paths):
    p=paths['public_keys']/'public_manifest.json'
    return common.read(p) if p.exists() else None

def run(name,root):
    started=time.monotonic();report=dict(passed=False,synthetic=True,genuine_eligible=False,stage=name,pid=os.getpid(),
        handler_started=False,handler_completed=False,source_files_unchanged=False,cleanup_completed=False)
    primary=None;cleanup_error=None;held=None;config=None;ordinal=None;state=None;old_umask=os.umask(0o077)
    try:
        config,config_sha=common.invocation(root)
        if name not in common.NAMES:raise ValueError('known original entrypoint required')
        state=common.read(root/'stage_state.json');ordinal=state['next_stage'];order=common.sequence(config['num_runs'])
        if type(ordinal)is not int or not 0<=ordinal<len(order) or order[ordinal]!=name or state['invocation_id']!=config['invocation_id']:raise ValueError('fresh setup/online stage order differs')
        for i in range(ordinal):
            raw=(root/'provenance'/f'{i:03d}.json').read_bytes();old=json.loads(raw)
            if (old.get('passed')is not True or old.get('terminal_scope_completed')is not True or old.get('termination_scope_completed')is not True
                    or old.get('invocation_sha256')!=config_sha or old.get('source_inventory_sha256')!=config['source_inventory_sha256']
                    or old.get('ordinal')!=i or old.get('stage')!=order[i] or old.get('previous_receipt_sha256')!=(None if i==0 else _hash(root/'provenance'/f'{i-1:03d}.json'))):raise ValueError('complete ordered source-bound stage receipt required')
        if state.get('previous_receipt_sha256')!=(None if ordinal==0 else _hash(root/'provenance'/f'{ordinal-1:03d}.json')):raise ValueError('latest receipt binding differs')
        adapter=execution.adapter();paths=adapter.stage_paths(root,config['size'])
        for value in paths.values():
            if isinstance(value,Path):
                for candidate in (value,*value.parents):
                    if candidate==root:break
                    if candidate.is_symlink():raise ValueError('stage paths cannot traverse aliases')
        # There is no implicit genuine fallback: both environment and the
        #typed invocation must authorize the separately named synthetic code.
        import synthetic_backend
        synthetic_backend.install()
        import ranked_entrypoints as entry,file_stages,ranked_readback as readback
        held=execution.HeldDirectory(root)
        report.update(ordinal=ordinal,invocation_id=config['invocation_id'],invocation_sha256=config_sha,source_inventory_sha256=config['source_inventory_sha256'],
            size=config['size'],seed=config['seed'],count=config['count'],run_number=0 if ordinal<2 else (ordinal-2)//5+1,
            previous_receipt_sha256=state.get('previous_receipt_sha256'),entrypoint_sha256=_hash(root/'submissions'/f'{name}.py'),
            input_hashes_before=_input_hashes(name,paths),original_body='upstream stages.py' if name in ('client_preprocess_input','client_postprocess') else 'unchanged full file_stages.py')
        if name=='client_key_generation':
            if any(paths[n].exists() for n in ('public_keys','client_private')):raise ValueError('fresh per-invocation keys required')
        elif name=='server_preprocess_model':
            if paths['server_data'].exists():raise ValueError('fresh per-invocation public model required')
        else:
            public=_public(paths)
            if public['context_id']!=state['context_id']:raise ValueError('fresh setup context differs')
        handler=entry.resolve(name)
        body=Path(handler.__code__.co_filename).resolve()
        relative='parent/upstream_adapter/stages.py' if name in ('client_preprocess_input','client_postprocess') else 'parent/runtime/stage/file_stages.py'
        if body!=(common.HERE/relative).resolve() or _hash(body)!=config['source_hashes'][relative]:raise ValueError('actual installed entrypoint body differs')
        report.update(original_body_source=relative,original_body_sha256=_hash(body),synthetic_backend_sha256=_hash(common.HERE/'synthetic_backend.py'))
        report['handler_started']=True
        result=entry.invoke(name,paths);report['handler_completed']=True
        public=_public(paths);report['context_id']=public['context_id']
        if name=='client_key_generation':
            if result['context_id']!=public['context_id']:raise ValueError('key handler result differs')
        elif name=='server_preprocess_model':
            model=common.read(paths['server_data']/public['context_id']/'model_manifest.json');report['model_id']=model['model_id']
            if result['context_id']!=public['context_id'] or result['model_id']!=model['model_id']:raise ValueError('model handler result differs')
        elif name=='client_preprocess_input':
            records=[json.loads(s) for s in paths['preprocessed_input'].read_text().splitlines()]
            if len(records)!=config['count']:raise ValueError('complete fresh tokenization required')
            report['preprocessed_input_sha256']=_hash(paths['preprocessed_input']);report['record_count']=len(records)
        elif name in ('client_encode_encrypt_input','server_encrypted_compute','client_decrypt_decode'):
            if type(result.get('sample_count'))is not int or result['sample_count']!=config['count']:raise ValueError('complete ordered handler count required')
            batch=common.read(paths['upload']/'batch.json')
            if batch['public']['context_id']!=public['context_id']:raise ValueError('request context differs')
            if name=='client_encode_encrypt_input':
                summary,_=readback.requests(paths,public=batch['public'],count=config['count'],expected_batch_sha256=result['public_batch_sha256'])
                report.update(record_count=summary['sample_count'],tile_count=summary['tile_count'],public_batch_sha256=summary['public_batch_sha256'],
                    simulated_logical_payload_bytes=summary['ciphertext_payload_bytes'],ordered_request_ids=[row['contract']['request_id'] for row in batch['requests']])
            elif name=='server_encrypted_compute':
                summary=readback.responses(paths,batch=batch);report.update(record_count=summary['sample_count'],response_count=summary['response_count'],response_batch_sha256=summary['response_batch_sha256'])
            else:
                decoded=[json.loads(s) for s in paths['decrypted_results'].read_text().splitlines()]
                receipt=common.read(paths['client_private']/'completed.json')
                if len(decoded)!=config['count'] or len(receipt['nonces'])!=config['count']:raise ValueError('complete decoded/receipt inventory required')
                report.update(record_count=len(decoded),completion_receipt_sha256=_hash(paths['client_private']/'completed.json'))
        else:
            tokens=[json.loads(s) for s in paths['preprocessed_input'].read_text().splitlines()]
            records=[json.loads(s) for s in paths['decrypted_results'].read_text().splitlines()]
            predictions=[int(s) for s in paths['predictions'].read_text().splitlines()]
            if len(predictions)!=config['count'] or [r['target_idx'] for r in tokens]!=[r['target_idx'] for r in records] or predictions!=[readback.label(r['he_logits']) for r in records]:raise ValueError('original postprocessing/order/tie rule differs')
            truth=[int(s) for s in paths['test_input'].with_name('test_labels.txt').read_text().splitlines()]
            if len(truth)!=config['count'] or any(x not in (0,1) for x in truth):raise ValueError('complete synthetic labels required')
            report.update(synthetic_correct=sum(a==b for a,b in zip(truth,predictions)),target_order_sha256=common.digest(common.canonical([r['target_idx'] for r in tokens])),label_sha256=_hash(paths['test_input'].with_name('test_labels.txt')),record_count=len(predictions),prediction_sha256=_hash(paths['predictions']),preprocessed_input_sha256=_hash(paths['preprocessed_input']))
        if report['input_hashes_before']!=_input_hashes(name,paths):raise ValueError('original stage input changed')
        held.check();common.invocation(root)
        report.update(passed=True,source_files_unchanged=True)
    except BaseException as error:
        primary=error;report.update(passed=False,error={'type':type(error).__name__,'message':'stage failed; synthetic/private values withheld'})
    finally:
        def attempt(label,call):
            nonlocal cleanup_error
            try:call()
            except BaseException as error:
                report.setdefault('cleanup_errors',[]).append({'operation':label,'type':type(error).__name__})
                if primary is not None:primary.add_note(label+': '+type(error).__name__)
                elif cleanup_error is None or (not isinstance(error,Exception) and isinstance(cleanup_error,Exception)):cleanup_error=error
        path=root/'provenance'/f'{ordinal:03d}.json' if ordinal is not None else root/'early_stage_failure.json'
        with terminal_scope(report,path,common.write,cleanup_signals,lambda:(primary,cleanup_error)):
            if held is not None:attempt('borrowed root close',held.close)
            attempt('restore umask',lambda:os.umask(old_umask))
            report.update(cleanup_completed=cleanup_error is None,elapsed_s=time.monotonic()-started)
            report['passed']=bool(report['passed'] and primary is None and cleanup_error is None)
            attempt('stage terminal publication',lambda:common.write(path,report))
            if primary is not None:raise primary
            if cleanup_error is not None:raise cleanup_error
    return report


def main(name,root):
    # The CLI accepts precisely the original single size argument; no reduced
    #count, internal batch, alternate seed or backend can be smuggled in argv.
    config,_=common.invocation(root)
    if len(sys.argv)!=2 or sys.argv[1]!=str(config['size']):raise SystemExit('exact original size argument required')
    state=common.read(root/'stage_state.json');ordinal=state['next_stage'];path=root/'provenance'/f'{ordinal:03d}.json'
    try:
        report=finish(path,lambda:run(name,root),common.write)
        if not report['passed']:raise ValueError('stage did not complete')
        # Advance only after the complete terminal receipt exists. Failed
        #publication preserves the prior ordinal and never authorizes a retry.
        state.update(next_stage=ordinal+1,previous_receipt_sha256=_hash(path),context_id=report['context_id'])
        if 'model_id' in report:state['model_id']=report['model_id']
        common.write(root/'stage_state.json',state)
    except BaseException as error:
        try:
            failed=common.read(path);failed.update(passed=False,transition_completed=False,error={'type':type(error).__name__,'message':'stage terminal/state transition failed'})
            common.write(path,failed)
        except BaseException as secondary:error.add_note('stage transition failed republication: '+type(secondary).__name__)
        print(json.dumps({'passed':False,'error_type':type(error).__name__,'synthetic':True}));raise SystemExit(130 if not isinstance(error,Exception) else 1)
    print(json.dumps({'passed':True,'stage':name,'synthetic':True,'genuine_eligible':False,'receipt_sha256':_hash(path)}))
