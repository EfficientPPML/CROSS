"""Public source/attempt protocol for an isolated seven-process integration."""
from pathlib import Path
import hashlib,json,os,stat,sys
HERE=Path(__file__).resolve().parent
PARENT=HERE/'parent'
sys.path[:0]=[str(HERE),str(PARENT),str(PARENT/'runtime/stage'),str(PARENT/'joined'),str(PARENT/'joined/checkout/cadathlon/common'),str(PARENT/'runtime')]
import key_gate
NAMES=('client_key_generation','server_preprocess_model','client_preprocess_input','client_encode_encrypt_input','server_encrypted_compute','client_decrypt_decode','client_postprocess')
COUNTS={1:100,2:200,3:408}

def canonical(value):return key_gate.canonical(value)
def digest(value):return hashlib.sha256(value).hexdigest()
def read(path,limit=16<<20):return key_gate.parse(key_gate.read(path,limit))
def write(path,value):
    path=Path(path);temp=path.with_suffix('.tmp');temp.write_bytes(canonical(value));temp.replace(path)
def sources():
    expected=read(HERE/'parent_source_manifest.json')
    if {n:digest((PARENT/n).read_bytes()) for n in expected}!=expected:raise ValueError('frozen272 parent closure changed')
    paths={f'parent/{n}':PARENT/n for n in expected}
    for directory in ('upstream','synthetic_modules'):
        paths.update({p.relative_to(HERE).as_posix():p for p in (HERE/directory).rglob('*') if p.is_file() and p.suffix in ('.py','.json')})
    for p in HERE.iterdir():
        if p.is_file() and p.suffix in ('.py','.json'):paths[p.name]=p
    return {n:p.read_bytes() for n,p in sorted(paths.items())}
def hashes(raw):return {n:digest(b) for n,b in raw.items()}
def sequence(num_runs):
    if type(num_runs)is not int or not 1<=num_runs<=2:raise ValueError('default1 or explicit repeat2 preflight only')
    return NAMES[:2]+NAMES[2:]*num_runs

def invocation(root):
    root=Path(root).absolute();raw=key_gate.read(root/'invocation.json',4<<20);config=key_gate.parse(raw)
    fields={'schema','execution_mode','genuine_eligible','invocation_id','size','count','seed','num_runs','root_identity','source_hashes','source_inventory_sha256','harness_hashes'}
    if type(config)is not dict or set(config)!=fields or config['schema']!='cross-ranked-seven-process-preflight-v1':raise ValueError('exact integration invocation schema required')
    if config['execution_mode']!='synthetic-preflight' or config['genuine_eligible']is not False:raise ValueError('actual ranked launch remains disabled pending reviewed size0/resource gates')
    if type(config['size'])is not int or config['size'] not in COUNTS or type(config['count'])is not int or config['count']!=COUNTS[config['size']] or type(config['seed'])is not int or config['seed'] not in (42,43,44):raise ValueError('fixed ranked size/seed/count required')
    sequence(config['num_runs']);info=root.lstat()
    if not stat.S_ISDIR(info.st_mode) or [info.st_dev,info.st_ino]!=config['root_identity'] or stat.S_IMODE(info.st_mode)!=0o700:raise ValueError('fresh owned integration root identity differs')
    # Upstream creates and removes these paths before any staged entrypoint.
    #Reject aliases before invoking that unchanged initialization code.
    folder={1:'small',2:'medium',3:'large'}[config['size']]
    for relative in ('io','datasets','measurements','harness','submissions','provenance','_source',
                     f'io/{folder}',f'io/{folder}/intermediate','io/server_data',
                     f'datasets/{folder}',f'datasets/{folder}/intermediate',f'measurements/{folder}'):
        p=root/relative
        if p.is_symlink():raise ValueError('owned integration paths cannot traverse aliases')
    template=(HERE/'entry_template.py').read_bytes()
    if {p.name for p in (root/'submissions').iterdir()}!={n+'.py' for n in NAMES}:raise ValueError('exact seven original entrypoint wrappers required')
    if any(key_gate.read(root/'submissions'/(n+'.py'))!=template for n in NAMES):raise ValueError('staged executable wrapper differs from source snapshot')
    current=hashes(sources())
    if current!=config['source_hashes'] or digest(canonical(current))!=config['source_inventory_sha256']:raise ValueError('exact integration source identity differs')
    pins=read(HERE/'upstream/manifest.json')
    if pins!=config['harness_hashes'] or {n:digest((root/n).read_bytes()) for n in pins}!=pins:raise ValueError('unchanged complete original harness required')
    return config,digest(raw)
