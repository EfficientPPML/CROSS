"""One of seven real subprocess entrypoints in the owned staged integration."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'_source'))
from stage_entry import main
if __name__=='__main__':main(Path(__file__).stem,ROOT)
