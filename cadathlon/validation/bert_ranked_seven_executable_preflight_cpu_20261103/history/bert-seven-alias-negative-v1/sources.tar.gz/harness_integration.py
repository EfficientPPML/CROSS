"""Isolated, explicitly synthetic execution of the pinned original harness.

This does not authorize an actual ranked batch. The original source dispatches
all seven processes, native verification, size logging and steps5–9 timers.
"""
from pathlib import Path
import io,json,os,shutil,sys,tarfile,uuid
import integration_common as common
import ranked_execution as execution
import check_transformer_suite as process
PYTHON=Path('/tmp/cross-pretrained-validation-env/bin/python')


def archive(path,raw):
    with tarfile.open(path,'w:gz') as out:
        for name,data in sorted(raw.items()):
            info=tarfile.TarInfo(name);info.size=len(data);out.addfile(info,io.BytesIO(data))
def verify_archive(path,expected):
    with tarfile.open(path) as out:
        rows=out.getmembers()
        return len(rows)==len(expected)==len({r.name for r in rows}) and all(r.isfile() for r in rows) and {r.name:common.digest(out.extractfile(r).read()) for r in rows}==expected


def prepare(root,*,size,seed,num_runs=1,execution_mode='synthetic-preflight'):
    # A new child of a caller-created isolated lab is required. Existing roots,
    #symlinks, retained production paths and a genuine mode are never adopted.
    if execution_mode!='synthetic-preflight':raise ValueError('actual ranked execution not authorized by this preflight')
    if type(size)is not int or size not in common.COUNTS or type(seed)is not int or seed not in (42,43,44):raise ValueError('exact ranked size and seed required')
    common.sequence(num_runs)
    root=Path(root).absolute()
    if root.exists() or root.is_symlink():raise FileExistsError('fresh isolated root required')
    if root.parent.resolve()!=root.parent or root.parent==Path('/tmp') or not (root.parent/'.synthetic_integration_parent').is_file():raise ValueError('explicit isolated synthetic parent required')
    raw=common.sources();expected=common.hashes(raw);root.mkdir(mode=0o700)
    try:
        source=root/'_source';source.mkdir(mode=0o700)
        for name,data in raw.items():
            p=source/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
        for name,h in common.read(common.HERE/'upstream/manifest.json').items():
            data=raw['upstream/'+name]
            if common.digest(data)!=h:raise ValueError('original harness source differs')
            p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
        (root/'submissions').mkdir();(root/'provenance').mkdir()
        for name in common.NAMES:(root/'submissions'/(name+'.py')).write_bytes(raw['entry_template.py'])
        info=root.lstat();nonce=uuid.uuid4().hex
        config=dict(schema='cross-ranked-seven-process-preflight-v1',execution_mode=execution_mode,genuine_eligible=False,
            invocation_id=nonce,size=size,count=common.COUNTS[size],seed=seed,num_runs=num_runs,root_identity=[info.st_dev,info.st_ino],
            source_hashes=expected,source_inventory_sha256=common.digest(common.canonical(expected)),harness_hashes=common.read(common.HERE/'upstream/manifest.json'))
        common.write(root/'invocation.json',config)
        common.write(root/'stage_state.json',dict(invocation_id=nonce,next_stage=0,previous_receipt_sha256=None,context_id=None))
        return config
    except BaseException:
        # Preserve partial preparation for evidence. Never sweep the parent.
        raise


def run_prepared(root,evidence,*,python=PYTHON):
    root=Path(root);evidence=Path(evidence);evidence.mkdir(parents=True,exist_ok=False)
    source=root/'_source';config=common.read(root/'invocation.json')
    old=process.child_environment_overrides
    process.child_environment_overrides=lambda:dict(JAX_PLATFORMS='cpu',PYTHONUNBUFFERED='1',CROSS_RANKED_SYNTHETIC_ONLY='1',
        PYTHONPATH=str(source/'synthetic_modules'),PATH=str(python.parent)+os.pathsep+os.environ['PATH'],
        HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
    try:
        record=process.run_case([str(python),str(source/'harness_worker.py'),'--root',str(root)],evidence,timeout=None,cleanup_grace_s=30.)
    finally:process.child_environment_overrides=old
    proof=common.read(root/'harness_report.json') if (root/'harness_report.json').exists() else None
    passed=(record.get('returncode')==0 and not record.get('error') and all(record.get(n)is True for n in ('process_reaped','public_key_store_removed','owned_directory_handle_closed'))
        and type(proof)is dict and proof.get('passed')is True and proof.get('termination_scope_completed')is True
        and record.get('result')==dict(passed=True,synthetic=True,genuine_eligible=False,report_sha256=common.digest((root/'harness_report.json').read_bytes())))
    report=dict(passed=bool(passed),synthetic=True,genuine_eligible=False,process=record,proof=proof,source_inventory_sha256=config['source_inventory_sha256'])
    common.write(evidence/'result.json',report)
    return report
