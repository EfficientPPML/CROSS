"""Independent original timer/order and synthetic readback obligations."""
from pathlib import Path
from types import SimpleNamespace as NS
from datetime import datetime,timedelta
from decimal import Decimal
import ast,hashlib,json
import pytest
import integration_common as common
import harness_readback as readback
import ranked_timing as timing

HERE=Path(__file__).resolve().parent
UPSTREAM=HERE/'upstream/harness'


def test_all_original_harness_pins_and_three_timing_sources():
    pins=json.loads((HERE/'upstream/manifest.json').read_bytes())
    assert len(pins)==11
    assert {n:hashlib.sha256((HERE/'upstream'/n).read_bytes()).hexdigest() for n in pins}==pins
    assert timing.verify_harness_sources({n:(UPSTREAM/n).read_bytes() for n,_ in timing.SOURCE_PINS})


def test_original_dispatch_and_timer_placement():
    tree=ast.parse((UPSTREAM/'run_submission.py').read_bytes())
    main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
    repeat=next(n for n in main.body if isinstance(n,ast.For) and ast.unparse(n.iter)=='range(num_runs)')
    def calls(nodes,name):
        return [n for block in nodes for n in ast.walk(block) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr==name]
    dispatch=calls(repeat.body,'run_exe_or_python')
    actual=[n.args[1].value for n in dispatch if len(n.args)>1 and isinstance(n.args[1],ast.Constant)]
    assert actual[:6]==['generate_input',*common.NAMES[2:]]
    assert 'cleartext_impl' in actual
    before=[n for n in main.body if n.lineno<repeat.lineno]
    setup=[n.args[1].value for n in calls(before,'run_exe_or_python')]
    assert setup==['generate_dataset','client_key_generation','server_preprocess_model']
    positions={}
    for n in ast.walk(repeat):
        if not isinstance(n,ast.Call) or not isinstance(n.func,ast.Attribute):continue
        if n.func.attr=='log_step' and n.args and isinstance(n.args[0],ast.Constant):positions[('step',n.args[0].value)]=n.lineno
        if n.func.attr=='log_size':positions[('size',n.args[1].value)]=n.lineno
    assert positions['step',6]<positions['size','Encrypted input']<positions['step',7]
    assert positions['step',7]<positions['size','Encrypted results']<positions['step',8]
    assert positions['step',9]<positions['step',10.1]<positions['step',10.2]


def test_original_default_repeat_and_rng_reset_are_literal():
    utils=ast.parse((UPSTREAM/'utils.py').read_bytes())
    arg=next(n for n in ast.walk(utils) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='add_argument' and n.args and isinstance(n.args[0],ast.Constant) and n.args[0].value=='--num_runs')
    assert ast.literal_eval(next(k.value for k in arg.keywords if k.arg=='default'))==1
    tree=ast.parse((UPSTREAM/'run_submission.py').read_bytes())
    loop=next(n for n in ast.walk(tree) if isinstance(n,ast.For) and ast.unparse(n.iter)=='range(num_runs)')
    assignments=[ast.unparse(n) for n in ast.walk(loop) if isinstance(n,ast.Assign)]
    assert 'rng = np.random.default_rng(seed)' in assignments
    assert 'genqry_seed = rng.integers(0, 2147483647)' in assignments
    assert common.sequence(1)==common.NAMES
    assert common.sequence(2)==common.NAMES[:2]+common.NAMES[2:]*2
    with pytest.raises(ValueError):common.sequence(True)


def test_production_timer_includes_intervening_size_work():
    source=ast.parse((UPSTREAM/'utils.py').read_bytes())
    nodes=[n for n in source.body if isinstance(n,ast.FunctionDef) and n.name in ('log_step','log_size','human_readable_size')]
    clock=[datetime(2020,1,1)]
    def du(*args,**kwargs):clock[0]+=timedelta(seconds=2.5);return NS(stdout='123 path')
    ns=dict(datetime=NS(now=lambda:clock[0]),Path=Path,TextFormat=NS(BLUE='',RESET='',YELLOW=''),
        subprocess=NS(run=du),_last_timestamp=None,_timestamps={},_timestampsStr={},_bandwidth={})
    exec(compile(ast.Module(body=nodes,type_ignores=[]),'actual_original_utils_ast','exec'),ns)
    ns['log_step'](0,'Init',True)
    clock[0]+=timedelta(seconds=1.234567);ns['log_step'](6,'Input encryption')
    ns['log_size'](NS(exists=lambda:True),'Encrypted input')
    clock[0]+=timedelta(seconds=3.25);ns['log_step'](7,'Encrypted computation')
    assert ns['_timestampsStr']['Input encryption']=='1.2346s'
    assert ns['_timestampsStr']['Encrypted computation']=='5.75s'
    assert ns['_timestamps']['Encrypted computation']==5.75


def fake_readback(tmp_path,monkeypatch,*,num_runs=1,first_correct=100):
    root=tmp_path/'root';root.mkdir();(root/'provenance').mkdir();(root/'submissions').mkdir()
    count=100;config=dict(size=1,count=count,seed=42,num_runs=num_runs,invocation_id='1'*32,source_inventory_sha256='2'*64,harness_hashes={str(i):'a'*64 for i in range(11)})
    config_sha='3'*64;context='4'*64;input_sha='5'*64
    truth_raw=('0\n'*count).encode();pred=root/'predictions';pred.write_bytes(truth_raw)
    truth=root/'datasets/small/intermediate/test_labels.txt';truth.parent.mkdir(parents=True);truth.write_bytes(truth_raw)
    native=root/'io/small/harness_model_predictions.txt';native.parent.mkdir(parents=True);native.write_bytes(truth_raw)
    paths=dict(predictions=pred)
    monkeypatch.setattr(readback.common,'invocation',lambda path:(config,config_sha))
    monkeypatch.setattr(readback.execution,'adapter',lambda:NS(stage_paths=lambda root,size:paths))
    previous=None;order=common.sequence(num_runs)
    for i,name in enumerate(order):
        entry=root/'submissions'/f'{name}.py';entry.write_bytes(b'# owned synthetic stage\n')
        row={n:True for n in ('passed','synthetic','handler_started','handler_completed','source_files_unchanged','cleanup_completed','terminal_scope_completed','termination_scope_completed')}
        row.update(genuine_eligible=False,ordinal=i,stage=name,invocation_sha256=config_sha,source_inventory_sha256=config['source_inventory_sha256'],previous_receipt_sha256=previous,
            entrypoint_sha256=common.digest(entry.read_bytes()),context_id=context,record_count=count,pid=10000+i,preprocessed_input_sha256=input_sha,prediction_sha256=common.digest(truth_raw),label_sha256=common.digest(truth_raw),synthetic_correct=count,ordered_request_ids=[f'{(i+1)*1000+j:032x}' for j in range(count)])
        raw=common.canonical(row);(root/'provenance'/f'{i:03d}.json').write_bytes(raw);previous=common.digest(raw)
    common.write(root/'stage_state.json',dict(next_stage=len(order),previous_receipt_sha256=previous,context_id=context))
    measurements=root/'measurements/small';measurements.mkdir(parents=True)
    for i in range(num_runs):
        correct=first_correct if i==0 else count
        q=lambda n:dict(correct_predictions=n,total_samples=count,accuracy=n/count)
        fields={name:f'{float(j+i)}s' for j,(_,name) in enumerate(timing.STAGES,1)}
        fields.update({'Total':'9999.0s','Key Generation':'1234.0s'})
        common.write(measurements/f'results-{i+1}.json',dict(model_name='bert-base',dataset_name='mrpc',Timing=fields,
            Quality={'Encrypted model quality':q(correct),'Harness model quality':q(count)},**{'Server Reported':{'ignored':'0.001s'}}))
    return root,config


def test_readback_keeps_synthetic_origin_and_original_per_run_sums(tmp_path,monkeypatch):
    root,_=fake_readback(tmp_path,monkeypatch,num_runs=2)
    r=readback.verify(root)
    assert r['synthetic'] is True and r['genuine_eligible'] is False and r['official_ranked_timing_eligible'] is False
    assert r['stage_count']==12 and r['setup_count']==2 and r['online_stage_count']==10
    assert r['timing']['timer_kind']=='component_diagnostic' and r['timing']['ranked_recipe_complete'] is False
    assert [Decimal(x) for x in r['timing']['per_run_online_seconds']]==[15,20]
    assert Decimal(r['timing']['median_online_seconds'])==Decimal('17.5')


def test_failed_earlier_repeat_cannot_borrow_final_accuracy(tmp_path,monkeypatch):
    root,_=fake_readback(tmp_path,monkeypatch,num_runs=2,first_correct=0)
    with pytest.raises(ValueError):readback.verify(root)


@pytest.mark.parametrize('change',[lambda d:d['Timing'].pop('Input encryption'),lambda d:d['Timing'].__setitem__('Encrypted computation','NaNs')])
def test_original_timing_missing_or_nonfinite_rejected(tmp_path,monkeypatch,change):
    root,_=fake_readback(tmp_path,monkeypatch);path=root/'measurements/small/results-1.json';data=json.loads(path.read_bytes());change(data);common.write(path,data)
    with pytest.raises(ValueError):readback.verify(root)


def test_each_repeat_quality_requires_exact_integer_counts(tmp_path,monkeypatch):
    root,_=fake_readback(tmp_path,monkeypatch,num_runs=2)
    path=root/'measurements/small/results-1.json';data=json.loads(path.read_bytes())
    data['Quality']['Encrypted model quality']['correct_predictions']=100.0
    common.write(path,data)
    with pytest.raises(ValueError,match='quality count'):readback.verify(root)


def test_rehashed_receipt_chain_cannot_reuse_prior_nonce_set(tmp_path,monkeypatch):
    root,config=fake_readback(tmp_path,monkeypatch,num_runs=2)
    order=common.sequence(2);receipts=[common.read(root/'provenance'/f'{i:03d}.json') for i in range(len(order))]
    receipts[8]['ordered_request_ids']=list(receipts[3]['ordered_request_ids'])
    previous=None
    for i,row in enumerate(receipts):
        row['previous_receipt_sha256']=previous;raw=common.canonical(row)
        (root/'provenance'/f'{i:03d}.json').write_bytes(raw);previous=common.digest(raw)
    state=common.read(root/'stage_state.json');state['previous_receipt_sha256']=previous;common.write(root/'stage_state.json',state)
    with pytest.raises(ValueError,match='fresh unique'):readback.verify(root)
