"""Persisted cross-process doubles for file-handler/preprocessing integration.

No key, model or ciphertext exists here. Every stored payload identifies itself
as synthetic. The complete unchanged handler loops remain the code under test.
"""
from pathlib import Path
from contextlib import contextmanager
from types import SimpleNamespace as NS
import hashlib,json,math,os,sys,uuid
import numpy as np


def install():
    from synthetic_guard import require
    require()
    import file_stages as stages,client_keys,server_public_model as model,transport,transport_contract as tc,full_model_engine
    stages.shutil.disk_usage=lambda p:NS(total=2<<40,used=0,free=2<<40)
    def keygen(public,private,**kwargs):
        public=Path(public);private=Path(private);public.mkdir(mode=0o700);private.mkdir(mode=0o700)
        manifest=dict(context_id=hashlib.sha256(uuid.uuid4().bytes).hexdigest(),parameters=tc.parameters(),synthetic=True)
        (public/'public_manifest.json').write_bytes(tc.canonical(manifest))
        (private/'private_manifest.json').write_bytes(tc.canonical(dict(context_id=manifest['context_id'],synthetic=True)))
        (private/'secret.npy').write_bytes(b'SYNTHETIC PREFLIGHT ONLY; NOT A SECRET KEY')
        return dict(public_manifest=manifest,preflight={'synthetic':True})
    client_keys.generate=keygen
    def public(path,**kwargs):
        value=json.loads((Path(path)/'public_manifest.json').read_bytes())
        if value.get('synthetic')is not True:raise ValueError('synthetic loader refuses genuine public keys')
        return value
    client_keys.authenticate_public=public
    def preprocess(snapshot,path,*,context_id,**kwargs):
        path=Path(path);path.mkdir(mode=0o700)
        manifest=dict(context_id=context_id,model_id=hashlib.sha256((context_id+'synthetic-model').encode()).hexdigest(),
            checkpoint_sha256=tc.CHECKPOINT_SHA256,config_sha256=tc.CONFIG_SHA256,candidate_sha256=tc.CANDIDATE_SHA256,profile_sha256=tc.PROFILE_SHA256,synthetic=True)
        (path/'model_manifest.json').write_bytes(tc.canonical(manifest));return manifest
    def load(path,*,context_id):
        manifest=json.loads((Path(path)/'model_manifest.json').read_bytes())
        if manifest.get('synthetic')is not True or manifest['context_id']!=context_id:raise ValueError('synthetic model loader refuses genuine/foreign model')
        return {'synthetic':True},manifest
    model.preprocess=preprocess;model.load=load;stages._snapshot=lambda:Path('/nonexistent-synthetic-model')
    class Value:
        def __init__(self,ordinal,tile,tag,output=False):
            self.ordinal=ordinal;self.tile=tile;self.tag=tag;self.output=output
            self._ckks_nsd=1;self._ckks_scale=tc.parameters()['scaling_factor'];self.polynomial=NS(block_until_ready=lambda:None)
    class Client:
        def __init__(self):self.count=0
        def encrypt_slots(self,slots):
            i=self.count;self.count+=1;return Value(i//8,i%8,int(round(float(slots[0]))))
        def decrypt_slots(self,value):
            if not value.output:raise ValueError('synthetic decoded output required')
            data=np.zeros(65536);i=value.tag-1;data[:2]=(float(i%2==0),float(i%2==1));return data
    @contextmanager
    def client(public_keys,client_private,**kwargs):
        keys=public(public_keys)
        private=json.loads((Path(client_private)/'private_manifest.json').read_bytes())
        if private.get('synthetic')is not True or private['context_id']!=keys['context_id']:raise ValueError('synthetic private context differs')
        yield NS(ctx=Client(),public_manifest=keys)
    @contextmanager
    def server(public_keys,**kwargs):yield NS(ctx=object(),public_manifest=public(public_keys))
    sys.modules['key_contexts']=NS(load_client=client,load_server=server)
    sys.modules['support']=NS(require_secure_execution=lambda *a:None)
    sys.modules['response_scale']=NS(accepts_scale=lambda scale,**kw:type(scale)is float and scale==tc.parameters()['scaling_factor'])
    class Embeddings:
        def __init__(self,*a):pass
        def prepare(self,record):
            data=np.zeros((128,768));data[:,0]=record.input_ids[1]-101
            return stages.client_inputs.pack_embeddings(record,data)
    stages.client_inputs.ClientEmbeddings=Embeddings
    def save(value,path,*,contract,role,tile_index,expected_scale=None,input_digest=None):
        path=Path(path);path.mkdir(mode=0o700)
        obj=dict(schema='SYNTHETIC-NOT-CIPHERTEXT',ordinal=value.ordinal,tile=value.tile,tag=value.tag,output=value.output)
        content={'bundle.json':tc.canonical(obj),'ct_0.npz':b'SYNTHETIC PREFLIGHT; NOT CIPHERTEXT'}
        for n,b in content.items():(path/n).write_bytes(b)
        binding=tc.ciphertext_contract(contract,role,tile_index,expected_scale,input_digest)
        manifest=transport._manifest_fields(binding)|{'files':{n:hashlib.sha256(b).hexdigest() for n,b in content.items()}}
        (path/'transport.json').write_bytes(tc.canonical(manifest));return manifest
    def loadct(path,**kwargs):
        path=Path(path);manifest=json.loads((path/'transport.json').read_bytes())
        binding=tc.ciphertext_contract(kwargs['contract'],kwargs['role'],kwargs['tile_index'],kwargs.get('expected_scale'),kwargs.get('input_digest'))
        transport._validate_manifest(manifest,binding)
        if {p.name for p in path.iterdir()}!={'bundle.json','ct_0.npz','transport.json'}:raise ValueError('synthetic payload inventory differs')
        for n,h in manifest['files'].items():
            if hashlib.sha256((path/n).read_bytes()).hexdigest()!=h:raise ValueError('synthetic payload bytes differ')
        obj=json.loads((path/'bundle.json').read_bytes())
        if obj.pop('schema')!='SYNTHETIC-NOT-CIPHERTEXT':raise ValueError('synthetic loader refuses real ciphertext')
        return Value(**obj),manifest
    def validate(path,**kwargs):
        value,manifest=loadct(path,**kwargs)
        binding=tc.ciphertext_contract(kwargs['contract'],kwargs['role'],kwargs['tile_index'],kwargs.get('expected_scale'),kwargs.get('input_digest'))
        return NS(shape=binding['shape'],nbytes=math.prod(binding['shape'])*4,dtype=np.dtype('uint32')),binding['scale'],binding,manifest
    stages.save_ciphertext=save;stages.load_ciphertext=loadct;transport.validate_ciphertext=validate
    class Graph:
        def evaluate(self,tiles,weights,**kwargs):
            if len(tiles)!=8 or any(v.ordinal!=tiles[0].ordinal or v.tile!=i for i,v in enumerate(tiles)):raise ValueError('synthetic ordered eight tiles differ')
            return NS(output=Value(tiles[0].ordinal,0,tiles[0].tag,True))
    @contextmanager
    def graph(*a,**kw):yield Graph()
    full_model_engine.server_engine=graph
