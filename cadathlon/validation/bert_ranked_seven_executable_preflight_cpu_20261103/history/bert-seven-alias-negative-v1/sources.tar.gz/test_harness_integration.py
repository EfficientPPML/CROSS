from pathlib import Path
import json,os,shutil,sys
import pytest
import integration_common as c
import harness_integration as h
import harness_readback as readback
import ranked_terminal as terminal
import stage_entry

@pytest.fixture(scope='module')
def parent(tmp_path_factory):
    p=tmp_path_factory.mktemp('seven-owned');(p/'.synthetic_integration_parent').write_text('synthetic only');return p

@pytest.mark.parametrize('size',[1,2,3])
@pytest.mark.parametrize('seed',[42,43,44])
def test_original_nine_complete(size,seed,parent):
    root=parent/f'{size}-{seed}';config=h.prepare(root,size=size,seed=seed)
    result=h.run_prepared(root,parent/f'{size}-{seed}-evidence')
    assert result['passed'],result['process']
    proof=result['proof'];r=proof['readback']
    assert len(config['source_hashes'])>=272 and r['count']==c.COUNTS[size]
    assert r['stage_count']==7 and r['setup_count']==2 and r['online_stage_count']==5
    assert r['fresh_unique_request_count']==c.COUNTS[size]
    assert r['synthetic_correct']==r['synthetic_native_correct']==c.COUNTS[size]
    assert proof['original_harness_argv'][1:]==[str(size),'--seed',str(seed)]
    assert proof['original_harness_child_reaped'] and not r['official_ranked_timing_eligible']
    assert r['timing']['timer_kind']=='component_diagnostic'
    assert r['exact_harness_files']==11
    assert len({(root/'submissions'/f'{n}.py').read_bytes() for n in c.NAMES})==1
    stdout=(root/'harness.stdout.log').read_text()
    assert 'Encrypted input size:' in stdout and 'Encrypted results size:' in stdout
    assert 'Harness: Run inference for harness plaintext model' in stdout
    assert len((root/'io'/ {1:'small',2:'medium',3:'large'}[size]/'encrypted_model_predictions.txt').read_text().splitlines())==c.COUNTS[size]


def test_explicit_repeat_two_preserves_original_reset_and_once_setup(parent):
    root=parent/'repeat';h.prepare(root,size=1,seed=43,num_runs=2)
    result=h.run_prepared(root,parent/'repeat-evidence')
    assert result['passed'],result['process']
    p=result['proof'];r=p['readback']
    assert p['original_harness_argv'][-2:]==['--num_runs','2']
    assert r['stage_count']==12 and r['setup_count']==2 and r['fresh_unique_request_count']==200
    assert r['timing']['setup_shared_within_repeats'] and r['timing']['seed_selection_repeated_by_upstream']
    assert r['timing']['ranked_recipe_complete']is False
    first=c.read(root/'provenance/002.json');second=c.read(root/'provenance/007.json')
    assert first['preprocessed_input_sha256']==second['preprocessed_input_sha256']
    assert first['context_id']==second['context_id']

@pytest.mark.parametrize('kwargs',[{'size':True,'seed':42},{'size':0,'seed':42},{'size':4,'seed':42},{'size':1,'seed':41},{'size':1,'seed':42.},{'size':1,'seed':42,'num_runs':True},{'size':1,'seed':42,'num_runs':3},{'size':1,'seed':42,'execution_mode':'genuine'}])
def test_invalid_or_actual_mode_rejects_before_creation(parent,kwargs):
    root=parent/('invalid-'+str(len(list(parent.iterdir()))))
    with pytest.raises(ValueError):h.prepare(root,**kwargs)
    assert not root.exists()


def test_existing_and_symlink_roots_rejected(parent):
    root=parent/'existing';root.mkdir();sentinel=root/'sentinel';sentinel.write_text('keep')
    for p in (root,parent/'alias'):
        if p!=root:p.symlink_to(root,target_is_directory=True)
        with pytest.raises(FileExistsError):h.prepare(p,size=1,seed=42)
    assert sentinel.read_text()=='keep'


def test_unowned_parent_rejected(tmp_path):
    with pytest.raises(ValueError):h.prepare(tmp_path/'child',size=1,seed=42)
    assert not (tmp_path/'child').exists()

@pytest.mark.parametrize('mutation',['source','harness','mode','argv','stage','alias'])
def test_actual_process_rejects_corrupt_preflight_before_keys(parent,mutation):
    root=parent/f'negative-{mutation}';h.prepare(root,size=1,seed=42)
    if mutation=='source':(root/'_source/entry_template.py').write_text('# changed')
    elif mutation=='harness':(root/'harness/utils.py').write_text('# changed')
    elif mutation=='mode':
        cfg=c.read(root/'invocation.json');cfg['execution_mode']='genuine';c.write(root/'invocation.json',cfg)
    elif mutation=='stage':
        st=c.read(root/'stage_state.json');st['next_stage']=1;c.write(root/'stage_state.json',st)
    elif mutation=='alias':
        (root/'io').symlink_to(parent/'retained',target_is_directory=True);(parent/'retained').mkdir()
    else:
        # A typed seed/count mismatch blocks the upstream invocation itself.
        cfg=c.read(root/'invocation.json');cfg['count']=1;c.write(root/'invocation.json',cfg)
    result=h.run_prepared(root,parent/f'negative-{mutation}-evidence')
    assert not result['passed']
    assert result['process']['process_reaped']
    assert not (root/'io/small/public_keys').exists()

@pytest.mark.parametrize('value',[None,[],1,'bad',True])
def test_terminal_malformed_return_preserves_intended_error(tmp_path,value):
    from contextlib import nullcontext
    p=tmp_path/'report.json'
    with pytest.raises(ValueError,match='terminal report object'):
        terminal.finish(p,lambda:value,c.write,termination=nullcontext,shield=nullcontext)
    assert c.read(p)['passed']is False

@pytest.mark.parametrize('error',[KeyboardInterrupt(),SystemExit(17)])
def test_stage_body_cancellation_survives_cleanup_and_publication(monkeypatch,tmp_path,error):
    (tmp_path/'provenance').mkdir()
    def fail(*a,**kw):raise error
    monkeypatch.setattr(c,'invocation',fail)
    original=os.umask;count=0
    def mask(value):
        nonlocal count
        count+=1
        if count>1:raise OSError('cleanup failed')
        return original(value)
    monkeypatch.setattr(stage_entry.os,'umask',mask)
    monkeypatch.setattr(c,'write',lambda *a:(_ for _ in ()).throw(OSError('publication failed')))
    try:
        with pytest.raises(type(error)) as got:stage_entry.run(c.NAMES[0],tmp_path)
        assert got.value is error
    finally:original(0o022)


def test_state_publication_failure_invalidates_completed_receipt(monkeypatch,tmp_path):
    (tmp_path/'provenance').mkdir();path=tmp_path/'provenance/000.json'
    cfg={'size':1};state={'next_stage':0};report={'passed':True,'context_id':'a'*64,'termination_scope_completed':True}
    monkeypatch.setattr(c,'invocation',lambda root:(cfg,'b'*64))
    monkeypatch.setattr(stage_entry.sys,'argv',['client_key_generation.py','1'])
    original_read=c.read;original_write=c.write
    monkeypatch.setattr(c,'read',lambda p,*a:state.copy() if Path(p).name=='stage_state.json' else original_read(p,*a))
    def complete(p,call,write):write(p,report);return report
    monkeypatch.setattr(stage_entry,'finish',complete)
    def write(p,value):
        if Path(p).name=='stage_state.json':raise OSError('transition failed')
        original_write(p,value)
    monkeypatch.setattr(c,'write',write)
    with pytest.raises(SystemExit) as got:stage_entry.main(c.NAMES[0],tmp_path)
    assert got.value.code==1 and c.read(path)['passed']is False
