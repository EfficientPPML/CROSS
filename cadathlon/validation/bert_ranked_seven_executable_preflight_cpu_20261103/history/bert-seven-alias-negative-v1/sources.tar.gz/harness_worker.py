"""Run the unmodified upstream harness in this owned process group."""
from pathlib import Path
from contextlib import redirect_stdout,redirect_stderr
import argparse,json,os,subprocess,sys,time
import integration_common as common
from ranked_terminal import finish


def run(root):
    root=Path(root);config,config_sha=common.invocation(root);start=time.monotonic()
    report=dict(passed=False,synthetic=True,genuine_eligible=False,pid=os.getpid(),invocation_sha256=config_sha,
        source_inventory_sha256=config['source_inventory_sha256'],upstream_harness_started=False,upstream_harness_completed=False)
    try:
        os.chdir(root);os.umask(0o077)
        # Literal upstream parser/default, imported modules, timer and dispatch.
        sys.path.insert(0,str(root/'harness'))
        sys.argv=[str(root/'harness/run_submission.py'),str(config['size']),'--seed',str(config['seed'])]
        if config['num_runs']!=1:sys.argv.extend(['--num_runs',str(config['num_runs'])])
        report['original_harness_argv']=list(sys.argv)
        with (root/'harness.stdout.log').open('w') as out,(root/'harness.stderr.log').open('w') as err:
            report['upstream_harness_started']=True
            subprocess.run([sys.executable,*sys.argv],cwd=root,stdout=out,stderr=err,check=True)
            report['original_harness_child_reaped']=True
            report['upstream_harness_completed']=True
        import harness_readback
        report['readback']=harness_readback.verify(root)
        common.invocation(root)
        report.update(passed=True,source_files_unchanged=True,cleanup_completed=True,terminal_scope_completed=True)
    except BaseException as error:
        report.update(passed=False,error={'type':type(error).__name__,'message':'synthetic harness failed; see owned log'},cleanup_completed=False,terminal_scope_completed=False)
        try:common.write(root/'harness_report.json',report)
        except BaseException as secondary:error.add_note('harness failed publication: '+type(secondary).__name__)
        raise
    finally:
        report['elapsed_s']=time.monotonic()-start
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',required=True,type=Path);args=p.parse_args()
    try:report=finish(args.root/'harness_report.json',lambda:run(args.root),common.write)
    except BaseException as error:
        print(json.dumps(dict(passed=False,synthetic=True,error_type=type(error).__name__)))
        raise SystemExit(130 if not isinstance(error,Exception) else 1)
    print(json.dumps(dict(passed=report['passed'],synthetic=True,genuine_eligible=False,report_sha256=common.digest((args.root/'harness_report.json').read_bytes()))))
