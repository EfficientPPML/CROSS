from synthetic_guard import require
require()
def load_dataset(*args,**kwargs):
    rows=[dict(idx=i,sentence1=f'synthetic-left-{i}',sentence2=f'synthetic-right-{i}',label=i%2) for i in range(408)]
    return {'train':rows,'validation':rows,'test':rows}
