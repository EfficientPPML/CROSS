from synthetic_guard import require
require()
from contextlib import nullcontext
from types import SimpleNamespace
cuda=SimpleNamespace(is_available=lambda:False,manual_seed_all=lambda seed:None)
def manual_seed(seed):pass
def no_grad():return nullcontext()
