"""Fake tokenizer/classifier for original harness plumbing, never BERT math."""
from synthetic_guard import require
require()
from types import SimpleNamespace
class Tensor:
    def __init__(self,value):self.value=value
    def to(self,device):return self
class Scalar:
    def __init__(self,value):self.value=value
    def item(self):return self.value
class AutoTokenizer:
    @classmethod
    def from_pretrained(cls,*args,**kwargs):return cls()
    def __call__(self,left,right,**kwargs):
        i=int(left.rsplit('-',1)[1]);K=(1,15,16,17,64,127,128)[i%7]
        positions=[0]+list(range(129-K,128)) if K>1 else [0]
        result=dict(input_ids=[101,i+102]+[0]*126,token_type_ids=[0]*128,attention_mask=[int(j in positions) for j in range(128)])
        return {k:Tensor(v) for k,v in result.items()} if kwargs.get('return_tensors')=='pt' else result
class BertForSequenceClassification:
    @classmethod
    def from_pretrained(cls,*a,**kw):return cls()
    def to(self,device):return self
    def eval(self):return self
    def __call__(self,**encoding):
        i=encoding['input_ids'].value[1]-102
        return SimpleNamespace(logits=[[Scalar(float(i%2==0)),Scalar(float(i%2==1))]])
