"""Deliberate synthetic dependencies: never import silently in genuine work."""
import os,json
from pathlib import Path

def require():
    if os.environ.get('CROSS_RANKED_SYNTHETIC_ONLY')!='1':raise RuntimeError('synthetic dependency requires explicit preflight mode')
    p=Path.cwd()/'invocation.json'
    r=json.loads(p.read_text())
    if r.get('execution_mode')!='synthetic-preflight' or r.get('genuine_eligible')is not False:raise RuntimeError('synthetic invocation marker differs')
