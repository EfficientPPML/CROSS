"""Ordered source/receipt and original-timer readback, synthetic scope only."""
from pathlib import Path
import json
import integration_common as common
import ranked_execution as execution
import ranked_timing as timing


def lines(path):return [s for s in Path(path).read_text().splitlines() if s]
def verify(root):
    config,config_sha=common.invocation(root);order=common.sequence(config['num_runs']);state=common.read(root/'stage_state.json')
    if state['next_stage']!=len(order):raise ValueError('complete seven-entrypoint/repeated sequence required')
    receipts=[];previous=None;context=None
    if {p.name for p in (root/'provenance').iterdir()}!={f'{i:03d}.json' for i in range(len(order))}:raise ValueError('exact ordered receipt inventory required')
    for i,name in enumerate(order):
        raw=(root/'provenance'/f'{i:03d}.json').read_bytes();r=json.loads(raw)
        if any(r.get(n)is not True for n in ('passed','synthetic','handler_started','handler_completed','source_files_unchanged','cleanup_completed','terminal_scope_completed','termination_scope_completed')) or r.get('genuine_eligible')is not False:raise ValueError('complete synthetic terminal receipt required')
        if r.get('ordinal')!=i or r.get('stage')!=name or r.get('invocation_sha256')!=config_sha or r.get('source_inventory_sha256')!=config['source_inventory_sha256'] or r.get('previous_receipt_sha256')!=previous:raise ValueError('ordered source/receipt chain differs')
        if r['entrypoint_sha256']!=common.digest((root/'submissions'/f'{name}.py').read_bytes()):raise ValueError('entrypoint bytes differ')
        context=r['context_id'] if i==0 else context
        if r['context_id']!=context:raise ValueError('shared fresh setup context differs')
        if i>=2 and r.get('record_count')!=config['count']:raise ValueError('full ordered ranked count required')
        receipts.append(r);previous=common.digest(raw)
    if len({r['pid'] for r in receipts})!=len(order) or state['previous_receipt_sha256']!=previous or state['context_id']!=context:raise ValueError('separate process/last receipt binding differs')
    paths=execution.adapter().stage_paths(root,config['size']);folder={1:'small',2:'medium',3:'large'}[config['size']]
    truth=[int(s) for s in lines(root/'datasets'/folder/'intermediate/test_labels.txt')]
    pred=[int(s) for s in lines(paths['predictions'])];native=[int(s) for s in lines(root/'io'/folder/'harness_model_predictions.txt')]
    if any(len(v)!=config['count'] or any(type(x)is not int or x not in (0,1) for x in v) for v in (truth,pred,native)):raise ValueError('all N native/prediction/label records required')
    correct=sum(a==b for a,b in zip(pred,truth));official=sum(a==b for a,b in zip(native,truth));N=config['count']
    if not(4*correct>=3*N and 100*(official-correct)<=2*N):raise ValueError('synthetic independent integer acceptance failed')
    policy=timing.TimingPolicy('component_diagnostic',config['source_inventory_sha256'],'a'*64,'b'*64,True)
    runs=[];rawtiming=[];inputsha=None
    for i in range(config['num_runs']):
        # Earlier predictions are bound at publication by each postprocess
        #receipt; the current complete original harness emits one timing file/run.
        p=root/'measurements'/folder/f'results-{i+1}.json';raw=p.read_bytes();stages=timing.stages_from_harness_json(raw)
        r=receipts[2+i*5];sha=r['preprocessed_input_sha256'];inputsha=sha if i==0 else inputsha
        if sha!=inputsha:raise ValueError('original repeated-run seeded selection differs')
        runs.append(timing.RunTiming(config['size'],config['seed'],config['invocation_id'],context,sha,policy,stages,correct,official,run_number=i+1,num_runs=config['num_runs']))
        rawtiming.append(dict(run=i+1,sha256=common.digest(raw),online_fields=[dict(number=s.number,name=s.name,seconds_text=s.seconds_text) for s in stages]))
    return dict(synthetic=True,genuine_eligible=False,stage_count=len(order),setup_count=2,online_stage_count=5*config['num_runs'],
        count=N,seed=config['seed'],size=config['size'],num_runs=config['num_runs'],context_id=context,
        distinct_stage_pids=[r['pid'] for r in receipts],receipt_sha256=previous,source_inventory_sha256=config['source_inventory_sha256'],
        synthetic_correct=correct,synthetic_native_correct=official,synthetic_integer_gates_passed=True,
        timing_origin='unchanged upstream steps5–9 timer statements; synthetic backend and integration validation overhead',
        official_ranked_timing_eligible=False,timing=timing.repeat_summary(runs,num_runs=config['num_runs']),original_timing=rawtiming,
        exact_harness_files=len(config['harness_hashes']),original_cleartext_invocation_completed=True)
