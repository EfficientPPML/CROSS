"""Source-bound focused test evidence; no private dataset/model reads here."""
from pathlib import Path
import time
import build_fixture as f


def pytest_addoption(parser):
    parser.addoption('--source-report', default=None)


def pytest_sessionstart(session):
    target=session.config.getoption('--source-report')
    if target is None:return
    target=Path(target);target.mkdir(exist_ok=False)
    paths=f.source_paths()
    state=dict(paths=paths,target=target,started=time.monotonic(),
               before=f.archive_sources(paths,target/'sources.tar.gz'))
    session._source_bound=state
    f.write_json(target/'report.json',{'passed':False,'source_hashes_before':state['before']})


def pytest_sessionfinish(session,exitstatus):
    state=getattr(session,'_source_bound',None)
    if state is None:return
    after={name:f.sha(path) for name,path in state['paths'].items()}
    report=dict(passed=exitstatus==0 and after==state['before'],exitstatus=int(exitstatus),
                collected=session.testscollected,failed=session.testsfailed,
                source_hashes_before=state['before'],source_hashes_after=after,
                sources_unchanged=after==state['before'],source_archive_sha256=f.sha(state['target']/'sources.tar.gz'),
                elapsed_s=time.monotonic()-state['started'])
    f.write_json(state['target']/'report.json',report)
    if not report['passed'] and exitstatus==0:session.exitstatus=1
