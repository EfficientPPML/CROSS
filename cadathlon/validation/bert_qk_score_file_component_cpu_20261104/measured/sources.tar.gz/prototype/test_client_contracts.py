"""Synthetic private-record boundary tests; no native model or HE execution."""
import hashlib,json
from pathlib import Path
import numpy as np
import pytest
import client_contracts as c
from spec import ASSETS,REVISION,PUBLIC_ATTENTION_MASK


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

@pytest.fixture
def prepared(tmp_path,monkeypatch):
 private=tmp_path/'client_only';model=tmp_path/'model';private.mkdir();model.mkdir()
 tokens={'input_ids':[[1]*128],'token_type_ids':[[0]*128],'attention_mask':[list(PUBLIC_ATTENTION_MASK)]}
 (private/'tokens.json').write_text(json.dumps(tokens))
 monkeypatch.setattr(c,'PINNED_TOKENIZATION_SHA256',digest(private/'tokens.json'))
 (model/'model_manifest.json').write_text('{"synthetic_fixture_only":true}')
 rows=np.ones((2,16,768));rows[1]*=2;np.save(private/'embeddings.npy',rows)
 expected=np.zeros((2,65536));keys=112+(np.arange(16)+15)%16
 target=(np.arange(16)[:,None]*4096+keys[:,None]*16+np.arange(12)).ravel()
 values=(np.arange(192)+1)/192;expected[0,target]=values;np.save(private/'expected.npy',expected)
 report=dict(schema='bert-qk-preprocessing-v1',scope='synthetic record only',passed=True,query_tile=0,key_tile=7,offset=15,
  embedding_shape=[2,16,768],full_embedding_shape=[1,128,768],embedding_sha256=digest(private/'embeddings.npy'),expected_sha256=digest(private/'expected.npy'),tokenization_sha256=digest(private/'tokens.json'),model_manifest_sha256=digest(model/'model_manifest.json'),asset_sha256=ASSETS,model_revision=REVISION,dense_oracle_error=0.,score_oracle_error=0.,raw_score_count=192,raw_score_nonzero_count_above_1e_12=192,raw_score_minimum=float(values.min()),raw_score_maximum=float(values.max()),raw_score_max_abs=float(values.max()),selected_valid_key_rows=0,masked_reference_nonzero_count=0,elapsed_s=1.,versions={'transformers':'4.51.3'})
 (private/'preprocessing.json').write_text(json.dumps(report))
 return private,model,report


def test_valid_record_reconstructs_only_verified_private_bytes(prepared):
 private,model,report=prepared
 actual,rows,expected,identity=c.validate_preprocessing(private,model)
 assert actual==report and rows.shape==(2,16,768) and expected.shape==(2,65536)
 assert identity==digest(private/'preprocessing.json')


@pytest.mark.parametrize('field,value',[
 ('passed',False),('passed',1),('schema','old'),('query_tile',1),('key_tile',6),('offset',0),
 ('raw_score_count',191),('raw_score_nonzero_count_above_1e_12',0),('selected_valid_key_rows',1),
 ('masked_reference_nonzero_count',1),('embedding_shape',[2,2,768]),('full_embedding_shape',[1,16,768]),
 ('model_revision','wrong'),('asset_sha256',{}),('tokenization_sha256','0'*64),
 ('dense_oracle_error',1e-3),('score_oracle_error',float('nan')),('versions',{}),('raw_score_max_abs',999.)])
def test_stale_failed_or_wrong_fixed_preprocessing_rejected(prepared,field,value):
 private,model,report=prepared;report[field]=value;(private/'preprocessing.json').write_text(json.dumps(report))
 with pytest.raises(ValueError):c.validate_preprocessing(private,model)


@pytest.mark.parametrize('change',['zero_raw','wrong_padding','wrong_mask','repeated_tiles','wrong_dtype','tokens'])
def test_rehashed_private_artifacts_still_obey_nonvacuous_layout(prepared,change):
 private,model,report=prepared
 if change=='tokens':
  (private/'tokens.json').write_text('{}');report['tokenization_sha256']=digest(private/'tokens.json')
 else:
  name='embeddings.npy' if change in {'repeated_tiles','wrong_dtype'} else 'expected.npy'
  value=np.load(private/name)
  if change=='zero_raw':value[:]=0
  elif change=='wrong_padding':value[0,4095]=1
  elif change=='wrong_mask':value[1]=value[0]
  elif change=='repeated_tiles':value[1]=value[0]
  elif change=='wrong_dtype':value=value.astype(np.float32)
  np.save(private/name,value);report['embedding_sha256' if name=='embeddings.npy' else 'expected_sha256']=digest(private/name)
 (private/'preprocessing.json').write_text(json.dumps(report))
 with pytest.raises(ValueError):c.validate_preprocessing(private,model)


def test_invalid_preprocessing_fails_before_any_key_generation(prepared,monkeypatch):
 import component
 private,model,report=prepared;report['passed']=False;(private/'preprocessing.json').write_text(json.dumps(report))
 monkeypatch.setattr(component,'public_preflight',lambda:{})
 monkeypatch.setattr(component,'crypto',lambda:(None,None,None,object()))
 monkeypatch.setattr(component,'load_model',lambda directory:(None,None))
 with pytest.raises(ValueError,match='schema/status'):component.setup(private.parent,'nonce')
 assert not (private.parent/'public').exists()
