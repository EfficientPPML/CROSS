"""Trusted pinned BERT embedding/QK preprocessing; never imported by the server."""
from pathlib import Path
import argparse,hashlib,json,os,struct,time
import numpy as np
from spec import REVISION,ASSETS,EXAMPLE,KINDS,QUERY_TILE,KEY_TILE,OFFSET,PUBLIC_ATTENTION_MASK

def digest(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(path,value):Path(path).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def tensor_bytes(snapshot,name):
 with (snapshot/'model.safetensors').open('rb') as f:
  n=struct.unpack('<Q',f.read(8))[0];header=json.loads(f.read(n));entry=header[name];start,stop=entry['data_offsets'];f.seek(8+n+start);raw=f.read(stop-start)
 if entry['dtype']!='F32':raise ValueError('expected pinned F32 tensor')
 return np.frombuffer(raw,dtype='<f4').reshape(entry['shape']).copy()

def prepare(snapshot,private,model):
 started=time.perf_counter();hashes={n:digest(snapshot/n) for n in ASSETS}
 if hashes!=ASSETS or snapshot.name!=REVISION:raise ValueError('pinned BERT asset mismatch')
 import importlib.metadata,torch
 from transformers import AutoTokenizer,BertForSequenceClassification
 torch.set_num_threads(1)
 tokenizer=AutoTokenizer.from_pretrained(snapshot,local_files_only=True)
 network,loading=BertForSequenceClassification.from_pretrained(snapshot,local_files_only=True,use_safetensors=True,torch_dtype=torch.float64,attn_implementation='eager',output_loading_info=True)
 if loading['missing_keys'] or loading.get('mismatched_keys') or loading.get('error_msgs') or set(loading['unexpected_keys'])-{'bert.embeddings.position_ids'}:raise ValueError('incomplete pinned model')
 network.eval();tokens=tokenizer(*EXAMPLE,max_length=128,padding='max_length',truncation=True,return_tensors='pt')
 mask=tokens['attention_mask'][0].numpy()
 if not np.array_equal(mask,np.asarray(PUBLIC_ATTENTION_MASK)):raise ValueError('fixed public attention mask differs from native tokenizer')
 with torch.no_grad():
  full=network.bert.embeddings(input_ids=tokens['input_ids'],token_type_ids=tokens['token_type_ids'])
  native={kind:getattr(network.bert.encoder.layer[0].attention.self,kind)(full)[0].numpy().copy() for kind in KINDS}
 rows=np.stack([full[0,t*16:(t+1)*16].numpy().copy() for t in (QUERY_TILE,KEY_TILE)])
 if rows.shape!=(2,16,768) or np.array_equal(rows[0],rows[1]) or not np.isfinite(rows).all():raise ValueError('two distinct complete embedding tiles required')
 private.mkdir(mode=0o700);model.mkdir()
 np.save(private/'embeddings.npy',rows,allow_pickle=False)
 write(private/'tokens.json',{k:v.tolist() for k,v in tokens.items()})
 manifest={'schema':'pinned-bert-layer0-qk-v1','model_id':'google-bert/bert-base-cased-finetuned-mrpc','revision':REVISION,'asset_sha256':hashes,'tensors':{}}
 oracle_error=0.;selected={}
 for i,kind in enumerate(KINDS):
  for suffix,shape in (('weight',(768,768)),('bias',(768,))):
   name=f'bert.encoder.layer.0.attention.self.{kind}.{suffix}';array=tensor_bytes(snapshot,name)
   if array.shape!=shape:raise ValueError('pinned tensor shape mismatch')
   state=network.state_dict()[name].numpy()
   if not np.array_equal(array.astype(np.float64),state):raise ValueError('native tensor differs from safetensors bytes')
   file=f'{kind}_{suffix}.npy';np.save(model/file,array,allow_pickle=False)
   manifest['tensors'][file]={'name':name,'shape':list(shape),'dtype':array.dtype.str,'file_sha256':digest(model/file),'tensor_sha256':hashlib.sha256(array.tobytes()).hexdigest()}
  w=np.load(model/f'{kind}_weight.npy',allow_pickle=False).astype(np.float64);b=np.load(model/f'{kind}_bias.npy',allow_pickle=False).astype(np.float64)
  selected[kind]=rows[i]@w.T+b
  tile=(QUERY_TILE,KEY_TILE)[i]
  oracle_error=max(oracle_error,float(np.max(np.abs(selected[kind]-native[kind][tile*16:(tile+1)*16]))))
 if oracle_error>1e-12:raise ValueError('independent dense oracle mismatch')
 # Native dense attention scores before ANY key validity or softmax operation.
 # Their positions remain meaningful even if all selected keys are padding.
 q=native['query'].reshape(128,12,64).transpose(1,0,2)
 k=native['key'].reshape(128,12,64).transpose(1,0,2)
 dense=q@k.transpose(0,2,1)/8
 key_rows=KEY_TILE*16+(np.arange(16)+OFFSET)%16
 raw=np.stack([dense[:,QUERY_TILE*16+r,key_rows[r]] for r in range(16)])
 independent=(selected['query'].reshape(16,12,64)*np.roll(selected['key'],-OFFSET,axis=0).reshape(16,12,64)).sum(-1)/8
 score_oracle_error=float(np.max(np.abs(raw-independent)))
 if score_oracle_error>1e-12:raise ValueError('independent raw head-score oracle mismatch')
 if not np.isfinite(raw).all() or np.count_nonzero(np.abs(raw)>1e-12)!=192:raise ValueError('raw score reference must have192 nonzero finite values')
 target=(np.arange(16)[:,None]*4096+key_rows[:,None]*16+np.arange(12)).ravel()
 expected=np.zeros((2,65536));expected[0,target]=raw.ravel();expected[1,target]=(raw*mask[key_rows,None]).ravel()
 np.save(private/'expected.npy',expected,allow_pickle=False)
 write(model/'model_manifest.json',manifest)
 report={'schema':'bert-qk-preprocessing-v1','scope':'Trusted client preprocessing only: unchanged fixed128-token public pair; complete embedding module, full768x768 Q/K; raw192 native scores before attention masking.','passed':True,'query_tile':QUERY_TILE,'key_tile':KEY_TILE,'offset':OFFSET,'embedding_shape':list(rows.shape),'full_embedding_shape':list(full.shape),'embedding_sha256':digest(private/'embeddings.npy'),'expected_sha256':digest(private/'expected.npy'),'tokenization_sha256':digest(private/'tokens.json'),'model_manifest_sha256':digest(model/'model_manifest.json'),'asset_sha256':hashes,'model_revision':REVISION,'dense_oracle_error':oracle_error,'score_oracle_error':score_oracle_error,'raw_score_count':192,'raw_score_nonzero_count_above_1e_12':int(np.count_nonzero(np.abs(raw)>1e-12)),'raw_score_minimum':float(raw.min()),'raw_score_maximum':float(raw.max()),'raw_score_max_abs':float(np.abs(raw).max()),'selected_valid_key_rows':int(mask[key_rows].sum()),'masked_reference_nonzero_count':int(np.count_nonzero(expected[1])),'elapsed_s':time.perf_counter()-started,'versions':{n:importlib.metadata.version(n) for n in ('numpy','torch','transformers','tokenizers','safetensors')}}
 write(private/'preprocessing.json',report)
 for file in private.iterdir():os.chmod(file,0o600)
 print(json.dumps(report,allow_nan=False))
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--snapshot',type=Path,required=True);p.add_argument('--private',type=Path,required=True);p.add_argument('--model',type=Path,required=True);a=p.parse_args();prepare(a.snapshot,a.private,a.model)
