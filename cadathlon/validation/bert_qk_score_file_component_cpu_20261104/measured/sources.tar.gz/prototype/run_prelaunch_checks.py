"""Source-bound CPU route/package/transport/client/collector checks; no HE run."""
from pathlib import Path
import hashlib,io,json,os,sys,tarfile,time
LAB=Path(__file__).resolve().parent;sys.path.insert(0,str(LAB/'prototype'))
import collect,pytest
out=LAB/'prelaunch-tests-v2';out.mkdir(exist_ok=False)
snapshot=collect.sources();snapshot[str(Path(__file__))]=Path(__file__).read_bytes()
before=collect.hashes(snapshot);started=time.perf_counter()
with tarfile.open(out/'sources.tar.gz','w:gz') as tar:
 for name,data in snapshot.items():
  path=Path(name);member='repository/'+str(path.relative_to(collect.ROOT)) if path.is_relative_to(collect.ROOT) else 'prototype/'+path.name
  info=tarfile.TarInfo(member);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
paths=[LAB/'checkout/cadathlon/tests'/name for name in ('test_encrypted_score_routing.py','test_package.py','test_bert_staging.py')]
paths += [LAB/'prototype'/name for name in ('test_component.py','test_qk_transport.py','test_client_contracts.py')]
command=['-q',*[str(p) for p in paths],'--junitxml='+str(out/'junit.xml')]
rc=pytest.main(command)
after=collect.hashes(collect.sources());after[str(Path(__file__))]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
r={'scope':__doc__,'passed':rc==0 and before==after,'returncode':int(rc),'elapsed_s':time.perf_counter()-started,'source_hashes_start':before,'source_hashes_end':after,'source_files_unchanged':before==after,'source_count':len(before),'command':[sys.executable,__file__],'pytest_arguments':command,'cpu_affinity':sorted(os.sched_getaffinity(0)),'environment':{k:os.environ.get(k) for k in ('JAX_PLATFORMS','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')},'source_archive_sha256':hashlib.sha256((out/'sources.tar.gz').read_bytes()).hexdigest()}
(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:r[k] for k in ('passed','returncode','elapsed_s','source_files_unchanged','source_count')}))
raise SystemExit(0 if r['passed'] else 1)
