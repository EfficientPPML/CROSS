"""Private client preprocessing checks; this module is never imported by server."""
from pathlib import Path
import hashlib,io,math
import numpy as np
from spec import ASSETS,REVISION,QUERY_TILE,KEY_TILE,OFFSET,PUBLIC_ATTENTION_MASK,PINNED_TOKENIZATION_SHA256
from transport import _json,_read_regular

FIELDS={'schema','scope','passed','query_tile','key_tile','offset','embedding_shape','full_embedding_shape','embedding_sha256','expected_sha256','tokenization_sha256','model_manifest_sha256','asset_sha256','model_revision','dense_oracle_error','score_oracle_error','raw_score_count','raw_score_nonzero_count_above_1e_12','raw_score_minimum','raw_score_maximum','raw_score_max_abs','selected_valid_key_rows','masked_reference_nonzero_count','elapsed_s','versions'}

def validate_preprocessing(private,model):
 private,model=Path(private),Path(model)
 raw=_read_regular(private/'preprocessing.json',65536);report=_json(raw)
 if not isinstance(report,dict) or set(report)!=FIELDS or report['schema']!='bert-qk-preprocessing-v1' or report['passed'] is not True:raise ValueError('invalid preprocessing schema/status')
 for name,expected in [('query_tile',QUERY_TILE),('key_tile',KEY_TILE),('offset',OFFSET),('raw_score_count',192),('raw_score_nonzero_count_above_1e_12',192),('selected_valid_key_rows',0),('masked_reference_nonzero_count',0)]:
  if type(report[name]) is not int or report[name]!=expected:raise ValueError('preprocessing fixed count/tile differs')
 if report['embedding_shape']!=[2,16,768] or report['full_embedding_shape']!=[1,128,768] or report['model_revision']!=REVISION or report['asset_sha256']!=ASSETS:raise ValueError('preprocessing shape/checkpoint identity differs')
 if not isinstance(report['versions'],dict) or report['versions'].get('transformers')!='4.51.3':raise ValueError('pinned native loader version differs')
 for name in ('dense_oracle_error','score_oracle_error'):
  value=report[name]
  if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or not 0<=value<=1e-12:raise ValueError('preprocessing native oracle gate failed')
 tokens=_read_regular(private/'tokens.json',65536)
 token_hash=hashlib.sha256(tokens).hexdigest()
 if token_hash!=PINNED_TOKENIZATION_SHA256 or token_hash!=report['tokenization_sha256']:raise ValueError('fixed tokenization identity differs')
 token_values=_json(tokens)
 if set(token_values)!={'input_ids','attention_mask','token_type_ids'} or token_values['attention_mask']!=[list(PUBLIC_ATTENTION_MASK)]:raise ValueError('fixed public attention mask differs')
 if hashlib.sha256(_read_regular(model/'model_manifest.json',65536)).hexdigest()!=report['model_manifest_sha256']:raise ValueError('preprocessing public model identity differs')
 arrays=[]
 for name,shape,key in [('embeddings.npy',(2,16,768),'embedding_sha256'),('expected.npy',(2,65536),'expected_sha256')]:
  content=_read_regular(private/name,math.prod(shape)*8+65536)
  if hashlib.sha256(content).hexdigest()!=report[key]:raise ValueError('preprocessing private array digest differs')
  value=np.load(io.BytesIO(content),allow_pickle=False)
  if value.dtype!=np.float64 or value.shape!=shape or not np.isfinite(value).all():raise ValueError('preprocessing private array shape/dtype differs')
  arrays.append(value)
 rows,expected=arrays
 if np.array_equal(rows[0],rows[1]):raise ValueError('input embedding tiles must differ')
 keys=KEY_TILE*16+(np.arange(16)+OFFSET)%16
 target=(np.arange(16)[:,None]*4096+keys[:,None]*16+np.arange(12)).ravel()
 raw_scores=expected[0,target];inactive=np.ones(65536,bool);inactive[target]=False
 if np.any(expected[:,inactive]) or np.count_nonzero(np.abs(raw_scores)>1e-12)!=192:raise ValueError('raw score reference support differs or is vacuous')
 if not np.array_equal(expected[1,target],raw_scores*np.repeat(np.asarray(PUBLIC_ATTENTION_MASK)[keys],12)):raise ValueError('optional mask reference differs')
 for name,value in [('raw_score_minimum',float(raw_scores.min())),('raw_score_maximum',float(raw_scores.max())),('raw_score_max_abs',float(np.abs(raw_scores).max()))]:
  if type(report[name]) is not float or report[name]!=value:raise ValueError('preprocessing aggregate range differs')
 return report,rows,expected,hashlib.sha256(raw).hexdigest()
