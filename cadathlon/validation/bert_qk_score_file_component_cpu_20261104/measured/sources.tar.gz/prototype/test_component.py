"""CPU collector failure and ownership checks; no encryption."""
import json,sys
from pathlib import Path
import pytest

def test_cleanup_only_cancellation_is_preserved_after_attempting_every_resource(monkeypatch):
 from types import SimpleNamespace
 import component
 seen=[];interrupted=KeyboardInterrupt('cleanup cancellation')
 def clear():seen.append('graph');raise interrupted
 def close():seen.append('owner');raise OSError('secondary owner failure')
 monkeypatch.setattr(component.gc,'collect',lambda:seen.append('gc'))
 with pytest.raises(KeyboardInterrupt) as result:
  component.cleanup(SimpleNamespace(clear_caches=lambda:seen.append('jax')),
   SimpleNamespace(evict_context_caches=lambda context:seen.append('context')),
   object(),SimpleNamespace(clear=clear),SimpleNamespace(close=close))
 assert result.value is interrupted
 assert seen==['graph','owner','context','jax','gc']
 assert any('secondary owner failure' in note for note in interrupted.__notes__)

def test_product_recurrence_uses_level17_q36_tail_not_output_level_tail(monkeypatch):
 import os,math
 monkeypatch.setenv('JAX_PLATFORMS','cpu')
 monkeypatch.setenv('CROSS_ROOT',str(Path(__file__).resolve().parents[1]/'checkout'))
 import component
 from spec import parameters
 p=parameters();scale=p['output_scale']
 expected=scale*scale/(269221889*260571137)
 assert p['q_towers'][34:36]==[269221889,260571137]
 assert component.expected_product_scale(p,17,scale,scale)==expected
 wrong=scale*scale/(256376833*257949697)
 assert not math.isclose(expected,wrong,rel_tol=1e-12)
 # Unequal input scales must also survive the same actual divisor rule.
 assert component.expected_product_scale(p,17,scale,scale*2)==expected*2

@pytest.mark.parametrize('level',[0,19,True,-1])
def test_invalid_product_scale_level_is_rejected(monkeypatch,level):
 monkeypatch.setenv('JAX_PLATFORMS','cpu')
 monkeypatch.setenv('CROSS_ROOT',str(Path(__file__).resolve().parents[1]/'checkout'))
 import component
 from spec import parameters
 with pytest.raises(ValueError):component.expected_product_scale(parameters(),level,1.,1.)

def test_initial_report_write_failure_becomes_fresh_failed_metadata(tmp_path,monkeypatch):
 from types import SimpleNamespace
 import collect
 original=collect.process.write_json;calls=0
 def write(path,value):
  nonlocal calls
  if path.name=='report.json':
   calls+=1
   if calls==1:raise OSError('initial publication failed')
  return original(path,value)
 monkeypatch.setattr(collect.process,'write_json',write)
 monkeypatch.setattr(collect.process,'run_case',lambda *a,**k:(_ for _ in ()).throw(AssertionError('child must not launch')))
 args=SimpleNamespace(output=tmp_path/'evidence',snapshot=tmp_path/'unused',preprocess_python=Path(sys.executable))
 assert collect.run(args)==1
 report=json.loads((args.output/'report.json').read_text())
 assert report['passed'] is False and 'initial publication failed' in report['error']
 assert report['stages']=={} and report['owned_component_directory_removed']

def test_software_metadata_failure_keeps_fresh_failure_report(tmp_path,monkeypatch):
 from types import SimpleNamespace
 import collect
 monkeypatch.setattr(collect.process,'software_versions',lambda:(_ for _ in ()).throw(RuntimeError('metadata failure')))
 args=SimpleNamespace(output=tmp_path/'evidence',snapshot=tmp_path/'unused',preprocess_python=Path(sys.executable))
 assert collect.run(args)==1
 report=json.loads((args.output/'report.json').read_text())
 assert not report['passed'] and 'metadata failure' in report['error'] and report['stages']=={}

def test_all_outer_signals_shield_repeated_cleanup_interruptions():
 import collect,signal
 before={s:signal.getsignal(s) for s in (signal.SIGTERM,signal.SIGHUP,signal.SIGINT)}
 with collect.termination_signals():
  handler=signal.getsignal(signal.SIGINT)
  with pytest.raises(SystemExit) as caught:handler(signal.SIGINT,None)
  assert caught.value.code==130
  assert all(signal.getsignal(s)==signal.SIG_IGN for s in before)
 assert {s:signal.getsignal(s) for s in before}==before
@pytest.mark.parametrize('cancel,fail_final_write',[(False,False),(True,False),(True,True)])
def test_collector_failure_cleanup_and_primary_cancellation(tmp_path,monkeypatch,cancel,fail_final_write):
 from types import SimpleNamespace
 import collect
 original_write=collect.process.write_json
 def fake_case(command,directory,**kwargs):
  record={'returncode':1,'passed':False,'error':'injected preprocessor failure','process_reaped':True,'public_key_store_removed':True,'owned_directory_handle_closed':True}
  original_write(directory/'process.json',record)
  if cancel:raise KeyboardInterrupt('primary cancellation')
  return record
 monkeypatch.setattr(collect.process,'run_case',fake_case)
 if fail_final_write:
  def failing_write(path,value):
   if path.name=='report.json' and 'elapsed_s' in value:raise OSError('secondary final write')
   return original_write(path,value)
  monkeypatch.setattr(collect.process,'write_json',failing_write)
 owned=[];original_mkdtemp=collect.tempfile.mkdtemp
 def own(*a,**k):
  result=original_mkdtemp(*a,dir=tmp_path,**k);owned.append(Path(result));return result
 monkeypatch.setattr(collect.tempfile,'mkdtemp',own)
 args=SimpleNamespace(output=tmp_path/'evidence',snapshot=tmp_path/'unused',preprocess_python=Path(sys.executable))
 if cancel:
  with pytest.raises(KeyboardInterrupt,match='primary cancellation') as captured:collect.run(args)
  if fail_final_write:assert any('secondary final write' in n for n in captured.value.__notes__)
 else:assert collect.run(args)==1
 assert owned and all(not p.exists() for p in owned)
 if not fail_final_write:
  r=json.loads((args.output/'report.json').read_text());assert r['passed'] is False and r['owned_component_directory_removed'] and r['all_processes_reaped']

@pytest.mark.parametrize('mode',['missing','corrupt','nonobject','unreaped'])
def test_collector_unknown_active_process_retains_owned_files(tmp_path,monkeypatch,mode):
 from types import SimpleNamespace
 import collect,shutil
 def case(command,directory,**kwargs):
  if mode=='corrupt':(directory/'process.json').write_text('{')
  if mode=='nonobject':(directory/'process.json').write_text('[]')
  if mode=='unreaped':collect.process.write_json(directory/'process.json',{'process_reaped':False})
  raise KeyboardInterrupt('primary cancellation')
 monkeypatch.setattr(collect.process,'run_case',case)
 args=SimpleNamespace(output=tmp_path/'evidence',snapshot=tmp_path/'unused',preprocess_python=Path(sys.executable))
 with pytest.raises(KeyboardInterrupt,match='primary cancellation'):collect.run(args)
 r=json.loads((args.output/'report.json').read_text());owned=Path(r['owned_component_directory'])
 try:
  assert r['passed'] is False and r['all_processes_reaped'] is False and r['owned_component_directory_removed'] is False
  assert r['owned_directory_handle_closed'] is True and owned.is_dir()
  assert r['stages']['public-preflight']['process_reaped'] is False
 finally:shutil.rmtree(owned) # No real child was launched by this test double.

def test_collector_replaced_owned_directory_never_deletes_replacement(tmp_path,monkeypatch):
 from types import SimpleNamespace
 import collect,shutil
 moved=[]
 def case(command,directory,**kwargs):
  r=json.loads((directory.parent/'report.json').read_text());owned=Path(r['owned_component_directory']);other=owned.with_name(owned.name+'-moved');owned.rename(other);moved.extend([owned,other]);owned.mkdir();(owned/'sentinel').write_text('keep')
  return {'process_reaped':True,'returncode':1,'error':'injected','public_key_store_removed':True,'owned_directory_handle_closed':True}
 monkeypatch.setattr(collect.process,'run_case',case)
 args=SimpleNamespace(output=tmp_path/'evidence',snapshot=tmp_path/'unused',preprocess_python=Path(sys.executable))
 try:
  assert collect.run(args)==1;r=json.loads((args.output/'report.json').read_text());assert not r['owned_component_directory_removed'] and r['owned_directory_handle_closed'];assert (moved[0]/'sentinel').read_text()=='keep';assert moved[1].is_dir()
 finally:
  for item in moved:shutil.rmtree(item)
