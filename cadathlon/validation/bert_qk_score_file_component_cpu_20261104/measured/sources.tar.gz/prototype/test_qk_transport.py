"""Backend-free strict two-upload QK transport and public contract checks."""
import copy,hashlib,os,shutil,sys
from types import SimpleNamespace
from pathlib import Path
import numpy as np
import pytest
ROOT=Path(__file__).resolve().parents[1]/'checkout'
sys.path[:0]=[str(ROOT/'cadathlon/common')]
import transport as t
import contracts
from spec import parameters,PUBLIC_ATTENTION_MASK,ASSETS,REVISION,KINDS

PUBLIC={'context_id':'a'*64,'parameters':parameters()}
NONCE='qk_independent_request'


def manifest(role):
    return dict(format=t.FORMAT,context_id=PUBLIC['context_id'],request_id=NONCE,
        role=role,input_digest=None,level=18,files={'bundle.json':'b'*64,'ct_0.npz':'c'*64})


def pair():return {role:manifest(role) for role in t.INPUT_ROLES}


def rewrite_metadata(directory,name,value):
    path=directory/'ct_0.npz'
    with np.load(path,allow_pickle=False) as data:arrays={key:np.asarray(data[key]) for key in data.files}
    arrays[name]=value;np.savez(path,**arrays)
    m=t._json((directory/'transport.json').read_bytes())
    m['files']['ct_0.npz']=hashlib.sha256(path.read_bytes()).hexdigest()
    (directory/'transport.json').write_bytes(t._canonical(m))


@pytest.fixture(scope='module')
def valid_directories(tmp_path_factory):
    root=tmp_path_factory.mktemp('qk_transport')
    digest=t.request_pair_digest(pair(),public=PUBLIC,request_id=NONCE)
    output={}
    for role in (*t.INPUT_ROLES,*t.OUTPUT_LEVELS):
        directory=root/role;directory.mkdir()
        c=t._contract(PUBLIC,NONCE,role,None if role in t.INPUT_ROLES else digest)
        payload=np.zeros(c['shape'],dtype=np.uint32)
        np.savez(directory/'ct_0.npz',payload=payload,moduli=np.asarray(c['moduli'],dtype=np.int64),
            degree_layout=np.asarray(c['layout'],dtype=np.int64),precision=np.asarray(32,dtype=np.int64),
            scale=np.asarray(c['scale'],dtype=np.float64),nsd=np.asarray(1,dtype=np.int64))
        (directory/'bundle.json').write_bytes(t._canonical({'shape':{'__ct__':0},'count':1}))
        m=dict(format=t.FORMAT,context_id=PUBLIC['context_id'],request_id=NONCE,role=role,
            input_digest=c['input_digest'],level=c['level'],files={name:hashlib.sha256((directory/name).read_bytes()).hexdigest() for name in ('bundle.json','ct_0.npz')})
        (directory/'transport.json').write_bytes(t._canonical(m));output[role]=directory
    return output,digest


@pytest.mark.parametrize('role,level,count',[('query_input',18,38),('key_input',18,38),('raw_scores',7,16),('masked_scores',6,14)])
def test_exact_role_level_qprefix_and_payload(valid_directories,role,level,count):
    dirs,digest=valid_directories
    data,scale,c,m=t.validate_ciphertext(dirs[role],public=PUBLIC,request_id=NONCE,role=role,input_digest=None if role in t.INPUT_ROLES else digest)
    assert data.shape==(1,2,256,512,count) and data.dtype==np.uint32
    assert c['level']==level and c['moduli']==parameters()['q_towers'][:count]
    assert scale==parameters()['scaling_factor']


def test_pair_order_independent_and_both_digests_bound():
    original=pair();expected=t.request_pair_digest(original,public=PUBLIC,request_id=NONCE)
    assert contracts.request_digest(dict(reversed(list(original.items()))),public=PUBLIC,request_id=NONCE)==expected
    for role in t.INPUT_ROLES:
        changed=copy.deepcopy(original);changed[role]['files']['ct_0.npz']='d'*64
        assert t.request_pair_digest(changed,public=PUBLIC,request_id=NONCE)!=expected


@pytest.mark.parametrize('change',['missing','extra','swap','context','nonce','level','input_digest','extra_field','digest'])
def test_pair_fail_closed(change):
    m=pair()
    if change=='missing':del m['key_input']
    elif change=='extra':m['value']=manifest('value')
    elif change=='swap':m['query_input'],m['key_input']=m['key_input'],m['query_input']
    elif change=='context':m['key_input']['context_id']='e'*64
    elif change=='nonce':m['key_input']['request_id']='other_nonce'
    elif change=='level':m['key_input']['level']=True
    elif change=='input_digest':m['key_input']['input_digest']='e'*64
    elif change=='extra_field':m['key_input']['private_ids']=[1,2]
    elif change=='digest':m['key_input']['files']['ct_0.npz']='not-a-digest'
    with pytest.raises(ValueError):t.request_pair_digest(m,public=PUBLIC,request_id=NONCE)


def test_response_rejects_replaced_either_upload(valid_directories):
    dirs,digest=valid_directories
    for role in t.INPUT_ROLES:
        changed=pair();changed[role]['files']['ct_0.npz']='d'*64
        new=t.request_pair_digest(changed,public=PUBLIC,request_id=NONCE)
        with pytest.raises(ValueError,match='binding mismatch'):
            t.validate_ciphertext(dirs['raw_scores'],public=PUBLIC,request_id=NONCE,role='raw_scores',input_digest=new)


@pytest.mark.parametrize('field,value',[('nsd',np.asarray(2,dtype=np.int64)),('scale',np.asarray(1.,dtype=np.float64)),
    ('precision',np.asarray(64,dtype=np.int64)),('moduli',np.asarray(parameters()['q_towers'][1:17],dtype=np.int64)),
    ('degree_layout',np.asarray([512,256],dtype=np.int64))])
def test_rehashed_bad_metadata_rejected(tmp_path,valid_directories,field,value):
    dirs,digest=valid_directories;dest=tmp_path/'bad';shutil.copytree(dirs['raw_scores'],dest)
    rewrite_metadata(dest,field,value)
    with pytest.raises(ValueError):t.validate_ciphertext(dest,public=PUBLIC,request_id=NONCE,role='raw_scores',input_digest=digest)


def test_rehashed_oversized_residue_rejected(tmp_path,valid_directories):
    dirs,digest=valid_directories;dest=tmp_path/'bad';shutil.copytree(dirs['masked_scores'],dest)
    payload=np.zeros((1,2,256,512,14),dtype=np.uint32);payload[0,0,0,0,0]=parameters()['q_towers'][0]
    rewrite_metadata(dest,'payload',payload)
    with pytest.raises(ValueError,match='residue'):t.validate_ciphertext(dest,public=PUBLIC,request_id=NONCE,role='masked_scores',input_digest=digest)


def test_plaintext_bookkeeping_and_extra_inventory_rejected(tmp_path,valid_directories):
    dirs,digest=valid_directories;dest=tmp_path/'bad';shutil.copytree(dirs['masked_scores'],dest)
    (dest/'private_ids.json').write_text('[1]')
    with pytest.raises(ValueError,match='inventory'):t.validate_ciphertext(dest,public=PUBLIC,request_id=NONCE,role='masked_scores',input_digest=digest)
    (dest/'private_ids.json').unlink();b={'shape':{'__ct__':0},'count':1,'private_ids':[1]}
    (dest/'bundle.json').write_bytes(t._canonical(b));m=t._json((dest/'transport.json').read_bytes())
    m['files']['bundle.json']=hashlib.sha256((dest/'bundle.json').read_bytes()).hexdigest();(dest/'transport.json').write_bytes(t._canonical(m))
    with pytest.raises(ValueError,match='bookkeeping'):t.validate_ciphertext(dest,public=PUBLIC,request_id=NONCE,role='masked_scores',input_digest=digest)


@pytest.mark.parametrize('field,value',[('batch',True),('max_level',1),('degree_layout',[512,256]),('dnum',3),('secret_key',[])])
def test_changed_fixed_parameter_rejected_before_payload(field,value):
    public=copy.deepcopy(PUBLIC);public['parameters'][field]=value
    with pytest.raises(ValueError):t._contract(public,NONCE,'query_input',None)


def test_packing_binds_mask_and_keeps_all_query_rows():
    layout=contracts.packing_contract()
    assert layout['public_attention_mask']==list(PUBLIC_ATTENTION_MASK) and sum(PUBLIC_ATTENTION_MASK)==15
    assert layout['query_rows_remain_active'] and layout['query_tile']==0 and layout['key_tile']==7 and layout['offset']==15
    assert layout['output_levels']=={'raw_scores':7,'masked_scores':6}
    rows=np.arange(16*768,dtype=np.float64).reshape(16,768)/1024
    packed=contracts.pack_rows(rows)
    assert packed.shape==(65536,) and np.array_equal(contracts.unpack_rows(packed),rows)
    assert np.count_nonzero(packed.reshape(16,4096)[:,768:])==0
    with pytest.raises(ValueError):contracts.pack_rows(rows.astype(np.float32))


def test_self_consistently_rehashed_wrong_model_rejected(tmp_path):
    # Every file/digest/shape agrees with this export, while its tensor bytes
    # differ from the checkpoint whose asset identity the manifest declares.
    manifest=dict(schema='pinned-bert-layer0-qk-v1',model_id='google-bert/bert-base-cased-finetuned-mrpc',
        revision=REVISION,asset_sha256=ASSETS,tensors={})
    for kind in KINDS:
        for suffix,shape in (('weight',(768,768)),('bias',(768,))):
            value=np.zeros(shape,dtype='<f4');name=f'{kind}_{suffix}.npy';path=tmp_path/name
            np.save(path,value,allow_pickle=False)
            manifest['tensors'][name]=dict(name=f'bert.encoder.layer.0.attention.self.{kind}.{suffix}',
                shape=list(shape),dtype='<f4',file_sha256=contracts.sha(path),tensor_sha256=hashlib.sha256(value.tobytes()).hexdigest())
    (tmp_path/'model_manifest.json').write_bytes(t._canonical(manifest))
    with pytest.raises(ValueError,match='public tensor identity'):
        contracts.load_model(tmp_path)


def test_public_hash_rejects_symlink_fifo_and_oversize(tmp_path):
    regular=tmp_path/'file';regular.write_bytes(b'abc')
    link=tmp_path/'link';link.symlink_to(regular)
    with pytest.raises((OSError,ValueError)):contracts.sha(link)
    fifo=tmp_path/'fifo';os.mkfifo(fifo)
    with pytest.raises(ValueError):contracts.sha(fifo)
    with pytest.raises(ValueError):contracts.sha(regular,2)


@pytest.mark.parametrize('field,message',[('streaming_linear_source_sha256','streaming linear source'),('score_routing_source_sha256','score routing source')])
def test_stale_helper_rejected_before_any_key_load(tmp_path,field,message):
    body=dict(schema='bert-qk-scores-public-ckks-v1',parameters=parameters(),rotations=[],arrays={},
        representation='standard-ntt-residues/digit-modulus-degree',keygen_source_sha256='a'*64,
        model_manifest_sha256='a'*64,packing=contracts.packing_contract(),
        streaming_linear_source_sha256=contracts.linear_source_sha256(),score_routing_source_sha256=contracts.routing_source_sha256())
    body[field]='0'*64
    manifest=dict(body,context_id=contracts.digest(body))
    (tmp_path/'public_manifest.json').write_bytes(t._canonical(manifest))
    with pytest.raises(ValueError,match=message):contracts.load_public(tmp_path,tmp_path/'no-model')


def test_loader_remains_backend_free(valid_directories):
    # These tests invoke only NumPy manifests/codec metadata, not ciphertexts.
    assert 'jax' not in sys.modules


@pytest.mark.parametrize('replace',[False,True])
def test_writer_failure_pins_inode_and_retains_replacement(tmp_path,monkeypatch,replace):
    contract=t._contract(PUBLIC,NONCE,'query_input',None)
    class FakePolynomial:
        shape=contract['shape'];degree_layout=contract['layout'];precision=32
        _ckks_nsd=1;_ckks_scale=contract['scale']
        def validate(self):return self
        def get_moduli(self):return contract['moduli']
    target=tmp_path/'request';moved=tmp_path/'moved';handles=[]
    original_open=t.os.open
    def opened(path,flags,*args,**kwargs):
        fd=original_open(path,flags,*args,**kwargs)
        if Path(path)==target:handles.append(fd)
        return fd
    def writer(ct,directory):
        assert handles and os.fstat(handles[0]).st_ino==directory.stat().st_ino
        (directory/'partial').write_text('partial')
        if replace:
            directory.rename(moved);directory.mkdir();(directory/'unowned').write_text('keep')
        raise KeyboardInterrupt('primary writer cancellation')
    monkeypatch.setattr(t.os,'open',opened)
    monkeypatch.setitem(sys.modules,'jaxite_word',SimpleNamespace(Polynomial=FakePolynomial))
    monkeypatch.setitem(sys.modules,'bundle_io',SimpleNamespace(save_bundle=writer))
    with pytest.raises(KeyboardInterrupt,match='primary writer cancellation'):
        t.save_ciphertext(FakePolynomial(),target,public=PUBLIC,request_id=NONCE,role='query_input')
    with pytest.raises(OSError):os.fstat(handles[0])
    if replace:
        assert (target/'unowned').read_text()=='keep' and (moved/'partial').exists()
    else:assert not target.exists()
