"""Real secure CPU parity and lifecycle proof for isolated rotation binding hits."""
import sys,time,json,hashlib,importlib.util,gc,weakref
from pathlib import Path
sys.path[:0]=['/tmp/rotation-binding-hit-lab','/home/jianming_gatech/CROSS/cadathlon/common','/home/jianming_gatech/CROSS']
import jax,numpy as np
from jaxite_word import CKKSContext,key_gen,he_params,util
from jaxite_word.composite_prime_gen import composite_prime_gen
from encrypted_rotation import CompiledRotation,rotation_state_without_controls
ROOT=Path('/home/jianming_gatech/CROSS');LAB=Path('/tmp/rotation-binding-hit-lab')
sources=[Path(__file__),LAB/'encrypted_rotation.py',*sorted((ROOT/'jaxite_word').rglob('*.py')),*sorted((ROOT/'cadathlon/common').glob('encrypted_*.py')),ROOT/'cadathlon/common/support.py']
hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
spec=importlib.util.spec_from_file_location('original_rotation',ROOT/'cadathlon/common/encrypted_rotation.py');original=importlib.util.module_from_spec(spec);spec.loader.exec_module(original)
jax.config.update('jax_enable_x64',True);assert jax.default_backend()=='cpu'
started=time.perf_counter();N=16384;depth=6;dnum=8;batch=2
q=composite_prime_gen(2,2*(depth+1),61,44,2*N,31);p=util.generate_p_towers(q,dnum,N,aux_bits=30)
assert he_params.qp_is_secure(q,p,N,he_params.SecurityTarget(128,'classical'))
keys=key_gen.gen_pke_pair(q,[],N);evaluation=key_gen.gen_evaluation_key(keys['secret_key'],q=q,P=p,dnum=dnum)
indices=(1,7,-3)
rotations={index:key_gen.gen_rotation_key(keys['secret_key'],q,p,index,dnum=dnum)[index] for index in indices}
S=float(q[-2])*q[-1]
params=dict(degree=N,num_slots=N//2,scaling_factor=S,output_scale=S,q_towers=q,p_towers=p,composite_degree=2,degree_layout=(128,128),p=44,CKKS_M_FACTOR=1,max_bits_in_word=61,noise_scale_degree=1)
client=CKKSContext(dict(params,**keys));ctx=CKKSContext(dict(params,evaluation_key=[jax.numpy.asarray(evaluation[name],dtype='uint32').transpose(0,2,1) for name in ('a','b')]))
ctx.program_initialization(list(indices),dnum=dnum,r=128,c=128,batch=batch,pregenerated_rotation_keys=rotations)
slots=np.linspace(-.75,.75,N//2);ciphertext=client.encrypt_slots_batch([slots,.5*slots],scale=S*.75)
assert ctx.secret_key is None and ctx._param_cache.secret_key is None and ctx.parameters.get('secret_key') is None
fresh=CompiledRotation(ctx);old=original.CompiledRotation(ctx)
import herot
real_control_gen=herot._HERotKernel.control_gen;phase='';counts={}
def counted(*args,**kwargs):
 counts[phase]=counts.get(phase,0)+1
 return real_control_gen(*args,**kwargs)
herot._HERotKernel.control_gen=counted
records=[];state_records=[]
try:
 for level in (6,3,0):
  value=ciphertext if level==6 else ctx.he_level_reduce[6,level].level_reduce(ciphertext)
  # Metadata-only NSD2 case confirms rotations do not reinterpret scale/NSD.
  value._ckks_nsd=2 if level==3 else 1
  for index in indices:
   phase=f'state_facade_{level}_{index}';begin=time.perf_counter();facade=ctx.he_rot[level,index]
   expected_state=facade._rotation_state();jax.block_until_ready(expected_state)
   facade_seconds=time.perf_counter()-begin
   phase=f'state_direct_{level}_{index}';begin=time.perf_counter();direct=rotation_state_without_controls(ctx._param_cache,level,index);jax.block_until_ready(direct)
   direct_seconds=time.perf_counter()-begin
   for expected,actual in zip(expected_state,direct,strict=True):
    assert expected.dtype==actual.dtype;np.testing.assert_array_equal(actual,expected)
   state_records.append(dict(level=level,index=index,bit_exact=True,shapes=[list(x.shape) for x in direct],facade_state_seconds=facade_seconds,direct_state_seconds=direct_seconds))
   del facade,expected_state,direct
   ctx.he_rot._instances.clear();ctx._param_cache._formatted_rotation_keys.clear()
   phase=f'original_rotate_{level}_{index}';begin=time.perf_counter();expected=old.rotate(value,index);old_seconds=time.perf_counter()-begin
   phase=f'candidate_rotate_{level}_{index}';begin=time.perf_counter();actual=fresh.rotate(value,index);new_seconds=time.perf_counter()-begin
   np.testing.assert_array_equal(actual.polynomial,expected.polynomial)
   assert actual._ckks_scale==expected._ckks_scale==value._ckks_scale and actual._ckks_nsd==expected._ckks_nsd==value._ckks_nsd
   assert tuple(actual.moduli)==tuple(value.moduli)
   assert counts.get(f'candidate_rotate_{level}_{index}',0)==(1 if index==indices[0] else 0)
   assert not ctx._param_cache._formatted_rotation_keys
   assert not ctx.he_rot._instances
   records.append(dict(level=level,index=index,bit_exact=True,scale=actual._ckks_scale,nsd=actual._ckks_nsd,old_seconds=old_seconds,candidate_seconds=new_seconds,binding_hit=index!=indices[0],candidate_control_gen_calls=counts.get(f'candidate_rotate_{level}_{index}',0)))
   print(json.dumps(records[-1]),flush=True)
  del expected,actual
 assert old.compile_count==fresh.compile_count==3
 # Reuse bound arithmetic after global eager cache eviction, and after public
 # formatted-key cache eviction. It must not reconstruct any HERot controls.
 jax.clear_caches();ctx.he_rot.clear();ctx._param_cache._formatted_rotation_keys.clear()
 phase='candidate_after_eager_cache_clear';actual=fresh.rotate(value,indices[1]);assert counts.get(phase,0)==0
 phase='original_after_eager_cache_clear';expected=old.rotate(value,indices[1]);np.testing.assert_array_equal(actual.polynomial,expected.polynomial);assert counts.get(phase,0)==1
 # A serial caller may have prebuilt a keyed facade for a binding-hit index.
 # The candidate must retire that facade, preserving prior ownership behavior.
 prebuilt=ctx.he_rot[0,indices[1]];phase='candidate_prebuilt_facade_retirement'
 actual=fresh.rotate(value,indices[1]);np.testing.assert_array_equal(actual.polynomial,expected.polynomial)
 assert counts.get(phase,0)==0 and not ctx.he_rot._instances
 del prebuilt
 before=fresh.compile_count;fresh.clear();phase='candidate_rebind';actual=fresh.rotate(value,indices[1]);np.testing.assert_array_equal(actual.polynomial,expected.polynomial);assert fresh.compile_count==before
 # Missing offline key must fail in keyless evaluator without retaining state.
 try:fresh.rotate(value,19)
 except ValueError as exc:assert 'not supplied' in str(exc) and 'unavailable' in str(exc)
 else:raise AssertionError('missing offline key unexpectedly accepted')
 # Retain compiled executables while retiring binding-owned real NTT arrays.
 code=fresh._compiler;refs=[weakref.ref(item) for item in fresh._binding[1].controls]
 fresh.clear();old.clear();del fresh,old,value,expected,actual,ciphertext,client,ctx
 from jaxite_word import polynomial,ckks_ctx
 import ntt_mm
 jax.clear_caches();polynomial._POLYNOMIAL_REGISTRY.clear();ntt_mm._barrett_ntt_context_cache.clear();gc.collect()
 assert not [ref() for ref in refs if ref() is not None]
finally:herot._HERotKernel.control_gen=real_control_gen
assert hashes=={str(path):hashlib.sha256(Path(path).read_bytes()).hexdigest() for path in hashes}
report=dict(passed=True,scope='Isolated real secure CPU rotation binding-hit parity; no TPU or transformer performance claim',degree=N,depth=depth,dnum=dnum,batch=batch,num_q=len(q),num_p=len(p),log2_qp=sum(np.log2(float(v)) for v in q+p),security_128_classical=True,secretless_server=True,missing_offline_key_rejected=True,retired_controls_released=True,source_hashes_unchanged=True,source_hashes=hashes,records=records,state_records=state_records,control_gen_counts=counts,compile_count=code.compile_count,total_seconds=time.perf_counter()-started)
(LAB/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ('records','state_records','source_hashes','control_gen_counts')}),flush=True)
