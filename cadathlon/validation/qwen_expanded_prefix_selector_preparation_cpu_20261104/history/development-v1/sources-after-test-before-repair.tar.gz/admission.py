"""Pure bytes-only future proof contract, exercised only with synthetic evidence."""
from dataclasses import dataclass
import io,json,math,tarfile
from pathlib import PurePosixPath
from selector import NORMS,BASELINE_SHA256,EPSILON,canonical,digest

@dataclass(frozen=True)
class InitialAdmission:
    union_bytes:bytes
    proof_sha256:str
    scope:str='synthetic_preparation_only'

@dataclass(frozen=True)
class ProofPins:
    parent_sha256:str
    worker_sha256:str
    archive_sha256:str
    root_sha256:str
    source_manifest_bytes:bytes

def parse(raw):
    if type(raw)is not bytes:raise ValueError('exact bytes required')
    def pairs(items):
        out={}
        for k,v in items:
            if k in out:raise ValueError('duplicate JSON field')
            out[k]=v
        return out
    def invalid(x):raise ValueError('nonfinite JSON')
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=invalid)

def exact_int(x,wanted):return type(x)is int and x==wanted

def require_flags(row,true=(),false=()):
    if type(row)is not dict or any(row.get(k)is not True for k in true)or any(row.get(k)is not False for k in false):raise ValueError('required typed proof flag differs')

def lengths():
    return [n for _ in range(96)for n in range(1,33)]+[16+step for _ in range(2)for _ in range(16)for step in range(4)]

def expected_counts():
    seq=lengths();tokens=sum(seq);scores=16*sum(s*(s+1)//2 for s in seq)
    rows={}
    for name in NORMS:
        rows[name]=3200 if name=='final.inverse_sqrt'else tokens*(16 if '.q.'in name else 8 if '.k.'in name else 1)
    for i in range(28):
        rows[f'{i}.silu']=tokens*3072
        rows[f'{i}.softmax.raw_valid']=scores
        rows[f'{i}.softmax.centered']=scores
    return rows

def stat(row,count,positive=False):
    if type(row)is not dict or set(row)!={'count','minimum','maximum','nonfinite','nonpositive'}:raise ValueError('exact range statistic schema required')
    if not exact_int(row['count'],count)or not exact_int(row['nonfinite'],0)or type(row['nonpositive'])is not int or not 0<=row['nonpositive']<=count:raise ValueError('range count/finite coverage differs')
    lo,hi=row['minimum'],row['maximum']
    if any(type(x)is not float or not math.isfinite(x)for x in(lo,hi))or lo>hi:raise ValueError('finite typed range required')
    if positive and(not EPSILON<=lo or row['nonpositive']!=0):raise ValueError('positive norm input required')
    return dict(row)

def range_union(ranges):
    if type(ranges)is not dict or set(ranges)!={'native','exact','native_exact_union','baseline_generator_separate_diagnostic','initial_bounds_include_baseline'}:raise ValueError('initial range families differ')
    if ranges['initial_bounds_include_baseline']is not False:raise ValueError('baseline cannot enter initial bounds')
    counts=expected_counts();families=[]
    for kind in('native','exact'):
        family=ranges[kind]
        if type(family)is not dict or not exact_int(family.get('contexts'),3200)or family.get('reciprocal_inputs_observed')is not False:raise ValueError('complete native/exact range family required')
        rows=family['ranges']
        if type(rows)is not dict or set(rows)!=set(counts):raise ValueError('all native/exact nonlinear input labels required')
        cleaned={name:stat(rows[name],count,name in NORMS)for name,count in counts.items()}
        score_rows=family['score_rows']
        if type(score_rows)is not dict or set(score_rows)!=set(map(str,range(28))):raise ValueError('all28 causal score layers required')
        for layer in score_rows.values():
            if type(layer)is not dict or set(layer)!=set(map(str,range(1,33))):raise ValueError('every actual causal K required')
            for key,row in layer.items():
                k=int(key);contexts=sum(s>=k for s in lengths())
                if not exact_int(row.get('query'),k-1)or not exact_int(row.get('key_count'),k)or not exact_int(row.get('contexts'),contexts)or row.get('shape')!=[1,16,k]or any(type(x)is not int for x in row['shape']):raise ValueError('per-query/K score coverage differs')
                if row.get('k1_bypass')is not(k==1)or not exact_int(row.get('reciprocal_observations'),0):raise ValueError('K1 bypass/no invented reciprocal required')
                stat(row['raw_valid'],16*k*contexts);centered=stat(row['centered'],16*k*contexts)
                if k==1 and(centered['minimum']!=0. or centered['maximum']!=0.):raise ValueError('K1 centered bypass must be zero')
        families.append(cleaned)
    union={}
    for name in counts:
        a,b=(f[name]for f in families)
        union[name]=dict(count=a['count']+b['count'],minimum=min(a['minimum'],b['minimum']),maximum=max(a['maximum'],b['maximum']),nonfinite=0,nonpositive=a['nonpositive']+b['nonpositive'])
    if canonical(union)!=canonical(ranges['native_exact_union']):raise ValueError('native/exact union differs; baseline must remain excluded')
    return union

def authenticate_synthetic(parent_bytes,worker_bytes,archive_bytes,root_bytes,*,pins):
    """No IO. Future actual admission requires separate reviewed pins/entrypoint."""
    if type(pins)is not ProofPins:raise ValueError('externally authenticated pin bundle required')
    for raw,pin in((parent_bytes,pins.parent_sha256),(worker_bytes,pins.worker_sha256),(archive_bytes,pins.archive_sha256),(root_bytes,pins.root_sha256)):
        if type(raw)is not bytes or type(pin)is not str or len(pin)!=64 or digest(raw)!=pin:raise ValueError('external proof digest differs')
    sources=parse(pins.source_manifest_bytes)
    if type(sources)is not dict or not sources:raise ValueError('reviewed producer source inventory required')
    for name,pin in sources.items():
        path=PurePosixPath(name)
        if type(name)is not str or path.is_absolute()or '..'in path.parts or path.as_posix()!=name or type(pin)is not str or len(pin)!=64:raise ValueError('invalid reviewed source map')
    found={};total=0
    if len(archive_bytes)>32<<20:raise ValueError('source archive bound exceeded')
    with tarfile.open(fileobj=io.BytesIO(archive_bytes),mode='r:gz')as t:
        for m in t:
            total+=m.size
            if m.name not in sources or m.name in found or not m.isfile()or m.size>16<<20 or total>32<<20:raise ValueError('source archive member differs')
            found[m.name]=digest(t.extractfile(m).read())
    if found!=sources:raise ValueError('source archive differs from independent reviewed inventory')
    parent,worker,review=map(parse,(parent_bytes,worker_bytes,root_bytes))
    for r in(parent,worker):
        require_flags(r,true=('passed','complete','cleanup_completed','signal_restoration_completed','terminal_after_body_cleanup_and_signal_restoration_attempts','acceptance_requires_independent_exit0_reap_and_exact_report_hash','source_files_unchanged'),false=('coefficient_selection',))
        if r.get('source_hashes_start')!=sources or r.get('source_hashes_end')!=sources or r.get('source_manifest_sha256')!=digest(pins.source_manifest_bytes):raise ValueError('producer source binding differs')
        if r.get('audit_denials')!=[] or 'error_type'in r:raise ValueError('producer failure/denial present')
    require_flags(parent,true=('actual_observer_stage','child_reaped','child_group_absent'),false=('model_forward',))
    if not exact_int(parent.get('child_returncode'),0)or parent.get('worker_report_sha256')!=pins.worker_sha256 or canonical(parent.get('worker'))!=canonical(worker)or parent.get('source_archive',{}).get('sha256')!=pins.archive_sha256:raise ValueError('parent/worker/archive completion binding differs')
    require_flags(worker,true=('initial_selection_admissible','model_forward','calibration_reauthenticated','private_directory_handle_closed','private_outputs_retained','external_inputs_never_removed','exact_order'),false=('tokenizer_execution','validation_inputs_read','coefficient_selection_performed','encrypted_execution','baseline_ranges_in_initial_selection','contains_tokens_or_logits'))
    integer_fields={'expected_entries':3200,'retained_entries':3200,'semantic_passes':3200,'baseline_complete':64,'original416_members':416,'new_protocol_candidates_used':0,'new_candidates_evaluated':0}
    if any(not exact_int(worker.get(k),n)for k,n in integer_fields.items()):raise ValueError('initial full-workload accounting differs')
    if worker.get('schema')!='qwen-expanded-initial-observer-ledger-v1'or worker.get('baseline_manifest_sha256')!=BASELINE_SHA256 or worker.get('baseline_role')!='initial_free_trace_generator_only':raise ValueError('initial observer/baseline role differs')
    for kind,n in(('prefill',3072),('teacher',64),('free',64)):
        row=worker.get('by_kind',{}).get(kind,{})
        if any(not exact_int(row.get(k),v)for k,v in dict(expected=n,records=n,observed=n,complete=n,invalid=0,unmeasured=0,semantic_failures=0).items()):raise ValueError('partial initial workload forbidden')
    if set(worker.get('by_kind',{}))!={'prefill','teacher','free'}:raise ValueError('initial kinds differ')
    for field in('hook_invariance_by_length','exact_invariance_by_length'):
        rows=worker.get(field,{})
        if set(rows)!=set(map(str,range(1,33)))or any(x is not True for x in rows.values()):raise ValueError('all-length invariance required')
    rows=worker.get('prefills_by_length',{})
    if set(rows)!=set(map(str,range(1,33)))or any(not exact_int(x,96)for x in rows.values()):raise ValueError('all-length prefill counts differ')
    required=dict(schema='qwen-initial3200-root-review-contract-v1',passed=True,parent_report_sha256=pins.parent_sha256,worker_report_sha256=pins.worker_sha256,source_archive_sha256=pins.archive_sha256,source_manifest_sha256=digest(pins.source_manifest_bytes),outer_exit_code=0,outer_reaped=True,outer_group_absent=True,worker_exit_code=0,worker_reaped=True,worker_group_absent=True,exact_ordered_contexts=3200,per_context_norm_input_sites=113,per_context_silu_sites=28,per_context_causal_score_sites=28,baseline_free_contexts=64,baseline_excluded=True,per_context_coverage_independently_verified=True,aggregate_ranges_independently_recomputed=True,source_inventory_independently_verified=True)
    if type(review)is not dict or set(review)!=set(required)or any(type(review[k])is not type(v)or review[k]!=v for k,v in required.items()):raise ValueError('independent complete initial root/outer proof required')
    union=range_union(worker['input_ranges'])
    return InitialAdmission(canonical(union),digest(canonical(dict(parent=pins.parent_sha256,worker=pins.worker_sha256,root=pins.root_sha256,archive=pins.archive_sha256))))

def admit_actual(*args,**kwargs):raise RuntimeError('Actual observer admission is disabled until reviewed producer pins and separate grant')
