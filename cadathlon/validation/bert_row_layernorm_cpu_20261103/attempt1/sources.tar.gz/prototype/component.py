"""Separate client/server/client proof of two fixed BERT row LayerNorms."""
from pathlib import Path
import argparse
import gc
import hashlib
import importlib
import io
import json
import os
import shutil
import sys
import time

import numpy as np

if os.environ.get('JAX_PLATFORMS') != 'cpu':
    raise RuntimeError('explicit CPU backend required')
ROOT = Path(os.environ['CROSS_ROOT']).resolve()
sys.path[:0] = [str(ROOT), str(ROOT/'cadathlon/common')]
from spec import KINDS, CHECKPOINTS, ROLE_LEVELS, INPUT_ROLES, RULES, ROTATIONS, parameters
from contracts import (check_parameters, digest, write, sha, load_model, store_array,
    load_public, normalization_source_sha256, packing_contract, combined_request_digest)
from transport import (load_ciphertext, save_ciphertext, manifest_digest,
    validate_ciphertext, _json, _read_regular)


def crypto():
    import jax
    from jaxite_word import CKKSContext, ckks_ctx, key_gen
    jax.config.update('jax_enable_x64', True)
    if {device.platform for device in jax.devices()} != {'cpu'}:
        raise ValueError('unexpected accelerator')
    return jax, CKKSContext, ckks_ctx, key_gen


def context_parameters(p):
    return {name:p[name] for name in ('degree','num_slots','q_towers','p_towers',
        'composite_degree','degree_layout','scaling_factor','output_scale','sigma',
        'secret_distribution')} | dict(p=56, CKKS_M_FACTOR=1, max_bits_in_word=61, noise_scale_degree=1)


def cleanup(jax, ckks, context=None, graph=None, owner=None):
    primary = sys.exception()
    failures = []
    callbacks = []
    if graph is not None:
        callbacks.append(graph.clear)
    if owner is not None:
        callbacks.append(owner.close)
    if context is not None:
        callbacks.append(lambda: ckks.evict_context_caches(context))
    callbacks.extend((jax.clear_caches, gc.collect))
    for callback in callbacks:
        try:
            callback()
        except BaseException as error:
            failures.append(error)
    if failures:
        if primary is not None:
            for error in failures:
                primary.add_note('Cleanup also failed: ' + str(error))
        else:
            cancellation = next((error for error in failures if not isinstance(error, Exception)), None)
            if cancellation is not None:
                for error in failures:
                    if error is not cancellation:
                        cancellation.add_note('Cleanup also failed: ' + str(error))
                raise cancellation
            raise RuntimeError('Cleanup failed: ' + '; '.join(map(str, failures))) from failures[0]


def private_array(private, name, expected_sha):
    raw = _read_regular(private/name, 16384*8+4096)
    if hashlib.sha256(raw).hexdigest() != expected_sha:
        raise ValueError('private input/reference hash mismatch')
    value = np.load(io.BytesIO(raw), allow_pickle=False)
    if value.dtype != np.float64 or value.shape != (16384,) or not np.isfinite(value).all():
        raise ValueError('private input/reference must be one finite float64 tile')
    return value


def preflight():
    p = parameters()
    actual = check_parameters(p)
    from encrypted_row_normalization import RowLayerNorm
    from encrypted_streaming_linear import RowTileLayout
    from encrypted_polynomial import EncryptedPolynomialEvaluator, PolynomialApproximation
    from types import SimpleNamespace
    if list(RowLayerNorm.required_rotation_indices(RowTileLayout(16384))) != ROTATIONS:
        raise ValueError('public rotation inventory differs from the implemented schedule')
    for rule in RULES.values():
        approximation = PolynomialApproximation('inverse_sqrt', tuple(rule['domain']), tuple(rule['coefficients']))
        depth = EncryptedPolynomialEvaluator.polynomial_depth(SimpleNamespace(strategy='power'), approximation)
        if depth+5+1 != p['max_level']:
            raise ValueError('normalization depth/reserve differs from fixed profile')
    alpha = (len(p['q_towers'])+p['dnum']-1)//p['dnum']
    parts = (len(p['q_towers'])+alpha-1)//alpha
    pair_bytes = 2*parts*p['degree']*(len(p['q_towers'])+len(p['p_towers']))*4
    own = (len(ROTATIONS)+1)*pair_bytes + 2*p['degree']*len(p['q_towers'])*4
    # Other accepted component jobs may still be creating their public keys.
    reserve = 8780775424 + 18723373056 + 4*1024**3
    available = shutil.disk_usage('/tmp').free
    if available < own+reserve:
        raise ValueError('insufficient disk space for keys, concurrent reservations and margin')
    return dict(stage='public-preflight', passed=True, parameters=p,
        actual_log2_qp=actual, actual_switch_partitions=parts, rotation_count=len(ROTATIONS),
        raw_owned_public_key_bytes=own, concurrent_and_safety_reserve_bytes=reserve,
        disk_free_bytes=available, private_inputs_read=False, encryption_performed=False)


def setup(root, request_id):
    from assets import validate_private
    jax, Context, ckks, kg = crypto()
    p = parameters()
    bits = check_parameters(p)
    private, public, model = root/'client_only', root/'public', root/'model'
    prep = validate_private(private, model)
    load_model(model)
    public.mkdir()
    started = time.perf_counter()
    client = None
    try:
        pair = kg.gen_pke_pair(p['q_towers'], [], p['degree'], noise_std=p['sigma'])
        evaluation = kg.gen_evaluation_key(pair['secret_key'], q=p['q_towers'],
            P=p['p_towers'], dnum=p['dnum'], noise_std=p['sigma'])
        arrays = {'public_key.npy':store_array(public,'public_key.npy',pair['public_key'])}
        for part in ('a','b'):
            name = 'relin_'+part+'.npy'
            arrays[name] = store_array(public, name, evaluation[part])
        for number, index in enumerate(ROTATIONS,1):
            keys = kg.gen_rotation_key(pair['secret_key'],p['q_towers'],p['p_towers'],index,
                dnum=p['dnum'],noise_std=p['sigma'])[index]
            for part in ('a','b'):
                name = f'rot_{index}_{part}.npy'
                arrays[name] = store_array(public,name,keys[part])
            if number % 5 == 0:
                print(f'Generated {number}/{len(ROTATIONS)} rotation keys',file=sys.stderr,flush=True)
        body = dict(schema='bert-row-norm-public-ckks-v1',parameters=p,rotations=ROTATIONS,
            arrays=arrays,representation='standard-ntt-residues/digit-modulus-degree',
            keygen_source_sha256=sha(kg.__file__),model_manifest_sha256=sha(model/'model_manifest.json'),
            packing=packing_contract(),normalization_source_sha256=normalization_source_sha256())
        manifest = body | {'context_id':digest(body)}
        write(public/'public_manifest.json',manifest)
        secret = store_array(private,'secret.npy',pair['secret_key'])
        os.chmod(private/'secret.npy',0o600)
        client = Context(dict(context_parameters(p),**pair))
        upload = root/'upload'
        upload.mkdir()
        requests = {}
        rings = []
        from support import require_secure_execution
        for phase, role in zip(KINDS, INPUT_ROLES):
            name = phase+'_input.npy'
            values = private_array(private,name,prep['input_sha256'][name])
            encrypted = client.encrypt_slots(values)
            if getattr(encrypted,'_ckks_nsd',1) != 1:
                raise ValueError('fresh encryption has unexpected noise-scale degree')
            encrypted._ckks_nsd = 1
            rings.append(require_secure_execution(client,encrypted))
            requests[role] = save_ciphertext(encrypted,upload/role,public=manifest,request_id=request_id,role=role)
            del encrypted, values
        input_digest = combined_request_digest(requests,public=manifest,request_id=request_id)
        write(private/'private_manifest.json',dict(schema='bert-row-norm-private-v1',
            context_id=manifest['context_id'],request_id=request_id,input_digest=input_digest,
            secret=secret,preprocessing_sha256=sha(private/'preprocessing.json'),row_positions=[0,1]))
        return dict(stage='client-encrypt',passed=True,context_id=manifest['context_id'],
            ring=rings,actual_log2_qp=bits,elapsed_s=time.perf_counter()-started,
            public_key_bytes=sum(path.stat().st_size for path in public.iterdir()),request_count=2)
    finally:
        cleanup(jax,ckks,client)


def evaluate(root, request_id):
    private = root/'client_only'
    blocked = []
    def audit(event,args):
        if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
            path = Path(os.fsdecode(args[0])).resolve()
            if path==private or private in path.parents:
                blocked.append(str(path))
                raise PermissionError('server attempted client-only file access')
    sys.addaudithook(audit)
    jax, Context, ckks, kg = crypto()
    public, arrays, model = load_public(root/'public',root/'model')
    p = public['parameters']
    def forbidden(*args,**kwargs):
        raise AssertionError('server codec or secret-dependent key generation forbidden')
    for name in ('key_gen','jaxite_word.key_gen'):
        module = importlib.import_module(name)
        for method in ('gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen'):
            setattr(module,method,forbidden)
    for method in ('encrypt','encrypt_slots','encrypt_slots_batch','decrypt','decrypt_slots','decrypt_slots_batch'):
        setattr(Context,method,forbidden)
    context = owner = graph = None
    try:
        context = Context(dict(context_parameters(p),evaluation_key=[
            jax.numpy.asarray(arrays['relin_'+part+'.npy']).transpose(0,2,1) for part in ('a','b')]))
        rotations = {index:{part:arrays[f'rot_{index}_{part}.npy'] for part in ('a','b')} for index in ROTATIONS}
        context.program_initialization(ROTATIONS,dnum=8,r=128,c=256,batch=1,pregenerated_rotation_keys=rotations)
        assert context.secret_key is None and context._param_cache.secret_key is None and context.parameters.get('secret_key') is None
        from encrypted_ntt import enable_scoped_ntt_subsets
        from encrypted_streaming_linear import RowTileLayout
        from encrypted_row_normalization import RowLayerNorm
        from encrypted_polynomial import PolynomialApproximation
        from support import require_secure_execution, synchronize
        owner = enable_scoped_ntt_subsets(context)
        graph = RowLayerNorm(context,RowTileLayout(16384),low_memory=True,preserve_dispatch_cache=True)
        inputs, requests = {}, {}
        for role in INPUT_ROLES:
            inputs[role], requests[role] = load_ciphertext(root/'upload'/role,public=public,request_id=request_id,role=role)
            require_secure_execution(context,inputs[role])
        input_digest = combined_request_digest(requests,public=public,request_id=request_id)
        initial_payload_hashes = {role:hashlib.sha256(np.asarray(value.polynomial).tobytes()).hexdigest() for role,value in inputs.items()}
        download = root/'download'
        download.mkdir()
        records, responses = {}, {}
        started = time.perf_counter()
        for phase, input_role in zip(KINDS,INPUT_ROLES):
            gamma,beta = model[phase]
            rule = RULES[phase]
            approximation = PolynomialApproximation('inverse_sqrt',tuple(rule['domain']),tuple(rule['coefficients']))
            begin = time.perf_counter()
            result = graph.normalize_tile(inputs[input_role],gamma,beta,approximation,
                epsilon=rule['epsilon'],valid_rows=2,capture=True)
            outputs = result.checkpoints | {'output':result.output}
            for checkpoint in CHECKPOINTS:
                role = phase+'_'+checkpoint
                output = outputs[checkpoint]
                synchronize(output)
                rings = require_secure_execution(context,output)
                if graph.arithmetic._level(output)!=ROLE_LEVELS[role] or output._ckks_nsd!=1:
                    raise ValueError('unexpected normalization checkpoint metadata')
                response = save_ciphertext(output,download/role,public=public,request_id=request_id,
                    role=role,input_digest=input_digest)
                responses[role] = manifest_digest(response)
                records[role] = dict(ring=rings,level=ROLE_LEVELS[role],scale=output._ckks_scale,
                    nsd=output._ckks_nsd,slots=16384)
            print(f'{phase} LayerNorm complete in {time.perf_counter()-begin:.2f}s',file=sys.stderr,flush=True)
            del output, outputs, result
            graph.clear()
        after_payload_hashes = {role:hashlib.sha256(np.asarray(value.polynomial).tobytes()).hexdigest() for role,value in inputs.items()}
        if initial_payload_hashes != after_payload_hashes:
            raise ValueError('input ciphertext payload changed')
        write(download/'responses.json',dict(schema='bert-row-norm-responses-v1',context_id=public['context_id'],
            request_id=request_id,input_digest=input_digest,outputs=responses))
        return dict(stage='keyless-server',passed=True,checks=records,server_s=time.perf_counter()-started,
            server_secret_absent=True,client_codecs_and_keygen_forbidden=True,client_file_access_attempts=blocked,
            input_count=2,output_count=8,input_payloads_unchanged=True,no_refresh=True,full_bert_evaluated=False)
    finally:
        cleanup(jax,ckks,context,graph,owner)


def finish(root,request_id):
    from assets import validate_private
    jax,Context,ckks,kg = crypto()
    public,arrays,_ = load_public(root/'public',root/'model')
    p = public['parameters']
    private = root/'client_only'
    m = _json(_read_regular(private/'private_manifest.json',65536))
    expected = {'schema','context_id','request_id','input_digest','secret','preprocessing_sha256','row_positions'}
    if (set(m)!=expected or m['schema']!='bert-row-norm-private-v1' or m['context_id']!=public['context_id']
            or m['request_id']!=request_id or m['row_positions']!=[0,1]):
        raise ValueError('private context identity differs')
    if sha(private/'preprocessing.json')!=m['preprocessing_sha256']:
        raise ValueError('preprocessing identity differs')
    prep = validate_private(private,root/'model')
    requests = {role:validate_ciphertext(root/'upload'/role,public=public,request_id=request_id,role=role)[3] for role in INPUT_ROLES}
    if combined_request_digest(requests,public=public,request_id=request_id)!=m['input_digest']:
        raise ValueError('request identity differs')
    raw = _read_regular(private/'secret.npy',26*32768*4+4096)
    desc = m['secret']
    if (set(desc)!={'sha256','shape','dtype'} or desc['shape']!=[26,32768]
            or desc['dtype']!='uint32' or hashlib.sha256(raw).hexdigest()!=desc['sha256']):
        raise ValueError('private key descriptor differs')
    secret = np.load(io.BytesIO(raw),allow_pickle=False)
    if secret.dtype!=np.uint32 or secret.shape!=(26,32768) or np.any(secret>=np.asarray(p['q_towers'],dtype=np.uint32)[:,None]):
        raise ValueError('private key residues invalid')
    context = None
    try:
        context = Context(dict(context_parameters(p),secret_key=secret,public_key=arrays['public_key.npy']))
        download = root/'download'
        aggregate = _json(_read_regular(download/'responses.json',65536))
        expected = dict(schema='bert-row-norm-responses-v1',context_id=public['context_id'],request_id=request_id,input_digest=m['input_digest'])
        if (set(aggregate)!=set(expected)|{'outputs'} or any(aggregate[k]!=v for k,v in expected.items())
                or set(aggregate['outputs'])!=set(ROLE_LEVELS)
                or {path.name for path in download.iterdir()}!=set(ROLE_LEVELS)|{'responses.json'}):
            raise ValueError('response inventory differs')
        checks = {}
        for role in ROLE_LEVELS:
            value,response = load_ciphertext(download/role,public=public,request_id=request_id,
                role=role,input_digest=m['input_digest'])
            if manifest_digest(response)!=aggregate['outputs'][role]:
                raise ValueError('response digest differs')
            name = role+'_expected.npy'
            reference = private_array(private,name,prep['private_reference_sha256'][name])
            decoded = np.asarray(context.decrypt_slots(value))
            if decoded.shape!=(16384,) or not np.isfinite(decoded).all():
                raise ValueError('invalid decoded output')
            difference = np.abs(decoded-reference)
            maximum = float(difference.max())
            checks[role] = dict(passed=maximum<=1e-6,max_abs_error=maximum,gate=1e-6,slots_checked=16384,
                per_physical_row_max_abs=difference.reshape(4,4096).max(axis=1).tolist(),
                decoded_min=float(decoded.min()),decoded_max=float(decoded.max()))
            if role.endswith('_output') or role.endswith('_mean'):
                padding = np.ones((4,4096),bool)
                padding[:2,:768] = False
                checks[role]['padding_max_abs_error'] = float(difference[padding.ravel()].max())
        return dict(stage='client-decrypt',passed=all(row['passed'] for row in checks.values()),checks=checks,
            worst_abs_error=max(row['max_abs_error'] for row in checks.values()),all_slots_checked=8*16384,
            full_bert_evaluated=False,mrpc_accuracy_evaluated=False)
    finally:
        cleanup(jax,ckks,context)


if __name__=='__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=('preflight','setup','server','finish'))
    parser.add_argument('--root',type=Path)
    parser.add_argument('--request-id')
    args = parser.parse_args()
    if args.stage=='preflight':
        result = preflight()
    else:
        if args.root is None or args.request_id is None:
            parser.error('root and request-id required for cryptographic stages')
        result = {'setup':setup,'server':evaluate,'finish':finish}[args.stage](args.root.resolve(),args.request_id)
    print(json.dumps(result,allow_nan=False))
    raise SystemExit(0 if result['passed'] else 1)
