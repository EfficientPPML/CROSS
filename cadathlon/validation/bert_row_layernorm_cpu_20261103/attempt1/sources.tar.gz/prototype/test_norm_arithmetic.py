"""Independent public row oracles and configuration checks; no HE claim."""
from collections import Counter
from dataclasses import dataclass
import copy
import math
from pathlib import Path
import sys
from types import SimpleNamespace

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1] / 'checkout'
sys.path[:0] = [str(ROOT), str(ROOT/'cadathlon/common')]
from encrypted_polynomial import EncryptedPolynomialEvaluator, PolynomialApproximation
from encrypted_streaming_linear import RowTileLayout
from encrypted_row_normalization import RowLayerNorm
from spec import RULES, ROTATIONS


@dataclass
class Value:
    data: np.ndarray
    level: int


class PublicArithmetic(EncryptedPolynomialEvaluator):
    def __init__(self):
        self.strategy = 'power'
        self.refresher = None
        self.ctx = SimpleNamespace(num_slots=16384)
        self.counts = Counter()
        self.rotations = set()

    def _level(self, value):
        return value.level

    def result(self, value, data, level):
        result = copy.copy(value)
        result.data, result.level = data, level
        return result

    def weighted_sum(self, values, weights, *, bias=0.):
        values, weights = tuple(values), tuple(weights)
        self.counts['plaintext_products'] += len(values)
        self.counts['rescales'] += 1
        return self.result(values[0], sum(v.data*w for v, w in zip(values, weights))+bias,
                           min(v.level for v in values)-1)

    def multiply(self, left, right):
        self.counts['ciphertext_products'] += 1
        self.counts['rescales'] += 1
        return self.result(left, left.data*right.data, min(left.level, right.level)-1)

    def add(self, left, right, *, subtract=False):
        self.counts['additions'] += 1
        return self.result(left, left.data-right.data if subtract else left.data+right.data,
                           min(left.level, right.level))

    def rotate(self, value, shift):
        self.counts['rotations'] += 1
        self.rotations.add(shift % 16384)
        return self.result(value, np.roll(value.data, -shift), value.level)


class PublicLayerNorm(RowLayerNorm):
    """Replace only the CKKS boundary for ideal arithmetic/configuration tests."""
    def __init__(self):
        self.layout = RowTileLayout(16384)
        self.arithmetic = PublicArithmetic()
        self.validations = 0

    def _validate_ciphertext(self, value, required):
        self.validations += 1
        if value.level < required+1:
            raise ValueError('one reserved level required')


def contract(phase):
    rule = RULES[phase]
    return PolynomialApproximation('inverse_sqrt', tuple(rule['domain']), tuple(rule['coefficients']))


@pytest.mark.parametrize('phase', ['attention', 'mlp'])
@pytest.mark.parametrize('valid_rows', [1, 2, 3, 4])
def test_full_slot_native_width_oracle_and_hostile_padding(phase, valid_rows):
    engine = PublicLayerNorm()
    approximation = contract(phase)
    lo, hi = approximation.domain
    epsilon = RULES[phase]['epsilon']
    rng = np.random.default_rng(768+valid_rows)
    tile = rng.uniform(-100, 100, (4, 4096))
    logical = rng.normal(size=(valid_rows, 768))
    logical -= logical.mean(axis=1, keepdims=True)
    logical /= np.sqrt((logical*logical).mean(axis=1, keepdims=True))
    variances = np.linspace(lo+(hi-lo)/8, hi-(hi-lo)/8, valid_rows)
    logical *= np.sqrt(variances[:, None]-epsilon)
    logical += np.linspace(-9, 11, valid_rows)[:, None]
    tile[:valid_rows, :768] = logical
    original = tile.copy()
    gamma, beta = rng.normal(size=(2, 768))
    original_gamma, original_beta = gamma.copy(), beta.copy()
    value = Value(tile.ravel(), 12)
    value._public_abs_bound = 999.
    value._public_bound_provenance = 'stale input-only contract'
    result = engine.normalize_tile(value, gamma, beta, approximation,
        epsilon=epsilon, valid_rows=valid_rows, capture=True)
    expected_mean = np.zeros((4, 4096))
    means = logical.mean(axis=1, keepdims=True)
    expected_mean[:valid_rows, :768] = means
    expected_variance = np.full((4, 4096), (lo+hi)/2)
    local_variance = ((logical-means)**2).mean(axis=1, keepdims=True)+epsilon
    expected_variance[:valid_rows] = local_variance
    expected_inverse = approximation.evaluate_public(expected_variance)
    expected = np.zeros((4, 4096))
    expected[:valid_rows, :768] = (logical-means)*expected_inverse[:valid_rows, :768]*gamma+beta
    for name, reference, level in [('mean', expected_mean, 11), ('variance', expected_variance, 9),
                                    ('inverse', expected_inverse, 3)]:
        actual = result.checkpoints[name]
        np.testing.assert_allclose(actual.data.reshape(4,4096), reference, rtol=0, atol=1e-9)
        assert actual.level == level
    np.testing.assert_allclose(result.output.data.reshape(4,4096), expected, rtol=0, atol=1e-9)
    assert result.output.level == 1
    assert not result.output.data.reshape(4,4096)[:valid_rows,768:].any()
    assert not result.output.data.reshape(4,4096)[valid_rows:].any()
    np.testing.assert_array_equal(tile, original)
    np.testing.assert_array_equal(gamma, original_gamma)
    np.testing.assert_array_equal(beta, original_beta)
    assert value._public_abs_bound == 999.
    assert all(not any(name.startswith('_public_') for name in vars(item))
               for item in (result.output, *result.checkpoints.values()))
    assert engine.arithmetic.counts['rotations'] == 42
    assert sorted(engine.arithmetic.rotations) == ROTATIONS == list(RowLayerNorm.required_rotation_indices(engine.layout))


@pytest.mark.parametrize('change', [
    {'epsilon':0}, {'epsilon':-1}, {'epsilon':float('nan')}, {'epsilon':True},
    {'valid_rows':0}, {'valid_rows':5}, {'valid_rows':True}, {'capture':1},
    {'gamma':np.ones(767)}, {'gamma':np.ones(768,dtype=complex)},
    {'gamma':np.ones(768,dtype=bool)}, {'beta':np.full(768,float('inf'))},
    {'approximation':PolynomialApproximation('bad',(-1.,1.),(1.,2.))},
    {'approximation':PolynomialApproximation('bad',(1.,2.),tuple([1.]*34))},
    {'approximation':PolynomialApproximation('bad',(1.,2.),(1e308,1e308,1e308))},
])
def test_invalid_public_contract_rejected_before_ciphertext(change):
    engine = PublicLayerNorm()
    args = dict(gamma=np.ones(768), beta=np.zeros(768), approximation=contract('attention'),
                epsilon=1e-12, valid_rows=2, capture=False)
    args.update(change)
    with pytest.raises((ValueError, TypeError)):
        engine.normalize_tile(object(), **args)
    assert engine.validations == 0 and not engine.arithmetic.counts


def test_default_does_not_retain_checkpoints_and_low_capacity_is_rejected():
    engine = PublicLayerNorm()
    values = np.tile(np.linspace(-1,1,768), (2,1))
    input_tile = next(engine.layout.pack_client_rows(values))
    args = dict(gamma=np.ones(768), beta=np.zeros(768), approximation=contract('attention'),
                epsilon=1e-12, valid_rows=2)
    with pytest.raises(ValueError, match='reserved'):
        engine.normalize_tile(Value(input_tile,11), **args)
    assert not engine.arithmetic.counts
    result = engine.normalize_tile(Value(input_tile,12), **args)
    assert result.checkpoints == {} and result.output.level == 1


def test_import_and_rotation_plan_are_backend_free():
    assert 'jax' not in sys.modules
    assert len(RowLayerNorm.required_rotation_indices(RowTileLayout(16384))) == 22
    with pytest.raises(ValueError):
        RowLayerNorm.required_rotation_indices(RowTileLayout(16384,features=2048))
