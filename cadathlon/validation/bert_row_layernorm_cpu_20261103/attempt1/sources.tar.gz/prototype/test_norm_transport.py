"""Backend-free strict two-upload LayerNorm transport and public contract checks."""
import copy,hashlib,os,shutil,sys
from types import SimpleNamespace
from pathlib import Path
import numpy as np
import pytest
ROOT=Path(__file__).resolve().parents[1]/'checkout'
sys.path[:0]=[str(ROOT/'cadathlon/common')]
import transport as t
import contracts
from spec import parameters,ASSETS,REVISION,KINDS,ROLE_LEVELS,RULES,NORM_TENSOR_SHA256,ROTATIONS

PUBLIC={'context_id':'a'*64,'parameters':parameters()}
NONCE='norm_independent_request'


def manifest(role):
    return dict(format=t.FORMAT,context_id=PUBLIC['context_id'],request_id=NONCE,
        role=role,input_digest=None,level=12,files={'bundle.json':'b'*64,'ct_0.npz':'c'*64})


def pair():return {role:manifest(role) for role in t.INPUT_ROLES}


def rewrite_metadata(directory,name,value):
    path=directory/'ct_0.npz'
    with np.load(path,allow_pickle=False) as data:arrays={key:np.asarray(data[key]) for key in data.files}
    arrays[name]=value;np.savez(path,**arrays)
    m=t._json((directory/'transport.json').read_bytes())
    m['files']['ct_0.npz']=hashlib.sha256(path.read_bytes()).hexdigest()
    (directory/'transport.json').write_bytes(t._canonical(m))


@pytest.fixture(scope='module')
def valid_directories(tmp_path_factory):
    root=tmp_path_factory.mktemp('norm_transport')
    digest=t.request_pair_digest(pair(),public=PUBLIC,request_id=NONCE)
    output={}
    for role in (*t.INPUT_ROLES,*t.OUTPUT_LEVELS):
        directory=root/role;directory.mkdir()
        c=t._contract(PUBLIC,NONCE,role,None if role in t.INPUT_ROLES else digest)
        payload=np.zeros(c['shape'],dtype=np.uint32)
        np.savez(directory/'ct_0.npz',payload=payload,moduli=np.asarray(c['moduli'],dtype=np.int64),
            degree_layout=np.asarray(c['layout'],dtype=np.int64),precision=np.asarray(32,dtype=np.int64),
            scale=np.asarray(c['scale'],dtype=np.float64),nsd=np.asarray(1,dtype=np.int64))
        (directory/'bundle.json').write_bytes(t._canonical({'shape':{'__ct__':0},'count':1}))
        m=dict(format=t.FORMAT,context_id=PUBLIC['context_id'],request_id=NONCE,role=role,
            input_digest=c['input_digest'],level=c['level'],files={name:hashlib.sha256((directory/name).read_bytes()).hexdigest() for name in ('bundle.json','ct_0.npz')})
        (directory/'transport.json').write_bytes(t._canonical(m));output[role]=directory
    return output,digest


@pytest.mark.parametrize('role,level,count',[(role,12,26) for role in t.INPUT_ROLES]+[(role,level,2*(level+1)) for role,level in ROLE_LEVELS.items()])
def test_exact_role_level_qprefix_and_payload(valid_directories,role,level,count):
    dirs,digest=valid_directories
    data,scale,c,m=t.validate_ciphertext(dirs[role],public=PUBLIC,request_id=NONCE,role=role,input_digest=None if role in t.INPUT_ROLES else digest)
    assert data.shape==(1,2,128,256,count) and data.dtype==np.uint32
    assert c['level']==level and c['moduli']==parameters()['q_towers'][:count]
    assert scale==parameters()['scaling_factor']


def test_pair_order_independent_and_both_digests_bound():
    original=pair();expected=t.request_pair_digest(original,public=PUBLIC,request_id=NONCE)
    assert contracts.request_digest(dict(reversed(list(original.items()))),public=PUBLIC,request_id=NONCE)==expected
    for role in t.INPUT_ROLES:
        changed=copy.deepcopy(original);changed[role]['files']['ct_0.npz']='d'*64
        assert t.request_pair_digest(changed,public=PUBLIC,request_id=NONCE)!=expected


@pytest.mark.parametrize('change',['missing','extra','swap','context','nonce','level','input_digest','extra_field','digest'])
def test_pair_fail_closed(change):
    m=pair()
    if change=='missing':del m['mlp_request']
    elif change=='extra':m['value']=manifest('value')
    elif change=='swap':m['attention_request'],m['mlp_request']=m['mlp_request'],m['attention_request']
    elif change=='context':m['mlp_request']['context_id']='e'*64
    elif change=='nonce':m['mlp_request']['request_id']='other_nonce'
    elif change=='level':m['mlp_request']['level']=True
    elif change=='input_digest':m['mlp_request']['input_digest']='e'*64
    elif change=='extra_field':m['mlp_request']['private_ids']=[1,2]
    elif change=='digest':m['mlp_request']['files']['ct_0.npz']='not-a-digest'
    with pytest.raises(ValueError):t.request_pair_digest(m,public=PUBLIC,request_id=NONCE)


def test_response_rejects_replaced_either_upload(valid_directories):
    dirs,digest=valid_directories
    for role in t.INPUT_ROLES:
        changed=pair();changed[role]['files']['ct_0.npz']='d'*64
        new=t.request_pair_digest(changed,public=PUBLIC,request_id=NONCE)
        with pytest.raises(ValueError,match='binding mismatch'):
            t.validate_ciphertext(dirs['attention_mean'],public=PUBLIC,request_id=NONCE,role='attention_mean',input_digest=new)


@pytest.mark.parametrize('field,value',[('nsd',np.asarray(2,dtype=np.int64)),('scale',np.asarray(1.,dtype=np.float64)),
    ('precision',np.asarray(64,dtype=np.int64)),('moduli',np.asarray(parameters()['q_towers'][1:25],dtype=np.int64)),
    ('degree_layout',np.asarray([256,128],dtype=np.int64))])
def test_rehashed_bad_metadata_rejected(tmp_path,valid_directories,field,value):
    dirs,digest=valid_directories;dest=tmp_path/'bad';shutil.copytree(dirs['attention_mean'],dest)
    rewrite_metadata(dest,field,value)
    with pytest.raises(ValueError):t.validate_ciphertext(dest,public=PUBLIC,request_id=NONCE,role='attention_mean',input_digest=digest)


def test_rehashed_oversized_residue_rejected(tmp_path,valid_directories):
    dirs,digest=valid_directories;dest=tmp_path/'bad';shutil.copytree(dirs['mlp_output'],dest)
    payload=np.zeros((1,2,128,256,4),dtype=np.uint32);payload[0,0,0,0,0]=parameters()['q_towers'][0]
    rewrite_metadata(dest,'payload',payload)
    with pytest.raises(ValueError,match='residue'):t.validate_ciphertext(dest,public=PUBLIC,request_id=NONCE,role='mlp_output',input_digest=digest)


def test_plaintext_bookkeeping_and_extra_inventory_rejected(tmp_path,valid_directories):
    dirs,digest=valid_directories;dest=tmp_path/'bad';shutil.copytree(dirs['mlp_output'],dest)
    (dest/'private_ids.json').write_text('[1]')
    with pytest.raises(ValueError,match='inventory'):t.validate_ciphertext(dest,public=PUBLIC,request_id=NONCE,role='mlp_output',input_digest=digest)
    (dest/'private_ids.json').unlink();b={'shape':{'__ct__':0},'count':1,'private_ids':[1]}
    (dest/'bundle.json').write_bytes(t._canonical(b));m=t._json((dest/'transport.json').read_bytes())
    m['files']['bundle.json']=hashlib.sha256((dest/'bundle.json').read_bytes()).hexdigest();(dest/'transport.json').write_bytes(t._canonical(m))
    with pytest.raises(ValueError,match='bookkeeping'):t.validate_ciphertext(dest,public=PUBLIC,request_id=NONCE,role='mlp_output',input_digest=digest)


@pytest.mark.parametrize('field,value',[('batch',True),('max_level',1),('degree_layout',[256,128]),('dnum',3),('secret_key',[])])
def test_changed_fixed_parameter_rejected_before_payload(field,value):
    public=copy.deepcopy(PUBLIC);public['parameters'][field]=value
    with pytest.raises(ValueError):t._contract(public,NONCE,'attention_request',None)


def test_packing_binds_rules_and_keeps_distinct_active_rows():
    layout=contracts.packing_contract()
    assert layout['slots']==16384 and layout['rows_per_tile']==4 and layout['rows']==2
    assert layout['output_levels']==ROLE_LEVELS and layout['rules']==RULES
    assert layout['input_roles']==list(t.INPUT_ROLES) and layout['refresh'] is False
    layout['rules']['attention']['domain'][0]=99
    assert contracts.packing_contract()['rules']==RULES
    rows=np.arange(2*768,dtype=np.float64).reshape(2,768)/1024
    packed=contracts.pack_rows(rows)
    assert packed.shape==(16384,) and np.array_equal(contracts.unpack_rows(packed),rows)
    blocks=packed.reshape(4,4096)
    assert np.count_nonzero(blocks[:2,768:])==0 and np.count_nonzero(blocks[2:])==0
    with pytest.raises(ValueError):contracts.pack_rows(rows.astype(np.float32))


def synthetic_model(tmp_path,monkeypatch):
    manifest=dict(schema='pinned-bert-layer0-row-norm-v1',model_id='google-bert/bert-base-cased-finetuned-mrpc',
        revision=REVISION,asset_sha256=ASSETS,tensors={})
    pins={phase:{} for phase in KINDS}
    for phase in KINDS:
        for suffix in ('gamma','beta'):
            value=np.arange(768,dtype='<f4')/1024;name=f'{phase}_{suffix}.npy';path=tmp_path/name
            np.save(path,value,allow_pickle=False)
            pins[phase][suffix]=hashlib.sha256(value.tobytes()).hexdigest()
            manifest['tensors'][name]=dict(name=contracts.tensor_name(phase,suffix),shape=[768],dtype='<f4',
                file_sha256=contracts.sha(path),tensor_sha256=pins[phase][suffix])
    monkeypatch.setattr(contracts,'NORM_TENSOR_SHA256',pins)
    (tmp_path/'model_manifest.json').write_bytes(t._canonical(manifest))
    return manifest


def test_model_returns_two_public_vector_pairs(tmp_path,monkeypatch):
    m=synthetic_model(tmp_path,monkeypatch)
    loaded,vectors=contracts.load_model(tmp_path)
    assert loaded==m and set(vectors)==set(KINDS)
    for phase in KINDS:
        gamma,beta=vectors[phase]
        assert gamma.shape==beta.shape==(768,) and gamma.dtype==beta.dtype==np.float64


@pytest.mark.parametrize('phase,suffix',[(p,s) for p in KINDS for s in ('gamma','beta')])
def test_self_consistently_rehashed_wrong_model_rejected(tmp_path,monkeypatch,phase,suffix):
    m=synthetic_model(tmp_path,monkeypatch)
    name=f'{phase}_{suffix}.npy';path=tmp_path/name
    wrong=np.zeros(768,dtype='<f4');np.save(path,wrong,allow_pickle=False)
    m['tensors'][name].update(file_sha256=contracts.sha(path),tensor_sha256=hashlib.sha256(wrong.tobytes()).hexdigest())
    (tmp_path/'model_manifest.json').write_bytes(t._canonical(m))
    with pytest.raises(ValueError,match='public tensor identity'):contracts.load_model(tmp_path)


@pytest.mark.parametrize('change',['schema','asset','revision','extra','missing','shape','name','dtype'])
def test_model_identity_inventory_and_type_rejected(tmp_path,monkeypatch,change):
    m=synthetic_model(tmp_path,monkeypatch)
    if change=='schema':m['schema']='pinned-bert-layer0-qkv-v1'
    elif change=='asset':m['asset_sha256']=dict(ASSETS,**{'model.safetensors':'0'*64})
    elif change=='revision':m['revision']='0'*40
    elif change=='extra':m['private_ids']=[0,1]
    elif change=='missing':del m['tensors']['mlp_beta.npy']
    elif change=='shape':m['tensors']['attention_gamma.npy']['shape']=[True]
    elif change=='name':m['tensors']['attention_gamma.npy']['name']=contracts.tensor_name('mlp','gamma')
    elif change=='dtype':m['tensors']['attention_gamma.npy']['dtype']='<f8'
    (tmp_path/'model_manifest.json').write_bytes(t._canonical(m))
    with pytest.raises(ValueError):contracts.load_model(tmp_path)


def test_public_hash_rejects_symlink_fifo_and_oversize(tmp_path):
    regular=tmp_path/'file';regular.write_bytes(b'abc')
    link=tmp_path/'link';link.symlink_to(regular)
    with pytest.raises((OSError,ValueError)):contracts.sha(link)
    fifo=tmp_path/'fifo';os.mkfifo(fifo)
    with pytest.raises(ValueError):contracts.sha(fifo)
    with pytest.raises(ValueError):contracts.sha(regular,2)


def public_body():
    return dict(schema='bert-row-norm-public-ckks-v1',parameters=parameters(),rotations=ROTATIONS,arrays={},
        representation='standard-ntt-residues/digit-modulus-degree',keygen_source_sha256='a'*64,
        model_manifest_sha256='a'*64,packing=contracts.packing_contract(),
        normalization_source_sha256=contracts.normalization_source_sha256())


def test_stale_helper_rejected_before_any_key_load(tmp_path):
    body=public_body();body['normalization_source_sha256']='0'*64
    (tmp_path/'public_manifest.json').write_bytes(t._canonical(dict(body,context_id=contracts.digest(body))))
    with pytest.raises(ValueError,match='normalization source'):contracts.load_public(tmp_path,tmp_path/'no-model')


@pytest.mark.parametrize('change',['rules','roles','layout','rotations','secret'])
def test_public_rehashed_contract_change_rejected(tmp_path,monkeypatch,change):
    body=public_body();monkeypatch.setattr(contracts,'check_parameters',lambda p:0)
    if change=='rules':body['packing']['rules']['mlp']['degree']=12
    elif change=='roles':body['packing']['output_levels']['mlp_inverse']=4
    elif change=='layout':body['packing']['rows_per_tile']=2
    elif change=='rotations':body['rotations']=ROTATIONS[:-1]
    elif change=='secret':body['secret_key']='private.npy'
    (tmp_path/'public_manifest.json').write_bytes(t._canonical(dict(body,context_id=contracts.digest(body))))
    with pytest.raises(ValueError):contracts.load_public(tmp_path,tmp_path/'no-model')


def test_loader_remains_backend_free(valid_directories):
    # These tests invoke only NumPy manifests/codec metadata, not ciphertexts.
    assert 'jax' not in sys.modules


@pytest.mark.parametrize('replace',[False,True])
def test_writer_failure_pins_inode_and_retains_replacement(tmp_path,monkeypatch,replace):
    contract=t._contract(PUBLIC,NONCE,'attention_request',None)
    class FakePolynomial:
        shape=contract['shape'];degree_layout=contract['layout'];precision=32
        _ckks_nsd=1;_ckks_scale=contract['scale']
        def validate(self):return self
        def get_moduli(self):return contract['moduli']
    target=tmp_path/'request';moved=tmp_path/'moved';handles=[]
    original_open=t.os.open
    def opened(path,flags,*args,**kwargs):
        fd=original_open(path,flags,*args,**kwargs)
        if Path(path)==target:handles.append(fd)
        return fd
    def writer(ct,directory):
        assert handles and os.fstat(handles[0]).st_ino==directory.stat().st_ino
        (directory/'partial').write_text('partial')
        if replace:
            directory.rename(moved);directory.mkdir();(directory/'unowned').write_text('keep')
        raise KeyboardInterrupt('primary writer cancellation')
    monkeypatch.setattr(t.os,'open',opened)
    monkeypatch.setitem(sys.modules,'jaxite_word',SimpleNamespace(Polynomial=FakePolynomial))
    monkeypatch.setitem(sys.modules,'bundle_io',SimpleNamespace(save_bundle=writer))
    with pytest.raises(KeyboardInterrupt,match='primary writer cancellation'):
        t.save_ciphertext(FakePolynomial(),target,public=PUBLIC,request_id=NONCE,role='attention_request')
    with pytest.raises(OSError):os.fstat(handles[0])
    if replace:
        assert (target/'unowned').read_text()=='keep' and (moved/'partial').exists()
    else:assert not target.exists()


def test_duplicate_json_role_rejected():
    with pytest.raises(ValueError,match='duplicate'):
        t._json(b'{"attention_request":{},"attention_request":{},"mlp_request":{}}')


@pytest.mark.parametrize('role',list(ROLE_LEVELS))
def test_response_roles_cannot_be_substituted(valid_directories,role):
    dirs,digest=valid_directories
    other=('mlp_' if role.startswith('attention_') else 'attention_')+role.split('_',1)[1]
    with pytest.raises(ValueError,match='binding mismatch'):
        t.validate_ciphertext(dirs[role],public=PUBLIC,request_id=NONCE,role=other,input_digest=digest)


def test_fixed_public_model_pin_inventory():
    assert set(NORM_TENSOR_SHA256)=={'attention','mlp'}
    assert all(set(p)=={'gamma','beta'} for p in NORM_TENSOR_SHA256.values())
    assert NORM_TENSOR_SHA256['attention']['gamma']=='75757855791f359399f2b35e7fb16db0bc93d08a3476cf7fdd8c523027029d03'
    assert contracts.tensor_name('attention','gamma')=='bert.encoder.layer.0.attention.output.LayerNorm.weight'
    assert contracts.tensor_name('mlp','beta')=='bert.encoder.layer.0.output.LayerNorm.bias'


@pytest.mark.parametrize('change',[None,'eight_parts','wrong_pk_shape','dtype','residue','extra_secret'])
def test_public_key_loader_uses_seven_actual_parts(tmp_path,monkeypatch,change):
    # Backend-free loader contract proof. Arrays are broadcast test doubles;
    # actual ring/P security and cryptographic correctness are separate tests.
    body=public_body();names=contracts.key_names();q=parameters()['q_towers']
    assert len(names)==47 and len(ROTATIONS)==22
    model=tmp_path/'model';model.mkdir();(model/'model_manifest.json').write_bytes(b'model')
    keys=tmp_path/'keys';keys.mkdir();arrays={}
    for name in names:
        shape=(2,26,32768) if name=='public_key.npy' else (7,30,32768)
        (keys/name).write_bytes(b'array')
        body['arrays'][name]=dict(sha256='a'*64,shape=list(shape),dtype='uint32')
        arrays[name]=np.broadcast_to(np.array(0,dtype=np.uint32),shape)
    if change=='eight_parts':body['arrays']['relin_a.npy']['shape']=[8,30,32768]
    elif change=='wrong_pk_shape':body['arrays']['public_key.npy']['shape']=[2,30,32768]
    elif change=='dtype':arrays['relin_a.npy']=arrays['relin_a.npy'].astype(np.uint64)
    elif change=='residue':arrays['public_key.npy']=np.broadcast_to(np.array(q[0],dtype=np.uint32),(2,26,32768))
    elif change=='extra_secret':(keys/'secret_key.npy').write_bytes(b'private')
    monkeypatch.setattr(contracts,'check_parameters',lambda p:0)
    monkeypatch.setattr(contracts,'sha',lambda *a,**kw:'a'*64)
    monkeypatch.setattr(contracts,'normalization_source_sha256',lambda:body['normalization_source_sha256'])
    monkeypatch.setattr(contracts,'load_model',lambda path:({'model':'test'},{'vectors':'test'}))
    monkeypatch.setitem(sys.modules,'jaxite_word',SimpleNamespace(key_gen=SimpleNamespace(__file__='fake-keygen.py')))
    monkeypatch.setattr(contracts.np,'load',lambda path,**kw:arrays[Path(path).name])
    (keys/'public_manifest.json').write_bytes(t._canonical(dict(body,context_id=contracts.digest(body))))
    if change is None:
        _,loaded,vectors=contracts.load_public(keys,model)
        assert set(loaded)==names and loaded['relin_a.npy'].shape==(7,30,32768)
        assert loaded['public_key.npy'].shape==(2,26,32768) and vectors=={'vectors':'test'}
    else:
        with pytest.raises(ValueError):contracts.load_public(keys,model)
