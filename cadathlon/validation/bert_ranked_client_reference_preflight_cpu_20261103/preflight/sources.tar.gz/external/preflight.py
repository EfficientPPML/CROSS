"""Source-bound mock/import/public-proof checks; no actual native/private reads."""
from pathlib import Path
import hashlib,io,json,os,signal,subprocess,sys,tarfile,time,xml.etree.ElementTree as ET
ROOT=Path('/tmp/bert-ranked-client-reference-20261103');OUT=ROOT/'preflight-v1'
PYTHON=Path('/tmp/cross-pretrained-validation-env/bin/python')
sys.path.insert(0,str(ROOT));import ranked_collect as c

def source_paths():return c.source_paths()|{'external/preflight.py':Path(__file__)}
def write(value):c.write(OUT/'report.json',value)
def terminate(child,primary):
    if child is None:return
    # Short preparation processes get the same graceful process-group policy;
    # a normal healthy process has no deadline.
    try:
        try:os.killpg(child.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        try:child.wait(timeout=30)
        except subprocess.TimeoutExpired:
            try:os.killpg(child.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            child.wait()
    except BaseException as error:
        if primary is None:raise
        primary.add_note('preflight child cleanup: '+type(error).__name__)

def main():
    start=time.monotonic();OUT.mkdir(exist_ok=False);paths=source_paths();before=c.hashes(paths);candidate=c.hashes(c.source_paths())
    r=dict(passed=False,scope='Synthetic native/record/lifecycle checks, installed denied entrypoints, and public producer/assets authentication; no actual private input, native model, JAX or HE.',
        source_hashes_before=before,source_count=len(before),candidate_source_hashes=candidate,candidate_source_count=len(candidate),pid=os.getpid(),cpu_affinity=sorted(os.sched_getaffinity(0)),processes=[])
    child=None;primary=None
    try:
        write(r);c.archive(OUT/'sources.tar.gz',paths)
        first=c.assets();r['asset_hashes_before']=first
        if first!=c.input_gate.ASSETS:raise ValueError('exact pinned public assets required')
        tests=['test_ranked_reference.py','test_fixture_lifecycle.py','test_native_policy.py']
        commands=[('tests',[str(PYTHON),'-m','pytest','-q',*tests,'--junitxml='+str(OUT/'tests.xml')]),
            ('installed',[str(PYTHON),str(ROOT/'installed_probe.py'),'--output',str(OUT/'installed')]),
            ('public-gate',[str(PYTHON),str(ROOT/'ranked_collect.py'),'--output',str(OUT/'public-gate')])]
        for name,command in commands:
            started=time.monotonic()
            with (OUT/(name+'.log')).open('wb') as log:
                child=subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                record=dict(name=name,command=command,pid=child.pid,reaped=False);r['processes'].append(record);write(r)
                result=child.wait();record.update(returncode=result,reaped=True,elapsed_s=time.monotonic()-started)
                child=None;write(r)
            if result:raise RuntimeError(name+' failed')
        suites=ET.parse(OUT/'tests.xml').getroot();count=sum(int(s.attrib.get('tests','0')) for s in suites)
        if count!=69 or any(any(int(s.attrib.get(x,'0')) for x in ('errors','failures','skipped')) for s in suites):raise ValueError('complete 69 mock checks required')
        installed=json.loads((OUT/'installed/report.json').read_text());public=json.loads((OUT/'public-gate/report.json').read_text())
        if not installed['passed'] or installed['denied_calls']!=12 or not installed['all_restored']:raise ValueError('installed import guard proof differs')
        if not public['passed'] or public['execute']is not False or public['private_fixture_read']is not False:raise ValueError('public-only prerequisite proof differs')
        if installed['source_hashes_before']!=candidate or installed['source_hashes_after']!=candidate or public['source_hashes_before']!=candidate or public['source_hashes_after']!=candidate:raise ValueError('child sources differ')
        r.update(passed=True,tests_passed=count,installed_entrypoints=9,installed_denials=12,public_prerequisite_passed=True,
            installed_report_sha256=c.sha(OUT/'installed/report.json'),public_gate_report_sha256=c.sha(OUT/'public-gate/report.json'))
    except BaseException as error:
        primary=error;r.update(passed=False,error=dict(type=type(error).__name__,message='Public preparation preflight failed'))
    finally:
        try:
            terminate(child,primary)
            if child is not None:r['processes'][-1].update(returncode=child.returncode,reaped=child.returncode is not None)
            after=c.hashes(source_paths());assets=c.assets();verified=c.archive_ok(OUT/'sources.tar.gz',before)
            r.update(source_hashes_after=after,asset_hashes_after=assets,source_files_unchanged=after==before,assets_unchanged=assets==r.get('asset_hashes_before'),
                source_archive_verified=verified,source_archive_sha256=c.sha(OUT/'sources.tar.gz'),all_children_reaped=all(x['reaped'] for x in r['processes']),elapsed_s=time.monotonic()-start)
            r['passed']=bool(r['passed'] and after==before and verified and r['assets_unchanged'] and r['all_children_reaped'])
            write(r)
        except BaseException as error:
            if primary is None:raise
            primary.add_note('preflight terminal evidence: '+type(error).__name__)
    if primary is not None:raise primary
    print(json.dumps({k:v for k,v in r.items() if not isinstance(v,(dict,list))}));return 0 if r['passed'] else 1

if __name__=='__main__':
    from cleanup import termination_signals
    with termination_signals():code=main()
    raise SystemExit(code)
