"""Real installed entrypoints, denied before models or any asset/private reads."""
from pathlib import Path
import argparse,hashlib,inspect,json,os,sys,time
HERE=Path(__file__).resolve().parent


def main(output):
    forbidden=[]
    def audit(event,args):
        if event=='open' and args and isinstance(args[0],(str,bytes,os.PathLike)):
            path=Path(os.fsdecode(args[0]))
            if ('cross_validation_assets' in path.parts or path.suffix in ('.npy','.npz','.safetensors')
                or any(part.startswith(('bert-ranked-input-client-','bert-ranked-reference-client-')) for part in path.parts)):
                forbidden.append('denied asset/private input open');raise AssertionError('installed probe forbids asset/private reads')
        if event in ('socket.connect','socket.connect_ex'):raise AssertionError('installed probe forbids network')
    sys.addaudithook(audit);start=time.monotonic()
    import ranked_collect as c,ranked_native as n,client_inputs
    import torch,safetensors,safetensors.torch
    from transformers import BertForSequenceClassification,AutoTokenizer
    from transformers.models.bert.modeling_bert import BertModel,BertEmbeddings,BertSelfAttention,BertSdpaSelfAttention
    paths=c.source_paths();before=c.hashes(paths)
    output.mkdir(exist_ok=False);c.archive(output/'sources.tar.gz',paths)
    entries=[(BertForSequenceClassification,'from_pretrained'),(BertForSequenceClassification,'forward'),
        (BertModel,'forward'),(BertEmbeddings,'forward'),(AutoTokenizer,'from_pretrained'),
        (client_inputs,'ClientEmbeddings'),(n,'load_weights'),(safetensors,'safe_open'),(safetensors.torch,'load_file')]
    missing=object();original=[];calls=[];policies=[]
    def denied(label):
        def deny(*args,**kwargs):
            calls.append(label)
            if label=='BertForSequenceClassification.from_pretrained':
                policies.append(dict(local_files_only=kwargs.get('local_files_only'),use_safetensors=kwargs.get('use_safetensors'),
                    output_loading_info=kwargs.get('output_loading_info'),dtype=str(kwargs.get('torch_dtype')),attention=kwargs.get('attn_implementation')))
            raise RuntimeError('installed ranked probe denied '+label)
        return deny
    def invoke(call):
        try:call()
        except RuntimeError as error:
            if not str(error).startswith('installed ranked probe denied '):raise
        else:raise AssertionError('installed native entrypoint was not denied')
    try:
        for owner,name in entries:
            label=owner.__name__+'.'+name;original.append((owner,name,owner.__dict__.get(name,missing),inspect.getattr_static(owner,name)))
            setattr(owner,name,denied(label))
        for owner,name in entries:invoke(lambda owner=owner,name=name:getattr(owner,name)(None))
        # Execute the exact copied native loader bodies. All terminate in the
        # installed loader guard, before checkpoint access/model construction.
        invoke(lambda:n.native_model())
        invoke(lambda:n.native_model(torch.float64,True))
        invoke(n.NativeBackend)
        expected=[dict(local_files_only=True,use_safetensors=True,output_loading_info=True,dtype='None',attention=None),
                  dict(local_files_only=True,use_safetensors=True,output_loading_info=True,dtype='torch.float64',attention='eager')]
        if policies[-3:]!=expected+[expected[0]]:raise AssertionError('exact native default/eager call policy differs')
    finally:
        primary=sys.exception();errors=[]
        for owner,name,local,static in reversed(original):
            try:
                if local is missing:delattr(owner,name)
                else:setattr(owner,name,local)
            except BaseException as error:errors.append(error)
        if errors:
            if primary is not None:
                for e in errors:primary.add_note('installed guard restoration: '+type(e).__name__)
            else:raise next((e for e in errors if not isinstance(e,Exception)),errors[0])
    restored=all(inspect.getattr_static(o,name)is static for o,name,local,static in original)
    after=c.hashes(paths);loaded={}
    for name,module in tuple(sys.modules.items()):
        file=getattr(module,'__file__',None)
        if file and Path(file).is_absolute() and Path(file).is_file() and Path(file).resolve().parent==HERE:
            p=Path(file).resolve()
            if p.suffix=='.py':loaded[name]=dict(file=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    no_he=not any(x=='jax' or x.startswith(('jax.','jaxite_word','jaxite.')) for x in sys.modules)
    report=dict(passed=restored and len(calls)==12 and not forbidden and before==after and c.archive_ok(output/'sources.tar.gz',before) and no_he,
        scope='Installed imports and denied native entrypoints only; no models, assets, private inputs, JAX or HE.',
        direct_entrypoints=9,denied_calls=len(calls),denied_entrypoints=calls,all_restored=restored,native_loader_policies=policies[-3:],
        installed_attention_classes=[BertSelfAttention.__name__,BertSdpaSelfAttention.__name__],loaded_local_modules=loaded,
        source_hashes_before=before,source_hashes_after=after,source_files_unchanged=before==after,
        source_archive_verified=c.archive_ok(output/'sources.tar.gz',before),source_archive_sha256=c.sha(output/'sources.tar.gz'),
        forbidden_reads=forbidden,no_jax_or_he_modules_loaded=no_he,elapsed_s=time.monotonic()-start,pid=os.getpid(),cpu_affinity=sorted(os.sched_getaffinity(0)))
    c.write(output/'report.json',report)
    print(json.dumps({k:report[k] for k in ('passed','direct_entrypoints','denied_calls','elapsed_s')}))
    return 0 if report['passed'] else 1

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    raise SystemExit(main(**vars(p.parse_args())))
