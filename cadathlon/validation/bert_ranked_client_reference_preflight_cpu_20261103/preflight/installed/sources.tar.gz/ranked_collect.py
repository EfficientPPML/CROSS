"""Nine ranked private references; no HE and no benchmark timing claim."""
from pathlib import Path
import argparse,gc,hashlib,importlib.metadata,io,json,os,stat,sys,tarfile,tempfile,time
import client_inputs,input_gate,key_gate,ranked_input_gate as gate
from ranked_records import decode_cases,aggregates
from ranked_native import NativeBackend,evaluate_unique
from full_model_reference import MANIFEST_SHA256
from owned_directory import open_owned_directory,check_owned_directory
from cleanup import cleanup_signals,termination_signals
from terminal import terminal_scope
HERE=Path(__file__).resolve().parent
FIXTURE=Path('/tmp/bert-ranked-input-fixtures-20261103/actual-v1')
_FAILED_PRIVATE_FDS=[]

def sha(path):return client_inputs.file_sha256(Path(path))
def write(path,value):
    value['error_absent']='error' not in value
    if isinstance(value.get('error'),dict):
        value['error']['message']='Reference preparation failed; private details withheld'
    data=(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    fd,name=tempfile.mkstemp(prefix='.'+path.name+'-',dir=path.parent)
    temp=Path(name)
    try:
        with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
        temp.replace(path)
    finally:
        primary=sys.exception()
        try:temp.unlink(missing_ok=True)
        except BaseException as error:
            if primary is None:raise
            primary.add_note('public metadata temporary cleanup: '+type(error).__name__)

def source_paths():
    import check_reference
    result=check_reference.source_paths()
    # Include the Python implementation selection and independent polynomial
    #evaluators; compiled kernels are versioned, not claimed as source archives.
    import importlib.util
    for name in ('transformers.models.bert.configuration_bert','torch.nn.modules.module','safetensors.torch',
                 'numpy.polynomial.chebyshev','numpy.polynomial.polynomial','numpy.polynomial.polyutils'):
        result['installed/'+name.replace('.','/')+'.py']=Path(importlib.util.find_spec(name).origin)
    return result

def hashes(paths):return {n:sha(p) for n,p in paths.items()}
def archive(path,paths):
    with tarfile.open(path,'w:gz') as t:
        for n,p in paths.items():b=p.read_bytes();m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
def archive_ok(path,expected):
    with tarfile.open(path) as t:
        members=t.getmembers()
        return (len(members)==len(expected)==len({m.name for m in members}) and all(m.isfile() for m in members)
            and {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in members}==expected)
def assets():return {n:sha(n) for n in input_gate.ASSETS}

def save_references(root,fd,identity,cases,rows,bindings):
    check_owned_directory(root,fd,identity);inventory={}
    def file(name,value,lines=False):
        raw=(''.join(json.dumps(v,sort_keys=True,allow_nan=False)+'\n' for v in value) if lines else json.dumps(value,sort_keys=True,allow_nan=False)+'\n').encode()
        handle=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=fd)
        try:
            pending=memoryview(raw)
            while pending:
                written=os.write(handle,pending)
                if written<=0:raise OSError('private reference write made no progress')
                pending=pending[written:]
            os.fsync(handle)
        finally:
            primary=sys.exception()
            try:os.close(handle)
            except BaseException as error:
                _FAILED_PRIVATE_FDS.append((root,name,handle))
                if primary is None:raise
                primary.add_note('private reference file cleanup: '+type(error).__name__)
        info=os.stat(name,dir_fd=fd,follow_symlinks=False)
        if not stat.S_ISREG(info.st_mode) or stat.S_IMODE(info.st_mode)!=0o600:raise ValueError('private reference0600 publication failed')
        inventory[name]=dict(sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
    index={r['target_idx']:r for r in rows}
    file('master_references.jsonl',rows,True)
    for case in cases:
        selected=[index[r.target_idx] for r in case['records']]
        file(f"size{case['size']}-seed{case['seed']}-references.jsonl",selected,True)
    private=dict(schema='bert-ranked-private-references-v1',bindings=bindings,files=inventory.copy(),
        cases=[{n:c[n] for n in ('size','seed','count','input_sha256','private_target_order_sha256')} for c in cases])
    file('private_manifest.json',private)
    check_owned_directory(root,fd,identity)
    if set(os.listdir(fd))!=set(inventory):raise ValueError('private reference file inventory changed')
    for name,record in inventory.items():
        if sha(root/name)!=record['sha256']:raise ValueError('private reference readback differs')
    return inventory

def outside(output,protected):
    output=Path(output).absolute()
    for root in protected:
        root=Path(root).absolute()
        if output==root or root in output.parents or output.resolve()==root.resolve() or root.resolve() in output.resolve().parents:
            raise ValueError('new evidence must be outside retained original fixtures')
    return output

def run(output,*,execute=False,fixture_evidence=FIXTURE,fixture_report_sha256=gate.REPORT_SHA):
    if type(execute)is not bool:raise ValueError('explicit execution policy required')
    # Authenticate all nine PUBLIC records before output creation/containment.
    authorized=gate.public(fixture_evidence,fixture_report_sha256)
    output=outside(output,(authorized['workspace'],fixture_evidence));output.mkdir(exist_ok=False)
    report=dict(passed=False,execute=execute,scope='Client-only ranked reference preparation; no HE or benchmark/per-case native timing claim.',
        official_reference_complete=False,exact_reference_parity_passed=False,approximation_validation_passed=False,
        official_evaluation_complete=False,private_reference_publication_complete=False,official_references_retained=False,private_workspace_retained=False,error_absent=True,
        raw_arrays_archived=False,actual_native_started=False,fixture_report_sha256=fixture_report_sha256,
        candidate_sha256=MANIFEST_SHA256,selected_records=2124,unique_records=408,cases=[],cleanup_errors=[],
        reference_acceptance_requires=['official_reference_complete','private_reference_publication_complete','official_references_retained','private_workspace_retained','error_absent','source_files_unchanged','source_archive_verified','assets_unchanged','original_fixture_unchanged','public_prerequisite_unchanged','cleanup_completed','terminal_scope_completed','no_jax_or_he_modules_loaded'],
        pid=os.getpid(),cpu_affinity=sorted(os.sched_getaffinity(0)))
    start=time.monotonic();primary=cleanup_error=None;paths={};before={};initial_assets=None;borrowed=None;backend=None
    workspace=fd=identity=None;old_umask=None
    def attempt(name,fn):
        nonlocal cleanup_error
        try:return fn()
        except BaseException as error:
            report['cleanup_errors'].append(dict(operation=name,type=type(error).__name__))
            if primary is not None:primary.add_note(name+': '+type(error).__name__)
            elif cleanup_error is None:cleanup_error=error
            elif not isinstance(error,Exception) and isinstance(cleanup_error,Exception):
                error.add_note('earlier cleanup: '+type(cleanup_error).__name__);cleanup_error=error
            else:cleanup_error.add_note(name+': '+type(error).__name__)
    try:
        write(output/'report.json',report);old_umask=os.umask(0o077)
        paths=source_paths();before=hashes(paths)
        origins=json.loads((HERE/'origins.json').read_bytes())
        if any(before.get(n)!=v['sha256'] for n,v in origins.items()) or before.get('candidate_manifest.json')!=MANIFEST_SHA256:
            raise ValueError('exact copied helper/candidate bytes differ')
        archive(output/'sources.tar.gz',paths)
        if not archive_ok(output/'sources.tar.gz',before):raise ValueError('initial source archive differs')
        report.update(source_hashes_before=before,source_archive_sha256=sha(output/'sources.tar.gz'),
            versions={n:importlib.metadata.version(n) for n in ('numpy','scipy','torch','transformers','safetensors')},
            gates=dict(exact_native_abs=1e-12,embedding_native_abs=0.,approximate_logit='abs(error)<=0.02+0.01*abs(official_fp32)',tie='class1 on equal logits'))
        if execute:
            prerequisite=key_gate.parse(key_gate.read(HERE/'preflight-v1/report.json'))
            if prerequisite.get('passed')is not True or prerequisite.get('candidate_source_hashes')!=before:
                raise ValueError('successful unchanged source-bound preflight required before native execution')
            initial_assets=assets()
            if initial_assets!=input_gate.ASSETS:raise ValueError('pinned public assets differ before native work')
            borrowed=gate.BorrowedFixtures(authorized);borrowed.__enter__()
            cases,master=decode_cases(borrowed)
            report['all_nine_private_inputs_authenticated']=True
            # Every record/label/order is validated before any model is built.
            workspace=Path(tempfile.mkdtemp(prefix='bert-ranked-reference-client-'));workspace.chmod(0o700)
            fd,identity=open_owned_directory(workspace);report.update(private_workspace=str(workspace),private_workspace_identity=identity)
            report['actual_native_started']=True;write(output/'report.json',report)
            backend=NativeBackend()
            report['native_policy']=backend.policy
            def progress(values):report['progress']=values;write(output/'report.json',report)
            rows=evaluate_unique(master,backend,progress)
            report['cases']=aggregates(cases,rows)
            report['official_evaluation_complete']=True
            report['exact_reference_parity_passed']=all(c['exact_reference_parity_passed'] for c in report['cases'])
            report['approximation_validation_passed']=all(c['approximation_complete'] and c['approximate_numeric_gate_passed'] and c['prediction_agreement'] and c['ranked_accuracy_floor_passed'] and c['ranked_accuracy_drop_passed'] for c in report['cases'])
            bindings=dict(fixture_report_sha256=fixture_report_sha256,candidate_sha256=MANIFEST_SHA256,
                source_archive_sha256=report['source_archive_sha256'],checkpoint_sha256=client_inputs.ASSETS['model.safetensors'],
                config_sha256=client_inputs.ASSETS['config.json'],official_dtype='float32',official_attention='sdpa',diagnostic_dtype='float64',diagnostic_attention='eager')
            bindings['evaluation_completion_flags']={n:report[n] for n in ('official_evaluation_complete','exact_reference_parity_passed','approximation_validation_passed')}
            bindings['final_acceptance_requires_public_report']=True
            report['private_reference_files']=save_references(workspace,fd,identity,cases,rows,bindings)
            report.update(private_reference_publication_complete=True,official_references_retained=True,official_reference_complete=True)
            report['passed']=report['exact_reference_parity_passed'] and report['approximation_validation_passed']
        else:report.update(passed=True,public_gate_only=True,private_fixture_read=False)
    except BaseException as error:
        primary=error;report.update(passed=False,error=dict(type=type(error).__name__,message='Reference preparation failed; private details withheld'))
    finally:
        with terminal_scope(report,output/'report.json',write,cleanup_signals,lambda:(primary,cleanup_error)):
            if backend is not None:attempt('native owner retirement',backend.close)
            if borrowed is not None:
                report['original_fixture_unchanged']=attempt('all original fixture readback',borrowed.check)is True
                attempt('borrowed fixture handle close',lambda:borrowed.close(primary))
                if not borrowed.closed:report['cleanup_errors'].append(dict(operation='borrowed handles unresolved',type='IncompleteCleanup'))
            if initial_assets is not None:
                final_assets=attempt('public asset readback',assets);report.update(asset_hashes_before=initial_assets,asset_hashes_after=final_assets,assets_unchanged=final_assets==initial_assets)
            if workspace is not None:
                report['private_workspace_retained']=attempt('private reference directory identity',lambda:(check_owned_directory(workspace,fd,identity),True)[1])is True
            if fd is not None:attempt('private reference handle close',lambda:os.close(fd))
            after=attempt('source readback',lambda:hashes(paths));verified=attempt('source archive readback',lambda:archive_ok(output/'sources.tar.gz',before)) if before else False
            report.update(source_hashes_after=after,source_files_unchanged=bool(before) and after==before,source_archive_verified=verified is True)
            again=attempt('public producer reauthentication',lambda:gate.public(fixture_evidence,fixture_report_sha256))
            report['public_prerequisite_unchanged']=again is not None and again['report']==authorized['report']
            if old_umask is not None:attempt('umask restoration',lambda:os.umask(old_umask))
            report['cleanup_completed']=not report['cleanup_errors']
            report['no_jax_or_he_modules_loaded']=not any(n=='jax' or n.startswith(('jax.','jaxite_word','jaxite.')) for n in sys.modules)
            acceptance=report['no_jax_or_he_modules_loaded'] and report['source_files_unchanged'] and verified and report['public_prerequisite_unchanged'] and report['cleanup_completed'] and primary is None and cleanup_error is None and (not execute or report.get('assets_unchanged') and report.get('original_fixture_unchanged') and report['private_reference_publication_complete'] and report['official_references_retained'] and report['private_workspace_retained'])
            if not acceptance:
                report['official_reference_complete']=False;report['exact_reference_parity_passed']=False;report['approximation_validation_passed']=False
            report['passed']=bool(report['passed'] and acceptance and primary is None and cleanup_error is None)
            report['no_jax_or_he_modules_loaded']=not any(n=='jax' or n.startswith(('jax.','jaxite_word','jaxite.')) for n in sys.modules)
            report['passed']=report['passed'] and report['no_jax_or_he_modules_loaded'];report['elapsed_s']=time.monotonic()-start
            try:write(output/'report.json',report)
            except BaseException as error:
                prior=primary if primary is not None else cleanup_error
                if prior is None:raise
                prior.add_note('reference terminal publication: '+type(error).__name__)
            if primary is not None:raise primary
            if cleanup_error is not None:raise cleanup_error
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--execute',action='store_true')
    try:
        with termination_signals():result=run(**vars(p.parse_args()))
        print(json.dumps({n:result[n] for n in ('passed','execute','official_reference_complete','exact_reference_parity_passed','approximation_validation_passed','elapsed_s')}))
        exit_code=0 if result['passed'] else 1
    except BaseException as error:
        # CLI tracebacks may carry third-party input fragments. Keep all public
        #errors type-only while the in-process API preserves primary identity.
        print(json.dumps(dict(passed=False,error_type=type(error).__name__)),file=sys.stderr);exit_code=130 if not isinstance(error,Exception) else 1
    raise SystemExit(exit_code)
