"""Synthetic native objects exercise actual adapter without model/assets/data reads."""
from contextlib import nullcontext
from types import SimpleNamespace as NS
import sys
import numpy as np
import pytest
import ranked_native as n
import client_inputs

class Tensor:
    def __init__(self,a):self.a=np.asarray(a)
    def cpu(self):return self
    def detach(self):return self
    def numpy(self):return self.a

class Hook:
    def __init__(self,owner,callback):self.owner=owner;self.callback=callback;self.removed=False;self.error=None
    def remove(self):
        self.removed=True
        if self.error:raise self.error
        self.owner.hooks.remove(self)

class Attention:
    def __init__(self,kind):self.self=type(kind,(),{})();self.hooks=[];self.handles=[]
    def register_forward_hook(self,callback):
        h=Hook(self,callback);self.hooks.append(h);self.handles.append(h);return h

class Model:
    def __init__(self,kind,base):
        self.config=NS(_attn_implementation=kind);self.base=base;self.calls=[];self.fail=None
        self.bert=NS(encoder=NS(layer=[NS(attention=Attention('BertSdpaSelfAttention' if kind=='sdpa' else 'BertSelfAttention')) for _ in range(12)]),pooler=Attention('Pooler'))
    def __call__(self,**kw):
        self.calls.append(kw)
        if self.fail:raise self.fail
        for i,layer in enumerate(self.bert.encoder.layer):
            for h in layer.attention.hooks[:]:h.callback(layer.attention,(),(Tensor((self.base+(i+1)*.1)[None]),))
        pool=np.arange(768,dtype=np.float64)/1024
        for h in self.bert.pooler.hooks[:]:h.callback(self.bert.pooler,(),Tensor(pool[None]))
        return NS(logits=Tensor([[.1,.2]]),hidden_states=tuple(Tensor((self.base+i)[None]) for i in range(13)))

@pytest.fixture
def adapter(monkeypatch):
    base=np.arange(128*768,dtype=np.float64).reshape(128,768)/2**20
    official=Model('sdpa',base);native=Model('eager',base);calls=[];threads=[];compute_calls=[]
    torch=NS(float64='float64',long='long',set_num_threads=threads.append,get_num_threads=lambda:threads[-1],
             tensor=lambda a,**kw:Tensor(a),no_grad=nullcontext)
    monkeypatch.setitem(sys.modules,'torch',torch)
    def native_model(*args):calls.append(args);return official if not args else native
    monkeypatch.setattr(n,'native_model',native_model)
    monkeypatch.setattr(n.client_inputs,'ClientEmbeddings',lambda path:NS(original_embeddings=lambda record:base.copy()))
    monkeypatch.setattr(n,'load_weights',lambda pins:{'synthetic':np.array([[1.,2.]],dtype=np.float64)})
    positions=(0,3,17,127)
    record=client_inputs.ValidatedInput(7,(101,)+tuple([0]*127),tuple([0]*128),tuple(int(i in positions) for i in range(128)))
    def compute(values,weights,raw,approximate):
        compute_calls.append((values.copy(),weights,raw,approximate))
        np.testing.assert_array_equal(values,base[list(positions)])
        return dict(attention_outputs=[(base+(i+1)*.1)[list(positions)] for i in range(12)],
                    block_outputs=[(base+i+1)[list(positions)] for i in range(12)],pooler=np.arange(768,dtype=np.float64)/1024,
                    logits=np.array([.1,.2]),domain_observations=[])
    monkeypatch.setattr(n,'compute',compute)
    return NS(base=base,official=official,native=native,calls=calls,threads=threads,compute_calls=compute_calls,record=record,positions=positions)


def test_same_original_positions_and_frozen_rules_with_two_reused_models(adapter):
    a=adapter;b=n.NativeBackend()
    assert a.calls==[(),('float64',True)] and a.threads==[4]
    assert b.policy['official_attention']=='sdpa' and b.policy['diagnostic_attention']=='eager'
    assert not b.weights['synthetic'].flags.writeable
    for _ in range(2):
        r=b.evaluate(a.record)
        assert r['exact_reference_parity_passed'] and r['approximation_complete'] and r['original_positions']==list(a.positions)
    assert len(a.calls)==2 and len(a.compute_calls)==4 and [c[3] for c in a.compute_calls]==[False,True]*2
    assert len({id(c[1]) for c in a.compute_calls})==1 and len({c[2] for c in a.compute_calls})==1
    for model in (a.official,a.native):
        for kw in model.calls:
            assert kw['input_ids'].a.shape==(1,128)
            np.testing.assert_array_equal(kw['attention_mask'].a[0],a.record.attention_mask)
    assert all(h.removed for layer in a.native.bert.encoder.layer for h in layer.attention.handles)
    b.close();assert b.official is b.native is b.embedder is b.weights is None

@pytest.mark.parametrize('kind',['sdpa','eager','empty'])
def test_actual_implementation_policy_rejected_before_forward(adapter,kind):
    a=adapter
    if kind=='empty':a.official.bert.encoder.layer=[]
    elif kind=='sdpa':a.official.config._attn_implementation='eager'
    else:a.native.bert.encoder.layer[0].attention.self=object()
    with pytest.raises(ValueError):n.NativeBackend()
    assert not a.official.calls and not a.native.calls

@pytest.mark.parametrize('mode',['domain','nonfinite','exact','native','mutation'])
def test_failure_scopes_and_complete_native_hook_retirement(adapter,monkeypatch,mode):
    a=adapter;b=n.NativeBackend();original=n.compute
    primary=RuntimeError('PRIVATE_MARKER')
    def compute(*args,**kwargs):
        approximate=kwargs['approximate']
        if mode=='domain' and approximate:raise n.DomainViolation('private-site',{'label':'private-site','passed':False})
        r=original(*args,**kwargs)
        if mode=='nonfinite' and approximate:r['logits'][0]=np.nan
        if mode=='exact' and not approximate:r['block_outputs'][7][0,0]+=1e-8
        if mode=='mutation' and approximate:args[0][0,0]+=1
        return r
    monkeypatch.setattr(n,'compute',compute)
    if mode=='native':a.native.fail=primary
    try:
        if mode in ('native','mutation'):
            with pytest.raises(RuntimeError if mode=='native' else ValueError) as caught:b.evaluate(a.record)
            if mode=='native':assert caught.value is primary
        else:
            r=b.evaluate(a.record)
            if mode=='exact':assert not r['exact_reference_parity_passed'] and r['approximation_complete']
            else:assert not r['approximation_complete'] and r['exact_reference_parity_passed']
    finally:
        assert all(h.removed for layer in a.native.bert.encoder.layer for h in layer.attention.handles)
        b.close()


def test_partial_native_constructor_retired_on_later_load_failure(adapter,monkeypatch):
    calls=[];original=n.NativeBackend.close;error=KeyboardInterrupt('private')
    def close(self):calls.append(self);original(self)
    monkeypatch.setattr(n.NativeBackend,'close',close)
    monkeypatch.setattr(n,'load_weights',lambda *args:(_ for _ in ()).throw(error))
    with pytest.raises(KeyboardInterrupt) as caught:n.NativeBackend()
    assert caught.value is error and len(calls)==1 and calls[0].official is calls[0].native is None
