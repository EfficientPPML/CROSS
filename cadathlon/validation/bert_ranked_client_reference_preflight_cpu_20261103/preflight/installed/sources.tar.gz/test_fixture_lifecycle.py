"""Deterministic original-inode and uncertain-descriptor regressions, synthetic only."""
import os
from pathlib import Path
import pytest
import ranked_input_gate as g
from test_ranked_reference import fixture,authorized


def test_uncertain_directory_close_never_retries_reused_number(tmp_path,monkeypatch):
    held=g.BorrowedFixtures({});fd=os.open(tmp_path,os.O_RDONLY|os.O_DIRECTORY);held.handles=[fd]
    real=os.close;calls=[];replacement=[];error=OSError('close outcome uncertain')
    def close(current):
        calls.append(current)
        if current==fd and not replacement:
            real(current);replacement.append(os.open(tmp_path,os.O_RDONLY|os.O_DIRECTORY));raise error
        real(current)
    with monkeypatch.context() as m:
        m.setattr(g.os,'close',close)
        with pytest.raises(OSError) as caught:held.close()
        assert caught.value is error and replacement==[fd] and not held.closed and not held.handles
        assert held.uncertain_directory_descriptors==[fd]
        held.close();assert calls==[fd] and os.fstat(replacement[0])
    real(replacement[0])


def test_directory_cleanup_attempts_all_and_preserves_cancellation(tmp_path,monkeypatch):
    held=g.BorrowedFixtures({});fds=[os.open(tmp_path,os.O_RDONLY|os.O_DIRECTORY) for _ in range(3)];held.handles=fds[:]
    real=os.close;calls=[];first=OSError('ordinary');cancel=KeyboardInterrupt('cancel')
    def close(fd):
        calls.append(fd);real(fd)
        if fd==fds[2]:raise first
        if fd==fds[1]:raise cancel
    with monkeypatch.context() as m:
        m.setattr(g.os,'close',close)
        with pytest.raises(KeyboardInterrupt) as caught:held.close()
        assert caught.value is cancel and calls==fds[::-1] and not held.closed
        held.close();assert calls==fds[::-1]


@pytest.mark.parametrize('kind',['regular','fifo','oversize'])
def test_open_time_replacement_rejected_without_adopting_new_state(fixture,monkeypatch,kind):
    held=g.BorrowedFixtures(authorized(fixture));held.__enter__()
    path,state=next((p,s) for p,s in held.states.items() if s[0]=='file');original=path.with_name(path.name+'-original')
    old=g.os.open;done=[];states=held.states.copy()
    def swap(name,flags,*args,**kwargs):
        if name==path.name and kwargs.get('dir_fd')==state[1] and not done:
            done.append(1);path.rename(original)
            if kind=='fifo':os.mkfifo(path,0o600)
            else:
                path.write_bytes(held.raw_for(path));path.chmod(0o600)
                if kind=='oversize':
                    with path.open('wb') as stream:stream.truncate((16<<20)+1)
        return old(name,flags,*args,**kwargs)
    try:
        with monkeypatch.context() as m:
            m.setattr(g.os,'open',swap)
            with pytest.raises(ValueError):held.check()
        assert done and held.states==states and original.exists()
    finally:held.close()


def test_change_during_read_rejected_and_original_state_retained(fixture,monkeypatch):
    held=g.BorrowedFixtures(authorized(fixture));held.__enter__()
    path,state=next((p,s) for p,s in held.states.items() if s[0]=='file');states=held.states.copy();real=os.read;done=[]
    def read(fd,n):
        value=real(fd,n)
        if not done and g.BorrowedFixtures._signature(os.fstat(fd))==state[2]:
            done.append(1)
            with path.open('ab') as f:f.write(b'changed')
        return value
    try:
        with monkeypatch.context() as m:
            m.setattr(g.os,'read',read)
            with pytest.raises(ValueError):held.check()
        assert done and held.states==states
    finally:held.close()


def test_read_primary_preserved_when_file_close_uncertain(tmp_path,monkeypatch):
    path=tmp_path/'file';path.write_bytes(b'test');path.chmod(0o600)
    parent=os.open(tmp_path,os.O_RDONLY|os.O_DIRECTORY);held=g.BorrowedFixtures({});realclose=os.close
    primary=KeyboardInterrupt('primary');secondary=OSError('secondary');closed=[]
    def close(fd):closed.append(fd);realclose(fd);raise secondary
    try:
        with monkeypatch.context() as m:
            m.setattr(g.os,'read',lambda *a:(_ for _ in ()).throw(primary));m.setattr(g.os,'close',close)
            with pytest.raises(KeyboardInterrupt) as caught:held._read(path,parent)
            assert caught.value is primary
            held.close(primary);assert len(closed)==1 and held.uncertain_file_descriptors==closed and not held.closed
        assert 'OSError' in '\n'.join(primary.__notes__)
    finally:realclose(parent)


def test_authenticated_reader_uses_no_dup_or_fdopen(fixture,monkeypatch):
    def denied(*args,**kwargs):raise AssertionError('descriptor ownership handoff')
    authorization=authorized(fixture)
    with monkeypatch.context() as m:
        m.setattr(g.os,'dup',denied);m.setattr(g.os,'fdopen',denied)
        with g.BorrowedFixtures(authorization) as held:assert held.check()
