"""Client-only reused native models and unchanged independent arithmetic."""
import gc,json,sys
from pathlib import Path
import numpy as np
import client_inputs
from check_reference import native_model,compare,prediction_agreement,real_array
from prepare_native_full import capture_pooler,hidden_array
from collect_full_model_reference import load_weights
from full_model_reference import compute,DomainViolation,MANIFEST_SHA256
HERE=Path(__file__).resolve().parent

class NativeBackend:
    def __init__(self):
        import torch
        self.torch=torch;torch.set_num_threads(4)
        self.official=native_model()
        if self.official.config._attn_implementation!='sdpa' or any(type(layer.attention.self).__name__!='BertSdpaSelfAttention' for layer in self.official.bert.encoder.layer):
            raise ValueError('upstream default FP32 attention must resolve to actual SDPA')
        self.native=native_model(torch.float64,True)
        if self.native.config._attn_implementation!='eager' or any(type(layer.attention.self).__name__!='BertSelfAttention' for layer in self.native.bert.encoder.layer):
            raise ValueError('diagnostic FP64 attention must be actual eager implementation')
        self.embedder=client_inputs.ClientEmbeddings(__import__('input_gate').MODEL)
        arrays=load_weights(json.loads((HERE/'server_tensor_pins.json').read_bytes()))
        self.weights={name:np.frombuffer(value.tobytes(),dtype=np.float64).reshape(value.shape) for name,value in arrays.items()}
        self.raw=(HERE/'candidate_manifest.json').read_bytes()
        self.count=0
    def evaluate(self,record):
        torch=self.torch;K=sum(record.attention_mask)
        tokens={name:torch.tensor([getattr(record,name)],dtype=torch.long,device='cpu') for name in ('input_ids','token_type_ids','attention_mask')}
        with torch.no_grad():
            native32=real_array(self.official(**tokens,return_dict=True).logits.cpu().numpy()[0],(2,))
            original=self.embedder.original_embeddings(record);positions=tuple(i for i,x in enumerate(record.attention_mask) if x)
            embeddings=original[list(positions)].copy();original_bytes=embeddings.tobytes();attention=[];handles=[]
            def hook(module,args,value):attention.append(hidden_array(value[0],128)[list(positions)])
            try:
                for layer in self.native.bert.encoder.layer:handles.append(layer.attention.register_forward_hook(hook))
                full,pooler=capture_pooler(self.native.bert.pooler,lambda:self.native(**tokens,return_dict=True,output_hidden_states=True))
            finally:
                primary=sys.exception();errors=[]
                for handle in handles:
                    try:handle.remove()
                    except BaseException as error:errors.append(error)
                if errors:
                    if primary is not None:
                        for error in errors:primary.add_note('native hook cleanup: '+type(error).__name__)
                    else:raise next((e for e in errors if not isinstance(e,Exception)),errors[0])
            if len(attention)!=12 or len(full.hidden_states)!=13:raise ValueError('complete native hidden-state capture required')
            native64=real_array(full.logits.cpu().numpy()[0],(2,))
            embed_gate=compare(original,hidden_array(full.hidden_states[0],128),shape=(128,768),gate=0.)
            exact=compute(embeddings,self.weights,self.raw,approximate=False)
            checks=[dict(layer=layer,attention=compare(exact['attention_outputs'][layer],attention[layer],shape=(K,768),gate=1e-12),
                block=compare(exact['block_outputs'][layer],hidden_array(full.hidden_states[layer+1],128)[list(positions)],shape=(K,768),gate=1e-12)) for layer in range(12)]
            pool_gate=compare(exact['pooler'],pooler,shape=(768,),gate=1e-12);logit_gate=compare(exact['logits'],native64,shape=(2,),gate=1e-12)
            row=dict(target_idx=record.target_idx,original_positions=list(positions),native_fp32_logits=native32.tolist(),native_fp64_logits=native64.tolist(),
                independent_exact_fp64_logits=exact['logits'].tolist(),approximate_fp64_logits=None,approximation_complete=False,
                exact_reference_parity_passed=embed_gate['passed'] and pool_gate['passed'] and logit_gate['passed'] and all(x[k]['passed'] for x in checks for k in ('attention','block')),
                exact_parity=dict(embedding=embed_gate,layers=checks,pooler=pool_gate,logits=logit_gate))
            try:
                approx=compute(embeddings,self.weights,self.raw,approximate=True)
                row.update(approximation_complete=True,approximate_fp64_logits=real_array(approx['logits'],(2,)).tolist(),domain_observations=approx['domain_observations'],
                    approximate_vs_official_fp32=compare(approx['logits'],native32,shape=(2,),p2=True),
                    approximate_vs_native_fp64=compare(approx['logits'],native64,shape=(2,),p2=True),
                    prediction_agreement_official_fp32=prediction_agreement(approx['logits'],native32),
                    prediction_agreement_native_fp64=prediction_agreement(approx['logits'],native64))
            except DomainViolation as error:
                row.update(failure_kind='DomainViolation',failed_domain=error.observation,unexecuted_later_sites=True)
            except (ValueError,FloatingPointError,OverflowError) as error:
                row.update(failure_kind=type(error).__name__,failure_message='Unchanged approximation failed; private details withheld',unexecuted_later_sites=True)
            if embeddings.tobytes()!=original_bytes:raise ValueError('original compact embedding source changed')
            self.count+=1
            return row
    def close(self):
        self.official=self.native=self.embedder=self.weights=None;gc.collect()

def evaluate_unique(master,backend,progress):
    rows=[]
    for record,truth in zip(master['records'],master['labels']):
        row=backend.evaluate(record)
        if row.get('target_idx')!=record.target_idx:raise ValueError('native reference association differs')
        row['label']=truth;rows.append(row)
        progress(dict(completed_unique=len(rows),exact_parity_failures=sum(not r['exact_reference_parity_passed'] for r in rows),
            approximation_failures=sum(not r['approximation_complete'] for r in rows)))
    if len(rows)!=408:raise ValueError('complete unique408 reference inventory required')
    return rows
