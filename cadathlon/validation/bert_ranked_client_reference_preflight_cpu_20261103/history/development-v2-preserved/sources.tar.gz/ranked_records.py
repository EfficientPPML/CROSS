"""Private record/order validation and aggregate-only diagnostics."""
import hashlib,json,math
import numpy as np
import client_inputs
from ranked_input_gate import SCHEDULE,NAMES
from check_reference import compare,prediction_agreement,real_array

def digest(raw):return hashlib.sha256(raw).hexdigest()
def parse(raw):
    try:return client_inputs._json(raw)
    except Exception:raise ValueError('private JSON schema could not be validated') from None

def decode_cases(borrowed):
    cases=[]
    for public,(size,count,seed) in zip(borrowed.authorized['report']['cases'],SCHEDULE):
        raw=borrowed.raw[(size,seed)];name=NAMES[size]
        try:
            lines=raw[f'io/{name}/intermediate/client_preprocessed_input'].decode('utf8').splitlines()
            records=tuple(client_inputs.validate_record(parse(line)) for line in lines)
            selection=parse(raw['private_selection.json'])
            labels=tuple(int(line) for line in raw[f'datasets/{name}/intermediate/test_labels.txt'].decode('ascii').splitlines())
        except Exception:raise ValueError('private ranked records failed schema validation') from None
        if type(selection)is not dict or set(selection)!={'schema','size','count','base_seed','generator_seed','row_ordinals','target_ids','labels'}:
            raise ValueError('exact private ranked selection schema required')
        for n,v in dict(schema='private-bert-ranked-selection-v1',size=size,count=count,base_seed=seed,generator_seed=public['generator_seed']).items():
            if type(selection[n])is not type(v) or selection[n]!=v:raise ValueError('private ranked selection identity differs')
        ids=tuple(r.target_idx for r in records);ordinals=selection['row_ordinals']
        if (len(records)!=count or len(set(ids))!=count or list(ids)!=selection['target_ids']
            or type(ordinals)is not list or len(ordinals)!=count or any(type(x)is not int or not 0<=x<408 for x in ordinals)
            or any(type(x)is not int for x in selection['target_ids']) or ordinals!=sorted(set(ordinals)) or len(labels)!=count or any(x not in (0,1) for x in labels)
            or selection['labels']!=list(labels) or any(type(x)is not int for x in selection['labels'])):
            raise ValueError('private ranked count/order/labels differ')
        if digest(json.dumps(list(ids)).encode())!=public['private_target_order_sha256'] or digest(json.dumps(ordinals).encode())!=public['private_row_order_sha256']:
            raise ValueError('private ranked ordered digest differs')
        hist={}
        for record in records:
            k=str(sum(record.attention_mask));hist[k]=hist.get(k,0)+1
        if hist!=public['valid_token_count_histogram']:raise ValueError('private token-length histogram differs')
        cases.append(dict(size=size,seed=seed,count=count,records=records,labels=labels,ordinals=tuple(ordinals),
            input_sha256=public['input_file_sha256'][f'io/{name}/intermediate/client_preprocessed_input'],
            private_target_order_sha256=public['private_target_order_sha256']))
    master=next(c for c in cases if (c['size'],c['seed'])==(3,42))
    if master['ordinals']!=tuple(range(408)):raise ValueError('complete canonical408 order required')
    lookup={r.target_idx:(r,label,i) for i,(r,label) in enumerate(zip(master['records'],master['labels']))}
    if len(lookup)!=408:raise ValueError('exact unique408 master required')
    for case in cases:
        for record,label,ordinal in zip(case['records'],case['labels'],case['ordinals']):
            if lookup.get(record.target_idx)!=(record,label,ordinal):raise ValueError('ranked case differs from the authenticated canonical master')
    return tuple(cases),master

def label(logits):
    values=real_array(logits,(2,));return int(values[1]>=values[0])

def aggregates(cases,rows):
    index={row['target_idx']:row for row in rows};result=[]
    if len(index)!=len(rows) or len(rows)!=408:raise ValueError('exact complete unique reference result inventory required')
    for case in cases:
        selected=[index[record.target_idx] for record in case['records']]
        official=sum(label(row['native_fp32_logits'])==truth for row,truth in zip(selected,case['labels']))
        approx_complete=all(row['approximation_complete'] for row in selected)
        approximate=sum(label(row['approximate_fp64_logits'])==truth for row,truth in zip(selected,case['labels'])) if approx_complete else None
        numeric=all(row.get('approximate_vs_official_fp32',{}).get('passed')is True for row in selected)
        prediction=all(row.get('prediction_agreement_official_fp32')is True for row in selected)
        result.append(dict(size=case['size'],seed=case['seed'],count=case['count'],official_reference_complete=True,
            official_correct=official,official_accuracy=official/case['count'],approximation_complete=approx_complete,
            approximate_correct=approximate,approximate_accuracy=None if approximate is None else approximate/case['count'],
            approximate_numeric_gate_passed=numeric,prediction_agreement=prediction,
            ranked_accuracy_floor_passed=approx_complete and 4*approximate>=3*case['count'],
            ranked_accuracy_drop_passed=approx_complete and 100*(official-approximate)<=2*case['count'],
            exact_reference_parity_passed=all(row['exact_reference_parity_passed'] for row in selected),
            domain_failure_count=sum(row.get('failure_kind')=='DomainViolation' for row in selected),
            input_sha256=case['input_sha256'],private_target_order_sha256=case['private_target_order_sha256']))
    return result
