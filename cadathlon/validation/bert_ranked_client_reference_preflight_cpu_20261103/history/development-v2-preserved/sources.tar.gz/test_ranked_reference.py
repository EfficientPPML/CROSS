"""Synthetic nine-case records and mocked native owners; no real private reads."""
from pathlib import Path
from types import SimpleNamespace as NS
import hashlib,json,os,shutil,stat,sys
import pytest
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import ranked_input_gate as g,ranked_records as records,ranked_collect as c
from ranked_native import evaluate_unique

@pytest.fixture
def fixture(tmp_path):
    # Public producer proof only. All private bytes below are generated here.
    evidence=tmp_path/'evidence';evidence.mkdir();root=tmp_path/'private';root.mkdir(mode=0o700)
    public=Path('/tmp/bert-ranked-input-fixtures-20261103/actual-v1')
    report=json.loads((public/'report.json').read_text());shutil.copyfile(public/'sources.tar.gz',evidence/'sources.tar.gz')
    info=root.stat();report['private_workspace']=str(root);report['private_workspace_identity']=dict(device=info.st_dev,inode=info.st_ino)
    for row,(size,count,seed) in zip(report['cases'],g.SCHEDULE):
        case=root/f'size{size}-seed{seed}';case.mkdir(mode=0o700);name=g.NAMES[size]
        ids=list(range(1000,1000+count));labels=[x%2 for x in ids]
        token_rows=[dict(target_idx=x,input_ids=[101,1000+x%100,102]+[0]*125,token_type_ids=[0]*128,attention_mask=[1]*3+[0]*125) for x in ids]
        selection=dict(schema='private-bert-ranked-selection-v1',size=size,count=count,base_seed=seed,generator_seed=row['generator_seed'],row_ordinals=list(range(count)),target_ids=ids,labels=labels)
        content={n:b'fixture\n' for n in g.expected_files(size)}
        content[f'io/{name}/intermediate/client_preprocessed_input']=''.join(json.dumps(v)+'\n' for v in token_rows).encode()
        content[f'datasets/{name}/intermediate/test_labels.txt']=''.join(str(x)+'\n' for x in labels).encode()
        content['private_selection.json']=json.dumps(selection).encode()
        for n,b in content.items():p=case/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);p.chmod(0o600)
        for p in case.rglob('*'):
            if p.is_dir():p.chmod(0o700)
        row.update(input_file_sha256={n:hashlib.sha256(b).hexdigest() for n,b in content.items()},preprocessed_input_path=str(case/f'io/{name}/intermediate/client_preprocessed_input'),
            private_target_order_sha256=hashlib.sha256(json.dumps(ids).encode()).hexdigest(),private_row_order_sha256=hashlib.sha256(json.dumps(list(range(count))).encode()).hexdigest(),valid_token_count_histogram={'3':count})
    def publish():
        raw=json.dumps(report).encode();(evidence/'report.json').write_bytes(raw);return hashlib.sha256(raw).hexdigest()
    pin=publish()
    return NS(evidence=evidence,root=root,report=report,pin=pin,publish=publish)

def authorized(f):return g.public(f.evidence,f.pin)

def test_public_gate_and_54file_authenticated_unique408(fixture):
    with g.BorrowedFixtures(authorized(fixture)) as held:
        cases,master=records.decode_cases(held)
        assert len(cases)==9 and sum(c['count'] for c in cases)==2124 and len(master['records'])==408
        assert held.check() and len([s for s in held.states.values() if s[0]=='file'])==54
    assert held.closed and not held.handles

@pytest.mark.parametrize('field,value',[('passed',False),('terminal_scope_completed',False),('cleanup_completed',False),('ranked_cases_expected',True),('selected_records_expected',408),('model_forward',True)])
def test_incomplete_public_producer_rejected(fixture,field,value):
    fixture.report[field]=value;fixture.pin=fixture.publish()
    with pytest.raises(ValueError):authorized(fixture)

@pytest.mark.parametrize('change',['last_count','last_order','last_path','last_inventory','source','assets','upstream'])
def test_all_nine_public_contracts_checked_before_private_reads(fixture,change,monkeypatch):
    if change=='last_count':fixture.report['cases'][-1]['record_count']=407
    if change=='last_order':fixture.report['cases'][-1]['base_seed']=42
    if change=='last_path':fixture.report['cases'][-1]['preprocessed_input_path']='/not/private'
    if change=='last_inventory':fixture.report['cases'][-1]['input_file_sha256']['extra']='0'*64
    if change=='source':fixture.report['source_hashes_after']={}
    if change=='assets':fixture.report['asset_file_sha256_before']={}
    if change=='upstream':fixture.report['upstream_original_sha256_after']={}
    fixture.pin=fixture.publish();original=g.os.open;reads=[]
    def opening(path,*a,**kw):
        if str(fixture.root) in str(path):reads.append(str(path));raise AssertionError('private read before public gate')
        return original(path,*a,**kw)
    monkeypatch.setattr(g.os,'open',opening)
    with pytest.raises(ValueError):authorized(fixture)
    assert reads==[]

@pytest.mark.parametrize('change',['byte','mode','extra','symlink'])
def test_private_auth_rejects_replacement_content_and_inventory(fixture,change):
    a=authorized(fixture);row=fixture.report['cases'][0];p=Path(row['preprocessed_input_path'])
    if change=='byte':p.write_bytes(b'changed')
    if change=='mode':p.chmod(0o644)
    if change=='extra':(p.parent/'extra').write_bytes(b'x')
    if change=='symlink':p.unlink();p.symlink_to(fixture.evidence/'report.json')
    with pytest.raises((ValueError,OSError)):
        with g.BorrowedFixtures(a):pass

def test_borrowed_final_inventory_mutation_detected_and_original_retained(fixture):
    with g.BorrowedFixtures(authorized(fixture)) as held:
        extra=fixture.root/'size1-seed42'/'extra';extra.write_bytes(b'replacement sentinel')
        with pytest.raises(ValueError,match='inventory'):held.check()
    assert extra.read_bytes()==b'replacement sentinel' and held.closed

def test_same_id_different_token_case_cannot_deduplicate(fixture):
    with g.BorrowedFixtures(authorized(fixture)) as held:
        name='io/small/intermediate/client_preprocessed_input';raw=held.raw[(1,42)][name]
        rows=[json.loads(x) for x in raw.splitlines()];rows[0]['input_ids'][1]+=1
        held.raw[(1,42)][name]=''.join(json.dumps(r)+'\n' for r in rows).encode()
        with pytest.raises(ValueError,match='canonical master'):records.decode_cases(held)

def row(record,*,failed=False,exact=True):
    logits=[-1.,1.] if record.target_idx%2 else [1.,-1.]
    result=dict(target_idx=record.target_idx,native_fp32_logits=logits,native_fp64_logits=logits,independent_exact_fp64_logits=logits,
        approximate_fp64_logits=None if failed else logits,exact_reference_parity_passed=exact,approximation_complete=not failed,
        approximate_vs_official_fp32={'passed':not failed},prediction_agreement_official_fp32=not failed)
    if failed:result['failure_kind']='DomainViolation'
    return result

class FakeBackend:
    def __init__(self,failed=None,exact=True):self.count=0;self.closed=False;self.failed=failed;self.exact=exact
    def evaluate(self,record):self.count+=1;return row(record,failed=record.target_idx==self.failed,exact=self.exact)
    def close(self):self.closed=True

def test_all408_visited_even_with_approximation_domain_failure(fixture):
    with g.BorrowedFixtures(authorized(fixture)) as held:
        cases,master=records.decode_cases(held);backend=FakeBackend(failed=1000);progress=[]
        rows=evaluate_unique(master,backend,progress.append);aggregate=records.aggregates(cases,rows)
        assert backend.count==408 and len(progress)==408 and progress[-1]['approximation_failures']==1
        assert all(r['official_reference_complete'] and not r['approximation_complete'] and r['domain_failure_count']==1 for r in aggregate)
        assert all(r['approximate_accuracy']is None and r['ranked_accuracy_floor_passed']is False for r in aggregate)

@pytest.mark.parametrize('logits,expected',[([1.,1.],1),([2.,1.],0),([1.,2.],1)])
def test_original_upstream_tie(logits,expected):assert records.label(logits)==expected

@pytest.mark.parametrize('value',[[float('nan'),0.],[float('inf'),0.],[1.],[[1.,2.]]])
def test_nonfinite_wrongshape_fails_without_raw_value_message(value):
    with pytest.raises(ValueError) as error:records.label(value)
    assert 'nan' not in str(error.value).lower() and 'inf' not in str(error.value).lower()

@pytest.fixture
def mocked_run(fixture,tmp_path,monkeypatch):
    root=tmp_path/'candidate';root.mkdir();manifest=HERE/'candidate_manifest.json';shutil.copyfile(manifest,root/manifest.name)
    (root/'origins.json').write_text('{}');sources={n:root/n for n in ('candidate_manifest.json','origins.json')}
    before=c.hashes(sources);(root/'preflight-v1').mkdir();(root/'preflight-v1/report.json').write_text(json.dumps(dict(passed=True,candidate_source_hashes=before)))
    monkeypatch.setattr(c,'HERE',root);monkeypatch.setattr(c,'source_paths',lambda:sources);monkeypatch.setattr(c,'assets',lambda:dict(c.input_gate.ASSETS))
    owners=[];controls={}
    def backend():
        owner=FakeBackend(controls.get('failed'),controls.get('exact',True));owners.append(owner);return owner
    monkeypatch.setattr(c,'NativeBackend',backend)
    args=dict(output=tmp_path/'result',execute=True,fixture_evidence=fixture.evidence,fixture_report_sha256=fixture.pin)
    return NS(args=args,owners=owners,controls=controls,fixture=fixture,sources=sources)

def test_reuses_one_backend_preserves_all_private_inputs_and_modes(mocked_run):
    m=mocked_run;r=c.run(**m.args)
    assert r['passed'] and r['official_reference_complete'] and r['exact_reference_parity_passed'] and r['approximation_validation_passed']
    assert len(m.owners)==1 and m.owners[0].count==408 and m.owners[0].closed
    output=Path(r['private_workspace']);assert stat.S_IMODE(output.stat().st_mode)==0o700
    assert len(list(output.iterdir()))==11 and all(stat.S_IMODE(p.stat().st_mode)==0o600 for p in output.iterdir())
    assert r['original_fixture_unchanged'] and r['terminal_scope_completed']
    assert all('target_idx' not in x and 'label' not in x for x in r['cases'])
    shutil.rmtree(output)

def test_approximation_only_failure_retains_official_with_outer_failure(mocked_run):
    m=mocked_run;m.controls['failed']=1000;r=c.run(**m.args)
    assert not r['passed'] and r['official_reference_complete'] and r['exact_reference_parity_passed'] and not r['approximation_validation_passed']
    assert r['official_references_retained'] and all(not v['approximation_complete'] for v in r['cases'])
    shutil.rmtree(r['private_workspace'])

def test_exact_parity_failure_cannot_publish_aggregate_pass(mocked_run):
    m=mocked_run;m.controls['exact']=False;r=c.run(**m.args)
    assert not r['passed'] and not r['exact_reference_parity_passed']
    shutil.rmtree(r['private_workspace'])

def test_prerequisite_mismatch_precedes_private_model_and_evidence(mocked_run):
    m=mocked_run;m.args['fixture_report_sha256']='0'*64
    with pytest.raises(ValueError):c.run(**m.args)
    assert not m.owners and not m.args['output'].exists()

def test_private_reference_output_containment_before_creation(mocked_run):
    m=mocked_run;m.args['output']=m.fixture.root/'bad'
    with pytest.raises(ValueError,match='outside'):c.run(**m.args)
    assert not m.owners and not m.args['output'].exists()

def test_public_preflight_does_not_read_private_or_construct_model(mocked_run,monkeypatch):
    m=mocked_run;m.args['execute']=False
    monkeypatch.setattr(c.gate,'BorrowedFixtures',lambda x:(_ for _ in ()).throw(AssertionError('private read')))
    r=c.run(**m.args);assert r['passed'] and not r['actual_native_started'] and not m.owners

@pytest.mark.parametrize('failure_type',[ValueError,KeyboardInterrupt,SystemExit])
def test_primary_exception_identity_preserved_public_message_redacted(mocked_run,monkeypatch,failure_type):
    m=mocked_run;error=failure_type('PRIVATE_TOKENS_LABELS_LOGITS_MARKER')
    def fail(*a):raise error
    monkeypatch.setattr(c,'evaluate_unique',fail)
    with pytest.raises(failure_type) as caught:c.run(**m.args)
    assert caught.value is error
    raw=(m.args['output']/'report.json').read_text();r=json.loads(raw)
    assert 'PRIVATE_TOKENS_LABELS_LOGITS_MARKER' not in raw and not r['passed']
    assert m.owners[0].closed and r['cleanup_completed']
    shutil.rmtree(r['private_workspace'])

@pytest.mark.parametrize('failure_type',[OSError,KeyboardInterrupt,SystemExit])
def test_terminal_shield_failure_republishes_false(mocked_run,monkeypatch,failure_type):
    from contextlib import contextmanager
    error=failure_type('shield exit');m=mocked_run
    @contextmanager
    def shield():
        yield
        raise error
    monkeypatch.setattr(c,'cleanup_signals',shield)
    with pytest.raises(failure_type) as caught:c.run(**m.args)
    assert caught.value is error
    r=json.loads((m.args['output']/'report.json').read_text())
    assert not r['passed'] and not r['terminal_scope_completed'] and not r['cleanup_completed']
    shutil.rmtree(r['private_workspace'])

@pytest.mark.parametrize('which',['source','asset','prerequisite'])
def test_late_binding_drift_invalidates_every_acceptance_flag(mocked_run,monkeypatch,which):
    m=mocked_run;original=c.evaluate_unique
    def evaluate(*args):
        result=original(*args)
        if which=='source':(c.HERE/'origins.json').write_text('{"changed":true}')
        if which=='asset':monkeypatch.setattr(c,'assets',lambda:{})
        if which=='prerequisite':(m.fixture.evidence/'report.json').write_text('{}')
        return result
    monkeypatch.setattr(c,'evaluate_unique',evaluate)
    try:r=c.run(**m.args)
    except ValueError:r=json.loads((m.args['output']/'report.json').read_text())
    assert not r['passed'] and not any(r[n] for n in ('official_reference_complete','exact_reference_parity_passed','approximation_validation_passed'))
    shutil.rmtree(r['private_workspace'])

def test_initial_publication_failure_recovers_redacted_report(mocked_run,monkeypatch):
    m=mocked_run;write=c.write;count=[]
    def faulty(path,value):
        count.append(1)
        if len(count)==1:raise OSError('PRIVATE_MARKER')
        write(path,value)
    monkeypatch.setattr(c,'write',faulty)
    with pytest.raises(OSError):c.run(**m.args)
    raw=(m.args['output']/'report.json').read_text()
    assert 'PRIVATE_MARKER' not in raw and not json.loads(raw)['passed'] and not m.owners


def test_private_output_replacement_is_retained_and_acceptance_fails(mocked_run,monkeypatch):
    m=mocked_run;save=c.save_references;replacement=[]
    def swapped(root,fd,identity,*args):
        inventory=save(root,fd,identity,*args)
        old=root.with_name(root.name+'-original');root.rename(old);root.mkdir(mode=0o700)
        (root/'sentinel').write_text('replacement');replacement.extend((root,old));return inventory
    monkeypatch.setattr(c,'save_references',swapped)
    with pytest.raises(RuntimeError):c.run(**m.args)
    r=json.loads((m.args['output']/'report.json').read_text())
    assert not r['passed'] and not r['private_workspace_retained'] and (replacement[0]/'sentinel').read_text()=='replacement'
    for p in replacement:shutil.rmtree(p)


def test_existing_reference_and_current_lifecycle_bytes_are_exact():
    import hashlib
    origin=json.loads((HERE/'origins.json').read_text())
    for name,row in origin.items():assert hashlib.sha256((HERE/name).read_bytes()).hexdigest()==row['sha256']
    assert origin['full_model_reference.py']['sha256']=='a32b51c0e0e1f436891fa087eeb2c8756c1115777a2a57d4f3605262cefc0d51'
    assert origin['cleanup.py']['sha256']=='1798455cdd88d4bbac5e1769e6b3226676ccb9901e7be6faf383e7ad063c1ef6'
    assert origin['terminal.py']['sha256']=='dc985d38746751099511b816bbac925b15ad31a8db6caffaebeb8e9b53a9464e'
