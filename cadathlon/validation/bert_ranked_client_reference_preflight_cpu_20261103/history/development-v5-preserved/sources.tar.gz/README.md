# Ranked BERT client-reference preparation candidate

This isolated candidate prepares private references for the nine original
ranked cases (100/200/408 records, seeds 42/43/44). It has not run native
inference. The preflight uses synthetic private records, mocked native objects,
real installed imports with model/asset entrypoints denied, and public producer
proofs. It performs no HE, key access, ciphertext operation, or calibration.

The externally pinned tokenizer-only producer report is authenticated before
any output creation. Its exact 27 source files, archive, asset bindings, all
nine ordered cases, and retained workspace identity must agree. Execution then
authenticates all 54 original private files through held directories and
bounded reads, compares each opened inode to its original identity, validates
records/order/labels, and verifies that every case is a subset of the same
ordered 408-record master. Originals are borrowed read-only. An uncertain close
is quarantined and never retried by descriptor number.

Only after those gates would execution construct one official FP32/default
SDPA model, one FP64/eager diagnostic model, one client embedding owner, and
one immutable collection of the 196 pinned encoder/head weights. Each of the
408 unique examples is evaluated once, with its original full 128-token native
mask. The independent NumPy graph receives only original-position compacted
embeddings. All 12 attention/block outputs, pooler and logits are compared to
native FP64 at the unchanged 1e-12 absolute gate; embedding parity uses zero.
The frozen approximation and its coefficient bytes are unchanged. Domain
failures are retained per example, never clipped or used to choose new rules.
Official numeric gates are abs(error) <= .02 + .01*abs(FP32 reference), with
class 1 on an exact tie. Ranked accuracy gates remain >=75% and <=2 percentage
points below native. The outer result requires exact and approximation gates,
plus complete provenance and cleanup; it cannot conceal a diagnostic failure.

Master and nine case references, IDs, labels, logits and detailed diagnostics
are private 0600 files in a new 0700 workspace, with a manifest written last.
A complete official reference may remain available if approximation validation
fails, but consumers must require the explicit official-reference provenance,
asset, original-fixture, cleanup and terminal flags. Raw references and model
arrays must never enter the public validation archive. Model reuse and unique
record reuse are reference-production choices, not a benchmark timing claim.

The original independent helpers and current cleanup/terminal helpers are
copied byte-for-byte and pinned by origins.json. Historical collector bodies
are retained solely for provenance and are never invoked. The source archive
includes candidate Python/JSON/document files and selected installed Python
implementations; binary libraries are identified by package versions, not
represented as exhaustively archived source.

Actual native execution requires the successful matching preflight-v1 report
and a separate root grant. The eventual command is:

    env OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 taskset -c 120-123 /tmp/cross-pretrained-validation-env/bin/python ranked_collect.py --execute --output actual-v1

No actual run is authorized by the presence of this command.
