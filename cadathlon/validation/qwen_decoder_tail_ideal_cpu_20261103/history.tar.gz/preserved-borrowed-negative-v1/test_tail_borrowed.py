"""Borrowed caller annotations are preserved; owned results stay stripped."""
import numpy as np
import pytest
from tail_ideal import build,pack,synthetic_inputs
import encrypted_qwen_decoder_tail as runtime

@pytest.fixture(autouse=True)
def clear_fake_quarantine():
    runtime._QUARANTINE.clear();yield;runtime._QUARANTINE.clear()

@pytest.mark.parametrize('failure',[False,True])
def test_supplied_attention_annotations_survive(monkeypatch,failure):
    def progress(label,value,metadata):
        if failure and label=='tile0.o.linear':raise RuntimeError('chosen body failure')
        value._public_interval=(-1.,1.)
    o,a,r,w,g=build(monkeypatch,progress=progress);source,attended=synthetic_inputs(0,(0,));inputs,attention=pack(source,attended,(0,),0)
    original=inputs[0];borrowed=attention.outputs[0]
    original._public_abs_bound=7.;borrowed._public_abs_bound=9.;borrowed._public_interval=(-9.,9.)
    if failure:
        with pytest.raises(RuntimeError,match='chosen body failure'):o.evaluate(attention,inputs)
    else:
        result=o.evaluate(attention,inputs)
        assert not any(name.startswith('_public_') for name in vars(result.outputs[0]))
    assert original._public_abs_bound==7.
    assert borrowed._public_abs_bound==9. and borrowed._public_interval==(-9.,9.)
