"""Isolated array-returning view of the existing private encoder arithmetic."""
from jaxite_word import ckks_ctx


def encode_array(slots, cycl_order, q_towers, p_towers, scale,
                 noise_scale_degree=1, max_bits_in_word=61,
                 max_bits_value=(1 << 63) - (1 << 9) - 1):
    degree = cycl_order // 2
    lite = ckks_ctx._get_or_make_encode_ctx(
        q_towers, degree, scale, max_bits_in_word, max_bits_value)
    return ckks_ctx._fast_encode(
        slots, lite, scale=scale, noise_scale_degree=noise_scale_degree,
        allow_complex=True, slot_count=len(slots))
