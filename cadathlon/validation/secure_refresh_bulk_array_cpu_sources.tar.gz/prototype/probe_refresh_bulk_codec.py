import sys,time,json,hashlib
from pathlib import Path
sys.path[:0]=['/tmp','/home/jianming_gatech/CROSS','/home/jianming_gatech/CROSS/cadathlon/common']
import numpy as np,jax
from jaxite_word import ckks_ctx
from jaxite_word.composite_prime_gen import composite_prime_gen
from encrypted_refresh import RefreshProfile
from refresh_bulk_codec import encode_array
jax.config.update('jax_enable_x64',True)
assert jax.default_backend()=='cpu'
files=[Path('/tmp/refresh_bulk_codec.py'),Path('/tmp/probe_refresh_bulk_codec.py'),Path(ckks_ctx.__file__)]
source_hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
start=time.perf_counter();N=16384;q=composite_prime_gen(2,14,61,44,2*N,31);S=float(q[-2])*q[-1]
cases=0
for nq in (4,8,14):
 for slots in (1,64,N//2):
  for scale in (S,S*S):
   for kind in ('real_scalar','complex_vector'):
    vector=([complex(-.3125)]*slots if kind=='real_scalar' else
        list(.3*np.cos(np.arange(slots)*.29)+.2j*np.sin(np.arange(slots)*.17)))
    kwargs=dict(slots=vector,cycl_order=2*N,q_towers=q[:nq],p_towers=[],scale=scale)
    old=ckks_ctx._ckks_encode(**kwargs);new=encode_array(**kwargs)
    np.testing.assert_array_equal(new,np.asarray(old,dtype=np.uint64))
    assert new.shape==(N,nq) and new.dtype==np.uint64
    old_jax=jax.numpy.array(old,dtype=jax.numpy.uint64).reshape(128,128,nq).astype(jax.numpy.uint32)
    new_jax=jax.numpy.asarray(new,dtype=jax.numpy.uint64).reshape(128,128,nq).astype(jax.numpy.uint32)
    np.testing.assert_array_equal(old_jax,new_jax);cases+=1
for slots in (1,64):
 for scale in (S,2.**112):
  kwargs=dict(slots=[complex(-.75)]*slots,cycl_order=2*N,q_towers=q,p_towers=[],scale=scale,noise_scale_degree=2,max_bits_in_word=31)
  np.testing.assert_array_equal(encode_array(**kwargs),np.asarray(ckks_ctx._ckks_encode(**kwargs),dtype=np.uint64));cases+=1
for slots in ([],[1j]*3,[1j]*(N//2+1)):
 for function in (encode_array,ckks_ctx._ckks_encode):
  try:function(slots,2*N,q,[],S)
  except ValueError:pass
  else:raise AssertionError('invalid sparse slot count accepted')
# Real deep-profile dimensions, without keys or a CKKS execution context.
params=RefreshProfile(131072,49,56,61,4).parameters();q=params['q_towers'];N=131072
vector=list(.3*np.cos(np.arange(128)*.29)+.2j*np.sin(np.arange(128)*.17))
kwargs=dict(slots=vector,cycl_order=2*N,q_towers=q,p_towers=[],scale=params['scaling_factor'])
old=ckks_ctx._ckks_encode(**kwargs);new=encode_array(**kwargs)
np.testing.assert_array_equal(new,np.asarray(old,dtype=np.uint64));cases+=1
begin=time.perf_counter();old_jax=jax.numpy.array(old,dtype=jax.numpy.uint64).reshape(256,512,len(q)).astype(jax.numpy.uint32);old_jax.block_until_ready();old_time=time.perf_counter()-begin
begin=time.perf_counter();new_jax=jax.numpy.asarray(new,dtype=jax.numpy.uint64).reshape(256,512,len(q)).astype(jax.numpy.uint32);new_jax.block_until_ready();new_time=time.perf_counter()-begin
np.testing.assert_array_equal(old_jax,new_jax)
assert source_hashes=={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
r=dict(passed=True,backend='cpu',scope='Exact private encoder residue and array-transfer parity; no encrypted bootstrap or TPU runtime claim',cases=cases,invalid_slot_counts_rejected=[0,3,8193],large_profile=dict(degree=N,num_q=len(q),num_p=len(params['p_towers']),slots=128),conversion_only_seconds=dict(nested_list_to_jax=old_time,ndarray_to_jax=new_time),total_seconds=time.perf_counter()-start,source_hashes_unchanged=True,source_hashes=source_hashes)
Path('/tmp/refresh-bulk-codec-proof.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r),flush=True)
