"""Source-bound combined public construction proof; no genuine worker launch."""
from pathlib import Path
import argparse,hashlib,json,os,sys,tarfile,time
import xml.etree.ElementTree as ET
from cleanup import termination_signals,cleanup_signals
import combined_source_guard as guard
from combined_processes import OwnedChild

HERE=Path(__file__).resolve().parent
EXTRA=('preflight_combined.py','README_COMBINED.md','combined_processes.py','test_preflight_combined.py')
GROUPS=(
 ('engine',('test_full_model_engine.py','test_cleanup_regressions.py','test_mask_capture.py','test_signal_installation.py'),37),
 ('prepared',('test_engine_prepared.py','test_linear_factory.py','test_plan.py','-k','not test_parity_closure_is_unchanged_except_explicit_two_seams'),48),
 ('native-wrapper',('test_native_signal_wrapper.py',),9),
 ('combined',('test_combined_owners.py','test_combined_handler.py'),26),
 ('collector',('test_preflight_combined.py',),13),
)

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n')
def run(output,*,source_guard_tests,_owned_identity=None):
    if type(source_guard_tests)is not int or source_guard_tests<1:raise ValueError('exact positive expected source guard count required')
    output=Path(output).resolve()
    if _owned_identity is None:output.mkdir(exist_ok=False)
    elif (output.stat().st_dev,output.stat().st_ino)!=_owned_identity:raise ValueError('owned evidence directory changed')
    started=time.monotonic()
    hashes={}
    report=dict(scope='Public/synthetic combined handler/owner/import construction; no HE, model or genuine launch',
        passed=False,body_passed=False,complete=False,termination_scope_completed=False,pid=os.getpid(),actual_HE=False,groups=[],started_children=[],
        source_guard_tests_expected=source_guard_tests,
        historical_parent_only_source_test_excluded='test_plan.py::test_parity_closure_is_unchanged_except_explicit_two_seams',
        combined_source_replacement='test_combined_source_guard.py: explicit251+fourBSGS+newsource closure')
    try:
        hashes=guard.capture_sources(HERE,extra_files=EXTRA)
        report.update(source_hashes_before=hashes,source_count=len(hashes))
        write(output/'report.json',report)
        report['initial_source_guard']=guard.check_sources(hashes,HERE,extra_files=EXTRA)
        with tarfile.open(output/'sources.tar.gz','w:gz')as tar:
            for name in sorted(hashes):tar.add(HERE/name,arcname=name)
        report['source_archive_sha256']=digest(output/'sources.tar.gz')
        with tarfile.open(output/'sources.tar.gz','r:gz')as tar:
            members=tar.getmembers()
            if any(not m.isfile()for m in members)or len({m.name for m in members})!=len(members):raise ValueError('unique ordinary archived sources required')
            archived={m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest()for m in members}
        report['source_archive_verified']=archived==hashes
        if archived!=hashes:raise ValueError('archive bytes differ from prelaunch source closure')
        for name,tests,count in (*GROUPS,('source-guard',('test_combined_source_guard.py',),source_guard_tests)):
            env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',
                OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',JAX_PLATFORMS='cpu',SIGNAL_EVIDENCE_DIR=str(output/'signal-cases'))
            with (output/(name+'.log')).open('w')as log:
                command=[sys.executable,'-m','pytest','--rootdir='+str(HERE),'--confcutdir='+str(HERE),'-q','--tb=short',*tests,'--junitxml='+str(output/(name+'.xml'))]
                child=OwnedChild(command,cwd=HERE,env=env,stdout=log)
                try:
                    record=dict(name=name,process=child.record,command=command)
                    report['started_children'].append(record);write(output/'report.json',report)
                    code=child.wait()
                finally:child.close(primary=sys.exception())
            tree=ET.parse(output/(name+'.xml'));cases=list(tree.iter('testcase'))
            bad=sum(len(c.findall(t))for c in cases for t in ('error','failure','skipped'))
            process=record['process']
            passed=code==0 and len(cases)==count and bad==0 and process['direct_child_reaped']and process['group_empty_verified']and process['cleanup_completed']and not process['cleanup_errors']
            report['groups'].append(dict(name=name,tests=len(cases),expected=count,bad=bad,passed=passed))
            write(output/'report.json',report)
            if not passed:raise ValueError('combined public proof group failed: '+name)
        report['body_passed']=True;report['complete']=True
    except BaseException as error:
        report['error']=dict(type=type(error).__name__,message=str(error));raise
    finally:
        active=sys.exception()
        try:
            report['all_started_children_reaped']=all(x['process']['direct_child_reaped']and x['process']['group_empty_verified']and x['process']['cleanup_completed']and not x['process']['cleanup_errors']for x in report['started_children'])
            report['source_hashes_after']=guard.capture_sources(HERE,extra_files=EXTRA)
            report['source_files_unchanged']=report['source_hashes_after']==hashes
            report['final_source_guard']=guard.check_sources(hashes,HERE,extra_files=EXTRA)
            report['source_archive_unchanged']=(output/'sources.tar.gz').is_file()and digest(output/'sources.tar.gz')==report.get('source_archive_sha256')
            report['body_passed']=report['body_passed']and bool(hashes)and report['source_files_unchanged']and report['source_archive_unchanged']and report['all_started_children_reaped']
            report['elapsed_seconds']=time.monotonic()-started
            write(output/'report.json',report)
        except BaseException as failure:
            report['passed']=False;report['body_passed']=False;report['final_evidence_failure']=dict(type=type(failure).__name__,message=str(failure))
            chosen=active if active is not None else failure
            if active is not None and failure is not active:active.add_note('combined final evidence: '+repr(failure))
            try:write(output/'report.json',report)
            except BaseException as publication:
                if publication is not chosen:chosen.add_note('combined failed republication: '+repr(publication))
            if active is None:raise chosen
    return report


def execute(output,*,source_guard_tests,termination=termination_signals,shield=cleanup_signals):
    """Only publish success after outer termination-handler restoration."""
    output=Path(output).resolve()
    # Refuse an existing destination before acquiring report ownership or
    # entering failure republication. An old result must never be overwritten.
    output.mkdir(exist_ok=False);info=output.stat();identity=(info.st_dev,info.st_ino)
    path=output/'report.json';report=None
    try:
        with termination():report=run(output,source_guard_tests=source_guard_tests,_owned_identity=identity)
        report['termination_scope_completed']=True
        report['passed']=report['body_passed']and report['complete']
        write(path,report)
        return report
    except BaseException as primary:
        try:
            info=output.lstat()
            if output.is_symlink()or (info.st_dev,info.st_ino)!=identity:raise ValueError('evidence directory replaced')
        except BaseException as ownership:
            primary.add_note('terminal report ownership unavailable: '+repr(ownership))
            raise primary
        if type(report)is not dict:
            try:
                report=json.loads(path.read_bytes())
                if type(report)is not dict:report={}
            except BaseException:report={}
        report.update(passed=False,termination_scope_completed=False,
            terminal_error=dict(type=type(primary).__name__,message=str(primary)))
        try:
            with shield():write(path,report)
        except BaseException as publication:
            if publication is not primary:primary.add_note('combined terminal republication: '+repr(publication))
        raise

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('output');p.add_argument('--source-guard-tests',required=True,type=int);a=p.parse_args()
    r=execute(a.output,source_guard_tests=a.source_guard_tests)
    print(json.dumps({k:r[k]for k in ('passed','complete','source_count','groups','elapsed_seconds')}))
    raise SystemExit(0 if r['passed']else 1)
