"""Prepared registration plus real BSGS/linear owners; ideal public primitives.

No key/context/backend/model construction. Actual compiled rotate/clear and
polynomial level/checkpoint methods run against explicitly synthetic helpers.
"""
from pathlib import Path
from types import SimpleNamespace as NS, ModuleType
import ast, gc, math, sys, weakref
import numpy as np
import pytest

HERE=Path(__file__).parent
sys.path.insert(0,str(HERE/'joined'))
import combined_bsgs_fixture as fixture
from combined_bsgs_fixture import doubles, Value, Q, DELTA
import encrypted_bsgs_score_routing as routing
import encrypted_bert_bsgs_attention as attention
import engine_prepared_owners as control_module
import loader_prepared_rotation as loader_module
import full_model_engine as engine
from encrypted_chained_streaming_linear import ChainedStreamingLinear
from encrypted_streaming_linear import RowTileLayout


@pytest.fixture
def rig(monkeypatch,doubles):
    events=[];ctx=fixture.Arithmetic().ctx
    ctx.parameters['secret_key']=None
    for k in attention.BertBSGSAttentionTile.required_rotation_indices():
        ctx._param_cache.raw_rotation_keys.setdefault(k,{n:NS(shape=(8,114,131072),dtype=np.dtype('uint32'))for n in ('a','b')})
        ctx._param_cache.coef_maps.setdefault(k,NS(shape=(131072,),dtype=np.dtype('int32')))
    class Helper(fixture.Helper):
        def clear(self,**kw):events.append(('helper-clear',id(self)))
    class Rotation(Helper):
        def __init__(self,context):
            super().__init__(context);self._lease=lease;self._max_entries=2;self._max_bytes=2<<30
            self._failed=None;self.entries=[];self.closed=False
        def clear(self,*,executables=False):
            events.append(('rotation-clear',id(self),executables))
            if self._failed is not None:raise self._failed
            self.entries.clear()
        def close(self):self.clear(executables=True);self.closed=True
        def rotate(self,value,shift):
            return Value(np.roll(value.polynomial.data,-shift),value.level,value._ckks_scale)
    class Base(fixture.Arithmetic):
        def __init__(self,context,**kw):
            self.ctx=context;self.low_memory=kw['low_memory'];self._active_level=None;self.calls=[]
            self._plaintext_multiply=Helper(context);self._rescale=Helper(context);self._multiplication_compiler=None
        def _clear_working_caches(self):events.append(('base-clear',id(self)))
        def multiply(self,left,right):
            level=min(left.level,right.level)
            return Value(left.polynomial.data*right.polynomial.data,level-1,left._ckks_scale*right._ckks_scale/math.prod(Q[2*level:2*level+2]))
    common=HERE/'joined/checkout/cadathlon/common'
    tree=ast.parse((common/'encrypted_polynomial.py').read_bytes())
    base=next(x for x in tree.body if isinstance(x,ast.ClassDef)and x.name=='EncryptedPolynomialEvaluator')
    namespace={}
    exec(compile(ast.Module(body=[x for x in base.body if isinstance(x,ast.FunctionDef)and x.name in ('_prepare','checkpoint')],type_ignores=[]),'actual-level-checkpoint','exec'),namespace)
    for name in ('_prepare','checkpoint'):setattr(Base,name,namespace[name])
    tree=ast.parse((common/'encrypted_packed_qwen.py').read_bytes())
    cls=next(x for x in tree.body if isinstance(x,ast.ClassDef)and x.name=='CompiledArithmetic')
    namespace=dict(EncryptedPolynomialEvaluator=Base,CompiledRotation=Rotation)
    exec(compile(ast.Module(body=[cls],type_ignores=[]),'actual-compiled-arithmetic','exec'),namespace)
    Arithmetic=namespace['CompiledArithmetic']
    lease=NS(_check=lambda:events.append('lease-check'),retire=lambda:events.append('lease-retired'))
    session=object.__new__(loader_module.PreparedLoaderSession)
    session._context=ctx;session._active=True;session._failure=None;session._registered=[];session.cleanup_completed=False
    session._arrays={'sentinel':object()};session._maps={};session._states={};session._owner=object()
    session.lease=lease;session._lease_bound=lease
    def factory(context,**kw):
        assert kw==dict(source_lease=lease,max_entries=2,max_bytes=2<<30,low_memory=True,preserve_dispatch_cache=True)
        return Arithmetic(context,low_memory=True,preserve_dispatch_cache=True)
    module=ModuleType('prepared_rotation');module.create_prepared_arithmetic=factory
    monkeypatch.setitem(sys.modules,'prepared_rotation',module)
    monkeypatch.setitem(sys.modules,'encrypted_packed_qwen',NS(CompiledArithmetic=Arithmetic))
    monkeypatch.setattr(control_module,'_types',lambda:(loader_module.PreparedLoaderSession,Arithmetic,Rotation))
    handle=NS(ctx=ctx,prepared_arithmetic=session.create)
    class Refresh:
        def __init__(self,context,**kw):
            assert context is ctx and 'arithmetic_factory'not in kw
            self.evaluator=Arithmetic(context,low_memory=True,preserve_dispatch_cache=True)
            self.compiled_primitives=tuple(Helper(context)for _ in range(5))
    provider=NS(close=lambda:events.append('provider-close'))
    monkeypatch.setattr(engine,'_dependencies',lambda:(lambda c:provider,Arithmetic,ChainedStreamingLinear,RowTileLayout,Refresh,object,lambda *a:None))
    assert not attention._QUARANTINE
    yield NS(ctx=ctx,events=events,session=session,handle=handle,Rotation=Rotation)
    # These are synthetic fixtures only; actual quarantines require process exit.
    attention._QUARANTINE.clear()


def open_engine(rig):return engine.server_engine(rig.ctx,manifest_bytes=b'public synthetic candidate',prepared_handle=rig.handle)


@pytest.mark.parametrize('level',(49,25))
def test_registered_graph_and_linear_capture_before_first_bsgs_operation(rig,level):
    with open_engine(rig)as graph:
        a=graph.arithmetic;b=graph.linear.arithmetic
        assert len(rig.session._registered)==2 and a is not b
        assert type(graph.linear)is ChainedStreamingLinear
        assert graph.refresher.evaluator not in (a,b)
        owner=attention.BertBSGSAttentionTile(a);originals=(a.rotation,b.rotation)
        assert owner._guard_owner._helpers[0]is originals[0]
        for arithmetic in (a,b):
            arithmetic.rotation.entries.append(object());arithmetic._prepare(level)
            assert not arithmetic.rotation.entries
            arithmetic.rotation.entries.append(object());arithmetic._prepare(level)
            assert arithmetic.rotation.entries
            arithmetic._prepare(level-1);assert not arithmetic.rotation.entries
            arithmetic.rotation.entries.append(object());token=object()
            assert arithmetic.checkpoint(token,'synthetic phase')is token
            assert not arithmetic.rotation.entries and arithmetic._active_level is None
        assert (a.rotation,b.rotation)==originals
        owner._guard();graph._check_prepared()
        data=np.arange(65536,dtype=np.float64)/65536
        route=routing.BSGSScoreRouting(a,routing.FactoredScoreLayout(3,7))
        out=route.forward(Value(data,level,DELTA),gain=.125)
        np.testing.assert_array_equal(out.polynomial.data,fixture.scatter(data,3,7,False,.125))
        assert out.level==level-2
        owner._guard();graph._check_prepared()
    assert all(x.closed for x in originals)and rig.events[-1]=='provider-close'
    assert rig.session._active and 'lease-retired'not in rig.events
    rig.session.close();assert rig.events[-1]=='lease-retired'and rig.session.cleanup_completed


@pytest.mark.parametrize('field',('rotation','_plaintext_multiply','_rescale','multiply'))
def test_bsgs_captured_helper_or_accessor_replacement_rejected_before_work(rig,field):
    with open_engine(rig)as graph:
        owner=attention.BertBSGSAttentionTile(graph.arithmetic)
        original=getattr(graph.arithmetic,field)
        setattr(graph.arithmetic,field,(lambda *a:None)if field=='multiply'else fixture.Helper(rig.ctx))
        with pytest.raises(ValueError):owner._guard()
        assert not graph.arithmetic.calls
        setattr(graph.arithmetic,field,original)
    rig.session.close()


@pytest.mark.parametrize('kind',(OSError,KeyboardInterrupt,SystemExit))
def test_original_prepared_readiness_failure_retained_until_loader_retirement(rig,kind):
    primary=kind('synthetic uncertain readiness')
    with pytest.raises(kind)as caught:
        with open_engine(rig)as graph:
            original=graph.arithmetic.rotation;other=graph.linear.arithmetic.rotation
            original._failed=primary
            graph.arithmetic.rotation=rig.Rotation(rig.ctx)
            graph.prepared_owners.owners.clear()
    assert caught.value is primary and other.closed
    assert rig.events[-1]=='provider-close'and 'lease-retired'not in rig.events
    with pytest.raises(kind)as caught:rig.session.close()
    assert caught.value is primary and rig.session._arrays and not rig.session.cleanup_completed
    assert any(x.rotation is original for x in rig.session._registered)
    assert 'lease-retired'not in rig.events


@pytest.mark.parametrize('operation',('scores','values'))
def test_bsgs_callback_keeps_original_payload_and_failure_identity(rig,operation):
    primary=KeyboardInterrupt('synthetic cancellation after payload replacement')
    with open_engine(rig)as graph:
        value=Value(np.zeros(65536),25,DELTA);old=weakref.ref(value.polynomial)
        def callback(*args):
            value.polynomial=Value(np.ones(65536),25,DELTA).polynomial
            gc.collect();assert old()is not None
            raise primary
        owner=attention.BertBSGSAttentionTile(graph.arithmetic,progress=callback)
        tiles=tuple(Value(np.zeros(65536),25,DELTA)for _ in range(8))
        with pytest.raises(KeyboardInterrupt)as caught:
            (owner.scores if operation=='scores'else owner.mix_values)(value,tiles)
        assert caught.value is primary and not owner._active
        assert attention._QUARANTINE[-1][-1]is primary
        gc.collect();assert old()is not None
        with pytest.raises(RuntimeError):owner._guard()
    rig.session.close();gc.collect();assert old()is not None
