"""Collector rejection/cleanup tests with synthetic child and source records."""
from pathlib import Path
import hashlib,json
from types import SimpleNamespace as NS
from contextlib import contextmanager,nullcontext
import pytest
import preflight_combined as collector


@pytest.mark.parametrize('fault',('none','nonzero','count','failure','skipped','source','cancellation'))
def test_false_success_rejected_and_started_child_closed(tmp_path,monkeypatch,fault):
    source=tmp_path/'public.py';source.write_text('PUBLIC=1\n')
    children=[];primary=KeyboardInterrupt('synthetic child cancellation')
    def capture(*args,**kwargs):return {'public.py':hashlib.sha256(source.read_bytes()).hexdigest()}
    def check(expected,*args,**kwargs):
        if capture()!=expected:raise ValueError('source changed')
        return dict(passed=True)
    class Child:
        def __init__(self,command,**kwargs):
            self.command=command;self.closed=False;self.primary=None
            self.record=dict(pid=100+len(children),direct_child_reaped=False,group_empty_verified=False,cleanup_completed=False,cleanup_errors=[])
            self.xml=Path(next(x.split('=',1)[1]for x in command if x.startswith('--junitxml=')))
            children.append(self)
        def wait(self):
            if fault=='cancellation':raise primary
            node='<testcase name="synthetic">'+({'failure':'<failure/>','skipped':'<skipped/>'}.get(fault,''))+'</testcase>'
            self.xml.write_text('<testsuites><testsuite>'+node*(2 if fault=='count'else 1)+'</testsuite></testsuites>')
            self.record.update(direct_child_reaped=True,group_empty_verified=True,cleanup_completed=True)
            if fault=='source':source.write_text('PUBLIC=2\n')
            return 2 if fault=='nonzero'else 0
        def close(self,primary=None):
            self.closed=True;self.primary=primary
            self.record.update(direct_child_reaped=True,group_empty_verified=True,cleanup_completed=True)
    monkeypatch.setattr(collector,'HERE',tmp_path)
    monkeypatch.setattr(collector,'GROUPS',(('only',('synthetic.py',),1),))
    monkeypatch.setattr(collector,'OwnedChild',Child)
    monkeypatch.setattr(collector,'guard',NS(capture_sources=capture,check_sources=check))
    out=tmp_path/'evidence'
    if fault=='none':
        result=collector.execute(out,source_guard_tests=1,termination=nullcontext,shield=nullcontext)
        assert result['passed']and result['complete']and len(children)==2
    elif fault=='cancellation':
        with pytest.raises(KeyboardInterrupt)as caught:collector.run(out,source_guard_tests=1)
        assert caught.value is primary and children[0].primary is primary
    else:
        with pytest.raises(ValueError):collector.run(out,source_guard_tests=1)
    report=json.loads((out/'report.json').read_bytes())
    assert report['passed']is (fault=='none')
    assert report['all_started_children_reaped']and all(c.closed for c in children)
    if fault in ('nonzero','count','failure','skipped','cancellation'):assert len(children)==1
    if fault=='source':assert report['source_files_unchanged']is False and 'final_evidence_failure'in report


@pytest.mark.parametrize('kind',(KeyboardInterrupt,SystemExit))
def test_failed_initial_and_final_publication_preserves_original_cancellation(tmp_path,monkeypatch,kind):
    primary=kind('initial source cancellation');secondary=OSError('publication unavailable')
    def fail(*a,**kw):raise primary
    def write(*a,**kw):raise secondary
    monkeypatch.setattr(collector,'guard',NS(capture_sources=fail))
    monkeypatch.setattr(collector,'write',write)
    with pytest.raises(kind)as caught:collector.execute(tmp_path/'out',source_guard_tests=1,termination=nullcontext,shield=nullcontext)
    assert caught.value is primary and any('republication'in n for n in primary.__notes__)


@pytest.mark.parametrize('kind',(OSError,KeyboardInterrupt))
def test_outer_scope_failure_never_publishes_success(tmp_path,monkeypatch,kind):
    primary=kind('synthetic signal restoration failure');out=tmp_path/'out';path=out/'report.json'
    def body(*a,**kw):
        r=dict(passed=False,body_passed=True,complete=True,termination_scope_completed=False)
        collector.write(path,r);return r
    @contextmanager
    def termination():
        yield
        raise primary
    monkeypatch.setattr(collector,'run',body)
    with pytest.raises(kind)as caught:collector.execute(out,source_guard_tests=1,termination=termination,shield=nullcontext)
    assert caught.value is primary
    r=json.loads(path.read_bytes());assert r['passed']is False and r['termination_scope_completed']is False


def test_success_not_published_inside_outer_signal_scope(tmp_path,monkeypatch):
    out=tmp_path/'out';path=out/'report.json'
    def body(*a,**kw):
        r=dict(passed=False,body_passed=True,complete=True,termination_scope_completed=False)
        collector.write(path,r);return r
    @contextmanager
    def termination():
        yield
        assert json.loads(path.read_bytes())['passed']is False
    monkeypatch.setattr(collector,'run',body)
    r=collector.execute(out,source_guard_tests=1,termination=termination,shield=nullcontext)
    assert r['passed']and r['termination_scope_completed']


def test_existing_evidence_is_never_overwritten_by_failure_republication(tmp_path):
    path=tmp_path/'report.json';raw=b'previous evidence, not owned by this call\n';path.write_bytes(raw)
    with pytest.raises(FileExistsError):collector.execute(tmp_path,source_guard_tests=1,termination=nullcontext,shield=nullcontext)
    assert path.read_bytes()==raw
