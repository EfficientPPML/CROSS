"""Static source closure for the isolated prepared/BSGS handler successor.

This module imports no runtime/backend. Its externally pinned expected mapping
must come from the reviewed execution snapshot, never from an untrusted worker.
Call require_unloaded=True in the fresh worker before importing graph modules,
then check loaded origins again before payload work and on completion. File
hashes alone cannot authenticate code already executed before that fresh gate.
No parent proof is converted into a combined encrypted or numerical pass.
"""
from pathlib import Path
import ast
import hashlib
import importlib.machinery
import json
import stat
import sys

HERE=Path(__file__).resolve().parent
PARENT_MANIFEST_SHA256='2955b897789cfe2e21bce7d6876323d22b5b79ae884b0719b6f20fc08df84fcc'
PREPARED_ARCHIVE='79596ebfc9929294d4b0eb5d2daf72d2a0b0e74aa9080f527374035bf30899bd'
BSGS_ARCHIVE='c7b79e973d0e0688070c29c68557321c29fdadb6e13b18418ac03ddbae341b55'
BSGS={
 'joined/encrypted_bert_bsgs_attention.py':'0f21b3f4c1793a1e543989ddfcbbc68db939bfb38428328ce675406e4e8e5034',
 'joined/encrypted_bert_full_model.py':'db348dbc9a749c723df3687e5e64fd5b8f9737c615bdb13e49d48034ac910ae6',
 'joined/encrypted_bert_layer_attention.py':'2ca712f4d1e72c44b70045219485565ec7dee557607d6a121af74ad71aae801c',
 'joined/encrypted_bsgs_score_routing.py':'f7d9492c5ca959bb09c7c7dfe2b4062ce33b2c64678558df261b1ed92ddd8fde'}
KNOWN_NEW=('combined_parent_sources.json','baseline/file_stages.py','test_combined_handler.py',
 'combined_source_guard.py','test_combined_source_guard.py','combined_bsgs_fixture.py',
 'p60_profile_and_refresh.json','test_combined_owners.py')
NEW_PINS={'combined_bsgs_fixture.py':'4d65f3419f564466c93babbb9d39e931467b82c2c140fab887173b29ac4c9a9f',
 'p60_profile_and_refresh.json':'fe2408637f9d6de19ac6aef9f6f749aaef9dd56ccbb37b5334293cd223ede035'}
CRITICAL={
 **{n:'runtime/stage/'+n+'.py'for n in ('file_stages','full_model_engine','key_contexts',
     'loader_prepared_rotation','engine_prepared_owners','prepared_rotation','client_keys','support','server_public_model')},
 **{n:'joined/'+n+'.py'for n in ('encrypted_bert_full_model','encrypted_bert_layer_attention',
     'encrypted_bert_bsgs_attention','encrypted_bsgs_score_routing','layer_attention_contract')},
 **{n:'joined/checkout/cadathlon/common/'+n+'.py'for n in ('encrypted_streaming_linear',
     'encrypted_chained_streaming_linear','encrypted_packed_qwen','encrypted_rotation','encrypted_primitives',
     'encrypted_compilation','encrypted_ntt','encrypted_refresh','encrypted_scale_planning',
     'encrypted_fullslot_refresh_binding','encrypted_score_reduction','encrypted_factored_score_routing',
     'encrypted_shallow_score_routing')},
 'jaxite_word':'runtime/jaxite_word/__init__.py'}
for _name in ('ckks_ctx','polynomial','mapping','key_gen','he_params','finite_field','herot','hemul',
              'ptct_mul','rescale','he_ops','ntt_mm','bootstrapping'):
 CRITICAL[_name]=CRITICAL['jaxite_word.'+_name]='runtime/jaxite_word/'+_name+'.py'
del _name
EXPORTS={
 'key_contexts':('load_server','load_server_prepared'),
 'loader_prepared_rotation':('PreparedLoaderSession',),
 'prepared_rotation':('AuthenticatedRotationLease','PreparedCompiledRotation','create_prepared_arithmetic'),
 'engine_prepared_owners':('PreparedEngineOwners',),
 'full_model_engine':('ServerEngine','server_engine'),
 'encrypted_bert_full_model':('BertFullModel',),
 'encrypted_bert_bsgs_attention':('BertBSGSAttentionTile',),
 'encrypted_bsgs_score_routing':('BSGSScoreRouting',)}

def sha(raw):return hashlib.sha256(raw).hexdigest()

def _name(name):
 if type(name)is not str or not name or Path(name).is_absolute()or '..'in Path(name).parts or Path(name).as_posix()!=name:
  raise ValueError('ordinary relative source name required')
 if Path(name).suffix not in ('.py','.json','.md'):raise ValueError('only explicit public source/metadata files allowed')
 return name

def _read(root,name):
 name=_name(name);path=root/name
 for part in (path,*path.parents):
  if part==root:break
  if part.is_symlink():raise ValueError('symlinked source member or parent forbidden: '+name)
 before=path.stat()
 if not stat.S_ISREG(before.st_mode)or before.st_size>8<<20:raise ValueError('bounded regular source required: '+name)
 raw=path.read_bytes();after=path.stat()
 state=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 if state(before)!=state(after)or len(raw)!=before.st_size:raise ValueError('source changed while reading: '+name)
 return raw

def _inventory(root,extra_files):
 if type(extra_files)is not tuple or len(set(extra_files))!=len(extra_files):raise ValueError('unique explicit tuple of extra source files required')
 extra=tuple(_name(n)for n in extra_files)
 raw=_read(root,'combined_parent_sources.json')
 if sha(raw)!=PARENT_MANIFEST_SHA256:raise ValueError('externally reviewed canonical parent manifest differs')
 origin=json.loads(raw);parent=origin['prepared251']
 if (len(parent)!=251 or origin['bsgs_copied_sources']!=BSGS or origin['prepared_archive_sha256']!=PREPARED_ARCHIVE
     or origin['bsgs_full_source_archive_sha256']!=BSGS_ARCHIVE):raise ValueError('reviewed source-parent bindings differ')
 names=set(parent)|set(BSGS)|set(KNOWN_NEW)
 if names.intersection(extra):raise ValueError('extra source already belongs to the explicit closure')
 return parent,tuple(sorted(names|set(extra)))

def capture_sources(root=HERE,*,extra_files=()):
 """Hash the explicit reviewed source set; never discover files with a glob."""
 root=Path(root).resolve();parent,names=_inventory(root,extra_files)
 current={n:sha(_read(root,n))for n in names}
 for name,pinned in parent.items():
  if name in BSGS or name=='runtime/stage/file_stages.py':continue
  if current[name]!=pinned:raise ValueError('unchanged prepared-parent source differs: '+name)
 for name,pinned in (BSGS|NEW_PINS).items():
  if current[name]!=pinned:raise ValueError('pinned combined source differs: '+name)
 return current

def _roots(root):
 # jaxite_word inserts its package directory ahead of the worker's explicit
 # HERE/stage/joined/common/runtime sequence. No system path is searched here.
 return [root/'runtime/jaxite_word',root,root/'runtime/stage',root/'joined',
         root/'joined/checkout/cadathlon/common',root/'runtime']

def _resolve(name,roots):
 search=list(map(str,roots));parts=name.split('.');spec=None
 for i in range(len(parts)):
  spec=importlib.machinery.PathFinder.find_spec('.'.join(parts[:i+1]),search)
  if spec is None:return None
  if i+1<len(parts):
   if spec.submodule_search_locations is None:return None
   search=list(spec.submodule_search_locations)
 return None if spec.origin is None else Path(spec.origin).resolve()

def _static(root,expected):
 roots=_roots(root);resolved={};pending=list(CRITICAL);external=set()
 while pending:
  name=pending.pop()
  if name in resolved or name in external:continue
  path=_resolve(name,roots)
  if path is None:external.add(name);continue
  if not path.is_relative_to(root):raise ValueError('resolved source escaped closure: '+name)
  relative=path.relative_to(root).as_posix()
  if relative not in expected:raise ValueError('reachable source omitted from explicit inventory: '+relative)
  if sha(_read(root,relative))!=expected[relative]:raise ValueError('resolved source hash differs: '+name)
  resolved[name]=relative;tree=ast.parse(_read(root,relative),filename=relative)
  for node in ast.walk(tree):
   if isinstance(node,ast.Import):pending.extend(a.name for a in node.names)
   elif isinstance(node,ast.ImportFrom)and node.level==0 and node.module:
    pending.append(node.module)
    pending.extend(node.module+'.'+a.name for a in node.names if a.name!='*'and _resolve(node.module+'.'+a.name,roots)is not None)
   elif isinstance(node,ast.Call)and isinstance(node.func,ast.Attribute)and node.func.attr=='import_module':
    if node.args and isinstance(node.args[0],ast.Constant)and type(node.args[0].value)is str:pending.append(node.args[0].value)
 for name,relative in CRITICAL.items():
  if resolved.get(name)!=relative:raise ValueError('critical source resolution differs: '+name)
 for module,names in EXPORTS.items():
  tree=ast.parse(_read(root,CRITICAL[module]));exports={n.name for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.AsyncFunctionDef))}
  if not set(names)<=exports:raise ValueError('actual source export missing: '+module)
 tree=ast.parse(_read(root,CRITICAL['file_stages']))
 handler=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='server_encrypted_compute')
 imports=[n for n in ast.walk(handler)if isinstance(n,ast.ImportFrom)and any(a.name=='load_server_prepared'for a in n.names)]
 if len(imports)!=1 or imports[0].module!='key_contexts' or imports[0].level!=0:
  raise ValueError('handler must import actual key_contexts.load_server_prepared export')
 defaults={a.arg:b for a,b in zip(handler.args.kwonlyargs,handler.args.kw_defaults)}
 if not isinstance(defaults.get('prepared_rotation_cache'),ast.Constant)or defaults['prepared_rotation_cache'].value is not False:
  raise ValueError('ordinary exact-False handler default required')
 return resolved,sorted(external)

def check_sources(expected,root=HERE,*,extra_files=(),loaded_modules=None,require_unloaded=False):
 """Verify snapshot bytes, static paths/exports, and already-loaded origins.

 `require_unloaded` is the fresh-worker entry check, before runtime imports.
 The default supports later checks after the reviewed modules were imported.
 Neither variant executes a loader or claims arbitrary in-memory code attestation.
 """
 if type(expected)is not dict or any(type(n)is not str or type(h)is not str or len(h)!=64 for n,h in expected.items()):
  raise ValueError('externally pinned exact source hash dictionary required')
 if type(require_unloaded)is not bool:raise ValueError('exact boolean import phase required')
 root=Path(root).resolve();actual=capture_sources(root,extra_files=extra_files)
 if actual!=expected:raise ValueError('exact combined source inventory or bytes differ')
 resolved,external=_static(root,expected);modules=sys.modules if loaded_modules is None else loaded_modules;checked={}
 for name,module in tuple(modules.items()):
  if module is None:continue
  file=getattr(module,'__file__',None)
  if name in resolved:
   if require_unloaded:raise ValueError('runtime module preloaded before fresh source gate: '+name)
   if not file or Path(file).resolve()!=root/resolved[name]:raise ValueError('preloaded critical/local module path differs: '+name)
  if not file:continue
  path=Path(file).resolve()
  if not path.is_relative_to(root)or path.suffix!='.py':continue
  relative=path.relative_to(root).as_posix()
  if relative not in expected or sha(_read(root,relative))!=expected[relative]:raise ValueError('preloaded source hash/inventory differs: '+name)
  origin=getattr(getattr(module,'__spec__',None),'origin',None)
  if origin not in (None,'built-in','frozen')and Path(origin).resolve()!=path:raise ValueError('preloaded module origin differs: '+name)
  checked[name]={'path':relative,'sha256':expected[relative]}
 for name in ('polynomial','ckks_ctx','mapping'):
  if name in modules and 'jaxite_word.'+name in modules and modules[name]is not modules['jaxite_word.'+name]:
   raise ValueError('flat/package runtime module identities split: '+name)
 return {'passed':True,'source_file_count':len(expected),'critical_resolution':{n:resolved[n]for n in CRITICAL},
  'reachable_local_modules':resolved,'external_imports':external,'loaded_local_modules':checked,
  'fresh_runtime_gate':require_unloaded,'combined_HE_or_full_numeric_pass':False}
