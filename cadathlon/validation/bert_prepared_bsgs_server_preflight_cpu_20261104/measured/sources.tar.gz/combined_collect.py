"""Isolated combined server collector. No healthy timeout or output deletion.

Only a future reviewed execute invocation may create ciphertext outputs. The
original upload is borrowed and unrelated original-I/O siblings are ignored.
"""
from pathlib import Path
import argparse,json,os,sys,time
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE/'runtime/stage'),str(HERE/'joined'),
              str(HERE/'joined/checkout/cadathlon/common'),str(HERE/'runtime')]
import combined_common as common

def services():
    from types import SimpleNamespace
    import dependencies_combined,combined_worker
    from combined_processes import OwnedChild
    from cleanup import cleanup_signals,termination_signals
    return SimpleNamespace(**locals())

def validate_worker(proof,process,expected,report):
    flags=('passed','body_complete','termination_scope_completed','cleanup_completed',
           'actual_server_compute_started','actual_server_compute_completed','request_readback_complete',
           'response_readback_complete','upload_payloads_unchanged','keygen_codecs_native_private_forbidden',
           'source_files_unchanged','upload_retained','response_root_retained','external_workspaces_never_removed')
    if (type(proof)is not dict or any(proof.get(n)is not True for n in flags)
        or any(proof.get(n)is not False for n in ('key_generation','encryption','decryption','native_model_forward','client_private_read'))
        or proof.get('cleanup_errors')or proof.get('error')or proof.get('forbidden_attempts')
        or proof.get('source_hashes_start')!=expected or proof.get('source_hashes_end')!=expected
        or proof.get('prerequisite')!=report['prerequisite']or proof.get('reviewed_dependencies')!=report['reviewed_dependencies']
        or proof.get('response_contract')!=report['response_contract']
        or process.get('direct_returncode')!=0 or type(process.get('direct_returncode'))is not int
        or any(process.get(n)is not True for n in ('direct_child_reaped','group_empty_verified','cleanup_completed'))
        or process.get('cleanup_errors')):raise ValueError('strict source/phase/terminal worker proof required')
    request=proof.get('request_readback',{});response=proof.get('response_readback',{});bound=report['prerequisite']
    for item in (request,response):
        if (type(item.get('sample_count'))is not int or item['sample_count']!=1
            or item.get('input_digest')!=bound['input_digest']or item.get('public_batch_sha256')!=bound['public_batch_sha256']):raise ValueError('ordered request response binding differs')
    if (type(request.get('tile_count'))is not int or request['tile_count']!=8 or request.get('tiles')!=report['authenticated_tiles']
        or type(response.get('response_count'))is not int or response['response_count']!=1
        or type(response.get('level'))is not int or response['level']!=2):raise ValueError('complete size0 transport proof required')
    numeric=('prepared_graph_owners','prepared_max_entries_per_owner','prepared_max_bytes_per_owner','prepared_aggregate_logical_bytes')
    if (any(type(proof.get(n))is not int for n in numeric)or proof.get('prepared_rotation_cache')is not True or proof.get('prepared_graph_owners')!=2
        or proof.get('prepared_max_entries_per_owner')!=2 or proof.get('prepared_max_bytes_per_owner')!=2<<30
        or proof.get('prepared_aggregate_logical_bytes')!=4<<30 or proof.get('refresh_rotation_cache')!='ordinary'):
        raise ValueError('fixed two-owner prepared mode required')

def body(report,*,output,response_root,execute,arguments,worker_python,s):
    primary=None;child=None;upload=None;response=None;execution=None;before={};started=time.monotonic()
    try:
        common.environment();report['software']=common.software_versions();raw=common.raw_sources(HERE);before=common.hashes(raw)
        report.update(source_hashes_start=before,source_bytes=sum(map(len,raw.values())),source_guard_start=common.check_sources(before,HERE))
        common.archive(output/'sources.tar.gz',raw);common.check_archive(output/'sources.tar.gz',before)
        execution=output/'execution_source';execution.mkdir(mode=0o700)
        for name,data in raw.items():
            p=execution/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
        if common.hashes({n:common.read(execution/n)for n in before})!=before:raise ValueError('execution snapshot differs')
        common.write(output/'source_manifest.json',before)
        report.update(source_archive_sha256=common.digest(common.read(output/'sources.tar.gz',32<<20)),source_archive_verified=True,
            reviewed_dependencies=s.dependencies_combined.inspect(root=HERE),source_count=len(before),environment=common.environment())
        if not execute:
            report.update(preparation_complete=True,body_complete=True,actual_execution_attempted=False)
            return
        report['reviewed_dependencies']=s.dependencies_combined.require_ready(root=HERE)
        profile=raw['runtime/stage/server_inputs/p60_profile_and_refresh.json'];plan=raw['runtime/stage/server_inputs/twelve_layer_plan.json']
        keys,model,inputs=s.combined_worker.authenticate(s.combined_worker.services(),arguments,profile,plan)
        report['prerequisite']=s.combined_worker.prerequisite_summary(keys,model,inputs);report['authenticated_tiles']=inputs['tiles']
        paths=s.combined_worker.make_paths(keys,model,inputs,arguments['io_workspace'],response_root)
        upload=common.HeldDirectory(paths['upload'])
        # Full existing key/model/upload storage is excluded. This is just new
        # response transport plus a fixed evidence/filesystem margin.
        parent=common.HeldDirectory(Path(response_root).parent)
        parent_primary=None
        try:
            space=os.fstatvfs(parent.fd);free=space.f_bavail*space.f_frsize;required=(6<<20)+(1<<30)
            if free<required:raise OSError('insufficient separate response storage')
            Path(response_root).mkdir(mode=0o700,exist_ok=False);report['response_root_created']=True
        except BaseException as error:parent_primary=error;raise
        finally:
            try:parent.close()
            except BaseException as error:
                if parent_primary is None:raise
                parent_primary.add_note('response parent close: '+repr(error))
        response=common.HeldDirectory(response_root)
        report.update(response_contract=s.combined_worker.response_contract(paths,upload,response,report['prerequisite']),
            storage=dict(required_bytes=required,available_bytes=free,includes='one6291456-byte ciphertext payload plus1GiB evidence/filesystem margin',
                excludes='borrowed public key/model/upload bytes, prepared4GiB logical cap, physical/transient/compiler memory'),
            actual_execution_attempted=True)
        work=output/'worker';work.mkdir(mode=0o700)
        args=arguments|dict(response_root=response_root,response_identity=list(response.identity),output=work/'worker_report.json',
            source_manifest=output/'source_manifest.json',source_manifest_sha256=common.digest(common.read(output/'source_manifest.json')))
        command=[str(worker_python),str(execution/'combined_worker.py')]
        for name,value in args.items():command+=['--'+name.replace('_','-'),json.dumps(value)if name=='response_identity'else str(value)]
        env=os.environ.copy();env.update(JAX_PLATFORMS='cpu',PYTHONUNBUFFERED='1',PYTHONDONTWRITEBYTECODE='1')
        common.write(output/'report.json',report)
        with (work/'worker.log').open('x')as log:
            child=s.OwnedChild(command,cwd=execution,stdout=log,env=env,term_grace=30.,kill_grace=30.)
            report['worker_process']=child.record;common.write(output/'report.json',report)
            code=child.wait()
        if code!=0:raise ValueError('combined server worker failed')
        proof=common.parse(common.read(work/'worker_report.json'))
        report['worker_report_sha256']=common.digest(common.read(work/'worker_report.json'))
        validate_worker(proof,child.record,before,report)
        after=s.combined_worker.authenticate(s.combined_worker.services(),arguments,profile,plan)
        if s.combined_worker.prerequisite_summary(*after)!=report['prerequisite']:raise ValueError('external prerequisite drift')
        upload.check();response.check()
        report.update(actual_server_compute=True,request_readback=proof['request_readback'],response_readback=proof['response_readback'],
            worker_elapsed_s=proof['elapsed_s'],body_complete=True,operation_complete=True)
    except BaseException as error:primary=error
    finally:
        final=common.Finalizer(report,primary)
        def cleanup():
            if child is not None:
                final.attempt('owned child close',lambda:child.close(primary=primary));report['worker_process']=child.record
            report['all_processes_reaped']=child is None or all(child.record.get(n)is True for n in ('direct_child_reaped','group_empty_verified','cleanup_completed'))and not child.record.get('cleanup_errors')
            report['source_hashes_end']=final.attempt('current source readback',lambda:common.hashes(common.raw_sources(HERE)))
            report['execution_source_hashes_end']=final.attempt('execution source readback',lambda:{n:common.digest(common.read(execution/n))for n in before})if execution is not None else None
            report['source_archive_verified']=final.attempt('source archive readback',lambda:common.check_archive(output/'sources.tar.gz',before))is True if before else False
            report['source_guard_end']=final.attempt('loaded source origins',lambda:common.check_sources(before,HERE))if before else None
            report['source_files_unchanged']=bool(before)and before==report.get('source_hashes_end')==report.get('execution_source_hashes_end')
            for name,owner in (('upload',upload),('response_root',response)):
                if owner is not None:
                    report[name+'_retained']=final.attempt('check '+name,owner.check)is True
                    final.attempt('close '+name,owner.close)
            report['external_workspaces_never_removed']=True
            report['response_retention_policy']='retain separate owned response root on all attempts; never alter original download or private ledger'
        final.shielded(s.cleanup_signals,cleanup)
        report['cleanup_completed']=not report.get('cleanup_errors')and report['all_processes_reaped']
        report['body_complete']=bool(report.get('body_complete')and report['source_files_unchanged']and report['source_archive_verified']and report['cleanup_completed']and(not execute or report.get('upload_retained')and report.get('response_root_retained')))
        report['elapsed_s']=time.monotonic()-started
        final.attempt('body terminal report',lambda:common.write(output/'report.json',report));final.raise_if_failed()

def run(output,*,response_root,execute=False,worker_python=Path('/tmp/cross-pretrained-validation-env/bin/python'),**arguments):
    if type(execute)is not bool:raise ValueError('exact execute boolean required')
    protected=tuple(arguments[n]for n in ('key_workspace','model_workspace','io_workspace','key_evidence','model_evidence','stage3_evidence'))
    output=common.outside(output,(*protected,HERE));response_root=common.outside(response_root,(*protected,HERE,output))
    if Path(response_root).exists()or Path(response_root).is_symlink():raise FileExistsError('fresh separate response root required')
    output.mkdir(mode=0o700,exist_ok=False)
    report=dict(passed=False,body_complete=False,termination_scope_completed=False,cleanup_completed=False,execute=execute,
        actual_execution_attempted=False,actual_server_compute=False,all_processes_reaped=True,pid=os.getpid(),cpu_affinity=sorted(os.sched_getaffinity(0)),
        source_files_unchanged=False,source_archive_verified=False,
        scope='Isolated combined server collector preparation. Actual execute requires completed reviewed dependencies and separate authorization; no numerical accuracy or speed inference.')
    try:s=services()
    except BaseException as primary:
        report['error']=dict(type=type(primary).__name__,message=str(primary))
        try:common.write(output/'report.json',report)
        except BaseException as error:primary.add_note('collector service import publication: '+repr(error))
        raise
    return common.finish(output/'report.json',report,lambda r:body(r,output=output,response_root=response_root,execute=execute,
        arguments=arguments,worker_python=worker_python,s=s),s.termination_signals,s.cleanup_signals)

def main():
    p=argparse.ArgumentParser()
    for n in ('output','response-root','key-evidence','key-workspace','model-evidence','model-workspace','stage3-evidence','io-workspace'):p.add_argument('--'+n,required=True,type=Path)
    for n in ('key-report-sha256','model-report-sha256','stage3-report-sha256'):p.add_argument('--'+n,required=True)
    p.add_argument('--execute',action='store_true');p.add_argument('--worker-python',type=Path,default=Path('/tmp/cross-pretrained-validation-env/bin/python'))
    report=run(**vars(p.parse_args()));print(json.dumps({n:report[n]for n in ('passed','execute','actual_server_compute','elapsed_s')}))
    return 0 if report['passed']else 1
if __name__=='__main__':raise SystemExit(main())
