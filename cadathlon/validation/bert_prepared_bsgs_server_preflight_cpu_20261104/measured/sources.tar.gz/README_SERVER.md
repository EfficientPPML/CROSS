# Isolated prepared-cache and BSGS server preparation

This successor preserves all 265 bytes from reviewed combined handler proof
`1218e06b8458996f669392276ef1e76ed2bb96618079b01c8818e2520f2e9834`.
Only explicitly named new files implement a fresh source-gated worker, collector,
dependency gate and synthetic tests. Inherited worker/collect/dependencies are
provenance only and are never selected for this path.

The worker authenticates completed stages 1, 2 and 3 before transport payloads,
uses all eight ordered ciphertexts, and explicitly selects the reviewed prepared
handler. Graph and linear owners each have two entries and a 2 GiB logical cap;
refresh stays ordinary. The 4 GiB sum excludes master key/mmap backing, compiler,
conversion and arithmetic temporaries, ciphertexts and physical memory overhead.
There is no changed arithmetic or inferred speed/peak-memory result.

Original stage3 upload is read-only and independently held. A separately created
0700 response root receives download and server_report. Existing original-I/O
siblings may change legitimately. No external key/model/input directory, original
download or private requests/completed ledger is ever removed or reused. Response
artifacts remain after every actual attempt, including failure or uncertain child
status. A future client successor must authenticate the new response-root inode,
ordered input binding and response digests before decoding; current ordinary
stage5 paths cannot silently stand in for that successor.

The completed full-BSGS K15/K128 82-check ideal proof is separately pinned
alongside the combined265 construction proof and authenticated all74 matrix
compatibility audit. The earlier pending state is preserved. Technical readiness
does not supply actual launch authorization or joined encrypted accuracy. Preparation and installed-denial checks
create no contexts, keys or ciphertexts and read no retained payload bodies. No
actual server launch is authorized by this preflight or by a command-line toggle.
A future run requires parent review and a separate launch decision.

Healthy child execution has no deadline. Failed/cancelled owned child cleanup has
30-second TERM and 30-second KILL grace, records direct-child wait and owned-group
absence separately, and makes no grandchild-reaping or OS-sandbox claim. Success
is published only after cleanup and outer termination-handler restoration.

The expanded source closure includes three public predecessor source archives.
Its uncompressed inventory exceeds the historical 16 MiB evidence limit; new
source-archive readers use an explicit 32 MiB total bound and 16 MiB per-member
bound. A future client gate must adopt this bound with the exact reviewed
manifest, rather than reusing a size0-only gate or weakening source checks.
