"""Public-only prerequisite audit for the isolated prepared/BSGS server.

The reviewed pins are part of the source closure, not authority supplied by a
worker. The completed ideal BSGS82 proof establishes a technical prerequisite;
it does not authorize actual execution. No mutable readiness flag is trusted.
No backend, key, tensor, ciphertext or private reference is opened here.
"""
from pathlib import Path
import hashlib,io,json,tarfile,math
import combined_common as public

HERE=Path(__file__).resolve().parent
PINS_SHA256='cf4dfb66fc8e544f22e1e75a318e7cca892299cefedbb5b9cfe51aa23527e17f'
MANIFEST_SHA256='3460bf8ee39430303ad773b5d8c1d5e42187d5b314972c2215ffb97a631a9546'
COMBINED_REPORT_SHA256='4bdf99941c6782f27e163e694d230f570ec07a1f2355da952f7852eea8c5e02d'
COMPATIBILITY_REPORT_SHA256='8675f6822b11e08026345cd66b9ea29f93075e0d03eba7f4df984d56ef2fe5c9'
BSGS_REPORT_SHA256='8a9589ce238fe3e936603b80e1b2402c5f7cb1ae25d48efd0bcb61d9fce9746b'
CHECKPOINT_SHA256='e1f8085ef673c9eb8a1a93a84270742e8aa0ccbceadef01eef15e26c44b46034'
CONTEXT_ID='ba28d6a81704eba60c51ad59fbfee3901516b783a1144d973e8199a014d87fb9'
FLAGS=('passed','source_files_unchanged','source_archive_verified')

def _hash(raw):return hashlib.sha256(raw).hexdigest()
def _require(value,message):
    if not value:raise ValueError(message)
def _sha(value):
    _require(type(value)is str and len(value)==64 and all(c in '0123456789abcdef'for c in value),'canonical SHA256 required')
    return value

def _relative(name):
    _require(type(name)is str and bool(name)and not Path(name).is_absolute()and '..'not in Path(name).parts and Path(name).as_posix()==name,'ordinary relative public name required')
    return name

def _read(root,name,maximum=8<<20):
    name=_relative(name);path=root/name
    for parent in (path,*path.parents):
        if parent==root:break
        _require(not parent.is_symlink(),'symlinked public prerequisite forbidden: '+name)
    return public.read(path,maximum)

def _mapping(value,count):
    _require(type(value)is dict and len(value)==count,'exact source count required')
    for name,digest in value.items():_relative(name);_sha(digest)
    return value

def _archive(raw,expected):
    """Authenticate bounded regular members without extraction or execution."""
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz')as tar:
        members=tar.getmembers()
        _require(len(members)==len(expected)and len({m.name for m in members})==len(members),'duplicate or missing source archive member')
        _require(all(m.isfile()and 0<=m.size<=8<<20 for m in members)and sum(m.size for m in members)<=32<<20,'bounded regular public source archive required')
        for item in members:
            _relative(item.name)
            _require(item.name in expected,'unexpected source archive member')
            with tar.extractfile(item)as stream:body=stream.read(item.size+1)
            _require(len(body)==item.size and _hash(body)==expected[item.name],'source archive member bytes differ')
    return True

def _proof(root,name,pin):
    _require(set(pin)=={'report_sha256','archive_sha256','source_count'},'fixed public proof pin fields required')
    _require(type(pin['source_count'])is int and pin['source_count']>0,'typed source count required')
    raw=_read(root,f'combined_evidence/{name}/report.json')
    _require(_hash(raw)==_sha(pin['report_sha256']),'externally reviewed report hash differs: '+name)
    report=public.parse(raw)
    _require(type(report)is dict and all(report.get(k)is True for k in FLAGS),'successful public source proof required: '+name)
    _require(not report.get('error')and not report.get('errors')and not report.get('cleanup_errors'),'public proof records failure')
    before=_mapping(report.get('source_hashes_before'),pin['source_count'])
    _require(report.get('source_hashes_after')==before,'before/after source inventory differs')
    blob=_read(root,f'combined_evidence/{name}/sources.tar.gz',32<<20)
    _require(_hash(blob)==_sha(pin['archive_sha256'])==report.get('source_archive_sha256'),'source archive pin differs')
    _archive(blob,before)
    return report,before

def _process(row):
    _require(type(row)is dict and all(row.get(k)is True for k in ('cleanup_completed','direct_child_reaped','group_empty_verified')),'direct child retirement and group absence required')
    _require(type(row.get('direct_returncode'))is int and row['direct_returncode']==0 and row.get('cleanup_errors')==[],'successful direct child wait required')
    for key in ('pid','process_group'):_require(type(row.get(key))is int and row[key]>0,'typed positive process identifier required')

def _combined(report,expected):
    _require(all(report.get(k)is True for k in ('complete','body_passed','all_started_children_reaped','termination_scope_completed','source_archive_unchanged')),'complete combined preparation required')
    _require(report.get('actual_HE')is False and type(report.get('source_count'))is int and report['source_count']==265,'public265 proof scope required')
    declared={'engine':37,'prepared':48,'native-wrapper':9,'combined':26,'collector':13,'source-guard':36}
    rows=report.get('groups');children=report.get('started_children')
    _require(type(rows)is list and len(rows)==len(declared)and {r.get('name')for r in rows}==set(declared),'complete combined test groups required')
    for row in rows:
        _require(row.get('passed')is True and all(type(row.get(k))is int for k in ('tests','expected','bad'))and row['tests']==row['expected']==declared[row['name']]and row['bad']==0,'complete typed combined test count required')
    _require(type(children)is list and len(children)==len(declared)and {r.get('name')for r in children}==set(declared),'all direct test children required')
    for child in children:_process(child.get('process'))
    for key in ('initial_source_guard','final_source_guard'):
        guard=report.get(key,{})
        _require(guard.get('passed')is True and type(guard.get('source_file_count'))is int and guard['source_file_count']==265 and guard.get('combined_HE_or_full_numeric_pass')is False,'successful scoped source guard required')
    _require(report['source_hashes_before']==expected,'combined proof must bind the exact265 manifest')

def _keys(value,count=None):
    _require(type(value)is list and all(type(v)is int and v>0 for v in value)and value==sorted(set(value)),'sorted unique exact integer key inventory required')
    _require(count is None or len(value)==count,'public key inventory count differs')
    return set(value)

def _compatibility(report):
    _require(all(report.get(k)is True for k in ('cleanup_completed','actual_key_store_covers','profile_matches_existing','no_payloads_archived')),'successful public compatibility proof required')
    _require(report.get('backends_imported')is False,'public compatibility scope required')
    _require(report.get('checkpoint_sha256_before')==report.get('checkpoint_sha256_after')==CHECKPOINT_SHA256 and report.get('context_id')==CONTEXT_ID,'exact checkpoint/context binding required')
    dense=_keys(report.get('dense_keys'),6);graph=_keys(report.get('graph_keys'),62);refresh=_keys(report.get('refresh_keys'),106)
    required=_keys(report.get('required_keys'),118);available=_keys(report.get('available_keys'),130)
    _require(dense<=graph and graph|refresh==required and required<=available and report.get('missing_keys')==[] and report.get('unused_existing_keys')==sorted(available-required),'actual118 subset130 key union differs')
    suffixes=('attention.self.query','attention.self.key','attention.self.value','attention.output.dense','intermediate.dense','output.dense')
    names={f'bert.encoder.layer.{layer}.{suffix}.weight'for layer in range(12)for suffix in suffixes}|{'bert.pooler.dense.weight','classifier.weight'}
    matrices=report.get('matrices')
    _require(type(matrices)is list and len(matrices)==74 and {r.get('name')for r in matrices}==names,'all74 public matrices required')
    union=set()
    for row in matrices:
        _require(_sha(row.get('file_sha256_before'))==row.get('file_sha256_after')and _sha(row.get('tensor_sha256'))==row.get('checkpoint_tensor_sha256'),'before/after public tensor identity differs')
        union|=_keys(row.get('required_keys'))
    _require(union==dense,'actual matrix key union differs')
    return dict(matrix_count=74,dense_key_count=6,graph_key_count=62,refresh_key_count=106,required_key_count=118,available_key_count=130,all_required_keys_available=True,context_id=CONTEXT_ID)

def _bsgs(report,root_receipt,expected):
    """Check the pinned public terminal summary; raw private arrays stay closed.

    The fixed source-bound collector verified every individual domain and P2
    predicate before publishing this summary. This gate authenticates that
    exact report, not a new model or private-array numerical re-evaluation.
    """
    _require(all(report.get(k)is True for k in ('complete','asset_files_unchanged','cleanup_completed','terminal_scope_completed','termination_scope_completed','all_direct_children_reaped','all_owned_groups_empty','only_initial_embeddings_supplied')),'complete ideal BSGS82 terminal required')
    _require(all(report.get(k)is False for k in ('encrypted_execution','model_forward','raw_arrays_archived')),'ideal-only BSGS scope required')
    _require(type(report.get('source_count'))is int and report['source_count']==150 and report.get('snapshot_source_hashes_after')==report['source_hashes_before'],'complete150 source snapshot required')
    tests=report.get('tests',{})
    _require(tests=={'tests':82,'errors':0,'failures':0,'skipped':0}and all(type(v)is int for v in tests.values()),'all82 tests with no skipped/failure required')
    for field,value in [('original_tests_selected',33),('new_fixture_metadata_tests_expected',2),('new_collector_tests_expected',47),('legacy_collector_tests_excluded',13)]:
        _require(type(report.get(field))is int and report[field]==value,'fixed ideal test selection required')
    _process(report.get('process'))
    assets=report.get('asset_hashes_before')
    _require(type(assets)is dict and assets==report.get('asset_hashes_after')and assets=={'private_original_native_fixture':'758ff5d71fa3c836f74a974dee97c4a744e17ea283047e2abe15b4675edc202a','public_checkpoint':CHECKPOINT_SHA256},'pinned original fixture/checkpoint hashes required')
    _require(report.get('requested_cases')==[15,128]and all(type(v)is int for v in report['requested_cases']),'both fixed cases required')
    counts={15:dict(rotate=81845,multiply=7008,pt_products=517267,rescales=37398),128:dict(rotate=538189,multiply=59236,pt_products=2058877,rescales=269701)}
    rows=report.get('cases');_require(type(rows)is list and len(rows)==2 and [r.get('K')for r in rows]==[15,128],'both complete case summaries required')
    for row in rows:
        K=row['K'];_require(type(K)is int,'typed case required')
        for field,value in [('stage_records',24),('physical_slots',(24*((K+15)//16)+2)*65536),('actual_domains',302 if K==15 else 2346),('independent_domains',156),('identity_refresh_calls',136 if K==15 else 1067)]:
            _require(type(row.get(field))is int and row[field]==value,'complete fixed stage/domain/refresh inventory required')
        _require(row.get('primitive_counts')==counts[K]and all(type(v)is int for v in row['primitive_counts'].values()),'fixed BSGS operation counts required')
        _require(row.get('native_prediction_agrees')is True and row.get('native_P2_predicate_enforced_by_pinned_test')is True,'original native P2 and prediction predicates required')
        for field in ('maximum_stage_absolute_error','pooler_absolute_error','logit_absolute_error'):
            value=row.get(field);_require(type(value)in (int,float)and math.isfinite(value)and 0<=value<=1e-7,'fixed all-slot ideal error gate required')
        value=row.get('native_logit_max_abs');_require(type(value)in (int,float)and math.isfinite(value)and value>=0,'finite native diagnostic required')
    for name in ('encrypted_bert_full_model.py','encrypted_bert_layer_attention.py','encrypted_bert_bsgs_attention.py','encrypted_bsgs_score_routing.py'):
        _require(expected['joined/'+name]==report['source_hashes_before'].get(name),'combined graph must use ideal-proved runtime bytes')
    _require(type(root_receipt)is dict and all(root_receipt.get(k)is True for k in ('passed','outer_reaped','all_current_snapshot_archive_sources_equal','assets_rehashed','producer_pid_and_owned_group_absent')),'independently pinned root terminal attestation required')
    for key,value in [('outer_exit_code',0),('outer_session',2171),('source_count',150),('tests',82)]:
        _require(type(root_receipt.get(key))is int and root_receipt[key]==value,'typed root terminal result required')
    _require(root_receipt.get('report_sha256')==BSGS_REPORT_SHA256 and root_receipt.get('source_archive_sha256')==report['source_archive_sha256']and root_receipt.get('cases')==rows,'root terminal must bind exact report/archive/cases')
    return dict(source_count=150,tests=82,cases=[15,128],physical_slots=sum(r['physical_slots']for r in rows),actual_domains=2648,independent_domains=312,ideal_only=True,root_outer_reap_attested=True)

def inspect(root=HERE):
    root=Path(root).resolve()
    raw=_read(root,'combined_dependency_pins.json')
    _require(_hash(raw)==PINS_SHA256,'reviewed dependency pin document differs')
    pins=public.parse(raw)
    _require(set(pins)=={'schema','combined_manifest_sha256','combined265','compatibility118','bsgs82'}and pins['schema']=='bert-prepared-bsgs-server-dependencies-v1','fixed dependency schema required')
    _require(pins['combined_manifest_sha256']==MANIFEST_SHA256 and pins['combined265']['report_sha256']==COMBINED_REPORT_SHA256 and pins['compatibility118']['report_sha256']==COMPATIBILITY_REPORT_SHA256,'reviewed public prerequisite pins differ')
    manifest_raw=_read(root,'combined_265_sources.json');_require(_hash(manifest_raw)==MANIFEST_SHA256,'reviewed265 manifest differs')
    expected=_mapping(public.parse(manifest_raw),265)
    combined,before=_proof(root,'combined265',pins['combined265']);_combined(combined,expected)
    current={name:_hash(_read(root,name))for name in expected}
    _require(current==before,'frozen prepared/BSGS265 current source bytes differ')
    compatibility,_=_proof(root,'compatibility118',pins['compatibility118']);summary=_compatibility(compatibility)
    bsgs_pin=pins['bsgs82']
    _require(type(bsgs_pin)is dict and set(bsgs_pin)=={'state','report_sha256','archive_sha256','source_count','expected_tests','root_terminal_sha256'}and bsgs_pin['state']=='complete'and bsgs_pin['report_sha256']==BSGS_REPORT_SHA256 and type(bsgs_pin['expected_tests'])is int and bsgs_pin['expected_tests']==82,'reviewed completed BSGS82 pin required')
    bsgs,_=_proof(root,'bsgs82',{n:bsgs_pin[n]for n in ('report_sha256','archive_sha256','source_count')})
    terminal_raw=_read(root,'combined_evidence/bsgs82/root_terminal.json')
    _require(_hash(terminal_raw)==_sha(bsgs_pin['root_terminal_sha256']),'root terminal attestation hash differs')
    bsgs_summary=_bsgs(bsgs,public.parse(terminal_raw),expected)
    return dict(schema=pins['schema'],passed=True,ready=True,dependencies_authenticated=True,
        pending=[],combined_source_count=265,
        combined_report_sha256=COMBINED_REPORT_SHA256,compatibility_report_sha256=COMPATIBILITY_REPORT_SHA256,
        dependency_pins_sha256=PINS_SHA256,compatibility=summary,bsgs82=bsgs_summary,
        execution_authorized=False,actual_HE=False,
        scope='Exact public preparation/ideal prerequisites only; independent actual launch authorization remains required.')

def require_ready(root=HERE):
    result=inspect(root)
    if result['ready']is not True:raise RuntimeError('combined server dependencies pending: completed full BSGS82 ideal proof is not yet pinned')
    return result
