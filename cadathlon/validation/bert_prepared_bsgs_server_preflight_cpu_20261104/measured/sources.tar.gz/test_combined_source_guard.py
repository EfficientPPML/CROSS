"""Independent source-only closure faults; no runtime loaders or payload reads."""
from pathlib import Path
from types import SimpleNamespace as NS
import ast
import json
import shutil
import sys
import pytest
import combined_source_guard as guard

@pytest.fixture
def source(tmp_path):
 expected=guard.capture_sources()
 for name in expected:
  target=tmp_path/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(guard.HERE/name,target)
 return tmp_path,expected

def check(source,**options):
 root,expected=source;return guard.check_sources(expected,root,loaded_modules={},**options)

def test_exact_complete_parent_plus_four_and_known_new_sources():
 expected=guard.capture_sources();assert len(expected)==261
 result=guard.check_sources(expected,loaded_modules={})
 assert result['passed']is True and result['combined_HE_or_full_numeric_pass']is False
 assert set(guard.BSGS)<=set(expected)
 assert set(guard.KNOWN_NEW)<=set(expected)
 assert result['critical_resolution']==guard.CRITICAL
 assert len(result['reachable_local_modules'])>=79

@pytest.mark.parametrize('name',('joined/encrypted_bsgs_score_routing.py','joined/encrypted_bert_bsgs_attention.py',
 'runtime/stage/engine_prepared_owners.py','combined_parent_sources.json','test_combined_owners.py'))
def test_missing_current_source_fails(source,name):
 root,expected=source;(root/name).unlink()
 with pytest.raises((ValueError,FileNotFoundError)):check(source)

def test_omitted_or_extra_expected_inventory_fails(source):
 root,expected=source;expected=expected.copy();expected.pop('joined/encrypted_bsgs_score_routing.py')
 with pytest.raises(ValueError,match='inventory'):guard.check_sources(expected,root,loaded_modules={})
 expected=guard.capture_sources(root);expected['invented.py']='0'*64
 with pytest.raises(ValueError,match='inventory'):guard.check_sources(expected,root,loaded_modules={})

@pytest.mark.parametrize('name',('runtime/stage/engine_prepared_owners.py',
 'joined/checkout/cadathlon/common/encrypted_streaming_linear.py','joined/encrypted_bsgs_score_routing.py'))
def test_rehashed_parent_or_frozen_bsgs_mutation_cannot_be_accepted(source,name):
 root,expected=source;path=root/name;path.write_bytes(path.read_bytes()+b'\n# changed\n')
 expected[name]=guard.sha(path.read_bytes())
 with pytest.raises(ValueError,match='source differs'):guard.check_sources(expected,root,loaded_modules={})

def test_parent_manifest_mutually_rehashed_substitution_rejected(source):
 root,expected=source;path=root/'combined_parent_sources.json';value=json.loads(path.read_bytes())
 value['prepared251']['runtime/stage/full_model_engine.py']='0'*64;path.write_text(json.dumps(value));expected[path.name]=guard.sha(path.read_bytes())
 with pytest.raises(ValueError,match='canonical parent manifest'):check(source)

def test_handler_real_export_regression_catches_original_invented_module(source):
 root,expected=source;path=root/'runtime/stage/file_stages.py'
 path.write_text(path.read_text().replace('from key_contexts import load_server_prepared','from loader_prepared_rotation import load_server_prepared'))
 expected=guard.capture_sources(root)
 with pytest.raises(ValueError,match='actual key_contexts'):guard.check_sources(expected,root,loaded_modules={})

def test_handler_actual_export_exists_without_executing_module():
 paths=guard.capture_sources();raw=(guard.HERE/'runtime/stage/key_contexts.py').read_bytes();tree=ast.parse(raw)
 fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='load_server_prepared')
 assert set(('profile_bytes','plan_bytes','dedicated_no_write'))<={n.arg for n in fn.args.kwonlyargs}
 assert 'runtime/stage/key_contexts.py'in paths

def test_old_handler_ordinary_default_cannot_be_silently_enabled(source):
 root,expected=source;path=root/'runtime/stage/file_stages.py';path.write_text(path.read_text().replace('prepared_rotation_cache=False','prepared_rotation_cache=True'))
 with pytest.raises(ValueError,match='exact-False'):guard.check_sources(guard.capture_sources(root),root,loaded_modules={})

@pytest.mark.parametrize('name',('encrypted_bert_full_model','encrypted_bsgs_score_routing',
 'engine_prepared_owners','loader_prepared_rotation','prepared_rotation','encrypted_streaming_linear','jaxite_word.ckks_ctx'))
def test_preloaded_wrong_path_even_identical_bytes_rejected(source,tmp_path,name):
 root,expected=source;foreign=tmp_path/'foreign_copy.py';foreign.write_bytes((root/guard.CRITICAL[name]).read_bytes())
 with pytest.raises(ValueError,match='preloaded critical/local module path'):
  guard.check_sources(expected,root,loaded_modules={name:NS(__file__=str(foreign))})

def test_preloaded_expected_path_but_stale_file_hash_rejected(source):
 root,expected=source;path=root/'runtime/stage/file_stages.py';path.write_bytes(path.read_bytes()+b'\n# drift\n')
 with pytest.raises(ValueError,match='inventory or bytes'):
  guard.check_sources(expected,root,loaded_modules={'file_stages':NS(__file__=str(path))})

def test_preloaded_spec_origin_mismatch_rejected(source):
 root,expected=source;path=root/guard.CRITICAL['prepared_rotation']
 with pytest.raises(ValueError,match='origin differs'):
  guard.check_sources(expected,root,loaded_modules={'prepared_rotation':NS(__file__=str(path),__spec__=NS(origin='/foreign/prepared_rotation.py'))})

def test_fresh_worker_rejects_even_correct_preloaded_runtime(source):
 root,expected=source;path=root/guard.CRITICAL['prepared_rotation'];module=NS(__file__=str(path))
 with pytest.raises(ValueError,match='preloaded before fresh'):
  guard.check_sources(expected,root,loaded_modules={'prepared_rotation':module},require_unloaded=True)
 result=guard.check_sources(expected,root,loaded_modules={'prepared_rotation':module})
 assert result['loaded_local_modules']['prepared_rotation']['sha256']==expected[guard.CRITICAL['prepared_rotation']]

def test_split_flat_package_wrapper_identities_rejected(source):
 root,expected=source;path=root/guard.CRITICAL['polynomial']
 with pytest.raises(ValueError,match='identities split'):
  guard.check_sources(expected,root,loaded_modules={'polynomial':NS(__file__=str(path)),'jaxite_word.polynomial':NS(__file__=str(path))})
 module=NS(__file__=str(path));guard.check_sources(expected,root,loaded_modules={'polynomial':module,'jaxite_word.polynomial':module})

def test_new_critical_shadow_cannot_redirect_resolution(source):
 root,expected=source;shadow=root/'encrypted_bsgs_score_routing.py';shadow.write_bytes((root/guard.CRITICAL[shadow.stem]).read_bytes())
 extras=(shadow.name,);expected=guard.capture_sources(root,extra_files=extras)
 with pytest.raises(ValueError,match='critical source resolution'):
  guard.check_sources(expected,root,extra_files=extras,loaded_modules={})

def test_lazy_local_dependency_must_be_explicitly_captured(source):
 root,expected=source;path=root/'runtime/stage/file_stages.py';path.write_bytes(path.read_bytes()+b'\ndef lazy():\n import future_combined_worker\n')
 (root/'future_combined_worker.py').write_text('raise AssertionError("must never execute")\n')
 expected=guard.capture_sources(root)
 with pytest.raises(ValueError,match='omitted from explicit inventory'):guard.check_sources(expected,root,loaded_modules={})
 extra=('future_combined_worker.py',);expected=guard.capture_sources(root,extra_files=extra)
 result=guard.check_sources(expected,root,extra_files=extra,loaded_modules={})
 assert result['reachable_local_modules']['future_combined_worker']=='future_combined_worker.py'

def test_explicit_future_collector_and_metadata_captured(source):
 root,expected=source
 for name in ('preflight_combined.py','combined_worker.py','dependencies_combined.py','future_review.json'):
  (root/name).write_text('{}\n'if name.endswith('.json')else'raise AssertionError("not executed")\n')
 extras=('preflight_combined.py','combined_worker.py','dependencies_combined.py','future_review.json')
 expected=guard.capture_sources(root,extra_files=extras);result=guard.check_sources(expected,root,extra_files=extras,loaded_modules={})
 assert result['source_file_count']==265

@pytest.mark.parametrize('extras',([],('../outside.py',),('/tmp/absolute.py',),('data.npy',),('worker.py',),('new.py','new.py')))
def test_bad_extra_inventory_rejected(extras):
 with pytest.raises(ValueError):guard.capture_sources(extra_files=extras)

def test_symlink_source_rejected(source):
 root,expected=source;path=root/'runtime/stage/file_stages.py';raw=path.read_bytes();path.unlink();target=root/'alternate.py';target.write_bytes(raw);path.symlink_to(target)
 with pytest.raises(ValueError,match='symlinked'):check(source)

def test_no_backend_imports_in_fresh_static_probe():
 import subprocess,os
 code='import sys,combined_source_guard as g;g.check_sources(g.capture_sources(),loaded_modules={});assert not any(n in sys.modules for n in ("numpy","jax","torch","transformers","jaxite_word"))'
 result=subprocess.run([sys.executable,'-c',code],cwd=guard.HERE,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),capture_output=True,text=True)
 assert result.returncode==0,result.stderr
