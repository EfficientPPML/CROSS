"""Public report/source substitutions only; no payload or backend work."""
from pathlib import Path
import copy,io,json,tarfile,hashlib,sys
import pytest
import dependencies_combined as d

HERE=Path(__file__).resolve().parent

def report(name):return json.loads((HERE/'combined_evidence'/name/'report.json').read_text())
def manifest():return json.loads((HERE/'combined_265_sources.json').read_text())
def digest(b):return hashlib.sha256(b).hexdigest()

def test_actual_public_prerequisites_remain_pending():
    result=d.inspect(HERE)
    assert result['passed']is True and result['ready']is False
    assert result['pending']==['completed_full_bsgs82_ideal_proof']
    assert result['compatibility']['required_key_count']==118
    assert result['compatibility']['available_key_count']==130
    with pytest.raises(RuntimeError,match='BSGS82'):d.require_ready(HERE)

def test_no_numerical_imports_or_payload_reads(monkeypatch):
    allowed=set(manifest())|{'combined_dependency_pins.json','combined_265_sources.json'}|{f'combined_evidence/{g}/{f}'for g in ('combined265','compatibility118')for f in ('report.json','sources.tar.gz')}
    before=set(sys.modules);original=d._read;seen=[]
    def read(root,name,*args):
        assert name in allowed
        assert not name.endswith(('.npy','.npz','.safetensors'))
        seen.append(name);return original(root,name,*args)
    monkeypatch.setattr(d,'_read',read);d.inspect(HERE)
    assert not any(n=='jax' or n.startswith(('jax.','jaxite_word','torch','transformers','numpy'))for n in set(sys.modules)-before)
    assert set(manifest())<=set(seen)

@pytest.mark.parametrize('name',[
 'combined_dependency_pins.json','combined_265_sources.json',
 'combined_evidence/combined265/report.json','combined_evidence/combined265/sources.tar.gz',
 'combined_evidence/compatibility118/report.json','combined_evidence/compatibility118/sources.tar.gz',
 'runtime/stage/full_model_engine.py','runtime/stage/key_contexts.py',
 'runtime/stage/prepared_rotation.py','joined/encrypted_bsgs_score_routing.py',
 'joined/encrypted_bert_full_model.py','joined/encrypted_bert_bsgs_attention.py'])
def test_single_public_source_or_evidence_substitution_rejected(monkeypatch,name):
    original=d._read
    monkeypatch.setattr(d,'_read',lambda root,n,*a:original(root,n,*a)+(b' 'if n==name else b''))
    with pytest.raises(ValueError):d.inspect(HERE)

@pytest.mark.parametrize('key',['passed','complete','body_passed','all_started_children_reaped','termination_scope_completed','source_archive_unchanged'])
def test_combined_flags_reject_integer_alias(key):
    row=report('combined265');row[key]=1
    if key=='passed':
        assert row[key]is not True
    else:
        with pytest.raises(ValueError):d._combined(row,manifest())

@pytest.mark.parametrize('key',['cleanup_completed','direct_child_reaped','group_empty_verified','direct_returncode','pid'])
def test_child_retirement_is_typed(key):
    row=report('combined265')['started_children'][0]['process'];row[key]=True if key in ('direct_returncode','pid')else 1
    with pytest.raises(ValueError):d._process(row)

@pytest.mark.parametrize('mutation',[
 lambda r:r['groups'].pop(),lambda r:r['started_children'].pop(),
 lambda r:r['groups'][0].update(tests=True),lambda r:r['groups'][0].update(bad=1),
 lambda r:r['started_children'][0]['process'].update(cleanup_errors=['failure']),
 lambda r:r['final_source_guard'].update(passed=1),
 lambda r:r['source_hashes_before'].pop(next(iter(r['source_hashes_before'])))])
def test_combined_incomplete_test_or_source_proof_rejected(mutation):
    row=report('combined265');mutation(row)
    with pytest.raises(ValueError):d._combined(row,manifest())

@pytest.mark.parametrize('mutation',[
 lambda r:r.update(cleanup_completed=1),lambda r:r.update(actual_key_store_covers=False),
 lambda r:r.update(backends_imported=True),lambda r:r.update(context_id='0'*64),
 lambda r:r.update(checkpoint_sha256_after='0'*64),lambda r:r['required_keys'].pop(),
 lambda r:r['available_keys'].append(r['available_keys'][-1]),
 lambda r:r['dense_keys'].__setitem__(0,True),lambda r:r['matrices'].pop(),
 lambda r:r['matrices'][0].update(name='unexpected'),
 lambda r:r['matrices'][0].update(checkpoint_tensor_sha256='0'*64),
 lambda r:r['matrices'][0].update(file_sha256_after='0'*64),
 lambda r:r['matrices'][0].update(required_keys=[262143]),
 lambda r:r.update(missing_keys=[1])])
def test_compatibility_all74_and118_subset130_rejected_on_drift(mutation):
    row=report('compatibility118');mutation(row)
    with pytest.raises(ValueError):d._compatibility(row)

def blob(rows):
    out=io.BytesIO()
    with tarfile.open(fileobj=out,mode='w:gz')as tar:
        for name,body,kind in rows:
            item=tarfile.TarInfo(name);item.size=len(body);item.type=kind;tar.addfile(item,io.BytesIO(body))
    return out.getvalue()

@pytest.mark.parametrize('rows',[
 [('x.py',b'a',tarfile.REGTYPE),('x.py',b'a',tarfile.REGTYPE)],
 [('../x.py',b'a',tarfile.REGTYPE)], [('x.py',b'a',tarfile.SYMTYPE)],
 [('y.py',b'a',tarfile.REGTYPE)], [('x.py',b'b',tarfile.REGTYPE)], []])
def test_archive_inventory_not_only_hash_dictionary(rows):
    with pytest.raises(ValueError):d._archive(blob(rows),{'x.py':digest(b'a')})

def test_public_reader_rejects_symlink_member(tmp_path):
    (tmp_path/'x.py').symlink_to(HERE/'dependencies_combined.py')
    with pytest.raises(ValueError,match='symlink'):d._read(tmp_path,'x.py')

def test_public_parser_rejects_duplicate_fields():
    with pytest.raises(ValueError):d.public.parse(b'{"ready":false,"ready":true}')

def test_pending_authority_cannot_be_enabled_by_adding_file(monkeypatch):
    old=d._read
    def read(root,name,*a):
        assert 'bsgs82'not in name
        return old(root,name,*a)
    monkeypatch.setattr(d,'_read',read)
    assert d.inspect(HERE)['ready']is False

@pytest.mark.parametrize('field,value',[('state','complete'),('report_sha256','0'*64),('archive_sha256','0'*64)])
def test_source_pinned_pending_authority_cannot_be_rewritten(monkeypatch,field,value):
    old=d._read;row=json.loads(old(HERE,'combined_dependency_pins.json'));row['bsgs82'][field]=value
    raw=json.dumps(row).encode()
    monkeypatch.setattr(d,'_read',lambda root,n,*a:raw if n=='combined_dependency_pins.json'else old(root,n,*a))
    with pytest.raises(ValueError,match='pin document'):d.inspect(HERE)
