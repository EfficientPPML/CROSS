"""Fresh source-gated prepared+BSGS server worker; no client operations.

Only stdlib and the stdlib-only successor helpers may load before bootstrap.
The original upload is borrowed; all responses go to a separate owned root.
"""
from pathlib import Path
import argparse,hashlib,json,os,sys,time
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE/'runtime/stage'),str(HERE/'joined'),
              str(HERE/'joined/checkout/cadathlon/common'),str(HERE/'runtime')]
import combined_common as common

def bootstrap(source_manifest,source_manifest_sha256):
    common.environment()
    raw=common.read(source_manifest)
    if common.digest(raw)!=source_manifest_sha256:raise ValueError('externally bound worker source manifest differs')
    expected=common.parse(raw)
    return expected,common.check_sources(expected,HERE,fresh=True)

def services():
    from types import SimpleNamespace
    import key_gate,model_gate,stage3_gate,dependencies_combined,boundaries,server_readback
    from cleanup import cleanup_signals,termination_signals
    return SimpleNamespace(**locals())

def authenticate(s,arguments,profile,plan):
    keys=s.key_gate.authenticate(arguments['key_evidence'],arguments['key_report_sha256'],arguments['key_workspace'],profile_bytes=profile,plan_bytes=plan)
    model=s.model_gate.authenticate(arguments['model_evidence'],arguments['model_report_sha256'],arguments['model_workspace'],keys=keys)
    inputs=s.stage3_gate.authenticate(arguments['stage3_evidence'],arguments['stage3_report_sha256'],arguments['io_workspace'],keys=keys,model=model)
    return keys,model,inputs

def prerequisite_summary(keys,model,inputs):
    return {n:keys[n]for n in ('context_id','key_report_sha256','key_source_archive_sha256')}|{
        n:model[n]for n in ('model_id','model_report_sha256','model_manifest_sha256')}|{
        n:inputs[n]for n in ('stage3_report_sha256','public_batch_sha256','input_digest')}

def make_paths(keys,model,inputs,io_workspace,response_root):
    import file_stages
    original=Path(io_workspace);owned=Path(response_root)
    common.outside(owned,(original,keys['public_keys'],model['server_data']))
    if Path(inputs['upload'])!=original/'upload':raise ValueError('authenticated upload differs')
    return dict(size=0,batch_size=1,model_id=file_stages.MODEL_ID,model_revision=file_stages.REVISION,
        public_keys=keys['public_keys'],server_data=model['server_data'],upload=original/'upload',
        download=owned/'download',server_report=owned/'server_report')

def response_contract(paths,upload_owner,response_owner,prerequisite):
    return dict(schema='prepared-bsgs-separate-response-v1',upload=str(paths['upload']),
        upload_identity=list(upload_owner.identity),response_root=str(response_owner.path),
        response_root_identity=list(response_owner.identity),download=str(paths['download']),
        server_report=str(paths['server_report']),prerequisite=prerequisite,
        sample_count=1,request_tile_count=8,expected_response_level=2,
        client_successor_required=True,original_io_download_used=False)

def body(report,*,expected,arguments,response_root,response_identity,output,s):
    primary=None;upload=None;owned=None;calls=[];started=time.monotonic()
    try:
        report['reviewed_dependencies']=s.dependencies_combined.require_ready(root=HERE)
        profile=common.read(HERE/'runtime/stage/server_inputs/p60_profile_and_refresh.json')
        plan=common.read(HERE/'runtime/stage/server_inputs/twelve_layer_plan.json')
        keys,model,inputs=authenticate(s,arguments,profile,plan)
        report['prerequisite']=prerequisite_summary(keys,model,inputs)
        paths=make_paths(keys,model,inputs,arguments['io_workspace'],response_root)
        upload=common.HeldDirectory(paths['upload']);owned=common.HeldDirectory(response_root)
        if list(owned.identity)!=response_identity or list(Path(response_root).iterdir()):raise ValueError('fresh empty owned response root required')
        report['response_contract']=response_contract(paths,upload,owned,report['prerequisite'])
        # Imports are allowed only after the fresh bootstrap and prerequisite gates.
        import file_stages
        report['source_guard_before_payload']=common.check_sources(expected,HERE)
        with s.boundaries.server_only(calls,private_paths=(Path(arguments['key_workspace'])/'client_private',)):
            request=s.server_readback.requests(paths,keys=keys,model=model,stage3=inputs)
            report.update(request_readback_complete=True,request_readback={n:v for n,v in request.items()if n!='batch'})
            upload.check();owned.check();report['actual_server_compute_started']=True;common.write(output,report)
            result=file_stages.server_encrypted_compute(paths,prepared_rotation_cache=True)
            report['actual_server_compute_completed']=True
            response=s.server_readback.responses(paths,request=request)
            if (type(result)is not dict or type(result.get('sample_count'))is not int or result['sample_count']!=1
                or result.get('public_batch_sha256')!=inputs['public_batch_sha256']
                or type(response.get('sample_count'))is not int or response['sample_count']!=1
                or type(response.get('response_count'))is not int or response['response_count']!=1
                or type(response.get('level'))is not int or response['level']!=2):raise ValueError('complete size0 response required')
            if s.server_readback.requests(paths,keys=keys,model=model,stage3=inputs)!=request:raise ValueError('original upload changed')
            upload.check();owned.check()
        if calls:raise ValueError('forbidden server action attempted')
        if prerequisite_summary(*authenticate(s,arguments,profile,plan))!=report['prerequisite']:raise ValueError('completed prerequisite changed')
        report.update(response_readback_complete=True,response_readback=response,upload_payloads_unchanged=True,
            keygen_codecs_native_private_forbidden=True,context_id=keys['context_id'],model_id=model['model_id'],body_complete=True)
    except BaseException as error:primary=error
    finally:
        final=common.Finalizer(report,primary)
        def cleanup():
            report['source_guard_end']=final.attempt('final source and loaded origins',lambda:common.check_sources(expected,HERE))
            report['source_hashes_end']=final.attempt('final source hashes',lambda:common.hashes(common.raw_sources(HERE)))
            for name,owner in (('upload',upload),('response_root',owned)):
                if owner is not None:
                    report[name+'_retained']=final.attempt('check '+name,owner.check)is True
                    final.attempt('close '+name,owner.close)
            report.update(forbidden_attempts=calls,elapsed_s=time.monotonic()-started,
                source_files_unchanged=report.get('source_hashes_end')==expected,
                external_workspaces_never_removed=True,response_cleanup_policy='retain all created response artifacts, including failure or unknown process status')
        try:
            with s.cleanup_signals():cleanup()
        except BaseException as error:final.attempt('cleanup signal scope',lambda:(_ for _ in ()).throw(error))
        report['cleanup_completed']=not report.get('cleanup_errors')
        report['body_complete']=bool(report.get('body_complete')and report['source_files_unchanged']and report['cleanup_completed']and report.get('upload_retained')and report.get('response_root_retained'))
        final.attempt('body terminal publication',lambda:common.write(output,report))
        final.raise_if_failed()

def run(*,source_manifest,source_manifest_sha256,response_root,response_identity,output,**arguments):
    output=Path(output)
    protected=tuple(arguments[n]for n in ('key_workspace','model_workspace','io_workspace','key_evidence','model_evidence','stage3_evidence'))
    common.outside(output,protected);common.outside(response_root,(*protected,output.parent,HERE))
    if type(response_identity)is not list or len(response_identity)!=2 or any(type(x)is not int for x in response_identity):raise ValueError('typed response inode identity required')
    if output.exists()or output.is_symlink():raise FileExistsError('fresh worker report required')
    report=dict(passed=False,body_complete=False,termination_scope_completed=False,cleanup_completed=False,
        actual_server_compute_started=False,actual_server_compute_completed=False,request_readback_complete=False,
        response_readback_complete=False,source_files_unchanged=False,pid=os.getpid(),cpu_affinity=sorted(os.sched_getaffinity(0)),
        key_generation=False,encryption=False,decryption=False,native_model_forward=False,client_private_read=False,
        prepared_rotation_cache=True,prepared_graph_owners=2,prepared_max_entries_per_owner=2,
        prepared_max_bytes_per_owner=2<<30,prepared_aggregate_logical_bytes=4<<30,refresh_rotation_cache='ordinary',
        scope='Genuine prepared-cache plus BSGS size0 server preparation; numerical accuracy requires separately bound client validation. No launch or performance claim from preflight.')
    try:
        expected,guard=bootstrap(source_manifest,source_manifest_sha256)
    except BaseException as primary:
        report['error']=dict(type=type(primary).__name__,message=str(primary))
        try:common.write(output,report)
        except BaseException as error:primary.add_note('bootstrap failure publication: '+repr(error))
        raise
    report.update(source_hashes_start=expected,source_guard_start=guard,environment=common.environment())
    try:s=services()
    except BaseException as primary:
        report['error']=dict(type=type(primary).__name__,message=str(primary))
        try:common.write(output,report)
        except BaseException as error:primary.add_note('service import failure publication: '+repr(error))
        raise
    def work(value):return body(value,expected=expected,arguments=arguments,response_root=response_root,
        response_identity=response_identity,output=output,s=s)
    return common.finish(output,report,work,s.termination_signals,s.cleanup_signals)

def main():
    p=argparse.ArgumentParser()
    for n in ('key-evidence','key-workspace','model-evidence','model-workspace','stage3-evidence','io-workspace','response-root','output','source-manifest'):p.add_argument('--'+n,required=True,type=Path)
    for n in ('key-report-sha256','model-report-sha256','stage3-report-sha256','source-manifest-sha256'):p.add_argument('--'+n,required=True)
    p.add_argument('--response-identity',required=True,type=json.loads)
    args=vars(p.parse_args());report=run(**args)
    print(json.dumps(dict(passed=report['passed'],worker_report_sha256=common.digest(common.read(Path(args['output']))),
        context_id=report.get('context_id'),model_id=report.get('model_id'))))
    return 0 if report['passed']else 1
if __name__=='__main__':raise SystemExit(main())
