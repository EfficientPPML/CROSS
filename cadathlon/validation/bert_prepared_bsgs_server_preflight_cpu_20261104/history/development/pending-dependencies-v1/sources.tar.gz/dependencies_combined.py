"""Public-only prerequisite audit for the isolated prepared/BSGS server.

The reviewed pins are part of the source closure, not authority supplied by a
worker. A completed full BSGS82 proof has not yet been supplied. This version
therefore cannot authorize execution, including when a plausible file appears
at the future proof path. Adoption requires a new reviewed source/pin version.
No backend, key, tensor, ciphertext or private reference is opened here.
"""
from pathlib import Path
import hashlib,io,json,tarfile
import combined_common as public

HERE=Path(__file__).resolve().parent
PINS_SHA256='597ab460bc529a76341ab57be40aa1e908afddc289dd783c7a51c91e8b8b6091'
MANIFEST_SHA256='3460bf8ee39430303ad773b5d8c1d5e42187d5b314972c2215ffb97a631a9546'
COMBINED_REPORT_SHA256='4bdf99941c6782f27e163e694d230f570ec07a1f2355da952f7852eea8c5e02d'
COMPATIBILITY_REPORT_SHA256='8675f6822b11e08026345cd66b9ea29f93075e0d03eba7f4df984d56ef2fe5c9'
CHECKPOINT_SHA256='e1f8085ef673c9eb8a1a93a84270742e8aa0ccbceadef01eef15e26c44b46034'
CONTEXT_ID='ba28d6a81704eba60c51ad59fbfee3901516b783a1144d973e8199a014d87fb9'
FLAGS=('passed','source_files_unchanged','source_archive_verified')

def _hash(raw):return hashlib.sha256(raw).hexdigest()
def _require(value,message):
    if not value:raise ValueError(message)
def _sha(value):
    _require(type(value)is str and len(value)==64 and all(c in '0123456789abcdef'for c in value),'canonical SHA256 required')
    return value

def _relative(name):
    _require(type(name)is str and bool(name)and not Path(name).is_absolute()and '..'not in Path(name).parts and Path(name).as_posix()==name,'ordinary relative public name required')
    return name

def _read(root,name,maximum=8<<20):
    name=_relative(name);path=root/name
    for parent in (path,*path.parents):
        if parent==root:break
        _require(not parent.is_symlink(),'symlinked public prerequisite forbidden: '+name)
    return public.read(path,maximum)

def _mapping(value,count):
    _require(type(value)is dict and len(value)==count,'exact source count required')
    for name,digest in value.items():_relative(name);_sha(digest)
    return value

def _archive(raw,expected):
    """Authenticate bounded regular members without extraction or execution."""
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz')as tar:
        members=tar.getmembers()
        _require(len(members)==len(expected)and len({m.name for m in members})==len(members),'duplicate or missing source archive member')
        _require(all(m.isfile()and 0<=m.size<=8<<20 for m in members)and sum(m.size for m in members)<=32<<20,'bounded regular public source archive required')
        for item in members:
            _relative(item.name)
            _require(item.name in expected,'unexpected source archive member')
            with tar.extractfile(item)as stream:body=stream.read(item.size+1)
            _require(len(body)==item.size and _hash(body)==expected[item.name],'source archive member bytes differ')
    return True

def _proof(root,name,pin):
    _require(set(pin)=={'report_sha256','archive_sha256','source_count'},'fixed public proof pin fields required')
    _require(type(pin['source_count'])is int and pin['source_count']>0,'typed source count required')
    raw=_read(root,f'combined_evidence/{name}/report.json')
    _require(_hash(raw)==_sha(pin['report_sha256']),'externally reviewed report hash differs: '+name)
    report=public.parse(raw)
    _require(type(report)is dict and all(report.get(k)is True for k in FLAGS),'successful public source proof required: '+name)
    _require(not report.get('error')and not report.get('errors')and not report.get('cleanup_errors'),'public proof records failure')
    before=_mapping(report.get('source_hashes_before'),pin['source_count'])
    _require(report.get('source_hashes_after')==before,'before/after source inventory differs')
    blob=_read(root,f'combined_evidence/{name}/sources.tar.gz',32<<20)
    _require(_hash(blob)==_sha(pin['archive_sha256'])==report.get('source_archive_sha256'),'source archive pin differs')
    _archive(blob,before)
    return report,before

def _process(row):
    _require(type(row)is dict and all(row.get(k)is True for k in ('cleanup_completed','direct_child_reaped','group_empty_verified')),'direct child retirement and group absence required')
    _require(type(row.get('direct_returncode'))is int and row['direct_returncode']==0 and row.get('cleanup_errors')==[],'successful direct child wait required')
    for key in ('pid','process_group'):_require(type(row.get(key))is int and row[key]>0,'typed positive process identifier required')

def _combined(report,expected):
    _require(all(report.get(k)is True for k in ('complete','body_passed','all_started_children_reaped','termination_scope_completed','source_archive_unchanged')),'complete combined preparation required')
    _require(report.get('actual_HE')is False and type(report.get('source_count'))is int and report['source_count']==265,'public265 proof scope required')
    declared={'engine':37,'prepared':48,'native-wrapper':9,'combined':26,'collector':13,'source-guard':36}
    rows=report.get('groups');children=report.get('started_children')
    _require(type(rows)is list and len(rows)==len(declared)and {r.get('name')for r in rows}==set(declared),'complete combined test groups required')
    for row in rows:
        _require(row.get('passed')is True and all(type(row.get(k))is int for k in ('tests','expected','bad'))and row['tests']==row['expected']==declared[row['name']]and row['bad']==0,'complete typed combined test count required')
    _require(type(children)is list and len(children)==len(declared)and {r.get('name')for r in children}==set(declared),'all direct test children required')
    for child in children:_process(child.get('process'))
    for key in ('initial_source_guard','final_source_guard'):
        guard=report.get(key,{})
        _require(guard.get('passed')is True and type(guard.get('source_file_count'))is int and guard['source_file_count']==265 and guard.get('combined_HE_or_full_numeric_pass')is False,'successful scoped source guard required')
    _require(report['source_hashes_before']==expected,'combined proof must bind the exact265 manifest')

def _keys(value,count=None):
    _require(type(value)is list and all(type(v)is int and v>0 for v in value)and value==sorted(set(value)),'sorted unique exact integer key inventory required')
    _require(count is None or len(value)==count,'public key inventory count differs')
    return set(value)

def _compatibility(report):
    _require(all(report.get(k)is True for k in ('cleanup_completed','actual_key_store_covers','profile_matches_existing','no_payloads_archived')),'successful public compatibility proof required')
    _require(report.get('backends_imported')is False,'public compatibility scope required')
    _require(report.get('checkpoint_sha256_before')==report.get('checkpoint_sha256_after')==CHECKPOINT_SHA256 and report.get('context_id')==CONTEXT_ID,'exact checkpoint/context binding required')
    dense=_keys(report.get('dense_keys'),6);graph=_keys(report.get('graph_keys'),62);refresh=_keys(report.get('refresh_keys'),106)
    required=_keys(report.get('required_keys'),118);available=_keys(report.get('available_keys'),130)
    _require(dense<=graph and graph|refresh==required and required<=available and report.get('missing_keys')==[] and report.get('unused_existing_keys')==sorted(available-required),'actual118 subset130 key union differs')
    suffixes=('attention.self.query','attention.self.key','attention.self.value','attention.output.dense','intermediate.dense','output.dense')
    names={f'bert.encoder.layer.{layer}.{suffix}.weight'for layer in range(12)for suffix in suffixes}|{'bert.pooler.dense.weight','classifier.weight'}
    matrices=report.get('matrices')
    _require(type(matrices)is list and len(matrices)==74 and {r.get('name')for r in matrices}==names,'all74 public matrices required')
    union=set()
    for row in matrices:
        _require(_sha(row.get('file_sha256_before'))==row.get('file_sha256_after')and _sha(row.get('tensor_sha256'))==row.get('checkpoint_tensor_sha256'),'before/after public tensor identity differs')
        union|=_keys(row.get('required_keys'))
    _require(union==dense,'actual matrix key union differs')
    return dict(matrix_count=74,dense_key_count=6,graph_key_count=62,refresh_key_count=106,required_key_count=118,available_key_count=130,all_required_keys_available=True,context_id=CONTEXT_ID)

def inspect(root=HERE):
    root=Path(root).resolve()
    raw=_read(root,'combined_dependency_pins.json')
    _require(_hash(raw)==PINS_SHA256,'reviewed dependency pin document differs')
    pins=public.parse(raw)
    _require(set(pins)=={'schema','combined_manifest_sha256','combined265','compatibility118','bsgs82'}and pins['schema']=='bert-prepared-bsgs-server-dependencies-v1','fixed dependency schema required')
    _require(pins['combined_manifest_sha256']==MANIFEST_SHA256 and pins['combined265']['report_sha256']==COMBINED_REPORT_SHA256 and pins['compatibility118']['report_sha256']==COMPATIBILITY_REPORT_SHA256,'reviewed public prerequisite pins differ')
    manifest_raw=_read(root,'combined_265_sources.json');_require(_hash(manifest_raw)==MANIFEST_SHA256,'reviewed265 manifest differs')
    expected=_mapping(public.parse(manifest_raw),265)
    combined,before=_proof(root,'combined265',pins['combined265']);_combined(combined,expected)
    current={name:_hash(_read(root,name))for name in expected}
    _require(current==before,'frozen prepared/BSGS265 current source bytes differ')
    compatibility,_=_proof(root,'compatibility118',pins['compatibility118']);summary=_compatibility(compatibility)
    # Pending is intentional authority, not a file-existence heuristic. An
    # arbitrary added completed report cannot enable this frozen version.
    _require(pins['bsgs82']=={'state':'pending','report_sha256':None,'archive_sha256':None,'source_count':150,'expected_tests':82},'full BSGS82 proof must remain explicitly pending in this version')
    return dict(schema=pins['schema'],passed=True,ready=False,dependencies_authenticated=True,
        pending=['completed_full_bsgs82_ideal_proof'],combined_source_count=265,
        combined_report_sha256=COMBINED_REPORT_SHA256,compatibility_report_sha256=COMPATIBILITY_REPORT_SHA256,
        dependency_pins_sha256=PINS_SHA256,compatibility=summary,
        execution_authorized=False,actual_HE=False,
        scope='Exact public prerequisites only; full BSGS82 completion pin and independent actual launch authorization remain required.')

def require_ready(root=HERE):
    result=inspect(root)
    if result['ready']is not True:raise RuntimeError('combined server dependencies pending: completed full BSGS82 ideal proof is not yet pinned')
    return result
