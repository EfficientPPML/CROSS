from contextlib import nullcontext,contextmanager
from pathlib import Path
from types import SimpleNamespace
import sys,json
import pytest
import combined_worker as w

@pytest.fixture
def fixture(tmp_path,monkeypatch):
    roots={n:tmp_path/n for n in ('keys','model','io','response','evidence')}
    for p in roots.values():p.mkdir()
    (roots['io']/'upload').mkdir();(roots['io']/'download').mkdir();(roots['io']/'download'/'sentinel').write_text('active')
    events=[];expected={'source':'hash'};keys=dict(context_id='context',key_report_sha256='k',key_source_archive_sha256='kt',public_keys=roots['keys'])
    model=dict(model_id='model',model_report_sha256='m',model_manifest_sha256='mm',server_data=roots['model'])
    inputs=dict(upload=roots['io']/'upload',stage3_report_sha256='s',public_batch_sha256='b',input_digest='i')
    request=dict(sample_count=1,tile_count=8,public_batch_sha256='b',input_digest='i',tiles=[{'tile':i}for i in range(8)],batch={})
    response=dict(sample_count=1,response_count=1,public_batch_sha256='b',input_digest='i',level=2)
    args={n:roots['evidence']for n in ('key_evidence','model_evidence','stage3_evidence')}
    args.update(key_workspace=roots['keys'],model_workspace=roots['model'],io_workspace=roots['io'],key_report_sha256='k',model_report_sha256='m',stage3_report_sha256='s')
    def gate(name,value):
        def call(*a,**kw):events.append(name);return value
        return call
    def handler(paths,*,prepared_rotation_cache):
        events.append('handler');assert prepared_rotation_cache is True
        assert paths['upload']==roots['io']/'upload'and paths['download']==roots['response']/'download'
        paths['download'].mkdir();paths['server_report'].write_text('{}')
        return {'sample_count':1,'public_batch_sha256':'b'}
    module=SimpleNamespace(MODEL_ID='fixed-model',REVISION='rev',server_encrypted_compute=handler)
    monkeypatch.setitem(sys.modules,'file_stages',module)
    @contextmanager
    def boundary(calls,**kw):events.append('guard-enter');yield;events.append('guard-exit')
    s=SimpleNamespace(key_gate=SimpleNamespace(authenticate=gate('key',keys)),model_gate=SimpleNamespace(authenticate=gate('model',model)),
        stage3_gate=SimpleNamespace(authenticate=gate('stage3',inputs)),dependencies_combined=SimpleNamespace(require_ready=gate('dependency',{'ready':True})),
        server_readback=SimpleNamespace(requests=gate('requests',request),responses=gate('responses',response)),
        boundaries=SimpleNamespace(server_only=boundary),cleanup_signals=nullcontext)
    monkeypatch.setattr(w.common,'check_sources',lambda *a,**kw:{'passed':True})
    monkeypatch.setattr(w.common,'raw_sources',lambda *a:{'source':b'raw'})
    monkeypatch.setattr(w.common,'hashes',lambda *a:expected)
    real=w.common.read;monkeypatch.setattr(w.common,'read',lambda p,*a:b'{}'if 'server_inputs'in str(p)else real(p,*a))
    report=dict(passed=False,body_complete=False)
    kw=dict(expected=expected,arguments=args,response_root=roots['response'],response_identity=[roots['response'].stat().st_dev,roots['response'].stat().st_ino],output=roots['evidence']/'worker.json',s=s)
    return SimpleNamespace(roots=roots,events=events,expected=expected,args=args,report=report,kw=kw,s=s,module=module,request=request,response=response)

def test_real_call_separate_output_and_order(fixture):
    f=fixture;w.body(f.report,**f.kw)
    assert f.report['body_complete']and f.report['cleanup_completed']
    assert f.events[:4]==['dependency','key','model','stage3']
    assert f.events.index('guard-enter')<f.events.index('requests')<f.events.index('handler')<f.events.index('responses')<f.events.index('guard-exit')
    assert (f.roots['io']/'download'/'sentinel').read_text()=='active'
    assert f.report['response_contract']['original_io_download_used']is False

def test_pending_dependency_precedes_any_prerequisite(fixture):
    f=fixture
    def pending(**kw):raise RuntimeError('full82 pending')
    f.s.dependencies_combined.require_ready=pending
    with pytest.raises(RuntimeError,match='pending'):w.body(f.report,**f.kw)
    assert not f.events and not f.report.get('actual_server_compute_started')

@pytest.mark.parametrize('flag',['sample_count','response_count','level'])
def test_typed_response_contract(fixture,flag):
    f=fixture;f.response[flag]=True if flag!='level'else2.0
    with pytest.raises(ValueError):w.body(f.report,**f.kw)
    assert f.report['actual_server_compute_completed']and not f.report['body_complete']

@pytest.mark.parametrize('error',[ValueError,KeyboardInterrupt,SystemExit])
def test_actual_started_failure_retains_outputs_and_original(fixture,error):
    f=fixture;primary=error('failed')
    def handler(paths,**kw):paths['download'].mkdir();(paths['download']/'partial').write_text('partial');raise primary
    f.module.server_encrypted_compute=handler
    with pytest.raises(error)as got:w.body(f.report,**f.kw)
    assert got.value is primary and (f.roots['response']/'download'/'partial').exists()
    assert (f.roots['io']/'download'/'sentinel').read_text()=='active'
    assert f.report['upload_retained']and f.report['response_root_retained']

def test_upload_mutation_detected(fixture):
    f=fixture;n=[0]
    def requests(*a,**kw):
        n[0]+=1
        return f.request if n[0]==1 else dict(f.request,input_digest='changed')
    f.s.server_readback.requests=requests
    with pytest.raises(ValueError,match='upload changed'):w.body(f.report,**f.kw)

def test_nonempty_response_rejected_before_payload(fixture):
    f=fixture;(f.roots['response']/'sentinel').write_text('old')
    with pytest.raises(ValueError,match='empty'):w.body(f.report,**f.kw)
    assert 'requests'not in f.events

def test_shared_response_root_rejected(fixture):
    f=fixture;f.kw['response_root']=f.roots['io']
    with pytest.raises(ValueError,match='disjoint'):w.body(f.report,**f.kw)
    assert 'requests'not in f.events

def test_bootstrap_checks_before_services(tmp_path,monkeypatch):
    events=[];manifest=tmp_path/'source.json';manifest.write_text('{"x":"h"}')
    monkeypatch.setattr(w.common,'environment',lambda:events.append('environment'))
    monkeypatch.setattr(w.common,'check_sources',lambda expected,root,*,fresh:events.append(('guard',fresh))or{})
    expected,_=w.bootstrap(manifest,w.common.digest(manifest.read_bytes()))
    assert events==['environment',('guard',True)]and expected=={'x':'h'}
    with pytest.raises(ValueError):w.bootstrap(manifest,'wrong')
