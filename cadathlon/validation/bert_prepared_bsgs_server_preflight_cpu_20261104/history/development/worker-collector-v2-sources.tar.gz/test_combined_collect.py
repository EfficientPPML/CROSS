from contextlib import nullcontext
from pathlib import Path
from types import SimpleNamespace
import copy,json
import pytest
import combined_collect as c

def proof_fixture():
    before={'one':'hash'};prereq={'input_digest':'i','public_batch_sha256':'b'};contract={'root':'owned'}
    report=dict(prerequisite=prereq,reviewed_dependencies={'ready':True},response_contract=contract,authenticated_tiles=list(range(8)))
    flags=('passed','body_complete','termination_scope_completed','cleanup_completed','actual_server_compute_started',
        'actual_server_compute_completed','request_readback_complete','response_readback_complete','upload_payloads_unchanged',
        'keygen_codecs_native_private_forbidden','source_files_unchanged','upload_retained','response_root_retained','external_workspaces_never_removed')
    proof={n:True for n in flags}|dict(source_hashes_start=before,source_hashes_end=before,prerequisite=prereq,
        reviewed_dependencies=report['reviewed_dependencies'],response_contract=contract,
        request_readback=dict(sample_count=1,tile_count=8,tiles=list(range(8)),**prereq),
        response_readback=dict(sample_count=1,response_count=1,level=2,**prereq),prepared_rotation_cache=True,
        prepared_graph_owners=2,prepared_max_entries_per_owner=2,prepared_max_bytes_per_owner=2<<30,
        prepared_aggregate_logical_bytes=4<<30,refresh_rotation_cache='ordinary')
    process=dict(direct_returncode=0,direct_child_reaped=True,group_empty_verified=True,cleanup_completed=True,cleanup_errors=[])
    return proof,process,before,report

def test_complete_worker_contract():c.validate_worker(*proof_fixture())

@pytest.mark.parametrize('key',['termination_scope_completed','cleanup_completed','actual_server_compute_completed','upload_payloads_unchanged','source_files_unchanged','prepared_rotation_cache'])
def test_false_worker_flags(key):
    p,process,before,r=proof_fixture();p[key]=False
    with pytest.raises(ValueError):c.validate_worker(p,process,before,r)

@pytest.mark.parametrize('key',['direct_child_reaped','group_empty_verified','cleanup_completed'])
def test_process_failure_rejects_valid_worker(key):
    p,process,before,r=proof_fixture();process[key]=False
    with pytest.raises(ValueError):c.validate_worker(p,process,before,r)

@pytest.mark.parametrize('mutation',['sources','root','ordered','digest','ordinary','level'])
def test_rehashed_inconsistent_proof(mutation):
    p,process,before,r=proof_fixture()
    if mutation=='sources':p['source_hashes_end']={'different':'hash'}
    elif mutation=='root':p['response_contract']={'root':'original download'}
    elif mutation=='ordered':p['request_readback']['tiles']=list(reversed(range(8)))
    elif mutation=='digest':p['response_readback']['input_digest']='different'
    elif mutation=='ordinary':p['prepared_rotation_cache']=False
    elif mutation=='level':p['response_readback']['level']=2.0
    with pytest.raises(ValueError):c.validate_worker(p,process,before,r)

def test_existing_output_never_overwritten(tmp_path):
    protected={n:tmp_path/n for n in ('key_workspace','model_workspace','io_workspace','key_evidence','model_evidence','stage3_evidence')}
    output=tmp_path/'result';output.mkdir();(output/'report.json').write_text('sentinel')
    with pytest.raises(FileExistsError):c.run(output,response_root=tmp_path/'response',**protected)
    assert (output/'report.json').read_text()=='sentinel'

def test_original_io_alias_rejected_before_any_output(tmp_path):
    protected={n:tmp_path/n for n in ('key_workspace','model_workspace','io_workspace','key_evidence','model_evidence','stage3_evidence')}
    protected['io_workspace'].mkdir();alias=tmp_path/'alias';alias.symlink_to(protected['io_workspace'],target_is_directory=True)
    out=tmp_path/'new'
    with pytest.raises(ValueError):c.run(out,response_root=alias/'response',**protected)
    assert not out.exists()

def test_preparation_does_not_authenticate_or_allocate_response(tmp_path,monkeypatch):
    output=tmp_path/'out';output.mkdir();response=tmp_path/'response';expected={'file.py':'h'}
    monkeypatch.setattr(c.common,'environment',lambda:{})
    monkeypatch.setattr(c.common,'raw_sources',lambda *a:{'file.py':b'public'})
    monkeypatch.setattr(c.common,'hashes',lambda *a:expected)
    monkeypatch.setattr(c.common,'check_sources',lambda *a:{'passed':True})
    monkeypatch.setattr(c.common,'check_archive',lambda *a:True)
    monkeypatch.setattr(c.common,'digest',lambda raw:'h')
    def forbidden(*a,**kw):raise AssertionError('private/prerequisite/worker execution attempted')
    s=SimpleNamespace(dependencies_combined=SimpleNamespace(inspect=lambda **kw:{'ready':False,'pending':['bsgs82']},require_ready=forbidden),
        combined_worker=SimpleNamespace(authenticate=forbidden),OwnedChild=forbidden,cleanup_signals=nullcontext)
    r={};c.body(r,output=output,response_root=response,execute=False,arguments={},worker_python=Path('none'),s=s)
    assert r['body_complete']and r['preparation_complete']and not response.exists()
