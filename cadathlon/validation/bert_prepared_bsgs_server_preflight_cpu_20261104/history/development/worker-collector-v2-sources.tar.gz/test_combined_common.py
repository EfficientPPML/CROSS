from contextlib import contextmanager,nullcontext
from pathlib import Path
import json,os,stat
from types import SimpleNamespace
import pytest
import combined_common as c

@pytest.mark.parametrize('raw',[b'{"x":1,"x":2}',b'{"x":NaN}',b'{"x":Infinity}'])
def test_noncanonical_public_json(raw):
    with pytest.raises(ValueError):c.parse(raw)

def test_read_regular_bounded_and_symlink(tmp_path):
    p=tmp_path/'x';p.write_bytes(b'abc');assert c.read(p)==b'abc'
    with pytest.raises(ValueError):c.read(p,2)
    q=tmp_path/'link';q.symlink_to(p)
    with pytest.raises(ValueError):c.read(q)

def test_read_replacement_after_open(tmp_path,monkeypatch):
    p=tmp_path/'x';p.write_bytes(b'abc');real=c.os.open
    def changed(*a,**kw):
        fd=real(*a,**kw);p.unlink();p.write_bytes(b'abc');return fd
    monkeypatch.setattr(c.os,'open',changed)
    with pytest.raises(ValueError,match='replaced'):c.read(p)

@pytest.mark.parametrize('error',[KeyboardInterrupt,SystemExit])
def test_read_body_primary_preserved_on_close(tmp_path,monkeypatch,error):
    p=tmp_path/'x';p.write_bytes(b'abc');primary=error('body');real=c.os.close;held=[]
    def fail_read(*a):raise primary
    def fail_close(fd):held.append(fd);raise OSError('close')
    monkeypatch.setattr(c.os,'read',fail_read);monkeypatch.setattr(c.os,'close',fail_close)
    with pytest.raises(error)as got:c.read(p)
    assert got.value is primary
    for fd in held:real(fd)

def test_write_primary_and_retry_has_unique_temp(tmp_path,monkeypatch):
    p=tmp_path/'r.json';real=c.os.write;counter=[0]
    def once(*a):
        counter[0]+=1
        if counter[0]==1:raise OSError('temporary write failure')
        return real(*a)
    monkeypatch.setattr(c.os,'write',once)
    with pytest.raises(OSError):c.write(p,{'passed':True})
    c.write(p,{'passed':False});assert json.loads(p.read_text())=={'passed':False}

@pytest.mark.parametrize('relation',['same','descendant','ancestor','alias'])
def test_disjoint_output(tmp_path,relation):
    base=tmp_path/'retained';base.mkdir()
    candidate={'same':base,'descendant':base/'new','ancestor':tmp_path,'alias':tmp_path/'alias'}[relation]
    if relation=='alias':candidate.symlink_to(base,target_is_directory=True)
    with pytest.raises(ValueError):c.outside(candidate,(base,))

def test_upload_sibling_allowed_but_replacement_rejected(tmp_path):
    root=tmp_path/'io';root.mkdir();upload=root/'upload';upload.mkdir();held=c.HeldDirectory(upload)
    (root/'download').mkdir();assert held.check()
    upload.rename(root/'old');upload.mkdir()
    with pytest.raises(ValueError):held.check()
    held.close()

def test_failed_close_is_quarantined_without_retry(tmp_path,monkeypatch):
    held=c.HeldDirectory(tmp_path);calls=[];real=c.os.close
    def fail(fd):calls.append(fd);raise OSError('uncertain')
    monkeypatch.setattr(c.os,'close',fail)
    with pytest.raises(OSError)as first:held.close()
    with pytest.raises(OSError)as second:held.close()
    assert second.value is first.value and len(calls)==1 and held in c._QUARANTINE
    real(held.fd)

@pytest.mark.parametrize('kind',[KeyboardInterrupt,SystemExit])
def test_cleanup_only_cancellation_precedence(kind):
    r={};f=c.Finalizer(r);cancel=kind('stop')
    f.attempt('ordinary',lambda:(_ for _ in ()).throw(OSError('close')))
    f.attempt('cancel',lambda:(_ for _ in ()).throw(cancel))
    f.attempt('later',lambda:(_ for _ in ()).throw(ValueError('hash')))
    with pytest.raises(kind)as got:f.raise_if_failed()
    assert got.value is cancel and len(r['cleanup_errors'])==3

def test_body_primary_preserved():
    primary=ValueError('body');f=c.Finalizer({},primary)
    f.attempt('cleanup',lambda:(_ for _ in ()).throw(KeyboardInterrupt()))
    with pytest.raises(ValueError)as got:f.raise_if_failed()
    assert got.value is primary

def test_success_only_after_termination_exit(tmp_path):
    p=tmp_path/'report.json';r={}
    @contextmanager
    def termination():
        yield
        assert json.loads(p.read_text()).get('passed')is not True
    def body(v):v.update(body_complete=True,cleanup_completed=True)
    result=c.finish(p,r,body,termination,nullcontext)
    assert result['passed']and result['termination_scope_completed']

@pytest.mark.parametrize('kind',[RuntimeError,KeyboardInterrupt,SystemExit])
def test_termination_failure_republished(tmp_path,kind):
    p=tmp_path/'report.json';primary=kind('restore')
    @contextmanager
    def termination():yield;raise primary
    def body(r):r.update(body_complete=True,cleanup_completed=True)
    with pytest.raises(kind)as got:c.finish(p,{},body,termination,nullcontext)
    assert got.value is primary
    r=json.loads(p.read_text());assert r['passed']is False and r['termination_scope_completed']is False

def test_initial_publication_error_is_preserved_and_republished(tmp_path,monkeypatch):
    p=tmp_path/'r.json';real=c.write;primary=OSError('initial');count=[0]
    def once(*args):
        count[0]+=1
        if count[0]==1:raise primary
        return real(*args)
    monkeypatch.setattr(c,'write',once)
    with pytest.raises(OSError)as got:c.finish(p,{},lambda r:None,nullcontext,nullcontext)
    assert got.value is primary and json.loads(p.read_text())['passed']is False

@pytest.mark.parametrize('name,value',[('CROSS_MOCK','1'),('BOOTSTRAP_FAKE','1'),('JAX_DISABLE_JIT','1'),('XLA_FLAGS','bad')])
def test_runtime_override_rejected(monkeypatch,name,value):
    for n in tuple(os.environ):
        if n.startswith(('CROSS_','BOOTSTRAP_','PYTEST_')):monkeypatch.delenv(n)
    monkeypatch.setenv('JAX_PLATFORMS','cpu');monkeypatch.setenv(name,value)
    with pytest.raises(ValueError):c.environment()
