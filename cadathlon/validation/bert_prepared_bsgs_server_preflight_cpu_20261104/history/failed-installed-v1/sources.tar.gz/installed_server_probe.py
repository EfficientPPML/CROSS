"""Installed entrypoint denial probe only; never constructs a runtime object."""
from pathlib import Path
import argparse,json,os,sys
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE/'runtime/stage'),str(HERE/'joined'),str(HERE/'joined/checkout/cadathlon/common'),str(HERE/'runtime')]
import combined_common as common

def run(source_manifest,source_manifest_sha256,output):
    if Path(output).exists()or Path(output).is_symlink():raise FileExistsError('fresh installed-probe output required')
    common.environment();raw=common.read(source_manifest)
    if common.digest(raw)!=source_manifest_sha256:raise ValueError('external installed-probe source manifest differs')
    expected=common.parse(raw);initial=common.check_sources(expected,HERE,fresh=True)
    from cleanup import termination_signals,cleanup_signals
    report=dict(passed=False,body_complete=False,cleanup_completed=False,termination_scope_completed=False,pid=os.getpid(),
        source_hashes_start=expected,source_guard_start=initial,actual_HE=False,actual_contexts=False,actual_keys=False,
        payload_reads=False,scope='Installed forbidden-entrypoint denial and restoration only; no handler/context/key/payload/model operation')
    def body(r):
        r['software']=common.software_versions()
        import boundaries,client_keys,client_inputs,key_contexts,file_stages
        import key_gen
        from jaxite_word import CKKSContext
        from jaxite_word import key_gen as package_keys
        pairs=[(m,n)for m in (key_gen,package_keys)for n in boundaries.KEY_METHODS]
        pairs += [(CKKSContext,n)for n in boundaries.CODECS]
        pairs += [(client_keys,'generate'),(client_inputs,'ClientEmbeddings'),(key_contexts,'load_client'),(key_contexts,'_read_private'),
                  (file_stages,'client_key_generation'),(file_stages,'client_encode_encrypt_input'),(file_stages,'client_decrypt_decode'),
                  (file_stages,'server_preprocess_model'),(file_stages,'_records'),(file_stages,'_snapshot')]
        originals=[getattr(owner,name)for owner,name in pairs]
        allowed=(key_contexts.load_server,key_contexts.load_server_prepared,file_stages.server_encrypted_compute)
        calls=[]
        with boundaries.server_only(calls):
            for owner,name in pairs:
                try:getattr(owner,name)(None)
                except RuntimeError as error:
                    if not str(error).startswith('forbidden stage4 server action:'):raise
                else:raise ValueError('installed forbidden entrypoint was callable')
            if allowed!=(key_contexts.load_server,key_contexts.load_server_prepared,file_stages.server_encrypted_compute):raise ValueError('allowed server/prepared handler changed')
        if len(calls)!=25 or any(getattr(owner,name)is not original for (owner,name),original in zip(pairs,originals)):raise ValueError('exact installed denial/restoration inventory differs')
        if any(n.split('.')[0]in ('torch','transformers')for n in sys.modules):raise ValueError('native model module imported')
        r.update(denied_entries=calls,denied_count=25,all_forbidden_entries_restored=True,allowed_server_entries_unchanged=True,
            source_guard_end=common.check_sources(expected,HERE),source_hashes_end=common.hashes(common.raw_sources(HERE)),
            body_complete=True,cleanup_completed=True)
        r['source_files_unchanged']=r['source_hashes_end']==expected
        if not r['source_files_unchanged']:raise ValueError('installed probe source drift')
    return common.finish(output,report,body,termination_signals,cleanup_signals)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source-manifest',type=Path,required=True);p.add_argument('--source-manifest-sha256',required=True);p.add_argument('--output',type=Path,required=True)
    r=run(**vars(p.parse_args()));print(json.dumps({'passed':r['passed'],'denied_count':r['denied_count']}));raise SystemExit(0 if r['passed'] else 1)
