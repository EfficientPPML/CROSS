"""Preflight must not read the real dataset, tokenizer or checkpoint assets."""
from pathlib import Path
import json,os,sys

ATTEMPTS=[]
PROTECTED=(Path('/home/jianming_gatech/cross_validation_assets'),)
def pytest_sessionstart(session):
    def audit(event,args):
        if event!='open' or not args or not isinstance(args[0],(str,bytes,os.PathLike)):return
        path=Path(os.fsdecode(args[0])).absolute()
        if any(path==p or p in path.parents for p in PROTECTED):
            ATTEMPTS.append(str(path));raise RuntimeError('real validation asset read forbidden in fixture preflight')
    sys.addaudithook(audit)
def pytest_sessionfinish(session,exitstatus):
    target=os.environ.get('RANKED_FIXTURE_READ_GUARD_OUTPUT')
    if target:Path(target).write_text(json.dumps(dict(attempted_real_asset_reads=ATTEMPTS))+'\n')
