"""Nine ranked input fixtures only; no embeddings/model/keys/HE execution."""
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
import hashlib,importlib.metadata,json,os,random,stat,sys,tarfile,tempfile,time
import upstream_fixture as base
from owned_directory import open_owned_directory,check_owned_directory,remove_owned_directory
from cleanup import cleanup_signals,termination_signals
from terminal import terminal_scope

ROOT=Path(__file__).resolve().parent
SCHEDULE=tuple((size,count,seed) for size,count in ((1,100),(2,200),(3,408)) for seed in (42,43,44))


def write_json(path,value):
    raw=(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    fd,name=tempfile.mkstemp(prefix='.'+path.name+'-',dir=path.parent)
    temporary=Path(name)
    try:
        with os.fdopen(fd,'wb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
        temporary.replace(path)
    finally:
        primary=sys.exception()
        try:temporary.unlink(missing_ok=True)
        except BaseException as error:
            if primary is None:raise
            primary.add_note('metadata temporary cleanup: '+type(error).__name__)


def validate_case(size,seed):
    if type(size)is not int or size not in (1,2,3) or type(seed)is not int or seed not in (42,43,44):
        raise ValueError('exact ranked size1/2/3 and base seed42/43/44 required')
    return {1:100,2:200,3:408}[size]


def instance_params(workspace,size):
    if type(size)is not int or size not in (1,2,3):raise ValueError('ranked size must be1,2,3')
    path=ROOT/'upstream/submissions/params.py';ns={'__name__':'_isolated_ranked_params'}
    exec(compile(path.read_bytes(),str(path),'exec'),ns)
    params=ns['InstanceParams'](size,rootdir=workspace,dataset='mrpc')
    if params.get_batch_size()!={1:100,2:200,3:408}[size]:raise ValueError('upstream ranked batch mapping changed')
    return params


def preprocess(workspace,size,tokenizer):
    calls=[]
    class LocalTokenizer:
        @staticmethod
        def from_pretrained(name):
            if name!='google-bert/bert-base-cased-finetuned-mrpc':raise ValueError('upstream tokenizer identity changed')
            calls.append(name);return tokenizer
    def params(actual_size,dataset):
        if type(actual_size)is not int or actual_size!=size or dataset!='mrpc':
            raise ValueError('upstream preprocessing size/dataset changed')
        return instance_params(workspace,size)
    ns=dict(json=json,sys=SimpleNamespace(argv=['client_preprocess_input.py',str(size)],stderr=sys.stderr),
        InstanceParams=params,AutoTokenizer=LocalTokenizer,MODEL_ID='google-bert/bert-base-cased-finetuned-mrpc',
        MAX_LENGTH=128,print=lambda *args,**kwargs:None)
    base.compile_function(ROOT/'upstream/submissions/client_preprocess_input.py','main',ns)()
    if len(calls)!=1:raise ValueError('one pinned tokenizer lookup required')


def prepare_case(workspace,rows,tokenizer,*,size,seed):
    import numpy as np
    count=validate_case(size,seed);params=instance_params(workspace,size)
    params.dataset_intermediate_dir().mkdir(parents=True)
    # Preserve the same upstream complete-dataset export and selected export.
    base.export(rows,params.datadir()/'dataset_samples.jsonl',params.datadir()/'dataset_labels.txt',-1,None)
    derived=base.upstream_seed(seed)
    base.export(rows,params.get_test_input_file(),params.get_ground_truth_labels_file(),count,derived)
    independent_seed=int(np.random.Generator(np.random.PCG64(seed)).integers(0,2147483647))
    chosen=list(range(408)) if count==408 else sorted(random.Random(independent_seed).sample(range(408),count))
    selected=[rows[i] for i in chosen]
    expected_raw=''.join(json.dumps(dict(target_idx=r['idx'],sentence1=r['sentence1'],sentence2=r['sentence2']))+'\n' for r in selected)
    expected_labels=''.join(str(r['label'])+'\n' for r in selected)
    if (derived!=independent_seed or params.get_test_input_file().read_text()!=expected_raw
            or params.get_ground_truth_labels_file().read_text()!=expected_labels):
        raise ValueError('upstream selection/order/labels differ from independent reference')
    preprocess(workspace,size,tokenizer)
    expected=[]
    for r in selected:
        item=tokenizer.encode_plus(r['sentence1'],r['sentence2'],max_length=128,padding='max_length',truncation=True)
        record=dict(target_idx=r['idx'],**{k:item[k] for k in ('input_ids','token_type_ids','attention_mask')})
        base.validate_tokens(record);expected.append(record)
    output=params.io_intermediate_dir()/'client_preprocessed_input'
    if output.read_text()!=''.join(json.dumps(r)+'\n' for r in expected):
        raise ValueError('upstream tokenizer differs from independent encode_plus reference')
    private=dict(schema='private-bert-ranked-selection-v1',size=size,count=count,base_seed=seed,generator_seed=derived,
        row_ordinals=chosen,target_ids=[r['idx'] for r in selected],labels=[r['label'] for r in selected])
    base.write_json(workspace/'private_selection.json',private)
    for path in workspace.rglob('*'):path.chmod(0o700 if path.is_dir() else 0o600)
    workspace.chmod(0o700)
    files=sorted(p for p in workspace.rglob('*') if p.is_file())
    lengths=[sum(r['attention_mask']) for r in expected]
    histogram={str(k):lengths.count(k) for k in sorted(set(lengths))}
    return dict(size=size,count=count,base_seed=seed,generator_seed=derived,record_count=len(expected),
        preprocessed_input_path=str(output),input_file_sha256={str(p.relative_to(workspace)):base.sha(p) for p in files},
        private_target_order_sha256=hashlib.sha256(json.dumps(private['target_ids']).encode()).hexdigest(),
        private_row_order_sha256=hashlib.sha256(json.dumps(chosen).encode()).hexdigest(),
        fixed_token_length=128,valid_token_count_histogram=histogram,
        selection_byte_parity=True,tokenization_byte_parity=True,labels_private=True,
        all_private_directories_0700=all(stat.S_IMODE(p.stat().st_mode)==0o700 for p in (workspace,*[x for x in workspace.rglob('*') if x.is_dir()])),
        all_private_files_0600=all(stat.S_IMODE(p.stat().st_mode)==0o600 for p in files))


def asset_hashes():return {str(base.MODEL/k):base.sha(base.MODEL/k) for k in base.ASSETS}|{str(base.DATA):base.sha(base.DATA)}


def load_rows():
    import pyarrow.parquet as pq
    expected={str(base.MODEL/k):v for k,v in base.ASSETS.items()}|{str(base.DATA):base.DATA_SHA}
    if asset_hashes()!=expected:raise ValueError('pinned dataset/model/tokenizer assets differ')
    table=pq.read_table(base.DATA)
    if table.num_rows!=408 or set(table.column_names)!={'sentence1','sentence2','label','idx'}:
        raise ValueError('pinned MRPC validation schema differs')
    rows=table.to_pylist()
    if (any(type(r['idx'])is not int or type(r['label'])is not int or r['label'] not in (0,1)
            or type(r['sentence1'])is not str or type(r['sentence2'])is not str for r in rows)
            or len({r['idx'] for r in rows})!=408):raise ValueError('MRPC private row inventory differs')
    return rows


@contextmanager
def no_model_execution():
    import torch
    from transformers import PreTrainedModel
    patched=[];primary=None;failure=None
    def deny(*args,**kwargs):raise RuntimeError('model construction/forward forbidden in tokenizer-only fixture')
    try:
        for owner,name in ((PreTrainedModel,'__init__'),(torch.nn.Module,'__call__')):
            original=getattr(owner,name);patched.append((owner,name,original))
            setattr(owner,name,deny)
        yield
    except BaseException as error:primary=error;raise
    finally:
        with cleanup_signals():
            for owner,name,original in reversed(patched):
                try:setattr(owner,name,original)
                except BaseException as error:
                    if primary is not None:primary.add_note('native guard restoration: '+type(error).__name__)
                    elif failure is None:failure=error
                    elif not isinstance(error,Exception) and isinstance(failure,Exception):
                        error.add_note('earlier native guard restoration: '+type(failure).__name__);failure=error
                    else:failure.add_note('additional native guard restoration: '+type(error).__name__)
            if primary is None and failure is not None:raise failure


def prepare(workspace):
    from transformers import AutoTokenizer
    rows=load_rows();cases=[]
    with no_model_execution():
        tokenizer=AutoTokenizer.from_pretrained(base.MODEL,local_files_only=True)
        if type(tokenizer).__name__!='BertTokenizerFast' or not tokenizer.is_fast:
            raise ValueError('pinned fast tokenizer implementation differs')
        for size,count,seed in SCHEDULE:
            child=workspace/f'size{size}-seed{seed}';child.mkdir(mode=0o700)
            cases.append(prepare_case(child,rows,tokenizer,size=size,seed=seed))
    if len(cases)!=9 or sum(x['record_count'] for x in cases)!=2124:
        raise ValueError('all nine ranked cases and2124 selected records required')
    full=[x for x in cases if x['count']==408]
    if len({x['private_target_order_sha256'] for x in full})!=1:
        raise ValueError('upstream full408 export must preserve identical order for all seeds')
    return cases


def source_paths():
    paths=base.source_paths();paths['origin.json']=ROOT/'origin.json'
    return paths


def verify_archive(path,expected):
    with tarfile.open(path) as archive:
        members=archive.getmembers()
        if (len(members)!=len(expected) or len({m.name for m in members})!=len(members)
                or any(not m.isfile() or Path(m.name).is_absolute() or '..' in Path(m.name).parts for m in members)):
            raise ValueError('exact source archive inventory required')
        actual={m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in members}
        if actual!=expected:raise ValueError('source archive final bytes differ')
    return True


def collect(output):
    output=Path(output)
    if output.parent.resolve()!=ROOT or output.name in ('upstream','server_inputs'):
        raise ValueError('fresh direct child of the isolated lab required for evidence')
    output.mkdir(exist_ok=False)
    report=dict(schema='bert-ranked-tokenizer-fixtures-v1',passed=False,
        scope='Nine client-only upstream selector/tokenizer fixtures; no embeddings/model forward/keys/HE/ranked accuracy',
        cases=[],ranked_cases_expected=9,selected_records_expected=2124,model_forward=False,encrypted_execution=False,
        private_workspace_retained=False,cleanup_completed=False,cleanup_errors=[])
    paths={};workspace=fd=identity=None;primary=cleanup_error=None;started=time.monotonic();old_umask=os.umask(0o077)
    try:
        write_json(output/'report.json',report)
        paths=source_paths();report['source_hashes_before']=base.archive_sources(paths,output/'sources.tar.gz')
        report['source_archive_sha256']=base.sha(output/'sources.tar.gz')
        origin=json.loads((ROOT/'upstream_origin.json').read_text())
        report['upstream_original_sha256_before']=base.upstream_hashes(origin)
        if report['upstream_original_sha256_before']!={k:v['sha256'] for k,v in origin.items()}:
            raise ValueError('frozen upstream source identity changed')
        report['asset_file_sha256_before']=asset_hashes()
        workspace=Path(tempfile.mkdtemp(prefix='bert-ranked-input-client-'))
        fd,identity=open_owned_directory(workspace)
        report.update(private_workspace=str(workspace),private_workspace_identity=identity)
        report['cases']=prepare(workspace)
        report['model_construction_and_forward_guards']=True
        check_owned_directory(workspace,fd,identity)
        report['private_workspace_permissions']=oct(stat.S_IMODE(workspace.stat().st_mode))
        report['passed']=(len(report['cases'])==9 and all(x['all_private_files_0600'] and x['all_private_directories_0700'] for x in report['cases'])
                          and stat.S_IMODE(workspace.stat().st_mode)==0o700)
        report['versions']={name:importlib.metadata.version(name) for name in ('numpy','pyarrow','transformers','tokenizers','torch')}
        report['cpu_affinity']=sorted(os.sched_getaffinity(0));report['python']=sys.version
    except BaseException as error:
        primary=error;report['error']=dict(type=type(error).__name__,message='Ranked fixture preparation failed; no private contents published')
        raise
    finally:
        def attempt(label,fn):
            nonlocal cleanup_error
            try:return fn()
            except BaseException as error:
                report['passed']=False;report['cleanup_errors'].append(label+': '+type(error).__name__)
                if primary is not None:primary.add_note(label+': '+type(error).__name__)
                elif cleanup_error is None:cleanup_error=error
                elif not isinstance(error,Exception) and isinstance(cleanup_error,Exception):
                    error.add_note('earlier cleanup: '+type(cleanup_error).__name__);cleanup_error=error
                else:cleanup_error.add_note(label+': '+type(error).__name__)
        with terminal_scope(report,output/'report.json',write_json,cleanup_signals,lambda:(primary,cleanup_error)):
            if paths:
                after=attempt('source final identity',lambda:{k:base.sha(p) for k,p in paths.items()})
                assets=attempt('asset final identity',asset_hashes)
                originals=attempt('upstream final identity',lambda:base.upstream_hashes(json.loads((ROOT/'upstream_origin.json').read_text())))
                report.update(source_hashes_after=after,asset_file_sha256_after=assets,upstream_original_sha256_after=originals)
                report['sources_unchanged']=after==report.get('source_hashes_before') and after is not None
                report['assets_unchanged']=assets==report.get('asset_file_sha256_before') and assets is not None
                report['upstream_originals_unchanged']=originals==report.get('upstream_original_sha256_before') and originals is not None
                report['source_archive_verified']=attempt('source archive final readback',lambda:verify_archive(output/'sources.tar.gz',report['source_hashes_before'])) is True
                report['passed']=report['passed'] and report['sources_unchanged'] and report['assets_unchanged'] and report['upstream_originals_unchanged'] and report['source_archive_verified']
            if workspace is not None:
                if report['passed']:report['private_workspace_retained']=True
                else:
                    removed=attempt('owned private cleanup',lambda:remove_owned_directory(workspace,fd,identity))is True
                    report['private_workspace_removed_on_failure']=removed
                    report['private_workspace_retained']=False if removed else None
            if fd is not None:attempt('owned handle close',lambda:os.close(fd))
            attempt('umask restoration',lambda:os.umask(old_umask))
            report['cleanup_completed']=not report['cleanup_errors']
            report['elapsed_s']=time.monotonic()-started
            attempt('report publication',lambda:write_json(output/'report.json',report))
        if primary is None and cleanup_error is not None:raise cleanup_error
    if not report['passed']:raise RuntimeError('ranked fixture evidence did not pass')
    return report


def main():
    try:
        with termination_signals():result=collect(sys.argv[1])
    except BaseException as error:
        # Never print tokenizer/data exception bodies into public raw logs.
        print(json.dumps(dict(passed=False,error_type=type(error).__name__)))
        return 130 if isinstance(error,KeyboardInterrupt) else (error.code if isinstance(error,SystemExit) and type(error.code)is int and error.code!=0 else 1)
    print(json.dumps(dict(passed=result['passed'],cases=len(result['cases']),source_archive_sha256=result['source_archive_sha256'])))
    return 0 if result['passed'] is True and result['terminal_scope_completed'] is True else 1
if __name__=='__main__':raise SystemExit(main())
