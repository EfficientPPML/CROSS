from contextlib import contextmanager,nullcontext
from pathlib import Path
import hashlib,json,os,random,sys
import numpy as np
import pytest
import build_ranked as f


def rows():return [dict(idx=9000+i,label=i%2,sentence1='Synthetic first '+str(i),sentence2='Synthetic second '+str(i)) for i in range(408)]


class Tokenizer:
    def __init__(self):self.calls=[]
    def __call__(self,a,b,**kwargs):
        self.calls.append((a,b,kwargs));i=int(a.rsplit(' ',1)[1]);count=2+i%126
        return dict(input_ids=[101]+[102+i%100]*(count-1)+[0]*(128-count),
                    token_type_ids=[0]*128,attention_mask=[1]*count+[0]*(128-count))
    def encode_plus(self,a,b,**kwargs):return self(a,b,**kwargs)


@pytest.fixture(autouse=True)
def no_real_asset_reads(monkeypatch):
    original=f.base.sha
    def guarded(path):
        p=Path(path)
        if p==f.base.DATA or f.base.MODEL in p.parents:raise AssertionError('no dataset/model/tokenizer payload reads in mock preflight')
        return original(p)
    monkeypatch.setattr(f.base,'sha',guarded)


@pytest.mark.parametrize('size,count,seed',f.SCHEDULE)
def test_nine_exact_upstream_cases_and_private_permissions(tmp_path,size,count,seed):
    root=tmp_path/'private';root.mkdir(mode=0o700);tokenizer=Tokenizer()
    result=f.prepare_case(root,rows(),tokenizer,size=size,seed=seed)
    derived=f.base.upstream_seed(seed)
    selected=list(range(408)) if count==408 else sorted(random.Random(derived).sample(range(408),count))
    output=[json.loads(line) for line in Path(result['preprocessed_input_path']).read_text().splitlines()]
    assert [r['target_idx'] for r in output]==[9000+i for i in selected]
    assert result['record_count']==count and len(tokenizer.calls)==2*count
    assert result['private_target_order_sha256']==hashlib.sha256(json.dumps([9000+i for i in selected]).encode()).hexdigest()
    assert result['selection_byte_parity'] and result['tokenization_byte_parity']
    assert result['all_private_files_0600'] and result['all_private_directories_0700']
    assert sum(result['valid_token_count_histogram'].values())==count
    public=json.dumps(result)
    assert all(word not in public for word in ('Synthetic first','Synthetic second','target_ids','row_ordinals'))
    assert all(call[2]==dict(max_length=128,padding='max_length',truncation=True) for call in tokenizer.calls)
    private=json.loads((root/'private_selection.json').read_text())
    assert private['row_ordinals']==selected and private['labels']==[i%2 for i in selected]


def test_all408_seed_repetitions_have_identical_bytes_and_order(tmp_path):
    results=[]
    for seed in (42,43,44):
        root=tmp_path/str(seed);root.mkdir();results.append(f.prepare_case(root,rows(),Tokenizer(),size=3,seed=seed))
    assert len({r['private_target_order_sha256'] for r in results})==1
    assert len({f.base.sha(Path(r['preprocessed_input_path'])) for r in results})==1
    assert len({r['generator_seed'] for r in results})==3


@pytest.mark.parametrize('size,seed',[(True,42),(0,42),(100,42),(1,True),(1,41),(1,42.0)])
def test_exact_public_case_types(size,seed):
    with pytest.raises(ValueError):f.validate_case(size,seed)


def test_seed_body_matches_pcg64_for_all_three():
    assert [f.base.upstream_seed(s) for s in (42,43,44)]==[int(np.random.Generator(np.random.PCG64(s)).integers(0,2147483647)) for s in (42,43,44)]


def test_upstream_copies_and_original_size0_are_exact():
    origin=json.loads((f.ROOT/'upstream_origin.json').read_text())
    assert {name:f.base.sha(f.ROOT/'upstream'/name) for name in origin}=={name:x['sha256'] for name,x in origin.items()}
    for name,record in json.loads((f.ROOT/'origin.json').read_text()).items():assert f.base.sha(f.ROOT/name)==record['sha256']


def test_guard_denies_model_construction_and_forward_and_restores():
    import torch
    from transformers import PreTrainedModel
    previous=(PreTrainedModel.__init__,torch.nn.Module.__call__)
    with f.no_model_execution():
        with pytest.raises(RuntimeError):PreTrainedModel.__init__(None)
        with pytest.raises(RuntimeError):torch.nn.Module.__call__(None)
    assert previous==(PreTrainedModel.__init__,torch.nn.Module.__call__)


def test_guard_install_mutates_then_raises_and_restores(monkeypatch):
    import builtins,torch
    from transformers import PreTrainedModel
    original=(PreTrainedModel.__init__,torch.nn.Module.__call__);called=[]
    error=KeyboardInterrupt('installation interrupted after mutation')
    def setter(owner,name,value):
        builtins.setattr(owner,name,value)
        if owner is torch.nn.Module and name=='__call__' and not called:
            called.append(True);raise error
    monkeypatch.setattr(f,'setattr',setter,raising=False)
    with pytest.raises(KeyboardInterrupt) as caught:
        with f.no_model_execution():pytest.fail('body must not run')
    assert caught.value is error
    assert original==(PreTrainedModel.__init__,torch.nn.Module.__call__)


def test_guard_restore_attempts_all_and_preserves_body_primary(monkeypatch):
    import builtins,torch
    from transformers import PreTrainedModel
    original=(PreTrainedModel.__init__,torch.nn.Module.__call__);restored=[]
    primary=SystemExit(143)
    def setter(owner,name,value):
        builtins.setattr(owner,name,value)
        if value in original:
            restored.append(name)
            if name=='__call__':raise OSError('restoration observed failure')
    monkeypatch.setattr(f,'setattr',setter,raising=False)
    with pytest.raises(SystemExit) as caught:
        with f.no_model_execution():raise primary
    assert caught.value is primary and restored==['__call__','__init__']
    assert original==(PreTrainedModel.__init__,torch.nn.Module.__call__)


def setup_collect(tmp_path,monkeypatch):
    root=tmp_path/'lab';root.mkdir();source=root/'source.py';source.write_text('x=1\n')
    origin=f.ROOT/'upstream_origin.json';(root/'upstream_origin.json').write_bytes(origin.read_bytes())
    monkeypatch.setattr(f,'ROOT',root)
    monkeypatch.setattr(f,'source_paths',lambda:{'source.py':source})
    monkeypatch.setattr(f,'asset_hashes',lambda:{'public-asset':'a'*64})
    def private(parent):
        p=root/'private-workspace';p.mkdir(mode=0o700);return str(p)
    monkeypatch.setattr(f.tempfile,'mkdtemp',lambda **kwargs:private(root))
    monkeypatch.setattr(f.importlib.metadata,'version',lambda name:'mock-version')
    return root


def mock_prepare(workspace):
    (workspace/'sensitive.txt').write_text('private synthetic fixture');(workspace/'sensitive.txt').chmod(0o600)
    return [dict(all_private_files_0600=True,all_private_directories_0700=True) for _ in range(9)]


def test_collect_success_retains_only_private_workspace_and_complete_scope(tmp_path,monkeypatch):
    root=setup_collect(tmp_path,monkeypatch);monkeypatch.setattr(f,'prepare',mock_prepare)
    result=f.collect(root/'out')
    assert result['passed'] and result['terminal_scope_completed'] and result['cleanup_completed']
    assert result['private_workspace_retained'] and Path(result['private_workspace']).exists()
    assert 'private synthetic fixture' not in (root/'out/report.json').read_text()


def test_initial_publication_failure_still_records_failed_attempt(tmp_path,monkeypatch):
    root=setup_collect(tmp_path,monkeypatch);original=f.write_json;calls=[]
    def write(path,value):
        calls.append(1)
        if len(calls)==1:raise OSError('first publication')
        return original(path,value)
    monkeypatch.setattr(f,'write_json',write)
    with pytest.raises(OSError):f.collect(root/'out')
    report=json.loads((root/'out/report.json').read_text())
    assert not report['passed'] and not (root/'private-workspace').exists()


def test_primary_preparation_cancel_preserved_and_owned_private_removed(tmp_path,monkeypatch):
    root=setup_collect(tmp_path,monkeypatch);failure=KeyboardInterrupt('private detail not for public report')
    def fail(workspace):mock_prepare(workspace);raise failure
    monkeypatch.setattr(f,'prepare',fail)
    with pytest.raises(KeyboardInterrupt) as caught:f.collect(root/'out')
    assert caught.value is failure
    report=json.loads((root/'out/report.json').read_text())
    assert not report['passed'] and report['private_workspace_removed_on_failure']
    assert 'private detail' not in (root/'out/report.json').read_text()


def test_terminal_shield_failure_invalidates_persisted_success(tmp_path,monkeypatch):
    root=setup_collect(tmp_path,monkeypatch);monkeypatch.setattr(f,'prepare',mock_prepare)
    @contextmanager
    def shield():
        yield
        raise RuntimeError('shield exit')
    monkeypatch.setattr(f,'cleanup_signals',shield)
    with pytest.raises(RuntimeError):f.collect(root/'out')
    report=json.loads((root/'out/report.json').read_text())
    assert not report['passed'] and not report['terminal_scope_completed'] and report['terminal_failure_republished']
    assert report['private_workspace_retained']  # It really was retained before shield failure.


def test_final_publication_failure_does_not_replace_primary(tmp_path,monkeypatch):
    root=setup_collect(tmp_path,monkeypatch);failure=SystemExit(143)
    def fail(workspace):raise failure
    monkeypatch.setattr(f,'prepare',fail);original=f.write_json;calls=[]
    def write(path,value):
        calls.append(1)
        if len(calls)>1:raise OSError('final write')
        return original(path,value)
    monkeypatch.setattr(f,'write_json',write)
    with pytest.raises(SystemExit) as caught:f.collect(root/'out')
    assert caught.value is failure and caught.value.__notes__


def test_existing_evidence_and_external_output_refused(tmp_path,monkeypatch):
    root=setup_collect(tmp_path,monkeypatch);(root/'existing').mkdir();(root/'existing/sentinel').write_text('keep')
    with pytest.raises(FileExistsError):f.collect(root/'existing')
    with pytest.raises(ValueError):f.collect(tmp_path/'outside')
    assert (root/'existing/sentinel').read_text()=='keep' and not (tmp_path/'outside').exists()


def test_changed_source_archive_fails_before_private_retention(tmp_path,monkeypatch):
    root=setup_collect(tmp_path,monkeypatch)
    def prepare(workspace):
        result=mock_prepare(workspace);(root/'out/sources.tar.gz').write_bytes(b'changed archive')
        return result
    monkeypatch.setattr(f,'prepare',prepare)
    with pytest.raises(f.tarfile.ReadError):f.collect(root/'out')
    report=json.loads((root/'out/report.json').read_text())
    assert report['passed'] is False and report['source_archive_verified'] is False
    assert report['private_workspace_removed_on_failure'] is True


def test_main_system_exit_zero_failure_cannot_report_success(monkeypatch,capsys):
    monkeypatch.setattr(f.sys,'argv',['build_ranked.py','unused'])
    def fail(output):raise SystemExit(0)
    monkeypatch.setattr(f,'collect',fail)
    assert f.main()==1 and json.loads(capsys.readouterr().out)['passed'] is False


@pytest.mark.parametrize('passed,terminal,code',[(True,True,0),(False,True,1),(True,False,1)])
def test_main_requires_success_and_completed_terminal_scope(monkeypatch,capsys,passed,terminal,code):
    monkeypatch.setattr(f.sys,'argv',['build_ranked.py','unused'])
    monkeypatch.setattr(f,'collect',lambda output:dict(passed=passed,terminal_scope_completed=terminal,cases=[],source_archive_sha256='a'*64))
    assert f.main()==code
