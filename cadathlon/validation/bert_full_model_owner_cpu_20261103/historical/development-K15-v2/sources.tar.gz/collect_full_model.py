"""Immutable-source ideal joined BERT graph collector; no encrypted execution."""
from pathlib import Path
import argparse,contextlib,hashlib,importlib.metadata,io,json,os,signal,subprocess,sys,tarfile,time
import xml.etree.ElementTree as ET
HERE=Path(__file__).resolve().parent
ROOT_FILES=('encrypted_bert_full_model.py','full_model_fixtures.py','test_full_model_owner.py','collect_full_model.py',
 'full_model_reference.py','encrypted_bert_layer_attention.py','layer_attention_contract.py','server_public_model.py',
 'ideal_primitives.py','ideal_refresh.py','test_initial_ideal.py','test_softmax_tile.py','lifecycle.py',
 'candidate_manifest.json','actual_profile_audit.json','p60_profile_and_refresh.json','matrix_inventory.json',
 'verified_model_manifest.json','source_origin.json','prerequisites.json')
MODEL=Path('/home/jianming_gatech/cross_validation_assets/bert/f150c1d609d1e50dd5e2e5408661cfac8339277c/model.safetensors')
MODEL_SHA='e1f8085ef673c9eb8a1a93a84270742e8aa0ccbceadef01eef15e26c44b46034'
NATIVE_SHA='758ff5d71fa3c836f74a974dee97c4a744e17ea283047e2abe15b4675edc202a'


def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def write(path,value):
    target=path.with_suffix('.tmp');target.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');target.replace(path)
def source_bytes(root=HERE):
    paths=[root/n for n in ROOT_FILES]+sorted((root/'checkout').rglob('*.py'))+sorted((root/'evidence_inputs').glob('*.json'))
    return {str(p.relative_to(root)):p.read_bytes() for p in paths}
def hashes(data):return {n:hashlib.sha256(v).hexdigest() for n,v in data.items()}
def make_archive(path,data):
    with tarfile.open(path,'w:gz') as tar:
        for n,b in data.items():
            member=tarfile.TarInfo(n);member.size=len(b);tar.addfile(member,io.BytesIO(b))
def verify_archive(path,before):
    with tarfile.open(path) as tar:
        rows=tar.getmembers()
        return (len(rows)==len(before)==len({m.name for m in rows}) and all(m.isfile() for m in rows)
                and {m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in rows}==before)
def prerequisite_gate(data):
    pins=json.loads(data['prerequisites.json'])
    for name,expected in pins['frozen_files'].items():
        if name not in data or hashlib.sha256(data[name]).hexdigest()!=expected:raise ValueError('frozen prerequisite differs: '+name)
    for role,row in pins['prerequisites'].items():
        report=json.loads(data[row['report_name']])
        if (not all(report.get(k) is True for k in ('passed','source_files_unchanged','source_archive_verified','asset_files_unchanged','test_child_reaped'))
                or report.get('cleanup_errors')!=[] or report['source_hashes_before']!=report['source_hashes_after']
                or report['source_archive_sha256']!=row['archive_sha256']):raise ValueError('failed prerequisite: '+role)
        archive=Path(row['archive_path'])
        if sha(archive)!=row['archive_sha256'] or not verify_archive(archive,report['source_hashes_before']):raise ValueError('prerequisite archive differs: '+role)
    if json.loads(data[pins['prerequisites']['native']['report_name']])['fixture_npz_sha256']!=NATIVE_SHA:raise ValueError('native fixture differs')
    return pins


@contextlib.contextmanager
def termination_signals():
    old={}
    def interrupted(signum,frame):raise SystemExit(128+signum)
    try:
        for signum in (signal.SIGTERM,signal.SIGHUP):old[signum]=signal.signal(signum,interrupted)
        yield
    finally:
        for signum,handler in old.items():signal.signal(signum,handler)

def group_alive(pid):
    try:os.killpg(pid,0);return True
    except ProcessLookupError:return False

def reap(child):
    if child is None:return dict(entered=False,reaped=True,group_gone=True)
    survived_leader=child.poll() is not None and group_alive(child.pid)
    if group_alive(child.pid):
        try:os.killpg(child.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        try:child.wait(timeout=5)
        except subprocess.TimeoutExpired:pass
        until=time.monotonic()+2
        while group_alive(child.pid) and time.monotonic()<until:time.sleep(.02)
        if group_alive(child.pid):
            try:os.killpg(child.pid,signal.SIGKILL)
            except ProcessLookupError:pass
    child.wait(timeout=30)
    gone=not group_alive(child.pid)
    if not gone:raise RuntimeError('owned test process group survives cleanup')
    if survived_leader:raise RuntimeError('owned test descendants outlived normal leader; group cleaned')
    return dict(entered=True,pid=child.pid,exit_code=child.returncode,reaped=True,group_gone=gone)


def run(output,selection=None):
    output=output.resolve();output.mkdir(exist_ok=False);started=time.monotonic();child=None;primary=None;cancel=None
    before={};assets_before={};cleanup=[];snapshot=output/'snapshot';snapshot.mkdir();pins=None
    native=HERE/'client_native_full.npz';asset_paths={'public_checkpoint':MODEL,'private_original_native_fixture':native}
    report=dict(passed=False,complete=False,scope='Actual joined twelve-layer owner, ideal slot/metadata primitives and identity refresh; no HE, five-handler, ranked or timing claim.',
        requested_cases=[15,128],selection=selection,ideal_all_slot_gate=1e-7,native_P2_gate='abs(error)<=0.02+0.01*abs(native)',
        source_count=0,cases=[],raw_arrays_archived=False,only_initial_embeddings_supplied=True,cpu_affinity=sorted(os.sched_getaffinity(0)))
    def attempt(label,action):
        nonlocal cancel
        try:return action()
        except BaseException as error:
            cleanup.append(dict(operation=label,type=type(error).__name__,message=str(error)))
            if primary is not None:primary.add_note(label+': '+repr(error))
            elif not isinstance(error,Exception) and cancel is None:cancel=error
            return None
    try:
        write(output/'report.json',report)
        data=source_bytes();before=hashes(data);make_archive(output/'sources.tar.gz',data)
        if not verify_archive(output/'sources.tar.gz',before):raise ValueError('source archive readback differs')
        pins=prerequisite_gate(data)
        for name,raw in data.items():
            path=snapshot/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
        if hashes(source_bytes(snapshot))!=before:raise ValueError('snapshot source differs')
        assets_before={n:sha(p) for n,p in asset_paths.items()}
        if assets_before!={'public_checkpoint':MODEL_SHA,'private_original_native_fixture':NATIVE_SHA}:raise ValueError('fixed asset differs')
        env=dict(os.environ,BERT_FULL_NATIVE_FIXTURE=str(native),OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',MKL_NUM_THREADS='4',PYTHONHASHSEED='0',JAX_PLATFORMS='cpu')
        env.pop('PYTHONPATH',None)
        command=[sys.executable,'-m','pytest','-q','--tb=short',str(snapshot/'test_full_model_owner.py'),'--junitxml='+str(output/'tests.xml')]
        if selection:command+=['-k',selection]
        report.update(source_count=len(before),source_hashes_before=before,source_archive_sha256=sha(output/'sources.tar.gz'),asset_hashes_before=assets_before,
            versions={n:importlib.metadata.version(n) for n in ('numpy','scipy','pytest')},command=command,
            environment={n:env.get(n) for n in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','PYTHONHASHSEED','JAX_PLATFORMS','BERT_FULL_NATIVE_FIXTURE')})
        write(output/'report.json',report)
        with (output/'tests.log').open('wb') as log:
            child=subprocess.Popen(command,cwd=snapshot,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            report['child_pid']=child.pid;write(output/'report.json',report)
            report['test_exit_code']=child.wait()
        suites=ET.parse(output/'tests.xml').getroot().findall('testsuite')
        report['tests']={n:sum(int(s.attrib.get(n,0)) for s in suites) for n in ('tests','errors','failures','skipped')}
        for K in (15,128):
            progress_path=snapshot/f'joined-progress-K{K}.jsonl'
            if progress_path.exists():(output/progress_path.name).write_bytes(progress_path.read_bytes())
            path=snapshot/f'joined-K{K}.json'
            if path.exists():
                row=json.loads(path.read_text());report['cases'].append(row);write(output/f'joined-K{K}.json',row)
        if (report['test_exit_code']!=0 or any(report['tests'][n] for n in ('errors','failures','skipped'))):raise ValueError('joined ideal tests failed')
        report['complete']=selection is None and len(report['cases'])==2 and {x['K'] for x in report['cases']}=={15,128} and all(x.get('passed') is True for x in report['cases'])
        report['passed']=bool(report['complete'])
    except BaseException as error:
        primary=error;report.update(passed=False,error=dict(type=type(error).__name__,message=str(error)))
    finally:
        process=attempt('reap owned test process group',lambda:reap(child))
        after=attempt('original source readback',lambda:hashes(source_bytes()))
        snap_after=attempt('snapshot source readback',lambda:hashes(source_bytes(snapshot)))
        assets_after=attempt('fixed asset readback',lambda:{n:sha(p) for n,p in asset_paths.items()})
        archived=attempt('archive readback',lambda:verify_archive(output/'sources.tar.gz',before)) if before else False
        report.update(source_hashes_after=after,snapshot_source_hashes_after=snap_after,source_files_unchanged=bool(before) and before==after==snap_after,
            source_archive_verified=archived is True,asset_hashes_after=assets_after,asset_files_unchanged=bool(assets_before) and assets_before==assets_after,
            process_cleanup=process,cleanup_errors=cleanup,elapsed_s=time.monotonic()-started)
        report['passed']=bool(report.get('passed') and report['source_files_unchanged'] and report['asset_files_unchanged'] and archived and not cleanup and process and process['reaped'] and process['group_gone'])
        try:write(output/'report.json',report)
        except BaseException as error:
            keep=primary if primary is not None else cancel
            if keep is None:raise
            keep.add_note('final report publication: '+repr(error))
        if primary is not None:raise primary
        if cancel is not None:raise cancel
    print(json.dumps({n:report[n] for n in ('passed','complete','tests','elapsed_s','source_archive_sha256')}))
    return 0 if report['passed'] else 1

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--selection');args=parser.parse_args()
    with termination_signals():raise SystemExit(run(args.output,args.selection))
