"""Joined full-width graph tests using ideal primitives, never HE evidence."""
from pathlib import Path
from collections import Counter
from types import SimpleNamespace
import copy,hashlib,json,math,time,os
import numpy as np
import pytest
from test_initial_ideal import ideal_primitives
from test_softmax_tile import refresh_and_tracked
from ideal_refresh import IdentityRefresh,install_public_bootstrap_plan
from ideal_primitives import Arithmetic,Value,IdealLinear,install_matrix_class,DELTA
from encrypted_bert_attention_tile import BertAttentionTile
from encrypted_bert_all_row_norm import BertRowLayerNorm
from encrypted_bert_layer_attention import BertLayerAttention
from encrypted_bert_all_ffn import BertFFNTile
from encrypted_bert_pooler_head import BertPoolerHead
from encrypted_bert_full_model import BertFullModel
from full_model_fixtures import load
import full_model_reference as reference
HERE=Path(__file__).resolve().parent;RAW=(HERE/'candidate_manifest.json').read_bytes();MANIFEST=json.loads(RAW)

@pytest.fixture(autouse=True)
def primitives(refresh_and_tracked,monkeypatch):
    install_matrix_class(monkeypatch);install_public_bootstrap_plan(monkeypatch)
    from test_initial_ideal import Value as BaseValue
    BaseValue.degree_layout=(256,512)
    import encrypted_bert_rational_tanh as tanh
    import encrypted_scaled_newton as newton
    monkeypatch.setattr(tanh,'integer_affine',newton.integer_affine)

@pytest.fixture(scope='module')
def fixtures():
    weights,native,report=load();(HERE/'fixture_pins.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    return weights,native

def setup(fixtures,K=15,progress=None):
    weights,native=fixtures;ops=Arithmetic();refresh=IdentityRefresh(ops);linear=IdealLinear(ops);cache=ops.ctx._param_cache
    keys=set(BertAttentionTile.required_rotation_indices())|set(BertRowLayerNorm.required_rotation_indices())
    for a in weights.values():
        if a.ndim==2:keys.update(linear.required_rotation_indices(a,linear.layout))
    for key in keys:
        if key not in cache.raw_rotation_keys:cache.raw_rotation_keys[key]={'a':object(),'b':object()};cache.coef_maps[key]=object()
    cache.eval_key_a_full=SimpleNamespace(shape=(8,131072,114),dtype=np.dtype('uint32'))
    cache.eval_key_b_full=SimpleNamespace(shape=(8,131072,114),dtype=np.dtype('uint32'))
    positions=tuple(map(int,native[f'K{K}_positions']))
    owner=BertFullModel(ops,linear,refresh,weights,RAW,original_positions=positions,context_id='a'*64,request_id='b'*32,progress=progress)
    packed=np.zeros((128,4096));packed[:,:768]=native[f'K{K}_embeddings']
    sources=tuple(Value(row.reshape(-1),49,DELTA) for row in packed.reshape(8,16,4096))
    return owner,ops,refresh,sources

@pytest.mark.parametrize('during_callback',[False,True])
def test_callback_factory_binding_is_fixed(fixtures,during_callback):
    box={}
    def progress(*args):box['owner']._callback_bound=lambda *args:None
    owner,ops,refresh,sources=setup(fixtures,progress=progress if during_callback else None);box['owner']=owner
    if during_callback:
        with pytest.raises(ValueError):owner._callback('probe',Value(np.zeros(65536)),{})
    else:
        owner._callback_bound=lambda *args:None
        with pytest.raises(ValueError):owner._guard()
    assert not ops.calls and not refresh.calls

@pytest.mark.parametrize('kind',['ctx_secret','cache_secret','parameters_secret','callback','positions','contract','scale','keys','map','eval_none','eval_placeholder','eval_dtype','context','bound_owner','source_nsd','source_scale','source_level','capture'])
def test_entry_guards_before_primitives(fixtures,kind):
    owner,ops,refresh,sources=setup(fixtures);capture=False;cache=ops.ctx._param_cache
    if kind=='ctx_secret':ops.ctx.secret_key=object()
    elif kind=='cache_secret':cache.secret_key=object()
    elif kind=='parameters_secret':ops.ctx.parameters['secret_key']=object()
    elif kind=='callback':owner._callback_bound=lambda *a:None
    elif kind=='positions':owner.original_positions=tuple(float(x) for x in owner.original_positions)
    elif kind=='contract':owner.contracts[0]['key_count']=1
    elif kind=='scale':ops.scale*=2
    elif kind=='keys':cache.raw_rotation_keys[owner.required_keys[0]]['a']=object()
    elif kind=='map':cache.coef_maps[owner.required_keys[0]]=object()
    elif kind=='eval_none':cache.eval_key_a_full=None
    elif kind=='eval_placeholder':cache.eval_key_a_full=SimpleNamespace(shape=(1,),dtype=np.dtype('uint32'))
    elif kind=='eval_dtype':cache.eval_key_a_full.dtype=np.dtype('float32')
    elif kind=='context':owner.ctx=Arithmetic().ctx
    elif kind=='bound_owner':ops.declare_bound=lambda *a:None
    elif kind=='source_nsd':sources[0]._ckks_nsd=True
    elif kind=='source_scale':sources[0]._ckks_scale=math.nextafter(DELTA,math.inf)
    elif kind=='source_level':sources[0].level=48
    else:capture=1
    with pytest.raises((ValueError,TypeError)):owner.evaluate(sources,capture_checkpoints=capture)
    assert not ops.calls and not refresh.calls and not owner._active

@pytest.mark.parametrize('kind',['current','original','captured','sibling','callback','key','reentry','cancel'])
def test_callback_lifetime_guards_without_full_graph(fixtures,kind):
    state={};seen=[];error=KeyboardInterrupt('same primary')
    def progress(*args):
        owner=state['owner'];value=args[1];seen.append(len(state['ops'].calls))
        if kind=='current':value._ckks_nsd=True
        elif kind=='original':state['sources'][0]._ckks_nsd=True
        elif kind=='captured':state['captured']._ckks_nsd=True
        elif kind=='sibling':state['sibling']._ckks_nsd=True
        elif kind=='callback':owner._callback_bound=lambda *a:None
        elif kind=='key':owner.ctx._param_cache.raw_rotation_keys[owner.required_keys[0]]['b']=object()
        elif kind=='reentry':owner.evaluate(state['sources'])
        else:raise error
    owner,ops,refresh,sources=setup(fixtures,progress=progress);state.update(owner=owner,ops=ops,sources=sources)
    captured=Value(np.zeros(65536),3);sibling=Value(np.zeros(65536),5);state.update(captured=captured,sibling=sibling)
    owner._inputs=sources;owner._input_states=tuple(owner._fingerprint(v) for v in sources)
    owner._captured=[(captured,owner._fingerprint(captured))];owner._live=[(sibling,owner._fingerprint(sibling))];owner._active=True
    with pytest.raises(KeyboardInterrupt if kind=='cancel' else (ValueError,TypeError)) as caught:owner._callback('probe',Value(np.zeros(65536)),{})
    if kind=='cancel':assert caught.value is error
    assert seen==[0] and not ops.calls and not refresh.calls


@pytest.mark.parametrize('kind',['cancel','reentry'])
def test_outer_evaluate_releases_borrowers_after_callback(fixtures,kind):
    state={};primary=KeyboardInterrupt('preserved primary');seen=[]
    def progress(*args):
        seen.append(args[0])
        if kind=='cancel':raise primary
        state['owner'].evaluate(state['sources'])
    owner,ops,refresh,sources=setup(fixtures,progress=progress)
    state.update(owner=owner,sources=sources)
    source_states=tuple(owner._fingerprint(v) for v in sources)
    with pytest.raises(KeyboardInterrupt if kind=='cancel' else ValueError) as caught:
        owner.evaluate(sources,capture_checkpoints=True)
    if kind=='cancel':assert caught.value is primary
    assert len(seen)==1 and ops.calls
    assert not owner._active and not owner._inputs and not owner._input_states
    assert not owner._live and not owner._captured and not owner._children and not owner._child_state
    assert owner._progress_stage is None and owner.last_run is None
    assert tuple(owner._fingerprint(v) for v in sources)==source_states
    assert owner.arithmetic is ops and owner.refresher is refresh


def operation_plan(weights,K):
    from encrypted_packed_qwen import MatrixDiagonals
    from encrypted_chained_streaming_linear import linear_rotation_plan
    T=math.ceil(K/16);total=Counter();refreshes=3;layers=[]
    def matrix(value):
        source=MatrixDiagonals(value,65536,4096);plan=linear_rotation_plan(source,strategy='chained')
        return dict(rotations=plan.nonzero_rotation_calls,diagonals=len(source.active),groups=len({x//source.n1 for x in source.active}))
    def terms(rule):
        degree=rule['polynomial']['degree'];method=rule['method']
        coefficients=np.polynomial.chebyshev.cheb2poly(rule['polynomial']['coefficients'])
        indices=[i for i in range(1,len(coefficients)) if coefficients[i]!=0] if method=='power' else list(range(1,degree+1))
        powers={1}
        def visit(n):
            if n not in powers:visit(n//2);visit((n+1)//2);powers.add(n)
        for n in indices:visit(n)
        return len(powers)-1,len(indices),degree
    for layer in range(12):
        n=MANIFEST['normalization_reciprocal_by_public_K'][str(K)]['iterations'];s=MANIFEST['softmax'][str(layer)]['squarings']
        products,count,_=terms(MANIFEST['norms'][f'{layer}.attention']);maps=16+2*T
        row=Counter(rotate=86*maps+T*(8656+28+14*s+42),multiply=T*(256+18+2*n*s+products+2),
            pt_products=1535*maps+T*(7168+17+3*s+4+count),rescales=24*maps+T*(768+27+(2*n+3)*s+products+7))
        level=23 if layer==0 else 6;soft_refresh=int(layer!=0)+1
        for _ in range(s):
            if level<n+7:level=25;soft_refresh+=1
            level-=n+5;assert level>=2
        refreshes+=T*(soft_refresh+2+int(layer!=0))
        prefix=f'bert.encoder.layer.{layer}.';matrices=[matrix(weights[prefix+name+'.weight']) for name in ('intermediate.dense','output.dense')]
        rotations=sum(x['rotations'] for x in matrices);groups=sum(x['groups'] for x in matrices);diagonals=sum(x['diagonals'] for x in matrices)
        norm=MANIFEST['norms'][f'{layer}.mlp'];p,count,d=terms(norm);g=MANIFEST['gelu'][str(layer)]['degree']
        corrections=0 if norm['method']=='power' else d-1
        normterms=4+count+(0 if norm['method']=='power' else sum(1 if i%2==0 else 2 for i in range(2,d+1)))
        geluterms=1+g+sum(1 if i%2==0 else 2 for i in range(2,g+1))
        weighted=groups+g+1+5+corrections;mult=g-1+p+2
        row.update(rotate=T*(rotations+42),multiply=T*mult,pt_products=T*(diagonals+geluterms+normterms),rescales=T*(weighted+mult))
        total.update(row);layers.append(dict(layer=layer,counts=dict(row),softmax_refreshes_per_tile=soft_refresh))
    head=[matrix(weights[name]) for name in ('bert.pooler.dense.weight','classifier.weight')]
    total.update(rotate=sum(x['rotations'] for x in head),multiply=68,pt_products=sum(x['diagonals'] for x in head)+13,
                 rescales=sum(x['groups'] for x in head)+76)
    return dict(counts=dict(total),identity_refreshes=refreshes,layers=layers,full_refresh_cost_included=False)


def observe_domains(K):
    observations=[];score_tiles=Counter()
    def add(label,value,domain):
        a=np.asarray(value);lo,hi=domain;finite=np.isfinite(a)
        row=dict(label=label,domain=list(domain),count=int(a.size),minimum=float(a.min()) if finite.all() else None,
                 maximum=float(a.max()) if finite.all() else None,passed=bool(finite.all() and np.all(a>=lo) and np.all(a<=hi)))
        observations.append(row);assert row['passed'],row
    def progress(label,value,counts):
        import re
        layer_match=re.match(r'layer(\d+)\.',label);layer=int(layer_match[1]) if layer_match else None
        if label.endswith(' / all-key scores'):
            tile=score_tiles[layer];score_tiles[layer]+=1;valid=min(16,K-16*tile)
            scores=value.data.reshape(16,4096)[:valid,:2048].reshape(valid,128,16)[:,:K,:12]
            add(label,scores-scores.mean(axis=1,keepdims=True),MANIFEST['softmax'][str(layer)]['centered_domain'])
        elif label.endswith(' normalized_t') or label.endswith(' refreshed_normalized_t'):
            add(label,value.data,[-1.,1.])
        elif label.endswith(' mean_exp'):
            add(label,value.data,MANIFEST['initial_reciprocal']['domain'])
        elif label.endswith('normalization round denominator'):
            add(label,value.data,MANIFEST['normalization_reciprocal_by_public_K'][str(K)]['domain'])
        elif re.search(r'layer \d+\.(attention|mlp) variance$',label):
            site=re.search(r'layer (\d+\.(?:attention|mlp)) variance$',label)[1]
            add(label,value.data,MANIFEST['norms'][site]['polynomial']['domain'])
        elif label.endswith('FFN intermediate dense'):
            add(label,value.data,MANIFEST['gelu'][str(layer)]['polynomial']['domain'])
        elif label.endswith('head pooler dense'):
            add(label,value.data,MANIFEST['tanh']['domain'])
        elif re.search(r'head round\d+\.denominator$',label):
            add(label,value.data,MANIFEST['tanh_reciprocal']['domain'])
    return progress,observations,score_tiles


@pytest.mark.parametrize('K',(15,128))
def test_joined_all12_actual_ciphertext_connections_all_slots(fixtures,monkeypatch,K):
    weights,native=fixtures;started=time.monotonic();domain_callback,domains,score_tiles=observe_domains(K)
    retained=[];box={};trace={'attention':{},'ffn':{},'head':None};stages=[]
    progress_path=HERE/f'joined-progress-K{K}.jsonl'
    with progress_path.open('x'):pass
    def progress(label,value,counts):
        domain_callback(label,value,counts)
        if re.fullmatch(r'layer\d+\.(attention|ffn(?:\.\d+)?) / layer\d+\.(attention|block)\.\d+',label):
            with progress_path.open('a') as stream:stream.write(json.dumps(dict(label=label,level=value.level,elapsed_s=time.monotonic()-started))+'\n')
        if label.endswith(' / output') or re.match(r'layer\d+\.(attention|ffn(?:\.\d+)?) / layer\d+\.(attention|block)\.\d+$',label):retained.append(value)
        value._public_unjustified=0.
        for earlier in retained:earlier._public_callback_added=0.
    import re
    owner,ops,refresh,sources=setup(fixtures,K,progress);box['owner']=owner
    original=[x.data.copy() for x in sources]
    for source in sources:source._public_borrowed='preserve'
    def check_refresh_bound(src,out):
        bound=refresh.calls[-1][2]
        row=dict(label='refresh bound',domain=[-bound,bound],minimum=float(src.data.min()),
            maximum=float(src.data.max()),count=65536,passed=bool(np.isfinite(src.data).all() and np.all(np.abs(src.data)<=bound)))
        domains.append(row);assert row['passed'],row
    refresh.inject=check_refresh_bound
    attention_impl=BertLayerAttention.evaluate;ffn_impl=BertFFNTile.evaluate_tile;head_impl=BertPoolerHead.evaluate_tile
    def attention(child,inputs):
        expected=sources if child.layer==0 else tuple(trace['ffn'][child.layer-1])
        assert len(inputs)==len(expected) and all(a is b for a,b in zip(inputs,expected))
        result=attention_impl(child,inputs);trace['attention'][child.layer]=result.outputs;return result
    def ffn(child,value):
        sequence=trace['ffn'].setdefault(child.layer,[]);assert value is trace['attention'][child.layer][len(sequence)]
        result=ffn_impl(child,value);sequence.append(result.output);return result
    def head(child,value,**kwargs):
        assert value is trace['ffn'][11][0];trace['head']=value
        return head_impl(child,value,**kwargs)
    monkeypatch.setattr(BertLayerAttention,'evaluate',attention);monkeypatch.setattr(BertFFNTile,'evaluate_tile',ffn);monkeypatch.setattr(BertPoolerHead,'evaluate_tile',head)
    oracle=reference.compute(native[f'K{K}_embeddings'][:K],weights,RAW,approximate=True)
    plan=operation_plan(weights,K)
    result=owner.evaluate(sources,capture_checkpoints=True)
    errors=[];T=math.ceil(K/16)
    for layer in range(12):
        for phase,expected_rows in (('attention',oracle['attention_outputs'][layer]),('block',oracle['block_outputs'][layer])):
            maximum=0.
            for tile in range(T):
                start=16*tile;valid=min(16,K-start);expected=np.zeros((16,4096));expected[:valid,:768]=expected_rows[start:start+valid]
                actual=result.checkpoints[f'layer{layer}.{phase}.{tile}'];error=float(np.max(np.abs(actual.data-expected.ravel())))
                assert np.isfinite(error) and error<=1e-7,(layer,phase,K,error);maximum=max(maximum,error)
            errors.append(dict(layer=layer,phase=phase,max_abs=maximum,physical_slots=T*65536))
    expected=np.zeros(65536);expected[:768]=oracle['pooler']
    pooler_error=float(np.max(np.abs(result.checkpoints['head.tanh_output'].data-expected)));assert pooler_error<=1e-7
    expected[:]=0;expected[:2]=oracle['logits'];logit_error=float(np.max(np.abs(result.output.data-expected)));assert logit_error<=1e-7
    native_logits=native[f'K{K}_logits_native'];actual_logits=result.output.data[:2];native_errors=np.abs(actual_logits-native_logits)
    assert np.all(native_errors<=.02+.01*np.abs(native_logits));assert int(np.argmax(actual_logits))==int(np.argmax(native_logits))
    assert result.output.level==2 and type(result.output._ckks_nsd)is int and result.output._ckks_nsd==1
    for value in result.checkpoints.values():assert not any(k.startswith('_public_') for k in vars(value))
    for source,saved in zip(sources,original):np.testing.assert_array_equal(source.data,saved);assert source._public_borrowed=='preserve'
    assert not owner._active and not owner._inputs and not owner._live and not owner._captured and not owner._children
    calls=Counter(ops.calls);actual_counts=dict(rotate=calls['rotate'],multiply=calls['multiply'],pt_products=ops.public_multiplies+calls['initial_affine'],
        rescales=calls['weighted_sum']+calls['multiply']+calls['initial_affine'])
    assert actual_counts==plan['counts'],(actual_counts,plan['counts']);assert len(refresh.calls)==plan['identity_refreshes']
    assert score_tiles==Counter({layer:T for layer in range(12)}) and all(row['passed'] for row in domains)
    assert len(trace['attention'])==len(trace['ffn'])==12 and trace['head'] is trace['ffn'][11][0]
    report=dict(passed=True,K=K,scope='Actual joined12 owner with ideal slot/metadata primitives and identity refresh; no HE/five-handler/ranked evidence.',
        ideal_gate=1e-7,stage_errors=errors,pooler_all_slot_max_abs=pooler_error,logits_all_slot_max_abs=logit_error,
        native_logit_gate='abs(error)<=0.02+0.01*abs(native)',native_logit_max_abs=float(native_errors.max()),native_prediction_agrees=True,
        physical_stage_slots_checked=(24*T+2)*65536,all_connections_are_actual_output_objects=True,output_level=2,
        primitive_counts=actual_counts,all_primitive_calls=dict(calls),public_operation_plan=plan,identity_refresh_calls=len(refresh.calls),
        actual_domain_observations=domains,independent_domain_observations=oracle['domain_observations'],actual_metadata=result.metadata,
        elapsed_s=time.monotonic()-started)
    (HERE/f'joined-K{K}.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')

@pytest.mark.parametrize('name',['candidate_manifest.json','full_model_reference.py','server_public_model.py','encrypted_bert_layer_attention.py','layer_attention_contract.py','evidence_inputs/native_report.json','evidence_inputs/reference_report.json'])
def test_collector_rejects_substituted_prerequisite_before_asset_access(monkeypatch,name):
    import collect_full_model as collector
    data=collector.source_bytes();data[name]+=b'\n'
    monkeypatch.setattr(collector,'sha',lambda *args: (_ for _ in ()).throw(AssertionError('archive/assets must not be read')))
    with pytest.raises(ValueError,match='frozen prerequisite differs'):collector.prerequisite_gate(data)


def test_collector_source_failure_persists_failed_report_preserving_cancellation(monkeypatch,tmp_path):
    import collect_full_model as collector
    primary=KeyboardInterrupt('initial source cancelled')
    monkeypatch.setattr(collector,'source_bytes',lambda *args: (_ for _ in ()).throw(primary))
    monkeypatch.setattr(collector,'sha',lambda *args:'0'*64)
    with pytest.raises(KeyboardInterrupt) as caught:collector.run(tmp_path/'failed')
    assert caught.value is primary
    report=json.loads((tmp_path/'failed/report.json').read_text())
    assert report['passed'] is False and report['complete'] is False and report['source_files_unchanged'] is False
    assert report['process_cleanup']==dict(entered=False,reaped=True,group_gone=True)
    assert report['error']['type']=='KeyboardInterrupt' and report['cleanup_errors']


def test_collector_final_publication_does_not_replace_primary(monkeypatch,tmp_path):
    import collect_full_model as collector
    primary=KeyboardInterrupt('initial publication cancelled');calls=[]
    def fail(*args):
        calls.append(1)
        if len(calls)==1:raise primary
        raise OSError('final publication unavailable')
    monkeypatch.setattr(collector,'write',fail)
    monkeypatch.setattr(collector,'source_bytes',lambda *args:{})
    monkeypatch.setattr(collector,'sha',lambda *args:'0'*64)
    with pytest.raises(KeyboardInterrupt) as caught:collector.run(tmp_path/'failed')
    assert caught.value is primary and len(calls)==2
    assert any('final report publication' in note for note in primary.__notes__)


def test_collector_archive_rejects_duplicate_members(tmp_path):
    import collect_full_model as collector
    import io,tarfile
    path=tmp_path/'duplicate.tar.gz'
    with tarfile.open(path,'w:gz') as archive:
        for _ in range(2):
            row=tarfile.TarInfo('same.py');row.size=1;archive.addfile(row,io.BytesIO(b'x'))
    assert collector.verify_archive(path,{'same.py':hashlib.sha256(b'x').hexdigest()}) is False


def test_collector_reaps_descendant_after_successful_leader(tmp_path):
    import collect_full_model as collector
    import subprocess,sys,time,os,signal
    marker=tmp_path/'pid'
    code="import subprocess,sys; p=subprocess.Popen([sys.executable,'-c','import time; time.sleep(60)']); open(sys.argv[1],'w').write(str(p.pid))"
    child=subprocess.Popen([sys.executable,'-c',code,str(marker)],start_new_session=True)
    child.wait(timeout=10)
    try:
        with pytest.raises(RuntimeError,match='descendants outlived|group survives'):collector.reap(child)
    finally:
        if collector.group_alive(child.pid):
            try:os.killpg(child.pid,signal.SIGKILL)
            except ProcessLookupError:pass
    assert child.returncode==0
