"""Independent NumPy full-BERT reference; no HE or native intermediate inputs.

All later states are computed from original compact embeddings and196 public
weights. Frozen power sites use Horner/actual rounded power coefficients;
balanced sites use independent Clenshaw (chebval), not encrypted recurrences.
"""
import hashlib,json,math
import numpy as np
from scipy.special import erf
MANIFEST_SHA256='4e2277beea7189aa1d77b168c500c8a175f6c630afa520fcc6b38cb5a179cff9'

class DomainViolation(ValueError):
    def __init__(self,label,observation):
        self.label=label;self.observation=observation
        super().__init__('declared nonlinear domain failed: '+label)

def manifest(raw):
    if type(raw)is not bytes or hashlib.sha256(raw).hexdigest()!=MANIFEST_SHA256:raise ValueError('exact frozen v2 manifest bytes required')
    result=json.loads(raw)
    for rule in [result['base_exp'],result['tanh']['base_polynomial'],*[x['polynomial'] for x in result['norms'].values()],*[x['polynomial'] for x in result['gelu'].values()]]:
        coefficients=np.asarray(rule['coefficients'],dtype='<f8')
        if hashlib.sha256(coefficients.tobytes()).hexdigest()!=rule['coefficient_f64le_sha256']:raise ValueError('frozen public coefficient bytes differ')
    return result

def tensor_shapes():
    result={}
    for layer in range(12):
        prefix=f'bert.encoder.layer.{layer}.'
        for name,m,n in [('attention.self.query',768,768),('attention.self.key',768,768),('attention.self.value',768,768),
                         ('attention.output.dense',768,768),('intermediate.dense',3072,768),('output.dense',768,3072)]:
            result[prefix+name+'.weight']=(m,n);result[prefix+name+'.bias']=(m,)
        for name in ('attention.output.LayerNorm','output.LayerNorm'):
            for suffix in ('weight','bias'):result[prefix+name+'.'+suffix]=(768,)
    result.update({'bert.pooler.dense.weight':(768,768),'bert.pooler.dense.bias':(768,),
                   'classifier.weight':(2,768),'classifier.bias':(2,)})
    return result

class Arithmetic:
    def __init__(self,raw,*,approximate):
        if type(approximate)is not bool:raise ValueError('explicit approximate boolean required')
        self.manifest=manifest(raw);self.approximate=approximate;self.observations=[]
    def observe(self,label,x,domain):
        a=np.asarray(x);lo,hi=domain;finite=np.isfinite(a);values=a[finite]
        row=dict(label=label,domain=list(domain),count=int(a.size),minimum=float(values.min()) if values.size else None,
                 maximum=float(values.max()) if values.size else None,below=int(np.sum(a<lo)),above=int(np.sum(a>hi)),nonfinite=int(np.sum(~finite)))
        self.observations.append(row)
        if row['below'] or row['above'] or row['nonfinite']:raise DomainViolation(label,row)
    def polynomial(self,x,rule,method,label):
        self.observe(label,x,rule['domain']);lo,hi=rule['domain']
        t=np.asarray(x)*(2/(hi-lo))-(hi+lo)/(hi-lo)
        if method=='power':
            power=np.polynomial.chebyshev.cheb2poly(np.asarray(rule['coefficients'],dtype=np.float64))
            return np.polynomial.polynomial.polyval(t,power)
        if method=='balanced_chebyshev':return np.polynomial.chebyshev.chebval(t,rule['coefficients'])
        raise ValueError('frozen polynomial method unsupported')
    def inverse(self,x,rule,label):
        self.observe(label,x,rule['domain']);seed=rule['seed']
        result=x*(-seed*seed)+2*seed
        for _ in range(1,rule['iterations']):result=result*(2-x*result)
        return result
    def norm(self,x,gamma,beta,site):
        centered=x-x.mean(axis=-1,keepdims=True);variance=(centered*centered).mean(axis=-1,keepdims=True)+1e-12
        if self.approximate:
            rule=self.manifest['norms'][site]
            inverse=self.polynomial(variance,rule['polynomial'],rule['method'],site+'.inverse_sqrt')
        else:inverse=1/np.sqrt(variance)
        return centered*inverse*gamma+beta
    def softmax(self,scores,layer):
        if not self.approximate:
            z=scores-scores.max(axis=-1,keepdims=True);exponential=np.exp(z)
            return exponential/exponential.sum(axis=-1,keepdims=True)
        rule=self.manifest['softmax'][str(layer)];K=scores.shape[-1];label=f'{layer}.softmax'
        centered=scores-scores.mean(axis=-1,keepdims=True)
        self.observe(label+'.centered_scores',centered,rule['centered_domain'])
        base=self.polynomial(centered/(2**rule['squarings']),self.manifest['base_exp'],'power',label+'.base_exp')
        inverse=self.inverse(base.mean(axis=-1,keepdims=True),self.manifest['initial_reciprocal'],label+'.initial_mean_inverse')
        probabilities=base*inverse/K
        contract=self.manifest['normalization_reciprocal_by_public_K'][str(K)]
        for index in range(rule['squarings']):
            squared=probabilities*probabilities;denominator=squared.sum(axis=-1,keepdims=True)
            inverse=self.inverse(denominator,contract,label+f'.round{index}.denominator_inverse.K{K}')
            probabilities=squared*inverse
        return probabilities
    def gelu(self,x,layer):
        if not self.approximate:return .5*x*(1+erf(x/np.sqrt(2.)))
        return self.polynomial(x,self.manifest['gelu'][str(layer)]['polynomial'],'balanced_chebyshev',f'{layer}.gelu')
    def tanh(self,x):
        if not self.approximate:return np.tanh(x)
        rule=self.manifest['tanh'];self.observe('pooler.tanh.input',x,rule['domain'])
        value=self.polynomial(x/(2**rule['doublings']),rule['base_polynomial'],'power','pooler.tanh.base')
        for index in range(rule['doublings']):
            denominator=1+value*value
            inverse=self.inverse(denominator,self.manifest['tanh_reciprocal'],f'pooler.tanh.round{index}.denominator_inverse')
            value=2*value*inverse
        return value

def compute(embeddings,weights,manifest_bytes,*,approximate):
    """Compute all12 layers from scratch; public weights are checked by the caller."""
    shapes=tensor_shapes()
    if type(weights)is not dict or set(weights)!=set(shapes):raise ValueError('exact196 public weights required')
    for name,shape in shapes.items():
        a=np.asarray(weights[name])
        if a.dtype!=np.float64 or a.shape!=shape or not np.isfinite(a).all():raise ValueError('invalid public tensor '+name)
    value=np.asarray(embeddings)
    if value.dtype!=np.float64 or value.ndim!=2 or value.shape[1]!=768 or not 1<=len(value)<=128 or not np.isfinite(value).all():
        raise ValueError('original compact float64[K,768] embeddings required')
    value=value.copy();arithmetic=Arithmetic(manifest_bytes,approximate=approximate);attention=[];blocks=[]
    for layer in range(12):
        prefix=f'bert.encoder.layer.{layer}.'
        def dense(x,name):return x@weights[prefix+name+'.weight'].T+weights[prefix+name+'.bias']
        q,k,v=(dense(value,'attention.self.'+name).reshape(len(value),12,64).transpose(1,0,2) for name in ('query','key','value'))
        scores=(q@k.swapaxes(-1,-2))/math.sqrt(64)
        probabilities=arithmetic.softmax(scores,layer)
        attended=(probabilities@v).transpose(1,0,2).reshape(value.shape)
        residual=value+dense(attended,'attention.output.dense');name=prefix+'attention.output.LayerNorm'
        value=arithmetic.norm(residual,weights[name+'.weight'],weights[name+'.bias'],f'{layer}.attention')
        attention.append(value.copy())
        activated=arithmetic.gelu(dense(value,'intermediate.dense'),layer)
        residual=value+dense(activated,'output.dense');name=prefix+'output.LayerNorm'
        value=arithmetic.norm(residual,weights[name+'.weight'],weights[name+'.bias'],f'{layer}.mlp')
        if not np.isfinite(value).all():raise ValueError('nonfinite propagated block output')
        blocks.append(value.copy())
    pooled=value[0]@weights['bert.pooler.dense.weight'].T+weights['bert.pooler.dense.bias']
    pooled=arithmetic.tanh(pooled)
    logits=pooled@weights['classifier.weight'].T+weights['classifier.bias']
    if not np.isfinite(pooled).all() or not np.isfinite(logits).all():raise ValueError('nonfinite final output')
    return dict(attention_outputs=tuple(attention),block_outputs=tuple(blocks),pooler=pooled,logits=logits,
                domain_observations=arithmetic.observations,approximate=approximate)
