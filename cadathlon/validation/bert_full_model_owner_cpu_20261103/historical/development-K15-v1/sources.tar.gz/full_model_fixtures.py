"""Client-only original embeddings/native references and pinned public weights.

No later native or independent clear output is supplied to the joined owner.
"""
from pathlib import Path
import hashlib,json,os
import numpy as np
from server_public_model import tensor_shapes,TENSOR_SHA256,CHECKPOINT_SHA256
HERE=Path(__file__).resolve().parent
MODEL=Path('/home/jianming_gatech/cross_validation_assets/bert/f150c1d609d1e50dd5e2e5408661cfac8339277c/model.safetensors')
NATIVE_SHA='758ff5d71fa3c836f74a974dee97c4a744e17ea283047e2abe15b4675edc202a'

def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def load():
    native_path=Path(os.environ.get('BERT_FULL_NATIVE_FIXTURE',HERE/'client_native_full.npz'))
    if sha(MODEL)!=CHECKPOINT_SHA256 or sha(native_path)!=NATIVE_SHA:raise ValueError('pinned public checkpoint/native reference changed')
    weights={};records={}
    with MODEL.open('rb') as stream:
        n=int.from_bytes(stream.read(8),'little');header=json.loads(stream.read(n));base=n+8
        for name,shape in tensor_shapes().items():
            desc=header[name];lo,hi=desc['data_offsets']
            if desc['dtype']!='F32' or desc['shape']!=list(shape) or hi-lo!=4*np.prod(shape):raise ValueError('fixed tensor shape/dtype differs')
            stream.seek(base+lo);raw=stream.read(hi-lo)
            if hashlib.sha256(raw).hexdigest()!=TENSOR_SHA256[name]:raise ValueError('fixed tensor bytes differ')
            lift=np.frombuffer(raw,dtype='<f4').astype('<f8');weights[name]=np.frombuffer(lift.tobytes(),dtype='<f8').reshape(shape)
            records[name]=dict(shape=list(shape),source_f32_sha256=TENSOR_SHA256[name])
    with np.load(native_path,allow_pickle=False) as source:
        expected={f'layer{layer}_K{K}_native' for K in (15,128) for layer in range(12)}
        expected.update(f'K{K}_{name}' for K in (15,128) for name in ('embeddings','positions','pooler_native','logits_native'))
        if set(source.files)!=expected:raise ValueError('complete32 native reference arrays required')
        native={}
        for name in source.files:
            a=source[name];K=15 if '_K15_' in name or name.startswith('K15_') else 128
            if name.endswith('_positions'):
                if a.dtype!=np.int64 or a.shape!=(K,) or tuple(a)!=tuple(range(K)):raise ValueError('fixed original positions changed')
            else:
                shape=(128,768) if name.endswith('_embeddings') else (768,) if name.endswith('_pooler_native') else (2,) if name.endswith('_logits_native') else (K,768)
                if a.dtype!=np.float64 or a.shape!=shape or not np.isfinite(a).all():raise ValueError('fixed native array schema differs')
            native[name]=a.copy();records[name]=dict(shape=list(a.shape),dtype=a.dtype.str,sha256=hashlib.sha256(a.tobytes()).hexdigest())
    if sha(MODEL)!=CHECKPOINT_SHA256 or sha(native_path)!=NATIVE_SHA:raise ValueError('fixture assets changed while loading')
    return weights,native,dict(passed=True,checkpoint_sha256=CHECKPOINT_SHA256,native_fixture_sha256=NATIVE_SHA,
        arrays=records,scope=__doc__,joined_input_arrays=['K15_embeddings','K128_embeddings'])
