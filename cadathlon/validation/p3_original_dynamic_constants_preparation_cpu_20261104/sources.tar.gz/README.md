# Original P3 dynamic-constant candidate

`baseline_dynamic_constants.py` is the original baseline with one added keyword: `Mapping(..., dynamic_constants=True)`. It keeps the actual `nn.vectorize`, `PackingPolicy(lazy_constants=True)`, original model, input shape, batch and device tuple. It does not adopt the student ring, compact models, setup parallelism, a new worker or different correctness gates. Nothing is promoted or used by the queued TPU sweep.

The six public synthetic fixture checks run the real CPU model frontend and packing twice and compare the frontend digest, packed fingerprint, complete ring and original weights. Only Mapping construction is replaced with a recording stub. The existing `mapping_compile_test.py::DynamicConstantsCompilationTest` is copied unchanged and selected in full: its three tests exercise clear CPU resident-constant compilation across two inputs and cache cleanup on ordinary/concurrent/exceptional paths. A small AST check verifies the one-keyword delta.

This preparation creates no CKKS context, polynomial, key or encrypted request. CPU-only JAX is explicit; optional accelerator imports are denied. Real cryptographic constructor functions are guarded during tests. The only real compilation test is a small uint32 clear arithmetic function, not the CNN or an HE program.

For later comparison, `Mapping` supports this option only for whole-program, bootstrap-free, single-device execution. The original P3 runner uses one device and these original models have no bootstrap. Full original-profile HE correctness, setup/whole-process memory and timing, all-six TPU completion and any five-minute claim still need a separately authorized comparison. This source does not supply a new launcher or alter existing calibration/grants.
