"""The alternative changes only Mapping's handling of already packed constants."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest
import conftest

ROOT=Path(__file__).resolve().parent
P3=ROOT/'checkout/cadathlon/non_agent_pset/p3_cnn'

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

def test_exact_one_keyword_delta():
    old=ast.parse((P3/'src/baseline.py').read_text())
    new=ast.parse((ROOT/'baseline_dynamic_constants.py').read_text())
    calls=[x for x in ast.walk(new) if isinstance(x,ast.Call) and isinstance(x.func,ast.Name) and x.func.id=='Mapping']
    assert len(calls)==1
    keywords=calls[0].keywords
    assert keywords[-1].arg=='dynamic_constants' and ast.literal_eval(keywords[-1].value) is True
    calls[0].keywords=keywords[:-1]
    assert ast.dump(new,include_attributes=False)==ast.dump(old,include_attributes=False)

@pytest.mark.parametrize('index',range(1,7))
def test_original_six_frontends_and_packings_are_identical(index,monkeypatch):
    import jaxite_word
    from jaxite_word import nn,packing
    reference=load('p3_public_reference',P3/'src/reference.py')
    legacy=load('p3_original_baseline',P3/'src/baseline.py')
    alternative=load('p3_dynamic_baseline',ROOT/'baseline_dynamic_constants.py')
    case=json.loads((P3/'test'/f'test{index}.in').read_bytes())
    model,shape,inputs,logits=reference.make_case(case)
    expected=json.loads((P3/'test'/f'test{index}.out').read_bytes())['logits']
    np.testing.assert_allclose(logits,expected,rtol=1e-10,atol=1e-10)
    weight_before={n:hashlib.sha256(p.detach().numpy().tobytes()).hexdigest() for n,p in model.named_parameters()}
    program_digests=[];policies=[];calls=[]
    original_vectorize=nn.vectorize;original_pack=packing.pack
    def vectorize(*args,**kwargs):
        program=original_vectorize(*args,**kwargs);program_digests.append(program.digest);return program
    def pack(program,policy):
        policies.append(policy);return original_pack(program,policy)
    def mapping(packed,**kwargs):
        result=SimpleNamespace(packed=packed,kwargs=kwargs);calls.append(result);return result
    monkeypatch.setattr(nn,'vectorize',vectorize)
    monkeypatch.setattr(packing,'pack',pack)
    monkeypatch.setattr(jaxite_word,'Mapping',mapping)
    devices=(object(),)
    before=legacy.build_mapping(model,shape,batch=case['batch'],devices=devices)
    after=alternative.build_mapping(model,shape,batch=case['batch'],devices=devices)
    assert len(calls)==2 and len(program_digests)==2 and program_digests[0]==program_digests[1]
    assert policies==[packing.PackingPolicy(lazy_constants=True)]*2
    assert before.packed.fingerprint==after.packed.fingerprint
    assert before.packed.ring_config==after.packed.ring_config
    assert before.kwargs==dict(global_batch=case['batch'],devices=devices)
    assert after.kwargs==dict(global_batch=case['batch'],devices=devices,dynamic_constants=True)
    assert weight_before=={n:hashlib.sha256(p.detach().numpy().tobytes()).hexdigest() for n,p in model.named_parameters()}
    ring=after.packed.ring_config
    assert ring.degree==32768 and ring.dnum==4 and after.packed.depth==7
    assert len(ring.q_towers)==16 and len(ring.p_towers)==4
    conftest.RECORDS.append(dict(case=f'test{index}',model=case['model'],batch=case['batch'],shape=list(shape),frontend_digest=program_digests[0],packing_fingerprint=after.packed.fingerprint,
        ring=dict(degree=ring.degree,dnum=ring.dnum,q_towers=list(ring.q_towers),p_towers=list(ring.p_towers),depth=after.packed.depth),
        public_clear_fixture_matches=True,weights_unchanged=True,packing_unchanged=True,mapping_is_recording_stub=True))
