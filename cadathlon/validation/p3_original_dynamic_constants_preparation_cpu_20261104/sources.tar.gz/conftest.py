"""CPU-only guard for this small frontend/clear-compilation preparation."""
import importlib.abc
import json
import os
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent
CHECKOUT=ROOT/'checkout'
assert os.environ.get('JAX_PLATFORMS')=='cpu'
assert sys.dont_write_bytecode
os.environ['CROSS_ROOT']=str(CHECKOUT)
sys.path[:0]=[str(ROOT),str(CHECKOUT)]
OPTIONAL_IMPORT_DENIALS=[]
CRYPTO_ATTEMPTS=[]
RECORDS=[]

class NoAccelerator(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0] in ('libtpu','torch_xla','tensorflow','flax'):
            OPTIONAL_IMPORT_DENIALS.append(fullname)
            raise ImportError('CPU preparation only')
        return None

sys.meta_path.insert(0,NoAccelerator())
import pytest

@pytest.fixture(scope='session',autouse=True)
def no_crypto_or_accelerator():
    import jax
    from jaxite_word import CKKSContext,Polynomial
    from jaxite_word import key_gen
    assert jax.default_backend()=='cpu'
    assert all(d.platform=='cpu' for d in jax.devices())
    patch=pytest.MonkeyPatch()
    def denied(*args,**kwargs):
        CRYPTO_ATTEMPTS.append('context/polynomial/key-generation')
        raise AssertionError('No cryptographic construction permitted in preparation')
    patch.setattr(CKKSContext,'__init__',denied)
    patch.setattr(Polynomial,'__init__',denied)
    for module in {key_gen,sys.modules.get('key_gen')} - {None}:
        for name in ('gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen'):
            patch.setattr(module,name,denied)
    yield
    patch.undo()
    assert CRYPTO_ATTEMPTS==[]

def pytest_sessionfinish(session,exitstatus):
    import jax
    report=dict(scope='Original six public synthetic frontend/packing comparisons and unchanged three clear CPU dynamic-constant compilation/lifetime tests; no Mapping construction, keys, HE, TPU or timing comparison.',
        passed=int(exitstatus)==0,pytest_exit_code=int(exitstatus),tests_collected=session.testscollected,
        pid=os.getpid(),pgid=os.getpgrp(),cpu_affinity=sorted(os.sched_getaffinity(0)),
        backend=jax.default_backend(),device_platforms=[d.platform for d in jax.devices()],
        cryptographic_construction_attempts=CRYPTO_ATTEMPTS,optional_accelerator_import_denials=OPTIONAL_IMPORT_DENIALS,
        records=RECORDS,calibrated_speed_claim=False,actual_original_profile_comparison=False)
    Path(os.environ['P3_PREPARATION_REPORT']).write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
