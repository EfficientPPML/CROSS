from pathlib import Path
import sys,json
import pytest
HERE=Path(__file__).parent;sys.path[:0]=[str(HERE),str(HERE/'runtime/stage'),str(HERE/'runtime')]
import parity_protocol as p

def test_public_profile_and_memory_no_payloads():
    plan=p.plan((HERE/'runtime/stage/server_inputs/p60_profile_and_refresh.json').read_bytes(),(HERE/'runtime/stage/server_inputs/twelve_layer_plan.json').read_bytes())
    assert plan['actual_rotation_calls']==24 and {1,64}<=set(plan['rotation_inventory'])
    assert [r['max_two_entry_bytes'] for r in plan['rows']]==[1913651200,554696704]
    assert [r['input_payload_bytes'] for r in plan['rows']]==[104857600,54525952]

def test_only_three_reviewed_runtime_overlays():
    origin=p.check_sources();assert origin['base_source_count']==217
    assert set(origin['overlays'])=={'runtime/stage/'+n for n in ('key_contexts.py','prepared_rotation.py','loader_prepared_rotation.py')}

@pytest.mark.parametrize('name,value',[('CROSS_SKIP_TOPLEVEL_ROTKEYS','0'),('CROSS_ROOT','/elsewhere'),('CROSS_FAKE',''),('BOOTSTRAP_TEST_N4096','1'),('PYTEST_TEST','1'),('JAX_DISABLE_JIT','1'),('XLA_FLAGS','--xla_force_host_platform_device_count=2')])
def test_inherited_runtime_test_switches_rejected(monkeypatch,name,value):
    monkeypatch.setenv('JAX_PLATFORMS','cpu');monkeypatch.setenv(name,value)
    with pytest.raises(ValueError):p.environment()
