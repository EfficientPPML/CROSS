from pathlib import Path
from dataclasses import replace
import json
import pytest
from public_source_pins import PUBLIC_PINS
from qwen_file_contract import PublicContract,canonical
from qwen_key_files_admission import bind_files
import qwen_key_contract as c
import qwen_key_loader as loader
from test_qwen_key_contract import fixture,profile

HERE=Path(__file__).resolve().parent


@pytest.fixture(scope='module')
def public_contract():
    return PublicContract.from_blobs({n:(HERE/'contract_inputs'/n).read_bytes()for n in PUBLIC_PINS})


def full_fixture(profile,public_contract,role='server'):
    raw,private,ids,_=fixture(profile,role)
    pub=c.authenticate_public(raw,profile,ids,role=role)
    priv=c.authenticate_private(private,pub)if role=='client'else None
    identity=public_contract.identity(context_id=ids.context_id,model_id=ids.model_id,
        producer_sources=ids.producer_source_manifest_sha256,consumer_sources=ids.consumer_source_manifest_sha256)
    return bind_files(public_contract,pub,canonical(identity),priv)


@pytest.mark.parametrize('role',['client','server'])
def test_full_source_profile_and_external_identity_are_both_bound(profile,public_contract,role):
    admitted=full_fixture(profile,public_contract,role)
    assert admitted.check().public.role==role and admitted.execution_authorized is False
    assert admitted.public_contract.profile()==profile.parameters


@pytest.mark.parametrize('field',['parameters','public_source_sha256','full_owner_source_manifest_sha256','candidate_sha256','schema'])
def test_full_contract_substitution_before_reader_seam(profile,public_contract,field):
    raw,_,ids,_=fixture(profile);pub=c.authenticate_public(raw,profile,ids,role='server')
    identity=public_contract.identity(context_id=ids.context_id,model_id=ids.model_id,
        producer_sources=ids.producer_source_manifest_sha256,consumer_sources=ids.consumer_source_manifest_sha256)
    if field=='parameters':identity[field]['dnum']=6
    elif field=='public_source_sha256':identity[field]['inputs/config.json']='0'*64
    else:identity[field]='0'*64
    with pytest.raises(ValueError):bind_files(public_contract,pub,canonical(identity))


def test_full_source_blobs_cannot_be_replaced(profile,public_contract):
    data=public_contract.check();data['inputs/profile_audit.json']+=b' '
    with pytest.raises(ValueError):PublicContract.from_blobs(data)


@pytest.mark.parametrize('fault',['narrow_identity','changed_expected','wrong_role','not_admission'])
def test_recording_entry_rejects_before_any_fd_or_dependency(profile,public_contract,fault):
    admitted=full_fixture(profile,public_contract)
    if fault=='narrow_identity':
        identity=json.loads(admitted.keys.identity_bytes)
        object.__setattr__(admitted.keys,'identity_bytes',canonical({k:identity[k]for k in ('context_id','model_id','producer_source_manifest_sha256','consumer_source_manifest_sha256')}))
    elif fault=='changed_expected':object.__setattr__(admitted.keys.public,'expected',replace(admitted.keys.public.expected,model_id='f'*64))
    elif fault=='not_admission':admitted=object()
    def forbidden(*args,**kwargs):raise AssertionError('dependency invoked before public admission')
    deps=loader.RecordingDependencies(forbidden,forbidden,forbidden,forbidden)
    with pytest.raises((ValueError,TypeError)):
        with loader._load_for_recording(admitted,'never-open',None if fault!='wrong_role'else'never-private',dependencies=deps):
            raise AssertionError('invalid admission entered')


def test_actual_entries_still_deny_without_inspecting_objects():
    class Poison:
        def __getattribute__(self,name):raise AssertionError('must deny first')
        def __fspath__(self):raise AssertionError('must not inspect path')
    with pytest.raises(PermissionError):loader.open_server(Poison(),Poison())
    with pytest.raises(PermissionError):loader.open_client(Poison(),Poison(),Poison())
