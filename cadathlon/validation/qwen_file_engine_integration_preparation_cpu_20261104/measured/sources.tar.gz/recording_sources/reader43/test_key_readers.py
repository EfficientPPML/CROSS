from pathlib import Path
from types import SimpleNamespace
import hashlib,io,json,os,stat
import numpy as np
import pytest
import qwen_key_readers as readers
import key_descriptor_io as dio
from cleanup_origin import protect_body,is_cleanup
from test_qwen_key_contract import fixture,profile
import qwen_key_contract as c


def saved(tmp_path,*,private=False,values=None,name='key.npy'):
    root=tmp_path/'keys';root.mkdir(mode=0o700)
    values=np.arange(42,dtype=np.uint32).reshape(2,3,7)%13 if values is None else values
    path=root/name
    with path.open('wb')as stream:np.save(stream,values,allow_pickle=False)
    path.chmod(0o600);raw=path.read_bytes()
    description=dict(sha256=hashlib.sha256(raw).hexdigest(),dtype='uint32',shape=list(values.shape),bytes=len(raw))
    owner=readers.ReadDirectory(root,private=private)
    return owner,path,values,description


@pytest.mark.parametrize('private',[False,True])
def test_real_small_key_file_same_fd_hash_header_residue_and_readonly_mapping(tmp_path,private):
    owner,path,values,description=saved(tmp_path,private=private)
    mapped=None
    try:
        mapped,state=readers.map_array(owner,path.name,description,values.shape,(17,19,23))
        np.testing.assert_array_equal(mapped,values)
        assert mapped.flags.writeable is False and state==readers._file_state(path.stat())
        with pytest.raises(ValueError):mapped[0,0,0]=1
        owner.check()
    finally:
        if mapped is not None:mapped._mmap.close()
        owner.close()


@pytest.mark.parametrize('version,width',[(1,2),(2,4)])
@pytest.mark.parametrize('length',[513,1<<15])
def test_header_length_rejected_before_header_read(version,width,length):
    raw=b'\x93NUMPY'+bytes((version,0))+length.to_bytes(width,'little')
    class PrefixOnly(io.BytesIO):
        def read(self,count=-1):
            if count>8:raise AssertionError('oversize header was consumed before cap')
            return super().read(count)
    with pytest.raises(ValueError,match='pre-read'):readers._header(PrefixOnly(raw),length+100,(2,3,7))


def test_header_length_rejected_against_remaining_file_extent():
    raw=b'\x93NUMPY\x02\x00'+(100).to_bytes(4,'little')
    with pytest.raises(ValueError,match='pre-read'):readers._header(io.BytesIO(raw),len(raw),(2,3,7))


@pytest.mark.parametrize('kind',['dtype','fortran','shape','trailing','hash','residue','unsupported_version'])
def test_real_malformed_key_files_reject_without_returned_mapping(tmp_path,kind):
    owner,path,values,description=saved(tmp_path)
    try:
        if kind=='hash':description['sha256']='0'*64
        else:
            if kind=='dtype':payload=values.astype(np.uint64)
            elif kind=='fortran':payload=np.asfortranarray(values)
            elif kind=='shape':payload=values.reshape(3,2,7)
            elif kind=='residue':payload=values.copy();payload[0,1,0]=19
            else:payload=values
            with path.open('wb')as stream:np.save(stream,payload,allow_pickle=False)
            raw=path.read_bytes()
            if kind=='trailing':raw+=b'extra'
            if kind=='unsupported_version':raw=raw[:6]+b'\x03\x00'+raw[8:]
            path.write_bytes(raw);path.chmod(0o600)
            description.update(sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
        with pytest.raises(ValueError):readers.map_array(owner,path.name,description,values.shape,(17,19,23))
    finally:owner.close()


def test_private_directory_and_file_modes_rechecked(tmp_path):
    owner,path,values,description=saved(tmp_path,private=True)
    try:
        path.chmod(0o644)
        with pytest.raises(ValueError,match='mode'):readers.map_array(owner,path.name,description,values.shape,(17,19,23))
        path.chmod(0o600);owner.path.chmod(0o755)
        with pytest.raises(ValueError,match='permissions'):owner.check()
    finally:owner.close()


@pytest.mark.parametrize('target',['symlink','directory'])
def test_no_symlink_or_nonregular_mapping(tmp_path,target):
    owner,path,values,description=saved(tmp_path)
    try:
        alias=owner.path/'alias.npy'
        if target=='symlink':alias.symlink_to(path)
        else:alias.mkdir()
        with pytest.raises((ValueError,OSError)):readers.map_array(owner,alias.name,description,values.shape,(17,19,23))
    finally:owner.close()


def isolated_os(monkeypatch,*,close=None,open=None):
    fake=SimpleNamespace(**vars(os))
    if close is not None:fake.close=close
    if open is not None:fake.open=open
    monkeypatch.setattr(readers,'os',fake);monkeypatch.setattr(dio,'os',fake)
    return fake


@pytest.mark.parametrize('kind',[ValueError,KeyboardInterrupt,SystemExit])
def test_body_primary_survives_real_fd_close_failure(tmp_path,monkeypatch,kind):
    owner,path,values,description=saved(tmp_path);body=kind('synthetic hash read failure');closed=[]
    def fail_hash(fd):raise body
    def close(fd):closed.append(fd);os.close(fd);raise OSError('synthetic uncertain close')
    monkeypatch.setattr(readers,'_sha_fd',fail_hash);isolated_os(monkeypatch,close=close)
    try:
        with pytest.raises(kind)as caught:readers.map_array(owner,path.name,description,values.shape,(17,19,23))
        assert caught.value is body and len(closed)==1 and not is_cleanup(body)
    finally:
        # Directory is not part of the injected file close fault.
        monkeypatch.undo();owner.close()


def test_nonowning_stream_constructor_failure_closes_original_fd_once(tmp_path,monkeypatch):
    owner,path,values,description=saved(tmp_path);closed=[];failure=ValueError('synthetic fdopen failure')
    fake=isolated_os(monkeypatch,close=lambda fd:(closed.append(fd),os.close(fd))[-1])
    def fdopen(*args,**kwargs):assert kwargs['closefd']is False;raise failure
    fake.fdopen=fdopen
    try:
        with pytest.raises(ValueError)as caught:readers.map_array(owner,path.name,description,values.shape,(17,19,23))
        assert caught.value is failure and len(closed)==1
        with pytest.raises(OSError):os.fstat(closed[0])
    finally:monkeypatch.undo();owner.close()


def test_directory_failed_close_is_sticky_and_never_retries(tmp_path,monkeypatch):
    root=tmp_path/'root';root.mkdir();owner=readers.ReadDirectory(root);fd=owner.fd;closed=[]
    failure=OSError('synthetic uncertain directory close')
    def close(value):closed.append(value);os.close(value);raise failure
    isolated_os(monkeypatch,close=close)
    with pytest.raises(OSError)as first:owner.close()
    with pytest.raises(OSError)as second:owner.close()
    assert first.value is second.value is failure and closed==[fd]and owner.fd is None


def test_shared_cleanup_origin_promotes_later_cancel_but_preserves_sticky_body():
    first=OSError('first close');later=KeyboardInterrupt('second close')
    def throw(error):raise error
    state=dio._CloseState()
    with pytest.raises(KeyboardInterrupt)as caught:
        try:state.cleanup('one',lambda:throw(first))
        finally:state.cleanup('two',lambda:throw(later))
    assert caught.value is later
    body=ValueError('genuine sticky body');state=dio._CloseState()
    with pytest.raises(ValueError)as caught:
        try:raise body
        finally:
            try:state.cleanup('same body rethrow',lambda:throw(body))
            finally:state.cleanup('later cancel',lambda:throw(later))
    assert caught.value is body and not is_cleanup(body)


def metadata_store(root,public,private=None):
    root.mkdir(mode=0o700)
    if private is None:
        (root/'public_manifest.json').write_bytes(public.raw)
        for spec in public.profile.arrays:(root/spec.name).write_bytes(b'')
    else:
        (root/'private_manifest.json').write_bytes(private.raw);(root/'secret.npy').write_bytes(b'')
    for p in root.iterdir():p.chmod(0o600)


@pytest.mark.parametrize('role',['client','server'])
def test_real_manifest_readers_bind_complete_inventory_without_array_reads(tmp_path,profile,role):
    raw,secret,ids,_=fixture(profile,role);public=c.authenticate_public(raw,profile,ids,role=role)
    root=tmp_path/'public';metadata_store(root,public);owner=readers.ReadDirectory(root)
    try:
        found,specs,again=readers.read_public(owner,public)
        assert again==raw and len(specs)==335 and found==public.manifest
        (root/'extra.npy').write_bytes(b'')
        with pytest.raises(ValueError,match='335'):readers.read_public(owner,public)
    finally:owner.close()
    if role=='client':
        private=c.authenticate_private(secret,public);root=tmp_path/'private';metadata_store(root,public,private);owner=readers.ReadDirectory(root,private=True)
        try:
            assert readers.read_private(owner,private,raw)[1]==secret
            (root/'private_manifest.json').write_bytes(secret+b' ')
            with pytest.raises(ValueError,match='changed'):readers.read_private(owner,private,raw)
        finally:owner.close()


def test_public_manifest_change_rejected(tmp_path,profile):
    raw,_,ids,_=fixture(profile);pub=c.authenticate_public(raw,profile,ids,role='server')
    root=tmp_path/'public';metadata_store(root,pub);owner=readers.ReadDirectory(root)
    try:
        (root/'public_manifest.json').write_bytes(raw+b' ')
        with pytest.raises(ValueError,match='changed'):readers.read_public(owner,pub)
    finally:owner.close()


def test_private_metadata_opened_mode_checked_before_read(tmp_path,monkeypatch):
    root=tmp_path/'private';root.mkdir(mode=0o700);path=root/'private_manifest.json';path.write_bytes(b'{}');path.chmod(0o600)
    owner=readers.ReadDirectory(root,private=True);reads=[]
    fake=isolated_os(monkeypatch)
    def changing_open(name,*args,**kwargs):
        path.chmod(0o644);return os.open(name,*args,**kwargs)
    def tracking_read(*args):reads.append(args);return os.read(*args)
    fake.open=changing_open;fake.read=tracking_read
    try:
        with pytest.raises(ValueError,match='mode'):readers.read_metadata(owner,path.name,65536)
        assert reads==[]
    finally:monkeypatch.undo();owner.close()


def test_file_replacement_during_mapping_rejected(tmp_path,monkeypatch):
    owner,path,values,description=saved(tmp_path)
    original=readers._sha_fd
    def replacing(fd):
        digest=original(fd);replacement=path.with_suffix('.replacement');replacement.write_bytes(path.read_bytes());replacement.replace(path);return digest
    monkeypatch.setattr(readers,'_sha_fd',replacing)
    try:
        with pytest.raises(ValueError,match='identity'):readers.map_array(owner,path.name,description,values.shape,(17,19,23))
    finally:owner.close()
