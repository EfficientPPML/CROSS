"""Concrete admission/metadata readers with fake array bodies and backend.

No Qwen-sized key data or backend context is constructed. Separate reader tests
exercise real small uint32 NPY files; this integration substitutes each335
array map while keeping real full-schema manifests and directory ownership.
"""
from pathlib import Path
from types import SimpleNamespace
import ast,hashlib,json,os,threading
import pytest
import qwen_key_loader as loader
import qwen_key_readers as readers
from cleanup_origin import is_cleanup
from test_qwen_loader_recording import recorded_loader,profile
from test_key_files_admission import full_fixture,public_contract
from test_key_readers import metadata_store


def setup_bridge(tmp_path,monkeypatch,profile,public_contract,role='server',**faults):
    admission=full_fixture(profile,public_contract,role)
    public=tmp_path/'public';metadata_store(public,admission.keys.public)
    private=None
    if role=='client':
        private=tmp_path/'private';metadata_store(private,admission.keys.public,admission.keys.private)
    rec=recorded_loader(profile,role,**faults)
    original=rec.namespace['_map_array']
    def recorded_map(owner,name,description,shape,moduli):
        mapped,_=original(owner,name,description,shape,moduli)
        return mapped,readers._file_state(os.stat(name,dir_fd=owner.fd,follow_symlinks=False))
    monkeypatch.setattr(loader,'_ACTIVE',threading.Lock())
    monkeypatch.setattr(loader,'_FAILURE_QUARANTINE',[])
    monkeypatch.setattr(loader,'threading',SimpleNamespace(current_thread=lambda:1,main_thread=lambda:2))
    dependencies=loader.RecordingDependencies(rec.namespace['keys']._security_check,rec.namespace['_crypto'],readers.ReadDirectory,recorded_map)
    def scope():return loader._load_for_recording(admission,public,private,dependencies=dependencies)
    def restored():
        rec.restored()
        assert loader._ACTIVE.acquire(blocking=False);loader._ACTIVE.release()
    return SimpleNamespace(admission=admission,public=public,private=private,rec=rec,
                           dependencies=dependencies,scope=scope,restored=restored)


@pytest.mark.parametrize('role',['client','server'])
def test_real_metadata_and_directory_bridge_preserves166_role_context(profile,public_contract,tmp_path,monkeypatch,role):
    env=setup_bridge(tmp_path,monkeypatch,profile,public_contract,role)
    with env.scope()as handle:
        assert handle.public is env.admission.keys.public and handle.admission is env.admission
        assert handle.public_manifest==env.admission.keys.public.manifest
        if role=='server':
            assert tuple(handle.ctx._param_cache.raw_rotation_keys)==profile.rotations
            assert handle.ctx.secret_key is None and handle.ctx.public_key is None
        else:assert handle.ctx.secret_key.name=='secret.npy'
    assert handle.ctx is None and not loader._FAILURE_QUARANTINE
    env.restored()


def test_same_process_nested_role_scope_is_denied_before_second_directory(profile,public_contract,tmp_path,monkeypatch):
    env=setup_bridge(tmp_path,monkeypatch,profile,public_contract)
    with env.scope():
        with pytest.raises(RuntimeError,match='serial'):
            with env.scope():raise AssertionError('nested stage entered')
    env.restored()


@pytest.mark.parametrize('role',['client','server'])
@pytest.mark.parametrize('kind',[ValueError,KeyboardInterrupt])
def test_entered_failure_retains_original_context_maps_and_body_identity(profile,public_contract,tmp_path,monkeypatch,role,kind):
    env=setup_bridge(tmp_path,monkeypatch,profile,public_contract,role);body=kind('synthetic entered body')
    with pytest.raises(kind)as caught:
        with env.scope()as handle:
            context=handle.ctx;closed_before=sum(x[0]=='mapping-close'for x in env.rec.log)
            raise body
    assert caught.value is body and not is_cleanup(body)
    assert sum(x[0]=='mapping-close'for x in env.rec.log)==closed_before
    held=loader._FAILURE_QUARANTINE[-1]
    assert held['context']is context and held['handle']is handle and handle.ctx is context
    assert len(held['public_mappings'])==(335 if role=='server'else 2)
    assert not any(x[0]=='codec-cache-evict'for x in env.rec.log)
    env.restored()


def test_readiness_uncertain_retains_context_and_every_mapping(profile,public_contract,tmp_path,monkeypatch):
    failure=OSError('synthetic readiness failure')
    env=setup_bridge(tmp_path,monkeypatch,profile,public_contract,ready_fault=failure)
    with pytest.raises(OSError)as caught:
        with env.scope()as handle:context=handle.ctx
    assert caught.value is failure and len([x for x in env.rec.log if x[0]=='ready'])==4
    held=loader._FAILURE_QUARANTINE[-1];assert held['context']is context and len(held['public_mappings'])==335
    assert not any(x[0]=='mapping-close'for x in env.rec.log);env.restored()


def test_constructor_failure_still_waits_each_transfer_before_mapping_close(profile,public_contract,tmp_path,monkeypatch):
    failure=ValueError('synthetic constructor')
    env=setup_bridge(tmp_path,monkeypatch,profile,public_contract,constructor_fault=failure)
    with pytest.raises(ValueError)as caught:
        with env.scope():raise AssertionError('failed construction yielded')
    assert caught.value is failure
    waits=[i for i,x in enumerate(env.rec.log)if x[0]=='ready'];closes=[i for i,x in enumerate(env.rec.log)if x[0]=='mapping-close']
    assert len(waits)==4 and len(closes)==335 and max(waits)<min(closes)
    assert not loader._FAILURE_QUARANTINE;env.restored()


def test_early_cleanup_error_later_directory_cancel_crosses_helper_boundary(profile,public_contract,tmp_path,monkeypatch):
    first=OSError('synthetic early mapping close');later=KeyboardInterrupt('synthetic directory close')
    env=setup_bridge(tmp_path,monkeypatch,profile,public_contract,'client',close_faults={'relin_a.npy':first})
    original=readers.ReadDirectory.close;closed=[]
    def close(owner):original(owner);closed.append(owner.path);raise later
    monkeypatch.setattr(readers.ReadDirectory,'close',close)
    with pytest.raises(KeyboardInterrupt)as caught:
        with env.scope():raise AssertionError('early cleanup failure yielded')
    assert caught.value is later and is_cleanup(first)and is_cleanup(later)
    assert [x for x in env.rec.log if x==('mapping-close','relin_a.npy')]==[('mapping-close','relin_a.npy')]
    assert closed==[env.public] and loader._FAILURE_QUARANTINE[0]['public_mappings'][0].name=='relin_a.npy'
    env.restored()


def test_uncertain_final_mapping_closes_quarantine_once_and_block_future_load(profile,public_contract,tmp_path,monkeypatch):
    ordinary=OSError('synthetic final close');cancel=KeyboardInterrupt('synthetic final cancellation')
    env=setup_bridge(tmp_path,monkeypatch,profile,public_contract,'client',close_faults={'secret.npy':ordinary,'public_key.npy':cancel})
    with pytest.raises(KeyboardInterrupt)as caught:
        with env.scope():pass
    assert caught.value is cancel and len(loader._FAILURE_QUARANTINE)==2
    assert [x for x in env.rec.log if x==('mapping-close','secret.npy')]==[('mapping-close','secret.npy')]
    env.restored()
    def forbidden(*args,**kwargs):raise AssertionError('new directory opened after quarantine')
    deps=loader.RecordingDependencies(env.dependencies.security_check,env.dependencies.runtime_factory,forbidden,env.dependencies.map_array)
    with pytest.raises(RuntimeError,match='quarantined'):
        with loader._load_for_recording(env.admission,env.public,env.private,dependencies=deps):pass
    env.restored()


def test_retained_public_and_private_metadata_recheck(profile,public_contract,tmp_path,monkeypatch):
    env=setup_bridge(tmp_path,monkeypatch,profile,public_contract,'client')
    with pytest.raises(ValueError,match='changed'):
        with env.scope():
            path=env.private/'private_manifest.json';path.write_bytes(path.read_bytes()+b' ')
    assert loader._FAILURE_QUARANTINE[-1]['reason']=='failed entered client stage';env.restored()


def test_complete_parent12_and_selected_runtime_function_lineage():
    here=Path(__file__).parent;parent=json.loads((here/'parent12_manifest.json').read_bytes())
    assert len(parent)==12 and all(hashlib.sha256((here/n).read_bytes()).hexdigest()==h for n,h in parent.items())
    old=ast.parse((here/'provenance/toy4v4_key_contexts.py').read_text());new=ast.parse((here/'qwen_key_loader.py').read_text())
    for name in ('_parameters','_keyless','_dispose_context'):
        a=next(n for n in old.body if isinstance(n,ast.FunctionDef)and n.name==name)
        b=next(n for n in new.body if isinstance(n,ast.FunctionDef)and n.name==name)
        assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
