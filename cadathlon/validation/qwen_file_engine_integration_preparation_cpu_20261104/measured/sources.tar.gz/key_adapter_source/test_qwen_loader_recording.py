"""Exact125 loader definition bodies with recording-only host/context seams.

No real paths, arrays, backend imports, contexts or key generation. Signal
installation is skipped by a recording non-main-thread seam; these tests make
no process-wide signal or actual body-authentication claim.
"""
from pathlib import Path
from contextlib import contextmanager
from types import SimpleNamespace
import ast
import hashlib
import sys
import threading
import pytest
import qwen_key_contract as c
import qwen_key_adapter as adapter
from test_qwen_key_contract import fixture, profile

HERE=Path(__file__).resolve().parent
FUNCTIONS={'_load','_parameters','_keyless','_dispose_context','_file_state'}
KEY_METHODS=('gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen')
CODECS=('encrypt','decrypt','encrypt_slots','decrypt_slots','encrypt_slots_batch','decrypt_slots_batch','decode')


def recorded_loader(profile,role,*,body_fault=None,map_fault=None,ready_fault=None,
                    constructor_fault=None,close_faults=None,manifest_drift=False):
    raw,private,ids,identity=fixture(profile,role)
    public=c.authenticate_public(raw,profile,ids,role=role)
    secret=c.authenticate_private(private,public)if role=='client'else None
    admission=adapter.admit(public,identity,secret)
    log=[];maps=[];transfers=[];handles=[];close_faults=close_faults or {}
    all_specs={s.name:s for s in profile.arrays}
    specs={name:(s.shape,s.moduli)for name,s in all_specs.items()}
    originals={};modules={}
    for alias in ('key_gen','jaxite_word.key_gen'):
        module=SimpleNamespace()
        for name in KEY_METHODS:
            def original(*args,**kwargs):return 'record-only keygen sentinel'
            setattr(module,name,original);originals[alias,name]=original
        modules[alias]=module
    def check_key_guards():
        for alias,module in modules.items():
            for name in KEY_METHODS:
                with pytest.raises(RuntimeError):getattr(module,name)()
                log.append(('key-denied',alias,name))
    class Directory:
        def __init__(self,path,private=False):
            self.path=path;self.private=private;self.fd=path;log.append(('directory-open',path,private))
        def check(self):log.append(('directory-check',self.path))
        def close(self):log.append(('directory-close',self.path));self.fd=None
    def state():
        return SimpleNamespace(st_dev=1,st_ino=2,st_size=3,st_mtime_ns=4,st_ctime_ns=5)
    class Map:
        def __init__(self,name,shape,moduli):
            self.name=name;self.shape=shape;self.moduli=moduli;self._mmap=self
        def close(self):
            log.append(('mapping-close',self.name))
            if self.name in close_faults:raise close_faults[self.name]
    def map_array(owner,name,descriptor,shape,moduli):
        owner.check();log.append(('map',name,shape))
        if name==map_fault:raise ValueError('recorded mapping fault')
        spec=profile.secret if name=='secret.npy'else all_specs[name]
        spec.validate(descriptor);assert shape==spec.shape and tuple(moduli)==spec.moduli
        value=Map(name,shape,moduli);maps.append(value);return value,(1,2,3,4,5)
    class Transfer:
        def __init__(self,label):self.label=label;transfers.append(self);log.append(('transfer',label))
        def transpose(self,*axes):
            assert axes==(0,2,1);return Transfer(self.label+'.formatted')
        def block_until_ready(self):
            log.append(('ready',self.label))
            if ready_fault is not None and self is transfers[0]:raise ready_fault
    def asarray(value,dtype):assert dtype=='uint32';return Transfer(value.name)
    class Context:
        def __init__(self,parameters,*,batch,dnum):
            log.append(('context-construct',batch,dnum));check_key_guards()
            assert batch==1 and dnum==8 and parameters['degree']==131072
            assert parameters['q_towers']==profile.parameters['q_towers']
            assert parameters['p_towers']==profile.parameters['p_towers']
            if role=='server':
                assert 'public_key'not in parameters and 'secret_key'not in parameters
                assert len(parameters['evaluation_key'])==2
                for name in CODECS:
                    with pytest.raises(RuntimeError):getattr(self,name)()
                    log.append(('codec-denied',name))
            else:
                assert parameters['public_key'].name=='public_key.npy'
                assert parameters['secret_key'].name=='secret.npy'
                assert self.decrypt_slots()=='record-only codec'
            if constructor_fault is not None:raise constructor_fault
            self.parameters=parameters;self.q_towers=parameters['q_towers'];self.p_towers=parameters['p_towers']
            self.degree_layout=parameters['degree_layout'];self.public_key=parameters.get('public_key');self.secret_key=parameters.get('secret_key')
            self._param_cache=SimpleNamespace(secret_key=self.secret_key,per_level_rotation_keys=False,
                raw_rotation_keys={},coef_maps={},_formatted_rotation_keys={})
        def program_initialization(self,rotations,*,dnum,r,c,batch,pregenerated_rotation_keys,cache_rotation_keys):
            assert tuple(rotations)==profile.rotations and (dnum,r,c,batch,cache_rotation_keys)==(8,256,512,1,True)
            assert set(pregenerated_rotation_keys)==set(profile.rotations)
            for i in rotations:
                for part in ('a','b'):assert pregenerated_rotation_keys[i][part].name==f'rot_{i}_{part}.npy'
            self._param_cache.raw_rotation_keys=pregenerated_rotation_keys
            self._param_cache.coef_maps={i:object()for i in rotations}
            log.append(('program-initialization',tuple(rotations)))
    for name in CODECS:
        def codec(self,*args,**kwargs):return 'record-only codec'
        setattr(Context,name,codec);originals['Context',name]=codec
    runtime=SimpleNamespace(Context=Context,key_modules=modules,
        jax=SimpleNamespace(numpy=SimpleNamespace(asarray=asarray),clear_caches=lambda:log.append(('global-cache-clear',))),
        ckks=SimpleNamespace(evict_context_caches=lambda ctx:log.append(('codec-cache-evict',))),
        polynomial=SimpleNamespace(_POLYNOMIAL_REGISTRY={}))
    def public_contract(profile_bytes,plan_bytes):
        admission.check();assert profile_bytes==profile.profile_bytes and plan_bytes==profile.plan_bytes
        log.append(('public-admission',));return profile.parameters,profile.rotations
    def security(p):assert p==profile.parameters;log.append(('security-check-recording',))
    def read_public(owner,p,rotations):return public.check(),specs,raw
    def read_private(owner,manifest,raw_public):
        assert role=='client'and manifest==public.manifest and raw_public==raw
        return secret.check(),private
    def read(fd,name,maximum):
        assert maximum==1<<20 and name=='public_manifest.json'
        return raw+b' 'if manifest_drift else raw
    def crypto():log.append(('recording-runtime',));return runtime
    fake_os=SimpleNamespace(environ={},listdir=lambda fd:list(specs)+['public_manifest.json'],stat=lambda *args,**kwargs:state())
    namespace=dict(contextmanager=contextmanager,SimpleNamespace=SimpleNamespace,sys=sys,
        os=fake_os,gc=SimpleNamespace(collect=lambda:log.append(('gc',))),
        signal=SimpleNamespace(SIGINT=2,SIGTERM=15,SIGHUP=1),
        threading=SimpleNamespace(current_thread=lambda:1,main_thread=lambda:2),
        keys=SimpleNamespace(public_contract=public_contract,_security_check=security,_read=read),
        _ACTIVE=threading.Lock(),_FAILURE_QUARANTINE=[],_ReadDirectory=Directory,
        _map_array=map_array,_read_public=read_public,_read_private=read_private,_crypto=crypto,
        KEYGEN_METHODS=KEY_METHODS,CODEC_METHODS=CODECS)
    tree=ast.parse((HERE/'provenance/default125_key_contexts.py').read_text())
    nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in FUNCTIONS]
    assert {n.name for n in nodes}==FUNCTIONS
    exec(compile(ast.Module(body=nodes,type_ignores=[]),'exact-default125-loader-AST','exec'),namespace)
    def open_scope():return namespace['_load']('public-recording',None if role=='server'else 'private-recording',
        profile_bytes=profile.profile_bytes,plan_bytes=profile.plan_bytes)
    def restored():
        for (alias,name),original in originals.items():assert getattr(Context if alias=='Context'else modules[alias],name)is original
        assert namespace['_ACTIVE'].acquire(blocking=False);namespace['_ACTIVE'].release()
    return SimpleNamespace(open=open_scope,namespace=namespace,log=log,maps=maps,transfers=transfers,
                           runtime=runtime,restored=restored,Transfer=Transfer,admission=admission)


def test_server_complete166_inventory_and_retirement_order(profile):
    rec=recorded_loader(profile,'server')
    with rec.open()as handle:
        assert handle.ctx.secret_key is None and handle.ctx.public_key is None
        assert len(rec.maps)==335 and len(rec.transfers)==4
        assert not any(x[0]=='mapping-close'for x in rec.log)
        assert rec.log.index(('public-admission',))<next(i for i,x in enumerate(rec.log)if x[0]=='directory-open')
        handle.ctx._param_cache._formatted_rotation_keys={262143:{'a':rec.Transfer('lazy-conjugate')}}
    assert handle.ctx is None and not rec.namespace['_FAILURE_QUARANTINE']
    ready=[i for i,x in enumerate(rec.log)if x[0]=='ready'];closed=[i for i,x in enumerate(rec.log)if x[0]=='mapping-close']
    assert len(ready)==5 and len(closed)==335 and max(ready)<min(closed)
    assert len([x for x in rec.log if x[0]=='key-denied'])==8
    assert len([x for x in rec.log if x[0]=='codec-denied'])==7
    rec.restored()


def test_client_authenticates335_but_retains_only_pke_and_secret(profile):
    rec=recorded_loader(profile,'client')
    with rec.open()as handle:
        assert len(rec.maps)==336 and len(rec.transfers)==0
        assert len([x for x in rec.log if x[0]=='mapping-close'])==334
        assert handle.ctx.decrypt_slots()=='record-only codec'
        assert handle.private_manifest['context_id']==handle.public_manifest['context_id']
    assert handle.ctx is None
    assert [x[1]for x in rec.log if x[0]=='mapping-close'][-2:]==['secret.npy','public_key.npy']
    rec.restored()


def test_serial_nonoverlapping_roles_and_lock_release(profile):
    rec=recorded_loader(profile,'server')
    with rec.open():
        with pytest.raises(RuntimeError,match='serial'): 
            with rec.open():raise AssertionError('nested loader entered')
    rec.restored()
    with rec.open():pass
    rec.restored()


@pytest.mark.parametrize('kind',[ValueError,KeyboardInterrupt,SystemExit])
def test_entered_server_body_failure_preserves_primary_and_quarantines(profile,kind):
    rec=recorded_loader(profile,'server');failure=kind('synthetic body')
    with pytest.raises(kind)as caught:
        with rec.open():raise failure
    assert caught.value is failure and not any(x[0]=='mapping-close'for x in rec.log)
    q=rec.namespace['_FAILURE_QUARANTINE'];assert len(q)==1 and len(q[0]['public_mappings'])==335
    assert q[0]['reason']=='failed entered server stage';rec.restored()
    before=len(rec.log)
    with pytest.raises(RuntimeError,match='quarantined'):
        with rec.open():raise AssertionError('quarantined loader entered')
    assert not any(x[0]=='directory-open'for x in rec.log[before:]);rec.restored()


@pytest.mark.parametrize('kind',[OSError,KeyboardInterrupt])
def test_uncertain_transfer_readiness_quarantines_all_original_maps(profile,kind):
    failure=kind('synthetic readiness');rec=recorded_loader(profile,'server',ready_fault=failure)
    with pytest.raises(kind)as caught:
        with rec.open():pass
    assert caught.value is failure and len([x for x in rec.log if x[0]=='ready'])==4
    assert not any(x[0]=='mapping-close'for x in rec.log)
    assert len(rec.namespace['_FAILURE_QUARANTINE'][0]['public_mappings'])==335
    rec.restored()


def test_constructor_failure_synchronizes_transfers_before_host_retirement(profile):
    failure=ValueError('synthetic constructor');rec=recorded_loader(profile,'server',constructor_fault=failure)
    with pytest.raises(ValueError)as caught:
        with rec.open():raise AssertionError('constructor fault entered')
    assert caught.value is failure
    ready=[i for i,x in enumerate(rec.log)if x[0]=='ready'];closed=[i for i,x in enumerate(rec.log)if x[0]=='mapping-close']
    assert len(ready)==4 and len(closed)==335 and max(ready)<min(closed)
    assert not rec.namespace['_FAILURE_QUARANTINE'];rec.restored()


def test_partial_mapping_fault_attempts_pre_runtime_cleanup(profile):
    rec=recorded_loader(profile,'server',map_fault='rot_8_a.npy')
    with pytest.raises(ValueError,match='mapping'):
        with rec.open():raise AssertionError('mapping fault entered')
    assert len(rec.maps)==17 and len([x for x in rec.log if x[0]=='mapping-close'])==17
    assert not any(x[0]=='recording-runtime'for x in rec.log);rec.restored()


def test_postyield_manifest_change_is_failed_entered_server_and_quarantined(profile):
    rec=recorded_loader(profile,'server',manifest_drift=True)
    with pytest.raises(ValueError,match='manifest'):
        with rec.open():pass
    assert rec.namespace['_FAILURE_QUARANTINE']and not any(x[0]=='mapping-close'for x in rec.log)
    rec.restored()


def test_cleanup_only_cancellation_and_genuine_client_body_priority(profile):
    ordinary=OSError('synthetic close');cancel=KeyboardInterrupt('synthetic close cancellation')
    rec=recorded_loader(profile,'client',close_faults={'secret.npy':ordinary,'public_key.npy':cancel})
    with pytest.raises(KeyboardInterrupt)as caught:
        with rec.open():pass
    assert caught.value is cancel;rec.restored()
    body=ValueError('synthetic genuine body')
    rec=recorded_loader(profile,'client',close_faults={'secret.npy':ordinary,'public_key.npy':cancel})
    with pytest.raises(ValueError)as caught:
        with rec.open():raise body
    assert caught.value is body
    assert [x[1]for x in rec.log if x[0]=='directory-close']==['private-recording','public-recording']
    rec.restored()


def test_loader_source_pin_is_exact_default125():
    source=(HERE/'provenance/default125_key_contexts.py').read_bytes()
    assert hashlib.sha256(source).hexdigest()=='056627ee3080f3d6ec7445ceb2f25171b49c7fc08eb256449a656b100f5853f0'
