from pathlib import Path
from dataclasses import replace
import ast
import hashlib
import json
import math
import pytest
import qwen_key_contract as c
import qwen_key_adapter as a

HERE=Path(__file__).resolve().parent


@pytest.fixture(scope='module')
def profile():
    return c.PublicProfile.from_bytes((HERE/'public_inputs/profile_audit.json').read_bytes(),
                                    (HERE/'public_inputs/actual_key_plan.json').read_bytes())


def fixture(profile,role='server'):
    arrays={s.name:dict(sha256=c.sha(s.name.encode()),dtype='uint32',shape=list(s.shape),bytes=s.raw_bytes+128)
            for s in profile.arrays}
    body=c.public_body(profile,arrays,c.KEYGEN)
    public=body|dict(context_id=c.sha(c.canonical(body)))
    raw=c.canonical(public)
    s=profile.secret
    private=c.canonical(dict(schema='cross-qwen-full-private-keys-v1',context_id=public['context_id'],
        public_manifest_sha256=c.sha(raw),bindings=c.bindings(),
        secret=dict(sha256=c.sha(b'synthetic-secret-descriptor-only'),dtype='uint32',shape=list(s.shape),bytes=s.raw_bytes+128)))
    ids=c.ExpectedIds(public['context_id'],c.sha(raw),c.KEYGEN,'1'*64,'2'*64,'3'*64,
                      c.sha(private)if role=='client'else None)
    identity={k:getattr(ids,k)for k in ('context_id','model_id','producer_source_manifest_sha256','consumer_source_manifest_sha256')}
    return raw,private,ids,c.canonical(identity)


def rebound_public(profile,raw,ids,mutate):
    value=json.loads(raw);mutate(value)
    body={k:v for k,v in value.items()if k!='context_id'}
    value['context_id']=c.sha(c.canonical(body));raw=c.canonical(value)
    return raw,replace(ids,public_manifest_sha256=c.sha(raw),context_id=value['context_id'])


def test_complete_specs_integer_security_and_original_inventory_ast(profile):
    p=profile.parameters;keys=profile.rotations;rows=profile.arrays
    assert len(rows)==335 and len(keys)==166 and keys[-1]==262143 and 65535 in keys
    assert len(p['q_towers'])==100 and len(p['p_towers'])==14
    product=math.prod(p['q_towers']+p['p_towers']);assert product.bit_length()==3403<=3523
    assert all(math.prod(p['p_towers'])>=math.prod(p['q_towers'][s:s+13])for s in range(0,100,13))
    assert rows[0].shape==(2,100,131072) and all(r.shape==(8,114,131072)for r in rows[1:])
    assert profile.secret.shape==(100,131072)
    assert profile.resources['public_array_bytes']==159807176704
    assert profile.resources['private_array_bytes']==52428800
    tree=ast.parse((HERE/'provenance/selected_client_io.py').read_bytes())
    node=next(x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name=='inventory')
    namespace={};exec(compile(ast.Module(body=[node],type_ignores=[]),'original-inventory-AST','exec'),namespace)
    assert namespace['inventory'](p,keys)=={s.name:(s.shape,s.moduli)for s in rows}


@pytest.mark.parametrize('role',['client','server'])
def test_public_private_admission_and_fresh_views(profile,role):
    raw,private,ids,identity=fixture(profile,role)
    pub=c.authenticate_public(raw,profile,ids,role=role)
    priv=c.authenticate_private(private,pub)if role=='client'else None
    admission=a.admit(pub,identity,priv);assert admission.execution_authorized is False
    view=pub.manifest;view['arrays'].clear();view['parameters']['q_towers'].clear()
    assert len(pub.manifest['arrays'])==335 and len(pub.manifest['parameters']['q_towers'])==100
    p=profile.parameters;p['q_towers'].clear();assert len(profile.parameters['q_towers'])==100
    if priv:
        view=priv.manifest;view['secret']['shape'].clear();assert priv.manifest['secret']['shape']==[100,131072]


@pytest.mark.parametrize('field',['context_id','public_manifest_sha256','keygen_source_sha256'])
def test_external_expectations_are_not_derived_from_manifest(profile,field):
    raw,_,ids,_=fixture(profile)
    with pytest.raises(ValueError):c.authenticate_public(raw,profile,replace(ids,**{field:'a'*64}),role='server')


@pytest.mark.parametrize('field',['context_id','model_id','producer_source_manifest_sha256','consumer_source_manifest_sha256'])
def test_expected_role_identity_is_compared(profile,field):
    raw,_,ids,identity=fixture(profile);pub=c.authenticate_public(raw,profile,ids,role='server')
    value=json.loads(identity);value[field]='f'*64
    with pytest.raises(ValueError):a.admit(pub,c.canonical(value))


@pytest.mark.parametrize('bad',[None,False,0,'a'*63,'A'*64])
def test_strict_external_hash_types(profile,bad):
    raw,_,ids,_=fixture(profile)
    with pytest.raises(ValueError):c.authenticate_public(raw,profile,replace(ids,context_id=bad),role='server')


@pytest.mark.parametrize('role',['client','server'])
def test_private_expectation_is_role_specific(profile,role):
    raw,_,ids,_=fixture(profile,role)
    ids=replace(ids,private_manifest_sha256=None if role=='client'else '4'*64)
    with pytest.raises(ValueError):c.authenticate_public(raw,profile,ids,role=role)


@pytest.mark.parametrize('mutation',[
    lambda v:v.update(schema='cross-bert-full-public-keys-v1'),
    lambda v:v['bindings'].update(candidate_sha256='a'*64),
    lambda v:v['parameters'].update(dnum=6),
    lambda v:v['parameters'].update(batch=True),
    lambda v:v.update(reusable_rotation_keys=1),
    lambda v:v['security_target'].update(bits=192),
    lambda v:v.update(keygen_source_sha256='b'*64),
    lambda v:v['rotations'].__setitem__(-1,65535),
    lambda v:v['rotations'].reverse(),
    lambda v:v['arrays'].pop('rot_262143_a.npy'),
    lambda v:v['arrays'].update(unexpected={}),
    lambda v:v.update(extra='forbidden'),
])
def test_self_consistent_rehashed_substitution_is_rejected(profile,mutation):
    raw,_,ids,_=fixture(profile);raw,ids=rebound_public(profile,raw,ids,mutation)
    with pytest.raises(ValueError):c.authenticate_public(raw,profile,ids,role='server')


@pytest.mark.parametrize('field,value',[
    ('dtype','uint64'),('dtype',False),('shape',[8,131072,114]),('shape',[True,100,131072]),
    ('bytes',True),('bytes',104857600),('bytes',104857600+4097),('sha256','f'*63)])
def test_array_descriptor_bounds_and_types(profile,field,value):
    raw,_,ids,_=fixture(profile)
    raw,ids=rebound_public(profile,raw,ids,lambda v:v['arrays']['public_key.npy'].update({field:value}))
    with pytest.raises(ValueError):c.authenticate_public(raw,profile,ids,role='server')


@pytest.mark.parametrize('which',['public','private'])
def test_metadata_caps_and_duplicate_keys(profile,which):
    raw,private,ids,_=fixture(profile,'client');pub=c.authenticate_public(raw,profile,ids,role='client')
    maximum=c.PUBLIC_LIMIT if which=='public'else c.PRIVATE_LIMIT
    for bad in (b' '* (maximum+1),b'{"a":1,"a":2}',b'{"x":NaN}',b'{"x":1e9999}'):
        with pytest.raises(ValueError):c.parse(bad,maximum)


@pytest.mark.parametrize('mutation',[
    lambda v:v.update(context_id='5'*64),
    lambda v:v.update(public_manifest_sha256='6'*64),
    lambda v:v.update(schema='cross-bert-full-private-keys-v1'),
    lambda v:v['bindings'].update(config_sha256='7'*64),
    lambda v:v['secret'].update(shape=[1,100,131072]),
    lambda v:v['secret'].update(bytes=52428800+4097),
    lambda v:v.update(extra=True),
])
def test_private_rehashed_cross_binding_rejected(profile,mutation):
    raw,private,ids,_=fixture(profile,'client');v=json.loads(private);mutation(v);private=c.canonical(v)
    ids=replace(ids,private_manifest_sha256=c.sha(private));pub=c.authenticate_public(raw,profile,ids,role='client')
    with pytest.raises(ValueError):c.authenticate_private(private,pub)


def test_stale_private_external_hash_and_server_private_rejected(profile):
    raw,private,ids,_=fixture(profile,'client');pub=c.authenticate_public(raw,profile,replace(ids,private_manifest_sha256='8'*64),role='client')
    with pytest.raises(ValueError):c.authenticate_private(private,pub)
    raw,private,ids,_=fixture(profile,'server');pub=c.authenticate_public(raw,profile,ids,role='server')
    with pytest.raises(ValueError):c.authenticate_private(private,pub)


def test_open_entries_deny_before_paths_or_admission_access():
    class Poison:
        def __getattribute__(self,name):raise AssertionError('object inspected before denial')
        def __fspath__(self):raise AssertionError('path inspected before denial')
    with pytest.raises(PermissionError):a.open_server(Poison(),Poison())
    with pytest.raises(PermissionError):a.open_client(Poison(),Poison(),Poison())


def test_binding_replay_detects_object_mutation(profile):
    raw,_,ids,identity=fixture(profile);pub=c.authenticate_public(raw,profile,ids,role='server');admission=a.admit(pub,identity)
    object.__setattr__(pub,'raw',raw+b' ')
    with pytest.raises(ValueError):admission.check()


def test_exact_source_inputs_reject_drift(profile):
    with pytest.raises(ValueError):c.PublicProfile.from_bytes(profile.profile_bytes+b' ',profile.plan_bytes)
    with pytest.raises(ValueError):c.PublicProfile.from_bytes(profile.profile_bytes,profile.plan_bytes+b' ')


def test_selected_io_contains_no_generation_or_unsafe_authentication():
    tree=ast.parse((HERE/'provenance/selected_client_io.py').read_text())
    names={x.name for x in tree.body if isinstance(x,(ast.FunctionDef,ast.ClassDef))}
    assert names=={'canonical','digest','_json','inventory','_CloseState','_stream','_sha_fd','_read'}
    assert not {'generate','_store','_write','_authenticate_array'}&names
    provenance=json.loads((HERE/'source_provenance.json').read_bytes())
    for name,row in provenance['sources'].items():
        assert hashlib.sha256((HERE/name).read_bytes()).hexdigest()==row['sha256']
