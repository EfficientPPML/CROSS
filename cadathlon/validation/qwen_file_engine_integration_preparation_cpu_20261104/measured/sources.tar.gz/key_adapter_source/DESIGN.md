# Qwen166 existing-key adapter preparation

This initial successor provides public typed manifest and descriptor admission,
plus recording-only tests of the exact reviewed default125 loader lifetime.
Actual `open_client` and `open_server` deny before any body read, path access,
backend import, context construction or key generation. No actual authority or
key-production evidence is created by these helpers or synthetic manifests.

The public profile is the exact208 depth49/p60/d8 audit row: N131072,65536 slots,
Q100/P14, CD2, layout256x512, precision32, batch1 and the original canonical
scale/distribution. The exact public234-matrix plan supplies166 ordered literal
indices, including distinct65535 and262143 (conjugation); no modulo reduction.
Its original candidate7f6478 provenance is retained. The completed208 source
bridge uses that unchanged key support for expanded candidate344954.

The existing wire layout is preserved: one PKE array (2,100,131072), two relin
arrays and332 rotation arrays (8,114,131072), all uint32 standard NTT residues.
Private secret shape is (100,131072). Public metadata is bounded1MiB, private
metadata64KiB; every declared NPY file is bounded by raw bytes+4096 and must be
larger than raw data. This descriptor check does not verify a header or residue
body. Fixed-profile QP bitlength/P-coverage are independently checked with
integers; a future real loader must still call the actual reviewed backend
security functions before context construction.

External expected context ID/public-manifest SHA/key-generation source SHA are
separate required inputs. Client admission also requires the private-manifest
SHA; server admission forbids it. The expected keygen source must match the
reviewed742e6af9 source identity, and both expected and manifest identities must
match. Neither imported source bytes nor a self-consistent context digest proves
that key generation occurred: a future independently admitted producer report,
source closure and terminal receipt remain required.

Expected model/producer/consumer IDs are compared separately against the
already structurally validated public file identity from Transformer's
PublicContract. This comparison is not a replacement for the full public file
schema or a role grant. Immutable binding properties replay authentication and
return fresh parsed views; caller-mutated dictionaries cannot alter bindings.

The recording tests compile only the exact existing `_load`, `_parameters`,
`_keyless` and `_dispose_context` definition bodies from the public copied125
key_contexts source, with synthetic directory/mapping/security/context/JAX
seams. They exercise all335 descriptors, both keygen aliases, server codec
denial, partial setup, post-yield checks, synchronization, cleanup, quarantine
and serial lock exclusion. They never invoke the original reader/crypto
factories or construct real backend contexts. Selected client reader bodies are
copied only for provenance; generate/_store/_write/_authenticate_array are not
included or selected. Later active loader integration needs a separately
reviewed source-bound successor, including exact imported source checks,
producer authority, private permission/header/residue checks and role grant.

No original/frozen/live files are edited, and no actual model, token, key,
ciphertext or private manifest bodies are read by this preparation.
