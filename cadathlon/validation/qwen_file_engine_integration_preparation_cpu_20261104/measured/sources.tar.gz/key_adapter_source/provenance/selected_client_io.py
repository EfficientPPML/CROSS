"""Selected existing-key reader definitions only; not a generation module.

Exact default125 selected definition bodies. No generate, _store, _write,
_authenticate_array or real crypto factory is included or selected.
"""
from contextlib import contextmanager
import hashlib,json,os,stat,sys
_IO_FAILURE_QUARANTINE=[]

def canonical(value):return (json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()

def digest(value):return hashlib.sha256(canonical(value)).hexdigest()

def _json(raw):
    def pairs(items):
        result={}
        for k,v in items:
            if k in result:raise ValueError('duplicate JSON key')
            result[k]=v
        return result
    def invalid(value):raise ValueError('nonfinite JSON constant')
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=invalid)

def inventory(p,rotations):
    q=len(p['q_towers']);n=p['degree'];alpha=(q+p['dnum']-1)//p['dnum'];parts=(q+alpha-1)//alpha
    switched=(parts,q+len(p['p_towers']),n)
    result={'public_key.npy':((2,q,n),tuple(p['q_towers']))}
    for name in ('relin_a.npy','relin_b.npy'):result[name]=(switched,tuple(p['q_towers']+p['p_towers']))
    for index in rotations:
        for part in ('a','b'):result[f'rot_{index}_{part}.npy']=(switched,tuple(p['q_towers']+p['p_towers']))
    return result

class _CloseState:
    """Share cleanup-origin state across nested metadata handles.

    Genuine body failures remain primary. Cleanup-only cancellation outranks
    ordinary cleanup errors. Uncertain resources are retained, never retried.
    This is dedicated-process failure handling, not process-wide atomicity.
    """
    def __init__(self):self.errors=[]
    def cleanup(self,label,action,owner=None):
        primary=sys.exception();cleanup_only=any(primary is error for error in self.errors)
        try:action()
        except BaseException as error:
            self.errors.append(error)
            if owner is not None:_IO_FAILURE_QUARANTINE.append((owner,error))
            if primary is None:raise
            if cleanup_only and isinstance(primary,Exception)and not isinstance(error,Exception):
                error.add_note('earlier metadata cleanup: '+repr(primary));raise
            if error is not primary:primary.add_note(label+': '+repr(error))
    def close(self,fd):
        self.cleanup('metadata descriptor close',lambda:os.close(fd),('descriptor',fd))

@contextmanager
def _stream(fd,mode,state):
    # The caller retains the descriptor even if stream construction fails.
    stream=os.fdopen(fd,mode,closefd=False)
    try:yield stream
    finally:state.cleanup('metadata stream close',stream.close,stream)

def _sha_fd(fd):
    # Borrow the original descriptor; no transfer/duplication is required.
    os.lseek(fd,0,os.SEEK_SET);digest=hashlib.sha256()
    while True:
        block=os.read(fd,1<<20)
        if not block:break
        digest.update(block)
    return digest.hexdigest()

def _read(directory_fd,name,maximum,*,_close_state=None):
    state=_CloseState()if _close_state is None else _close_state
    fd=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=directory_fd)
    try:
        info=os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_size>maximum:raise ValueError('regular bounded key file required')
        chunks=[];remaining=maximum+1
        while remaining:
            block=os.read(fd,min(remaining,1<<20))
            if not block:break
            chunks.append(block);remaining-=len(block)
        raw=b''.join(chunks)
        if len(raw)>maximum:raise ValueError('key metadata exceeds limit')
        fields=('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns');after=os.fstat(fd)
        if len(raw)!=info.st_size or any(getattr(after,n)!=getattr(info,n)for n in fields):raise ValueError('key metadata changed during descriptor read')
        return raw
    finally:state.close(fd)
