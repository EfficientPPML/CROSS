from pathlib import Path
from types import SimpleNamespace
import json
import pytest
import reconstruction_process as p

def setup(tmp_path):
 protected=tmp_path/"synthetic-borrowed-private";protected.mkdir(mode=0o700)
 root=tmp_path/"synthetic-source";root.mkdir()
 blobs={"execution_authorization.json":b'{"execute":false}',"reconstruction_protected_paths.json":json.dumps(dict(schema="qwen-candidate-reconstruction-protected-paths-v1",paths=[str(protected)])).encode()}
 return protected,root,blobs

@pytest.mark.parametrize("inside",[True,False])
def test_preflight_output_respects_borrowed_root(tmp_path,monkeypatch,inside):
 protected,root,blobs=setup(tmp_path);target=(protected if inside else tmp_path)/"fresh-evidence"
 args=SimpleNamespace(output=str(target),mode="collect-preflight",grant=None,grant_sha256=None,request=None,request_sha256=None,manifest_sha256="a"*64)
 class Audit:
  def __init__(self,*a):self.denials=[]
  def install(self):pass
 monkeypatch.setattr(p,"Audit",Audit)
 monkeypatch.setattr(p,"supervise",lambda output,*a:(output.close(),0)[1])
 if inside:
  with pytest.raises((ValueError,PermissionError)):p.collect(args,b"{}",{},blobs,{},root)
  assert not target.exists()
 else:
  assert p.collect(args,b"{}",{},blobs,{},root)==0 and target.is_dir()

@pytest.mark.parametrize("inside",[True,False])
def test_public_grant_path_rejected_before_read(tmp_path,monkeypatch,inside):
 protected,root,blobs=setup(tmp_path);target=(protected if inside else tmp_path)/"grant.json";target.write_text('{"execute":false}')
 touched=[];real=p.read
 def read(path,*a,**kw):touched.append(str(path));return real(path,*a,**kw)
 monkeypatch.setattr(p,"read",read)
 args=SimpleNamespace(output=str(tmp_path/"fresh-evidence"),mode="collect-reconstruct",grant=str(target),grant_sha256=p.sha(target.read_bytes()),request=str(tmp_path/"request.json"),request_sha256="b"*64)
 with pytest.raises((ValueError,PermissionError)):p.public_request(args,b"{}",{},blobs)
 assert bool(touched)is (not inside),"private grant bytes were opened before admission"
