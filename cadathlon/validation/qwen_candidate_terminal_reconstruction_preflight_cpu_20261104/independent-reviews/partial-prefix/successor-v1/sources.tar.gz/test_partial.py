"""Synthetic first-input stop cannot retain future outputs."""
import hashlib
import pytest
import verify_records as r
import verify_statistics as s
from synthetic_records import manifest,domain_observations,metric

def record(operators,blocks):
    entry=r.entries()[0];prefix=(1,);pin='a'*64;plan=s.domain_plan(manifest(),1)
    obs=domain_observations(plan,True);label=plan[0][0]
    row=dict(entry=entry,manifest_sha256=pin,token_ids=[1],context_sha256=s.context_hash(prefix),status='candidate_invalid',candidate_top1=None,numeric_pass=False,domain_pass=False,failure=dict(type='InvalidCircuit',label=label,record=obs['domains'][label]),operator_metrics=operators,block_metrics=blocks,full_logit_metric=None,observations=obs,observations_sha256=hashlib.sha256(s.canonical(obs)).hexdigest(),all_logits=0)
    return row,entry,prefix,pin,plan

@pytest.mark.parametrize('kind',['operator','block'])
def test_first_norm_input_stop_rejects_future_output(kind):
    operators={'0.input.inverse_sqrt':metric('operator',1024)}if kind=='operator'else{}
    blocks=[metric('block',1024)]if kind=='block'else[]
    row,e,prefix,pin,plan=record(operators,blocks)
    with pytest.raises(ValueError):r.candidate_journal(row,e,prefix,pin,plan,{})

def test_first_norm_input_stop_with_no_future_output_control():
    row,e,prefix,pin,plan=record({},[])
    result=r.candidate_journal(row,e,prefix,pin,plan,{})
    assert not result['complete']and result['operators']==result['blocks']==0
