from pathlib import Path
import json,os,signal,subprocess,sys
import pytest
@pytest.mark.parametrize("kind",["calibration","journal_race"])
def test_fifo_rejected_without_blocking(kind):
 p=subprocess.Popen([sys.executable,"-I","-B",str(Path(__file__).with_name("fifo_child.py")),kind],stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 timed_out=False
 try:out,err=p.communicate(timeout=2)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(p.pid,signal.SIGKILL);out,err=p.communicate(timeout=5)
 try:os.killpg(p.pid,0)
 except ProcessLookupError:absent=True
 else:absent=False
 receipt=dict(kind=kind,pid=p.pid,pgid=p.pid,exit_code=p.returncode,reaped=True,group_absent=absent,timed_out=timed_out,stdout=out.decode(),stderr=err.decode())
 Path(__file__).parent.parent.joinpath(kind+"-receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
 assert absent
 assert not timed_out,"FIFO open blocked before regular-file rejection"
 assert p.returncode==0 and b"rejected_before_read"in out,(out,err)
