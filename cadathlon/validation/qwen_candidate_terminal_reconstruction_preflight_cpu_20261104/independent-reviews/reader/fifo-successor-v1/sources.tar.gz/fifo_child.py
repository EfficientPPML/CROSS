from pathlib import Path
import os,sys,tempfile,types
sys.path.insert(0,str(Path(__file__).parent))
import private_journals as p
p.require_admitted=lambda value:value
with tempfile.TemporaryDirectory(prefix="synthetic-reconstruction-fifo-") as path:
 root=Path(path);root.chmod(0o700);info=root.stat()
 if sys.argv[1]=="calibration":
  file=root/"calibration_inputs.json";os.mkfifo(file,0o600);st=file.stat()
  d=dict(path=str(file),identity=[st.st_dev,st.st_ino],parent_identity=[info.st_dev,info.st_ino],bytes=1,sha256="0"*64,mode="0600",parent_mode="0700")
  try:p.CalibrationRead(types.SimpleNamespace(calibration_bytes=p.canonical(d)))
  except ValueError:print("rejected_before_read",flush=True)
  else:raise AssertionError("FIFO accepted")
 else:
  file=root/"ledger.json";file.write_bytes(b"{}");file.chmod(0o600)
  store=p.JournalStore(types.SimpleNamespace(private_path=str(root),private_identity=(info.st_dev,info.st_ino)))
  original=os.open
  def swap(name,flags,*args,**kw):
   if name=="ledger.json":
    file.unlink();os.mkfifo(file,0o600)
   return original(name,flags,*args,**kw)
  p.os.open=swap
  try:
   try:store.read("ledger.json")
   except ValueError:print("rejected_before_read",flush=True)
   else:raise AssertionError("FIFO accepted")
  finally:store.close()
