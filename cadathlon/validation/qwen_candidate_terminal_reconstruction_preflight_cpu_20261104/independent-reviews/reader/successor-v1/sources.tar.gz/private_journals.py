"""Held, read-only private journal scope; no CLI or launch authority.

All public admission is completed before the first private stat/open. A future
root worker must still own source checks, signal scopes, public publication and
independent process retirement. This module never removes private evidence.
"""
import hashlib
import os
from pathlib import Path
import re
import stat
from producer_admission import require_admitted
from verify_records import parse
from verify_statistics import canonical
from sources.cleanup_origin import cleanup_origin,protect_body,choose,mark_cleanup

MAX_JOURNAL=16<<20
MAX_LEDGER=64<<20
MAX_TOTAL=16<<30
FAILURE_QUARANTINE=[]

def close_fd(fd,owner):
    try:os.close(fd)
    except BaseException as error:
        FAILURE_QUARANTINE.append((owner,fd,error))
        raise mark_cleanup(error)

def state(v):return(v.st_dev,v.st_ino,v.st_mode,v.st_uid,v.st_nlink,v.st_size,v.st_mtime_ns,v.st_ctime_ns)
def ident(v):return(v.st_dev,v.st_ino)

def finish_all(primary,operations):
    body=None if primary is None or cleanup_origin(primary)else protect_body(primary)
    pending=primary
    for label,operation in operations:
        try:operation()
        except BaseException as error:pending=choose(pending,error,label,body_primary=body)
    if pending is not None and pending is not primary:raise pending

class JournalStore:
    def __init__(self,admitted):
        if FAILURE_QUARANTINE:raise RuntimeError('Uncertain descriptor retirement requires dedicated process exit')
        self.admitted=require_admitted(admitted) # Public-only; before private IO.
        self.path=admitted.private_path;self.owner=admitted.private_identity
        self.fd=None;self.records={};self.total=0;self.closed=False;self.rechecked=False;self.close_failed=False
        primary=None
        try:
            if str(Path(self.path).resolve())!=self.path:raise ValueError('Private root alias rejected')
            self.fd=os.open(self.path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
            self.check();self.names=set(os.listdir(self.fd))
            if 'ledger.json'not in self.names or len(self.names)>9601 or any(not re.fullmatch(r'(ledger|[0-9]{4}-(native|exact|candidate))\.json',n)for n in self.names):raise ValueError('Private journal inventory differs')
            for name in self.names:self.file_stat(name)
        except BaseException as error:
            primary=protect_body(error)
            finish_all(primary,[('private constructor close',self.close)])
            raise
    def check(self):
        if self.closed or self.fd is None:raise ValueError('Held private root is unavailable')
        named=os.stat(self.path,follow_symlinks=False);opened=os.fstat(self.fd)
        if ident(named)!=self.owner or ident(opened)!=self.owner or not stat.S_ISDIR(named.st_mode)or stat.S_IMODE(named.st_mode)!=0o700 or named.st_uid!=os.getuid():raise ValueError('Borrowed private directory identity differs')
    def file_stat(self,name):
        self.check()
        if name not in self.names:raise PermissionError('Only exact admitted journal names may be read')
        info=os.stat(name,dir_fd=self.fd,follow_symlinks=False)
        limit=MAX_LEDGER if name=='ledger.json'else MAX_JOURNAL
        if not stat.S_ISREG(info.st_mode)or stat.S_IMODE(info.st_mode)!=0o600 or info.st_uid!=os.getuid()or info.st_nlink!=1 or not 0<info.st_size<=limit:raise ValueError('Bounded private0600 regular journal required')
        return info
    def _read(self,name):
        before=self.file_stat(name);fd=None;primary=None;raw=None
        try:
            fd=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=self.fd)
            if state(os.fstat(fd))!=state(before):raise ValueError('Journal changed before descriptor acquisition')
            chunks=[];remaining=before.st_size+1
            while remaining:
                chunk=os.read(fd,min(1<<20,remaining))
                if not chunk:break
                chunks.append(chunk);remaining-=len(chunk)
            raw=b''.join(chunks)
            if len(raw)!=before.st_size or state(os.fstat(fd))!=state(before)or state(self.file_stat(name))!=state(before):raise ValueError('Journal changed during read')
        except BaseException as error:primary=protect_body(error);raise
        finally:
            if fd is not None:finish_all(primary,[('journal descriptor close',lambda:close_fd(fd,self))])
        return raw,state(before)
    def read(self,name):
        if name in self.records:raise ValueError('Each journal is consumed only once before terminal recheck')
        raw,observed=self._read(name);self.total+=len(raw)
        if self.total>MAX_TOTAL:raise ValueError('Private journal aggregate storage bound exceeded')
        self.records[name]=dict(sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),state=observed)
        return parse(raw)
    def recheck(self):
        self.check()
        if set(os.listdir(self.fd))!=self.names or set(self.records)!=self.names:raise ValueError('Every exact private journal must be consumed and retained')
        for name,prior in self.records.items():
            raw,observed=self._read(name)
            if observed!=prior['state']or len(raw)!=prior['bytes']or hashlib.sha256(raw).hexdigest()!=prior['sha256']:raise ValueError('Private journal changed after reconstruction')
        self.check();self.rechecked=True
    def inventory_sha256(self):
        if not self.rechecked:raise ValueError('Terminal private recheck required')
        return hashlib.sha256(canonical(self.records)).hexdigest()
    def close(self):
        if getattr(self,'close_failed',False):raise RuntimeError('Prior descriptor retirement remains uncertain')
        if self.fd is not None:
            fd,self.fd=self.fd,None
            try:close_fd(fd,self)
            except BaseException:
                self.close_failed=True
                raise
        self.closed=True
    def __enter__(self):return self
    def __exit__(self,kind,error,tb):
        finish_all(error,[('private terminal recheck',self.recheck),('private directory close',self.close)])
        return False

class CalibrationRead:
    """One exact authenticated calibration file; no validation sibling access."""
    def __init__(self,admitted):
        if FAILURE_QUARANTINE:raise RuntimeError('Uncertain descriptor retirement requires dedicated process exit')
        self.admitted=require_admitted(admitted);self.descriptor=parse(admitted.calibration_bytes)
        self.fd=None;self.parent=None;self.start=None;self.loaded=False;self.closed=False;self.close_failed=False
        primary=None
        try:
            d=self.descriptor;path=Path(d['path'])
            if str(path.resolve())!=str(path):raise ValueError('Calibration alias rejected')
            self.parent=os.open(str(path.parent),os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
            self.fd=os.open(path.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=self.parent)
            self.start=self.check()
        except BaseException as error:
            primary=protect_body(error);finish_all(primary,[('calibration constructor close',self.close)]);raise
    def check(self):
        d=self.descriptor;path=Path(d['path']);parent=os.fstat(self.parent);pn=os.stat(path.parent,follow_symlinks=False)
        opened=os.fstat(self.fd);named=os.stat(path.name,dir_fd=self.parent,follow_symlinks=False)
        if ident(parent)!=tuple(d['parent_identity'])or ident(pn)!=ident(parent)or not stat.S_ISDIR(pn.st_mode)or stat.S_IMODE(pn.st_mode)!=0o700 or pn.st_uid!=os.getuid():raise ValueError('Calibration parent identity differs')
        if ident(opened)!=tuple(d['identity'])or state(opened)!=state(named)or not stat.S_ISREG(opened.st_mode)or stat.S_IMODE(opened.st_mode)!=0o600 or opened.st_uid!=os.getuid()or opened.st_nlink!=1 or opened.st_size!=d['bytes']:raise ValueError('Calibration file identity differs')
        current=state(opened)
        if self.start is not None and current!=self.start:raise ValueError('Calibration changed during reconstruction')
        return current
    def bytes(self):
        self.check();os.lseek(self.fd,0,os.SEEK_SET);pieces=[];left=self.descriptor['bytes']+1
        while left:
            chunk=os.read(self.fd,min(1<<20,left))
            if not chunk:break
            pieces.append(chunk);left-=len(chunk)
        raw=b''.join(pieces);self.check()
        if len(raw)!=self.descriptor['bytes']or hashlib.sha256(raw).hexdigest()!=self.descriptor['sha256']:raise ValueError('Calibration source digest differs')
        self.loaded=True;return raw
    def recheck(self):
        if not self.loaded:raise ValueError('Calibration was never consumed')
        self.bytes()
    def close(self):
        if getattr(self,'close_failed',False):raise RuntimeError('Prior descriptor retirement remains uncertain')
        operations=[]
        for name in('fd','parent'):
            def close_one(name=name):
                fd=getattr(self,name)
                if fd is not None:
                    setattr(self,name,None)
                    try:close_fd(fd,self)
                    except BaseException:
                        self.close_failed=True
                        raise
            operations.append(('calibration '+name+' close',close_one))
        finish_all(None,operations);self.closed=True
    def __enter__(self):return self
    def __exit__(self,kind,error,tb):
        finish_all(error,[('calibration recheck',self.recheck),('calibration close',self.close)])
        return False
