import pytest
import private_journals as p

@pytest.mark.parametrize("kind",["journals","calibration"])
def test_uncertain_descriptor_never_retried(kind,monkeypatch):
    p.FAILURE_QUARANTINE.clear();calls=[]
    def close(fd):
        calls.append(fd)
        if fd==101:raise OSError("uncertain close")
    monkeypatch.setattr(p.os,"close",close)
    owner=(p.JournalStore if kind=="journals" else p.CalibrationRead).__new__(p.JournalStore if kind=="journals" else p.CalibrationRead)
    owner.fd=101;owner.closed=False
    if kind=="calibration":owner.parent=102
    with pytest.raises(OSError):owner.close()
    expected=list(calls)
    try:owner.close()
    except BaseException:pass
    assert calls==expected,"uncertain descriptor must not be retried"
    assert p.FAILURE_QUARANTINE
    p.FAILURE_QUARANTINE.clear()
