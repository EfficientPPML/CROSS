"""Actual isolated admission CLIs plus synthetic lifecycle fault injection."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from types import SimpleNamespace
from contextlib import contextmanager
import pytest
import reconstruction_process as p

ROOT=Path(__file__).parent

def snapshot(tmp_path):
    target=tmp_path/'execution';shutil.copytree(ROOT,target)
    mapping={x.relative_to(target).as_posix():hashlib.sha256(x.read_bytes()).hexdigest()for x in target.rglob('*')if x.is_file()}
    raw=json.dumps(mapping,sort_keys=True).encode();manifest=tmp_path/'source_manifest.json';manifest.write_bytes(raw)
    return target,manifest,hashlib.sha256(raw).hexdigest()

def invoke(target,manifest,pin,output,mode,*,script=None):
    args=[str(target/'entry.py'),'--manifest',str(manifest),'--manifest-sha256',pin,'--mode',mode,'--output',str(output)]
    command=[sys.executable,'-I','-B',*args]if script is None else[sys.executable,'-I','-B','-c',script,*args]
    child=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    stdout,stderr=child.communicate(timeout=30)
    with pytest.raises(ProcessLookupError):os.killpg(child.pid,0)
    return child.returncode,stdout,stderr

@pytest.mark.parametrize('mode',['collect-preflight','test-worker','collect-reconstruct','reconstruct-worker'])
def test_changed_helper_cannot_execute_before_source_auth(tmp_path,mode):
    target,manifest,pin=snapshot(tmp_path);marker=tmp_path/'CANARY';helper=target/'reconstruction_process.py'
    helper.write_text('from pathlib import Path\nPath('+repr(str(marker))+').touch()\nraise RuntimeError("canary")\n'+helper.read_text())
    code,out,err=invoke(target,manifest,pin,tmp_path/'out',mode)
    assert code!=0 and not marker.exists()and b'source closure SHA256 differs'in err

@pytest.mark.parametrize('origin',['file','spec','both_foreign_file','symlink_spec','pathlike_spec'])
def test_unknown_local_alias_rejected_independently(tmp_path,origin):
    target,manifest,pin=snapshot(tmp_path)
    alias=target/'private_journals.py'
    if origin=='symlink_spec':
        link=tmp_path/'outside-link.py';link.symlink_to(alias);alias=link
    script='''import sys,types,importlib.util,runpy,pathlib
m=types.ModuleType('unknown_alias')
mode=sys.argv.pop(1);path=sys.argv.pop(1)
if mode=='file':m.__file__=path
else:
 m.__spec__=importlib.util.spec_from_loader('unknown_alias',loader=None,origin=pathlib.Path(path)if mode=='pathlike_spec'else path)
 if mode=='both_foreign_file':m.__file__='/usr/foreign.py'
sys.modules['unknown_alias']=m
sys.argv=sys.argv[1:]
runpy.run_path(sys.argv[0],run_name='__main__')
'''
    # Extra argv consumed by the isolated wrapper before entry arguments.
    args=[sys.executable,'-I','-B','-c',script,origin,str(alias),str(target/'entry.py'),'--manifest',str(manifest),'--manifest-sha256',pin,'--mode','collect-preflight','--output',str(tmp_path/'out')]
    child=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);out,err=child.communicate(timeout=30)
    assert child.returncode!=0 and b'preloaded local helper or unknown local alias'in err
    with pytest.raises(ProcessLookupError):os.killpg(child.pid,0)

@pytest.mark.parametrize('mode',['collect-reconstruct','reconstruct-worker'])
def test_actual_roles_fail_without_root_grant_before_output(tmp_path,mode):
    target,manifest,pin=snapshot(tmp_path);out=tmp_path/'out';code,stdout,err=invoke(target,manifest,pin,out,mode)
    assert code!=0 and b'Independent root reconstruction grant'in err and not out.exists()

def test_existing_output_collision_preserves_report(tmp_path):
    target,manifest,pin=snapshot(tmp_path);out=tmp_path/'out';out.mkdir();report=out/'report.json';report.write_bytes(b'original evidence')
    code,stdout,err=invoke(target,manifest,pin,out,'collect-preflight')
    assert code!=0 and report.read_bytes()==b'original evidence'and sorted(x.name for x in out.iterdir())==['report.json']

@pytest.mark.parametrize('exception',[KeyboardInterrupt,SystemExit])
def test_supervise_attempt_all_on_shield_entry_failure(tmp_path,monkeypatch,exception):
    output=p.Output(tmp_path/'out');events=[]
    @contextmanager
    def bad(state):raise OSError('setup');yield
    monkeypatch.setattr(p,'shield',bad)
    def later():events.append('later');raise exception('cleanup cancellation')
    code=p.supervise(output,{'passed':False,'complete':False},lambda:None,[('first',lambda:events.append('first')),('later',later),('last',lambda:events.append('last'))])
    assert code==1 and events==['first','later','last']and output.fd is None
    row=json.loads((tmp_path/'out/report.json').read_text());assert row['passed']is False and row['error_type']==exception.__name__

@pytest.mark.parametrize('exception',[KeyboardInterrupt,SystemExit])
def test_genuine_body_identity_survives_sticky_and_cancel(tmp_path,exception):
    output=p.Output(tmp_path/'out');primary=ValueError('body');events=[]
    def fail():raise primary
    def sticky():events.append('sticky');raise primary
    def cancel():events.append('cancel');raise exception('cancel')
    assert p.supervise(output,{},fail,[('sticky',sticky),('cancel',cancel)])==1
    row=json.loads((tmp_path/'out/report.json').read_text());assert row['error_type']=='ValueError'and events==['sticky','cancel']

def test_outer_restore_failure_precedes_publication(tmp_path,monkeypatch):
    output=p.Output(tmp_path/'out')
    @contextmanager
    def broken():yield;raise KeyboardInterrupt('outer restore')
    monkeypatch.setattr(p,'termination_signals',broken)
    assert p.supervise(output,{},lambda:{'verification_passed':True},[])==1
    assert not(tmp_path/'out/review.json').exists()
    row=json.loads((tmp_path/'out/report.json').read_text())
    assert row['passed']is False and row['outer_termination_completed']is False and row['signal_restoration_completed']is False

def test_deterministic_source_archive():
    blobs={'b.py':b'b','a.py':b'a'}
    assert p.archive_bytes(blobs)==p.archive_bytes(dict(reversed(list(blobs.items()))))

def test_owned_child_requires_wait_and_group_absence(tmp_path):
    log=os.open(tmp_path/'child.log',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    try:
        child=p.OwnedChild([sys.executable,'-I','-B','-c','pass'],cwd=str(tmp_path),stdout=log)
        assert child.wait()==0
        assert child.record['direct_child_reaped']and child.record['group_empty_verified']and child.record['cleanup_completed']
    finally:os.close(log)

@pytest.mark.parametrize('name',['jax','jaxlib','jaxite_word','tensorflow','flax','torch_xla','torch','transformers','safetensors','tokenizers','numpy'])
def test_actual_backend_import_denied_before_module_body(tmp_path,name):
    script='''import sys,runpy,importlib
ns=runpy.run_path(sys.argv[1]);sys.meta_path.insert(0,ns['FrozenImports']({},allow_model=True))
try:importlib.import_module(sys.argv[2])
except ImportError as e:
 assert 'backend import forbidden' in str(e)
 assert sys.argv[2] not in sys.modules
else:raise AssertionError('backend body admitted')
'''
    child=subprocess.Popen([sys.executable,'-I','-B','-c',script,str(ROOT/'entry.py'),name],stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    out,err=child.communicate(timeout=30)
    assert child.returncode==0,err
    with pytest.raises(ProcessLookupError):os.killpg(child.pid,0)
