"""Synthetic borrowed-tree path admission; no real retained files are opened."""
import ast
import json
from pathlib import Path
from types import SimpleNamespace
import pytest
import reconstruction_process as p

def blobs(root):
    return {'execution_authorization.json':b'{"execute":false}',
        'reconstruction_protected_paths.json':json.dumps({'schema':'qwen-candidate-reconstruction-protected-paths-v1','paths':[str(root)]}).encode()}

@pytest.mark.parametrize('symlink',[False,True])
def test_preflight_output_denied_before_acquisition(tmp_path,monkeypatch,symlink):
    protected=tmp_path/'borrowed';protected.mkdir();path=protected/'new'
    if symlink:
        link=tmp_path/'alias';link.symlink_to(protected,target_is_directory=True);path=link/'new'
    args=SimpleNamespace(mode='collect-preflight',output=str(path),grant=None,grant_sha256=None,request=None,request_sha256=None)
    monkeypatch.setattr(p,'Output',lambda *a,**k:pytest.fail('borrowed output acquired'))
    with pytest.raises(PermissionError):p.collect(args,b'',{},blobs(protected),{},tmp_path/'source')
    assert not path.exists()

@pytest.mark.parametrize('key',['grant','request'])
def test_cli_public_descriptor_cannot_be_private_before_read(tmp_path,monkeypatch,key):
    protected=tmp_path/'borrowed';protected.mkdir();opened=[]
    args=SimpleNamespace(mode='collect-reconstruct',output=str(tmp_path/'out'),grant=str(tmp_path/'grant.json'),grant_sha256='a'*64,request=str(tmp_path/'request.json'),request_sha256='b'*64)
    setattr(args,key,str(protected/'private.json'))
    monkeypatch.setattr(p,'read',lambda *a,**k:opened.append(a[0]))
    with pytest.raises(PermissionError):p.public_request(args,b'',{},blobs(protected))
    assert opened==[]

def test_public_unprotected_control_reaches_public_grant_only(tmp_path,monkeypatch):
    protected=tmp_path/'borrowed';protected.mkdir();opened=[]
    args=SimpleNamespace(mode='collect-reconstruct',output=str(tmp_path/'out'),grant=str(tmp_path/'grant.json'),grant_sha256='a'*64,request=str(tmp_path/'request.json'),request_sha256='b'*64)
    def reader(path,*args,**kw):opened.append(str(path));return b'{"execute":false}'
    monkeypatch.setattr(p,'read',reader)
    with pytest.raises(PermissionError):p.public_request(args,b'',{},blobs(protected))
    assert opened==[args.grant]

def test_bootstrap_static_paths_match_authenticated_metadata():
    root=Path(__file__).parent;tree=ast.parse((root/'entry.py').read_text())
    node=next(n.value for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='BOOTSTRAP_PROTECTED'for t in n.targets))
    values=ast.literal_eval(node);metadata=json.loads((root/'reconstruction_protected_paths.json').read_text())
    assert list(values)==metadata['paths']and len(values)>15
