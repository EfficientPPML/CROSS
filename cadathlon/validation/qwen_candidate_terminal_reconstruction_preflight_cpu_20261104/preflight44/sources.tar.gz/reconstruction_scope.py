"""One admitted read-only replay with attempt-all finalization.

The root entrypoint must authenticate this whole reconstruction source closure,
install its outer termination scope, supply an authenticated source rechecker and
the reviewed cleanup shield, then publish this result and obtain an independent
outer receipt. This library neither publishes nor certifies its own retirement.
"""
from producer_admission import require_admitted
from private_journals import CalibrationRead,JournalStore
from cleanup_origin import cleanup_origin,protect_body,choose
from verify_records import parse,reconstruct
from verify_statistics import same

def run(admitted,*,source_check,cleanup_scope):
    admitted=require_admitted(admitted)
    if not callable(source_check)or not callable(cleanup_scope):raise ValueError('Explicit authenticated source checker and cleanup scope required')
    cal=store=None;result=None;primary=body=None;cleanup_state={};cleanup_errors=[]
    def attempt(label,operation):
        nonlocal primary
        try:return operation()
        except BaseException as error:
            cleanup_errors.append(label);primary=choose(primary,error,label,body_primary=body);return None
    try:
        source_check()
        cal=CalibrationRead(admitted)
        store=JournalStore(admitted)
        calibration=parse(cal.bytes());ledger=store.read('ledger.json')
        result=reconstruct(calibration,admitted.manifest_bytes,ledger,store.read,parse(admitted.worker_bytes),store.names)
        same(result['scientific_pass'],admitted.producer_passed)
    except BaseException as error:
        primary=error;body=None if cleanup_origin(error)else protect_body(error)
    finally:
        shield=None;entered=False
        try:
            shield=cleanup_scope(cleanup_state);shield.__enter__();entered=True
        except BaseException as error:
            cleanup_errors.append('cleanup shield entry');primary=choose(primary,error,'cleanup shield entry',body_primary=body)
        if cal is not None:attempt('calibration terminal recheck',cal.recheck)
        if store is not None:attempt('private journal terminal recheck',store.recheck)
        attempt('reconstruction sources terminal recheck',source_check)
        if store is not None:attempt('private journal handle close',store.close)
        if cal is not None:attempt('calibration handles close',cal.close)
        if entered:attempt('cleanup shield restoration',lambda:shield.__exit__(None,None,None))
    if primary is not None:raise primary
    if cleanup_errors or cleanup_state.get('restored')is not True or result is None or not cal.closed or not store.closed or not store.rechecked:
        raise RuntimeError('Reconstruction terminal cleanup is incomplete')
    pins=dict(admitted.expected_pins);grant=parse(dict(admitted.public_blobs)['reconstruction_grant'])
    bindings=dict(candidate_manifest_sha256=pins['candidate_manifest'],producer_source_manifest_sha256=pins['source_manifest'],
        producer_source_archive_sha256=pins['source_archive'],producer_parent_report_sha256=pins['parent'],producer_worker_report_sha256=pins['worker'],
        producer_outer_receipt_sha256=pins['producer_outer'],calibration_sha256=parse(admitted.calibration_bytes)['sha256'],protocol_sha256=grant['protocol_sha256'],
        model_pins_sha256=pins['model_pins'],grant_sha256=pins['producer_grant'],private_inventory_sha256=store.inventory_sha256(),ledger_sha256=store.records['ledger.json']['sha256'],
        reconstruction_source_manifest_sha256=admitted.reconstruction_source_manifest_sha256,reconstruction_source_archive_sha256=admitted.reconstruction_source_archive_sha256,reconstruction_grant_sha256=pins['reconstruction_grant'])
    checks={name:True for name in('producer_admitted','exact_private_inventory','calibration_identity','ordered_ledger','causal_prefixes','metric_inventory_and_gates','domain_inventory_and_gates','input_statistics_and_aggregates','public_private_summary_match','native_call_accounting','private_rechecks_completed','source_rechecks_completed','cleanup_completed','signal_restoration_completed')}
    return dict(schema='qwen-candidate-recorded-statistic-review-v2',verification_passed=True,
        scientific_pass=result['scientific_pass'],complete_scientific_failure_eligible=result['complete_scientific_failure_eligible'],candidate_ordinal=1,
        bindings=bindings,checks=checks,coverage=result['coverage'],gates=result['gates'],aggregate_sha256=result['aggregate_sha256'],
        recorded_statistic_reconstruction=True,fresh_array_recomputation=False,argmax_recomputed_from_logits=False,invariance_recomputed_from_arrays=False,
        selection_authorized=False,validation_authorized=False,row0_authorized=False)
