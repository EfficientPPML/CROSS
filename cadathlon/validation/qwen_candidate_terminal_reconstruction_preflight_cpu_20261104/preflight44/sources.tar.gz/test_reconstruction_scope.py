"""Explicit orchestration doubles; no real journal/model payloads."""
from contextlib import contextmanager
from types import SimpleNamespace
import pytest
import reconstruction_scope as s
from cleanup_origin import mark_cleanup

def setup(monkeypatch,*,failure=None,close_error=None):
    events=[]
    class Cal:
        def __init__(self,cap):events.append('cal open');self.closed=False
        def bytes(self):events.append('cal read');return b'{}'
        def recheck(self):events.append('cal recheck')
        def close(self):events.append('cal close');self.closed=True
    class Store:
        def __init__(self,cap):events.append('store open');self.names={'ledger.json'};self.records={'ledger.json':{'sha256':'4'*64}};self.closed=False;self.rechecked=False
        def read(self,name):events.append('journal read');return{}
        def recheck(self):events.append('store recheck');self.rechecked=True
        def close(self):
            events.append('store close');self.closed=True
            if close_error is not None:raise close_error
        def inventory_sha256(self):return'5'*64
    def reconstruct(*args):
        events.append('reconstruct')
        if failure is not None:raise failure
        return dict(scientific_pass=True,complete_scientific_failure_eligible=False,coverage={},gates={},aggregate_sha256='6'*64)
    pins={k:'1'*64 for k in('candidate_manifest','source_manifest','source_archive','parent','worker','producer_outer','model_pins','producer_grant','reconstruction_grant')}
    cap=SimpleNamespace(manifest_bytes=b'{}',worker_bytes=b'{}',producer_passed=True,expected_pins=tuple(pins.items()),public_blobs=(('reconstruction_grant',b'{"protocol_sha256":"protocol"}'),),calibration_bytes=b'{"sha256":"cal"}',reconstruction_source_manifest_sha256='a'*64,reconstruction_source_archive_sha256='b'*64)
    monkeypatch.setattr(s,'require_admitted',lambda x:x);monkeypatch.setattr(s,'CalibrationRead',Cal);monkeypatch.setattr(s,'JournalStore',Store);monkeypatch.setattr(s,'reconstruct',reconstruct)
    return cap,events

@contextmanager
def good_shield(state):
    try:yield
    finally:state['restored']=True

def test_success_returns_review_only_after_all_rechecks_and_closes(monkeypatch):
    cap,events=setup(monkeypatch)
    result=s.run(cap,source_check=lambda:events.append('sources'),cleanup_scope=good_shield)
    assert events==['sources','cal open','store open','cal read','journal read','reconstruct','cal recheck','store recheck','sources','store close','cal close']
    assert result['verification_passed']and result['checks']['cleanup_completed']
    assert result['validation_authorized']is False

@pytest.mark.parametrize('cancel',[KeyboardInterrupt,SystemExit])
def test_cleanup_shield_entry_never_skips_closes_or_source_check(monkeypatch,cancel):
    cap,events=setup(monkeypatch,close_error=cancel('close cancellation'))
    @contextmanager
    def broken(state):raise OSError('shield installation');yield
    with pytest.raises(cancel):s.run(cap,source_check=lambda:events.append('sources'),cleanup_scope=broken)
    assert events[-5:]==['cal recheck','store recheck','sources','store close','cal close']

@pytest.mark.parametrize('cancel',[KeyboardInterrupt,SystemExit])
def test_genuine_body_survives_sticky_and_later_cleanup(monkeypatch,cancel):
    primary=ValueError('genuine body');cap,events=setup(monkeypatch,failure=primary,close_error=primary)
    @contextmanager
    def broken(state):
        try:yield
        finally:raise cancel('restore')
    with pytest.raises(ValueError)as caught:s.run(cap,source_check=lambda:events.append('sources'),cleanup_scope=broken)
    assert caught.value is primary and events[-1]=='cal close'

def test_terminal_source_failure_cannot_publish_review(monkeypatch):
    cap,events=setup(monkeypatch);calls=[]
    def sources():
        calls.append(1)
        if len(calls)==2:raise ValueError('source changed')
    with pytest.raises(ValueError):s.run(cap,source_check=sources,cleanup_scope=good_shield)
    assert events[-2:]==['store close','cal close']

def test_failed_shield_restoration_flag_cannot_pass(monkeypatch):
    cap,events=setup(monkeypatch)
    @contextmanager
    def flag(state):yield;state['restored']=False
    with pytest.raises(RuntimeError):s.run(cap,source_check=lambda:None,cleanup_scope=flag)

def test_first_source_failure_never_opens_private(monkeypatch):
    cap,events=setup(monkeypatch)
    def fail():raise ValueError('public source gate')
    with pytest.raises(ValueError):s.run(cap,source_check=fail,cleanup_scope=good_shield)
    assert events==[]
