"""Synthetic local files only; no saved candidate inputs/journals opened."""
import copy
import hashlib
import io
import os
from pathlib import Path
import tarfile
import pytest
import producer_admission as a
import private_journals as p
from verify_statistics import canonical

def sha(x):return hashlib.sha256(x).hexdigest()
def encoded(x):return canonical(x)
def inode(path):v=path.stat();return[v.st_dev,v.st_ino]

def fake_proof(tmp_path,monkeypatch):
    calibration=tmp_path/'cal';private=tmp_path/'private';calibration.mkdir(mode=0o700);private.mkdir(mode=0o700)
    cal=calibration/'calibration_inputs.json';cal.write_bytes(b'{"synthetic":true}');cal.chmod(0o600)
    ledger=private/'ledger.json';ledger.write_bytes(b'{"synthetic":true}');ledger.chmod(0o600)
    d=dict(path=str(cal),sha256=sha(cal.read_bytes()),bytes=cal.stat().st_size,identity=inode(cal),parent_identity=inode(calibration),mode='0600',parent_mode='0700')
    bodies={f's{i}.py':b'pass\n'for i in range(136)}
    bodies.update({'candidate_proof/candidate-manifest.json':b'{}','public/model_pins.json':b'{}','protocol.json':b'protocol'})
    monkeypatch.setattr(a,'PROTOCOL_SHA256',sha(b'protocol'))
    source={n:sha(b)for n,b in bodies.items()};source_raw=encoded(source);monkeypatch.setattr(a,'SOURCE_MANIFEST_SHA256',sha(source_raw))
    buf=io.BytesIO()
    with tarfile.open(fileobj=buf,mode='w:gz')as t:
        for name,body in bodies.items():
            info=tarfile.TarInfo(name);info.size=len(body);t.addfile(info,io.BytesIO(body))
    public=dict(source_manifest=source_raw,source_archive=buf.getvalue(),candidate_manifest=b'{}',model_pins=b'{}')
    grant=dict(schema='qwen-expanded-candidate-checker-grant-v1',execute=True,candidate_ordinal=1,candidate_manifest_sha256=sha(public['candidate_manifest']),source_manifest_sha256=sha(source_raw),protocol_sha256=a.PROTOCOL_SHA256,model_pins_sha256=sha(public['model_pins']),validation_read=False,coefficient_selection=False,encrypted_execution=False,calibration=d,private_output=str(private))
    public['producer_grant']=encoded(grant)
    worker=dict(passed=True,source_manifest_sha256=sha(source_raw),source_hashes_start=source,source_hashes_end=source,audit_denials=[],manifest_sha256=sha(public['candidate_manifest']),grant_sha256=sha(public['producer_grant']),protocol_sha256=a.PROTOCOL_SHA256,candidate_ordinal=1,expected_entries=3200,retained_entries=3200,calibration_sha256=d['sha256'],private_output=dict(path=str(private),identity=inode(private),mode='0700'))
    flags=('complete','cleanup_completed','signal_restoration_completed','source_files_unchanged','terminal_after_body_cleanup_and_signal_restoration_attempts','acceptance_requires_independent_exit0_reap_and_exact_report_hash','calibration_reauthenticated','private_directory_handle_closed','private_outputs_retained','external_inputs_never_removed','model_asset_postchecks_completed','model_cleanup_completed','native_capture_cleanup_completed','ledger_complete','all_length_invariance','model_loaded','candidate_validation_admissible')
    worker.update({n:True for n in flags});worker.update({n:False for n in('coefficient_selection_performed','encrypted_execution','validation_inputs_read','tokenizer_execution','contains_tokens_logits_or_failure_text')})
    public['worker']=encoded(worker)
    parent={k:worker[k]for k in flags[:7]};parent.update(passed=True,source_manifest_sha256=sha(source_raw),source_hashes_start=source,source_hashes_end=source,audit_denials=[],worker=worker,worker_report_sha256=sha(public['worker']),source_archive={'sha256':sha(public['source_archive'])},child_returncode=0,child_reaped=True,child_group_absent=True,actual_candidate_stage=True,candidate_validation_admissible=True)
    public['parent']=encoded(parent)
    outer=dict(schema=a.OUTER_SCHEMA,report_sha256=sha(public['parent']),worker_report_sha256=sha(public['worker']),source_manifest_sha256=sha(source_raw),source_archive_sha256=sha(public['source_archive']),candidate_manifest_sha256=sha(public['candidate_manifest']),grant_sha256=sha(public['producer_grant']),exit_code=0,reaped=True,process_group_absent=True,worker_exit_code=0,worker_reaped=True,worker_group_absent=True)
    public['producer_outer']=encoded(outer)
    reconstruction=dict(schema='qwen-candidate-recorded-reconstruction-grant-v1',execute=True,candidate_ordinal=1,candidate_manifest_sha256=sha(public['candidate_manifest']),producer_parent_report_sha256=sha(public['parent']),producer_worker_report_sha256=sha(public['worker']),producer_outer_receipt_sha256=sha(public['producer_outer']),producer_source_manifest_sha256=sha(source_raw),producer_source_archive_sha256=sha(public['source_archive']),producer_grant_sha256=sha(public['producer_grant']),calibration=d,private_output=worker['private_output'],protocol_sha256=a.PROTOCOL_SHA256,model_pins_sha256=sha(public['model_pins']),model_forward=False,validation_read=False,row0_evaluation=False,selection=False,reconstruction_source_manifest_sha256='1'*64,reconstruction_source_archive_sha256='2'*64,reconstruction_script_sha256='3'*64)
    public['reconstruction_grant']=encoded(reconstruction)
    reconstruction.update(request_sha256='4'*64,evidence_output=str(tmp_path/'evidence'))
    public['reconstruction_grant']=encoded(reconstruction)
    return public,{n:sha(v)for n,v in public.items()}

@pytest.fixture(autouse=True)
def no_quarantine_leak():
    assert not p.FAILURE_QUARANTINE
    yield
    for owner,fd,error in p.FAILURE_QUARANTINE:
        try:os.close(fd)
        except OSError:pass
    p.FAILURE_QUARANTINE.clear()

def test_public_gate_then_held_calibration_and_exact_journal(tmp_path,monkeypatch):
    public,pins=fake_proof(tmp_path,monkeypatch);cap=a.admit(public,pins)
    with p.CalibrationRead(cap)as cal:assert cal.bytes()==b'{"synthetic":true}'
    assert cal.closed
    with p.JournalStore(cap)as store:
        assert store.names=={'ledger.json'} and store.read('ledger.json')=={'synthetic':True}
        store.recheck();assert len(store.inventory_sha256())==64
    assert store.closed and store.rechecked

@pytest.mark.parametrize('role',a.NAMES)
def test_wrong_external_pin_before_any_private_io(tmp_path,monkeypatch,role):
    public,pins=fake_proof(tmp_path,monkeypatch);pins[role]='f'*64
    monkeypatch.setattr(os,'open',lambda *x,**k:pytest.fail('private open before public gate'))
    with pytest.raises(ValueError):a.admit(public,pins)

@pytest.mark.parametrize('field,value',[('model_forward',True),('validation_read',True),('candidate_ordinal',2),('selection',True),('execute',False)])
def test_reconstruction_grant_never_inherits_model_validation_authority(tmp_path,monkeypatch,field,value):
    public,pins=fake_proof(tmp_path,monkeypatch);r=a.parse(public['reconstruction_grant']);r[field]=value;public['reconstruction_grant']=encoded(r);pins['reconstruction_grant']=sha(public['reconstruction_grant'])
    with pytest.raises(ValueError):a.admit(public,pins)

@pytest.mark.parametrize('field,value',[('reaped',False),('worker_group_absent',False),('exit_code',True),('source_manifest_sha256','0'*64)])
def test_external_outer_cannot_infer_success_from_report(tmp_path,monkeypatch,field,value):
    public,pins=fake_proof(tmp_path,monkeypatch);r=a.parse(public['producer_outer']);r[field]=value;public['producer_outer']=encoded(r);pins['producer_outer']=sha(public['producer_outer'])
    with pytest.raises(ValueError):a.admit(public,pins)

@pytest.mark.parametrize('mutation',['extra','symlink','hardlink','mode','root_replace'])
def test_private_inventory_and_held_root_are_bound(tmp_path,monkeypatch,mutation):
    public,pins=fake_proof(tmp_path,monkeypatch);cap=a.admit(public,pins);root=Path(cap.private_path)
    if mutation=='extra':(root/'unknown.json').write_text('{}')
    elif mutation=='symlink':(root/'0000-native.json').symlink_to(root/'ledger.json')
    elif mutation=='hardlink':os.link(root/'ledger.json',root/'0000-native.json')
    elif mutation=='mode':(root/'ledger.json').chmod(0o644)
    else:root.rename(tmp_path/'old');root.mkdir(mode=0o700)
    with pytest.raises(ValueError):p.JournalStore(cap)

def test_changes_after_read_fail_final_recheck_and_close(tmp_path,monkeypatch):
    public,pins=fake_proof(tmp_path,monkeypatch);store=p.JournalStore(a.admit(public,pins))
    with pytest.raises(ValueError):
        with store:
            store.read('ledger.json');(Path(store.path)/'ledger.json').write_bytes(b'{"changed":true}')
    assert store.closed

@pytest.mark.parametrize('cancel',[KeyboardInterrupt,SystemExit])
def test_cleanup_only_cancellation_priority_and_genuine_body(cancel):
    ordinary=OSError('close');later=cancel('cancel');seen=[]
    def fail(e):
        def action():seen.append(e);raise e
        return action
    with pytest.raises(cancel)as got:p.finish_all(None,[('one',fail(ordinary)),('two',fail(later))])
    assert got.value is later and seen==[ordinary,later]
    body=ValueError('body');seen.clear()
    p.finish_all(body,[('sticky',fail(body)),('later',fail(cancel()))])
    assert len(seen)==2

def test_uncertain_close_retained_and_future_use_rejected(tmp_path,monkeypatch):
    public,pins=fake_proof(tmp_path,monkeypatch);cap=a.admit(public,pins);store=p.JournalStore(cap);original=os.close
    monkeypatch.setattr(os,'close',lambda fd:(_ for _ in()).throw(OSError('uncertain close')))
    with pytest.raises(OSError):store.close()
    assert p.FAILURE_QUARANTINE[0][0]is store and store.fd is None and store.close_failed
    with pytest.raises(RuntimeError):store.close()
    with pytest.raises(RuntimeError):p.JournalStore(cap)
    monkeypatch.setattr(os,'close',original)
