"""Isolated synthetic tempfile/audit startup; no actual body/model access."""
import os
from pathlib import Path
import subprocess
import sys
import pytest

def test_pytest_tempfile_discovery_uses_owned_worker_root(tmp_path):
    script='''import sys,os
from types import SimpleNamespace
from pathlib import Path
sys.path.insert(0,sys.argv[1])
import reconstruction_process as p
args=SimpleNamespace(output=sys.argv[2],grant=None,request=None)
audit=p.Audit(args,Path(sys.argv[1]));audit.install()
output=p.Output(args.output)
import tempfile
tempfile.tempdir='/tmp'
p.prepare_pytest_temp(output)
assert Path(tempfile.gettempdir())==Path(args.output)/'runtime-temporary'
with tempfile.TemporaryFile() as f:f.write(b'synthetic')
assert audit.denials==[]
output.close()
'''
    child=subprocess.Popen([sys.executable,'-I','-B','-c',script,str(Path(__file__).parent),str(tmp_path/'worker')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    out,err=child.communicate(timeout=30)
    assert child.returncode==0,err
    with pytest.raises(ProcessLookupError):os.killpg(child.pid,0)
