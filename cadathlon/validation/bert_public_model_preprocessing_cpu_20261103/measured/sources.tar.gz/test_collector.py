"""Stage2 collector lifecycle tests with fake metadata and no model/key payloads."""
from pathlib import Path
from types import SimpleNamespace
import hashlib,json,os,signal,sys
import pytest
import collect

@pytest.fixture
def case(tmp_path,monkeypatch):
    monkeypatch.setenv('JAX_PLATFORMS','cpu');parent=tmp_path/'models';parent.mkdir();keys=tmp_path/'keys';keys.mkdir();(keys/'sentinel').write_text('unchanged')
    output=tmp_path/'evidence';snapshot=tmp_path/'assets';snapshot.mkdir();events=[]
    raw={'worker.py':b'# worker','checkout/stage/server_inputs/p60_profile_and_refresh.json':b'p','checkout/stage/server_inputs/twelve_layer_plan.json':b'r'}
    monkeypatch.setattr(collect,'sources',lambda:dict(raw));monkeypatch.setattr(collect.process,'software_versions',lambda:{'mocked':True})
    auth=dict(context_id='a'*64,key_report_sha256='b'*64,key_source_archive_sha256='c'*64)
    def gate(*a,**kw):events.append('prerequisite');return dict(auth)
    monkeypatch.setattr(collect.key_gate,'authenticate',gate)
    model=SimpleNamespace(CHECKPOINT_SHA256='modelsha',CONFIG_SHA256='configsha',tensor_shapes=lambda:{str(i):(1,) for i in range(196)},
        file_sha=lambda p:events.append('asset') or ('modelsha' if p.name=='model.safetensors' else 'configsha'))
    monkeypatch.setitem(sys.modules,'server_public_model',model)
    def complete(command,directory,**kw):
        events.append('worker');assert kw==dict(timeout=None,cleanup_grace_s=120.)
        expected=json.loads(Path(command[-1]).read_text());workspace=Path(command[command.index('--model-workspace')+1]);cache=workspace/'server_data'/auth['context_id'];cache.mkdir(parents=True)
        manifest=dict(context_id=auth['context_id'],model_id='d'*64,tensors={'public':'mocked'})
        (cache/'model_manifest.json').write_bytes(collect.key_gate.canonical(manifest))
        assets={'model.safetensors':'modelsha','config.json':'configsha'}
        worker=dict(passed=True,actual_server_preprocess_called=True,readback_complete=True,all_readback_fp64_immutable=True,
            source_files_unchanged=True,keygen_and_codecs_forbidden=True,context_construction_forbidden=True,forbidden_attempts=[],
            tensor_count=196,matrix_count=74,source_hashes_start=expected,source_hashes_end=expected,prerequisite=auth,
            asset_hashes_start=assets,asset_hashes_end=assets,public_model_manifest=manifest,elapsed_s=1.)
        collect.write(directory/'worker_report.json',worker)
        record=dict(returncode=0,process_reaped=True,public_key_store_removed=True,owned_directory_handle_closed=True,
            result=dict(passed=True,worker_report_sha256=collect.process.sha256(directory/'worker_report.json'),model_id=manifest['model_id'],context_id=auth['context_id']))
        collect.write(directory/'process.json',record);return record
    monkeypatch.setattr(collect.process,'run_case',complete)
    args=dict(key_evidence=tmp_path/'prior',key_report_sha256='b'*64,key_workspace=keys,snapshot=snapshot,workspace_parent=parent)
    return SimpleNamespace(parent=parent,keys=keys,output=output,args=args,events=events,complete=complete,raw=raw,model=model)

def run(c,execute=False):return collect.run(c.output,execute=execute,**c.args)
def report(c):return json.loads((c.output/'report.json').read_text())

def test_default_preflight_and_required_first_gate(case,monkeypatch):
    monkeypatch.setattr(collect.process,'run_case',lambda *a,**kw:(_ for _ in ()).throw(AssertionError('no worker authorized')))
    r=run(case);assert r['passed'] and not r['actual_preprocessing'] and not r['model_workspace_retained']
    assert case.events[0]=='prerequisite' and not list(case.parent.iterdir()) and (case.keys/'sentinel').read_text()=='unchanged'

def test_success_external_cache_and_exact_manifest_binding(case):
    r=run(case,True);assert r['passed'] and r['model_workspace_retained'] and r['actual_preprocessing']
    cache=Path(r['model_cache']);assert r['model_cache_identity']==[cache.stat().st_dev,cache.stat().st_ino]
    assert (case.output/'model_manifest.json').read_bytes()==(cache/'model_manifest.json').read_bytes()
    assert r['model_manifest_sha256']==hashlib.sha256((cache/'model_manifest.json').read_bytes()).hexdigest()
    assert r['source_hashes_start']==r['source_hashes_end']==collect.hashes(case.raw)
    assert r['all_processes_reaped'] and r['cleanup_completed'] and (case.keys/'sentinel').read_text()=='unchanged'
    assert not list(case.output.rglob('*.npy'))

@pytest.mark.parametrize('kind',('returncode','unreaped','key_cleanup','handle_cleanup','source','assets','worker_digest','manifest','cache_manifest','cache_symlink'))
def test_worker_or_readback_failure_never_passes(case,monkeypatch,kind):
    def worker(*args,**kw):
        row=case.complete(*args,**kw);directory=args[1];p=directory/'worker_report.json';w=json.loads(p.read_text())
        if kind=='returncode':row['returncode']=1
        elif kind=='unreaped':row['process_reaped']=False
        elif kind=='key_cleanup':row['public_key_store_removed']=False
        elif kind=='handle_cleanup':row['owned_directory_handle_closed']=False
        elif kind=='source':w['source_hashes_end']={}
        elif kind=='assets':w['asset_hashes_end']={}
        elif kind=='worker_digest':row['result']['worker_report_sha256']='e'*64
        elif kind=='manifest':w['public_model_manifest']['context_id']='e'*64
        else:
            workspace=Path(args[0][args[0].index('--model-workspace')+1]);cache=workspace/'server_data'/('a'*64)
            if kind=='cache_manifest':(cache/'model_manifest.json').write_text('{}')
            else:cache.rename(cache.with_name('old'));cache.symlink_to('old',target_is_directory=True)
        if kind in ('source','assets','manifest'):
            collect.write(p,w);row['result']['worker_report_sha256']=collect.process.sha256(p)
        collect.write(directory/'process.json',row);return row
    monkeypatch.setattr(collect.process,'run_case',worker)
    with pytest.raises(ValueError):run(case,True)
    r=report(case);assert not r['passed'] and (case.keys/'sentinel').read_text()=='unchanged'
    assert Path(r['model_workspace']).exists()==(kind in ('unreaped','key_cleanup','handle_cleanup'))

@pytest.mark.parametrize('evidence',('missing','corrupt','list','incomplete','clean'))
def test_unknown_active_process_retains_model_workspace(case,monkeypatch,evidence):
    error=KeyboardInterrupt('primary')
    def worker(command,directory,**kw):
        if evidence=='corrupt':(directory/'process.json').write_text('{')
        elif evidence=='list':(directory/'process.json').write_text('[]')
        elif evidence=='incomplete':collect.write(directory/'process.json',dict(process_reaped=True))
        elif evidence=='clean':collect.write(directory/'process.json',dict(process_reaped=True,public_key_store_removed=True,owned_directory_handle_closed=True))
        raise error
    monkeypatch.setattr(collect.process,'run_case',worker)
    with pytest.raises(KeyboardInterrupt) as caught:run(case,True)
    r=report(case);assert caught.value is error and not r['passed']
    assert Path(r['model_workspace']).exists()==(evidence!='clean')
    assert (case.keys/'sentinel').read_text()=='unchanged'

@pytest.mark.parametrize('failure',('first_write','sources','software','gate','capacity'))
def test_early_failure_persists_terminal_report(case,monkeypatch,failure):
    if failure=='first_write':
        old=collect.write;calls=[]
        def write(*args):
            calls.append(1)
            if len(calls)==1:raise OSError('initial write')
            old(*args)
        monkeypatch.setattr(collect,'write',write)
    elif failure=='sources':monkeypatch.setattr(collect,'sources',lambda:(_ for _ in ()).throw(ValueError('sources')))
    elif failure=='software':monkeypatch.setattr(collect.process,'software_versions',lambda:(_ for _ in ()).throw(ValueError('software')))
    elif failure=='gate':monkeypatch.setattr(collect.key_gate,'authenticate',lambda *a,**kw:(_ for _ in ()).throw(ValueError('pending keys')))
    else:monkeypatch.setattr(collect.shutil,'disk_usage',lambda p:SimpleNamespace(total=10,free=1))
    with pytest.raises((ValueError,OSError)):run(case)
    assert not report(case)['passed'] and not list(case.parent.iterdir())
    if failure in ('gate','sources','first_write'):assert 'asset' not in case.events


def test_final_publication_preserves_primary_and_shields_three_signals(case,monkeypatch):
    error=KeyboardInterrupt('original');old=collect.write;signals=(signal.SIGINT,signal.SIGTERM,signal.SIGHUP);handlers={s:signal.getsignal(s) for s in signals}
    def stop(command,directory,**kw):
        collect.write(directory/'process.json',dict(process_reaped=True,public_key_store_removed=True,owned_directory_handle_closed=True));raise error
    monkeypatch.setattr(collect.process,'run_case',stop)
    def write(path,value):
        if path.name=='report.json' and 'elapsed_s' in value:
            for s in (*signals,*signals):os.kill(os.getpid(),s)
        old(path,value)
    monkeypatch.setattr(collect,'write',write)
    with pytest.raises(KeyboardInterrupt) as caught:run(case,True)
    assert caught.value is error and not report(case)['passed'] and not list(case.parent.iterdir())
    assert {s:signal.getsignal(s) for s in signals}==handlers


def test_final_write_failure_preserves_primary(case,monkeypatch):
    error=KeyboardInterrupt('original');old=collect.write
    monkeypatch.setattr(collect.process,'run_case',lambda *a,**kw:(_ for _ in ()).throw(error))
    def write(path,value):
        if path.name=='report.json' and 'elapsed_s' in value:raise OSError('final write')
        old(path,value)
    monkeypatch.setattr(collect,'write',write)
    with pytest.raises(KeyboardInterrupt) as caught:run(case,True)
    assert caught.value is error and any('final write' in n for n in error.__notes__)


def test_outputs_cannot_be_inside_retained_key_workspace(case):
    case.output=case.keys/'bad'
    with pytest.raises(ValueError):run(case)
    assert not case.output.exists() and (case.keys/'sentinel').read_text()=='unchanged'


def test_terminal_cache_mutation_retains_failed_workspace(case,monkeypatch):
    original=collect.cache_binding;calls=[]
    def bind(owner,context,manifest):
        calls.append(1)
        if len(calls)==2:(owner.path/'server_data'/context/'model_manifest.json').write_text('{}')
        return original(owner,context,manifest)
    monkeypatch.setattr(collect,'cache_binding',bind)
    with pytest.raises(ValueError):run(case,True)
    r=report(case);assert not r['passed'] and r['model_workspace_retained'] and not r['cleanup_completed']
    assert Path(r['model_workspace']).exists() and 'verification failed' in r['retention_reason']


def test_owned_workspace_replacement_is_never_deleted(case,monkeypatch):
    def replace(command,directory,**kw):
        workspace=Path(command[command.index('--model-workspace')+1]);workspace.rename(workspace.with_name(workspace.name+'-held'));workspace.mkdir();(workspace/'marker').write_text('keep')
        collect.write(directory/'process.json',dict(process_reaped=True,public_key_store_removed=True,owned_directory_handle_closed=True));raise KeyboardInterrupt('primary')
    monkeypatch.setattr(collect.process,'run_case',replace)
    with pytest.raises(KeyboardInterrupt):run(case,True)
    r=report(case);assert (Path(r['model_workspace'])/'marker').read_text()=='keep' and not r['cleanup_completed']


def test_changed_final_source_fails_without_retaining_valid_cache(case,monkeypatch):
    def mutate(*a,**kw):
        r=case.complete(*a,**kw);case.raw['worker.py']=b'# changed';return r
    monkeypatch.setattr(collect.process,'run_case',mutate)
    r=run(case,True);assert not r['passed'] and not r['source_files_unchanged'] and not Path(r['model_workspace']).exists()
