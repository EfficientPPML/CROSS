"""Collect actual public model preprocessing only after a pinned key proof."""
from pathlib import Path
import argparse,hashlib,importlib.metadata,io,json,math,os,shutil,stat,sys,tarfile,time,uuid
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE/'checkout'),str(HERE/'checkout/stage')]
import check_transformer_suite as process
import client_keys
import key_gate
from cleanup import cleanup_signals,termination_signals


def sources():
    paths={p.relative_to(HERE).as_posix():p for p in (HERE/'checkout').rglob('*') if p.is_file() and p.suffix in ('.py','.json') and '__pycache__' not in p.parts}
    paths.update({n:HERE/n for n in ('key_gate.py','worker.py','collect.py','cleanup.py','test_key_gate.py','test_worker.py','test_collector.py','preflight.py','source_origin.json','key_source_manifest.json','key_source_archive_fixture.tar.gz','key_gate_before_size_fix.py.txt')})
    return {n:p.read_bytes() for n,p in paths.items()}
def hashes(raw):return {n:hashlib.sha256(b).hexdigest() for n,b in raw.items()}
def write(path,value):process.write_json(path,value)
def archive(path,raw):
    with tarfile.open(path,'w:gz') as tar:
        for name,data in raw.items():info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data))
def check_archive(path,expected):
    with tarfile.open(path) as tar:
        members=tar.getmembers();return len(members)==len(expected)==len({m.name for m in members}) and all(m.isfile() for m in members) and {m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in members}==expected

def cache_binding(owner,context_id,manifest):
    """Bind the retained public cache, independently of worker stdout."""
    owner.check();key_gate.sha_field(context_id)
    parent=owner.path/'server_data';cache=parent/context_id
    for path in (parent,cache):
        if not stat.S_ISDIR(path.lstat().st_mode):raise ValueError('ordinary public cache directories required')
    info=cache.lstat();raw=key_gate.read(cache/'model_manifest.json')
    if raw!=key_gate.canonical(manifest):raise ValueError('retained fixed model manifest differs')
    return dict(model_cache=str(cache),model_cache_identity=[info.st_dev,info.st_ino],
                model_manifest_sha256=key_gate.digest(raw))

def run(output,*,key_evidence,key_report_sha256,key_workspace,snapshot,workspace_parent,execute=False,
        worker_python=Path('/tmp/cross-pretrained-validation-env/bin/python')):
    output=Path(output).absolute();key_workspace=Path(key_workspace).absolute();workspace_parent=Path(workspace_parent).absolute()
    if output==key_workspace or key_workspace in output.parents or workspace_parent==key_workspace or key_workspace in workspace_parent.parents:
        raise ValueError('stage2 outputs must be outside the retained key workspace')
    output.mkdir(parents=True,exist_ok=False);start=time.monotonic();primary=None;cleanup_error=None;owner=None;active=False;record=None;before={}
    report=dict(passed=False,execute=execute,actual_preprocessing=False,model_forward=False,encryption=False,
                model_workspace_retained=False,all_processes_reaped=True,wrapper_pid=os.getpid(),cpu_affinity=sorted(os.sched_getaffinity(0)))
    def attempt(label,fn):
        nonlocal cleanup_error
        try:return fn()
        except BaseException as error:
            report.setdefault('cleanup_errors',[]).append(dict(operation=label,type=type(error).__name__,message=str(error)))
            if primary is not None:primary.add_note(label+': '+repr(error))
            elif cleanup_error is None:cleanup_error=error
            elif not isinstance(error,Exception) and isinstance(cleanup_error,Exception):error.add_note('earlier cleanup: '+repr(cleanup_error));cleanup_error=error
            else:cleanup_error.add_note(label+': '+repr(error))
    try:
        write(output/'report.json',report)
        if type(execute)is not bool or os.environ.get('JAX_PLATFORMS')!='cpu':raise ValueError('explicit execution bool and CPU environment required')
        raw=sources();before=hashes(raw);archive(output/'sources.tar.gz',raw)
        if not check_archive(output/'sources.tar.gz',before):raise ValueError('startup source archive differs')
        execution=output/'execution_source';execution.mkdir()
        for name,data in raw.items():path=execution/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
        if {n:hashlib.sha256((execution/n).read_bytes()).hexdigest() for n in before}!=before:raise ValueError('isolated source copy differs')
        write(output/'source_manifest.json',before)
        profile=raw['checkout/stage/server_inputs/p60_profile_and_refresh.json'];plan=raw['checkout/stage/server_inputs/twelve_layer_plan.json']
        authorized=key_gate.authenticate(key_evidence,key_report_sha256,key_workspace,profile_bytes=profile,plan_bytes=plan)
        report['prerequisite']=dict(context_id=authorized['context_id'],key_report_sha256=authorized['key_report_sha256'],key_source_archive_sha256=authorized['key_source_archive_sha256'])
        import server_public_model
        raw_bytes=sum(math.prod(s)*4 for s in server_public_model.tensor_shapes().values());needed=raw_bytes+196*512+(1<<30)
        usage=shutil.disk_usage(workspace_parent)
        if usage.free<needed:raise OSError('insufficient model-cache storage capacity')
        report['storage']=dict(raw_model_bytes=raw_bytes,required_with_margin=needed,parent=str(workspace_parent),free_bytes=usage.free,total_bytes=usage.total,
                              exclusions='readback FP64 lifts, cryptographic keys/contexts/ciphertexts; not peak memory')
        pins={'model.safetensors':server_public_model.CHECKPOINT_SHA256,'config.json':server_public_model.CONFIG_SHA256}
        assets={n:server_public_model.file_sha(Path(snapshot)/n) for n in pins}
        if assets!=pins:raise ValueError('pinned public assets differ')
        report['asset_hashes_start']=assets
        owner=client_keys._OwnedDirectory(workspace_parent/('cross-bert-public-model-'+uuid.uuid4().hex))
        report.update(model_workspace=str(owner.path),model_workspace_identity=list(owner.identity),source_hashes_start=before,
            source_archive_sha256=process.sha256(output/'sources.tar.gz'),software=process.software_versions(),worker_python=str(worker_python),
            environment={n:os.environ.get(n) for n in ('JAX_PLATFORMS','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')})
        write(output/'report.json',report)
        if execute:
            directory=output/'worker';directory.mkdir();active=True
            command=[str(worker_python),str(execution/'worker.py'),'--key-evidence',str(key_evidence),'--key-report-sha256',key_report_sha256,
                '--key-workspace',str(key_workspace),'--model-workspace',str(owner.path),'--snapshot',str(snapshot),
                '--output',str(directory/'worker_report.json'),'--source-manifest',str(output/'source_manifest.json')]
            previous=process.child_environment_overrides;process.child_environment_overrides=lambda:{'JAX_PLATFORMS':'cpu','PYTHONUNBUFFERED':'1'}
            try:record=process.run_case(command,directory,timeout=None,cleanup_grace_s=120.)
            finally:process.child_environment_overrides=previous
            active=False;report['worker_process']=record
            if (type(record)is not dict or type(record.get('returncode'))is not int or record['returncode']!=0 or record.get('error')
                    or any(record.get(n)is not True for n in ('process_reaped','public_key_store_removed','owned_directory_handle_closed'))):raise ValueError('stage2 worker failed or cleanup incomplete')
            result=record.get('result');worker=key_gate.parse(key_gate.read(directory/'worker_report.json'))
            if (type(result)is not dict or result.get('passed')is not True or result.get('worker_report_sha256')!=process.sha256(directory/'worker_report.json')
                    or type(worker)is not dict or any(worker.get(n)is not True for n in ('passed','actual_server_preprocess_called','readback_complete','all_readback_fp64_immutable','source_files_unchanged','keygen_and_codecs_forbidden','context_construction_forbidden'))
                    or worker.get('forbidden_attempts') or worker.get('tensor_count')!=196 or worker.get('matrix_count')!=74
                    or worker.get('source_hashes_start')!=before or worker.get('source_hashes_end')!=before or worker.get('prerequisite')!=report['prerequisite']
                    or worker.get('asset_hashes_start')!=assets or worker.get('asset_hashes_end')!=assets):raise ValueError('strict stage2 readback/source proof differs')
            manifest=worker['public_model_manifest']
            if manifest.get('context_id')!=authorized['context_id'] or result.get('model_id')!=manifest.get('model_id'):raise ValueError('model/context result binding differs')
            binding=cache_binding(owner,authorized['context_id'],manifest)
            (output/'model_manifest.json').write_bytes(key_gate.canonical(manifest))
            report.update(binding,actual_preprocessing=True,model_id=manifest['model_id'],context_id=authorized['context_id'],worker_elapsed_s=worker['elapsed_s'])
        after_assets={n:server_public_model.file_sha(Path(snapshot)/n) for n in pins}
        if after_assets!=assets:raise ValueError('public assets changed')
        key_gate.authenticate(key_evidence,key_report_sha256,key_workspace,profile_bytes=profile,plan_bytes=plan)
        report.update(asset_hashes_end=after_assets,operation_complete=True)
    except BaseException as error:primary=error;report['error']=dict(type=type(error).__name__,message=str(error))
    finally:
        with cleanup_signals():
            if active:
                try:
                    record=key_gate.parse(key_gate.read(output/'worker/process.json'))
                    if type(record)is not dict or any(record.get(n)is not True for n in ('process_reaped','public_key_store_removed','owned_directory_handle_closed')):raise ValueError('active stage2 cleanup unknown')
                    report['worker_process']=record
                except BaseException as error:
                    report['worker_process']=dict(process_reaped=False,error='active stage2 cleanup unknown',evidence_error=repr(error))
                    if primary is None:primary=error
                    else:primary.add_note('active process evidence: '+repr(error))
            report['all_processes_reaped']=not active if record is None else type(record)is dict and all(record.get(n)is True for n in ('process_reaped','public_key_store_removed','owned_directory_handle_closed'))
            after=attempt('source readback',lambda:hashes(sources()));verified=attempt('archive readback',lambda:check_archive(output/'sources.tar.gz',before)) if before else False
            report.update(source_hashes_end=after,source_files_unchanged=bool(before) and before==after,source_archive_verified=verified is True)
            keep=bool(execute and report.get('operation_complete') and primary is None and cleanup_error is None and before==after and verified and report['all_processes_reaped'])
            if owner is not None:
                if keep:
                    report['model_workspace_retained']=True
                    attempt('retained model workspace check',owner.check)
                    def verify_cache():
                        current=cache_binding(owner,report['context_id'],key_gate.parse(key_gate.read(output/'model_manifest.json')))
                        if current!={n:report[n] for n in current}:raise ValueError('retained cache identity or manifest changed')
                    attempt('retained model cache check',verify_cache)
                    if primary is not None or cleanup_error is not None:report['retention_reason']='final model-cache verification failed; retained for inspection'
                elif report['all_processes_reaped']:attempt('remove owned model workspace',owner.remove)
                else:report['model_workspace_retained']=True;report['retention_reason']='owned worker cleanup unknown'
                attempt('close owned model workspace',owner.close)
            report['cleanup_completed']=not report.get('cleanup_errors') and report['all_processes_reaped']
            report['passed']=bool(report.get('operation_complete') and primary is None and cleanup_error is None and report['source_files_unchanged'] and verified and report['cleanup_completed'] and (not execute or report['model_workspace_retained']))
            report['elapsed_s']=time.monotonic()-start
            try:write(output/'report.json',report)
            except BaseException as error:
                prior=primary if primary is not None else cleanup_error
                if prior is None:raise
                prior.add_note('stage2 terminal publication: '+repr(error))
            if primary is not None:raise primary
            if cleanup_error is not None:raise cleanup_error
    print(json.dumps({n:report[n] for n in ('passed','execute','actual_preprocessing','model_workspace_retained','elapsed_s')}));return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--key-evidence',type=Path,required=True);p.add_argument('--key-report-sha256',required=True)
    p.add_argument('--key-workspace',type=Path,required=True);p.add_argument('--snapshot',type=Path,required=True);p.add_argument('--workspace-parent',type=Path,default=Path('/tmp'));p.add_argument('--execute',action='store_true');a=p.parse_args()
    with termination_signals():r=run(a.output,key_evidence=a.key_evidence,key_report_sha256=a.key_report_sha256,key_workspace=a.key_workspace,snapshot=a.snapshot,workspace_parent=a.workspace_parent,execute=a.execute);raise SystemExit(0 if r['passed'] else 1)
