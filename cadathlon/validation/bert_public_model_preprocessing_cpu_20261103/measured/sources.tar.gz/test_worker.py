"""Stage2 worker contract/guard tests; no actual public-key or model processing."""
from pathlib import Path
from types import SimpleNamespace
from contextlib import contextmanager
import hashlib,json,os,subprocess,sys
import numpy as np
import pytest
import worker

@pytest.fixture
def case(tmp_path,monkeypatch):
    monkeypatch.setenv('JAX_PLATFORMS','cpu');monkeypatch.setattr(worker,'HERE',tmp_path)
    stage=tmp_path/'checkout/stage/server_inputs';stage.mkdir(parents=True)
    (stage/'p60_profile_and_refresh.json').write_bytes(b'profile');(stage/'twelve_layer_plan.json').write_bytes(b'plan')
    (tmp_path/'source.py').write_bytes(b'# source');expected={'source.py':hashlib.sha256(b'# source').hexdigest()};source_manifest=tmp_path/'sources.json';source_manifest.write_text(json.dumps(expected))
    workspace=tmp_path/'model';workspace.mkdir();keys=tmp_path/'keys';keys.mkdir();snapshot=tmp_path/'assets';snapshot.mkdir();output=tmp_path/'worker_report.json';events=[]
    authorized=dict(context_id='a'*64,public_keys=keys/'public_keys',key_report_sha256='b'*64,key_source_archive_sha256='c'*64)
    def gate(*a,**kw):events.append('prerequisite');return authorized
    monkeypatch.setattr(worker.key_gate,'authenticate',gate)
    monkeypatch.setattr(worker,'install_audit',lambda *a:events.append('audit'))
    @contextmanager
    def guards(calls):events.append('guards');yield
    monkeypatch.setattr(worker,'forbid_crypto',guards)
    shapes={str(i):(1,1) if i<74 else (1,) for i in range(196)}
    def load(*a,**kw):
        events.append('readback');arrays={n:np.zeros(s,dtype='<f8') for n,s in shapes.items()}
        for a in arrays.values():a.flags.writeable=False
        return arrays,dict(model_id='d'*64,context_id='a'*64)
    model=SimpleNamespace(CHECKPOINT_SHA256='modelsha',CONFIG_SHA256='configsha',file_sha=lambda p:events.append('asset') or ('modelsha' if p.name=='model.safetensors' else 'configsha'),load=load,tensor_shapes=lambda:shapes)
    def preprocess(paths):
        events.append('actual_handler');assert set(paths)=={'size','batch_size','model_id','model_revision','public_keys','server_data'}
        assert not paths['server_data'].exists();paths['server_data'].mkdir();return dict(model_id='d'*64,context_id='a'*64)
    handlers=SimpleNamespace(MODEL_ID='model',REVISION='rev',server_preprocess_model=preprocess)
    monkeypatch.setitem(sys.modules,'file_stages',handlers);monkeypatch.setitem(sys.modules,'server_public_model',model)
    args=dict(evidence=tmp_path/'evidence',key_report_sha256='b'*64,key_workspace=keys,model_workspace=workspace,snapshot=snapshot,output=output,source_manifest=source_manifest)
    return SimpleNamespace(args=args,events=events,model=model,handlers=handlers,expected=expected,output=output)

def test_prerequisite_before_assets_and_actual_handler_readback(case):
    c=case;assert worker.run(**c.args)==0
    assert c.events[0]=='prerequisite' and c.events.index('guards')<c.events.index('actual_handler')<c.events.index('readback')
    r=json.loads(c.output.read_text());assert r['passed'] and r['tensor_count']==196 and r['matrix_count']==74 and r['all_readback_fp64_immutable']
    assert r['source_hashes_start']==r['source_hashes_end']==c.expected and not r['model_forward'] and not r['encryption']


def test_pending_key_proof_rejected_before_assets_and_handler(case,monkeypatch):
    def fail(*a,**kw):raise ValueError('keys pending')
    monkeypatch.setattr(worker.key_gate,'authenticate',fail)
    with pytest.raises(ValueError):worker.run(**case.args)
    assert not case.events and not json.loads(case.output.read_text())['passed']


def test_existing_model_output_fails_before_handler(case):
    (case.args['model_workspace']/'server_data').mkdir()
    with pytest.raises(FileExistsError):worker.run(**case.args)
    assert 'actual_handler' not in case.events

@pytest.mark.parametrize('bad',('mutable','wrong_dtype','wrong_count','wrong_shape','wrong_model_id'))
def test_actual_readback_failure_is_not_a_pass(case,bad):
    c=case;original=c.model.load
    def load(*a,**kw):
        arrays,m=original(*a,**kw)
        if bad=='mutable':arrays['0'].flags.writeable=True
        elif bad=='wrong_dtype':arrays['0']=np.zeros((1,1),dtype=np.float32)
        elif bad=='wrong_count':arrays.pop('0')
        elif bad=='wrong_shape':arrays['0']=np.zeros((2,2))
        else:m['model_id']='e'*64
        return arrays,m
    c.model.load=load
    with pytest.raises(ValueError):worker.run(**c.args)
    assert not json.loads(c.output.read_text())['passed']


def test_crypto_guard_aliases_and_restoration_with_fake_modules(monkeypatch):
    names=('gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen');codec=('__init__','encrypt','decrypt','encrypt_slots','decrypt_slots','encrypt_slots_batch','decrypt_slots_batch','decode')
    def original(*a,**kw):return 'ordinary'
    class Context:pass
    for n in codec:setattr(Context,n,original)
    modules={n:SimpleNamespace(__name__=n,**{m:original for m in names}) for n in ('key_gen','jaxite_word.key_gen')}
    monkeypatch.setitem(sys.modules,'jaxite_word',SimpleNamespace(CKKSContext=Context));monkeypatch.setattr(worker.importlib,'import_module',lambda n:modules[n])
    calls=[];error=KeyboardInterrupt('primary')
    with pytest.raises(KeyboardInterrupt) as caught:
        with worker.forbid_crypto(calls):
            for m in modules.values():
                for n in names:
                    with pytest.raises(AssertionError):getattr(m,n)()
            for n in codec:
                with pytest.raises(AssertionError):getattr(Context,n)(None)
            raise error
    assert caught.value is error and len(calls)==16
    assert all(getattr(m,n)is original for m in modules.values() for n in names)
    assert all(getattr(Context,n)is original for n in codec)


def test_audit_guard_private_and_model_imports_without_registering(monkeypatch,tmp_path):
    hooks=[];monkeypatch.setattr(worker.sys,'addaudithook',hooks.append);blocked=[];private=tmp_path/'private';private.mkdir()
    worker.install_audit(private,blocked);guard=hooks[0]
    with pytest.raises(PermissionError):guard('open',(str(private/'secret.npy'),))
    with pytest.raises(PermissionError):guard('import',('torch.nn',))
    guard('open',(str(tmp_path/'public.npy'),));guard('import',('numpy',))
    assert blocked==['private-file','native-model-import']

@pytest.mark.parametrize('cancel',(KeyboardInterrupt,SystemExit))
def test_guard_restoration_prioritizes_cleanup_cancellation_and_attempts_all(monkeypatch,cancel):
    names=('gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen');codec=('__init__','encrypt','decrypt','encrypt_slots','decrypt_slots','encrypt_slots_batch','decrypt_slots_batch','decode')
    def original(*a,**kw):pass
    class Context:pass
    for n in codec:setattr(Context,n,original)
    modules={n:SimpleNamespace(__name__=n,**{m:original for m in names}) for n in ('key_gen','jaxite_word.key_gen')}
    monkeypatch.setitem(sys.modules,'jaxite_word',SimpleNamespace(CKKSContext=Context));monkeypatch.setattr(worker.importlib,'import_module',lambda n:modules[n])
    restored=[];error=cancel('cleanup cancellation');real_setattr=setattr
    def assign(owner,name,value):
        if value is original:
            restored.append(name)
            if owner is Context and name=='decode':raise OSError('first cleanup failure')
            if owner is Context and name=='decrypt_slots_batch':raise error
        real_setattr(owner,name,value)
    monkeypatch.setattr(worker,'setattr',assign,raising=False)
    with pytest.raises(cancel) as caught:
        with worker.forbid_crypto([]):pass
    assert caught.value is error and len(restored)==16
    assert any('first cleanup failure' in n for n in error.__notes__)

def test_actual_public_import_guards_without_constructing_context(tmp_path):
    # Fresh subprocess: import real public backend constants only. Every context,
    # codec and keygen call remains replaced before the deliberate probes.
    script='''
from pathlib import Path
import worker
blocked=[]; calls=[]
worker.install_audit(Path('unavailable-client-private'),blocked)
with worker.forbid_crypto(calls):
    from jaxite_word import CKKSContext
    import importlib
    for module in (importlib.import_module('key_gen'),importlib.import_module('jaxite_word.key_gen')):
        for name in ('gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen'):
            try:getattr(module,name)()
            except AssertionError:pass
            else:raise AssertionError('key guard absent')
    try:CKKSContext()
    except AssertionError:pass
    else:raise AssertionError('context guard absent')
assert not blocked and len(calls)==9
'''
    result=subprocess.run([sys.executable,'-c',script],cwd=Path(worker.__file__).parent,env=os.environ.copy(),capture_output=True,text=True)
    assert result.returncode==0,result.stdout+result.stderr
