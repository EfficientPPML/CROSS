"""Source-bound stage2 tests/public storage planning; no completed-key reads or execution."""
from pathlib import Path
import argparse,json,math,os,shutil,subprocess,sys,time
import collect
from cleanup import cleanup_signals,termination_signals

def run(output):
    output=Path(output);output.mkdir(exist_ok=False);start=time.monotonic();primary=None;before={}
    report=dict(passed=False,actual_preprocessing=False,actual_key_generation=False,model_forward=False,
                scope='Mocked completed-key/worker boundaries plus real public-backend import guards; no key payloads, model assets, context or model preprocessing.')
    try:
        collect.write(output/'report.json',report);raw=collect.sources();before=collect.hashes(raw);collect.archive(output/'sources.tar.gz',raw)
        if not collect.check_archive(output/'sources.tar.gz',before):raise ValueError('preflight source archive differs')
        with (output/'tests.log').open('wb') as log:
            result=subprocess.run([sys.executable,'-m','pytest','-q',*[str(collect.HERE/n) for n in ('test_key_gate.py','test_worker.py','test_collector.py')],
                '--junitxml='+str(output/'tests.xml')],stdout=log,stderr=subprocess.STDOUT,cwd=collect.HERE)
        if result.returncode:raise ValueError('preflight tests failed')
        import server_public_model,xml.etree.ElementTree as ET
        shape=server_public_model.tensor_shapes();size=sum(math.prod(s)*4 for s in shape.values());needed=size+196*512+(1<<30)
        report.update(tests={k:sum(int(x.attrib.get(k,0)) for x in ET.parse(output/'tests.xml').getroot()) for k in ('tests','failures','errors','skipped')},
            public_storage=dict(tensor_count=len(shape),matrix_count=sum(len(s)==2 for s in shape.values()),raw_model_bytes=size,required_with_margin=needed,
                filesystems={str(p):dict(total=(u:=shutil.disk_usage(p)).total,free=u.free,enough=u.free>=needed) for p in (Path('/tmp'),Path('/dev/shm'))},
                exclusions='FP64 readback lifts and native conversion temporaries; no peak-memory claim'),
            prerequisite='Execution requires externally authenticated terminal successful first-handler evidence and retained key workspace; not consumed by this preflight.',passed=True)
    except BaseException as error:primary=error;report.update(passed=False,error=dict(type=type(error).__name__,message=str(error)))
    finally:
        with cleanup_signals():
            try:
                after=collect.hashes(collect.sources());verified=bool(before) and collect.check_archive(output/'sources.tar.gz',before)
                report.update(source_hashes_before=before,source_hashes_after=after,source_files_unchanged=bool(before) and after==before,
                    source_archive_sha256=collect.process.sha256(output/'sources.tar.gz') if before else None,source_archive_verified=verified,
                    elapsed_s=time.monotonic()-start,cpu_affinity=sorted(os.sched_getaffinity(0)),software=collect.process.software_versions())
                report['passed']=bool(report['passed'] and verified and before==after);collect.write(output/'report.json',report)
            except BaseException as error:
                if primary is None:raise
                primary.add_note('preflight terminal publication: '+repr(error))
            if primary is not None:raise primary
    print(json.dumps({n:report[n] for n in ('passed','tests','source_archive_sha256','elapsed_s')}));return 0 if report['passed'] else 1

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    with termination_signals():raise SystemExit(run(a.output))
