"""Prerequisite binding tests with fake evidence, never real key payloads."""
from pathlib import Path
from types import SimpleNamespace
import hashlib,io,json,math,os,sys,tarfile
import pytest
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'checkout/stage'))
import client_keys as keys
import key_gate
PROFILE=(HERE/'checkout/stage/server_inputs/p60_profile_and_refresh.json').read_bytes()
PLAN=(HERE/'checkout/stage/server_inputs/twelve_layer_plan.json').read_bytes()
ACTUAL_SOURCE_FILE=key_gate.KEY_SOURCE_FILE
ACTUAL_SOURCE_SHA256=key_gate.KEY_SOURCE_SHA256

@pytest.fixture
def fixture(tmp_path,monkeypatch):
    evidence=tmp_path/'evidence';evidence.mkdir();(evidence/'worker').mkdir();workspace=tmp_path/'keys';workspace.mkdir();(workspace/'public_keys').mkdir()
    source={'jaxite_word/key_gen.py':b'# explicit fake evidence, never real keys'};hashes={n:key_gate.digest(b) for n,b in source.items()}
    with tarfile.open(evidence/'sources.tar.gz','w:gz') as tar:
        for name,data in source.items():m=tarfile.TarInfo(name);m.size=len(data);tar.addfile(m,io.BytesIO(data))
    p,rotations=keys.public_contract(PROFILE,PLAN)
    arrays={n:dict(sha256='1'*64,dtype='uint32',shape=list(shape),bytes=math.prod(shape)*4+128) for n,(shape,moduli) in keys.inventory(p,rotations).items()}
    body=keys._body(p,rotations,arrays,hashes['jaxite_word/key_gen.py']);public=body|dict(context_id=keys.digest(body))
    (workspace/'public_keys/public_manifest.json').write_bytes(keys.canonical(public));(evidence/'public_manifest.json').write_bytes(keys.canonical(public))
    worker=dict(passed=True,actual_key_generation_started=True,actual_key_generation_completed=True,source_files_unchanged=True,
        private_binding_verified=True,private_permissions_verified=True,private_file_count=2,source_hashes_start=hashes,source_hashes_end=hashes,public_manifest=public)
    report=dict(passed=True,execute=True,actual_key_generation=True,workspace_retained=True,all_processes_reaped=True,cleanup_completed=True,
        source_files_unchanged=True,source_archive_verified=True,workspace=str(workspace),workspace_identity=[workspace.stat().st_dev,workspace.stat().st_ino],
        source_hashes_start=hashes,source_hashes_end=hashes,source_archive_sha256=key_gate.digest((evidence/'sources.tar.gz').read_bytes()),context_id=public['context_id'])
    case=SimpleNamespace(evidence=evidence,workspace=workspace,source=source,hashes=hashes,public=public,worker=worker,report=report)
    pin=tmp_path/'synthetic_source_manifest.json';pin.write_bytes(keys.canonical(hashes))
    monkeypatch.setattr(key_gate,'KEY_SOURCE_FILE',pin);monkeypatch.setattr(key_gate,'KEY_SOURCE_SHA256',key_gate.digest(pin.read_bytes()))
    rebind(case);return case

def rebind(c):
    (c.evidence/'worker/worker_report.json').write_bytes(keys.canonical(c.worker))
    c.report['worker_process']=dict(returncode=0,process_reaped=True,public_key_store_removed=True,owned_directory_handle_closed=True,
        result=dict(passed=True,context_id=c.public['context_id'],worker_report_sha256=key_gate.digest((c.evidence/'worker/worker_report.json').read_bytes())))
    publish(c)
def publish(c):
    (c.evidence/'report.json').write_bytes(keys.canonical(c.report));c.expected=key_gate.digest((c.evidence/'report.json').read_bytes())
def call(c):return key_gate.authenticate(c.evidence,c.expected,c.workspace,profile_bytes=PROFILE,plan_bytes=PLAN)


def test_external_pin_allows_only_public_metadata(fixture,monkeypatch):
    c=fixture;original=key_gate.read;read=[]
    def capture(path,*args):read.append(str(path));return original(path,*args)
    monkeypatch.setattr(key_gate,'read',capture);r=call(c)
    assert r['context_id']==c.public['context_id'] and r['public_keys']==c.workspace/'public_keys'
    assert not any('client_private' in p or p.endswith('.npy') for p in read)


def test_wrong_external_pin_fails_before_other_reads(fixture,monkeypatch):
    c=fixture;original=key_gate.read;reads=[]
    def capture(path,*args):reads.append(path);return original(path,*args)
    monkeypatch.setattr(key_gate,'read',capture);c.expected='0'*64
    with pytest.raises(ValueError):call(c)
    assert reads==[c.evidence/'report.json']

@pytest.mark.parametrize('flag',('passed','execute','actual_key_generation','workspace_retained','all_processes_reaped','cleanup_completed','source_files_unchanged','source_archive_verified'))
def test_pending_failed_or_boolean_alias_proof_rejected(fixture,flag):
    c=fixture;c.report[flag]=1;publish(c)
    with pytest.raises(ValueError):call(c)

@pytest.mark.parametrize('flag',('process_reaped','public_key_store_removed','owned_directory_handle_closed','returncode'))
def test_partial_process_cleanup_or_returncode_alias_rejected(fixture,flag):
    c=fixture;c.report['worker_process'][flag]=False if flag=='returncode' else 1;publish(c)
    with pytest.raises(ValueError):call(c)

@pytest.mark.parametrize('bad',('worker_digest','worker_private','worker_sources','workspace','public_copy','public_current','profile','archive','duplicate_member'))
def test_binding_corruption_rejected(fixture,bad):
    c=fixture
    if bad=='worker_digest':(c.evidence/'worker/worker_report.json').write_bytes(b'{}')
    elif bad=='worker_private':c.worker['private_binding_verified']=False;rebind(c)
    elif bad=='worker_sources':c.worker['source_hashes_end']={};rebind(c)
    elif bad=='workspace':c.report['workspace_identity'][1]+=1;publish(c)
    elif bad=='public_copy':(c.evidence/'public_manifest.json').write_bytes(b'{}')
    elif bad=='public_current':(c.workspace/'public_keys/public_manifest.json').write_bytes(b'{}')
    elif bad=='profile':
        with pytest.raises(ValueError):key_gate.authenticate(c.evidence,c.expected,c.workspace,profile_bytes=PROFILE+b' ',plan_bytes=PLAN)
        return
    elif bad=='archive':(c.evidence/'sources.tar.gz').write_bytes(b'bad')
    else:
        with tarfile.open(c.evidence/'sources.tar.gz','w:gz') as tar:
            for _ in range(2):
                n,b=next(iter(c.source.items()));m=tarfile.TarInfo(n);m.size=len(b);tar.addfile(m,io.BytesIO(b))
        c.report['source_archive_sha256']=key_gate.digest((c.evidence/'sources.tar.gz').read_bytes());publish(c)
    with pytest.raises(ValueError):call(c)

@pytest.mark.parametrize('kind',('symlink','fifo','directory','oversize'))
def test_prerequisite_reader_rejects_nonregular_or_unbounded(tmp_path,kind):
    p=tmp_path/'bad'
    if kind=='symlink':(tmp_path/'real').write_bytes(b'{}');p.symlink_to(tmp_path/'real')
    elif kind=='fifo':os.mkfifo(p)
    elif kind=='directory':p.mkdir()
    else:p.write_bytes(b'x'*33)
    with pytest.raises((ValueError,OSError)):key_gate.read(p,32)


def test_actual_inherited_58_source_archive_and_large_plan_regression(fixture,monkeypatch):
    c=fixture;raw=(HERE/'key_source_archive_fixture.tar.gz').read_bytes();c.hashes=key_gate.parse(ACTUAL_SOURCE_FILE.read_bytes())
    assert len(c.hashes)==58
    with tarfile.open(fileobj=io.BytesIO(raw)) as tar:
        assert tar.getmember('stage/server_inputs/twelve_layer_plan.json').size==6461050
    (c.evidence/'sources.tar.gz').write_bytes(raw)
    p,rotations=keys.public_contract(PROFILE,PLAN);body=keys._body(p,rotations,c.public['arrays'],c.hashes['jaxite_word/key_gen.py']);c.public=body|dict(context_id=keys.digest(body))
    for path in (c.evidence/'public_manifest.json',c.workspace/'public_keys/public_manifest.json'):path.write_bytes(keys.canonical(c.public))
    c.worker.update(source_hashes_start=c.hashes,source_hashes_end=c.hashes,public_manifest=c.public)
    c.report.update(source_hashes_start=c.hashes,source_hashes_end=c.hashes,source_archive_sha256=key_gate.digest(raw),context_id=c.public['context_id']);rebind(c)
    monkeypatch.setattr(key_gate,'KEY_SOURCE_FILE',ACTUAL_SOURCE_FILE);monkeypatch.setattr(key_gate,'KEY_SOURCE_SHA256',ACTUAL_SOURCE_SHA256)
    # Preserve an executable regression of the exact frozen prelaunch-v1 gate.
    import types
    old=types.ModuleType('old_source_size_gate');old.__file__=str(HERE/'key_gate_before_size_fix.py.txt')
    exec(compile((HERE/'key_gate_before_size_fix.py.txt').read_bytes(),old.__file__,'exec'),old.__dict__)
    with pytest.raises(ValueError,match='source archive inventory'):
        old.authenticate(c.evidence,c.expected,c.workspace,profile_bytes=PROFILE,plan_bytes=PLAN)
    assert call(c)['context_id']==c.public['context_id']


def test_fixed_inventory_rejects_authenticated_but_different_source_set(fixture,monkeypatch):
    c=fixture;pin=key_gate.KEY_SOURCE_FILE;pin.write_bytes(keys.canonical(dict(c.hashes,unexpected='f'*64)))
    monkeypatch.setattr(key_gate,'KEY_SOURCE_SHA256',key_gate.digest(pin.read_bytes()))
    with pytest.raises(ValueError,match='fixed first-handler source inventory'):call(c)


@pytest.mark.parametrize('sizes',((8*2**20+1,),(8*2**20,8*2**20,1)))
def test_source_archive_per_member_and_total_bounds(sizes):
    stream=io.BytesIO();expected={}
    with tarfile.open(fileobj=stream,mode='w:gz') as tar:
        for i,size in enumerate(sizes):
            data=b'0'*size;name=str(i)+'.py';m=tarfile.TarInfo(name);m.size=size;tar.addfile(m,io.BytesIO(data));expected[name]=key_gate.digest(data)
    with pytest.raises(ValueError,match='inventory'):key_gate.verify_source_archive(stream.getvalue(),expected)
