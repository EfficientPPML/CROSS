"""Actual public-model stage2 after externally authenticated completed stage1."""
from pathlib import Path
from contextlib import contextmanager,redirect_stdout
import argparse,hashlib,importlib,json,os,stat,sys,time
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE/'checkout/stage'),str(HERE/'checkout')]
from cleanup import cleanup_signals,termination_signals
import key_gate


def write(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');tmp.replace(path)
def hashes(expected):
    result={}
    for name in expected:
        path=Path(name)
        if path.is_absolute() or '..' in path.parts:raise ValueError('relative execution source required')
        result[name]=hashlib.sha256((HERE/path).read_bytes()).hexdigest()
    return result

def install_audit(private_path,blocked):
    private_path=Path(private_path).absolute();resolved=private_path.resolve()
    def guard(event,args):
        if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
            path=Path(os.fsdecode(args[0])).absolute()
            if path==private_path or private_path in path.parents or path.resolve()==resolved or resolved in path.resolve().parents:
                blocked.append('private-file');raise PermissionError('public model stage cannot read client-private files')
        if event=='import' and type(args[0])is str and args[0].split('.')[0] in ('torch','transformers'):
            blocked.append('native-model-import');raise PermissionError('no native model or embedding forward in public model stage')
    sys.addaudithook(guard)

@contextmanager
def forbid_crypto(calls):
    from jaxite_word import CKKSContext
    modules=[importlib.import_module(n) for n in ('key_gen','jaxite_word.key_gen')]
    if {m.__name__ for m in modules}!={'key_gen','jaxite_word.key_gen'}:raise ValueError('both keygen aliases required')
    patches=[];primary=None;failure=None
    def denied(name):
        def fail(*a,**kw):calls.append(name);raise AssertionError('forbidden stage2 action: '+name)
        return fail
    try:
        for module in modules:
            for name in ('gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen'):
                patches.append((module,name,getattr(module,name)));setattr(module,name,denied(module.__name__+'.'+name))
        for name in ('__init__','encrypt','decrypt','encrypt_slots','decrypt_slots','encrypt_slots_batch','decrypt_slots_batch','decode'):
            patches.append((CKKSContext,name,getattr(CKKSContext,name)));setattr(CKKSContext,name,denied('CKKSContext.'+name))
        yield
    except BaseException as error:primary=error;raise
    finally:
        with cleanup_signals():
            for owner,name,original in reversed(patches):
                try:setattr(owner,name,original)
                except BaseException as error:
                    if primary is not None:primary.add_note('stage2 guard restoration: '+repr(error))
                    elif failure is None:failure=error
                    elif not isinstance(error,Exception) and isinstance(failure,Exception):error.add_note('earlier guard restoration: '+repr(failure));failure=error
                    else:failure.add_note('additional guard restoration: '+repr(error))
            if primary is None and failure is not None:raise failure


def run(*,evidence,key_report_sha256,key_workspace,model_workspace,snapshot,output,source_manifest):
    start=time.monotonic();primary=None;expected={};blocked=[];calls=[]
    report=dict(passed=False,scope='Actual public model preprocessing/readback only; no private inputs, embeddings, encryption, native or encrypted forward.',
                model_forward=False,encryption=False,context_constructed=False,pid=os.getpid(),cpu_affinity=sorted(os.sched_getaffinity(0)))
    try:
        write(output,report)
        if os.environ.get('JAX_PLATFORMS')!='cpu':raise ValueError('explicit CPU public preprocessing required')
        expected=key_gate.parse(key_gate.read(source_manifest))
        report['source_hashes_start']=hashes(expected)
        if report['source_hashes_start']!=expected:raise ValueError('execution source startup differs')
        profile=(HERE/'checkout/stage/server_inputs/p60_profile_and_refresh.json').read_bytes();plan=(HERE/'checkout/stage/server_inputs/twelve_layer_plan.json').read_bytes()
        authorized=key_gate.authenticate(evidence,key_report_sha256,key_workspace,profile_bytes=profile,plan_bytes=plan)
        report['prerequisite']=dict(context_id=authorized['context_id'],key_report_sha256=authorized['key_report_sha256'],key_source_archive_sha256=authorized['key_source_archive_sha256'])
        install_audit(key_workspace/'client_private',blocked)
        import file_stages,server_public_model
        pins={'model.safetensors':server_public_model.CHECKPOINT_SHA256,'config.json':server_public_model.CONFIG_SHA256}
        assets={n:server_public_model.file_sha(snapshot/n) for n in pins}
        if assets!=pins:raise ValueError('pinned model/config assets differ')
        report['asset_hashes_start']=assets
        server_data=model_workspace/'server_data'
        if server_data.exists() or server_data.is_symlink():raise FileExistsError('fresh owned model output required')
        paths=dict(size=0,batch_size=1,model_id=file_stages.MODEL_ID,model_revision=file_stages.REVISION,
                   public_keys=authorized['public_keys'],server_data=server_data)
        os.environ['CROSS_BERT_SNAPSHOT']=str(snapshot)
        write(output,report)
        with forbid_crypto(calls),redirect_stdout(sys.stderr):
            result=file_stages.server_preprocess_model(paths)
            arrays,manifest=server_public_model.load(server_data/authorized['context_id'],context_id=authorized['context_id'])
            if (result['context_id']!=authorized['context_id'] or result['model_id']!=manifest['model_id']
                    or set(arrays)!=set(server_public_model.tensor_shapes()) or len(arrays)!=196
                    or any(a.dtype.str!='<f8' or a.flags.writeable or a.shape!=server_public_model.tensor_shapes()[n] for n,a in arrays.items())):
                raise ValueError('actual public-model readback differs')
            matrix_count=sum(a.ndim==2 for a in arrays.values());del arrays
        if calls or blocked:raise ValueError('stage2 attempted a forbidden private/crypto/model action')
        after={n:server_public_model.file_sha(snapshot/n) for n in pins}
        if after!=assets:raise ValueError('public assets changed during stage2')
        # The caller-pinned completed-key artifact/workspace must still match;
        #this public-only check never opens the secret or private manifest.
        key_gate.authenticate(evidence,key_report_sha256,key_workspace,profile_bytes=profile,plan_bytes=plan)
        report.update(passed=True,actual_server_preprocess_called=True,readback_complete=True,tensor_count=196,matrix_count=matrix_count,
                      all_readback_fp64_immutable=True,public_model_manifest=manifest,asset_hashes_end=after,
                      keygen_and_codecs_forbidden=True,context_construction_forbidden=True,forbidden_attempts=[],server_data=str(server_data))
    except BaseException as error:primary=error;report.update(passed=False,error=dict(type=type(error).__name__,message=str(error)))
    finally:
        with cleanup_signals():
            try:
                after=hashes(expected) if expected else {};report.update(source_hashes_end=after,source_files_unchanged=bool(expected) and after==expected,
                    forbidden_attempts=blocked+calls,elapsed_s=time.monotonic()-start)
                report['passed']=bool(report['passed'] and report['source_files_unchanged']);write(output,report)
            except BaseException as error:
                if primary is None:raise
                primary.add_note('stage2 terminal source/publication: '+repr(error))
            if primary is not None:raise primary
    print(json.dumps(dict(passed=report['passed'],model_id=report['public_model_manifest']['model_id'],context_id=authorized['context_id'],
        worker_report_sha256=hashlib.sha256(output.read_bytes()).hexdigest(),elapsed_s=report['elapsed_s'])));return 0 if report['passed'] else 1

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--key-evidence',type=Path,required=True);p.add_argument('--key-report-sha256',required=True);p.add_argument('--key-workspace',type=Path,required=True)
    p.add_argument('--model-workspace',type=Path,required=True);p.add_argument('--snapshot',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--source-manifest',type=Path,required=True);a=p.parse_args()
    with termination_signals():raise SystemExit(run(evidence=a.key_evidence,key_report_sha256=a.key_report_sha256,key_workspace=a.key_workspace,
        model_workspace=a.model_workspace,snapshot=a.snapshot,output=a.output,source_manifest=a.source_manifest))
