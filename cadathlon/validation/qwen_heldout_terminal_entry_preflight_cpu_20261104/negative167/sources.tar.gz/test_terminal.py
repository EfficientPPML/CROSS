"""Expected negatives exercise only synthetic reports and exact selected AST."""
import json,os,signal,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
import pytest
import probe
ROOT=Path(__file__).resolve().parent.parent

def run(kind,tmp_path):
    out=tmp_path/kind
    process=subprocess.Popen([sys.executable,'-I','-B',str(Path(probe.__file__)),str(out),kind],stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    try:
        stdout,stderr=process.communicate(timeout=15)
    except BaseException:
        try:os.killpg(process.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        process.communicate();raise
    try:os.killpg(process.pid,0)
    except ProcessLookupError:group_gone=True
    else:group_gone=False
    assert group_gone
    worker=json.loads((out/'report.json').read_bytes())
    receipt=dict(kind=kind,pid=process.pid,pgid=process.pid,exit_code=process.returncode,direct_child_reaped=True,group_absent=group_gone,stderr_bytes=len(stderr),report_passed=worker['passed'],persisted_cleanup_completed=worker['cleanup_completed'],actual_close=json.loads((out/'close-attempt.json').read_text()))
    receipt.update(probe.admitted_report(worker,process.returncode))
    (ROOT/(kind+'-receipt.json')).write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    return receipt

@pytest.mark.parametrize('kind',['oserror','systemexit1'])
def test_late_close_failure_must_not_admit_completed_scientific_result(kind,tmp_path):
    r=run(kind,tmp_path)
    assert r['exit_code']==1 and r['actual_close']['completed']is False
    if kind=='systemexit1':assert r['stderr_bytes']==0
    assert not(r['accept_worker_accepted']or r['complete_scientific_prior_accepted']), 'Failed close was admitted as completed scientific failure'

def test_clean_scientific_fail_control_is_accepted(tmp_path):
    r=run('clean',tmp_path)
    assert r['exit_code']==1 and r['actual_close']['completed']is True
    assert r['accept_worker_accepted']is r['complete_scientific_prior_accepted']is True

def test_independent_row0_retirement_control_admits_no_scientific_result():
    _,frozen,_,_=probe.fixture(False);sha=probe.f.sha
    grant=dict(protocol_sha256=sha(b'protocol'),model_pins_sha256=sha(b'modelpins'))
    fixed=dict(schema='qwen-independent-row0-admission-v1',candidate_manifest_sha256=frozen.manifest_sha256,freeze_receipt_sha256=frozen.receipt_sha256,**grant,selection_permanently_closed=True,scientific_result_admitted=False,retry_authorized=False,feedback_authorized=False,coefficient_selection_authorized=False,candidate_revision_authorized=False,validation_execution_authorized=False,row0_execution_authorized=False,prior_attempt='terminal',heldout_grant_sha256=sha(b'prior grant'),expected_source_manifest_sha256=sha(b'prior source'),observed_outcome='infrastructure_failure',parent=dict(pid=100,pgid=100,exit_code=1,reaped=True,group_absent=True,report_sha256=None,source_archive_sha256=None,source_verified=None,cleanup_completed=None,publication_completed=None),worker=dict(state='retired',pid=101,pgid=101,exit_code=1,reaped=True,group_absent=True,report_sha256=None),validation_read=dict(status='unknown',attempted=None,authenticated=None,reauthenticated=None))
    probe.gate._independent_row0(probe.fixtures['encoded'](fixed),frozen,grant)
    fixed['scientific_result_admitted']=True
    with pytest.raises(ValueError):probe.gate._independent_row0(probe.fixtures['encoded'](fixed),frozen,grant)
