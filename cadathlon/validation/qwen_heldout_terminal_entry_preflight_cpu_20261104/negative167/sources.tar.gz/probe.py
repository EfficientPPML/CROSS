"""Exact selected AST bodies with explicit synthetic lifecycle/public receipt seams."""
import ast
import hashlib
import json
import math
import re
import time
from pathlib import Path,PurePosixPath
from types import SimpleNamespace
from contextlib import contextmanager
HERE=Path(__file__).resolve().parent

def selected(file,names,env):
    tree=ast.parse((HERE/file).read_text());nodes=[]
    for n in tree.body:
        label=n.name if isinstance(n,(ast.FunctionDef,ast.ClassDef))else n.targets[0].id if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)else None
        if label in names:nodes.append(n)
    found={n.name if isinstance(n,(ast.FunctionDef,ast.ClassDef))else n.targets[0].id for n in nodes}
    assert found==set(names),(file,found,names)
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(HERE/file),'exec'),env)
    return env

base=dict(json=json,math=math,re=re,hashlib=hashlib,PurePosixPath=PurePosixPath)
f=SimpleNamespace(**selected('freeze_admission.py',('sha','digest','fields','integer'),dict(base)))
ig=SimpleNamespace(**selected('input_gate.py',('typed_equal',),{}))
genv=dict(base,freeze=f,input_gate=ig)
selected('heldout_authorization.py',('CANDIDATE','TERMINAL_FLAGS','WORKER_FLAGS','_parse','_equal','_prior_heldout','_independent_row0'),genv)
gate=SimpleNamespace(**genv)
fixtures=dict(json=json,f=f,gate=gate)
selected('test_heldout_authorization.py',('encoded','prior','prior_outer'),fixtures)
accept=selected('heldout_process.py',('accept_worker',),{'input_gate':ig})['accept_worker']

def fixture(passed=False):
    frozen=SimpleNamespace(manifest_sha256=gate.CANDIDATE,receipt_sha256=f.sha(b'synthetic freeze'))
    source=f.sha(b'synthetic source manifest')
    parent=fixtures['prior'](frozen,source,passed)
    args=SimpleNamespace(manifest_sha256=source,grant_sha256=parent['grant_sha256'])
    binding=SimpleNamespace(mode='heldout',manifest_sha256=frozen.manifest_sha256,frozen=frozen)
    return parent,frozen,args,binding

@contextmanager
def synthetic_signals(state=None,shield=False):
    if state is not None:state['restored']=True
    yield

def child(out,kind):
    # All data below are a synthetic public report and two event flags.
    out.mkdir(mode=0o700)
    parent,frozen,args,binding=fixture(False);report=parent['worker'];expected=report['source_hashes_start']
    class Output:
        path=str(out);owner=(100,200)
        def __init__(self,publication=False):self.publication=publication
        def close(self):
            if not self.publication:return
            (out/'close-attempt.json').write_text(json.dumps({'attempted':True,'completed':kind=='clean','fault':kind}))
            if kind=='oserror':raise OSError('synthetic publication close')
            if kind=='systemexit1':raise SystemExit(1)
        def json(self,name,value):
            (out/name).write_bytes(fixtures['encoded'](value))
        @classmethod
        def reopen(cls,path,owner):return cls(True)
    env=dict(time=time,Output=Output,signals=synthetic_signals,source_end=lambda root,exp:exp)
    selected('cleanup_origin.py',('BODY','CLEANUP','cleanup_origin','protect_body','mark_cleanup','choose'),env)
    selected('checker_process.py',('accumulate','supervise'),env)
    # Assert the frozen heldout layer aliases the exact extracted supervisor.
    t=ast.parse((HERE/'heldout_process.py').read_text())
    a=next(n for n in t.body if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)and n.targets[0].id=='supervise')
    assert ast.dump(a.value)==ast.dump(ast.Attribute(value=ast.Name(id='life',ctx=ast.Load()),attr='supervise',ctx=ast.Load()))
    def main():return env['supervise'](Output(),report,lambda:None,[],HERE,expected)
    # Execute the unchanged heldout_entry final main guard. No bootstrap, helper
    # import, parameter/model/input or actual role is executed by this probe.
    tree=ast.parse((HERE/'heldout_entry.py').read_text());node=tree.body[-1]
    assert isinstance(node,ast.If)and isinstance(node.body[0],ast.Raise)
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(HERE/'heldout_entry.py'),'exec'),{'__name__':'__main__','main':main})

def admitted_report(worker,code):
    parent,frozen,args,binding=fixture(False)
    accept(worker,code,worker['source_hashes_start'],args,binding)
    parent.update(worker=worker,worker_report_sha256=f.sha(fixtures['encoded'](worker)),child_returncode=code)
    raw=fixtures['encoded'](parent)
    # This is a deliberately synthetic external assertion. It demonstrates
    # what the pure prior validator accepts; it is not an authenticated root
    # attestation that the observed failed publication close completed.
    outer=fixtures['encoded'](fixtures['prior_outer'](parent,raw))
    gate._prior_heldout(raw,outer,frozen,args.manifest_sha256)
    return {'accept_worker_accepted':True,'complete_scientific_prior_accepted':True,'outer_publication_completed':'synthetic assertion only; contradicted in fault cases'}

if __name__=='__main__':
    import sys
    child(Path(sys.argv[1]),sys.argv[2])
