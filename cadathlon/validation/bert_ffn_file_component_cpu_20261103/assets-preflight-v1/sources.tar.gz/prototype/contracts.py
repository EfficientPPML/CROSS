"""Fixed pinned FFN model/key/circuit contracts; no private input loader."""
from pathlib import Path
import hashlib,json,math
import numpy as np
from spec import ASSETS,REVISION,KINDS,MATRIX_KINDS,ROTATIONS,LEVELS,parameters,GELU_DOMAIN,GELU_COEFFICIENTS,GELU_COEFFICIENT_SHA256,EXPECTED_TENSOR_SHA256
from transport import _json,_canonical,_read_regular

def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def digest(value):return hashlib.sha256(_canonical(value)).hexdigest()
def write(path,value):Path(path).write_bytes(_canonical(value))
def polynomial_contract():
 from encrypted_polynomial import PolynomialApproximation
 if hashlib.sha256(np.asarray(GELU_COEFFICIENTS,dtype='<f8').tobytes()).hexdigest()!=GELU_COEFFICIENT_SHA256:raise ValueError('fixed polynomial coefficient bytes differ')
 return PolynomialApproximation('gelu',GELU_DOMAIN,GELU_COEFFICIENTS)
def packing_contract():
 from encrypted_streaming_linear import RowTileLayout
 layout=RowTileLayout(32768)
 return {'input':layout.linear_contract(rows=2,input_width=768,output_width=3072),'output':layout.linear_contract(rows=2,input_width=3072,output_width=768),'levels':LEVELS,'raw_gelu_padding':'declared polynomial at zero','final_padding':'zero-including-bias'}
def circuit_contract():
 import encrypted_streaming_linear,encrypted_polynomial
 common=Path(encrypted_streaming_linear.__file__).parent
 return {'scope':'layer0 intermediate dense, fixed GELU, output dense only; no residual or LayerNorm','gelu':{'degree':48,'domain':list(GELU_DOMAIN),'coefficient_sha256':GELU_COEFFICIENT_SHA256,'basis':'balanced-chebyshev'},'source_sha256':{name:sha(common/name) for name in ('encrypted_streaming_linear.py','encrypted_polynomial.py','encrypted_packed_transformer.py','encrypted_packed_qwen.py')}|{name:sha(Path(__file__).with_name(name)) for name in ('component.py','spec.py','transport.py','contracts.py')}}
def pack_rows(rows,width=768):
 from encrypted_streaming_linear import RowTileLayout
 rows=np.asarray(rows)
 if rows.dtype!=np.float64 or rows.shape!=(2,width) or not np.isfinite(rows).all():raise ValueError('two finite float64 rows of declared width required')
 return next(RowTileLayout(32768).pack_client_rows(rows))
def unpack_rows(slots,width=768):
 from encrypted_streaming_linear import RowTileLayout
 return RowTileLayout(32768).unpack_client_rows([slots],rows=2,width=width)
def check_parameters(value):
 if value!=parameters() or set(value)!=set(parameters()):raise ValueError('unsupported public component parameters')
 for name in ('degree','num_slots','composite_degree','precision','max_level','dnum','batch'):
  if type(value[name]) is not int:raise ValueError('noninteger public parameter')
 from jaxite_word import he_params
 if value['sigma']!=he_params.DEFAULT_SIGMA or value['secret_distribution']!=he_params.SECRET_DISTRIBUTION:raise ValueError('security distributions differ')
 if not he_params.qp_is_secure(value['q_towers'],value['p_towers'],value['degree'],he_params.SecurityTarget(128,'classical')):raise ValueError('insecure actual ring')
 he_params.assert_p_coverage(value['q_towers'],value['p_towers'],value['dnum'])
 return sum(math.log2(q) for q in value['q_towers']+value['p_towers'])
def tensor_shape(phase,kind):
 return (3072,768) if (phase,kind)==('intermediate','weight') else (768,3072) if kind=='weight' else (3072,) if phase=='intermediate' else (768,)
def load_model(directory):
 directory=Path(directory);manifest=_json(_read_regular(directory/'model_manifest.json',65536));names={f'{phase}_{kind}.npy' for phase in MATRIX_KINDS for kind in ('weight','bias')}
 if set(manifest)!={'schema','model_id','revision','asset_sha256','tensors'} or manifest['schema']!='pinned-bert-layer0-ffn-v1' or manifest['model_id']!='google-bert/bert-base-cased-finetuned-mrpc' or manifest['revision']!=REVISION or manifest['asset_sha256']!=ASSETS or set(manifest['tensors'])!=names:raise ValueError('public pinned model identity differs')
 if directory.is_symlink() or {p.name for p in directory.iterdir()}!=names|{'model_manifest.json'}:raise ValueError('public model inventory differs')
 arrays={}
 for phase in MATRIX_KINDS:
  pair=[]
  for kind in ('weight','bias'):
   shape=tensor_shape(phase,kind);name=f'{phase}_{kind}.npy';full=f'bert.encoder.layer.0.{phase}.dense.{kind}';desc=manifest['tensors'][name];p=directory/name
   if set(desc)!={'name','shape','dtype','file_sha256','tensor_sha256'} or desc['name']!=full or desc['shape']!=list(shape) or desc['dtype']!='<f4' or desc['tensor_sha256']!=EXPECTED_TENSOR_SHA256[full] or p.is_symlink() or sha(p)!=desc['file_sha256']:raise ValueError('public tensor identity differs')
   a=np.load(p,allow_pickle=False,mmap_mode='r')
   if a.dtype.str!='<f4' or a.shape!=shape or not np.isfinite(a).all() or hashlib.sha256(a.tobytes()).hexdigest()!=desc['tensor_sha256']:raise ValueError('public tensor data differs')
   pair.append(a.astype(np.float64))
  arrays[phase]=tuple(pair)
 return manifest,arrays

def key_names():return {'public_key.npy','relin_a.npy','relin_b.npy'}|{f'rot_{i}_{part}.npy' for i in ROTATIONS for part in ('a','b')}
def store_array(directory,name,array):
 a=np.asarray(array,dtype=np.uint32);np.save(directory/name,a,allow_pickle=False)
 return {'sha256':sha(directory/name),'shape':list(a.shape),'dtype':'uint32'}
def load_public(directory,model_directory):
 directory=Path(directory);raw=_read_regular(directory/'public_manifest.json',262144);m=_json(raw)
 expected={'schema','parameters','rotations','arrays','representation','keygen_source_sha256','model_manifest_sha256','packing','circuit','context_id'}
 if not isinstance(m,dict) or set(m)!=expected:raise ValueError('unexpected public manifest fields')
 body={k:v for k,v in m.items() if k!='context_id'}
 if m['context_id']!=digest(body) or m['schema']!='bert-ffn-public-ckks-v1' or raw!=_canonical(m):raise ValueError('public context identity differs')
 if m['circuit']!=circuit_contract():raise ValueError('fixed circuit or source differs')
 polynomial_contract();check_parameters(m['parameters'])
 if m['rotations']!=ROTATIONS or m['representation']!='standard-ntt-residues/digit-modulus-degree' or m['packing']!=packing_contract():raise ValueError('unsupported circuit layout')
 from jaxite_word import key_gen
 if m['keygen_source_sha256']!=sha(key_gen.__file__):raise ValueError('public key source differs')
 model,matrices=load_model(model_directory)
 if sha(Path(model_directory)/'model_manifest.json')!=m['model_manifest_sha256']:raise ValueError('public model binding differs')
 names=key_names()
 if set(m['arrays'])!=names or directory.is_symlink() or {p.name for p in directory.iterdir()}!=names|{'public_manifest.json'}:raise ValueError('unexpected public key inventory')
 arrays={};p=m['parameters'];q=p['q_towers'];qp=q+p['p_towers']
 for name in sorted(names):
  path=directory/name;desc=m['arrays'][name];shape=(2,36,65536) if name=='public_key.npy' else (2,53,65536);moduli=q if name=='public_key.npy' else qp
  if set(desc)!={'sha256','shape','dtype'} or desc['shape']!=list(shape) or desc['dtype']!='uint32' or path.is_symlink() or sha(path)!=desc['sha256']:raise ValueError('public key descriptor differs')
  a=np.load(path,allow_pickle=False,mmap_mode='r')
  if a.dtype!=np.uint32 or a.shape!=shape or np.any(a>=np.asarray(moduli,dtype=np.uint32)[None,:,None]):raise ValueError('public key residues differ')
  arrays[name]=a
 return m,arrays,matrices
