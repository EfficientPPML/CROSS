"""Trusted native attention-output fixture for an isolated FFN, not a full P2 client."""
from pathlib import Path
import argparse,hashlib,importlib.metadata,json,os,struct,sys,time
import numpy as np
ROOT=Path(os.environ['CROSS_ROOT']).resolve();sys.path[:0]=[str(ROOT),str(ROOT/'cadathlon/common')]
from spec import REVISION,ASSETS,EXAMPLE,KINDS,MATRIX_KINDS,EXPECTED_TENSOR_SHA256,GELU_COEFFICIENT_SHA256
from contracts import sha,write,digest,pack_rows,polynomial_contract,tensor_shape

def tensor_bytes(snapshot,name):
 with (snapshot/'model.safetensors').open('rb') as f:
  n=struct.unpack('<Q',f.read(8))[0];header=json.loads(f.read(n));entry=header[name];start,stop=entry['data_offsets'];f.seek(8+n+start);raw=f.read(stop-start)
 if entry['dtype']!='F32':raise ValueError('expected pinned F32 tensor')
 return np.frombuffer(raw,dtype='<f4').reshape(entry['shape']).copy()
def prepare(snapshot,private,model):
 started=time.perf_counter();hashes={n:sha(snapshot/n) for n in ASSETS}
 if hashes!=ASSETS or snapshot.name!=REVISION:raise ValueError('pinned BERT asset mismatch')
 import torch
 from transformers import AutoTokenizer,BertForSequenceClassification
 torch.set_num_threads(1)
 tokenizer=AutoTokenizer.from_pretrained(snapshot,local_files_only=True)
 network,loading=BertForSequenceClassification.from_pretrained(snapshot,local_files_only=True,use_safetensors=True,torch_dtype=torch.float64,attn_implementation='eager',output_loading_info=True)
 if loading['missing_keys'] or loading.get('mismatched_keys') or loading.get('error_msgs') or set(loading['unexpected_keys'])-{'bert.embeddings.position_ids'}:raise ValueError('incomplete pinned model')
 network.eval();tokens=tokenizer(*EXAMPLE,max_length=128,padding='max_length',truncation=True,return_tensors='pt');layer=network.bert.encoder.layer[0]
 with torch.no_grad():
  embedding=network.bert.embeddings(input_ids=tokens['input_ids'],token_type_ids=tokens['token_type_ids'])
  mask=tokens['attention_mask'].bool();additive=torch.zeros(mask[:,None,None,:].shape,dtype=torch.float64).masked_fill(~mask[:,None,None,:],torch.finfo(torch.float64).min)
  attention=layer.attention(embedding,attention_mask=additive)[0]
  rows=attention[0,:2].numpy().copy();native_linear=layer.intermediate.dense(attention)[0,:2].numpy().copy();native_gelu=layer.intermediate(attention)[0,:2].numpy().copy();native_ffn=layer.output.dense(layer.intermediate(attention))[0,:2].numpy().copy()
 if rows.shape!=(2,768) or np.array_equal(rows[0],rows[1]) or not np.isfinite(rows).all() or not bool(mask[0,:2].all()):raise ValueError('fixed positions0/1 must be distinct finite valid attention-output rows')
 private.mkdir(mode=0o700);model.mkdir();np.save(private/'attention_rows.npy',rows,allow_pickle=False);write(private/'tokens.json',{k:v.tolist() for k,v in tokens.items()})
 manifest={'schema':'pinned-bert-layer0-ffn-v1','model_id':'google-bert/bert-base-cased-finetuned-mrpc','revision':REVISION,'asset_sha256':hashes,'tensors':{}};matrices={};state=network.state_dict()
 for phase in MATRIX_KINDS:
  pair=[]
  for kind in ('weight','bias'):
   name=f'bert.encoder.layer.0.{phase}.dense.{kind}';array=tensor_bytes(snapshot,name);tensor_sha=hashlib.sha256(array.tobytes()).hexdigest()
   if array.shape!=tensor_shape(phase,kind) or tensor_sha!=EXPECTED_TENSOR_SHA256[name] or not np.array_equal(array.astype(np.float64),state[name].numpy()):raise ValueError('native FFN tensor differs from frozen safetensors bytes')
   filename=f'{phase}_{kind}.npy';np.save(model/filename,array,allow_pickle=False);manifest['tensors'][filename]={'name':name,'shape':list(array.shape),'dtype':array.dtype.str,'file_sha256':sha(model/filename),'tensor_sha256':tensor_sha};pair.append(array.astype(np.float64))
  matrices[phase]=pair
 attention_hashes={}
 for name,value in state.items():
  if name.startswith('bert.encoder.layer.0.attention.'):
   original=tensor_bytes(snapshot,name)
   if not np.array_equal(original.astype(np.float64),value.numpy()):raise ValueError('native attention tensor differs from pinned bytes')
   attention_hashes[name]=hashlib.sha256(original.tobytes()).hexdigest()
 write(model/'model_manifest.json',manifest)
 preactivation=rows@matrices['intermediate'][0].T+matrices['intermediate'][1];contract=polynomial_contract();lo,hi=contract.domain
 violations=int(np.count_nonzero((preactivation<lo)|(preactivation>hi)|~np.isfinite(preactivation)))
 report={'scope':'Trusted native attention output is a component fixture only, not the embedding-only client boundary of a complete P2 submission. Fixed pair/rows selected before range checks; no residual or output LayerNorm in this FFN.', 'passed':False,'rows':[0,1],'shape':list(rows.shape),'full_attention_shape':list(attention.shape),'public_pair':list(EXAMPLE),'public_pair_sha256':digest(list(EXAMPLE)),'attention_rows_sha256':sha(private/'attention_rows.npy'),'tokenization_sha256':sha(private/'tokens.json'),'attention_module_tensor_sha256':attention_hashes,'model_manifest_sha256':sha(model/'model_manifest.json'),'asset_sha256':hashes,'model_revision':REVISION,'gelu_coefficient_sha256':GELU_COEFFICIENT_SHA256,'gelu_domain':list(contract.domain),'preactivation_range':[float(np.min(preactivation)),float(np.max(preactivation))],'gelu_domain_violations':violations,'versions':{n:importlib.metadata.version(n) for n in ('numpy','torch','transformers','tokenizers','safetensors')}}
 if violations:
  report['error']='Fixed GELU domain violated; domain is not widened';write(private/'preprocessing.json',report);print(json.dumps(report),flush=True);raise ValueError(report['error'])
 approx_gelu=contract.evaluate_public(preactivation);approx_ffn=approx_gelu@matrices['output'][0].T+matrices['output'][1]
 import math
 exact_gelu=.5*preactivation*(1+np.vectorize(math.erf)(preactivation/np.sqrt(2)));exact_ffn=exact_gelu@matrices['output'][0].T+matrices['output'][1]
 independent={'linear':float(np.max(np.abs(preactivation-native_linear))),'gelu':float(np.max(np.abs(exact_gelu-native_gelu))),'ffn':float(np.max(np.abs(exact_ffn-native_ffn)))}
 if max(independent.values())>1e-12:raise ValueError('independent native reference disagreement: '+str(independent))
 expected={'intermediate':pack_rows(preactivation,3072),'gelu':contract.evaluate_public(pack_rows(preactivation,3072)),'ffn':pack_rows(approx_ffn,768)}
 for kind,value in expected.items():np.save(private/f'expected_{kind}.npy',value,allow_pickle=False)
 np.save(private/'native_ffn.npy',native_ffn,allow_pickle=False)
 report.update(passed=True,private_reference_sha256={f'expected_{kind}.npy':sha(private/f'expected_{kind}.npy') for kind in KINDS}|{'native_ffn.npy':sha(private/'native_ffn.npy')},independent_native_max_abs_error=independent,gelu_approximation_max_abs_error=float(np.max(np.abs(approx_gelu-native_gelu))),ffn_approximation_max_abs_error=float(np.max(np.abs(approx_ffn-native_ffn))),ffn_approximation_nrmse=float(np.sqrt(np.mean((approx_ffn-native_ffn)**2))/max(np.sqrt(np.mean(native_ffn**2)),.01)),raw_gelu_padding_expected=float(contract.evaluate_public([0.])[0]),elapsed_s=time.perf_counter()-started)
 if report['gelu_approximation_max_abs_error']>1e-3:
  report['passed']=False;report['error']='fixed analytic GELU component target failed';write(private/'preprocessing.json',report);print(json.dumps(report),flush=True);raise ValueError(report['error'])
 write(private/'preprocessing.json',report)
 for file in private.iterdir():os.chmod(file,0o600)
 print(json.dumps(report,allow_nan=False))
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--snapshot',type=Path,required=True);p.add_argument('--private',type=Path,required=True);p.add_argument('--model',type=Path,required=True);a=p.parse_args();prepare(a.snapshot,a.private,a.model)
