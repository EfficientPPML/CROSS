"""Experimental compiled CKKS rotations with explicit public key operands.

Not yet used by SecureRefresh. This isolates compilation from rotation index so
one arithmetic executable can serve multiple keys at the same level. Controls
are lifted out of HLO literals, following Mapping's single-device compiler.
"""
from __future__ import annotations


class CompiledRotation:
    """Serial, single-device rotation executor; keeps at most one level bound."""

    def __init__(self, context):
        from encrypted_polynomial import EncryptedPolynomialEvaluator
        from encrypted_compilation import ExplicitArrayCompiler
        # Validate actual security and physically absent server secret keys.
        EncryptedPolynomialEvaluator(context)
        self.ctx = context
        self._binding = None
        self._compiler = ExplicitArrayCompiler()

    @property
    def compile_count(self):
        return self._compiler.compile_count

    def clear(self, *, executables=False):
        """Release active public arrays; optionally discard reusable code too."""
        self._binding = None
        if executables:
            self._compiler.clear_executables()

    def rotate(self, value, index):
        import jax
        from support import require_secure_execution

        require_secure_execution(self, value)
        if type(index) is not int:
            raise ValueError('rotation index must be an integer')
        cache = self.ctx._param_cache
        level = cache.level_for_num_q(value.num_moduli)
        expected_shape = (cache.batch, 2, *cache.degree_layout, value.num_moduli)
        if tuple(value.shape) != expected_shape:
            raise ValueError('ciphertext layout differs from the initialized rotation context')
        if len(value.polynomial.devices()) != 1:
            raise ValueError('compiled experimental rotation requires one physical device')
        device = next(iter(value.polynomial.devices()))
        operation = self.ctx.he_rot[level, index]
        state = operation._rotation_state()
        # Detach only the key/map references. The resulting arithmetic function
        # cannot accidentally capture a rotation key as a compilation constant.
        rotate = self.ctx.he_rot.take_explicit_rotation_fn((level, index))
        signature = (level, tuple(value.shape), str(value.polynomial.dtype), device)
        if self._binding is None or self._binding[0] != signature:
            binding = self._compiler.bind(rotate, (value.polynomial, *state),
                                          signature=signature, device=device)
            self._binding = (signature, binding)
        _, binding = self._binding
        result = value._clone_with_payload(binding(value.polynomial, *state))
        # Release transient formatted keys only after their execution finishes.
        # Raw supplied keys remain available for subsequent rotations.
        jax.block_until_ready(result.polynomial)
        cache._formatted_rotation_keys.pop(index, None)
        return result
