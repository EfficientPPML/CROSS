"""Exact regression checks for host-side CKKS plaintext preparation."""
import numpy as np
from absl.testing import absltest, parameterized

import ckks_ctx


class NativeEncodeResiduesTest(parameterized.TestCase):
  @parameterized.product(
      bound=[127, (1 << 61) - 1, (1 << 63) - 513],
      log_approx=[0, 5, 70],
      noise_scale_degree=[1, 2, 3],
  )
  def test_matches_scalar_fit_and_arbitrary_precision_scaling(
      self, bound, log_approx, noise_scale_degree,
  ):
    rng = np.random.default_rng(19)
    coefficients = [0, 1, bound // 2, bound // 2 + 1, bound - 1, bound]
    coefficients += rng.integers(0, bound, size=64).tolist()
    moduli = [17, 65537, 1073741857, 2147352577]
    scale = float(1 << 60)
    actual = ckks_ctx._native_encode_residues(
        coefficients, bound, moduli, log_approx, scale, noise_scale_degree,
    )
    multiplier = (1 << log_approx) * pow(int(round(scale)), noise_scale_degree - 1)
    expected = np.asarray([
        [(value * multiplier) % q for value in
         ckks_ctx.fit_to_native_vector(coefficients, bound, q, len(coefficients))]
        for q in moduli
    ], dtype=np.uint64).T
    np.testing.assert_array_equal(actual, expected)

  @parameterized.parameters(
      ([-1], 127, [17]),
      ([1 << 64], 127, [17]),
      ([1], 1 << 64, [17]),
      ([1], 127, [1 << 32]),
  )
  def test_preserves_scalar_fallback(self, coefficients, bound, moduli):
    self.assertIsNone(ckks_ctx._native_encode_residues(
        coefficients, bound, moduli, 0, 16.0, 1,
    ))

  def test_sparse_slot_encoding_preserves_ring_degree(self):
    coefficients, bound, moduli = [1, 2, 126, 125], 127, [17, 65537]
    actual = ckks_ctx._native_encode_residues(
        coefficients, bound, moduli, 0, 16.0, 1, ring_dim=32,
    )
    expected = np.asarray([
        ckks_ctx.fit_to_native_vector(coefficients, bound, q, 32)
        for q in moduli
    ], dtype=np.uint64).T
    np.testing.assert_array_equal(actual, expected)


class NativeInverseFFTTest(parameterized.TestCase):
  @parameterized.product(slots=[1, 8, 128, 4096, 16384], complex_input=[False, True])
  def test_is_bit_exact_with_scalar_butterflies(self, slots, complex_input):
    rng = np.random.default_rng(42)
    values = rng.normal(size=slots).astype(np.complex128)
    if complex_input:
      values += 1j * rng.normal(size=slots)
    original = [complex(value) for value in values]
    expected = original.copy()
    ckks_ctx.FFTSpecialInv(expected, slots * 4)
    actual = ckks_ctx._native_special_inverse_fft(original, slots * 4)
    np.testing.assert_array_equal(actual, expected)
    np.testing.assert_array_equal(original, values)


class SparsePrivateEncoderTest(parameterized.TestCase):
  @parameterized.product(slot_count=[1, 2, 4, 8, 16], complex_input=[False, True])
  def test_sparse_private_encoding_matches_full_periodic_encoding(
      self, slot_count, complex_input,
  ):
    # Independent full-slot encoding establishes the represented periodic
    # values and coefficient stride, rather than mirroring the sparse code.
    degree, moduli, scale = 32, [193, 257], float(1 << 20)
    rng = np.random.default_rng(103)
    values = rng.normal(size=slot_count).astype(np.complex128)
    if complex_input:
      values += 1j * rng.normal(size=slot_count)
    full = np.tile(values, degree // 2 // slot_count)
    actual = ckks_ctx._ckks_encode(values, 2 * degree, moduli, [], scale)
    expected = ckks_ctx._ckks_encode(full, 2 * degree, moduli, [], scale)
    np.testing.assert_array_equal(actual, expected)
    # The shared context must remain a full-slot encoder after sparse use.
    lite = ckks_ctx._get_or_make_encode_ctx(
        moduli, degree, scale, 61, (1 << 63) - 513)
    self.assertEqual(lite.num_slots, degree // 2)
    np.testing.assert_array_equal(
        ckks_ctx._fast_encode(full, lite, scale=scale, allow_complex=True),
        expected)
    if slot_count != degree // 2:
      with self.assertRaisesRegex(ValueError, 'expected exactly'):
        ckks_ctx._fast_encode(values, lite, scale=scale, allow_complex=True)

  @parameterized.parameters(0, 3, 17, 32)
  def test_invalid_private_sparse_counts_rejected(self, count):
    with self.assertRaisesRegex(ValueError, 'power-of-two divisor'):
      ckks_ctx._ckks_encode([1.] * count, 64, [193, 257], [], float(1 << 20))

  def test_full_slot_wrapper_stays_bit_exact_with_scalar_encoder(self):
    values = [complex(i / 32, (i % 3) / 32) for i in range(16)]
    args = (values, 64, [193, 257], [], float(1 << 20))
    np.testing.assert_array_equal(ckks_ctx._ckks_encode(*args),
                                 ckks_ctx._ckks_encode_fall_back(*args))


if __name__ == '__main__':
  absltest.main()
