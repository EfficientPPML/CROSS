"""Source-bound public response-scale proof; no model, context or HE."""
from pathlib import Path
import argparse,hashlib,io,json,os,subprocess,sys,tarfile,time
HERE=Path(__file__).resolve().parent
COMMON=Path('/tmp/bert-pooler-head-owner-20261103/checkout/cadathlon/common')

def raw_sources():
    files={n:HERE/n for n in ('response_scale.py','test_response_scale.py','collect_response_scale.py','server_inputs/p60_profile_and_refresh.json','server_inputs/candidate_manifest.json')}
    for n in ('encrypted_integer_affine.py','encrypted_scale_planning.py','encrypted_bert_rational_tanh.py','encrypted_bert_pooler_head.py','encrypted_polynomial.py','encrypted_primitives.py'):
        files['common/'+n]=COMMON/n
    return {n:p.read_bytes() for n,p in files.items()}
def hashes(raw):return {n:hashlib.sha256(b).hexdigest() for n,b in raw.items()}
def write(p,r):p.write_text(json.dumps(r,indent=2,allow_nan=False)+'\n')
def archive(p,raw):
    with tarfile.open(p,'w:gz') as t:
        for n,b in raw.items():m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
def check(p,expected):
    with tarfile.open(p) as t:
        members=t.getmembers();return len(members)==len(expected)==len({m.name for m in members}) and all(m.isfile() for m in members) and {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in members}==expected

def run(output):
    output.mkdir(exist_ok=False);start=time.monotonic();primary=None;before={};report=dict(passed=False,scope='Public binary64 metadata enclosure only; no model, key generation or encrypted execution.')
    try:
        write(output/'report.json',report);raw=raw_sources();before=hashes(raw);archive(output/'sources.tar.gz',raw)
        if not check(output/'sources.tar.gz',before):raise ValueError('source archive differs')
        import response_scale
        report['certificate']=response_scale.scale_certificate(profile_bytes=raw['server_inputs/p60_profile_and_refresh.json'],manifest_bytes=raw['server_inputs/candidate_manifest.json'])
        with (output/'tests.log').open('wb') as log:
            result=subprocess.run([sys.executable,'-m','pytest','-q',str(HERE/'test_response_scale.py'),'--junitxml='+str(output/'tests.xml')],cwd=HERE,stdout=log,stderr=subprocess.STDOUT,check=False)
        if result.returncode:raise ValueError('scale tests failed')
        import xml.etree.ElementTree as ET
        report['tests']={k:sum(int(x.attrib.get(k,0)) for x in ET.parse(output/'tests.xml').getroot()) for k in ('tests','failures','errors','skipped')}
        report['passed']=not any(report['tests'][k] for k in ('failures','errors','skipped'))
    except BaseException as e:primary=e;report.update(passed=False,error=dict(type=type(e).__name__,message=str(e)))
    finally:
        try:
            after=hashes(raw_sources());verified=bool(before) and check(output/'sources.tar.gz',before)
            report.update(source_hashes_before=before,source_hashes_after=after,source_archive_verified=verified,
                source_archive_sha256=hashlib.sha256((output/'sources.tar.gz').read_bytes()).hexdigest() if before else None,
                source_files_unchanged=before==after,elapsed_s=time.monotonic()-start,cpu_affinity=sorted(os.sched_getaffinity(0)))
            report['passed']=bool(report['passed'] and verified and before==after);write(output/'report.json',report)
        except BaseException as e:
            if primary is None:raise
            primary.add_note('terminal source/publication: '+repr(e))
        if primary is not None:raise primary
    print(json.dumps({k:report[k] for k in ('passed','tests','elapsed_s','source_archive_sha256')}));return 0 if report['passed'] else 1
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();raise SystemExit(run(a.output))
