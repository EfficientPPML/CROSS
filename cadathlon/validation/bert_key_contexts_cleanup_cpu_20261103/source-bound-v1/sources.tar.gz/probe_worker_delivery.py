"""Public-only counterexample: pthread_sigmask is not process-wide shielding."""
import json,signal,threading
SIG=signal.SIGTERM
start=threading.Event();done=threading.Event();observations=[]
old=signal.getsignal(SIG);main_id=threading.get_ident()
def handler(signum,frame):
    observations.append(dict(handler_on_main=threading.get_ident()==main_id,
        main_thread_mask_contains_signal=SIG in signal.pthread_sigmask(signal.SIG_BLOCK,[])))
def worker():
    start.wait()
    # Delivery to this unblocked thread models the kernel's permissible choice
    #for a process-directed signal in a NumPy/JAX multi-threaded process.
    signal.pthread_kill(threading.get_ident(),SIG)
    done.set()
signal.signal(SIG,handler)
thread=threading.Thread(target=worker);thread.start()
mask=signal.pthread_sigmask(signal.SIG_BLOCK,[SIG])
try:
    start.set();done.wait();thread.join()
    assert observations==[dict(handler_on_main=True,main_thread_mask_contains_signal=True)]
    print(json.dumps(dict(counterexample_confirmed=True,observations=observations,
        scope='No loader/model/keys/HE. A main-thread-only mask does not defer Python signal handling delivered to an unblocked worker.')))
finally:
    signal.signal(SIG,old);signal.pthread_sigmask(signal.SIG_SETMASK,mask)
