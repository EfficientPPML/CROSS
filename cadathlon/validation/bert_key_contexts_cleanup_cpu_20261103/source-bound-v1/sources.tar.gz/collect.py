"""Source-bound public/mock cleanup evidence, preserving broader counterexample."""
from pathlib import Path
import hashlib,io,json,os,signal,shutil,subprocess,sys,tarfile,tempfile,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'candidate'))
from cleanup import termination_signals,cleanup_signals
TESTS=('test_client_keys.py','test_key_contexts.py','test_response_scale.py','test_key_contexts_signals.py','test_wrapper_signals.py')

def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,r):
    tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(r,indent=2,allow_nan=False)+'\n');tmp.replace(p)
def paths():
    result={str(p.relative_to(HERE)):p for branch in ('before','candidate','prerequisites','runtime') for p in (HERE/branch).rglob('*') if p.is_file() and p.suffix in ('.py','.json')}
    for n in ('collect.py','origins.json','probe_worker_delivery.py','development-v1-test.py'):result[n]=HERE/n
    base=Path('/tmp/bert-pooler-head-owner-20261103/checkout/cadathlon/common')
    for n in ('encrypted_integer_affine.py','encrypted_scale_planning.py','encrypted_bert_rational_tanh.py'):result['external/common/'+n]=base/n
    base=Path('/tmp/bert-twelve-layer-continuation-plan-20261103')
    for n in ('p60_profile_and_refresh.json','report.json'):result['external/public/'+n]=base/n
    return result
def hashes(p):return {n:sha(v) for n,v in p.items()}
def archive(p,files):
    with tarfile.open(p,'w:gz') as t:
        for name,f in files.items():
            b=f.read_bytes();m=tarfile.TarInfo(name);m.size=len(b);t.addfile(m,io.BytesIO(b))
def verify(p,expected):
    with tarfile.open(p) as t:
        ms=t.getmembers()
        assert len(ms)==len(expected)==len({m.name for m in ms}) and all(m.isfile() for m in ms)
        assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in ms}==expected
    return True

def run():
    out=HERE/'source-bound-v1';out.mkdir();report=dict(passed=False,scope='Public constants and mocked key/context lifecycle only; no actual keygen, CKKS context, ciphertext or model.',
        threaded_process_signal_atomicity_established=False,original_process_stress_failure_preserved=True,
        primary_identity_outside_entered_guard_guaranteed=False,cpu_affinity=sorted(os.sched_getaffinity(0)))
    child=None;primary=None;cancel=None;errors=[];files={};before={};work=None;fd=None;identity=None;start=time.monotonic()
    def attempt(name,fn):
        nonlocal cancel
        try:return fn()
        except BaseException as e:
            errors.append(dict(operation=name,type=type(e).__name__))
            if primary is not None:primary.add_note(name+': '+repr(e))
            elif not isinstance(e,Exception) and cancel is None:cancel=e
    def stop():
        if child is None:return
        if child.poll() is None:
            os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=20)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
        else:child.wait()
    try:
        write(out/'report.json',report)
        with termination_signals():
            files=paths();before=hashes(files);archive(out/'sources.tar.gz',files);verify(out/'sources.tar.gz',before)
            report.update(source_hashes_before=before,source_archive_sha256=sha(out/'sources.tar.gz'))
            work=Path(tempfile.mkdtemp(prefix='key-contexts-cleanup-tests-'));fd=os.open(work,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
            s=os.fstat(fd);identity=(s.st_dev,s.st_ino)
            command=[sys.executable,'-m','pytest','-q',*[str(HERE/'candidate'/n) for n in TESTS],
                '--tb=short','--basetemp='+str(work/'pytest'),'--junitxml='+str(out/'tests.xml')]
            report['command']=command
            with (out/'tests.log').open('wb') as log:
                child=subprocess.Popen(command,cwd=HERE/'candidate',stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                report['child_pid']=child.pid;write(out/'report.json',report);report['returncode']=child.wait()
            import xml.etree.ElementTree as ET
            report['tests']={n:sum(int(x.attrib.get(n,0)) for x in ET.parse(out/'tests.xml').getroot()) for n in ('tests','errors','failures','skipped')}
            report['passed']=report['returncode']==0 and report['tests']==dict(tests=123,errors=0,failures=0,skipped=0)
    except BaseException as e:primary=e;report.update(passed=False,error=dict(type=type(e).__name__,message=str(e)))
    finally:
        with cleanup_signals():
            attempt('reap child',stop)
            def remove():
                s=work.lstat();held=os.fstat(fd)
                if (s.st_dev,s.st_ino)!=identity or (held.st_dev,held.st_ino)!=identity:raise RuntimeError('owned test directory replacement retained')
                shutil.rmtree(work)
            if fd is not None:
                attempt('owned test files removal',remove);attempt('owned directory close',lambda:os.close(fd))
            after=attempt('source readback',lambda:hashes(files))
            verified=attempt('archive readback',lambda:verify(out/'sources.tar.gz',before)) if before else False
            report.update(source_hashes_after=after,source_files_unchanged=bool(before) and after==before,
                source_archive_verified=verified is True,cleanup_errors=errors,child_reaped=child is None or child.poll() is not None,
                owned_test_directory_removed=work is None or not work.exists(),elapsed_s=time.monotonic()-start)
            report['passed']=bool(report['passed'] and report['source_files_unchanged'] and verified and not errors)
            attempt('final publication',lambda:write(out/'report.json',report))
    if primary is not None:raise primary
    if cancel is not None:raise cancel
    return 0 if report['passed'] and not errors else 1
if __name__=='__main__':raise SystemExit(run())
