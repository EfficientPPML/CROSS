"""Fresh-process actual wrapper+loader cancellation; mocked crypto only."""
from pathlib import Path
import argparse,json,os,signal,sys,threading
import pytest
import key_contexts as loaders
from cleanup import termination_signals
from test_client_keys import mocked
from test_key_contexts import case,client

def run(phase,output,workspace):
    patch=pytest.MonkeyPatch();m=mocked.__wrapped__(workspace,patch)
    generator=case.__wrapped__(m,patch);c=next(generator)
    real=signal.signal;old={s:signal.getsignal(s) for s in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP)}
    oldmask=signal.pthread_sigmask(signal.SIG_BLOCK,[])
    events=[];armed=[];injected=[];outer={};handle=secret=ctx=None;error=None
    original_close=loaders._ReadDirectory.close
    def close(owner):
        original_close(owner);events.append('directory-close')
    patch.setattr(loaders._ReadDirectory,'close',close)
    def setter(sig,handler):
        result=real(sig,handler)
        selected=phase=='install' and sig==signal.SIGINT and handler is not outer.get(sig)
        selected|=phase=='restore' and sig==signal.SIGHUP and handler is outer.get(sig)
        if armed and selected and not injected:
            injected.append(True)
            os.kill(os.getpid(),signal.SIGTERM if phase=='install' else signal.SIGHUP)
        return result
    patch.setattr(signal,'signal',setter)
    done=threading.Event();thread=threading.Thread(target=done.wait);thread.start()
    try:
        with termination_signals():
            outer.update({s:signal.getsignal(s) for s in old})
            with client(c) as handle:
                ctx=handle.ctx;secret=ctx.secret_key;armed.append(True)
                if phase=='body':
                    injected.append(True);os.kill(os.getpid(),signal.SIGTERM)
    except BaseException as caught:error=type(caught).__name__
    finally:
        done.set();thread.join()
        record=dict(phase=phase,error_type=error,all_cleanup_attempted=bool(handle is not None and handle.ctx is None and not vars(ctx)
            and secret._mmap.closed and events==['directory-close','directory-close'] and not loaders._ACTIVE.locked()),
            aliases_restored=all(getattr(module,n)is c.original for module in c.modules.values() for n in loaders.KEYGEN_METHODS),
            handlers_restored={s:signal.getsignal(s) for s in old}==old,
            thread_mask_restored=signal.pthread_sigmask(signal.SIG_BLOCK,[])==oldmask,
            signal_injected=bool(injected),mocked_crypto_only=True)
        try:next(generator)
        except StopIteration:pass
        patch.undo()
        output.write_text(json.dumps(record,sort_keys=True)+'\n')
    return 1 if error is not None else 0

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('phase',choices=('install','body','restore'));p.add_argument('output',type=Path);p.add_argument('workspace',type=Path)
    a=p.parse_args();raise SystemExit(run(a.phase,a.output,a.workspace))
