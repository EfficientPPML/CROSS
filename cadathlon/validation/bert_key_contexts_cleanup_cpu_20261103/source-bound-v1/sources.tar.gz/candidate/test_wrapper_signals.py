"""Actual loader under the single-fire wrapper; sampled process-signal stress.

No guarantee is inferred for arbitrary delivery time or exception identity
outside an entered guard. Original unwrapped stress failures remain evidence.
"""
from pathlib import Path
import json,subprocess,sys
import pytest

@pytest.mark.parametrize('repeat',range(3))
@pytest.mark.parametrize('phase',('install','body','restore'))
def test_process_signal_loader_wrapper_cleanup_fail_closed(tmp_path,phase,repeat):
    root=Path(__file__).resolve().parent;workspace=tmp_path/'fixture';workspace.mkdir();report=tmp_path/'report.json'
    child=subprocess.run([sys.executable,str(root/'loader_wrapper_probe.py'),phase,str(report),str(workspace)],
        stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20)
    assert child.returncode==1,(phase,repeat,child.returncode,child.stderr.decode())
    result=json.loads(report.read_bytes())
    assert result['phase']==phase and result['error_type'] is not None
    assert all(result[n]is True for n in ('all_cleanup_attempted','aliases_restored','handlers_restored','thread_mask_restored','signal_injected','mocked_crypto_only'))
