"""Actual process-local pending signals and post-mutation fault injection."""
import os,signal
import pytest
import key_contexts as loaders
from test_client_keys import mocked
from test_key_contexts import case,client,assert_restored
SIGS=(signal.SIGINT,signal.SIGTERM,signal.SIGHUP)

@pytest.fixture
def signal_state():
    real=signal.signal;old={s:signal.getsignal(s) for s in SIGS}
    real_mask=signal.pthread_sigmask;mask=real_mask(signal.SIG_BLOCK,[])
    def original(signum,frame):raise KeyboardInterrupt('original handler invoked')
    for s in SIGS:real(s,original)
    try:yield real,original,mask
    finally:
        # Tests deliver only their own signals; drain any delayed cancellation
        #before restoring the runner's prior handlers and mask.
        for s in SIGS:real(s,lambda *_:None)
        real_mask(signal.SIG_UNBLOCK,SIGS)
        for s,h in old.items():real(s,h)
        real_mask(signal.SIG_SETMASK,mask)

@pytest.mark.parametrize('kind',('real_pending','post_mutation_setter'))
def test_installation_tracks_mutation_and_defers_uninstalled_signal(case,signal_state,monkeypatch,kind):
    real,original,mask=signal_state;injected=[]
    def setter(sig,handler):
        result=real(sig,handler)
        if sig==signal.SIGINT and handler is not original and not injected:
            injected.append(True)
            if kind=='real_pending':os.kill(os.getpid(),signal.SIGTERM)
            else:raise OSError('setter mutated first handler then failed')
        return result
    monkeypatch.setattr(signal,'signal',setter)
    with pytest.raises(KeyboardInterrupt if kind=='real_pending' else OSError):
        with client(case) as h:secret=h.ctx.secret_key
    assert injected==[True]
    assert all(signal.getsignal(s)is original for s in SIGS)
    assert signal.pthread_sigmask(signal.SIG_BLOCK,[])==mask
    assert h.ctx is None and secret._mmap.closed
    assert_restored(case)

@pytest.mark.parametrize('body_primary',(False,True))
def test_pending_restoration_signal_preserves_primary_and_mask(case,signal_state,monkeypatch,body_primary):
    real,original,mask=signal_state;sent=[];primary=ValueError('body primary')
    def setter(sig,handler):
        result=real(sig,handler)
        if sig==signal.SIGHUP and handler is original and not sent:
            sent.append(True);os.kill(os.getpid(),signal.SIGHUP)
        return result
    monkeypatch.setattr(signal,'signal',setter)
    with pytest.raises(ValueError if body_primary else KeyboardInterrupt) as caught:
        with client(case) as h:
            secret=h.ctx.secret_key
            if body_primary:raise primary
    if body_primary:assert caught.value is primary and any('original handler' in n for n in primary.__notes__)
    assert sent and all(signal.getsignal(s)is original for s in SIGS)
    assert signal.pthread_sigmask(signal.SIG_BLOCK,[])==mask
    assert h.ctx is None and secret._mmap.closed;assert_restored(case)

@pytest.mark.parametrize('sig',SIGS)
def test_actual_repeated_signal_during_cleanup_does_not_interrupt_unmapping(case,signal_state,sig):
    real,original,mask=signal_state;events=[]
    def clear():
        events.append('before');os.kill(os.getpid(),sig);os.kill(os.getpid(),sig);events.append('after')
    case.runtime.jax.clear_caches=clear
    with pytest.raises(KeyboardInterrupt,match='signals deferred'):
        with client(case) as h:secret=h.ctx.secret_key
    assert events==['before','after'] and secret._mmap.closed and h.ctx is None
    assert all(signal.getsignal(s)is original for s in SIGS)
    assert signal.pthread_sigmask(signal.SIG_BLOCK,[])==mask;assert_restored(case)

@pytest.mark.parametrize('body_primary',(False,True))
def test_final_unblock_cancellation_has_priority_over_cleanup_error(case,signal_state,monkeypatch,body_primary):
    real,original,mask=signal_state;original_mask=signal.pthread_sigmask;unblocks=[];primary=ValueError('body primary')
    case.runtime.jax.clear_caches=lambda:(_ for _ in ()).throw(OSError('ordinary cleanup failure'))
    def masking(how,values):
        result=original_mask(how,values)
        if how==signal.SIG_SETMASK:
            unblocks.append(True)
            if len(unblocks)==2:raise SystemExit('final unblock cancellation')
        return result
    monkeypatch.setattr(signal,'pthread_sigmask',masking)
    with pytest.raises(ValueError if body_primary else SystemExit) as caught:
        with client(case) as h:
            secret=h.ctx.secret_key
            if body_primary:raise primary
    if body_primary:assert caught.value is primary
    else:assert any('ordinary cleanup failure' in n for n in caught.value.__notes__)
    assert len(unblocks)==2 and secret._mmap.closed and h.ctx is None
    assert all(signal.getsignal(s)is original for s in SIGS)
    assert original_mask(signal.SIG_BLOCK,[])==mask;assert_restored(case)

def test_failed_block_attempt_does_not_abandon_cleanup(case,signal_state,monkeypatch):
    real,original,mask=signal_state;called=[]
    def blocking(*a):called.append(True);raise OSError('cannot install signal block')
    monkeypatch.setattr(signal,'pthread_sigmask',blocking)
    with pytest.raises(OSError,match='signal block'):
        with client(case) as h:secret=h.ctx.secret_key
    assert called and secret._mmap.closed and h.ctx is None
    assert all(signal.getsignal(s)is original for s in SIGS);assert_restored(case)
