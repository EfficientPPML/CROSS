from pathlib import Path
import ast,math,random,sys
from fractions import Fraction
import pytest
import response_scale as scales
HERE=Path(__file__).resolve().parent
PROFILE=(HERE/'server_inputs/p60_profile_and_refresh.json').read_bytes()
MANIFEST=(HERE/'server_inputs/candidate_manifest.json').read_bytes()
COMMON=Path('/tmp/bert-pooler-head-owner-20261103/checkout/cadathlon/common')


def certificate():return scales.scale_certificate(profile_bytes=PROFILE,manifest_bytes=MANIFEST)

def source_functions(path,names,namespace):
    tree=ast.parse(path.read_bytes());body=[x for x in tree.body if isinstance(x,(ast.FunctionDef,ast.ClassDef)) and x.name in names]
    assert {x.name for x in body}==set(names)
    exec(compile(ast.Module(body=body,type_ignores=[]),str(path),'exec'),namespace);return namespace


def test_exact_fraction_endpoints_and_three_scale_set():
    c=certificate();delta=c['canonical_scale'];T=c['target_before_rescale'];u=Fraction(1,2**53)
    lo=Fraction.from_float(T)*(1-u)**2;hi=Fraction.from_float(T)*(1+u)**2
    products=c['product_candidates'];assert len(products)==3
    assert Fraction.from_float(math.nextafter(products[0],-math.inf))<lo<=Fraction.from_float(products[0])
    assert Fraction.from_float(products[-1])<=hi<Fraction.from_float(math.nextafter(products[-1],math.inf))
    assert c['accepted_scales']==(math.nextafter(math.nextafter(delta,-math.inf),-math.inf),delta,math.nextafter(delta,math.inf))
    assert c['accepted_scales']==tuple(sorted(set(p/c['divisor'] for p in products)))
    for s in c['accepted_scales']:assert scales.accepts_scale(s,profile_bytes=PROFILE,manifest_bytes=MANIFEST)

@pytest.mark.parametrize('bad',(True,1,0.,-1.,float('nan'),float('inf'),complex(1,0),'1',None))
def test_bad_scale_rejected(bad):assert not scales.accepts_scale(bad,profile_bytes=PROFILE,manifest_bytes=MANIFEST)

def test_wrong_artifacts_and_neighbour_rejected():
    c=certificate();s=c['canonical_scale']
    assert not scales.accepts_scale(s,profile_bytes=PROFILE+b' ',manifest_bytes=MANIFEST)
    assert not scales.accepts_scale(s,profile_bytes=PROFILE,manifest_bytes=MANIFEST+b' ')
    assert not scales.accepts_scale(math.nextafter(min(c['accepted_scales']),-math.inf),profile_bytes=PROFILE,manifest_bytes=MANIFEST)
    assert not scales.accepts_scale(math.nextafter(max(c['accepted_scales']),math.inf),profile_bytes=PROFILE,manifest_bytes=MANIFEST)


def test_production_affine_recurrence_at_extreme_and_random_source_scales():
    ns=source_functions(COMMON/'encrypted_scale_planning.py',('positive_scale','affine_scale'),dict(math=math))
    c=certificate();rng=random.Random(901733);sources=[sys.float_info.min,sys.float_info.max,math.ulp(0.),c['canonical_scale']]
    sources += [math.ldexp(rng.uniform(1.,1.99999999999999),rng.randrange(-1022,1024)) for _ in range(2048)]
    accepted=rejected=0
    for s in sources:
        try:actual=ns['affine_scale'](s,c['canonical_scale'],c['divisor'])['output_scale']
        except (ValueError,OverflowError):rejected+=1;continue
        accepted+=1;assert actual in c['accepted_scales']
    assert accepted>1000 and rejected>0


def test_actual_static_newton_tanh_replay_for_adjacent_refresh_scales():
    # Execute the actual frozen public plan bodies, not a rewritten recurrence.
    import dataclasses,hashlib,json,numpy as np
    from decimal import Decimal,localcontext
    ns=dict(math=math,np=np,Decimal=Decimal,localcontext=localcontext,dataclass=dataclasses.dataclass,field=dataclasses.field,
            hashlib=hashlib,json=json,MANIFEST_SHA256=scales.MANIFEST_SHA256,
            COEFFICIENT_SHA256='a107f176bf28ea6e8f80af0613687c02ed6478078395b67d94b5e04b077204a7',typed=lambda x:(type(x),repr(x)))
    source_functions(COMMON/'encrypted_integer_affine.py',('_positive_scale','backward_scale_plan'),ns)
    source_functions(COMMON/'encrypted_scale_planning.py',('positive_scale','drop_divisor','affine_scale','weighted_sum_scale','multiply_scale','static_newton_forward'),ns)
    source_functions(COMMON/'encrypted_bert_rational_tanh.py',('BertTanhContract','contract_state','tanh_scale_plan'),ns)
    q=json.loads(PROFILE)['profile']['q'];c=certificate();delta=c['canonical_scale'];contract=ns['BertTanhContract'](MANIFEST)
    for s in (math.nextafter(delta,-math.inf),delta,math.nextafter(delta,math.inf)):
        pooled=ns['affine_scale'](s,delta,ns['drop_divisor'](q,12))['output_scale']
        plan=ns['tanh_scale_plan'](q,input_level=11,input_scale=pooled,canonical_scale=delta,contract=contract,
                                  refresh_scales={1:s,3:s,5:s})
        assert plan['output_level']==3 and len(plan['rounds'])==6 and [x['round'] for x in plan['refresh_events']]==[1,3,5]
        final=ns['affine_scale'](plan['output_scale'],delta,c['divisor'])['output_scale']
        assert scales.accepts_scale(final,profile_bytes=PROFILE,manifest_bytes=MANIFEST)
