"""Public source and synthetic lifecycle tests; never a full graph or asset run."""
from pathlib import Path
from types import SimpleNamespace as NS
from contextlib import contextmanager
import copy,io,json,math,sys,tarfile
import pytest
import collect_bsgs_full as c

def case(K):
    T=(K+15)//16
    def domain(independent=False):
        d=dict(label='synthetic fixed domain',domain=[-1.,1.],count=1,minimum=0.,maximum=0.)
        d.update(dict(below=0,above=0,nonfinite=0)if independent else dict(passed=True));return d
    return dict(passed=True,K=K,all_connections_are_actual_output_objects=True,native_prediction_agrees=True,ideal_gate=1e-7,output_level=2,
        native_logit_gate='abs(error)<=0.02+0.01*abs(native)',physical_stage_slots_checked=(24*T+2)*65536,
        stage_errors=[dict(layer=l,phase=p,physical_slots=T*65536,max_abs=1e-12)for l in range(12)for p in ('attention','block')],
        pooler_all_slot_max_abs=1e-12,logits_all_slot_max_abs=1e-12,native_logit_max_abs=1e-4,
        primitive_counts=dict(c.EXPECTED_COUNTS[K]),identity_refresh_calls=c.EXPECTED_REFRESH[K],
        public_operation_plan=dict(counts=dict(c.EXPECTED_COUNTS[K]),identity_refreshes=c.EXPECTED_REFRESH[K]),
        actual_domain_observations=[domain()for _ in range(c.EXPECTED_DOMAINS[K])],independent_domain_observations=[domain(True)for _ in range(156)],
        actual_metadata=dict(explicit_direct_ciphertext_connections=True,output_level=2,original_positions=list(range(K))))

@pytest.mark.parametrize('K',(15,128))
def test_fixed_case_summary(K):
    r=c.verify_case(case(K),K);assert r['actual_domains']==c.EXPECTED_DOMAINS[K]

@pytest.mark.parametrize('field',('missing_stage','failed_stage','nan','bad_count','bad_refresh','domain_stop','missing_domain','independent_stop','wrong_positions','wrong_K','prediction','head','gate','boolean_count'))
def test_case_failures_rejected(field):
    r=case(15)
    if field=='missing_stage':r['stage_errors'].pop()
    elif field=='failed_stage':r['stage_errors'][0]['max_abs']=1e-6
    elif field=='nan':r['stage_errors'][0]['max_abs']=float('nan')
    elif field=='bad_count':r['primitive_counts']['rotate']+=1
    elif field=='bad_refresh':r['identity_refresh_calls']+=1
    elif field=='domain_stop':r['actual_domain_observations'][0]['minimum']=-2.
    elif field=='missing_domain':r['actual_domain_observations'].pop()
    elif field=='independent_stop':r['independent_domain_observations'][0]['nonfinite']=1
    elif field=='wrong_positions':r['actual_metadata']['original_positions'][0]=1
    elif field=='wrong_K':r['K']=True
    elif field=='prediction':r['native_prediction_agrees']=False
    elif field=='head':r['logits_all_slot_max_abs']=1e-6
    elif field=='gate':r['ideal_gate']=1e-6
    else:r['primitive_counts']['multiply']=True
    with pytest.raises(ValueError):c.verify_case(r,15)

@pytest.mark.parametrize('name',('encrypted_bert_full_model.py','encrypted_bert_layer_attention.py','test_full_model_owner.py','ideal_primitives.py','encrypted_bsgs_score_routing.py','candidate_manifest.json','full_model_reference.py','collector_overlay_manifest.json','baseline_source_manifest.json'))
def test_source_substitution_precedes_external_reports_and_assets(name,monkeypatch):
    data=c.source_bytes();data[name]+=b'\n'
    monkeypatch.setattr(c,'predecessor',lambda *a,**kw:(_ for _ in ()).throw(AssertionError('external report accessed')))
    with pytest.raises(ValueError):c.prerequisite_gate(data)

def test_actual_public_predecessor_and_overlay_identity():
    m=c.prerequisite_gate(c.source_bytes());assert len(m['overlays'])==4 and len(m['new_runtime'])==2

@pytest.mark.parametrize('kind',('duplicate','nonregular','wrongbytes'))
def test_archive_readback_rejects_invalid_inventory(tmp_path,kind):
    p=tmp_path/'sources.tar.gz'
    with tarfile.open(p,'w:gz')as t:
        for _ in range(2 if kind=='duplicate'else 1):
            m=tarfile.TarInfo('x');m.size=1
            if kind=='nonregular':m.type=tarfile.SYMTYPE;m.linkname='foreign';m.size=0;t.addfile(m)
            else:t.addfile(m,io.BytesIO(b'x'))
    with pytest.raises(ValueError):c.archive_readback(p,{'x':c.digest(b'y'if kind=='wrongbytes'else b'x')})

def test_output_subtree_excluded_from_fixed_source_inventory(tmp_path):
    before=c.hashes(c.source_bytes());assert 'collect_bsgs_full.py'in before and 'source_inventory.json'in before
    names=json.loads((c.HERE/'source_inventory.json').read_bytes());assert not any(n.startswith(('development','source-bound','snapshot'))for n in names)

def test_failed_first_case_does_not_lose_second_evidence(tmp_path):
    source=tmp_path/'source';out=tmp_path/'out';source.mkdir();out.mkdir()
    bad=case(15);bad['passed']=False
    c.write(source/'joined-K15.json',bad);c.write(source/'joined-K128.json',case(128));report={}
    with pytest.raises(ValueError):c.read_cases(source,out,report)
    assert all((out/f'joined-K{K}.json').is_file()for K in (15,128))
    assert report['cases'][0]['K']==128

@pytest.fixture
def fake(tmp_path,monkeypatch):
    raw={'source_inventory.json':b'["source_inventory.json"]'};m={'assets':{'public_checkpoint':{'path':'public','sha256':'a'*64},'private_original_native_fixture':{'path':'private','sha256':'b'*64}}};fault={};events=[]
    monkeypatch.setattr(c,'source_bytes',lambda root=c.HERE:dict(raw))
    monkeypatch.setattr(c,'prerequisite_gate',lambda data:m)
    monkeypatch.setattr(c,'asset_hashes',lambda data:{n:r['sha256']for n,r in m['assets'].items()})
    class Child:
        def __init__(self,command,*,cwd,stdout,env):
            events.append('spawn');self.cwd=Path(cwd);self.record=dict(pid=123,direct_child_reaped=False,group_empty_verified=False,cleanup_completed=False)
            assert env['BERT_FULL_NATIVE_FIXTURE']=='private'
            assert 'not test_collector_'in command
        def wait(self):
            events.append('wait')
            if 'wait'in fault:raise fault['wait']
            self.record.update(direct_child_reaped=True,group_empty_verified=True,cleanup_completed=True)
            if fault.get('group'):self.record['group_empty_verified']=False
            for K in (15,128):
                if fault.get('missing')==K:continue
                c.write(self.cwd/f'joined-K{K}.json',case(K))
            n=c.ORIGINAL_TESTS+c.FIXTURE_METADATA_TESTS+c.COLLECTOR_TESTS+(1 if fault.get('count')else 0)
            (self.cwd.parent/'tests.xml').write_text(f'<testsuites><testsuite tests="{n}" errors="0" failures="0" skipped="0"/></testsuites>')
            return 0
        def close(self,primary=None):
            events.append('close')
            if 'close'in fault:raise fault['close']
            if fault.get('group'):raise RuntimeError('owned group remains')
            self.record.update(direct_child_reaped=True,group_empty_verified=True,cleanup_completed=True)
    monkeypatch.setattr(c,'OwnedChild',Child)
    return NS(output=tmp_path/'output',fault=fault,events=events,raw=raw)

def test_success_requires_both_cases_and_terminal(fake):
    r=c.finish(fake.output/'report.json',lambda:c.run(fake.output),c.write,c.public_io.public_report)
    assert r['passed']and r['complete']and r['terminal_scope_completed']and r['termination_scope_completed']
    assert r['all_direct_children_reaped']and r['all_owned_groups_empty']and fake.events==['spawn','wait','close']
    assert (r['original_tests_selected'],r['new_fixture_metadata_tests_expected'],r['new_collector_tests_expected'])==(33,2,47)
    assert r['tests']==dict(tests=82,errors=0,failures=0,skipped=0)

@pytest.mark.parametrize('kind',('missing','count','group','wait'))
def test_incomplete_execution_fails_and_retains(fake,kind):
    fake.fault[kind]=128 if kind=='missing'else KeyboardInterrupt('cancel')if kind=='wait'else True
    with pytest.raises(BaseException):c.run(fake.output)
    r=json.loads((fake.output/'report.json').read_bytes());assert r['passed']is False and fake.events[-1]=='close'
    assert (fake.output/'sources.tar.gz').is_file()

@pytest.mark.parametrize('kind',(KeyboardInterrupt,SystemExit,ValueError))
def test_true_body_primary_survives_cleanup_errors(fake,kind):
    primary=kind('body');fake.fault.update(wait=primary,close=OSError('cleanup'))
    with pytest.raises(kind)as seen:c.run(fake.output)
    assert seen.value is primary and any('retirement'in n for n in primary.__notes__)

def test_cleanup_cancellation_supersedes_ordinary_cleanup(fake,monkeypatch):
    first=OSError('close');cancel=KeyboardInterrupt('later source');fake.fault['close']=first;counter=0
    def sources(root=c.HERE):
        nonlocal counter
        counter+=1
        if counter==3:raise cancel
        return dict(fake.raw)
    monkeypatch.setattr(c,'source_bytes',sources)
    with pytest.raises(KeyboardInterrupt)as seen:c.run(fake.output)
    assert seen.value is cancel

def test_snapshot_creation_failure_preserves_failed_report(fake,monkeypatch):
    mkdir=Path.mkdir
    def fail(p,*a,**kw):
        if p.name=='snapshot':raise OSError('snapshot failure')
        return mkdir(p,*a,**kw)
    monkeypatch.setattr(Path,'mkdir',fail)
    with pytest.raises(OSError):c.run(fake.output)
    r=json.loads((fake.output/'report.json').read_bytes());assert not r['passed']and fake.events==[]

def test_outer_restoration_failure_republishes_failure(fake):
    @contextmanager
    def broken():
        yield
        raise KeyboardInterrupt('restore')
    with pytest.raises(KeyboardInterrupt):c.finish(fake.output/'report.json',lambda:c.run(fake.output),c.write,c.public_io.public_report,termination=broken)
    r=json.loads((fake.output/'report.json').read_bytes());assert not r['passed']and not r['termination_scope_completed']

def test_cleanup_scope_exit_republishes_failure(fake,monkeypatch):
    @contextmanager
    def broken():
        yield
        raise RuntimeError('cleanup restoration')
    monkeypatch.setattr(c,'cleanup_signals',broken)
    with pytest.raises(RuntimeError):c.run(fake.output)
    r=json.loads((fake.output/'report.json').read_bytes());assert not r['passed']and not r['terminal_scope_completed']

def test_real_clean_child_wait_and_group_absence(tmp_path):
    with c.public_io.owned_stream(tmp_path/'child.log',write=True)as log:
        child=c.OwnedChild([sys.executable,'-c','print("public-only")'],cwd=tmp_path,stdout=log)
        assert child.wait()==0;child.close()
    assert all(child.record[n]is True for n in ('direct_child_reaped','group_empty_verified','cleanup_completed'))

@pytest.mark.parametrize('kind',('source','asset'))
def test_late_provenance_drift_cannot_pass(fake,monkeypatch,kind):
    count=0
    if kind=='source':
        def source(root=c.HERE):
            nonlocal count
            count+=1
            return dict(fake.raw)if count<3 else {'source_inventory.json':b'changed'}
        monkeypatch.setattr(c,'source_bytes',source)
    else:
        original=c.asset_hashes
        def assets(m):
            nonlocal count
            count+=1;out=original(m)
            if count>1:out['public_checkpoint']='c'*64
            return out
        monkeypatch.setattr(c,'asset_hashes',assets)
    r=c.run(fake.output)
    assert r['passed']is False and r['complete']is True
    assert not r['source_files_unchanged'if kind=='source'else 'asset_files_unchanged']
    assert all((fake.output/f'joined-K{K}.json').exists()for K in (15,128))

def test_prerequisite_failure_never_reads_fixture_bodies(fake,monkeypatch):
    primary=ValueError('unapproved overlay')
    monkeypatch.setattr(c,'prerequisite_gate',lambda *a:(_ for _ in ()).throw(primary))
    monkeypatch.setattr(c,'asset_hashes',lambda *a:(_ for _ in ()).throw(AssertionError('asset read')))
    with pytest.raises(ValueError)as seen:c.run(fake.output)
    assert seen.value is primary and fake.events==[]
