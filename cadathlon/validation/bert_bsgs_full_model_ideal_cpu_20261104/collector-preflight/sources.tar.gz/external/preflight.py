"""Source-bound narrow collector tests only; no full graph or fixture bodies."""
from pathlib import Path
import hashlib,json,os,sys,time,xml.etree.ElementTree as ET
LAB=Path('/tmp/bert-full-model-bsgs-integration-v2-20261103');sys.path.insert(0,str(LAB));import collect_bsgs_full as c
OUT=LAB/'collector-preflight-v1'
def run():
    OUT.mkdir();start=time.monotonic();report=dict(passed=False,complete=False,scope=__doc__);expected={};child=None;primary=None;cleanup_error=None
    try:
        c.write(OUT/'report.json',report);raw=c.source_bytes();runtime=c.hashes(raw);raw['external/preflight.py']=Path(__file__).read_bytes();expected=c.hashes(raw)
        c.archive(OUT/'sources.tar.gz',raw);snapshot=OUT/'execution';snapshot.mkdir()
        for n,b in raw.items():p=snapshot/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
        c.archive_readback(OUT/'sources.tar.gz',expected)
        report.update(source_hashes_before=expected,runtime_source_count=len(runtime),proof_source_count=len(expected),source_archive_sha256=c.public_io.file_sha(OUT/'sources.tar.gz'))
        with c.public_io.owned_stream(OUT/'tests.log',write=True)as log:
            child=c.OwnedChild([sys.executable,'-m','pytest','-q','--tb=short','test_bsgs_full_collector.py','test_full_model_owner.py::test_tracked_reciprocal_fixture_preserves_bsgs_structural_metadata','--junitxml='+str(OUT/'tests.xml')],cwd=snapshot,stdout=log,env=dict(os.environ,PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONDONTWRITEBYTECODE='1'))
            report['process']=child.record;c.write(OUT/'report.json',report);code=child.wait()
        suites=list(ET.parse(OUT/'tests.xml').getroot().iter('testsuite'));counts={k:sum(int(s.attrib.get(k,0))for s in suites)for k in ('tests','errors','failures','skipped')};report['tests']=counts
        if code!=0 or counts!={'tests':49,'errors':0,'failures':0,'skipped':0}:raise ValueError('47 collector plus 2 metadata tests required')
        report.update(passed=True,complete=True,new_collector_tests=47,new_fixture_metadata_tests=2,full_graph_executed=False)
    except BaseException as e:primary=e;report.update(passed=False,error=dict(type=type(e).__name__,message=str(e)))
    finally:
        with c.terminal_scope(report,OUT/'report.json',c.write,c.cleanup_signals,lambda:(primary,cleanup_error)):
            errors=[]
            def attempt(label,fn):
                nonlocal cleanup_error
                try:return fn()
                except BaseException as e:
                    errors.append(dict(operation=label,type=type(e).__name__))
                    if cleanup_error is None or not isinstance(e,Exception)and isinstance(cleanup_error,Exception):cleanup_error=e
            if child is not None:attempt('child cleanup',lambda:child.close(primary=primary))
            after=attempt('current sources',lambda:c.hashes(c.source_bytes())|{'external/preflight.py':c.digest(Path(__file__).read_bytes())})
            copied=attempt('execution sources',lambda:{n:c.public_io.file_sha(OUT/'execution'/n)for n in expected})if expected else{}
            archive_ok=attempt('source archive',lambda:c.archive_readback(OUT/'sources.tar.gz',expected))if expected else False
            process_ok=child is not None and all(child.record.get(n)is True for n in ('direct_child_reaped','group_empty_verified','cleanup_completed'))
            report.update(source_hashes_after=after,snapshot_source_hashes_after=copied,source_files_unchanged=bool(expected)and expected==after==copied,source_archive_verified=archive_ok is True,cleanup_errors=errors,cleanup_completed=not errors and process_ok,elapsed_s=time.monotonic()-start)
            report['passed']=bool(report['passed']and report['source_files_unchanged']and report['source_archive_verified']and report['cleanup_completed'])
            attempt('final report',lambda:c.write(OUT/'report.json',report))
            if primary is not None:
                for e in errors:primary.add_note(str(e))
                raise primary
            if cleanup_error is not None:raise cleanup_error
    return report
r=c.finish(OUT/'report.json',run,c.write,c.public_io.public_report)
print(json.dumps({n:r[n]for n in ('passed','tests','runtime_source_count','proof_source_count','source_archive_sha256','elapsed_s')}));raise SystemExit(0 if r['passed']else 1)
