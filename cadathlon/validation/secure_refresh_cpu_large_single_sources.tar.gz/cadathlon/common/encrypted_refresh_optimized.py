"""Isolated experimental refresh fusion and public range preconditioning.

Scratch implementation while the repository's runtime sources are frozen.
The caller must establish the public magnitude bound; it is not measured from
the ciphertext. Preconditioning/restoration perform actual plaintext products
and rescales. This wrapper never decrypts or changes scale metadata to change
the represented message.
"""
import math

from encrypted_compilation import ExplicitArrayCompiler
from encrypted_polynomial import EncryptedPolynomialEvaluator
from encrypted_refresh import SecureRefresh
from encrypted_rotation import CompiledRotation


class CompiledRelinearization:
    def __init__(self, context):
        EncryptedPolynomialEvaluator(context)
        self.ctx = context
        self.compiler = ExplicitArrayCompiler()
        self.binding = None

    def clear(self, *, executables=False):
        self.binding = None
        if executables:
            self.compiler.clear_executables()

    def relinearize(self, value):
        import jax
        from jaxite_word import he_params
        value.validate()
        cache = self.ctx._param_cache
        target = he_params.SecurityTarget(128, 'classical')
        if not he_params.qp_is_secure(self.ctx.q_towers, self.ctx.p_towers, self.ctx.degree, target):
            raise ValueError('live relinearization ring is not 128-bit secure')
        level = cache.level_for_num_q(value.num_moduli)
        if (level < 1 or tuple(value.shape) != (cache.batch, 3, *cache.degree_layout, value.num_moduli)
                or tuple(value.moduli) != tuple(cache.q_moduli_at_level(level))
                or value.precision != 32 or str(value.polynomial.dtype) != 'uint32'):
            raise ValueError('invalid three-component relinearization input')
        if len(value.polynomial.devices()) != 1:
            raise ValueError('one-device relinearization required')
        device = next(iter(value.polynomial.devices()))
        signature = ('relinearize-no-rescale', level, tuple(value.shape), device)
        if self.binding is None or self.binding[0] != signature:
            operation = self.ctx.he_mul[level - 1]
            kernel = operation._no_relin_operator
            if not kernel.skip_rescale:
                raise ValueError('no-rescale relinearization controls required')
            try:
                binding = self.compiler.bind(kernel._relinearize_array, (value.polynomial,),
                                             signature=signature, device=device)
                self.binding = (signature, binding)
            finally:
                self.ctx.he_mul._instances.pop(level - 1, None)
        result = value._clone_with_payload(self.binding[1](value.polynomial), num_elements=2)
        jax.block_until_ready(result.polynomial)
        return result


class _Operation:
    def __init__(self, original, method, implementation):
        self.original, self.method, self.implementation = original, method, implementation

    def __getattr__(self, name):
        return self.implementation if name == self.method else getattr(self.original, name)


class CompiledRescale:
    def __init__(self, context):
        EncryptedPolynomialEvaluator(context)
        self.ctx = context
        self.compiler = ExplicitArrayCompiler()
        self.binding = None

    def clear(self, *, executables=False):
        self.binding = None
        if executables:
            self.compiler.clear_executables()

    def rescale(self, value, source, target):
        import jax
        import finite_field
        from support import require_secure_execution
        require_secure_execution(self, value)
        cache = self.ctx._param_cache
        if cache.level_for_num_q(value.num_moduli) != source or not 0 <= target < source:
            raise ValueError('invalid rescale level contract')
        finite_field.check_ct_operand(cache.ff_context_cls, value.num_moduli, value,
            'compiled rescale', batch=cache.batch, num_elements=2,
            degree_layout=cache.degree_layout, moduli=cache.q_moduli_at_level(source))
        if len(value.polynomial.devices()) != 1:
            raise ValueError('one-device rescale required')
        device = next(iter(value.polynomial.devices()))
        signature = ('rescale', source, target, tuple(value.shape), device)
        if self.binding is None or self.binding[0] != signature:
            operation = self.ctx.he_rescale[source, target]
            try:
                binding = self.compiler.bind(operation._rescale_array, (value.polynomial,),
                                             signature=signature, device=device)
                self.binding = (signature, binding)
            finally:
                self.ctx.he_rescale._instances.pop((source, target), None)
        target_moduli = cache.q_moduli_at_level(target)
        result = value._clone_with_payload(self.binding[1](value.polynomial), moduli=target_moduli,
                                           ntt_ctx=cache.get_sliced_ntt_q(target))
        if hasattr(value, '_ckks_scale'):
            result._ckks_scale = value._ckks_scale / math.prod(value.moduli[len(target_moduli):])
        jax.block_until_ready(result.polynomial)
        return result


class CompiledPlaintextMultiply:
    def __init__(self, context):
        EncryptedPolynomialEvaluator(context)
        self.ctx = context
        self.compiler = ExplicitArrayCompiler()
        self.binding = None

    def clear(self, *, executables=False):
        self.binding = None
        if executables:
            self.compiler.clear_executables()

    def multiply_encoded(self, value, plaintext, level):
        import jax
        import jax.numpy as jnp
        import finite_field
        from support import require_secure_execution
        require_secure_execution(self, value)
        if self.ctx._param_cache.level_for_num_q(value.num_moduli) != level:
            raise ValueError('plaintext multiply level mismatch')
        cache = self.ctx._param_cache
        finite_field.check_ct_operand(cache.ff_context_cls, value.num_moduli, value,
            'compiled plaintext multiply', batch=cache.batch, num_elements=2,
            degree_layout=cache.degree_layout, moduli=cache.q_moduli_at_level(level))
        if len(value.polynomial.devices()) != 1:
            raise ValueError('one-device plaintext multiply required')
        device = next(iter(value.polynomial.devices()))
        signature = ('plaintext-multiply', level, tuple(value.shape), tuple(plaintext.shape), str(plaintext.dtype), device)
        if self.binding is None or self.binding[0] != signature:
            operation = self.ctx.ptct_mul[level]
            def multiply(payload, encoded):
                prepared = operation._ptct.ff_ctx.to_computation_format(jnp.asarray(encoded, jnp.uint64))
                return operation._mul_array(payload, prepared)
            try:
                binding = self.compiler.bind(multiply, (value.polynomial, plaintext),
                                             signature=signature, device=device)
                self.binding = (signature, binding)
            finally:
                self.ctx.ptct_mul._instances.pop(level, None)
        result = value._clone_with_payload(self.binding[1](value.polynomial, plaintext))
        result.__dict__.pop('_ckks_scale', None)
        jax.block_until_ready(result.polynomial)
        return result

    def multiply(self, value, plaintext, level):
        import finite_field
        cache = self.ctx._param_cache
        finite_field.check_ct_operand(cache.ff_context_cls, cache.num_q_at_level(level), plaintext,
            'compiled plaintext operand', batch=1, num_elements=1,
            degree_layout=cache.degree_layout, moduli=cache.q_moduli_at_level(level))
        result = self.multiply_encoded(value, plaintext.polynomial, level)
        ciphertext_scale = getattr(value, '_ckks_scale', None)
        plaintext_scale = getattr(plaintext, '_ckks_scale', None)
        if ciphertext_scale is not None and plaintext_scale is not None:
            result._ckks_scale = float(ciphertext_scale) * float(plaintext_scale)
        result._ckks_nsd = getattr(value, '_ckks_nsd', 1) + 1
        return result


class _Accessor:
    def __init__(self, original, bind):
        self.original, self.bind = original, bind

    def __getitem__(self, key):
        return self.bind(key, self.original[key])

    def __getattr__(self, name):
        return getattr(self.original, name)


def install_compiled_primitives(engine, context):
    """Bind compiled operations only on this engine's private context view."""
    rotations = CompiledRotation(context)
    relinearization = CompiledRelinearization(context)
    rescale = CompiledRescale(context)
    plaintext = CompiledPlaintextMultiply(context)

    def bind_rotation(key, original):
        level, index = key

        def rotate(value):
            if context._param_cache.level_for_num_q(value.num_moduli) != level:
                raise ValueError('rotation level differs from bound accessor')
            return rotations.rotate(value, index)
        return _Operation(original, 'rotate', rotate)

    def bind_multiply(level, original):
        def relinearize(value):
            if context._param_cache.level_for_num_q(value.num_moduli) != level + 1:
                raise ValueError('relinearization level differs from bound accessor')
            return relinearization.relinearize(value)
        return _Operation(original, 'relinearize', relinearize)

    engine.ctx._he_rot = _Accessor(context.he_rot, bind_rotation)
    engine.ctx._he_mul = _Accessor(context.he_mul, bind_multiply)
    engine.ctx._he_rescale = _Accessor(context.he_rescale,
        lambda key, original: _Operation(original, 'rescale', lambda value: rescale.rescale(value, *key)))
    engine.ctx._ptct_mul = _Accessor(context.ptct_mul,
        lambda level, original: _Operation(original, '_mul_encoded',
            lambda value, encoded: plaintext.multiply_encoded(value, encoded, level)))
    checkpoint = engine._stage_checkpoint

    def release_bindings(tag, ct=None):
        if engine._low_mem:
            rotations.clear()
            relinearization.clear()
            rescale.clear()
            plaintext.clear()
        checkpoint(tag, ct)

    engine._stage_checkpoint = release_bindings
    return rotations, relinearization, rescale, plaintext


class OptimizedSecureRefresh(SecureRefresh):
    """Experimental compiled refresh with an explicit public magnitude bound.

    Reserve two input levels and one extra output level for real range
    preconditioning. Bounds may vary by public circuit operation. Magnitudes
    beyond the supplied bound are outside this experimental contract.
    """
    input_level = 2

    def __init__(self, context, *, public_bound=1., meta_precision=None, **kwargs):
        self.public_bound = self._bound(public_bound)
        if meta_precision is not None and (type(meta_precision) is not int or not 1 <= meta_precision <= 62):
            raise ValueError('meta_precision must be an integer in [1, 62] or None')
        self.meta_precision = meta_precision
        super().__init__(context, **kwargs)
        if self.plan['output_level'] < 2:
            raise ValueError('preconditioned refresh needs one extra output level')
        (self.compiled_rotation, self.compiled_relinearization,
         self.compiled_rescale, self.compiled_plaintext) = install_compiled_primitives(self.engine, context)

    @staticmethod
    def _bound(value):
        if isinstance(value, bool) or not isinstance(value, (float, int)):
            raise TypeError('public magnitude bound must be numeric')
        value = float(value)
        if not math.isfinite(value) or value <= 0:
            raise ValueError('public magnitude bound must be positive and finite')
        return value

    @property
    def output_level(self):
        return self.plan['output_level'] - 1

    def _refresh_canonical(self, value):
        from support import require_secure_execution
        depleted = self.evaluator._lower(value, 1)
        if self.meta_precision is None:
            result = self.engine.bootstrap(depleted)
        else:
            result = self.engine.meta_bootstrap(depleted, precision=self.meta_precision)
        require_secure_execution(self, result)
        level = self.ctx._param_cache.level_for_num_q(result.num_moduli)
        nsd = getattr(result, '_ckks_nsd', None)
        if nsd == 2:
            if level < 1:
                raise ValueError('bootstrap output lacks a normalization level')
            result = self.compiled_rescale.rescale(result, level, level - 1)
            result._ckks_nsd = 1
        elif nsd != 1:
            raise ValueError(f'unexpected bootstrap output noise-scale degree: {nsd}')
        result = self.evaluator.weighted_sum([result], [1.])
        if self.evaluator._level(result) < self.plan['output_level']:
            raise ValueError('bootstrap returned fewer normalized levels than its public plan')
        require_secure_execution(self, result)
        self.refresh_count += 1
        return result

    def refresh(self, value, *, public_bound=None):
        bound = self.public_bound if public_bound is None else self._bound(public_bound)
        if self.evaluator._level(value) < self.input_level:
            raise ValueError('public preconditioning requires two remaining input levels')
        if bound != 1.:
            value = self.evaluator.weighted_sum([value], [1. / bound])
        result = self._refresh_canonical(value)
        if bound != 1.:
            result = self.evaluator.weighted_sum([result], [bound])
        if self.evaluator._level(result) < self.output_level:
            raise ValueError('insufficient output capacity after public range restoration')
        return result
