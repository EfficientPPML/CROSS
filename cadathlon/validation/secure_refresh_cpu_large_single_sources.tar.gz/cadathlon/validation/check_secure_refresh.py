#!/usr/bin/env python3
"""Opt-in real secure bootstrap validation; client decryption only at the end."""
from __future__ import annotations

import argparse
import gc
import hashlib
import json
import math
from pathlib import Path
import sys
import time

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'cadathlon/common'))
from encrypted_refresh import RefreshProfile, refresh_plan
from encrypted_polynomial import EncryptedPolynomialEvaluator
from encrypted_refresh_optimized import OptimizedSecureRefresh as SecureRefresh


def run(*, degree=65536, depth=24, period=4, dnum=8, scale_bits=56,
        level_budget=(2, 2), low_memory=True, continuation=True, amplitude=14., public_bound=16., meta_precision=None):
    import jax
    from jaxite_word import CKKSContext, he_params, key_gen, ckks_ctx
    from support import require_secure_execution

    jax.config.update('jax_enable_x64', True)
    started = time.perf_counter()
    sources = sorted(str(path.relative_to(ROOT)) for path in ROOT.rglob('*.py'))
    source_hashes = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in sources}
    params = RefreshProfile(degree, depth, scale_bits, 61, dnum).parameters()
    q, p = params['q_towers'], params['p_towers']
    plan = refresh_plan(degree, period, level_budget, max_level=depth)
    r = 256
    params['degree_layout'] = (r, degree // r)

    def progress(message):
        print(f'[{time.perf_counter()-started:.1f}s] {message}', file=sys.stderr, flush=True)

    progress(f'secure ring N={degree} Q={len(q)} P={len(p)} log2QP={math.log2(math.prod(q+p)):.3f}; {len(plan["rotations"])} rotation keys')
    client = server = refresh = None
    try:
        # This is the client/offline phase. Convert retained public keys to
        # native uint32 arrays immediately to bound Python object overhead.
        keys = key_gen.gen_pke_pair(q, [], degree)
        evaluation = key_gen.gen_evaluation_key(keys['secret_key'], q=q, P=p, dnum=dnum,
                                                noise_std=he_params.DEFAULT_SIGMA, noise_scale=1)
        evaluation = [jax.numpy.asarray(evaluation[name], dtype='uint32').transpose(0, 2, 1)
                      for name in ('a', 'b')]
        rotations = {}
        for index in plan['rotations']:
            key = key_gen.gen_rotation_key(keys['secret_key'], q, p, index, dnum=dnum,
                noise_std=he_params.DEFAULT_SIGMA, noise_scale=1)[index]
            rotations[index] = {name: np.asarray(key[name], dtype=np.uint32) for name in ('a', 'b')}
            del key
            progress(f'rotation keys {len(rotations)}/{len(plan["rotations"])}')
        client = CKKSContext(dict(params, **keys))
        server = CKKSContext(dict(params, evaluation_key=evaluation))
        server.program_initialization(list(plan['rotations']), dnum=dnum, r=r, c=degree // r,
                                      batch=1, pregenerated_rotation_keys=rotations)
        del keys, evaluation, rotations
        gc.collect()
        progress('separate keyless server initialized')

        def forbidden(*args, **kwargs):
            raise AssertionError('server encryption, decryption, or key generation is forbidden')

        for name in ('encrypt', 'encrypt_slots', 'decrypt', 'decrypt_slots', 'decode'):
            setattr(server, name, forbidden)
        assert server.secret_key is None
        assert server._param_cache.secret_key is None
        assert server.parameters.get('secret_key') is None
        refresh = SecureRefresh(server, period=period, level_budget=level_budget, low_memory=low_memory, public_bound=public_bound, meta_precision=meta_precision)
        checkpoint = refresh.engine._stage_checkpoint

        def report_checkpoint(tag, ct=None):
            checkpoint(tag, ct)
            progress(f'bootstrap stage: {tag}')

        refresh.engine._stage_checkpoint = report_checkpoint
        setup_seconds = time.perf_counter() - started
        progress('bootstrap constants prepared')
        pattern = np.linspace(-amplitude, amplitude, period)
        values = np.tile(pattern, degree // 2 // period)
        encrypted = client.encrypt_slots(values)
        encrypted = server.he_level_reduce[depth, refresh.input_level].level_reduce(encrypted)
        # The only remaining access to client.secret_key is final decryption.
        generation_names = ('gen_pke_pair', 'gen_evaluation_key', 'gen_rotation_key')
        # Historical flat imports and package imports can identify distinct
        # key_gen modules. Guard both runtime spellings used by primitives.
        modules = {module for name, module in sys.modules.items()
                   if name in ('key_gen', 'jaxite_word.key_gen')}
        originals = {(module, name): getattr(module, name)
                     for module in modules for name in generation_names}
        for module, name in originals:
            setattr(module, name, forbidden)
        try:
            refreshed_at = time.perf_counter()
            result = refresh.refresh(encrypted)
            jax.block_until_ready(result.polynomial)
            refresh_seconds = time.perf_counter() - refreshed_at
            progress('homomorphic refresh complete')
            actual_level = server._param_cache.level_for_num_q(result.num_moduli)
            manifest = require_secure_execution(refresh, result)[0]
            refreshed = result
            # A subsequent real ciphertext multiplication proves that the
            # refreshed output is usable by the same polynomial evaluator.
            if continuation:
                result = refresh.evaluator.multiply(result, result)
                jax.block_until_ready(result.polynomial)
        finally:
            for (module, name), original in originals.items():
                setattr(module, name, original)
        actual = np.asarray(client.decrypt_slots(result))
        refreshed_actual = np.asarray(client.decrypt_slots(refreshed))
        expected = values ** 2 if continuation else values
        error = float(np.max(np.abs(actual - expected)))
        refresh_error = float(np.max(np.abs(refreshed_actual - values)))
        relative_error = float(np.max(np.abs(actual - expected) / np.maximum(np.abs(expected), 1e-300)))
        refresh_relative_error = float(np.max(np.abs(refreshed_actual-values) / np.maximum(np.abs(values), 1e-300)))
        source_hashes_end = {name: hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in sources}
        assert source_hashes_end == source_hashes, 'isolated validation source changed during execution'
        finite = bool(np.isfinite(actual).all() and np.isfinite(refreshed_actual).all())
        report = dict(passed=finite and max(error, refresh_error) < 1e-3, backend=jax.default_backend(),
                      device=str(jax.devices()[0]), profile=dict(degree=degree, depth=depth,
                      period=period, dnum=dnum, scale_bits=scale_bits), plan=plan,
                      actual_output_level=actual_level, continuation=continuation,
                      max_abs_error=error, refresh_max_abs_error=refresh_error, output_finite=finite,
                      max_relative_error=relative_error, refresh_max_relative_error=refresh_relative_error,
                      amplitude=amplitude, public_bound=public_bound, meta_precision=meta_precision,
                      source_hashes_unchanged=True, absolute_error_gate=1e-3,
                      scope='Actual secure periodic refresh at the reported magnitude plus encrypted square; no deep transformer completion claim.',
                      setup_seconds=setup_seconds, refresh_seconds=refresh_seconds,
                      total_seconds=time.perf_counter()-started, actual_ring=manifest,
                      timing_scope='component timing through client validation; excludes final cleanup and process startup',
                      server_has_secret_key=False, runtime_key_generation_forbidden=True,
                      source_hashes_at_start=source_hashes,
                      refreshed_sample=refreshed_actual[:period].tolist(), final_sample=actual[:period].tolist())
        progress(f'max absolute error {error:.6g}')
        return report
    finally:
        refresh = None
        for context in (client, server):
            if context is not None:
                ckks_ctx.evict_context_caches(context)
        jax.clear_caches()
        gc.collect()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--degree', type=int, default=65536)
    parser.add_argument('--depth', type=int, default=24)
    parser.add_argument('--amplitude', type=float, default=14.)
    parser.add_argument('--public-bound', type=float, default=16.)
    parser.add_argument('--meta-precision', type=int)
    parser.add_argument('--period', type=int, default=4)
    parser.add_argument('--dnum', type=int, default=8)
    parser.add_argument('--scale-bits', type=int, default=56)
    parser.add_argument('--budget', type=int, default=2)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    try:
        report = run(degree=args.degree, depth=args.depth, period=args.period,
                     dnum=args.dnum, scale_bits=args.scale_bits, level_budget=(args.budget, args.budget), amplitude=args.amplitude, public_bound=args.public_bound, meta_precision=args.meta_precision)
    except Exception as error:
        report = dict(passed=False, error=f'{type(error).__name__}: {error}')
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + '\n')
        raise
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({key: value for key, value in report.items() if key not in ('actual_ring', 'plan')}))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
