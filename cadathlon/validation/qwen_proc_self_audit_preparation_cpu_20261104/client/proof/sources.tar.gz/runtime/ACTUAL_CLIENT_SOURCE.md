# Actual client source preparation

This closure is source-only and has never been imported, collected or executed.
`qwen_client_entry_status.json` and `qwen_client_role_policy.json` keep actual
entry disabled. The dependency document is explicitly unconfigured. No real
resource policy, conditional/phase grant, future source hash or result is
supplied. A separately reviewed readiness successor and focused preparation
remain required before any actual role can be considered.

The executable source path is `qwen_client_entry.py` → `qwen_client_process.py`.
The entry requires fresh `-I -B`, an externally pinned canonical compact source
map, exact complete tree bytes and an external source-archive digest. Its closed
root-module selection and one common `support` module keep historical copies,
tests and unrelated full-model constructors unselected. Fixed34 core modules
are loaded through exact shared helper284817 only after public admission,
installed dependency policy and capacity checks. Both flat/package aliases are
retained as identical objects. Default decoder bc978 and all208 arithmetic
remain byte-identical. No prepared arithmetic factory is selected.

The public authority packet is one externally pinned canonical UTF-8 document.
Its expected-pin bytes are external authority; they are never computed from an
incoming outcome. It reauthenticates the generation ModelAdmission, generated
key normal-zero/root proof, the independently repinned client ModelAdmission,
conditional named role, exact phase grant and, for output, the separate actual
server terminal envelope. The generation/request/response names can share a
reviewed client map; no artificial digest inequality is required. The server's
execution source and scientific authorization remain separate from the inner
request provenance. No new scientific authorization verifier is supplied here.

The process authenticates the complete source map/archive and source-root role,
source-selected dependency/role documents, external resource policy/review and
fresh result/evidence destinations before importing NumPy/JAX/core. Model,
token, calibration and unrelated private paths remain protected. One dedicated
process performs one client role; no nested client/server context lifetime is
introduced. The loader common body and the original client encrypt/decrypt
stage bodies are retained exactly behind declared admission factoring.

Request mode reads only the phase-granted original float64 `[1,S,1024]` NPY.
Original held-file metadata is compared before first hash/header/payload read;
its small immutable copy uses exact original row positions and unchanged layout
helper. After key readiness and full FilesAdmission, the selected client context
encrypts one or two fresh L49 tiles, and Publisher creates an exclusive request
store under the independently granted original parent. Both key-generation
aliases are forbidden by the selected loader before context construction. No
fresh keys or model bodies are used by these client roles.

Response mode authenticates all38 response files, immutable six-field payloads,
original held directory and separate server evidence before allowing either
public or private key-store reads. The original default decoder is called with
actual scale,65536 slots and `validate_approximation=True`. Each returned fullslot
buffer is copied before another decode call. The exact layout helper selects
37×4096+384 row0 columns, yielding immutable `[1,151936]` logits. Every CT consumer
retires inside the original key-loader scope; the response owner retires before
private result publication. No thresholds, clipping or scientific acceptance
claims are added.

Publisher now requires canonical external parent bytes before mkdir, with
original held/named directory, effective UID and sticky-parent trust checks.
The result/evidence writer copies keygen85 Output except for two additional
small filenames. It holds original FDs, fsyncs/readbacks and never deletes or
retries an uncertain close. All38 response admission and input/key access gates
are client-specific; keygen's broad store audit is not reused. Original callbacks
are captured before later callbacks, and the shared4543 marker policy selects
body versus cleanup failures. Any escaped error/cancellation or late publication
close failure maps to infrastructure70; only an independently observed normal0,
reap/group absence and root archive/store review can admit a future result.

The externally reviewed resource policy must supply import and working-memory
headroom, host reserve, descriptor allowance and result/evidence filesystem
requirements. Source-derived logical bytes are explicitly not peak RSS bounds.
The process checks its actual cgroup-v2 identity, host/cgroup memory, RSS, fixed
CPU affinity, FD baseline, original granted parents, combined same-device space
and additional tmpfs output charge. It does not reserve storage or change limits.
No numeric resource choice is supplied by this source preparation.

Source capacity is64MiB total and8MiB per member because this explicit closure
retains over32MiB of admitted source/provenance bytes; body-read limits are
separate and unchanged. Installed source/origin policy remains external and
exact, including module-specific backend file/spec expectations. The audit is a
Python-level source guard, not OS/native isolation; lexical/path metadata
resolution is not claimed to be body-free stat isolation.

Historical373/366/208/authority39 metadata and test files are retained evidence,
not current test selection or proof. The new process, policies, filesystem
transitions, parent adaptation and actual dependency factory remain untested.
No old recording PASS is relabeled as actual backend or complete current-closure
proof. Future boundary tests must explicitly cover current source and use only
a separately authorized recording/synthetic preparation until actual grants.
