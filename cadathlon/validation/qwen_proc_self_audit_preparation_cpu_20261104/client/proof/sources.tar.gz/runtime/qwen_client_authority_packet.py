"""One externally pinned public metadata packet, with no private manifest body.

The launcher supplies the packet SHA from an independent reviewed launch. All
embedded expected-pin bytes inherit that external trust; no expectations are
computed from incoming outcomes. This module performs only pure byte/object
admission. It cannot authorize filesystem or backend operations by itself.
"""
from dataclasses import dataclass
from qwen_file_contract import PublicContract,canonical,sha,hash_value,same
from public_source_pins import PUBLIC_PINS
from client_role_common import raw_object,obj
from model_admission import ExpectedModelPins,authenticate_model
from keygen_authority import (ActualKeygenIntent,ExpectedLaunchPins,ExpectedReadyPins,
    authenticate_launch,authenticate_readiness)
from client_role_admission import (ExpectedRolePins,ExpectedPhasePins,
    authenticate_conditional_role,authenticate_phase)
from client_server_terminal import ExpectedServerPins,authenticate_server

PACKET_LIMIT=16<<20
FIELDS={'schema','generation_intent','generation_model','generation_launch_grant','generation_launch_pins',
    'generated_public_manifest','generated_report','generated_outer','generated_root_review','generated_ready_pins',
    'client_model','conditional_grant','conditional_pins','request','phase_grant','phase_pins','server',
    'dependency_policy','role_policy','resource_policy','resource_review'}


def _bytes(value,label,limit=2<<20):
    if type(value)is not str:raise TypeError('exact UTF-8 public '+label+' bytes required')
    raw=value.encode('utf-8')
    if not 0<len(raw)<=limit:raise ValueError('bounded public '+label+' required')
    return raw


def _model(public,value):
    obj(value,('manifest','report','outer','root_review','expected_pins'),'public model proof bundle')
    return authenticate_model(public,_bytes(value['manifest'],'model manifest'),_bytes(value['report'],'model report'),
        _bytes(value['outer'],'model outer',1<<16),_bytes(value['root_review'],'model root review',1<<16),
        expected_pins=ExpectedModelPins(_bytes(value['expected_pins'],'model external pins',1<<20)))


@dataclass(frozen=True)
class ClientPacket:
    public:PublicContract
    raw:bytes
    expected_sha256:str
    phase:object
    dependency_policy:bytes
    role_policy:bytes
    resource_policy:bytes
    resource_review:bytes

    def check(self):
        self.phase.check()
        rebuilt=authenticate_packet(self.public,self.raw,expected_sha256=self.expected_sha256)
        for name in('dependency_policy','role_policy','resource_policy','resource_review'):
            if getattr(self,name)!=getattr(rebuilt,name):raise ValueError('retained public client policy differs')
        if (self.phase.request_bytes!=rebuilt.phase.request_bytes or self.phase.grant_bytes!=rebuilt.phase.grant_bytes
                or self.phase.conditional.grant_bytes!=rebuilt.phase.conditional.grant_bytes
                or self.phase.expected_pins.raw!=rebuilt.phase.expected_pins.raw
                or self.phase.conditional.expected_pins.raw!=rebuilt.phase.conditional.expected_pins.raw
                or self.phase.conditional.intent.raw!=rebuilt.phase.conditional.intent.raw
                or self.phase.readiness.expected_pins.raw!=rebuilt.phase.readiness.expected_pins.raw):
            raise ValueError('retained phase packet differs')
        return self


def public_from_sources(blobs):
    if type(blobs)is not dict:raise TypeError('already authenticated complete source bytes required')
    return PublicContract.from_blobs({name:blobs['public_inputs/'+name]for name in PUBLIC_PINS})


def authenticate_packet(public,raw,*,expected_sha256):
    if type(public)is not PublicContract:raise TypeError('exact source-bound public contract required')
    public.check();hash_value(expected_sha256)
    if sha(raw)!=expected_sha256:raise ValueError('independently supplied public packet digest differs')
    packet=raw_object(raw,PACKET_LIMIT,'client public authority packet');obj(packet,FIELDS,'client public authority packet')
    if packet['schema']!='qwen-client-authority-packet-v1':raise ValueError('public authority packet schema differs')
    intent=ActualKeygenIntent(public,_bytes(packet['generation_intent'],'generation intent',1<<16))
    launch=authenticate_launch(intent,_bytes(packet['generation_launch_grant'],'generation grant',1<<16),
        _model(public,packet['generation_model']),expected_pins=ExpectedLaunchPins(_bytes(packet['generation_launch_pins'],'generation launch pins',1<<20)))
    ready=authenticate_readiness(launch,_bytes(packet['generated_public_manifest'],'public key manifest',1<<20),
        _bytes(packet['generated_report'],'generated-key report'),_bytes(packet['generated_outer'],'generated-key outer',1<<16),
        _bytes(packet['generated_root_review'],'generated-key root review',1<<16),
        expected_pins=ExpectedReadyPins(_bytes(packet['generated_ready_pins'],'generated-key external pins',1<<16)))
    role_pins=ExpectedRolePins(_bytes(packet['conditional_pins'],'independent client role pins',1<<20))
    conditional=authenticate_conditional_role(intent,_model(public,packet['client_model']),
        _bytes(packet['conditional_grant'],'conditional role grant',1<<16),expected_pins=role_pins)
    request=_bytes(packet['request'],'client request',1<<20);server=None
    if role_pins.check()['role']=='response_consumer':
        fields={'model','input_digest','response','inner_report','inner_outer','envelope','outer','root_review','expected_pins'}
        proof=obj(packet['server'],fields,'separate actual server proof')
        server=authenticate_server(public,_model(public,proof['model']),ready,request,proof['input_digest'],
            _bytes(proof['response'],'complete38 response',1<<20),_bytes(proof['inner_report'],'inner server report',1<<20),
            _bytes(proof['inner_outer'],'inner server outer',1<<16),_bytes(proof['envelope'],'actual server envelope'),
            _bytes(proof['outer'],'actual server outer',1<<16),_bytes(proof['root_review'],'actual server root review',1<<16),
            expected_pins=ExpectedServerPins(_bytes(proof['expected_pins'],'independent actual server pins',1<<20)))
    elif packet['server']is not None:raise ValueError('request phase cannot supply response/server proof')
    phase=authenticate_phase(conditional,ready,request,_bytes(packet['phase_grant'],'phase grant',1<<16),
        expected_pins=ExpectedPhasePins(_bytes(packet['phase_pins'],'independent phase pins',1<<16)),server=server)
    policies=role_pins.check()['policies'];raw_policies={name:_bytes(packet[name],name,1<<20)for name in('dependency_policy','role_policy','resource_policy','resource_review')}
    for name,value in raw_policies.items():
        if sha(value)!=policies[name+'_sha256']:raise ValueError('exact independently pinned '+name+' differs')
    return ClientPacket(public,raw,expected_sha256,phase,**raw_policies)
