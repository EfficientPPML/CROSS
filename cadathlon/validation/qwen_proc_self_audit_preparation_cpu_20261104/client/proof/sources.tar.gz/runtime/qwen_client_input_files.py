"""Held original-embedding input for the admitted client request phase.

This internal component is not an actual entrypoint. Its caller must complete
source, installed-dependency and externally reviewed capacity gates before
importing it. It opens only the exact phase-granted original embedding NPY; no
model, tokenizer, calibration or validation loader is present.
"""
from pathlib import Path
import os
import stat
import numpy as np
from client_role_admission import PhaseAdmission
from client_role_common import raw_object
from qwen_file_contract import canonical, same
from qwen_public_parameters import _FdReader, _header, _hash_fd
from qwen_publisher import _Descriptor
from qwen_finalizer import Finalizer
from cleanup import cleanup_signals

_QUARANTINE = []


def _state(info):
    return dict(device=info.st_dev,inode=info.st_ino,size=info.st_size,
        mtime_ns=info.st_mtime_ns,ctime_ns=info.st_ctime_ns,mode=stat.S_IMODE(info.st_mode))


class OriginalEmbeddingFile:
    """An immutable small copy backed by an original held input descriptor.

    File identity is compared with independent phase-grant metadata BEFORE its
    first body hash/header/payload read. The descriptor remains held for the
    entire consumer phase; no mmap, dup, fdopen or path reopen supplies arrays.
    """
    def __init__(self, phase):
        self.phase=phase;self.parent=_Descriptor('embedding parent');self.file=_Descriptor('embedding input')
        self.value=None;self.closed=False;self.failed=None;self._fixed=None
        if type(phase)is not PhaseAdmission:raise TypeError('exact admitted client phase required')
        phase.check()
        grant=raw_object(phase.grant_bytes,1<<16,'phase grant')
        if grant['role']!='request_producer':raise ValueError('only original embedding request input is allowed')
        self.description=canonical(grant['input']);description=grant['input']
        self.path=Path(description['path']);self.expected=canonical(description['state'])
        self.shape=tuple(description['shape']);self.expected_hash=description['sha256']
        parent=self.parent;file=self.file
        # Retain original owners locally even if setup or validation fails.
        parent_close=parent.close;file_close=file.close
        try:
            if self.path.resolve()!=self.path:raise ValueError('embedding input path must not contain a symlink alias')
            parent.fd=os.open(self.path.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
            info=os.fstat(parent.fd);named=self.path.parent.lstat()
            if not stat.S_ISDIR(info.st_mode)or(info.st_dev,info.st_ino)!=(named.st_dev,named.st_ino):
                raise ValueError('original embedding parent changed')
            self.parent_identity=(info.st_dev,info.st_ino)
            file.fd=os.open(self.path.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=parent.fd)
            self._check_file()
            size=description['state']['size']
            if _hash_fd(file.fd,stop=size)!=self.expected_hash:raise ValueError('granted embedding bytes differ')
            self._check_file()
            offset=_header(_FdReader(file.fd,size),size,self.shape)
            remaining=size-offset;parts=[];position=offset
            while remaining:
                block=os.pread(file.fd,min(1<<20,remaining),position)
                if not block:raise ValueError('truncated embedding payload')
                parts.append(block);position+=len(block);remaining-=len(block)
            raw=b''.join(parts)
            value=np.frombuffer(raw,dtype='<f8').reshape(self.shape)
            if type(value)is not np.ndarray or value.flags.writeable or not np.isfinite(value).all():
                raise ValueError('finite immutable original embedding payload required')
            self.value=value
            self._fixed=(phase,self.description,self.path,self.expected,self.shape,self.expected_hash,parent,file,value)
            self.check(readback=True)
        except BaseException as primary:
            final=Finalizer({},primary)
            final.attempt('original embedding file close',file_close)
            final.attempt('original embedding parent close',parent_close)
            self.closed=True;self.failed=final.selected()
            _QUARANTINE.append((self,phase,parent,file,self.value,self.failed))
            final.raise_if_failed()

    def _check_file(self):
        if self.parent.fd is None or self.file.fd is None:raise ValueError('original embedding descriptors are unavailable')
        parent=os.fstat(self.parent.fd);named_parent=self.path.parent.lstat()
        if (not stat.S_ISDIR(parent.st_mode)or not stat.S_ISDIR(named_parent.st_mode)
                or(parent.st_dev,parent.st_ino)!=self.parent_identity
                or(named_parent.st_dev,named_parent.st_ino)!=self.parent_identity):
            raise ValueError('original embedding parent was replaced')
        held=os.fstat(self.file.fd);named=os.stat(self.path.name,dir_fd=self.parent.fd,follow_symlinks=False)
        if not stat.S_ISREG(held.st_mode)or not stat.S_ISREG(named.st_mode):raise ValueError('regular embedding input required')
        if canonical(_state(held))!=self.expected or canonical(_state(named))!=self.expected:
            raise ValueError('independently granted embedding identity differs')

    def check(self,*,readback=False):
        if self.closed:raise ValueError('embedding owner is closed')
        if self.failed is not None:raise self.failed
        if self._fixed is None:raise ValueError('embedding setup is incomplete')
        current=(self.phase,self.description,self.path,self.expected,self.shape,self.expected_hash,self.parent,self.file,self.value)
        if any(a is not b for a,b in zip(current,self._fixed)):raise ValueError('original embedding owner binding changed')
        self.phase.check()
        same(raw_object(self.phase.grant_bytes,1<<16,'phase grant')['input'],raw_object(self.description,1<<16,'embedding input'),'embedding phase descriptor changed')
        self._check_file()
        if self.value.shape!=self.shape or self.value.dtype.str!='<f8' or self.value.flags.writeable:
            raise ValueError('original embedding immutable snapshot changed')
        if readback:
            if _hash_fd(self.file.fd,stop=raw_object(self.expected,1<<16,'embedding state')['size'])!=self.expected_hash:
                raise ValueError('original embedding readback differs')
            self._check_file()
        return self.value

    def close(self,primary=None):
        if self.closed:
            if primary is not None:raise primary
            if self.failed is not None:raise self.failed
            return
        # Capture original owners/callables before invoking any cleanup action.
        fixed=self._fixed
        parent,file=(fixed[6],fixed[7])if fixed is not None else(self.parent,self.file)
        parent_close=parent.close;file_close=file.close
        final=Finalizer({},primary)
        def retire():
            final.attempt('embedding final readback',lambda:self.check(readback=True))
            final.attempt('original embedding input close',file_close)
            final.attempt('original embedding parent close',parent_close)
        final.shielded(cleanup_signals,retire)
        self.closed=True;self.failed=final.selected()
        if self.failed is not None:_QUARANTINE.append((self,fixed,parent,file,self.value,self.failed))
        final.raise_if_failed()
