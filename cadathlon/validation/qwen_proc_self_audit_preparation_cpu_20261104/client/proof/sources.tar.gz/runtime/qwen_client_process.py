"""One future independently granted client phase in a dedicated process.

This is source preparation. The selected entry and role policy remain disabled;
no packet, grant, resource policy, runtime source or outcome is fabricated here.
The process never issues its own outer receipt or downstream authority.
"""
from dataclasses import dataclass
import hashlib
import os
from pathlib import Path
import stat
from cleanup import cleanup_signals,termination_signals
from cleanup_origin import protect_body
from qwen_finalizer import Finalizer
from qwen_file_contract import canonical,sha,same,hash_value
from qwen_public_parse import parse
from client_role_common import raw_object,obj
from qwen_client_authority_packet import public_from_sources,authenticate_packet,PACKET_LIMIT
from qwen_client_dependencies import policies,exact_environment,hash_installed,imported_origins,AccessScope
from qwen_client_resource import check_capacity
from qwen_key_contract import PublicProfile
from model_output import Output,read,canonical_path,overlap

_QUARANTINE=[]
_ISSUER=object()


def _accessor(value):return(getattr(value,'__self__',None),getattr(value,'__func__',value))
def _same_accessor(a,b):return all(x is y for x,y in zip(_accessor(a),_accessor(b)))
def _state(info):return dict(device=info.st_dev,inode=info.st_ino,size=info.st_size,mtime_ns=info.st_mtime_ns,ctime_ns=info.st_ctime_ns,mode=stat.S_IMODE(info.st_mode))


def admit(args,raw_map,expected,blobs):
    status=raw_object(blobs['qwen_client_entry_status.json'],1<<16,'client source readiness')
    same(status,dict(schema='qwen-client-entry-status-v1',actual_entry_ready=True,actual_grant_present=False,
        closure_preflight_passed=True,dependency_policy_instance_supplied=True,resource_policy_instance_supplied=False,
        source_only=False),'reviewed actual-ready source successor required')
    root=canonical_path(str(Path(__file__).parent))
    static=raw_object(blobs['qwen_client_static_policy.json'],1<<16,'client protected paths')
    obj(static,('schema','protected_paths'),'client protected paths')
    if static['schema']!='qwen-client-static-policy-v1'or type(static['protected_paths'])is not list:
        raise ValueError('exact client protected-path policy required')
    protected=tuple(canonical_path(p)for p in static['protected_paths'])
    records={}
    def public(path,digest,limit):
        hash_value(digest);p=canonical_path(path)
        if p.suffix.lower()in('.npy','.npz','.parquet','.safetensors')or any(overlap(p,r)for r in(root,*protected)):
            raise ValueError('public proof path overlaps source or protected body')
        raw=read(p,limit=limit,expected=digest);records[str(p)]=(digest,limit,raw);return raw
    packet_raw=public(args.packet,args.packet_sha256,PACKET_LIMIT)
    # The archive is an externally pinned source artifact, not a model body.
    archive_raw=public(args.archive,args.archive_sha256,64<<20)
    packet=authenticate_packet(public_from_sources(blobs),packet_raw,expected_sha256=args.packet_sha256)
    phase=packet.phase;role=phase.conditional.expected_pins.check();grant=parse(phase.grant_bytes)
    same(role['source_map'],expected,'complete actual client source differs')
    if sha(raw_map)!=args.manifest_sha256 or role['source_manifest_sha256']!=sha(raw_map):raise ValueError('canonical actual client map differs')
    if role['source_archive_sha256']!=args.archive_sha256 or sha(archive_raw)!=args.archive_sha256:raise ValueError('external actual client archive differs')
    if parse(phase.conditional.grant_bytes)['source_root']!=str(root)or role['role']!=args.role or grant['role']!=args.role:
        raise ValueError('actual client source/role differs from independent grant')
    dep,res=policies(packet)
    # These two policy documents belong to the complete reviewed source map.
    if packet.dependency_policy!=blobs['qwen_client_dependencies.json']or packet.role_policy!=blobs['qwen_client_role_policy.json']:
        raise ValueError('actual dependency/role policy is not selected source bytes')
    model_roots=tuple(canonical_path(v['path'])for v in phase.conditional.model.stores.check()['roots'].values())
    protected=protected+model_roots
    stores=tuple(canonical_path(v['path'])for v in grant['key_stores'].values())
    input_path=canonical_path(grant['input']['path']if args.role=='request_producer'else grant['input']['root']['path'])
    leaves=tuple(canonical_path(v['path'])for v in grant['outputs'].values())
    for i,leaf in enumerate(leaves):
        if any(overlap(leaf,b)for b in(root,*protected,*stores,input_path,*leaves[:i],*map(Path,records))):
            raise ValueError('owned output overlaps source/proof/borrowed body')
        try:leaf.lstat()
        except FileNotFoundError:pass
        else:raise FileExistsError('independently granted client output must be fresh')
    for name in records:
        if any(overlap(Path(name),p)for p in(*protected,*stores,input_path)):
            raise ValueError('public authority file overlaps an authenticated body scope')
    for name in dep['library_roots']:
        if any(overlap(Path(name),p)for p in(root,*protected,*stores,input_path,*leaves)):
            raise ValueError('installed library root overlaps client data or source')
    if any(overlap(input_path,p)or any(overlap(k,p)for k in stores)for p in protected):
        raise ValueError('client input/key scope overlaps protected model/calibration data')
    p=packet.public.check();profile=PublicProfile.from_bytes(p['inputs/profile_audit.json'],p['inputs/actual_key_plan.json'])
    return packet,profile,dep,res,records,tuple(map(str,protected))


@dataclass(frozen=True)
class RuntimeAdmission:
    phase:object
    core:object
    _issuer:object
    _control:object
    def check(self):
        if type(self)is not RuntimeAdmission or self._issuer is not _ISSUER:raise PermissionError('original process-issued runtime required')
        self._control(self,'check',None);return self
    def allow_embedding_input(self):self._control(self,'embedding',None)
    def allow_response_input(self):self._control(self,'response',None)
    def admit_complete_response(self,owner):self._control(self,'complete_response',owner)
    def retire_complete_response(self,owner):self._control(self,'retired_response',owner)
    def allow_key_reads(self):self._control(self,'keys',None)
    def require_key_read_scope(self):self._control(self,'require_keys',None)
    def publish_private_result(self,raw,*,shape,dtype):return self._control(self,'publish',(raw,shape,dtype))


def _runtime(packet,core,audit,source_check,publish):
    """One run-local controller retains the original object/callback identities."""
    phase=packet.phase;role=parse(phase.grant_bytes)['role'];state=dict(input=False,keys=False,response=None,response_callbacks=None,retired=False,published=False)
    original={};active=True
    def control(value,action,arg):
        if (not active or value is not original['runtime']or value.phase is not phase or value.core is not core
                or value._issuer is not _ISSUER or value._control is not control):raise ValueError('original client runtime binding changed')
        packet.check();core.check();audit.check()
        if audit.input_enabled is not state['input']or audit.keys_enabled is not state['keys']:raise ValueError('client body-read transition changed')
        if action=='check':return
        if action in('embedding','response'):
            if state['input']or(role=='request_producer')!=(action=='embedding'):raise ValueError('one exact client input transition required')
            source_check();audit.input_enabled=True;state['input']=True;return
        if action=='complete_response':
            from qwen_file_lifecycle import ResponseFiles
            if role!='response_consumer'or not state['input']or state['response']is not None or type(arg)is not ResponseFiles:
                raise ValueError('one complete authenticated response transition required')
            arg.check(readback=True)
            if (arg.closed or len(arg.records)!=38 or arg.response!=phase.server.response_bytes
                    or arg.expected_root!=canonical(parse(phase.grant_bytes)['input']['root'])):
                raise ValueError('complete original held response differs')
            state['response']=arg;state['response_callbacks']=(arg.check,arg.close);return
        if action=='retired_response':
            owner=state['response']
            if role!='response_consumer'or arg is not owner or state['retired']or not owner.closed or owner.failed is not None:
                raise ValueError('same complete response must retire after original key consumers')
            for name,fn in zip(('check','close'),state['response_callbacks']):
                if not _same_accessor(getattr(owner,name),fn):raise ValueError('original response retirement callback changed')
            state['retired']=True;return
        if action=='keys':
            if not state['input']or state['keys']:raise ValueError('one key-read transition after input required')
            if role=='response_consumer':
                owner=state['response']
                if owner is None or state['retired']:raise ValueError('all38 response bodies must authenticate before any private entry')
                check,close=state['response_callbacks']
                if not _same_accessor(owner.check,check)or not _same_accessor(owner.close,close):raise ValueError('original response callbacks changed before private entry')
                check(readback=True)
            source_check();audit.keys_enabled=True;state['keys']=True;return
        if action=='require_keys':
            if not state['keys']:raise PermissionError('private/key read scope has not been admitted')
            return
        if action=='publish':
            if role!='response_consumer'or not state['retired']or not state['keys']or state['published']:
                raise ValueError('one private result after original response/key retirement required')
            raw,shape,dtype=arg
            if type(raw)is not bytes or type(shape)is not tuple or shape!=(1,151936)or any(type(x)is not int for x in shape)or dtype!='float64':
                raise ValueError('complete original immutable result bytes required')
            result=publish(raw,shape,dtype);state['published']=True;return result
        raise ValueError('unselected client transition')
    runtime=RuntimeAdmission(phase,core,_ISSUER,control);original['runtime']=runtime
    def retire():
        nonlocal active
        runtime.check();active=False
    return runtime,retire


def run(args,raw_map,expected,blobs,gate,snapshot,origins):
    packet,profile,dep,res,public_records,protected=admit(args,raw_map,expected,blobs)
    phase=packet.phase;grant=parse(phase.grant_bytes);root=parse(phase.conditional.grant_bytes)['source_root']
    primary=None;audit=None;core=None;runtime=None;retire_runtime=None;result=None;report=None
    evidence=None;evidence_methods={};result_owner=None;result_methods={};result_binding=None
    installed_before=None;platforms=None;origins_after=None;capacity_observations=[];cleanup_report={}
    def source_check():
        if snapshot(expected)!=blobs:raise ValueError('complete selected client source changed')
        origins(expected,core_enabled=gate.core_enabled);packet.check();exact_environment(dep)
        if audit is not None:audit.check()
        if core is not None:core.check()
        for path,(digest,limit,raw)in public_records.items():
            if read(path,limit=limit,expected=digest)!=raw:raise ValueError('independent public authority bytes changed')
    def owner_guard(owner,methods):
        if owner is None:return
        for name,fn in methods.items():
            if not _same_accessor(getattr(owner,name),fn):raise ValueError('original client output callback changed')
    def publish(raw,shape,dtype):
        nonlocal result_owner,result_methods,result_binding
        if result_owner is not None:raise ValueError('private result is single-use')
        output=grant['outputs']['result'];result_owner=Output(output['path'],expected_parent=canonical(output['parent']))
        # Capture close first so any later acquisition/check failure still
        # retires the original owner, without consulting a mutable mirror.
        result_methods['close']=result_owner.close
        for name in('check','write','binding'):result_methods[name]=getattr(result_owner,name)
        captured=result_owner;methods=dict(result_methods);body=None;value=None
        try:
            owner_guard(captured,methods);methods['check']()
            methods['write']('logits.npy',raw);owner_guard(captured,methods)
            descriptor=dict(schema='qwen-client-private-vocabulary-result-v1',shape=list(shape),dtype=dtype,
                sha256=sha(raw),bytes=len(raw),context_id=phase.expected_ids().context_id,
                request_contract_sha256=sha(phase.request_bytes),response_manifest_sha256=sha(phase.server.response_bytes),
                model_id=phase.expected_ids().model_id,scientific_acceptance_claimed=False)
            methods['write']('result.json',canonical(descriptor));owner_guard(captured,methods);methods['check']()
            result_binding=methods['binding']();value=dict(logits_sha256=sha(raw),logits_bytes=len(raw),result_manifest_sha256=sha(canonical(descriptor)))
        except BaseException as error:body=protect_body(error)
        finally:
            final=Finalizer({},body)
            def close_result():
                final.attempt('original result callbacks',lambda:owner_guard(captured,methods))
                final.attempt('original private result retirement',lambda:methods['close'](primary=final.selected()))
                final.attempt('original result callbacks after retirement',lambda:owner_guard(captured,methods))
            final.shielded(cleanup_signals,close_result)
            chosen=final.selected()
            if chosen is not None:_QUARANTINE.append((captured,methods,raw,chosen));raise chosen
        return value
    try:
        exact_environment(dep);source_check()
        audit=AccessScope(root,expected,public_records,phase,profile,dep,res,protected);audit.install()
        capacity_observations.append(check_capacity(phase,packet.resource_policy,packet.resource_review,after_import=False))
        installed_before=hash_installed(dep)
        from qwen_backend_identity import install_core
        core=install_core(root,blobs,expected,gate=gate);gate.core_enabled=True
        core.load(('he_params','key_gen','ckks_ctx','polynomial'))
        import jax
        import numpy
        platforms=[str(d.platform)for d in jax.devices()]
        if not platforms or any(p!='cpu'for p in platforms)or jax.config.jax_enable_x64 is not True:
            raise ValueError('genuine CPU/x64 dependency runtime required')
        imported_origins(dep,root);same(hash_installed(dep),installed_before,'installed source changed during import')
        capacity_observations.append(check_capacity(phase,packet.resource_policy,packet.resource_review,after_import=True))
        source_check();audit.enabled=True
        destination=grant['outputs']['evidence'];evidence=Output(destination['path'],expected_parent=canonical(destination['parent']))
        evidence_methods['close']=evidence.close
        for name in('check','write'):evidence_methods[name]=getattr(evidence,name)
        runtime,retire_runtime=_runtime(packet,core,audit,source_check,publish)
        from qwen_client_orchestration import execute_request,execute_response
        with termination_signals():
            result=(execute_request if args.role=='request_producer'else execute_response)(runtime)
        runtime.check();source_check()
        if type(result)is not dict or result.get('complete')is not True:raise ValueError('complete client role result required')
        origins_after=imported_origins(dep,root);same(hash_installed(dep),installed_before,'installed source changed during client phase')
        # Context/key/file consumers have retired before terminal publication.
        # A later output close/audit failure still escapes to entry status70;
        # report existence alone never proves independent normal-zero exit.
        report=dict(schema='qwen-actual-client-report-v1',role=args.role,passed=True,complete=True,error_type=None,
            source_manifest_sha256=sha(raw_map),source_archive_sha256=args.archive_sha256,public_packet_sha256=args.packet_sha256,
            conditional_grant_sha256=sha(phase.conditional.grant_bytes),phase_grant_sha256=sha(phase.grant_bytes),
            request_contract_sha256=sha(phase.request_bytes),context_id=phase.expected_ids().context_id,model_id=phase.expected_ids().model_id,
            model_evidence=phase.conditional.expected_pins.check()['model_evidence'],key_evidence=phase.expected_pins.check()['key_evidence'],
            source_hashes_before=expected,source_hashes_after=expected,policies=phase.conditional.expected_pins.check()['policies'],
            result=result,process=dict(pid=os.getpid(),pgid=os.getpgrp()),audit_denials=[],
            backend=dict(platforms=platforms,jax_enable_x64=True,installed_source_count=len(installed_before),
                installed_source_hashes_sha256=sha(canonical(installed_before)),module_origin_count=len(origins_after),
                module_origins_sha256=sha(canonical(origins_after))),
            capacity=capacity_observations,checks=dict(public_model_and_key_readiness_before_body=True,original_owner_retirement_completed=True,
                source_postcheck_completed=True,installed_source_postcheck_completed=True,termination_scope_completed=True),
            scope=dict(request_encryption=args.role=='request_producer',response_decryption=args.role=='response_consumer',key_generation=False,
                model_body_reads=False,model_forward=False,token_or_calibration_reads=False,scientific_acceptance_claimed=False,downstream_execution_authorized=False))
        owner_guard(evidence,evidence_methods);evidence_methods['check']();evidence_methods['write']('report.json',canonical(report));evidence_methods['check']();audit.check()
    except BaseException as error:primary=protect_body(error)
    finally:
        original_evidence=evidence;original_methods=dict(evidence_methods);original_runtime=runtime;original_retire=retire_runtime
        final=Finalizer(cleanup_report,primary)
        def retire():
            final.attempt('complete client source and public proof postcheck',source_check)
            if audit is not None:final.attempt('client sticky audit after publication',audit.check)
            if original_retire is not None:final.attempt('original runtime retirement',original_retire)
            if primary is not None and 'write'in original_methods:
                def incomplete():
                    owner_guard(original_evidence,original_methods);original_methods['check']()
                    original_methods['write']('failure.json',canonical(dict(schema='qwen-client-incomplete-v1',role=args.role,passed=False,complete=False,
                        error_type=type(primary).__name__,source_manifest_sha256=sha(raw_map),phase_grant_sha256=sha(phase.grant_bytes),
                        process=dict(pid=os.getpid(),pgid=os.getpgrp()),actual_readiness=False)))
                final.attempt('bounded class-only incomplete evidence',incomplete)
            if 'close'in original_methods:
                final.attempt('original evidence callback identity',lambda:owner_guard(original_evidence,original_methods))
                final.attempt('original evidence retirement',lambda:original_methods['close'](primary=final.selected()))
            if audit is not None:
                final.attempt('terminal sticky audit veto',audit.check)
                final.attempt('original audit wrapper retirement',audit.close)
        final.shielded(cleanup_signals,retire)
        chosen=final.selected()
        if chosen is not None:
            _QUARANTINE.append((packet,core,audit,original_runtime,original_retire,original_evidence,original_methods,result_owner,dict(result_methods),result_binding,result,chosen));raise chosen
    return 0
