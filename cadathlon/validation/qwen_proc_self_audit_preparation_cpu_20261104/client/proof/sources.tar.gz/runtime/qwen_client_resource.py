"""Exact externally reviewed client resource policy; no default allocation.

Known logical byte counts below are not peak-memory bounds. The root-selected
policy and its separately pinned review must justify working/headroom values.
Checks observe the current process and original granted output-parent FDs; they
never reserve space, alter affinity/limits or construct a backend/context.
"""
from pathlib import Path
import os
import resource
import stat
from client_role_admission import PhaseAdmission
from client_role_common import raw_object,obj,integer
from qwen_file_contract import canonical,sha,same
from qwen_finalizer import Finalizer

_QUARANTINE=[]
COVERAGE=('client_key_authentication_mapping_lifetimes','original_python_secret_context_representation',
    'default_codec_CRT_FFT_scratch','JAX_CPU_allocator_and_compilation','retained_ciphertext_and_decode_snapshots',
    'parent_and_output_descriptor_peak','same_filesystem_combined_publication','host_memory_reserve')


def logical_facts(phase):
    phase.check();request=raw_object(phase.request_bytes,1<<20,'request')
    which=phase.conditional.expected_pins.check()['role']
    tiles=request['input']['input_tile_count']
    return dict(public_key_authentication_bytes=159807176704,retained_pke_raw_bytes=104857600,
        retained_secret_raw_bytes=52428800,largest_other_public_mapping_bytes=478150656,
        request_ciphertext_raw_bytes=tiles*104857600,response_ciphertext_raw_bytes=239075328,
        complete_decode_snapshot_bytes=19922944,full_vocabulary_float64_bytes=1215488,
        result_raw_bytes=tiles*104857600 if which=='request_producer'else 1215488,
        these_are_peak_RSS_bounds=False)


def authenticate_policy(phase,policy_bytes,review_bytes):
    if type(phase)is not PhaseAdmission:raise TypeError('exact complete phase required before resources')
    phase.check();pins=phase.conditional.expected_pins.check();which=pins['role'];policies=pins['policies']
    if sha(policy_bytes)!=policies['resource_policy_sha256']or sha(review_bytes)!=policies['resource_review_sha256']:
        raise ValueError('independently pinned resource policy/review differs')
    policy=raw_object(policy_bytes,1<<16,'client resource policy')
    fields={'schema','role','cores','import_headroom_bytes','working_memory_required_bytes','host_memory_reserve_bytes','additional_fds_required','storage_required_bytes','filesystem_reserve_bytes','logical_facts','cgroup_memory_current','cgroup_memory_max'}
    obj(policy,fields,'client resource policy')
    if policy['schema']!='qwen-client-resource-policy-v1'or policy['role']!=which:raise ValueError('exact client resource role required')
    cores=policy['cores']
    if type(cores)is not list or not 0<len(cores)<=256 or any(type(c)is not int or c<0 for c in cores)or cores!=sorted(set(cores)):
        raise ValueError('externally chosen exact CPU affinity required')
    for name in('import_headroom_bytes','working_memory_required_bytes','host_memory_reserve_bytes','additional_fds_required','filesystem_reserve_bytes'):
        integer(policy[name],1,name)
    for name,leaf in(('cgroup_memory_current','memory.current'),('cgroup_memory_max','memory.max')):
        value=policy[name]
        if type(value)is not str or not value.startswith('/sys/fs/cgroup/')or str(Path(value))!=value or '..'in Path(value).parts or Path(value).name!=leaf:
            raise ValueError('exact externally selected cgroup memory paths required')
    if Path(policy['cgroup_memory_current']).parent!=Path(policy['cgroup_memory_max']).parent:
        raise ValueError('one cgroup memory policy required')
    obj(policy['storage_required_bytes'],('result','evidence'),'separate publication capacity')
    for value in policy['storage_required_bytes'].values():integer(value,1,'publication capacity')
    facts=logical_facts(phase);same(policy['logical_facts'],facts,'source-derived logical facts differ')
    if policy['storage_required_bytes']['result']<=facts['result_raw_bytes']:
        raise ValueError('publication capacity must include header/container overhead')
    review=raw_object(review_bytes,1<<16,'independent client resource review')
    expected=dict(schema='qwen-client-resource-review-v1',role=which,
        policy_sha256=sha(policy_bytes),source_manifest_sha256=pins['source_manifest_sha256'],
        source_archive_sha256=pins['source_archive_sha256'],approved=True,coverage={n:True for n in COVERAGE},
        source_logical_counts_are_peak_RSS_bound=False,resource_allocation_performed=False)
    same(review,expected,'complete independent resource reasoning review required')
    return policy


def _close(fd,label,primary=None):
    final=Finalizer({},primary)
    def retire():
        try:os.close(fd)
        except BaseException as error:_QUARANTINE.append((fd,label,error));raise
    final.attempt(label,retire);final.raise_if_failed()


def _kernel(path,limit=1<<20):
    fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NONBLOCK);primary=None
    try:
        blocks=[];size=0
        while size<=limit:
            block=os.read(fd,min(65536,limit+1-size))
            if not block:break
            blocks.append(block);size+=len(block)
        if not 0<size<=limit:raise ValueError('bounded kernel metadata required')
        return b''.join(blocks).decode('ascii')
    except BaseException as error:primary=error;raise
    finally:_close(fd,'kernel memory descriptor retirement',primary)


def check_capacity(phase,policy_bytes,review_bytes,*,after_import):
    if type(after_import)is not bool:raise TypeError('exact capacity phase required')
    policy=authenticate_policy(phase,policy_bytes,review_bytes)
    if set(os.sched_getaffinity(0))!=set(policy['cores']):raise ValueError('actual CPU affinity differs from reviewed client policy')
    def kibibytes(path,label):
        rows=[x.split()for x in _kernel(path).splitlines()if x.startswith(label+':')]
        if len(rows)!=1 or len(rows[0])!=3 or rows[0][2]!='kB'or not rows[0][1].isdecimal():raise ValueError('exact kernel memory observation required')
        return int(rows[0][1])*1024
    available=kibibytes('/proc/meminfo','MemAvailable');rss=kibibytes('/proc/self/status','VmRSS')
    groups=[x.split(':',2)for x in _kernel('/proc/self/cgroup').splitlines()]
    unified=[x[2]for x in groups if len(x)==3 and x[:2]==['0','']]
    if len(unified)!=1:raise ValueError('one current cgroup-v2 scope required')
    current_path=Path('/sys/fs/cgroup')/unified[0].lstrip('/')/'memory.current'
    if str(current_path)!=policy['cgroup_memory_current']:raise ValueError('reviewed memory group is not this process')
    current_text=_kernel(policy['cgroup_memory_current']).strip();maximum_text=_kernel(policy['cgroup_memory_max']).strip()
    if not current_text.isdecimal()or not(maximum_text=='max'or maximum_text.isdecimal()):raise ValueError('exact current cgroup observation required')
    current=int(current_text);maximum=None if maximum_text=='max'else int(maximum_text)
    if maximum is not None and maximum<current:raise MemoryError('current cgroup limit exceeded')
    mounts=[]
    for line in _kernel('/proc/self/mountinfo').splitlines():
        left,separator,right=line.partition(' - ');fields=left.split();post=right.split()
        if not separator or len(fields)<6 or len(post)<3:raise ValueError('complete kernel mount metadata required')
        decoded=fields[4].replace('\\040',' ').replace('\\011','\t').replace('\\012','\n').replace('\\134','\\')
        mounts.append((Path(decoded),post[0]))
    soft,_=resource.getrlimit(resource.RLIMIT_NOFILE);open_count=len(os.listdir('/proc/self/fd'))
    if soft!=resource.RLIM_INFINITY and soft-open_count<policy['additional_fds_required']:
        raise OSError('reviewed client descriptor headroom unavailable')
    outputs=raw_object(phase.grant_bytes,1<<16,'phase grant')['outputs'];groups={};observed={};tmpfs_charge=0
    for role,description in outputs.items():
        expected=description['parent'];path=Path(expected['path'])
        if path.resolve()!=path:raise ValueError('granted output parent symlink alias differs')
        fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC);primary=None
        try:
            held=os.fstat(fd);named=path.lstat()
            for info in(held,named):
                mode=stat.S_IMODE(info.st_mode)
                if not stat.S_ISDIR(info.st_mode)or info.st_uid not in(0,os.geteuid())or(mode&0o022 and not mode&stat.S_ISVTX):
                    raise ValueError('trusted granted output parent required')
                same(dict(path=str(path),device=info.st_dev,inode=info.st_ino,mode=mode),expected,'original granted output parent differs')
            fs=os.fstatvfs(fd);free=fs.f_bavail*fs.f_frsize
            entry=groups.setdefault(held.st_dev,dict(required=policy['filesystem_reserve_bytes'],free=free))
            entry['required']+=policy['storage_required_bytes'][role];entry['free']=min(entry['free'],free)
            matches=[(p,t)for p,t in mounts if p==path or p in path.parents]
            if not matches:raise ValueError('output mount type unavailable')
            mount,kind=max(matches,key=lambda item:len(item[0].parts))
            if kind in('tmpfs','ramfs'):tmpfs_charge+=policy['storage_required_bytes'][role]
            observed[role]=dict(device=held.st_dev,parent_inode=held.st_ino,available_bytes=free,mount=str(mount),filesystem=kind)
            # This parent is observed/closed only; the subsequent writer must
            # independently compare its own original held FD before mkdir.
            again=os.fstat(fd)
            if (again.st_dev,again.st_ino,again.st_uid,stat.S_IMODE(again.st_mode))!=(held.st_dev,held.st_ino,held.st_uid,stat.S_IMODE(held.st_mode)):
                raise ValueError('capacity parent changed during check')
        except BaseException as error:primary=error;raise
        finally:_close(fd,'capacity parent retirement',primary)
    if any(row['free']<row['required']for row in groups.values()):raise OSError('reviewed combined publication capacity unavailable')
    headroom=policy['working_memory_required_bytes']if after_import else policy['import_headroom_bytes']
    required=headroom+policy['host_memory_reserve_bytes']+tmpfs_charge
    if available<required or(maximum is not None and maximum-current<required):raise MemoryError('reviewed client memory/cgroup headroom unavailable')
    return dict(after_import=after_import,observed_rss_bytes=rss,cgroup_current_bytes=current,cgroup_max_bytes=maximum,
        tmpfs_publication_charge_bytes=tmpfs_charge,available_memory_bytes=available,required_memory_bytes=required,
        fd_soft_limit=None if soft==resource.RLIM_INFINITY else soft,open_fd_observation=open_count,
        additional_fds_required=policy['additional_fds_required'],outputs=observed,
        capacity_reserved=False,peak_RSS_measured=False)
