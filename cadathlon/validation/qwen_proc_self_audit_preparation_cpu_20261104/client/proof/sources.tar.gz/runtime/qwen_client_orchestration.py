"""Private actual-stage composition; public entry is still default denied.

The selected process owns RuntimeAdmission and audit/resource transitions.
These functions do not derive trusted pins, grant themselves authority, or
publish an outer process receipt. They never load model/token inputs or generate
keys. Every original owner/callback is captured before a later callback runs.
"""
import io
import json
import numpy as np
from cleanup import cleanup_signals
from cleanup_origin import protect_body
from qwen_finalizer import Finalizer
from qwen_file_contract import canonical,sha,same
from client_role_common import raw_object
from qwen_client_backend import ClientBackend,_runtime
from qwen_client_input_files import OriginalEmbeddingFile
from qwen_key_contract import PublicProfile,authenticate_public,authenticate_private,PRIVATE_LIMIT
from qwen_key_files_admission import bind_files
from qwen_key_readers import read_metadata
from qwen_file_lifecycle import ProducerTerminal,ResponseFiles
from client_stage import _publish_input,_consume_output,_capture,_check_callbacks

_QUARANTINE=[]


def _admit_files(runtime,backend):
    """First private manifest read, after complete response admission if output."""
    _runtime(runtime);backend.check();runtime.require_key_read_scope()
    phase=runtime.phase;public=phase.conditional.intent.public;expected=phase.expected_ids()
    p=public.check();profile=PublicProfile.from_bytes(p['inputs/profile_audit.json'],p['inputs/actual_key_plan.json'])
    binding=authenticate_public(phase.readiness.public_manifest_bytes,profile,expected,role='client')
    backend.dependencies.security_check(profile.parameters)
    owner=None;close=None;primary=None;result=None
    try:
        private=raw_object(phase.grant_bytes,1<<16,'phase grant')['key_stores']['private']
        owner=backend.dependencies.directory_factory(private['path'],private=True)
        close=owner.close
        raw=read_metadata(owner,'private_manifest.json',PRIVATE_LIMIT)
        private_binding=authenticate_private(raw,binding)
        result=bind_files(public,binding,canonical(json.loads(phase.request_bytes)['public']),private_binding)
        owner.check();backend.check();runtime.require_key_read_scope()
    except BaseException as error:primary=protect_body(error)
    finally:
        final=Finalizer({},primary)
        if close is not None:final.attempt('original private manifest directory retirement',close)
        final.attempt('client runtime after manifest retirement',runtime.check)
        selected=final.selected()
        if selected is not None:_QUARANTINE.append((runtime,backend,owner,close,result,selected))
        final.raise_if_failed()
    return result


def execute_request(runtime):
    _runtime(runtime)
    phase=runtime.phase;grant=raw_object(phase.grant_bytes,1<<16,'phase grant')
    if grant['role']!='request_producer':raise ValueError('exact request phase required')
    backend=ClientBackend(runtime);embedding=None;callbacks=[];primary=None;published=None;close=None
    try:
        runtime.allow_embedding_input()
        embedding=OriginalEmbeddingFile(phase)
        close=_capture(embedding,'close',callbacks);check=_capture(embedding,'check',callbacks)
        values=check(readback=True)
        runtime.allow_key_reads()
        admission=_admit_files(runtime,backend)
        request=json.loads(phase.request_bytes)
        published=_publish_input(admission,grant['key_stores']['public']['path'],grant['key_stores']['private']['path'],
            request_id=request['request_id'],embeddings=values,positions=tuple(request['input']['original_positions']),
            key_dependencies=backend.dependencies,factories=backend.input_factories())
        _check_callbacks(callbacks);check(readback=True);runtime.check()
        if published.contract_bytes!=phase.request_bytes:raise ValueError('published request differs from exact phase contract')
    except BaseException as error:primary=protect_body(error)
    finally:
        final=Finalizer({},primary)
        def retire():
            final.attempt('original embedding callbacks',lambda:_check_callbacks(callbacks))
            if close is not None:final.attempt('original embedding retirement',lambda:close(primary=final.selected()))
            final.attempt('original embedding callbacks after retirement',lambda:_check_callbacks(callbacks))
            final.attempt('client runtime after request retirement',runtime.check)
        final.shielded(cleanup_signals,retire)
        error=final.selected()
        if error is not None:_QUARANTINE.append((runtime,backend,embedding,tuple(callbacks),published,error))
        final.raise_if_failed()
    return dict(request_contract_sha256=sha(published.contract_bytes),request_manifest_sha256=sha(published.manifest_bytes),
        input_digest=published.input_digest,input_ciphertext_count=grant['input']['shape'][1]//16+(1 if grant['input']['shape'][1]%16 else 0),
        complete=True,context_and_key_consumers_retired=True,original_embedding_readback_completed=True)


def _response_owner(runtime):
    phase=runtime.phase;server=phase.server;server.check()
    grant=raw_object(phase.grant_bytes,1<<16,'phase grant');public=phase.conditional.intent.public
    request=json.loads(phase.request_bytes);pins=server.expected_pins.check()
    inner=ProducerTerminal.authenticate(public,request,server.input_digest,server.response_bytes,
        report_bytes=server.inner_report_bytes,report_sha256=pins['inner_report_sha256'],
        outer_bytes=server.inner_outer_bytes,outer_sha256=pins['inner_outer_sha256'])
    # The separate server source/grant/outer/root envelope was reauthenticated
    # above. The legacy inner producer field keeps request-source provenance.
    return ResponseFiles(public,request,server.input_digest,server.response_bytes,grant['input']['root']['path'],
        terminal=inner,producer_report_sha256=pins['inner_report_sha256'],producer_outer_sha256=pins['inner_outer_sha256'],
        expected_root=canonical(grant['input']['root']))


def execute_response(runtime):
    _runtime(runtime)
    phase=runtime.phase;grant=raw_object(phase.grant_bytes,1<<16,'phase grant')
    if grant['role']!='response_consumer':raise ValueError('exact response phase required')
    response=None;callbacks=[];close=None;primary=None;result=None;backend=None;result_evidence=None
    try:
        runtime.allow_response_input()
        response=_response_owner(runtime)
        close=_capture(response,'close',callbacks);check=_capture(response,'check',callbacks)
        check(readback=True);_check_callbacks(callbacks)
        # No private-manifest/key/context entry occurs before all38 payloads and
        # their six-field schemas, immutable snapshots and original roots pass.
        runtime.admit_complete_response(response)
        backend=ClientBackend(runtime)
        runtime.allow_key_reads()
        admission=_admit_files(runtime,backend)
        result=_consume_output(admission,grant['key_stores']['public']['path'],grant['key_stores']['private']['path'],
            json.loads(phase.request_bytes),phase.server.input_digest,key_dependencies=backend.dependencies,
            factories=backend.output_factories(response))
        # _consume_output retired all CT consumers INSIDE key-loader scope, then
        # retired the same response owner. Do not invoke its close a second time.
        _check_callbacks(callbacks)
        if not response.closed:raise ValueError('original complete response owner was not retired')
        runtime.retire_complete_response(response)
        runtime.check()
        if (type(result)is not np.ndarray or result.dtype!=np.dtype('float64')or result.shape!=(1,151936)
                or result.flags.writeable or not np.isfinite(result).all()):
            raise ValueError('complete finite immutable vocabulary result required')
        # At most 1,215,488 raw bytes plus a bounded ordinary NPY header. This
        # small private result buffer is not a key/model array or RSS bound.
        stream=io.BytesIO();np.save(stream,result,allow_pickle=False);raw=stream.getvalue()
        if not result.nbytes<len(raw)<=result.nbytes+16384:raise ValueError('bounded vocabulary NPY result extent differs')
        result_evidence=runtime.publish_private_result(raw,shape=(1,151936),dtype='float64')
        runtime.check()
    except BaseException as error:primary=protect_body(error)
    finally:
        final=Finalizer({},primary)
        def retire():
            final.attempt('original response callbacks before retirement',lambda:_check_callbacks(callbacks))
            if close is not None and not response.closed:
                final.attempt('original response cleanup',lambda:close(primary=final.selected()))
            final.attempt('original response callbacks after retirement',lambda:_check_callbacks(callbacks))
            final.attempt('client runtime after response retirement',runtime.check)
        final.shielded(cleanup_signals,retire)
        selected=final.selected()
        if selected is not None:_QUARANTINE.append((runtime,backend,response,tuple(callbacks),result,result_evidence,selected))
        final.raise_if_failed()
    return dict(response_manifest_sha256=grant['input']['response_manifest_sha256'],input_digest=phase.server.input_digest,
        output_ciphertext_count=38,vocabulary_columns=151936,private_result=result_evidence,
        complete=True,all_response_payloads_before_private_entry=True,context_and_key_consumers_retired=True,
        default_decoder_approximation_check_enabled=True,scientific_acceptance_claimed=False)
