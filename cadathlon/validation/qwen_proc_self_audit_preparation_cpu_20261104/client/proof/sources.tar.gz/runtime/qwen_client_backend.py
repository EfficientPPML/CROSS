"""Source-fixed client dependencies behind the prospective process admission.

This module is stdlib/pure-authority only at import. Its internal factory needs
an exact RuntimeAdmission from the selected process. Public role entry remains
disabled. No selected call can generate keys; the loader patches both aliases
before constructing the borrowed client context. Resource bounds are supplied
by an independently reviewed exact policy, never chosen here.
"""
from dataclasses import dataclass
from types import SimpleNamespace
from pathlib import Path
import json
import os
import stat
from client_role_admission import PhaseAdmission
from client_role_common import raw_object
from qwen_file_contract import canonical,same


def _runtime(value):
    from qwen_client_process import RuntimeAdmission
    if type(value)is not RuntimeAdmission:raise PermissionError('complete source-fixed client runtime admission required')
    value.check()
    return value


def _file_state(info):
    return dict(device=info.st_dev,inode=info.st_ino,size=info.st_size,
        mtime_ns=info.st_mtime_ns,ctime_ns=info.st_ctime_ns,mode=stat.S_IMODE(info.st_mode))


@dataclass(frozen=True)
class ActualDependencies:
    backend:object
    security_check:object
    runtime_factory:object
    directory_factory:object
    map_array:object

    def check(self,admission,public_keys,client_private):
        if type(self)is not ActualDependencies or type(self.backend)is not ClientBackend:
            raise PermissionError('exact actual client dependency binding required')
        self.backend.check()
        if self.backend.dependencies is not self:raise ValueError('original actual client dependencies changed')
        from qwen_key_files_admission import FilesAdmission
        if type(admission)is not FilesAdmission:raise TypeError('complete file admission required before key reader')
        admission.check()
        phase=self.backend.phase;grant=raw_object(phase.grant_bytes,1<<16,'phase grant')
        stores=grant['key_stores']
        if str(public_keys)!=stores['public']['path']or str(client_private)!=stores['private']['path']:
            raise ValueError('actual client key paths differ from independent phase grant')
        if (admission.public_contract.blobs!=phase.conditional.intent.public.blobs
                or admission.keys.public.raw!=phase.readiness.public_manifest_bytes
                or admission.keys.public.expected!=phase.expected_ids()
                or admission.keys.private is None):
            raise ValueError('actual client file admission differs from generated readiness')
        same(admission.keys.check(),json.loads(phase.request_bytes)['public'],'actual client request identity differs')


@dataclass(frozen=True)
class ActualInputFactories:
    backend:object
    publisher:object
    secure:object
    shield:object


@dataclass(frozen=True)
class ActualOutputFactories:
    backend:object
    response_files:object
    materialize:object
    secure:object
    shield:object


class ClientBackend:
    """Original module/callback binding for one admitted, serial client phase."""
    def __init__(self,runtime):
        _runtime(runtime)
        self.runtime=runtime;self.phase=runtime.phase;self.core=runtime.core
        if type(self.phase)is not PhaseAdmission:raise TypeError('exact complete client phase required')
        self.phase.check()
        modules=self.core.load(('he_params','key_gen','ckks_ctx','polynomial'))
        self.he_params=modules['he_params'];self.key_gen=modules['key_gen']
        self.ckks=modules['ckks_ctx'];self.polynomial=modules['polynomial']
        self.security_identity=self.core.retain('he_params',('DEFAULT_SIGMA','SECRET_DISTRIBUTION','SecurityTarget','qp_is_secure','assert_p_coverage'))
        self.context_identity=self.core.retain('ckks_ctx',('CKKSContext','evict_context_caches'))
        self.polynomial_identity=self.core.retain('polynomial',('Polynomial','_POLYNOMIAL_REGISTRY'))
        # Installed-module and local helper provenance is enforced by the
        # original runtime gate before these selected imports are enabled.
        import jax
        from support import require_secure_execution
        from qwen_key_readers import ReadDirectory,map_array
        from cleanup import cleanup_signals
        self.jax=jax;self.secure=require_secure_execution;self.shield=cleanup_signals
        self._base_directory=ReadDirectory;self._base_map_array=map_array
        runtime.check()
        phase=self.phase;backend=self
        stores=raw_object(phase.grant_bytes,1<<16,'phase grant')['key_stores']
        store_bytes=canonical(stores)

        class GrantedKeyDirectory(ReadDirectory):
            def __init__(owner,path,*,private=False):
                backend.check()
                family='private'if private else'public';expected=json.loads(store_bytes)[family]
                if str(path)!=expected['path']or Path(path).resolve()!=Path(path):
                    raise ValueError('exact granted original key root required')
                owner.expected=canonical(expected);owner.family=family
                super().__init__(path,private=private)
            def check(owner):
                super().check()
                expected=json.loads(owner.expected)
                if canonical(expected)!=canonical(json.loads(store_bytes)[owner.family]):raise ValueError('original key store binding changed')
                for info in(os.fstat(owner.fd),owner.path.lstat()):
                    same(dict(path=str(owner.path),device=info.st_dev,inode=info.st_ino,mode=stat.S_IMODE(info.st_mode)),
                        {n:expected[n]for n in('path','device','inode','mode')},'independently retained key root differs')
                    if info.st_uid!=os.geteuid():raise ValueError('retained client key root owner differs')
                parent=owner.path.parent.lstat()
                same(dict(path=str(owner.path.parent),device=parent.st_dev,inode=parent.st_ino,mode=stat.S_IMODE(parent.st_mode)),
                    expected['parent'],'independently retained key parent differs')
                manifest=expected['manifest'];named=os.stat(manifest['name'],dir_fd=owner.fd,follow_symlinks=False)
                if not stat.S_ISREG(named.st_mode)or named.st_uid!=os.geteuid():raise ValueError('original retained key manifest required')
                same(_file_state(named),manifest['state'],'independently retained key manifest identity differs before body')

        def security_check(parameters):
            backend.check();p=phase.conditional.intent.public.profile();same(parameters,p,'actual loaded profile differs')
            h=backend.he_params
            if type(p['sigma'])is not float or p['sigma']!=h.DEFAULT_SIGMA or p['secret_distribution']!=h.SECRET_DISTRIBUTION:
                raise ValueError('fixed security distributions differ')
            if not h.qp_is_secure(p['q_towers'],p['p_towers'],p['degree'],h.SecurityTarget(128,'classical')):
                raise ValueError('actual full QP ring is insecure')
            h.assert_p_coverage(p['q_towers'],p['p_towers'],p['dnum'])
            backend.check()

        def runtime_factory():
            backend.check()
            return SimpleNamespace(Context=backend.ckks.CKKSContext,jax=backend.jax,ckks=backend.ckks,
                polynomial=backend.polynomial,key_modules={'key_gen':backend.key_gen,'jaxite_word.key_gen':backend.key_gen})

        def bound_map_array(owner,name,description,shape,moduli):
            backend.check();owner.check()
            return map_array(owner,name,description,shape,moduli)

        self.dependencies=ActualDependencies(self,security_check,runtime_factory,GrantedKeyDirectory,bound_map_array)
        self._fixed=(runtime,self.phase,self.core,self.he_params,self.key_gen,self.ckks,self.polynomial,
            self.security_identity,self.context_identity,self.polynomial_identity,self.jax,self.secure,self.shield,
            self._base_directory,self._base_map_array,self.dependencies)
        self._dependency_callbacks=(security_check,runtime_factory,GrantedKeyDirectory,bound_map_array)
        self.check()

    def check(self):
        _runtime(self.runtime)
        current=(self.runtime,self.phase,self.core,self.he_params,self.key_gen,self.ckks,self.polynomial,
            self.security_identity,self.context_identity,self.polynomial_identity,self.jax,self.secure,self.shield,
            self._base_directory,self._base_map_array,self.dependencies)
        if any(a is not b for a,b in zip(current,self._fixed)):raise ValueError('original client backend binding changed')
        self.phase.check();self.core.check()
        for retained in(self.security_identity,self.context_identity,self.polynomial_identity):retained.check()
        for name,original in zip(('security_check','runtime_factory','directory_factory','map_array'),self._dependency_callbacks):
            if getattr(self.dependencies,name)is not original:raise ValueError('original actual key dependency changed')
        return self

    def input_factories(self):
        self.check()
        if raw_object(self.phase.grant_bytes,1<<16,'phase grant')['role']!='request_producer':raise ValueError('request phase required')
        from qwen_publisher import Publisher
        backend=self;phase=self.phase
        output=raw_object(phase.grant_bytes,1<<16,'phase grant')['outputs']['result']
        def publisher(handle,request):
            backend.check()
            if canonical(request)!=phase.request_bytes:raise ValueError('actual input request differs from phase grant')
            return Publisher(phase.conditional.intent.public,request,'request',output['path'],expected_parent=canonical(output['parent']))
        return ActualInputFactories(self,publisher,self.secure,self.shield)

    def output_factories(self,response_owner):
        self.check()
        from qwen_file_lifecycle import ResponseFiles,AdmittedPayload
        from qwen_backend_composition import _materialize
        if type(response_owner)is not ResponseFiles:raise TypeError('already authenticated complete response owner required')
        backend=self;phase=self.phase;response_owner.check(readback=True)
        def response_files(public,request,input_digest):
            backend.check();response_owner.check(readback=True)
            if (public.blobs!=phase.conditional.intent.public.blobs or canonical(request)!=phase.request_bytes
                    or input_digest!=phase.server.input_digest):raise ValueError('original admitted response request differs')
            return response_owner
        def materialize(ctx,payload,binding):
            backend.check()
            # ResponseFiles owns immutable six-field payload bytes. Make the
            # same ordinary Polynomial as the admitted server/client codec seam.
            import numpy as np
            if type(payload)is not np.ndarray or payload.dtype!=np.dtype('uint32')or payload.flags.writeable:
                raise ValueError('immutable complete response residue snapshot required')
            return _materialize(AdmittedPayload(canonical(binding),payload.tobytes(order='C')))
        return ActualOutputFactories(self,response_files,materialize,self.secure,self.shield)


def admit_stage(admission,dependencies,factories,recording_kind,names):
    if type(dependencies)is not ActualDependencies:raise PermissionError('source-fixed actual dependencies required')
    backend=dependencies.backend;backend.check()
    grant=raw_object(backend.phase.grant_bytes,1<<16,'phase grant')
    dependencies.check(admission,grant['key_stores']['public']['path'],grant['key_stores']['private']['path'])
    expected=ActualInputFactories if recording_kind.__name__=='RecordingInputFactories'else ActualOutputFactories
    if type(factories)is not expected or factories.backend is not backend:raise PermissionError('source-fixed actual client factory binding required')
    selected=tuple(getattr(factories,name)for name in names)
    if any(not callable(fn)for fn in selected):raise TypeError('actual client callbacks required')
    def check():
        backend.check();admission.check()
        if factories.backend is not backend or any(getattr(factories,name)is not original for name,original in zip(names,selected)):
            raise ValueError('original actual client factories changed')
    check();return selected,check
