"""Direct fixed fresh-key process. Preparation status keeps actual entry denied.

There is no recording callback, context constructor or borrowed body loader in
the actual path. Root must separately admit the complete closure and all public
policies before a later ready source can consume an actual grant.
"""
import math
import os
from pathlib import Path
import stat
import sys
from cleanup import cleanup_signals,termination_signals
from cleanup_origin import protect_body
from qwen_finalizer import Finalizer
from qwen_file_contract import PublicContract,canonical,sha,same,hash_value
from qwen_public_parse import parse
from public_source_pins import PUBLIC_PINS
from qwen_key_contract import PublicProfile,ExpectedIds,KEYGEN,bindings,public_body,authenticate_public,authenticate_private
from model_admission import ExpectedModelPins,authenticate_model
from keygen_authority import ActualKeygenIntent,ExpectedLaunchPins,authenticate_launch,CHECK_NAMES,SCOPE_FALSE
from client_role_admission import ExpectedRolePins,authenticate_conditional_role
from keygen_output import Output,read,canonical_path,overlap
from keygen_dependencies import policies,environment,capacity,hash_installed,imported_origins,AccessScope,POLICY_NAMES

_QUARANTINE=[]
MODEL_ROLES=('manifest','report','outer','root_review','expected_pins')
MODEL_LIMITS={'manifest':1<<20,'report':2<<20,'outer':1<<16,'root_review':1<<16,'expected_pins':1<<20}


def obj(value,names,label):
    if type(value)is not dict or set(value)!=set(names):raise ValueError('closed '+label+' fields required')
    return value


def parsed(raw,fields,schema):
    value=parse(raw);obj(value,fields,schema)
    if canonical(value)!=raw or value['schema']!=schema:raise ValueError('canonical '+schema+' required')
    return value


def _accessor(value):return(getattr(value,'__self__',None),getattr(value,'__func__',value))
def same_accessor(a,b):return all(x is y for x,y in zip(_accessor(a),_accessor(b)))
def state(info):return dict(device=info.st_dev,inode=info.st_ino,size=info.st_size,mtime_ns=info.st_mtime_ns,ctime_ns=info.st_ctime_ns,mode=stat.S_IMODE(info.st_mode))


def admit(args,raw_map,expected,blobs):
    ready=parsed(blobs['keygen_entry_status.json'],('schema','actual_entry_ready'),'qwen-keygen-entry-status-v1')
    if ready['actual_entry_ready']is not True:raise PermissionError('actual keygen source remains unready pending complete review')
    root=canonical_path(str(Path(__file__).parent))
    static=parsed(blobs['keygen_static_policy.json'],('schema','protected_paths'),'qwen-keygen-static-policy-v1')['protected_paths']
    if type(static)is not list or any(type(v)is not str for v in static):raise ValueError('exact protected path policy required')
    blocked=[root,*map(canonical_path,static)];public_records={}
    def public(raw_path,digest,limit):
        hash_value(digest);p=canonical_path(raw_path)
        if p.suffix.lower()in('.npy','.npz','.safetensors','.parquet')or any(overlap(p,b)for b in blocked):
            raise ValueError('public authority role overlaps body/source/output')
        raw=read(p,limit=limit,expected=digest)
        old=public_records.get(str(p))
        if old is not None and old!=(digest,limit,raw):raise ValueError('one public path has conflicting roles')
        public_records[str(p)]=(digest,limit,raw)
        return raw
    def descriptor(row,limit):
        obj(row,('path','sha256'),'public descriptor');return public(row['path'],row['sha256'],limit)
    expected_raw=public(args.expected_pins,args.expected_pins_sha256,1<<20)
    pins=ExpectedLaunchPins(expected_raw);pv=pins.check()
    same(pv['source_map'],expected,'complete selected source map differs')
    if pv['source_manifest_sha256']!=sha(raw_map)or sha(raw_map)!=args.manifest_sha256:raise ValueError('actual compact source map differs')
    grant_raw=public(args.grant,args.grant_sha256,1<<16)
    if args.grant_sha256!=pv['grant_sha256']:raise ValueError('independent grant pin differs')
    bundle_raw=public(args.bundle,args.bundle_sha256,2<<20)
    bundle=parsed(bundle_raw,('schema','intent','model','roles','policies','prelaunch_review'),'qwen-keygen-public-inputs-v1')
    public_contract=PublicContract.from_blobs({name:blobs['public_inputs/'+name]for name in PUBLIC_PINS})
    intent_raw=descriptor(bundle['intent'],1<<16);intent=ActualKeygenIntent(public_contract,intent_raw);iv=intent.check()
    if sha(intent_raw)!=pv['intent_sha256']:raise ValueError('independent intent differs')
    leaves=[canonical_path(v)for v in iv['paths'].values()]
    for i,p in enumerate(leaves):
        if any(overlap(p,b)for b in blocked+leaves[:i]+list(map(Path,public_records))):raise ValueError('fresh key/evidence leaf overlaps protected roles')
        try:p.lstat()
        except FileNotFoundError:pass
        else:raise FileExistsError('key/evidence leaf must be fresh')
    blocked.extend(leaves)
    model_desc=obj(bundle['model'],MODEL_ROLES,'model proof descriptors')
    model_raw={name:descriptor(model_desc[name],MODEL_LIMITS[name])for name in MODEL_ROLES}
    def model_for(raw):
        return authenticate_model(public_contract,model_raw['manifest'],model_raw['report'],model_raw['outer'],model_raw['root_review'],expected_pins=ExpectedModelPins(raw))
    model=model_for(model_raw['expected_pins'])
    model_roots=[canonical_path(row['path'])for row in model.stores.check()['roots'].values()]
    if any(overlap(p,b)for p in leaves for b in model_roots):raise ValueError('new key store overlaps model store')
    if any(overlap(Path(p),b)for p in public_records for b in model_roots):raise ValueError('public proof path overlaps model body scope')
    blocked.extend(model_roots)
    launch=authenticate_launch(intent,grant_raw,model,expected_pins=pins)
    grant=parse(grant_raw)
    if grant['source_root']!=str(root):raise ValueError('actual source root differs from grant')
    pre=descriptor(bundle['prelaunch_review'],1<<20)
    if sha(pre)!=pv['prelaunch_review_sha256']or canonical(parse(pre))!=pre:raise ValueError('independent prelaunch review bytes differ')
    obj(bundle['policies'],POLICY_NAMES,'generation policy descriptors')
    policy_raw={name:descriptor(bundle['policies'][name],2<<20)for name in POLICY_NAMES}
    dep,res=policies(policy_raw,pv['policies'],sha(raw_map),pv['source_archive_sha256'])
    obj(bundle['roles'],('request_producer','response_consumer'),'separate conditional role descriptors')
    roles=[]
    for which,row in bundle['roles'].items():
        obj(row,('expected_pins','grant','model_expected_pins','readiness_review','policies'),'conditional role proof descriptors')
        role_pin_raw=descriptor(row['expected_pins'],1<<20);role_pins=ExpectedRolePins(role_pin_raw);rv=role_pins.check()
        role_model=model_for(descriptor(row['model_expected_pins'],1<<20))
        role_raw=descriptor(row['grant'],1<<16)
        role=authenticate_conditional_role(intent,role_model,role_raw,expected_pins=role_pins)
        if rv['role']!=which:raise ValueError('separate named role differs')
        same(pv['role_evidence'][which],dict(source_manifest_sha256=rv['source_manifest_sha256'],source_archive_sha256=rv['source_archive_sha256'],
            readiness_review_sha256=rv['readiness_review_sha256'],execution_grant_sha256=sha(role_raw)),'keygen conditional role evidence differs')
        if rv['generation_source_archive_sha256']!=pv['source_archive_sha256']:raise ValueError('role generation archive differs')
        for name in ('manifest_sha256','report_sha256','outer_sha256','root_review_sha256'):
            if rv['model_evidence'][name]!=pv['model_evidence'][name]:raise ValueError('all roles must use same actual model integrity proof')
        review=descriptor(row['readiness_review'],1<<20)
        if sha(review)!=rv['readiness_review_sha256']or canonical(parse(review))!=review:raise ValueError('independent role readiness review bytes differ')
        obj(row['policies'],POLICY_NAMES,'conditional policy descriptors')
        for name in POLICY_NAMES:
            raw=descriptor(row['policies'][name],2<<20)
            if sha(raw)!=rv['policies'][name]or canonical(parse(raw))!=raw:raise ValueError('conditional policy bytes differ')
        roles.append(role)
    # The external library policy cannot turn a model/key/source subtree into an installed-code scope.
    for path in dep['library_roots']:
        if any(overlap(Path(path),b)for b in [root,*leaves,*model_roots,*map(Path,static)]):raise ValueError('installed library root overlaps data/source')
    profile=PublicProfile.from_bytes(public_contract.check()['inputs/profile_audit.json'],public_contract.check()['inputs/actual_key_plan.json'])
    return launch,tuple(roles),profile,dep,res,public_records,tuple(static)+tuple(str(p)for p in model_roots)


def _switch(value,p,shape):
    if type(value)is not dict or set(value)!={'a','b','modulus','P','shape'}:raise ValueError('exact genuine key-switch result required')
    same(value['modulus'],dict(Q=p['q_towers'],P=p['p_towers']),'switch Q/P differs');same(value['P'],p['p_towers'],'switch P differs')
    if type(value['shape'])is not tuple or any(type(x)is not int for x in value['shape'])or value['shape']!=shape:raise ValueError('switch physical shape differs')


def generate(launch,profile,core,source_check,checks,counts):
    # All imported runtime dependencies are concrete authenticated modules; no injection seam.
    from qwen_key_store import KeyStore
    iv=launch.intent.check();grant=parse(launch.grant_bytes);p=profile.parameters
    key_lease=core.retain('key_gen',('gen_pke_pair','gen_evaluation_key','gen_rotation_key','KEY_GENERATION_VERSION'))
    original=dict(key_lease.values);pke=original['gen_pke_pair'];evaluation=original['gen_evaluation_key'];rotation=original['gen_rotation_key']
    owners=[];methods=[];retained=[];primary=None;result=None;cleanup_report={}
    def guard():
        launch.check();core.check();key_lease.check()
        for owner,row in zip(owners,methods):
            if any(not same_accessor(getattr(owner,n),fn)for n,fn in row.items()):raise ValueError('original key-store accessor changed')
    def acquire(role,specs,private):
        owner=KeyStore(iv['paths'][role],specs,expected_parent=canonical(grant['parents'][role]),private=private,shield=cleanup_signals)
        owners.append(owner);row={};methods.append(row);row['close']=owner.close
        for name in ('write_array','verify','write_manifest','identity','check'):row[name]=getattr(owner,name)
        guard();return owner,row
    def write(row,name,value,spec):
        description=row['write_array'](name,value);guard();spec.validate(description);return description
    try:
        pub_owner,pub=acquire('public_root',profile.arrays,False)
        priv_owner,priv=acquire('private_root',(profile.secret,),True)
        checks['external_parent_identity_checked_before_creation']=True
        source_check();guard();checks['pre_rng_checks_completed']=True
        pair=pke(p['q_towers'],[],p['degree'],noise_std=p['sigma']);retained.append(pair);counts['primitive_calls']+=1;guard()
        if type(pair)is not dict or set(pair)!={'public_key','secret_key'}:raise ValueError('exact genuine PKE result required')
        secret=pair['secret_key'];retained.append(secret)
        if type(secret)is not list or len(secret)!=len(p['q_towers'])or any(type(row)is not list or len(row)!=p['degree']or any(type(x)is not int for x in row)for row in secret):
            raise ValueError('original nested Python-integer secret required')
        secret_record=write(priv,'secret.npy',secret,profile.secret);counts['private_arrays']=1
        specs={s.name:s for s in profile.arrays}
        arrays={'public_key.npy':write(pub,'public_key.npy',pair['public_key'],specs['public_key.npy'])};counts['public_arrays']=1;counts['pke_pairs']=1
        del retained[0];del pair
        ek=evaluation(secret,q=p['q_towers'],P=p['p_towers'],dnum=p['dnum'],noise_std=p['sigma']);retained.append(ek);counts['primitive_calls']+=1;guard()
        _switch(ek,p,specs['relin_a.npy'].shape)
        for part in ('a','b'):
            name='relin_'+part+'.npy';arrays[name]=write(pub,name,ek[part],specs[name]);counts['public_arrays']+=1
        counts['evaluation_key_pairs']=1;retained.pop();del ek
        for index in profile.rotations:
            source_check();guard()
            generated=rotation(secret,p['q_towers'],p['p_towers'],index,dnum=p['dnum'],noise_std=p['sigma'])
            retained.append(generated);counts['primitive_calls']+=1;guard()
            if type(generated)is not dict or set(generated)!={index}or any(type(k)is not int for k in generated):raise ValueError('one exact genuine rotation result required')
            entry=generated[index];_switch(entry,p,specs[f'rot_{index}_a.npy'].shape)
            for part in ('a','b'):
                name=f'rot_{index}_{part}.npy';arrays[name]=write(pub,name,entry[part],specs[name]);counts['public_arrays']+=1
            counts['rotation_key_pairs']+=1;retained.pop();del entry,generated
            print(canonical(dict(phase='rotation_stored',completed=counts['rotation_key_pairs'],total=166)).decode(),end='',flush=True)
        checks['original_secret_operand_preserved']=True
        same(pub['verify'](),arrays,'complete public readback differs');guard()
        same(priv['verify'](),{'secret.npy':secret_record},'complete secret readback differs');guard()
        checks['all335_public_arrays_authenticated']=True;checks['secret_array_authenticated']=True
        body=public_body(profile,arrays,KEYGEN);public_manifest=body|dict(context_id=sha(canonical(body)));public_raw=canonical(public_manifest)
        private_raw=canonical(dict(schema='cross-qwen-full-private-keys-v1',context_id=public_manifest['context_id'],public_manifest_sha256=sha(public_raw),bindings=bindings(),secret=secret_record))
        internal=ExpectedIds(public_manifest['context_id'],sha(public_raw),KEYGEN,iv['model_id'],iv['request_producer_source_manifest_sha256'],iv['response_consumer_source_manifest_sha256'],sha(private_raw))
        authenticate_private(private_raw,authenticate_public(public_raw,profile,internal,role='client'))
        checks['public_private_manifest_link_authenticated']=True
        if priv['write_manifest'](private_raw)!=private_raw:raise ValueError('private manifest write differs')
        counts['private_files']=2;guard()
        if pub['write_manifest'](public_raw)!=public_raw:raise ValueError('public manifest write differs')
        counts['public_files']=336;guard()
        same(pub['verify'](),arrays,'final public readback differs');same(priv['verify'](),{'secret.npy':secret_record},'final private readback differs');guard()
        stores={}
        for role,owner,row,raw in [('public',pub_owner,pub,public_raw),('private',priv_owner,priv,private_raw)]:
            row['check']();held=os.fstat(owner.directory.fd);parent=os.fstat(owner.parent.fd)
            file=next(f for f in owner.files if f.name==role+'_manifest.json');file.readback();observed=os.fstat(file.fd)
            stores[role]=dict(path=str(owner.root),device=held.st_dev,inode=held.st_ino,mode=stat.S_IMODE(held.st_mode),
                parent=dict(path=str(owner.parent_path),device=parent.st_dev,inode=parent.st_ino,mode=stat.S_IMODE(parent.st_mode)),
                manifest=dict(name=file.name,sha256=sha(raw),state=state(observed)))
            same(stores[role]['parent'],grant['parents'][role+'_root'],'observed granted parent differs')
        checks['all_owned_files_fsynced']=True;checks['root_and_parent_fsync_completed']=True
        checks['final_readback_completed']=True;checks['original_owned_identity_unchanged']=True
        source_check();guard()
        result=dict(context_id=public_manifest['context_id'],public_manifest_sha256=sha(public_raw),private_manifest_sha256=sha(private_raw),stores=stores)
    except BaseException as error:primary=protect_body(error)
    finally:
        captured_owners=tuple(owners);captured_methods=tuple(dict(row)for row in methods);captured_retained=tuple(retained)
        final=Finalizer(cleanup_report,primary)
        def retire():
            final.attempt('generation final binding',guard)
            for row in reversed(captured_methods):
                close=row.get('close')
                if close is not None:final.attempt('original store retirement',lambda close=close:close(primary=primary))
                final.attempt('generation binding after retirement',guard)
            final.attempt('generation final source',source_check)
        final.shielded(cleanup_signals,retire)
        chosen=final.selected()
        if chosen is not None:
            _QUARANTINE.append((captured_owners,captured_methods,captured_retained,core,launch,chosen));raise chosen
        checks['cleanup_completed']=True
        retained.clear()
    return result


def run(args,raw_map,expected,blobs,gate,snapshot,origins):
    launch,roles,profile,dep,res,public_records,protected=admit(args,raw_map,expected,blobs)
    iv=launch.intent.check();pv=launch.expected_pins.check();grant=parse(launch.grant_bytes)
    root=grant['source_root'];audit=None;output=None;output_close=None;output_write=None;output_check=None;core=None;primary=None;result=None
    checks={n:False for n in CHECK_NAMES};counts=dict(pke_pairs=0,evaluation_key_pairs=0,rotation_key_pairs=0,primitive_calls=0,public_arrays=0,private_arrays=0,public_files=0,private_files=0)
    checks['model_admission_authenticated']=True
    report=None;cleanup_report={};backend=None;security=None
    def source_check():
        if snapshot(expected)!=blobs:raise ValueError('current complete source bytes changed')
        origins(expected,core_enabled=gate.core_enabled)
        launch.check()
        for role in roles:role.check()
        environment(dep)
        if audit is not None:audit.check()
        if core is not None:core.check()
        for path,(digest,limit,raw)in public_records.items():
            if read(path,limit=limit,expected=digest)!=raw:raise ValueError('original public authority bytes changed')
    try:
        environment(dep);source_check();checks['source_precheck_completed']=True
        audit=AccessScope(root,expected,public_records,iv,profile,dep,res,protected);audit.install()
        capacity(iv,res,after_import=False);checks['resource_admission_completed']=True
        installed_before=hash_installed(dep)
        from qwen_backend_identity import install_core
        core=install_core(root,blobs,expected,gate=gate)
        gate.core_enabled=True
        modules=core.load(('key_gen','he_params','util','rns'))
        import jax
        import numpy
        platforms=[str(d.platform)for d in jax.devices()]
        if not platforms or any(p!='cpu'for p in platforms)or jax.config.jax_enable_x64 is not True:raise ValueError('genuine CPU/x64 backend required')
        imported_origins(dep,root);same(hash_installed(dep),installed_before,'installed source bytes changed during import')
        lease=core.retain('he_params',('SecurityTarget','qp_is_secure','assert_p_coverage','q_partition_products','DEFAULT_SIGMA','SECRET_DISTRIBUTION'))
        hp=dict(lease.values);p=profile.parameters
        if hp['DEFAULT_SIGMA']!=p['sigma']or hp['SECRET_DISTRIBUTION']!=p['secret_distribution']or modules['key_gen'].KEY_GENERATION_VERSION!=3:
            raise ValueError('original security constants differ')
        if hp['qp_is_secure'](p['q_towers'],p['p_towers'],p['degree'],hp['SecurityTarget'](128,'classical'))is not True:
            raise ValueError('genuine QP security predicate failed')
        hp['assert_p_coverage'](p['q_towers'],p['p_towers'],p['dnum']);lease.check()
        security=dict(target_bits=128,attack='classical',degree=p['degree'],q_towers=len(p['q_towers']),p_towers=len(p['p_towers']),dnum=p['dnum'],
            qp_bits=math.prod(p['q_towers']+p['p_towers']).bit_length(),qp_inclusive_ceiling=3523,p_product_bits=math.prod(p['p_towers']).bit_length(),
            largest_q_partition_bits=max(hp['q_partition_products'](p['q_towers'],p['dnum'])).bit_length(),sigma=p['sigma'],secret_distribution=p['secret_distribution'],
            noise_scale=1,key_generation_version=modules['key_gen'].KEY_GENERATION_VERSION,qp_is_secure=True,p_coverage=True)
        checks['real_security_predicates_completed']=True
        capacity(iv,res,after_import=True);checks['capacity_checks_completed']=True;source_check();lease.check()
        backend=dict(dependency_policy_sha256=pv['policies']['dependency_policy_sha256'],observed_device_platforms=platforms,jax_enable_x64=True,genuine_backend_imports_completed=True)
        audit.enabled=True
        output=Output(iv['paths']['evidence_root'],expected_parent=canonical(grant['parents']['evidence_root']));output_close=output.close
        output_write=output.write;output_check=output.check
        with termination_signals():
            result=generate(launch,profile,core,source_check,checks,counts)
        checks['signals_restored']=True
        source_check();lease.check();same(hash_installed(dep),installed_before,'terminal installed source bytes changed');imported_origins(dep,root)
        checks['source_postcheck_completed']=True
        if not all(checks.values()):raise ValueError('actual generation checks incomplete')
        report=dict(schema='qwen-keygen-actual-report-v1',passed=True,complete=True,error_type=None,
            intent_sha256=sha(launch.intent.raw),grant_sha256=sha(launch.grant_bytes),source_manifest_sha256=sha(raw_map),source_archive_sha256=pv['source_archive_sha256'],
            source_hashes_before=expected,source_hashes_after=expected,model_id=iv['model_id'],model_evidence=pv['model_evidence'],role_evidence=pv['role_evidence'],
            core_source_manifest_sha256=iv['core_source_manifest_sha256'],keygen_source_sha256=KEYGEN,bindings=bindings(),
            request_producer_source_manifest_sha256=iv['request_producer_source_manifest_sha256'],response_consumer_source_manifest_sha256=iv['response_consumer_source_manifest_sha256'],
            **result,counts=counts,security=security,backend=backend,policies=pv['policies'],checks=checks,
            scope=dict(fresh_key_generation=True,new_owned_key_readback=True,**{n:False for n in SCOPE_FALSE}),process=dict(pid=os.getpid(),pgid=os.getpgrp()),audit_denials=[])
        if not same_accessor(output.write,output_write)or not same_accessor(output.check,output_check)or not same_accessor(output.close,output_close):raise ValueError('original output accessor changed')
        output_check();output_write('report.json',canonical(report));output_check();audit.check()
    except BaseException as error:primary=protect_body(error)
    finally:
        final=Finalizer(cleanup_report,primary)
        def retire():
            final.attempt('keygen final source/public binding',source_check)
            if audit is not None:final.attempt('sticky audit after publication',audit.check)
            if primary is not None and output_write is not None and output_check is not None:
                def failure_evidence():
                    if not same_accessor(output.write,output_write)or not same_accessor(output.check,output_check):
                        raise ValueError('original failure-publication accessor changed')
                    output_check()
                    failure=dict(schema='qwen-keygen-incomplete-v1',passed=False,complete=False,
                        error_type=type(primary).__name__,intent_sha256=sha(launch.intent.raw),grant_sha256=sha(launch.grant_bytes),
                        source_manifest_sha256=sha(raw_map),counts=counts,checks=checks,
                        process=dict(pid=os.getpid(),pgid=os.getpgrp()),actual_readiness=False)
                    output_write('failure.json',canonical(failure));output_check()
                final.attempt('bounded incomplete-generation evidence',failure_evidence)
            if output_close is not None:final.attempt('original evidence output close',lambda:output_close(primary=primary))
            if audit is not None:
                final.attempt('final sticky audit before restoration',audit.check)
                final.attempt('original audit wrapper restore',audit.close)
        final.shielded(cleanup_signals,retire)
        chosen=final.selected()
        if chosen is not None:
            _QUARANTINE.append((launch,roles,core,audit,output,report,chosen));raise chosen
    return 0
