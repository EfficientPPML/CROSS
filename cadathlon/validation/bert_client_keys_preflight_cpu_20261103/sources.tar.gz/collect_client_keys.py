"""Public security/resource and mocked key-storage preflight; no actual keygen.

Public CPU backend constants are allowed for the real security predicates.
All fake payloads live only in pytest temporary directories outside the archive.
"""
from pathlib import Path
import argparse,hashlib,importlib.metadata,io,json,os,signal,subprocess,sys,tarfile,time
HERE=Path(__file__).resolve().parent
REPO=Path('/home/jianming_gatech/CROSS')
PLAN=Path('/tmp/bert-twelve-layer-continuation-plan-20261103')

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sources():
    paths={n:HERE/n for n in ('client_keys.py','test_client_keys.py','collect_client_keys.py')}
    paths.update({n:PLAN/n for n in ('p60_profile_and_refresh.json','report.json')})
    paths['server_inputs/twelve_layer_plan.json']=HERE/'server_inputs/twelve_layer_plan.json'
    for path in sorted((REPO/'jaxite_word').rglob('*.py')):
        if not path.name.endswith('_test.py') and not path.name.startswith('test_'):paths[str(path.relative_to(REPO))]=path
    return {n:p.read_bytes() for n,p in paths.items()}
def hashes(raw):return {n:hashlib.sha256(b).hexdigest() for n,b in raw.items()}
def write(path,value):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');temp.replace(path)
def archive(path,raw):
    with tarfile.open(path,'w:gz') as t:
        for n,b in raw.items():m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
def verify_archive(path,before):
    with tarfile.open(path) as t:
        rows=t.getmembers()
        return len(rows)==len(before)==len({m.name for m in rows}) and all(m.isfile() for m in rows) and {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in rows}==before

def stop(child):
    if child is None:return
    if child.poll() is None:
        os.killpg(child.pid,signal.SIGTERM)
        try:child.wait(timeout=30)
        except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    else:child.wait()

def run(output):
    output.mkdir(exist_ok=False);start=time.monotonic();primary=None;cancel=None;child=None;before={};cleanup=[]
    report=dict(passed=False,scope='Metadata/lifecycle/mocked producer preflight only; no actual key generation, encryption, CKKS context or HE.',
        public_CPU_backend_constants_allowed=True,actual_key_generation=False,encrypted_execution=False,
        fake_payloads_archived=False,cpu_affinity=sorted(os.sched_getaffinity(0)))
    def attempt(label,fn):
        nonlocal cancel
        try:return fn()
        except BaseException as e:
            cleanup.append(dict(operation=label,type=type(e).__name__,message=str(e)))
            if primary is not None:primary.add_note(label+': '+repr(e))
            elif not isinstance(e,Exception) and cancel is None:cancel=e
            return None
    try:
        write(output/'report.json',report)
        if os.environ.get('JAX_PLATFORMS')!='cpu':raise ValueError('explicit CPU public-constant initialization required')
        raw=sources();before=hashes(raw);archive(output/'sources.tar.gz',raw)
        if not verify_archive(output/'sources.tar.gz',before):raise ValueError('startup source archive differs')
        report.update(source_hashes_before=before,source_archive_sha256=sha(output/'sources.tar.gz'),
            versions={n:importlib.metadata.version(n) for n in ('numpy','jax','jaxlib','pytest')},
            environment={n:os.environ.get(n) for n in ('JAX_PLATFORMS','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')})
        import client_keys
        def forbidden(*args,**kwargs):raise AssertionError('no actual keygen/HE authorized in preflight')
        client_keys._crypto=forbidden
        p,rotations=client_keys.public_contract(raw['p60_profile_and_refresh.json'],raw['report.json'])
        # Real predicates, without a CKKS context or any secret/public key.
        security=client_keys._security_check(p)
        from jaxite_word import he_params
        for name in ('gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen'):setattr(he_params.kg,name,forbidden)
        resource=client_keys.resources(p,rotations)
        import shutil
        usage=shutil.disk_usage('/dev/shm')
        report.update(security=security,parameters=p,rotation_inventory=list(rotations),resources=resource,
            tmpfs_observation=dict(path='/dev/shm',total_bytes=usage.total,free_bytes=usage.free),
            keygen_guarded_methods=['gen_pke_pair','gen_evaluation_key','gen_rotation_key','key_switch_gen'])
        command=[sys.executable,'-m','pytest','-q',str(HERE/'test_client_keys.py'),'--junitxml='+str(output/'tests.xml')]
        with (output/'tests.log').open('wb') as log:
            child=subprocess.Popen(command,cwd=HERE,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            report['test_child_pid']=child.pid;write(output/'report.json',report)
            if child.wait()!=0:raise ValueError('key helper preflight tests failed')
        import xml.etree.ElementTree as ET
        report['tests']={n:sum(int(x.attrib.get(n,0)) for x in ET.parse(output/'tests.xml').getroot()) for n in ('tests','failures','errors','skipped')}
        if any(report['tests'][n] for n in ('failures','errors','skipped')):raise ValueError('incomplete key helper tests')
        report['passed']=True
    except BaseException as e:primary=e;report.update(passed=False,error=dict(type=type(e).__name__,message=str(e)))
    finally:
        attempt('reap mocked tests',lambda:stop(child))
        after=attempt('source readback',lambda:hashes(sources()));verified=attempt('archive readback',lambda:verify_archive(output/'sources.tar.gz',before)) if before else False
        report.update(source_hashes_after=after,source_files_unchanged=bool(before) and before==after,source_archive_verified=verified is True,
            cleanup_errors=cleanup,elapsed_s=time.monotonic()-start,test_child_reaped=child is None or child.poll() is not None)
        report['passed']=bool(report.get('passed') and report['source_files_unchanged'] and verified and not cleanup)
        try:write(output/'report.json',report)
        except BaseException as e:
            keep=primary if primary is not None else cancel
            if keep is None:raise
            keep.add_note('terminal publication: '+repr(e))
        if primary is not None:raise primary
        if cancel is not None:raise cancel
    print(json.dumps({n:report[n] for n in ('passed','tests','elapsed_s','source_archive_sha256')}));return 0 if report['passed'] else 1
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();raise SystemExit(run(a.output))
